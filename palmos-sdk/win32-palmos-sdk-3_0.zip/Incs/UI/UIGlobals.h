/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 ****************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     Global.h
 * AUTHOR:   Art Lamb: September 12, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *        This file defines global variables used by the UI routines.
 *
 **********************************************************************/

#ifndef __GLOBAL_H__
#define __GLOBAL_H__


#define 	UIDefNumSysFonts  	8		// PalmOS 3.0 has eight system fonts
#define	UIDefNumAppFonts		4		// Space is initially allocated for four app fonts

#define 	eventQueueSize	10


typedef struct UIGlobalsType {

	// Global variables used by the window routines.
	WinHandle			activeWindow;
	WinHandle			displayWindow;
	WinHandle			drawWindow;
	WinHandle			firstWindow;
	WinHandle			exitWindowID;
	WinHandle			enterWindowID;
	WinHandle			exitedWindowID;
	GraphicStateType	gState;
	
	
	// Global variables used by the event routines.
	EventStoreType*	eventQ;
	Word					eventQIndex;
	Word					eventQLength;
	SWord      			lastScreenX;
	SWord      			lastScreenY;
	Boolean    			lastPenDown;
	SDWord				needNullTickCount;		// We want a null Evt when ticks reaches this value
	
	
	// Global variables used by the font routins.
	FontPtr 				uiCurrentFontPtr;
//	FontPtr 				uiFontTable[UINumFonts];// OBSOLETE: in 1.0 & 2.0, UINumFonts=7
	FontTablePtr		uiSysFontTablePtr;		// new for 3.0
	FontTablePtr		uiAppFontTablePtr;		// new for 3.0
	Word					uiNumSysFonts;				// new for 3.0
	Word					uiNumAppFonts;				// new for 3.0
	DWord					uiUnused1;					// new for 3.0, to maintain sizeof(UIGlobalsType)
	DWord					uiUnused2;					// new for 3.0, to maintain sizeof(UIGlobalsType)
	FontID  				uiCurrentFontID;
	
	
	// Global variables used by the form routines.
	FormPtr 				currentForm;
	
	
	// Global variables used by the insertion point routines.
	Boolean				insPtIsEnabled;
	Boolean				insPtOn;
	PointType			insPtLoc;
	SWord					insPtHeight;
	SDWord				insPtLastTick;
	WinHandle			insPtBitsBehind;
	
	// Global variables used by the clipboard routines.
	ClipboardItem 		clipboard[numClipboardForamts];
	
	// Globals used by the Memory Manager
	MenuBarPtr			uiCurrentMenu;
	Word					uiCurrentMenuRscID;
	
	// Global variables used by the field routines.
	FieldUndoType 		undoGlobals;

	// Global variables used by the Griffiti shift state indicator routines.
	Byte					gsiState;
	Boolean				gsiIsEnabled;
	PointType			gsiLocation;

	// Numeric decimal seperator, used in the field routines.
	Char					uiDecimalSeparator;
	
	} UIGlobalsType;
typedef UIGlobalsType* 	UIGlobalsPtr;


#define	ActiveWindow			((UIGlobalsPtr)GUIGlobalsP)->activeWindow
#define	DisplayWindow			((UIGlobalsPtr)GUIGlobalsP)->displayWindow
#define	DrawWindow				((UIGlobalsPtr)GUIGlobalsP)->drawWindow
#define	FirstWindow				((UIGlobalsPtr)GUIGlobalsP)->firstWindow
#define	ExitWindowID			((UIGlobalsPtr)GUIGlobalsP)->exitWindowID
#define	EnterWindowID			((UIGlobalsPtr)GUIGlobalsP)->enterWindowID
#define	ExitedWindowID			((UIGlobalsPtr)GUIGlobalsP)->exitedWindowID
#define	GState					((UIGlobalsPtr)GUIGlobalsP)->gState

#define	EventQ					((UIGlobalsPtr)GUIGlobalsP)->eventQ
#define	EventQIndex				((UIGlobalsPtr)GUIGlobalsP)->eventQIndex
#define	EventQLength			((UIGlobalsPtr)GUIGlobalsP)->eventQLength
#define	LastScreenX				((UIGlobalsPtr)GUIGlobalsP)->lastScreenX
#define	LastScreenY				((UIGlobalsPtr)GUIGlobalsP)->lastScreenY
#define	LastPenDown				((UIGlobalsPtr)GUIGlobalsP)->lastPenDown
#define	NeedNullTickCount		((UIGlobalsPtr)GUIGlobalsP)->needNullTickCount

// UIFontTable no longer exists; use UISysFontPtr and UIAppFontPtr
#define	UICurrentFontPtr		((UIGlobalsPtr)GUIGlobalsP)->uiCurrentFontPtr
#define	UISysFontTablePtr		((UIGlobalsPtr)GUIGlobalsP)->uiSysFontTablePtr
#define	UIAppFontTablePtr		((UIGlobalsPtr)GUIGlobalsP)->uiAppFontTablePtr
#define	UISysFontPtr			(((UIGlobalsPtr)GUIGlobalsP)->uiSysFontTablePtr)
#define	UIAppFontPtr			(((UIGlobalsPtr)GUIGlobalsP)->uiAppFontTablePtr)
#define	UINumSysFonts			((UIGlobalsPtr)GUIGlobalsP)->uiNumSysFonts
#define	UINumAppFonts			((UIGlobalsPtr)GUIGlobalsP)->uiNumAppFonts
#define	UICurrentFontID		((UIGlobalsPtr)GUIGlobalsP)->uiCurrentFontID

#define	CurrentForm				((UIGlobalsPtr)GUIGlobalsP)->currentForm

#define	InsPtIsEnabled			((UIGlobalsPtr)GUIGlobalsP)->insPtIsEnabled
#define	InsPtOn					((UIGlobalsPtr)GUIGlobalsP)->insPtOn
#define	InsPtLoc					((UIGlobalsPtr)GUIGlobalsP)->insPtLoc
#define	InsPtHeight				((UIGlobalsPtr)GUIGlobalsP)->insPtHeight
#define	InsPtLastTick			((UIGlobalsPtr)GUIGlobalsP)->insPtLastTick
#define	InsPtBitsBehind		((UIGlobalsPtr)GUIGlobalsP)->insPtBitsBehind

#define	Clipboard				((UIGlobalsPtr)GUIGlobalsP)->clipboard

#define	UICurrentMenu			((UIGlobalsPtr)GUIGlobalsP)->uiCurrentMenu
#define	UICurrentMenuRscID	((UIGlobalsPtr)GUIGlobalsP)->uiCurrentMenuRscID
#define	UndoGlobals				((UIGlobalsPtr)GUIGlobalsP)->undoGlobals

#define	GsiState					((UIGlobalsPtr)GUIGlobalsP)->gsiState
#define	GsiIsEnabled			((UIGlobalsPtr)GUIGlobalsP)->gsiIsEnabled
#define	GsiLocation				((UIGlobalsPtr)GUIGlobalsP)->gsiLocation

#define	UIDecimalSeparator	((UIGlobalsPtr)GUIGlobalsP)->uiDecimalSeparator


#endif //__GLOBAL_H__


