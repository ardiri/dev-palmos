/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ******************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     menu.h
 * AUTHOR:	 Roger Flores: November 18, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file defines menu structures and routines.
 *
 ***********************************************************************/

#ifndef __MENU_H__
#define __MENU_H__


#define noMenuSelection			-1
#define noMenuItemSelection	-1
#define separatorItemSelection	-2


// To match Apple's ResEdit the first byte of a menu item's text can
// be a special char indicating a special menu item.
#define MenuSeparatorChar			'-'



typedef struct {
	Word						id;				// id of the menu item
	Char						command;			// command key
	CharPtr					itemStr;			// string to be displayed
} MenuItemType;


typedef struct {
	WinHandle				menuWin;			// window of pull-down menu
	RectangleType			bounds;			// bounds of the pulldown
	WinHandle				bitsBehind;		// saving bits behind pull-down menu
	RectangleType			titleBounds;	// bounds of the title in menu bar
	CharPtr					title;			// menu title displayed in menu bar
	Word						numItems;		// number of items in the menu
	MenuItemType *			items;			// array of menu items
} MenuPullDownType;

typedef MenuPullDownType * MenuPullDownPtr;

typedef struct {
	Word visible			:1;			// Set if menu bar is drawn
	Word commandPending	:1;			// Set if next key is a command
	Word insPtEnabled	:1;			// Set if insPt was on when menu was drawn
} MenuBarAttrType;


typedef struct {
	WinHandle				barWin;			// window of menu bar
	WinHandle				bitsBehind;		// saving bits behind menu bar
	WinHandle				savedActiveWin;
	WinHandle				bitsBehindStatus;
	MenuBarAttrType 		attr;
	SWord						curMenu;			// current menu or -1 if none
	SWord						curItem;			// current item in curMenu, -1 if none
	SDWord					commandTick;	//
	SWord						numMenus;		// number of menus
	MenuPullDownPtr  		menus;			// array of menus
} MenuBarType;

typedef MenuBarType * MenuBarPtr;


#ifdef __cplusplus
extern "C" {
#endif

extern MenuBarPtr MenuInit (const Word resourceId)
							SYS_TRAP(sysTrapMenuInit);

extern MenuBarPtr MenuGetActiveMenu (void)
							SYS_TRAP(sysTrapMenuGetActiveMenu);

extern MenuBarPtr MenuSetActiveMenu (const MenuBarPtr pMenu)
							SYS_TRAP(sysTrapMenuSetActiveMenu);

extern void MenuDispose (const MenuBarPtr pMenu)
							SYS_TRAP(sysTrapMenuDispose);

extern Boolean MenuHandleEvent (MenuBarPtr pMenu, const EventPtr event,
	const WordPtr error)
							SYS_TRAP(sysTrapMenuHandleEvent);

extern void MenuDrawMenu (const MenuBarPtr pMenu)
							SYS_TRAP(sysTrapMenuDrawMenu);

extern void MenuEraseStatus (const MenuBarPtr pMenu)
							SYS_TRAP(sysTrapMenuEraseStatus);

extern void MenuSetActiveMenuRscID (const Word resourceId)
							SYS_TRAP(sysTrapMenuSetActiveMenuRscID);

#ifdef __cplusplus 
}
#endif

#endif //__MENU_H__
