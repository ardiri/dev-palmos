/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ******************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     field.h
 * AUTHOR:	 Art Lamb: August 29, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file defines field structures and routines.
 *
 ***********************************************************************/
#ifndef __FIND_H__
#define __FIND_H__

#define maxFinds			9
#define maxFindStrLen	16

typedef struct {
	Word				appCardNo;			// card number of the application
	LocalID			appDbID;				// LocalID of the application
	Boolean			foundInCaller;		// true if found in app that called Find

	Word				dbCardNo;			// card number of the database record was found in
	LocalID			dbID;					// LocalID of the database record was found in
	Word 				recordNum;			// index of record that contain a match
	Word				matchPos;			// postion in record of the match.
	Word				matchFieldNum;		// field number
	DWord				matchCustom;			// app specific data
	} FindMatchType;

typedef FindMatchType * FindMatchPtr;

typedef struct {

	// These fields are used by the applications.
	Word				dbAccesMode;		// read mode and maybe show secret
	Word 				recordNum;			// index of last record that contained a match
	Boolean			more;					// true of more matches to display
	Char				strAsTyped [maxFindStrLen+1];	// search string as entered
	Char				strToFind [maxFindStrLen+1];	// search string is lower case


	// These fields are private to the Find routine and should NOT be accessed by
	//  applications.
	Word				numMatches;			// # of matches
	Word				lineNumber;			// next line in the results tabel
	Boolean			continuation;		// true if contining search of same app
	Boolean			searchedCaller;	// true after we've searched app that initiated the find

	LocalID			callerAppDbID;		// dbID of app that initiated search
	Word				callerAppCardNo;	// cardNo of app that initiated search

	LocalID			appDbID;				// dbID of app that we're currently searching
	Word				appCardNo;			// card number of app that we're currently searching
	
	Boolean			newSearch;			// true for first search
	DmSearchStateType	searchState;	// search state
	FindMatchType	match [maxFinds];
} FindParamsType;

typedef FindParamsType * FindParamsPtr;


// Param Block passsed with the sysAppLaunchCmdGoto Command
typedef struct {
	Word				searchStrLen;		// length of search string.
	Word				dbCardNo;			// card number of the database	
	LocalID			dbID;					// LocalID of the database
	Word 				recordNum;			// index of record that contain a match
	Word				matchPos;			// postion in record of the match.
	Word				matchFieldNum;		// field number string was found int
	DWord				matchCustom;			// application specific info
	} GoToParamsType;

typedef GoToParamsType * GoToParamsPtr;


//----------------------------------------------------------
//	Find Functions
//----------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

void Find (GoToParamsPtr goToP)
			SYS_TRAP(sysTrapFind);
		

Boolean FindStrInStr (const CharPtr strToSearch, const CharPtr strToFind, 
	const WordPtr posP)
			SYS_TRAP(sysTrapFindStrInStr);

Boolean FindSaveMatch (const FindParamsPtr findParams, const Word recordNum, 
	const Word pos, const Word fieldNum, const DWord appCustom, 
	const Word cardNo, const LocalID dbID)
			SYS_TRAP(sysTrapFindSaveMatch);

void FindGetLineBounds (const FindParamsPtr findParams, const RectanglePtr r)
			SYS_TRAP(sysTrapFindGetLineBounds);

Boolean FindDrawHeader (const FindParamsPtr findParams, const CharPtr title)
			SYS_TRAP(sysTrapFindDrawHeader);

#ifdef __cplusplus 
}
#endif

#endif __FIND_H__
