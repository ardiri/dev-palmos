/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ******************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     CharAttr.h
 * AUTHOR:   Art Lamb: April 21, 1995
 *
 * DECLARER: Toolbox
 *
 * DESCRIPTION:
 *        This file defines character classification and character
 *        conversion macros
 *
 **********************************************************************/

#ifndef _CHAR_ATTR_H
#define _CHAR_ATTR_H

// Character attribute code bits
#define _XA		0x200 	// extra alphabetic
#define _XS		0x100 	// extra space
#define _BB		0x80 		// BEL, BS, etc.
#define _CN		0x40 		// CR, FF, HT, NL, VT
#define _DI		0x20 		// '0'-'9'
#define _LO		0x10 		// 'a'-'z' and lowercase extended chars.
#define _PU		0x08 		// punctuation
#define _SP		0x04 		// space
#define _UP		0x02 		// 'A'-'Z' and uppercase extended chars.
#define _XD		0x01 		// '0'-'9', 'A'-'F', 'a'-'f'


// Character classification macros.
// If these are used to test characters from events (keyDownEvent)
// IsAscii should be used first.
#define IsAscii(c)			(c <= 255)
#define IsAlNum(attr,c)		(attr[(Byte)(c)] & (_DI|_LO|_UP|_XA))
#define IsAlpha(attr,c)		(attr[(Byte)(c)] & (_LO|_UP|_XA))
#define IsCntrl(attr,c)		(attr[(Byte)(c)] & (_BB|_CN))
#define IsDigit(attr,c)		(attr[(Byte)(c)] & _DI)
#define IsGraph(attr,c)		(attr[(Byte)(c)] & (_DI|_LO|_PU|_UP|_XA))
#define IsLower(attr,c)		(attr[(Byte)(c)] & _LO)
#define IsPrint(attr,c)		(attr[(Byte)(c)] & (_DI|_LO|_PU|_SP|_UP|_XA))
#define IsPunct(attr,c)		(attr[(Byte)(c)] & _PU)
#define IsSpace(attr,c)		(attr[(Byte)(c)] & (_CN|_SP|_XS))
#define IsUpper(attr,c)		(attr[(Byte)(c)] & _UP)
#define IsHex(attr,c)		(attr[(Byte)(c)] & _XD)
#define IsDelim(attr,c)		(attr[(Byte)(c)] & _SP|_PU)


#ifdef __cplusplus
extern "C" {
#endif


WordPtr GetCharAttr (void)
			SYS_TRAP(sysTrapGetCharAttr);

BytePtr GetCharSortValue (void)
			SYS_TRAP(sysTrapGetCharSortValue);

BytePtr GetCharCaselessValue (void)
			SYS_TRAP(sysTrapGetCharCaselessValue);


#ifdef __cplusplus 
}
#endif


#endif /* _CHAR_ATTR_H */
