/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SerialLibMac.h
 *
 * Description:
 *		Include file for Mac Serial Library
 *
 * History:
 *   	6/30/95 Created by Vitaly Kruglikov
 *
 *******************************************************************/

#ifndef __SERIAL_LIB_MAC_H
#define __SERIAL_LIB_MAC_H


// Pilot common definitions
#include "Common.h"
#include "SerialMgr.h"

// Maximum size of our receive window. We have to emulate this
//  functionality on the Mac by reading out of the Mac's serial
//  driver into a temporary buffer maintained by the Serial Library
// in the emulator.
#define	serFakeIntQueueSize			0x100

// scanning mode states
#define scmOff								0	// scanning disabled
#define scmIdle							1	// idle while port is in use
#define scmActive							2	// active 

/********************************************************************
 * Serial Globals
 ********************************************************************/
typedef struct SerMacGlobalsType {
	UInt					refNum;				// port reference number
	UInt					openCount;			// number of times we have been opened
	UInt					port;
	SerSettingsType	settings;
	Word					lineErrors;			// line errors bitfield
	DWord					maxBaud;				// maximum supported baud rate
	Boolean				breakIsOn;			// set to true when break signal is started, false when it is stopped
	
	short					inRefNum;			// input driver reference number
	short					outRefNum;			// output driver reference number
	Ptr					inBufP;				// custom input buffer ptr
	
	// THe following fields are used to emulate the SerReceiveWindowOpen
	//  and SerReceiveWindowClose() routines in the Emulator. 
	Boolean				windowOpen;			// non-zero if window currently open
													//   used for error checking.
	Word					windowOffset;		// next available byte in intQueue;
	Word					windowSize;			// # of bytes read into "int queue"
	Byte					intQueue[serFakeIntQueueSize];	// fake Int. queue"
	SerCallbackEntryType
							blockingHook;		// blocking hook callback

	// Receive Queue semaphore info
	SerWakeupHandler		wakeupHandler;		// Wakeup handler, if installed
	DWord					wakeupRefcon;		// refcon for wakeup handler
	Word					smSignalSize;		// How much the semaphore is waiting for
	ULong					emTaskID;			// Task ID of interrupt simulator 

	// IrDA stuff
	Boolean				irdaMode;			// true if UART is set to IrDA mode
	Byte					scanningMode;     // true if background Ir scanning enabled
	SerWakeupHandler	scanWakeHandler;	// scannning Wakeup handler,
	DWord					scanWakeParam;	   // parameter to pass to wake handler
	} SerMacGlobalsType;
typedef SerMacGlobalsType*	SerMacGlobalsPtr;	

#define	serDefaultRcvBufferSize	(30*1024)

Err		SerPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);
#endif	//__SERIAL_LIB_MAC_H
