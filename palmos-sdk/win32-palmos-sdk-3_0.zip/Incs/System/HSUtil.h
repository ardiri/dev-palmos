/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		HSUtil.h
 *
 * Description:
 *		HotSync utility definitions.
 *
 *		Platform-independence data conversion macros.
 *
 * History:
 *   	7/19/96  vmk	Created by Vitaly Marty Kruglikov
 *
 *******************************************************************/

#ifndef __HS_UTIL_H__
#define __HS_UTIL_H__

// Cross-map Pilot types used in common headers to Microsoft VC++ types
#ifdef _MSC_VER
	typedef BYTE	Byte;
	typedef WORD	Word;
	typedef DWORD	DWord;
	typedef DWord	ULong;
	typedef void*	VoidPtr;
	typedef ULong*	ULongPtr;
	typedef Word	UInt;
#endif


//-----------------------------------------------------------
// Platform-independence macros
//-----------------------------------------------------------

#define	HSUtilReverseWord(__theWord__)						\
	(	(Word)															\
		(																	\
		(((Word)(__theWord__) << 8) & 0xFF00) |				\
		(((Word)(__theWord__) >> 8) & 0x00FF)					\
		)																	\
	)

#define	HSUtilReverseDWord(__theDWord__)						\
	(	(DWord)															\
		(																	\
		(((DWord)(__theDWord__) << 24) & 0xFF000000L) |		\
		(((DWord)(__theDWord__) << 8) & 0x00FF0000L) |		\
		(((DWord)(__theDWord__) >> 8) & 0x0000FF00L) |		\
		(((DWord)(__theDWord__) >> 24) & 0x000000FFL)		\
		)																	\
	)

#if ((defined(CPU_TYPE) && CPU_TYPE == CPU_68K) || defined(_MAC) || defined(_68K_) )
	#define	HSUtilPilotToHostWord(__theWord__)				\
			(__theWord__)
	
	#define	HSUtilPilotToHostDWord(__theDWord__)			\
			(__theDWord__)
	
	#define	HSUtilHostToPilotWord(__theWord__)				\
			(__theWord__)
	
	#define	HSUtilHostToPilotDWord(__theDWord__)			\
			(__theDWord__)
			
#else		// CPU_TYPE != CPU_68K
	#define	HSUtilPilotToHostWord(__theWord__)				\
			HSUtilReverseWord(__theWord__)
	
	#define	HSUtilPilotToHostDWord(__theDWord__)			\
			HSUtilReverseDWord(__theDWord__)
	
	#define	HSUtilHostToPilotWord(__theWord__)				\
			HSUtilReverseWord(__theWord__)
	
	#define	HSUtilHostToPilotDWord(__theDWord__)			\
			HSUtilReverseDWord(__theDWord__)
#endif	//CPU_TYPE == CPU_68K



#endif // __HS_UTIL_H__
