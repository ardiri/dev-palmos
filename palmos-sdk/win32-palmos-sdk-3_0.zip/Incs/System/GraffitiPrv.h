/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		GraffitiPRV.h
 *
 * Description:
 *		Private Header for the Graffiti interface
 *
 * History:
 *   	6/30  RM - Created by Ron Marianetti
 *
 *******************************************************************/

#ifdef	NON_PORTABLE
#ifndef __GRAFFITIPRV_H__
#define __GRAFFITIPRV_H__



#define	DP3MachineMacintosh
#include <P3API.h>


/************************************************************
 * Graffiti Constants
 *************************************************************/
// Bytes that follow the grfSpecialSequence byte in Graffiti dictionary
//  or macros. These are used for special test code and debugging
#define	grfSpecialToggleSplitMode	0x01		// Toggle split mode
#define	grfSpecialNoAutoOff			0x02		// Disable auto-off
#define	grfSpecialShowUserInfo		0x03		//	Display user information
#define	grfSpecialDeleteUserInfo	0x04		//	Delete user name & id
#define	grfSpecialSystemBuildDate	0x05		//	Show System Build date
#define	grfSpecialBatteryKind		0x06		//	Change battery kind

// Max # of keys returned from dictionary or macros 
#define	grfMaxKeys				100				

// Resource type and ID of macros resource
#define	grfMacrosResT			'macr'
#define	grfMacrosResID			10000
#define	grfMacrosMinSize		10					// min size of macros resource

// Version of Graffiti Macros database
#define	grfMacrosDBVersion	0					// version word


// Constant used to translate internal Graffiti Warnings into Pilot error codes
#define	grfWarningOffset		128


/************************************************************
 * Graffiti Globals
 *************************************************************/
#define grfMaxMacroName 	32
typedef struct GrfGlobalsType {
	TP3Data				p3Data;
	TP3DictState 		state;
	Int					uncertain;
	Word					glyphFlags;
	Word					shiftState;				// temp shift state
	
	SWord					macroNameLen;
	Byte					macroName[grfMaxMacroName];
	Byte					lastChar;
	
	ULong					globalsSize;
	
	
	// Various flags  
	Word					splitMode : 1;
	Word					restoreCaps : 1;
	Word					inMacro : 1;
	Word					wasAutoShifted : 1;
	
	// Glyph ID assigned to the up-stroke
	Byte					upShiftGlyphID;
	
	// Handle to P3 private globals
	Handle				globalsH;
	
	// Handle to template file
	Handle				templateH;
	
	// Handle to dictionary
	Handle				dictH;
	
	// Handle to macros resource
	Handle				macrosH;
	// Database acccess pointer to macros database
	DmOpenRef			macrosDbP;
	
	} GrfGlobalsType;
	
typedef GrfGlobalsType*	GrfGlobalsPtr;


#endif //__GRAFFITIPRV_H__
#endif // NON_PORTABLE



