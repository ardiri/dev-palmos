/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SoundPrv.h
 *
 * Description:
 *		Private Include file for Sound Manager
 *
 * History:
 *   	4/11/95  VMK - Created by Vitaly Kruglikov
 *
 *******************************************************************/

#ifdef	NON_PORTABLE

#ifndef __SOUNDPRV_H__
#define __SOUNDPRV_H__

// Convert milliseconds to PilotOS ticks
#define sndMilliSecToPilotTicks(milliSec)	(((milliSec) * (DWord)sysTicksPerSecond + 500) / 1000)

#define sndPilotTicksToMilliSec(ticks)	(((ticks) * 1000L) / sysTicksPerSecond)


/************************************************************
 * Sound Manager constants
 *************************************************************/

#define	sndSamplingRate					8000	// 8 kHz


// DOLATER: determine appropriate values experimentally (TBD)
#define	sndBeepDurationMSec				70				// msec
#define	sndConfirmationDurationMSec	70				// msec
#define	sndClickDurationMSec				9				// msec

// These frequencies are more audible on the current hardware.
#define	sndInfoFreq							500			// Hz
#define	sndWarningFreq						500			// Hz
#define	sndErrorFreq						500			// Hz
#define	sndConfirmationFreq				500			// Hz
#define	sndStartUpFreq						1000			// Hz
#define	sndClickFreq						200			// Hz


/*******************************************************************
 * Sound Manager Globals
 *
 *******************************************************************/
typedef struct SndGlobalsType {
	Long				smID;					// semaphore id for data access integrity
	Byte				sysAmp;				// system sound amplitude(0-sndMaxVolume)
	Byte				alarmAmp;			// alarm sound amplitude(0-sndMaxVolume)
	Byte				defAmp;				// default amplitude for other sounds(0-sndMaxVolume)
	WordPtr			wMidiFrqTabP;		// pointer to MIDI frequency table
#if EMULATION_LEVEL != EMULATION_NONE
	ULong				timerID;				// "sound-kill" timer ID (emulation only)
#endif
	} SndGlobalsType;

typedef SndGlobalsType*		SndGlobalsPtr;



/********************************************************************
 * Interal Sound Manager Routines
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

// Internally-used Sound Manager functions
extern Boolean ISndFrqOn(DWord dwFrq, Word wAmp);
extern void ISndSoundOff(void);
extern Err ISndMidiInit(SndGlobalsPtr gP);
extern Err ISndMidiNoteOn(SndGlobalsPtr gP, Byte bKey, Byte bVel, UInt relAmp, Boolean* soundOnP);



#ifdef __cplusplus 
}
#endif


#endif  // __SOUNDPRV_H__
#endif  // NON_PORTABLE
