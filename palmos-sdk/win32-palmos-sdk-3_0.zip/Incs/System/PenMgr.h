/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		PenMgr.h
 *
 * Description:
 *		Include file for Pen manager
 *
 * History:
 *   	6/5/96 Created by Ron Marianetti
 *
 *******************************************************************/

#ifndef __PEN_MGR_H
#define __PEN_MGR_H

// Pilot common definitions
#include <Common.h>
#include <SystemMgr.h>


/********************************************************************
 * Pen Manager Errors
 * the constant serErrorClass is defined in SystemMgr.h
 ********************************************************************/
#define	penErrBadParam				(penErrorClass | 1)



/********************************************************************
 * Pen manager Routines
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


// Initializes the Pen Manager
Err	PenOpen(void)
				SYS_TRAP(sysTrapPenOpen);

// Closes the Pen Manager and frees whatever memory it allocated
Err 	PenClose(void)
				SYS_TRAP(sysTrapPenClose);
				

// Put pen to sleep
Err	PenSleep(void)
				SYS_TRAP(sysTrapPenSleep);

// Wake pen
Err	PenWake(void)
				SYS_TRAP(sysTrapPenWake);
				

// Get the raw pen coordinates from the hardware. 
Err 	PenGetRawPen(PointType* penP)
				SYS_TRAP(sysTrapPenGetRawPen);
				
// Reset calibration in preparation for setting it again
Err	PenResetCalibration (void)
				SYS_TRAP(sysTrapPenResetCalibration);

// Set calibration settings for the pen
Err	PenCalibrate (PointType* digTopLeftP, PointType* digBotRightP,
					PointType* scrTopLeftP, PointType* scrBotRightP)
				SYS_TRAP(sysTrapPenCalibrate);

// Scale a raw pen coordinate into screen coordinates
Err 	PenRawToScreen(PointType* penP)
				SYS_TRAP(sysTrapPenRawToScreen);
				
// Scale a screen pen coordinate back into a raw coordinate
Err 	PenScreenToRaw(PointType* penP)
				SYS_TRAP(sysTrapPenScreenToRaw);
				

#ifdef __cplusplus
}
#endif

	
/************************************************************
 * Assembly Function Prototypes
 *************************************************************/
#define	_PenGetRawPen		\
				ASM_SYS_TRAP(sysTrapPenGetRawPen)



#endif	//__PEN_MGR_H
