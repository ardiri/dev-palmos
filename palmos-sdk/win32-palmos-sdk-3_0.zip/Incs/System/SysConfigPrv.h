/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SysConfigPrv.h
 *
 * Description:
 *		Private system configuration defines
 *
 * History:
 *   	8/23/96  RM - Created by Ron Marianetti
 *   12/10/97  SL - Rewrote memCalcDynamicRAMSize macro
 *
 *******************************************************************/

#ifdef	NON_PORTABLE

#ifndef __SYSCONFIGPRV_H__
#define __SYSCONFIGPRV_H__




/************************************************************
 * Private Memory Manager Constants
 *************************************************************/
#define mem32K		0x008000
#define mem64K		0x010000
#define mem96K		0x018000
#define mem128K	0x020000
#define mem256K	0x040000
#define mem512K	0x080000
#define mem1MB		0x100000
#define mem2MB		0x200000


//==========================================================================
// Default size of the dynamic heap
// This macro accepts the total RAM in card 0 as a parameter and returns
//  the number of bytes to assign to the dynamic heap
// 
// IMPORTANT!! Only certain sizes are supported by the hardware. This section
//   makes sure that the setting is one of the sizes supported by the hardware.
//   The routine HwrGetRAMSize() in ROMHardwareXXX.c is responsible for setting
//   up the chip select registers appropriately for each possible value of
//   DYN_MEM_SIZE.  
//
// <RM> 1-16-98, Replaced DYN_MEM_SIZE equate with DYN_MEM_SIZE_MIN &
//   DYN_MEM_SiZE_MAX
// <SL> 1-20-98, Added DYN_MEM_SIZE_EXTRA for Jerry and Cessna...
// WAS:
/*
	#ifndef DYN_MEM_SIZE
	#error	Build option DYN_MEM_SIZE not setup
	#endif

	#if 		DYN_MEM_SIZE == mem128K
	#define	memCalcDynamicRAMSize(totalSize) 		\
			((totalSize > mem1MB ) ? mem128K : ((totalSize > mem128K) ? mem96K : mem32K))
			// EvenBigger: 	>1MB --> 128K;							>128KB --> 96K;	else --> 32K

	#elif		DYN_MEM_SIZE == mem96K
		#define	memCalcDynamicRAMSize(totalSize) 	\
			((totalSize > mem1MB ) ? mem96K : ((totalSize > mem128K) ? mem64K : mem32K))
			// EvenBigger: 	>1MB --> 96K;							>128KB --> 64K;	else --> 32K

	#elif 	DYN_MEM_SIZE == mem64K
		#define	memCalcDynamicRAMSize(totalSize) 	\
			((totalSize > mem128K) ? mem64K : mem32K)
			// BigHeap: >128KB --> 64K; else 32K

	#elif 	DYN_MEM_SIZE == mem32K
		#define	memCalcDynamicRAMSize(totalSize)	mem32K
			// SmallHeap: always 32K

	#else
		#error	"Unsupported setting for DYN_MEM_SIZE!!"

	#endif
*/
//==========================================================================

#ifdef	DYN_MEM_SIZE
	#error	Error! Obsolete define DYN_MEM_SIZE used
#endif

#ifndef DYN_MEM_SIZE_MIN
	#error	Build option DYN_MEM_SIZE_MIN not setup
#endif

#ifndef DYN_MEM_SIZE_MAX
	#error	Build option DYN_MEM_SIZE_MAX not setup
#endif

#ifndef DYN_MEM_SIZE_EXTRA
	#error	Build option DYN_MEM_SIZE_EXTRA not setup
#endif

// PalmOS 1.0 always has a 32K dynamic heap
// PalmOS 2.0 Personal ROM always has a 32K dynamic heap
// PalmOS 2.0 Professional ROM always has a 64K dynamic heap
//
// PalmOS 3.0 default dynamic heap calcuation:
// 	Systems with >1 MB of RAM get a 96K dynamic heap
// 	Systems with >128K of RAM get a 64K dynamic heap
// 	Systems with  128K of RAM get a 32K dynamic heap
//
// Some systems may have extra requirements in order to
// function regardless of how much total RAM is installed.
// This gets specified in the DYN_MEM_SIZE_EXTRA build parm.
// Since this extra memory is used by these systems, it is
// not generally available for application use.

#define	prvDefaultSize(totalSize)				\
		((totalSize > mem1MB ) ? mem96K : 		\
		 (totalSize > mem128K) ? mem64K :  		\
		  mem32K) + DYN_MEM_SIZE_EXTRA
		
#define	memCalcDynamicRAMSize(totalSize)		\
		((prvDefaultSize(totalSize) > DYN_MEM_SIZE_MAX) ? DYN_MEM_SIZE_MAX : \
		 (prvDefaultSize(totalSize) < DYN_MEM_SIZE_MIN) ? DYN_MEM_SIZE_MIN : \
		 prvDefaultSize(totalSize))


#define	memCalcDynamicHeapSize(totalSize) 		\
		(memCalcDynamicRAMSize(totalSize)-sysLowMemSize)


#endif  // __SYSCONFIGPRV_H__
#endif //NON_PORTABLE
