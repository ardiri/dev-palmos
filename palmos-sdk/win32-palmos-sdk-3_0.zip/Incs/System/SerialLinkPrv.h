/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SerialLinkPrv.c
 *
 * Description:
 *		Private Serial Link includes
 *
 * History:
 *   	2/6/95 replaces DSerial.h from Debugger 
 *
 *******************************************************************/

#ifdef	NON_PORTABLE

#ifndef __SERIALLINKPRV_H
#define __SERIALLINKPRV_H

#include <SerialLinkMgr.h>


//*************************************************************************
//  Misc Constants
//*************************************************************************
// Default timeout  value once into receiving a packet in ticks
#define		slkDefaultInPktTimeout		(sysTicksPerSecond*2)




/*******************************************************************
 * Serial Link Globals
 *
 *******************************************************************/
#define	slkMaxSockets		5						// max # of sockets
#define	slkMaxRefNums		slkMaxSockets		// max # of refNums in use at any one time
#define	slkAnySocket		0xFF		

#define	slkEmptyRefNum		0xFF					// used to track empty refInfos

// We keep an array of these (slkMaxSockets in size) to track which
//  librarie's we've received packet headers for. Since we can have up
//  to slkMaxSockets unique refNums in use at any one time, we must make
//  the array at least that size.
typedef struct SlkRefInfoType {
	Byte		refNum;									// refNum of library, or 0xFF if empty
	SByte		destID;									// dest socketID, or -1 if none
	} SlkRefInfoType;
typedef SlkRefInfoType* SlkRefInfoPtr;	

typedef struct SlkGlobalsType {
	UInt						openCount;
	
	Byte						socketRefNum[slkMaxSockets];
	Boolean					socketOpen[slkMaxSockets];
	SlkSocketListenPtr	socketListenP[slkMaxSockets];
	Word						socketTimeout[slkMaxSockets];		// inPacket timeout
	
	
	// We can keep track of packets coming in for up to slkMaxRefNums libraries.
	//  This array holds the destination socket ID for packets received from
	//  each library.
	SlkRefInfoType			refInfo[slkMaxRefNums];
	
	Byte						transId;					// next transaction ID
	DWord						xmitSemaphoreID;		// Semaphore ID for transmitting
	Word						numReceived;			// # of packets received since serial link
															// was opened.
	} SlkGlobalsType;

typedef SlkGlobalsType*	SlkGlobalsPtr;


	
#endif	//__SERIALLINKPRV_H

#endif 	//NON_PORTABLE