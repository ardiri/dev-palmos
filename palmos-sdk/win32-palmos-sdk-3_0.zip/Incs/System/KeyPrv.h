/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		KeyPrv.h
 *
 * Description:
 *		Private Include file for Key manager
 *
 * History:
 *   	9/13/95 Created by Ron Marianetti
 *
 *******************************************************************/

#ifdef	NON_PORTABLE
#ifndef __KEYPRV_H
#define __KEYPRV_H


/********************************************************************
 * Key Manager Constants
 ********************************************************************/
#define	keyMinUpTicks					(sysTicksPerSecond/20)	// Min# of ticks key must be up to recognize it

#define	keyMinBacklightTicks			(sysTicksPerSecond)		// Min# of ticks key must be held down to
																				// turn on backlight

#define	keyBitMask						0x007F	// Which bits in port D we use for keys

/********************************************************************
 * Key Manager Globals
 ********************************************************************/
typedef struct KeyGlobalsType {
	ULong		lastKeyTicks;					// GHwrCurTicks last time we enqueued
													//  a key event - cleared as soon as
													//  key is released.
													

	Byte		keyState;						// current state of hardware keys - returned
													// by KeyCurrentState
	Byte		keyStateMask;					// which keys generate an event
	Byte		keyUpCount;						// # of consecutive times we've detected
													// no keys down - used for debouncing
	Byte		initDelay;						// key repeat init delay in ticks
	Byte		period;							// key repeat period in ticks
	
	DWord		turnOnTicks;					// Tickcount for key that turned
													// device on. Used for
													// detecting when we should turn on backlight
	
	// These variables used for sensing double-taps
	ULong		doubleTapTicks;				// GHwrCurTicks last tiem we enqueued
													//  a key event - never cleared. 
	Word		doubleTapDelay;				// double-tap timeout in ticks
	Byte		doubleTapState;				// state of hardware keys last time
	
	// Belongs next to 'period' but put here for alignment
	Boolean	queueAhead;						// if true, enqueue auto-repeat keys even if 
													// queue is not empty.
	} KeyGlobalsType;
	
typedef KeyGlobalsType*	KeyGlobalsPtr;





/********************************************************************
 * Key manager Routines
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

// Called early on during boot-up to get status of hard reset
//  and debugger key options. Returns DWord with bits set for each
//  key down.
DWord		KeyBootKeys(void);
				

// Initializes the Key Manager and allocates it's globals
Err		KeyInit(void)
				SYS_TRAP(sysTrapKeyInit);


// Called as a result of a key-down interrupt or periodically by
//  by timer task while key is down. Returns # of ticks before
//  it should be called again by timer task.
ULong		KeyHandleInterrupt(Boolean periodic, DWord status)
				SYS_TRAP(sysTrapKeyHandleInterrupt);
				
			
// Called by SysEvtMgr when it gets a pen event in order to
//  reset the key manager's double-tap detection.
Err		KeyResetDoubleTap(void)
				SYS_TRAP(sysTrapKeyResetDoubleTap);


// Called before system goes to sleep
Err		KeySleep(Boolean untilReset, Boolean emergency)
				SYS_TRAP(sysTrapKeySleep);


// Called when the system wakes up
Err		KeyWake(void)
				SYS_TRAP(sysTrapKeyWake);



#ifdef __cplusplus
}
#endif

	
#endif	//__KEYPRV_H
#endif 	// NON_PORTABLE