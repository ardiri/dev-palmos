/*********************************************************************** 
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ************************************************************************
 *
 * PROJECT:  Pilot INet Library
 * FILE:     INetMgrMail.h
 * AUTHOR:	 Ron Marianetti 6/2/97
 *
 * DESCRIPTION:
 *	  This header file contains the Mail specific equates for the
 *		Internet Library. It gets included by INetMgr.h
 *
 **********************************************************************/
#ifndef 	__INETMGR_MAIL_H__
#define	__INETMGR_MAIL_H__




/********************************************************************
 * Mail Attributes which can be set/get using the
 *  INetLibMailAttrSet/Get calls.
 *
 * Generally, attributes are only set BEFORE calling 
 *		InetLibSockMailReqCreate
 * and attributes are only gotten AFTER the mail response header
 *		has been received. 
 ********************************************************************/
typedef enum {

	// local error trying to communicate with server, if any
	inetMailAttrCommErr,							// DWord, read-only
	
	// New Mail Request attributes, these should be set immediately
	//  after calling INetLibMailReqCreate.  
	inetMailAttrReqEncrypted					// Byte (Boolean)	
	
	// DOLATER... we will probably need additional encryption 
	//  parameters here, or, it might make more sense to put
	//  them as INet client settings in the INetSettingEnum
	//  settings list. 
	
	} inetMailAttrEnum;




/********************************************************************
 * Mail commands and parameter blocks  for the INetLibSockMailReqCreate
 *		and INetLibSockMailReqAdd routines.
 *
 * These parameter blocks must be filled in by the caller before they
 *		call INetLibSockMailReqCreate to start the request formation
 *		and for every INetLibSockMailReqAdd. 
 ********************************************************************/
typedef struct {
	Word	hi;										// hi 2 bytes
	DWord	lo;										// lo 4 bytes of unique ID
	} INetMailUIDType;
 
typedef enum {
	inetMailCmdNew=0,							// specified through getNewMail flag
														//  in MailReqCreate().
	inetMailCmdSend=1,
	inetMailCmdGetMore=2,
	inetMailCmdServer=3
	} INetMailCmdEnum;
	
		
// The INetMailCmdNewPtr is used for the ReqCreate call

#define		inetMailMaxUsername 32 
#define		inetMailMaxPassword 32
typedef struct {
	INetMailUIDType	id;
	DWord					previewSize;
	CharPtr				headerFieldsP;
	
	DWord					availMemory;			// available memory
	DWord					truncationSize;		// truncation size
	DWord					networkID;				// network ID
	Char 					username[inetMailMaxUsername];	// user name, if any
	Char 					password[inetMailMaxPassword];	// password, if any
	} INetMailNewType, *INetMailNewPtr;


// The INetMailSendPtr is used for the ReqAdd call
typedef struct {
	Word					priority;
	Byte					confirmRead;
	Byte					confirmDelivery;
	Word					attachmentCount;
	void*					attachmentsP;
	DWord					msgSize;
	void*					msgP;
	} INetMailSendType, *INetMailSendPtr;


// The INetMailGetMorePtr is used for the ReqAdd call
typedef struct {
	INetMailUIDType	id;
	DWord					bodyEndOffset;
	CharPtr				headerFieldsP;
	} INetMailGetMoreType, *INetMailGetMorePtr;


// The INetMailServerPtr is used for the ReqAdd call
typedef struct {
	DWord					serverCmd;
	DWord					serverParamsLen;
	BytePtr				serverParamsP;
	} INetMailServerType, *INetMailServerPtr;



/********************************************************************
 * The INetLibSockRead call returns the following data:
 * 
 *  INetMailHeaderType 	headerInfo
 *  if (headerInfo.proxyErr == 0 && headerInfo.serverErr == 0) 
 *		 do {
 *		 	INetMailRspType	mailRsp
 *		 	if (	mailRsp.dataSize)
 *			  	Byte[mailRsp.dataSize]		data
 *  		} while (!mailRsp.kind != inetMailRspEnd)  
 *
 * Thus, the application must issue a read for a INetMailHeaderType
 *		struct, check for a server or proxy error, then issue
 *		a read for a INetMailRspType struct, check it's dataSize
 *		and read the following data if any, etc. etc. 
 *  
 ********************************************************************/
typedef enum {
	inetMailContentJerry = 0
	} INetMailContentTypeEnum;
	
// This structure is the first thing returned from a read call to a
//  Mail socket. If serverErr is 0 and proxyErr is 0, the caller
//  should next issue a read for a INetMailRspType. 
// If serverErr is not 0, then there will be 'rspSize' bytes of
//  data that can be read out of the socket that contains the
//  server error text. 
typedef struct {
	DWord		proxyErr;			// proxy error code, if any
	DWord		serverErr;			// server error code, if any
	DWord		rspSize;				// total size of response in bytes. If
										//   serverErr is not 0, this is the size of
										//   the following error text in the socket. 
	
	Word		contentType;		// inetMailContentXXX, format of all following
										//  new mail responses
	
	Word		newMsgs;				// how many new msgs are in the response
	Word		updMsgs;				// how many updated msgs are in the response
	
	Byte		moreMailAvail;		// true if more mail is on the server
	
	} INetMailHeaderType;
	
	
// These are the possible values for the kind field of a INetMailRspType.
typedef enum {
	inetMailRspEnd	=0,	   	// always the last one in the response
	inetMailRspNewMsg,
	inetMailRspMsgAttachment,
	inetMailRspUpdMsg,
	inetMailRspAck
	} INetMailRspEnum;
	
	
// The INetMailRspType is a union of possible response kinds. It is the next
//  thing returned after a  INetMailHeaderType and is followed by
//  'dataSize' bytes of data and then another INetMailHeaderType. 
typedef struct {
	Word	kind;						// inetMailRspXXX
	DWord	dataSize;				// size of following data, if any
	
	union {
		struct {
			DWord		generic[8];		// reserve 32 bytes 
			} generic;
			
		struct {
			INetMailUIDType	id;	// mail ID
			Word		addrType;		// sent to, cc, or bcc
			DWord		bodyEndOffset;	// where the mssage left off, 0 if msg complete
			Word		priority;		// priority of message
			DWord		serverMsgSize;	// server message size
			Word		serverNoteID;	// server error message, if any
			Word		attachmentCount;	// number of attachments that follow
			DWord		timeStamp;			//time stamp of the message
			} newMsg;
			
		struct {
			DWord		type;				// attachment type
			} attachment;
			
		struct {
			INetMailUIDType	id;	// mail ID
			DWord		bodyEndOffset;	// where the mssage left off, 0 if msg complete
			Word		serverNoteID;	// server error message, if any
			Word		attachmentCount;	// number of attachments that follow
			} updMsg;
			
		struct {
			Word		cmd;				// inetMailCmdXXX this is a response to
			DWord		serverErr;		// server error code
			INetMailUIDType	id; 	// mail mesage ID this concerns
			DWord		dataType;		// type of data that follows
			} ack;
		} params;			
	
	} INetMailRspType;
	




/********************************************************************
 * INet Library Mail specific functions. 
 * The trap numbers for these calls are defined in INetMgr.h
 *		which includes this header file. 
 ********************************************************************/

Err				INetLibSockMailReqCreate(Word libRefnum, Handle sockH,
						INetMailNewPtr paramsP, Word paramsLen, SDWord timeout)
						SYS_TRAP(inetLibTrapSockMailReqCreate);
						
Err				INetLibSockMailAttrSet(Word libRefnum, Handle sockH, 
							Word /*inetMailAttrEnum*/ attr, Word attrIndex, 
							BytePtr bufP,  Word bufLen, Word flags)
						SYS_TRAP(inetLibTrapSockMailAttrSet);
						
Err				INetLibSockMailReqAdd(Word libRefnum, Handle sockH,
							Word /*inetMailCmdEnum*/ mailCmd,
							void*  paramsP,  Word paramsLen)
						SYS_TRAP(inetLibTrapSockMailReqAdd);

Err				INetLibSockMailReqSend(Word libRefnum, Handle sockH)
						SYS_TRAP(inetLibTrapSockMailReqSend);

Err				INetLibSockMailAttrGet(Word libRefnum, Handle sockH, 
							Word /*inetMailAttrEnum*/ attr, Word attrIndex,
							VoidPtr bufP, DWordPtr bufLenP)
						SYS_TRAP(inetLibTrapSockMailAttrGet);

Err				InetLibTrapSockMailQueryProgress(Word libRefnum, Handle sockH,
						DWordPtr receivedBytes, DWordPtr usedBits, DWordPtr expandedBytes)
						SYS_TRAP(inetLibTrapSockMailQueryProgress);
						


#endif 	//__INETMGR_MAIL_H__
