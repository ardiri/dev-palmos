/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		StringMgr.h
 *
 * Description:
 *		String manipulation functions
 *
 * History:
 *   	11/09/94  RM - Created by Ron Marianetti
 *
 *******************************************************************/



#ifndef __STRINGMGR_H__
#define __STRINGMGR_H__


// Include elementary types
#include <Common.h>					// Basic types
#include <SysTraps.h>				// Trap Numbers.


#ifdef __cplusplus
extern "C" {
#endif

// String Manipulation routines
CharPtr	StrCopy(CharPtr dst, const Char* src)
							SYS_TRAP(sysTrapStrCopy);

CharPtr	StrNCopy(CharPtr dst, const Char* src, Word n)
							SYS_TRAP(sysTrapStrNCopy);

CharPtr	StrCat(CharPtr dst, const Char* src)
							SYS_TRAP(sysTrapStrCat);
							
CharPtr	StrNCat(CharPtr dst, const Char* src, Word n)
							SYS_TRAP(sysTrapStrNCat);
							
UInt		StrLen(const Char* src)
							SYS_TRAP(sysTrapStrLen);
							
Int		StrCompare(const Char* s1, const Char* s2)
							SYS_TRAP(sysTrapStrCompare);

Int		StrNCompare(const Char* s1, const Char* s2, DWord n)
							SYS_TRAP(sysTrapStrNCompare);

Int 		StrCaselessCompare(const Char* s1, const Char* s2)
							SYS_TRAP(sysTrapStrCaselessCompare);

Int		StrNCaselessCompare(const Char* s1, const Char* s2, DWord n)
							SYS_TRAP(sysTrapStrNCaselessCompare);

CharPtr	StrToLower(CharPtr dst, const Char* src)
							SYS_TRAP(sysTrapStrToLower);

CharPtr 	StrIToA(CharPtr s, Long i)
							SYS_TRAP(sysTrapStrIToA);

CharPtr 	StrIToH(CharPtr s, ULong i)
							SYS_TRAP(sysTrapStrIToH);

CharPtr StrLocalizeNumber(CharPtr s, Char thousandSeparator, Char decimalSeparator)
							SYS_TRAP(sysTrapStrLocalizeNumber);

CharPtr StrDelocalizeNumber(CharPtr s, Char thousandSeparator, Char decimalSeparator)
							SYS_TRAP(sysTrapStrDelocalizeNumber);

CharPtr	StrChr (const Char* str, Int chr)
							SYS_TRAP(sysTrapStrChr);

CharPtr	StrStr (const Char* str, const Char* token)
							SYS_TRAP(sysTrapStrStr);

Long		StrAToI (const Char* str)
							SYS_TRAP(sysTrapStrAToI);
							
SWord 	StrPrintF(CharPtr s, const Char* formatStr, ...)
							SYS_TRAP(sysTrapStrPrintF);
							
SWord 	StrVPrintF(CharPtr s, const Char* formatStr, const VoidPtr arg)
							SYS_TRAP(sysTrapStrVPrintF);

#ifdef __cplusplus 
}
#endif




#endif //__STRINGMGR_H
