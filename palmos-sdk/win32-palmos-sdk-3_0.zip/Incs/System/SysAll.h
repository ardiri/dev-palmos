/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SysAll.h
 *
 * Description:
 *		Includes all system header files in order to help compiler
 *		do pre-compiled headers
 *
 * History:
 *   	11/17/94  RM - Created by Ron Marianetti
 *		2/24/97   roger - changed to handle c++ versions.
 *		4/16/97   SCL - Added <FeatureMgr.h>
 *
 *******************************************************************/

#ifndef __SYSALL_H__
#define __SYSALL_H__


//*********************************************************************
// If not included from Pilot.h, as is the case when compiling UI modules,
//  use the SysAll pre-compiled header file. 
//*********************************************************************
#ifndef __PILOT_H__
	#ifndef PILOT_PRECOMPILED_HEADERS_OFF
	
		// Use Metrowerk's precompiled headers option
		#if defined(__MWERKS__)
			#if	!__option(precompile)
				#if	__PALMOS_TRAPS__
					#ifdef __cplusplus
						#include "SysAll.h++.mch"
					#else
						#include "SysAll.h.mch"
					#endif
				#else
					#ifdef CMD_LINE_BUILD
						#ifdef __cplusplus
							#include "SysAll.h++.mpw.mch"
						#else
							#include "SysAll.h.mpw.mch"
						#endif
					#else
						#ifdef __cplusplus
							#include "SysAll.h++.sim.mch"
						#else
							#include "SysAll.h.sim.mch"
						#endif
					#endif
				#endif
				#define	__INCLUDED_SYSALL_H_OBJ__
			#endif
		#endif
		
	#endif
#endif


// Fastest compilation speed is obtained by not including these
//  headers when the pre-compiled header is used.
#ifndef __INCLUDED_SYSALL_H_OBJ__
#include <Common.h>
#include <SysTraps.h>
#include <SystemMgr.h>
#include <DebugMgr.h>
#include <ErrorMgr.h>
#include <StringMgr.h>
#include <SysUtils.h>
#include <MemoryMgr.h>
#include <DataMgr.h>
#include <FeatureMgr.h>

#include <Preferences.h>
#include <Localize.h>
#include <TimeMgr.h>
#include <AlarmMgr.h>
#include <SoundMgr.h>
#include <Keyboard.h>
#include <GraffitiReference.h>
#include <AppLaunchCmd.h>
#endif


#endif // __SYSALL_H__