/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SerialLib68328.h
 *
 * Description:
 *		Include file for 68328 Serial Library
 *
 * History:
 *   	2/7/95 Created by Ron Marianetti
 *		vmk	8/21/95	Added defQData field to serial globals
 *
 *******************************************************************/

#ifndef __SERIAL_LIB_68328_H
#define __SERIAL_LIB_68328_H


// Pilot common definitions
#include <SerialMgr.h>

// scanning mode states
#define scmOff								0	// scanning disabled
#define scmIdle							1	// idle while port is in use
#define scmActive							2	// active 
#define scmOpening						3  // scanning is being activated

/********************************************************************
 * Serial Globals 
 ********************************************************************/
typedef struct SerGlobalsType {
	UInt					openCount;			// # of times we've been opened
	Int					port;					// DOLATER... NOT NEEDED ???
	SerSettingsType	settings;
	Word					lineErrors;			// line errors bitfield
	
	#ifndef BUILDING_FOR_DEBUGGER
	// Receive Queue. When the queue is empty, qStart == qEnd. When the queue
	//  is full, qStart = qEnd-1 (taking wrap-around into account if necessary).
	Word					qStart;				// start offset of queue
	Word					qEnd;					// end offset of queue
	Word					qSize;				// size of queue
	Ptr					qData;				// pointer to queue data
	Ptr					defQData;			// pointer to default queue data
	
	// Receive Queue semaphore info
	ProcPtr				wakeupHandler;		// Wakeup handler, if installed
	DWord					wakeupRefcon;		// refcon for wakeup handler
	Word					smSignalSize;		// How much the semaphore is waiting for
	DWord					smID;					// semaphore ID
	
	DWord					lastRcvTicks;		// tick count of last received char

	// For debugging
	Word					numReceived;		// # of chars received since serial manager opened
	Word					lastErrorStatus;	// receiver status of last line error
	Word					numRcvErrors;		// # of receive line errors since serial manager opened
	#endif

	// IrDA stuff
	Boolean				irdaMode;			// true if UART is set to IrDA mode
	Byte					scanningMode;     // current state of Ir scanning mode
	Boolean				scanIrdaMode;		// true if scanning should be done in irda mode
	SerWakeupHandler	scanWakeHandler;	// scannning Wakeup handler,
	DWord					scanWakeParam;	   // parameter to pass to wake handler

	} SerGlobalsType;
typedef SerGlobalsType*	SerGlobalsPtr;

#define	serDefaultRcvBufferSize	0x200

#endif	//__SERIAL_LIB_68328_H
