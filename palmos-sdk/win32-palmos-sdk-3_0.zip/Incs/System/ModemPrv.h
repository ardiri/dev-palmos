/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		ModemPrv.h
 *
 * Description:
 *		Private Include file for Modem Manager
 *
 * History:
 *   	9/25/95  VMK - Created by Vitaly Kruglikov
 *
 *******************************************************************/


#ifndef __MODEM_PRV_H__
#define __MODEM_PRV_H__

// Include elementary types
#include <Common.h>



/************************************************************
 * Modem Manager constants
 *************************************************************/
#define	mdmDefaultResponseWait		300000L		// in microseconds

/************************************************************
 * Modem Manager data structures
 *************************************************************/
typedef enum  {
	mdmCmdCSI,
	mdmCmdEOC,
	mdmCmdQuiet,
	mdmCmdDialTone,
	mdmCmdDialPulse,
	mdmCmdEchoOff,
	mdmCmdVerbose,
	mdmCmdDTWait,
	mdmCmdDCDWait,
	mdmCmdBasicXCmd,
	mdmCmdAdvXCmd,
	mdmCmdSpkrOnTillConnect,
	mdmCmdSpkrOff,
	mdmCmdVolume,
	mdmCmdHUP,
	mdmCmdFirmDTRDCD,
	mdmCmdEscape,
	mdmCmdReset,
	mdmCmdFactory,
	mdmCmdRetToCmdMode			// return to command mode after dialing
	} MdmCmdEnum;

typedef enum MdmRespIDType {
	mdmRespUnknown = 0,
	mdmRespOK,
	mdmRespConnect,
	mdmRespNoCarrier,
	mdmRespError,
	mdmRespNoDialTone,
	mdmRespBusy,
	mdmRespRing,
	
	mdmRespReserved = -1					// reserve -1 for internal use
	} MdmRespIDType;


// Configuration constants:

// Hardware handshake settings
enum {
	mdmHandshakeStd		= 0,			// standard AT handshaking (on at > 2400 baud)
	mdmHandshakeOff		= 1,			// force handshaking off
	mdmHandshakeOn			= 2			// force handshaking on
	};


//
// Modem Manager preference structure (system pref rsc id = sysResIDModemMgrPref):
//
#define mdmPrefVersionNum		2					// modem preference version

typedef struct MdmPrefType {
	Word			version;
	ULong			baud;										// baud rate
	Byte			volume;									// speaker volume level
	Boolean		pulse;									// set to true for pulse dial mode
	Byte			hShk;										// handshake option
	Boolean		autoBaud;								// set to true for auto-baud
	Char			resetString[(mdmCmdSize*2)+1];	// string to be embedded in the reset command (vmk added 12/17/96)
	Char			initString[mdmCmdBufSize];			// modem init string
	} MdmPrefType;
typedef MdmPrefType*		MdmPrefPtr;

#define mdmDefaultDialMode		false


/************************************************************
 * Modem Manager default settings. Used by PrvGetModemPrefs() 
 *  in ModemMgr.c when invalid or no prefs found.
 *
 * WARNING: In order to avoid confusion for the user, these
 *  defaults should match what the Modem Panel uses as it's defaults.
 *  The modem panels defaults are set by editing it's resources so
 *  they must be manually updated when these equates are changed.
 *************************************************************/
#define	mdmDefaultBaud				19200
#define	mdmDefaultVolume			mdmVolumeLow
#define	mdmDefaultPulse			false
#define 	mdmDefaultHShk				mdmHandshakeStd
#define 	mdmDefaultAutoBaud		false
#define	mdmDefaultResetString	""
#define 	mdmDefaultInitString		"&F&B1X4"


/************************************************************
 * Modem Manager Macros
 *************************************************************/

#endif  // __MODEM_PRV_H__

