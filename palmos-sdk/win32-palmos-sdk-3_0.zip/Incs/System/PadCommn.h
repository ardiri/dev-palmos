/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		PadCommn.h
 *
 * Description:
 *		Common Packet Assembly / Disassembly Protocol(PADP) definitions.
 *
 * History:
 *   	8/8/95	vmk	Created by Vitaly Marty Kruglikov
 *
 *******************************************************************/


#ifndef __PAD_COMMON_H__
#define __PAD_COMMON_H__

#include <Common.h>


/********************************************************************
 * PADP Packet Format
 ********************************************************************/

// The PADP packets are used for transmitting data for the Pilot PADP protocol layer.
// The structure of the PADP packet is built into the data part of the SLP packet and is,
// therefore, constrained by the SLP packet data size limitations.


// Packet type values used in the PADP packet header's "type" field:
//
typedef enum PadType {
	// 1.0 types
	padData		= 0x01,					// PADP data packet
	padAck		= 0x02,					// PADP ACK packet
	padUnused	= 0x03,					// used to be PADP NACK packet
	padTickle	= 0x04,					// PADP TICKLE packet(keep-alive)
	// 1.1 stuff added here:
	padAbort		= 0x08					// PAD abort connection packet
	} PadType;


// PADP "short" packet header (Pilot v1.0-compatible):
//
typedef struct PadShortHeaderType {
	Byte	type;							// PADP packet type
	Byte	flags;						// flags to signal special conditions
	Word	wSizeOrOffset;				// (high, low) --
											// in the 1st padData packet of the block, this field holds the
											// total block data size; in the subsequent padData packets,
											// this field holds the offset of data being sent; in padAck
											// packets, this field is set to the value of the padData packet
											// being ack'ed.
	} PadShortHeaderType;			// TOTAL: 4 bytes

typedef PadShortHeaderType*		PadShortHeaderPtr;


#if 0		// FUTURE
			// PADP "long" packet header (Future extension):
			//
			typedef struct PadLongHeaderType {
				Byte	type;							// PADP packet type
				Byte	flags;						// flags to signal special conditions
				DWord	dwSizeOrOffset;			// (high, low) --
														// in the 1st padData packet of the block, this field holds the
														// total block data size; in the subsequent padData packets,
														// this field holds the offset of data being sent; in padAck
														// packets, this field is set to the value of the padData packet
														// being ack'ed.
				} PadLongHeaderType;			// TOTAL: 6 bytes

			typedef PadLongHeaderType*		PadLongHeaderPtr;


			// Union of all header types
			typedef union PadGenericHeaderType {
				struct {
					Byte	type;
					Byte	flags;
					}						typeAndFlags;
				PadShortHeaderType	shortHdr;
				PadLongHeaderType		longHdr;
				} PadGenericHeaderType;
				
			// This is the maximum amount of data which may be sent in one PADP block using
			// long packet headers (Future extension)
			//
			#define padMaxLongBlockSize		0xFFFFFFFFL

			#define padHdrFlagLongHeader	0x10	// signals long header (Future extension)

#endif	// FUTURE


// This is the maximum amount of data which may be sent in one PADP block using
// short packet headers
//
#define padMaxShortBlockSize		0x0000FFFFL				// 64K - 1




// Flag values used in the PADP packet header's "flags" field.  padHdrFlagFirst and
// padHdrFlagLast must both be set when the entire data block is being transmitted
// in a single PADP packet.
//
#define padHdrFlagFirst			0x80	// identifies the 1st padData packet
												// of the block
														
#define padHdrFlagLast			0x40	// identifies the last padData packet
												// of the block
														
#define padHdrFlagErrMemory	0x20	// signals remote memory error in
												// padAck packets
														
														


/********************************************************************
 * PADP Protocol Parameters
 ********************************************************************/


// This is the maximum amount of data(in bytes) which may be sent in a single
// PADP packet(not including the PADP packet header)
//
#define padMaxPktDataSize			(1*1024)


// This is the maximum number of retries for resending a given data packet
//
#define	padMaxRetries				10


// This is the maximum number of seconds to wait for an acknowledgement after sending
// a data packet
//
#define padAckWaitSec				2


// This is the maximum number of seconds to wait for the next data packet to begin arriving
//
#define padInterPktTimeOutSec		30		// large value for debugging


// default max sec. to wait for command/reply
//
#define padCmdWaitSec				30
#define padReplyWaitSec				30


// Pilot-to-host tickle(keep alive) interval in seconds
//
#define padPilotToHostTickleIntervalSec	3

/********************************************************************
 * Macros
 ********************************************************************/



#endif	// __PAD_COMMON_H__
