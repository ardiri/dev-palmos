/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 ****************************************************************************
 *
 * PROJECT:  Pilot TCP/IP Library
 * FILE:     netdb.h
 * AUTHOR:	 Ron Marianetti 2/14/96
 *
 * DESCRIPTION:
 *	  This module contains the interface definitions that are 
 *	typically found in the unix header <netdb.h> for use by 
 * Pilot applications that wish to use the sockets API calls.
 *
 **********************************************************************/

/*	@(#)netdb.h 1.11 88/08/19 SMI from UCB 5.9 4/5/88	*/
/*
 * Copyright (c) 1980,1983,1988 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that this notice is preserved and that due credit is given
 * to the University of California at Berkeley. The name of the University
 * may not be used to endorse or promote products derived from this
 * software without specific prior written permission. This software
 * is provided ``as is'' without express or implied warranty.
 */



#ifndef 	__UNIXNETDB_H__
#define	__UNIXNETDB_H__


/*
 * Structures returned by network data base library.
 * All addresses are supplied in host order, and
 * returned in network order (suitable for use in system calls).
 */

struct	hostent {
	Char	*h_name;						/* official name of host */
	Char	**h_aliases;				/* alias list */
	Word	h_addrtype;					/* host address type */
	Word	h_length;					/* length of address */
	Char	**h_addr_list;				/* list of addresses from name server */
#define	h_addr	h_addr_list[0]	/* address, for backward compatiblity */
};

/*
 * Assumption here is that a network number
 * fits in 32 bits -- probably a poor one.
 */
struct	netent {
	Char		*n_name;					/* official name of net */
	Char		**n_aliases;			/* alias list */
	Word		n_addrtype;				/* net address type */
	DWord		n_net;					/* network # */
};

struct	servent {
	Char	*s_name;						/* official service name */
	Char	**s_aliases;				/* alias list */
	Word	s_port;						/* port # */
	Char	*s_proto;					/* protocol to use */
};

struct	protoent {
	Char	*p_name;						/* official protocol name */
	Char	**p_aliases;				/* alias list */
	Word	p_proto;						/* protocol # */
};

struct rpcent {
	Char	*r_name;						/* name of server for this rpc program */
	Char	**r_aliases;				/* alias list */
	SWord	r_number;					/* rpc program number */
};


// Supported calls
#define	gethostbyname(nameP) 	\
				((struct hostent*)NetLibGetHostByName(AppNetRefnum, nameP,&AppHostInfo,AppNetTimeout,&h_errno))
			
#define	gethostbyaddr(addr,len,type) 	\
				((struct hostent*)NetLibGetHostByAddr(AppNetRefnum, (BytePtr)addr,len,type,&AppHostInfo,AppNetTimeout,&h_errno))

#define	getservbyname(serv,proto)		\
				((struct servent*)NetLibGetServByName(AppNetRefnum, serv,proto,&AppServInfo,AppNetTimeout,&h_errno))
				

// Unsupported calls
// struct hostent	 *gethostent();
// struct netent	*getnetbyname(), *getnetbyaddr(), *getnetent();
// struct servent	*getservbyport(), *getservent();
// struct protoent	*getprotobyname(), *getprotobynumber(), *getprotoent();
// struct rpcent	*getrpcbyname(), *getrpcbynumber(), *getrpcent();

/*
 * Error return codes from gethostbyname() and gethostbyaddr()
 * (when using the resolver)
 */

extern  Err 		h_errno;				

#define	HOST_NOT_FOUND	1 				/* Authoritive Answer Host not found */
#define	TRY_AGAIN		2 				/* Non-Authoritive Host not found, or SERVERFAIL */
#define	NO_RECOVERY		3 				/* Non recoverable errors, FORMERR, REFUSED, NOTIMP */
#define	NO_DATA			4 				/* Valid name, no data record of requested type */
#define	NO_ADDRESS		NO_DATA		/* no address, look for MX record */


#endif	//	__UNIXNETDB_H__



