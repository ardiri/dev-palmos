/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SerialHWMgr.h
 *
 * Description:
 *		Include file for Serial manager
 *
 * History:
 *   	2/7/95 		SerMgr.h created by Ron Marianetti
 *
 *		1/14/98		SerHWMgr.h created by Ben Manuto
 *
 *******************************************************************/

#ifndef __SERIALHW_MGR_H
#define __SERIALHW_MGR_H


// BUILDING_SERHWMGR_LIB is defined by the SerialHWMgr.c file which does not want to see the 
//  SYS_TRAP macros for building the actual library.
#ifdef BUILDING_SERHWMGR_LIB
	#define SERHWMGR_LIB_TRAP(trapNum)
#else
	#define SERHWMGR_LIB_TRAP(trapNum) SYS_TRAP(trapNum)
#endif


#ifndef __SERIAL_MGR_H				// Only include the data types if SerialMgr.h WAS NOT included

// Pilot common definitions
#include <Common.h>
#include <SystemMgr.h>


/********************************************************************
 * Serial Manager Errors
 * the constant serErrorClass is defined in SystemMgr.h
 ********************************************************************/
#pragma mark -Error Codes-

#define	serErrBadParam				(serErrorClass | 1)
#define	serErrBadPort				(serErrorClass | 2)
#define	serErrNoMem					(serErrorClass | 3)
#define	serErrBadConnID			(serErrorClass | 4)
#define	serErrTimeOut				(serErrorClass | 5)
#define	serErrLineErr				(serErrorClass | 6)
#define	serErrAlreadyOpen			(serErrorClass | 7)
#define  serErrStillOpen			(serErrorClass | 8)
#define	serErrNotOpen				(serErrorClass | 9)
#define	serErrNotSupported		(serErrorClass | 10)		// functionality not supported


/********************************************************************
 * Serial Port Definitions
 ********************************************************************/
#pragma mark -Port Definitions-

#define serPortDefault      0x0000  // Use prefDefSerialPlugIn
#define serPortLocalHotSync 0x8000  // Use physical HotSync port
#define serPortMaskLocal    0x7FFF  // Mask off HotSync "hint" (for SerialMgr)


/********************************************************************
 * Serial Settings Descriptor
 ********************************************************************/
#pragma mark -Configuration Settings-

typedef struct SerSettingsType {
	UInt32			baudRate;			// baud rate
	UInt32			flags;				// miscellaneous settings
	Long			ctsTimeout;			// max # of ticks to wait for CTS to become asserted
											// before transmitting; used only when
											// configured with serSettingsFlagCTSAutoM.
	} SerSettingsType;
typedef SerSettingsType*	SerSettingsPtr;
	
#define		serSettingsFlagStopBitsM			0x00000001		// mask for stop bits field
#define		serSettingsFlagStopBits1			0x00000000		//  1 stop bits	
#define		serSettingsFlagStopBits2			0x00000001		//  2 stop bits	
#define		serSettingsFlagParityOnM			0x00000002		// mask for parity on
#define		serSettingsFlagParityEvenM			0x00000004		// mask for parity even
#define		serSettingsFlagXonXoffM				0x00000008		// (NOT IMPLEMENTED) mask for Xon/Xoff flow control
#define		serSettingsFlagRTSAutoM				0x00000010		// mask for RTS rcv flow control
#define		serSettingsFlagCTSAutoM				0x00000020		// mask for CTS xmit flow control
#define		serSettingsFlagBitsPerCharM		0x000000C0		// mask for bits/char
#define		serSettingsFlagBitsPerChar5		0x00000000		//  5 bits/char	
#define		serSettingsFlagBitsPerChar6		0x00000040		//  6 bits/char	
#define		serSettingsFlagBitsPerChar7		0x00000080		//  7 bits/char	
#define		serSettingsFlagBitsPerChar8		0x000000C0		//  8 bits/char	


// Default settings
#define		serDefaultSettings		(serSettingsFlagBitsPerChar8	|		\
												serSettingsFlagStopBits1		|		\
												serSettingsFlagRTSAutoM)
												
#define		serDefaultCTSTimeout		(5*sysTicksPerSecond);

//
// mask values for the lineErrors  from SerGetStatus
//
#pragma mark -Line Errors-

#define	serLineErrorParity		0x0001			// parity error
#define	serLineErrorHWOverrun	0x0002			// HW overrun
#define	serLineErrorFraming		0x0004			// framing error
#define 	serLineErrorBreak			0x0008			// break signal asserted
#define 	serLineErrorHShake		0x0010			// line hand-shake error
#define	serLineErrorSWOverrun	0x0020			// HW overrun




/********************************************************************
 * Type of a wakeup handler procedure which can be installed through the
 *   SerSetWakeupHandler() call.
 ********************************************************************/
typedef void (*SerWakeupHandler)  (UInt32 refCon);

/********************************************************************
 * Type of an emulator-mode only blocking hook routine installed via
 * SerControl function serCtlEmuSetBlockingHook.  This is supported only
 * under emulation mode.  The argument to the function is the value
 * specified in the SerCallbackEntryType structure.  The intention of the
 * return value is to return false if serial manager should abort the
 * current blocking action, such as when an app quit event has been received;
 * otherwise, it should return true.  However, in the current implementation,
 * this return value is ignored.  The callback can additionally process
 * events to enable user interaction with the UI, such as interacting with the
 * debugger. 
 ********************************************************************/
typedef Boolean (*SerBlockingHookHandler)  (UInt32 userRef);




/********************************************************************
 * Serial Library Control Enumerations (Pilot 2.0)
 ********************************************************************/
#pragma mark -Control Enumerations-

/********************************************************************
 * Structure for specifying callback routines.
 ********************************************************************/
typedef struct SerCallbackEntryType {
	Ptr		funcP;					// function pointer
	UInt32	userRef;					// ref value to pass to callback
	} SerCallbackEntryType;
typedef SerCallbackEntryType*	SerCallbackEntryPtr;

// v2.0 extension
// DOLATER... add DTR control and status
typedef enum SerCtlEnum {
	serCtlFirstReserved = 0,		// RESERVE 0
	
	serCtlStartBreak,					// turn RS232 break signal on:
											// users are responsible for ensuring that the break is set
											// long enough to genearate a valie BREAK!
											// valueP = 0, valueLenP = 0
											
	serCtlStopBreak,					// turn RS232 break signal off:
											// valueP = 0, valueLenP = 0

	serCtlBreakStatus,				// Get RS232 break signal status(on or off):
											// valueP = ptr to UInt16 for returning status(0 = off, !0 = on)
											// *valueLenP = sizeof(UInt16)
											
	serCtlStartLocalLoopback,		// Start local loopback test
											// valueP = 0, valueLenP = 0
											
	serCtlStopLocalLoopback,		// Stop local loopback test
											// valueP = 0, valueLenP = 0

	serCtlMaxBaud,						// Get maximum supported baud rate:
											// valueP = ptr to UInt32 for returned baud
											// *valueLenP = sizeof(UInt32)
	
	serCtlHandshakeThreshold,		// retrieve HW handshake threshold; this is the maximum baud rate
											// which does not require hardware handshaking
											// valueP = ptr to UInt32 for returned baud
											// *valueLenP = sizeof(UInt32)
	
	serCtlEmuSetBlockingHook,		// Set a blocking hook routine FOR EMULATION
											// MODE ONLY - NOT SUPPORTED ON THE PILOT
											//PASS:
											// valueP = ptr to SerCallbackEntryType
											// *valueLenP = sizeof(SerCallbackEntryType)
											//RETURNS:
											// the old settings in the first argument
											

	serCtlIrDAEnable,					// Enable  IrDA connection on this serial port
											// valueP = 0, valueLenP = 0

	serCtlIrDADisable,				// Disable  IrDA connection on this serial port
											// valueP = 0, valueLenP = 0

	serCtlIrScanningOn,				// Start Ir Scanning mode	
	
	serCtlIrScanningOff,				// Stop Ir Scanning mode
	
	serCtlRxEnable,					// enable receiver  ( for IrDA )
	
	serCtlRxDisable,					// disable receiver ( for IrDA )

	serCtlLAST							// ADD NEW ENTRIES BEFORE THIS ONE
	} SerCtlEnum;

#endif			// __SERIAL_MGR_H

/********************************************************************
 * Serial Hardware Library Routines
 ********************************************************************/
#pragma mark -API Functions-

#ifdef __cplusplus
extern "C" {
#endif

extern Err SerHWOpen(UInt16 refNum, UInt32 port, VoidPtr *thePort, UInt32 baud)
	SERHWMGR_LIB_TRAP(sysLibTrapOpen);
	
extern Err SerHWClose(UInt16 refNum, VoidPtr thePort)
	SERHWMGR_LIB_TRAP(sysLibTrapClose);
	
extern Err SerHWSleep(UInt16 refNum)
	SERHWMGR_LIB_TRAP(sysLibTrapSleep);
	
extern Err SerHWWake(UInt16 refNum)
	SERHWMGR_LIB_TRAP(sysLibTrapWake);

extern Err SerHWOpenBackground(UInt16 refNum, UInt32 port, VoidPtr *thePort, UInt32 baud)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom);

extern Err SerHWRequestOpen(UInt16 refNum, UInt32 port, VoidPtr *thePort, UInt32 baud)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+1);
	
extern Err SerHWGetSettings (UInt16 refNum, VoidPtr thePort, SerSettingsPtr settingsP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+2);
	
extern Err SerHWSetSettings (UInt16 refNum, VoidPtr thePort, SerSettingsPtr settingsP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+3);

extern UInt16 SerHWGetStatus(UInt16 refNum, VoidPtr thePort, BooleanPtr ctsOnP, BooleanPtr dsrOnP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+4);

extern Err SerHWClearErr (UInt16 refNum, VoidPtr thePort)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+5);

extern Err SerHWSendWait(UInt16 refNum, VoidPtr thePort)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+6);

extern Err SerHWSendCheck(UInt16 refNum, VoidPtr thePort, UInt32* numBytesP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+7);

extern Err SerHWSendFlush(UInt16 refNum, VoidPtr thePort)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+8);

extern Err SerHWReceiveWait(UInt16 refNum, VoidPtr thePort, UInt32 bytes, Long timeout)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+9);

extern Err SerHWReceiveCheck(UInt16 refNum, VoidPtr thePort,  UInt32* numBytesP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+10);

extern void SerHWReceiveFlush(UInt16 refNum, VoidPtr thePort, Long timeout)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+11);

extern Err SerHWSetReceiveBuffer(UInt16 refNum, VoidPtr thePort, VoidPtr bufP, UInt16 bufSize)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+12);

extern Err SerHWReceiveWindowOpen(UInt16 refNum, VoidPtr thePort, BytePtr* bufPP, UInt32* sizeP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+13);

extern Err SerHWReceiveWindowClose(UInt16 refNum, VoidPtr thePort, UInt32 bytesPulled)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+14);

extern Err SerHWSetWakeupHandler(UInt16 refNum, VoidPtr thePort, SerWakeupHandler procP, UInt32 refCon)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+15);

extern Err SerHWPrimeWakeupHandler(UInt16 refNum, VoidPtr thePort, UInt16 minBytes)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+16);

extern Err SerHWControl(UInt16 refNum, VoidPtr thePort, UInt16 op, VoidPtr valueP, UInt16Ptr valueLenP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+17);

extern UInt32 SerHWSend (UInt16 refNum, VoidPtr thePort, VoidPtr bufP, UInt32 count, Err* errP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+18);

extern UInt32 SerHWReceive(UInt16 refNum, VoidPtr thePort, VoidPtr rcvBufP, UInt32 count, Long timeout, Err* errP)
	SERHWMGR_LIB_TRAP(sysLibTrapCustom+19);

#ifdef __cplusplus
}
#endif

#endif		// __SERIALHW_MGR_H
