/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		PenPrv.h
 *
 * Description:
 *		Private Include file for Pen manager
 *
 * History:
 *   	 6/ 5/96 Created by Ron Marianetti
 *		11/24/97 SCL Changes related to PenGetRawPen to fix Rocky penDown problems
 *
 *******************************************************************/

#ifdef	NON_PORTABLE
#ifndef __PEN_PRV_H
#define __PEN_PRV_H


/********************************************************************
 * Pen Manager Constants
 ********************************************************************/
#define	penCalibrateTop			10
#define	penCalibrateLeft			10
#define	penCalibrateBottom		(hwrDisplayHeight-10)
#define	penCalibrateRight			(hwrDisplayWidth-10)

#define	penInitDelay				0x180		// <BugFix 5/1/97> increased from 30 to get
														//  rid of wild taps. 
#define	penBBDelay					105		// Delay for BurrBrown sampling (includes margin) 
#define	penInitMaxDDZ				12			// max change allowed in dx or dy between
														//  2 samples.

// We sample the pen 2 times in a row every 20ms and make sure the 2 points are
// within this many pixels. 
#define	penInitMaxSlop				2	

// Number of retries (samples) we'll take in an attempt to get 2 within maxSlop.
#define	penInitMaxRetries			3

// The max blip we allow on the last point of a stroke as compared to the
//  previous point
#define	penInitMaxEndBlip			5

// Number of samples we keep around for filtering functions.
// Must allow room for at least 2 samples previous to the hot sample
// (i.e. must be >= penHotSample+3
#define	penNumSamples				5

// Index of the sample we return from PenGetRawPen. Must be less than
//  penNumSamples!!
#define	penHotSample				2

// Number of pen-up samples in a row we must see in order to recognize a pen-up.
// Must be <= penHotSample+1 since we must have space in the sample array
// before and including the hot sample to store all these up samples.
#define	penMinUpSamples			3

// Number of pen-down samples in a row we must see in order to recognize a pen-down.
// We ignore pen location samples until we've seen this many "down" samples.
#define penMinDownSamples			1


// This constant is stored in the x field of a point within our sample
//  array to indicate a pen down but with no valid position.
#define	penDownButInvalid			0x7FFF



/********************************************************************
 * Pen Manager Globals
 ********************************************************************/
typedef struct PenGlobalsType {
	// Calibration info
	Boolean			calibrated;
	Boolean			filler;
	UInt				xOffset, yOffset;
	UInt				xScale, yScale;
	
	// Array of pen samples we've taken. The most recent sample is at index #0.
	// We keep this history of samples in order to filter out bad points. 
	// The sample that we return to the caller of PenGetRawPen is stored
	// at index pen
	PointType		sample[penNumSamples];
	
	// Parameters for filter
	UInt				delay;				// delay before reading A/D
	UInt				maxDDZ;				// max 2nd derivative.
	UInt				maxRetries;			// max samples in a row to get 2 within maxSlop
	UInt				maxSlop;				// max delta between 2 samples taken immediately
												//  after each other
	UInt				maxEndBlip;			// max blip we allow at the end of a stroke
	UInt				penDownCount;		// counter for ignoring the first few penDowns
	UInt				penDownCountInit;	// value with which to init penDownCount
	} PenGlobalsType;
	
typedef PenGlobalsType*	PenGlobalsPtr;



#endif	//__PEN_MGR_H
#endif 	// NON_PORTABLE