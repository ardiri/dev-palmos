/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		SerialLib68328.h
 *
 * Description:
 *		Include file for 68328 Serial Library
 *
 * History:
 *   	2/7/95 Created by Ron Marianetti
 *		vmk	8/21/95	Added defQData field to serial globals
 *
 *******************************************************************/

#ifndef __SERIAL_LIB_68681_H
#define __SERIAL_LIB_68681_H


// Touchdown common definitions
#include <SerialMgr.h>

/********************************************************************
 * Debug Info stored in serial globals 
 ********************************************************************/
typedef struct Ser681DebugInfoType {
		Word					lineErrorCount;	// number of line errors since opening

	#ifdef INCLUDE_BASIC_681_DEBUG_INFO
		Word					numReceived;		// number of bytes received since opening
		Word					numSent;				// number of bytes sent
		Byte					lastReceived;		// last byte received
		Byte					lastErrorStatus;	// receiver status of last line error
		
		// Include extensive debug info only if basic info is included
		#ifdef INCLUDE_EXTENSIVE_681_DEBUG_INFO
			Word					hwOverrunCount;	// number of hardware overrun errors since opening
			Word					parityErrorCount;	// number of parity errors since opening
			Word					framingErrorCount;// number of framing errors since opening
		#endif	//#ifdef INCLUDE_EXTENSIVE_681_DEBUG_INFO
	#endif	//#ifdef INCLUDE_BASIC_681_DEBUG_INFO

	} Ser681DebugInfoType;
	
typedef Ser681DebugInfoType*	Ser681DebugInfoPtr;



/********************************************************************
 * Serial Globals 
 ********************************************************************/
typedef struct Ser681GlobalsType {
	DWord					openSignature;		// hack to detect if we have been opened when
													// booting from the 68328-based debugger
	UInt					openCount;			// # of times we've been opened
	Int					port;
	SerSettingsType	settings;
	Word					lineErrors;			// line errors bitfield
	

	VoidPtr				chanP;				// pointer to this channel base in UART
	
#ifndef BUILDING_FOR_DEBUGGER
	// Receive Queue. When the queue is empty, qStart == qEnd. When the queue
	//  is full, qStart = qEnd-1 (taking wrap-around into account if necessary).
	Word					qStart;				// start offset of queue
	Word					qEnd;					// end offset of queue
	Word					qSize;				// size of queue
	Ptr					qData;				// pointer to queue data
	Ptr					defQData;			// pointer to default queue data
	
	// Receive Queue semaphore info
	Word					smSignalSize;		// How much the semaphore is waiting for
	DWord					smID;					// semaphore ID 

	DWord					lastRcvTicks;		// tick count of last received char

	Byte					currentIMR;			// current value of interrupt mask register
	Ptr					oldIRQ3P;			// saved pointer to previously-installed IRQ3 handler

	Boolean				breakIsOn;			// set to true when break signal is started, false when it is stopped
#endif	//#ifndef BUILDING_FOR_DEBUGGER

	// Serial Library debugging information
	Ser681DebugInfoType	debugInfo;
	
	} Ser681GlobalsType;

typedef Ser681GlobalsType*	Ser681GlobalsPtr;

#define	serLibDefaultRcvBufferSize	0x200

#endif	//__SERIAL_LIB_68681_H
