/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		PadUtil.h
 *
 * Description:
 *		Packet Assembly/Disassembly utility definitions
 *
 * History:
 *   	8/11/95	vmk	Created by Vitaly Marty Kruglikov
 *
 *******************************************************************/


#ifndef __PAD_UTIL_H__
#define __PAD_UTIL_H__

#if EMULATION_LEVEL == 1		// EMULATION_WINDOWS
	
	// Pilot common definitions
	#include "Common.h"

#else	// EMULATION_LEVEL != EMULATION_WINDOWS

	// Pilot common definitions
	#include <Common.h>

#endif	// EMULATION_LEVEL == EMULATION_WINDOWS

#if EMULATION_WINDOWS != 1
	LOGIC ERROR
#endif


// The PmSegmentType structure enables the caller to
// specify the block's data in multiple non-contiguous segments.  For example, when
// sending a record, DesktopLink will specify the function header, the argument wrapper,
// the fixed record info, and the record data as two or more segments(one or more segments
// for the fixed structures and one segment for the record data).  In such an instance,
// it is not practical(and sometimes not possible) to allocate a single data buffer to
// contain all that information contiguously.
//
typedef struct PmSegmentType {
	VoidPtr		dataP;				// ptr to segment data
	Word			dataSize;			// segment data size in bytes
	Boolean		wordAlign;			// if true, this segments data will be sent
											// at an even offset from the start of the
											// block, padding the previous segment's
											// data with a null byte, if necessary
	} PmSegmentType;

typedef PmSegmentType*		PmSegmentPtr;


#ifdef __cplusplus
extern "C" {
#endif

ULong PmAddSegmentSizes(Int segCount, PmSegmentType seg[]);

ULong	PmCopyFromSegments(VoidPtr bufP, Int segCount, PmSegmentType seg[],
			ULong blockOffset, ULong maxSize);


#ifdef __cplusplus 
}
#endif


#endif	// __PAD_UTIL_H__
