/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:  
 *		FileStreamPrv.h
 *
 * Description:
 *		Pilot File Stream private equates
 *
 * History:
 *		12/2/97	vmk		- Created by Vitaly Kruglikov 
 *
 *******************************************************************/

#ifndef __FILESTREAMPRV_H__
#define __FILESTREAMPRV_H__



/************************************************************
 * Internal structures
 *************************************************************/

// File descriptor block structure
#define fileDescriptorSignature		('STRM')

#define fileStateOpenComplete		(0x8000)				// set when opening completes
#define fileStateWriteAccess		(0x4000)				// set if file was opened with write access
#define fileStateDestructiveRead	(0x2000)				// set if file is in "destructive read" mode
#define fileStateAppend				(0x1000)				// set if file is in "append" mode
#define fileStateCreated			(0x0800)				// set if the open call caused the file to be created
#define fileStateCompressed		(0x0400)				// set if the file is in a compressed state
#define fileStateIOError			(0x0001)				// set if I/O error occurred (cleared w/ clearerr or seek)
#define fileStateEOF					(0x0002)				// set if read attempted beyond end of file (cleared by clearerr or seek)


// For error-checking -- ***ADD ALL NEW STATES TO THIS DEFINE***
#define fileAllStates			(	fileStateOpenComplete		|	\
											fileStateWriteAccess			|	\
											fileStateDestructiveRead	|	\
											fileStateAppend				|	\
											fileStateCreated				|	\
											fileStateCompressed			|	\
											fileStateIOError				|	\
											fileStateEOF )

typedef struct FileCachedInfoType {
	VoidHand		blockH;					// cached block handle: set to null if none
	ULong			blockIndex;				// block's record index in the database (0-based)
	Boolean		forWrite;				// true if got the block for write, false if for read-only
	Byte			bReserved;
	} FileCachedInfoType;
	

typedef struct FileDescriptorType {
	DWord			sig;					// signature (for debugging): set to fileDescriptorSignature
	DWord			openMode;			// mode flags passed to FileOpen (fileMode...)
	Word			state;				// current file state flags (fileState...)
	DmOpenRef	dbR;					// pointer to open database (NULL if not open)
	Err			lastError;			// error value from last file call
	Long			fileSize;			// cached file size (for perf. optimization)
	Long			numBlocks;			// cached number of data blocks (records) (for perf. optimization)
	Long			curOffset;			// current offset for reading and/or writing
	FileCachedInfoType	cached;	// cached block information
	DWord			dwReserved1;		// reserved -- set to zero
	DWord			dwReserved2;		// reserved -- set to zero
	} FileDescriptorType;

// File data block structure
#define fileBlockDataSize	(1024L * 4)	/* unit of stream storage */

#define fileDataBlockSignature		('DBLK')
#define fileDataBlockCategory			(dmUnfiledCategory)	/* record category used for data blocks */

typedef struct FileBlockHeaderType {
	DWord		sig;						// signature (for debugging and validation): set to fileDataBlockSignature
	SDWord	dataSize;				// size of valid data in the block (can be less than fileBlockDataSize)
	} FileBlockHeaderType;
	
typedef struct FileDataBlockType {
	FileBlockHeaderType	hdr;								// block header
	Byte						data[fileBlockDataSize];	// data storage
	} FileDataBlockType;


/************************************************************
 * File Stream Private procedures
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif


#endif //  #ifndef __FILESTREAMPRV_H__
