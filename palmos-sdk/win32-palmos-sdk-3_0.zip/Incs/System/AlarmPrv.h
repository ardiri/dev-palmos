/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		AlarmPrv.h
 *
 * Description:
 *		Private Include file for Alarm Manager
 *
 * History:
 *   	4/11/95  VMK - Created by Vitaly Kruglikov
 *
 *******************************************************************/


#ifdef	NON_PORTABLE
#ifndef __ALARM_PRV_H__
#define __ALARM_PRV_H__



/************************************************************
 * Alarm Manager Constants
 *
 *************************************************************/
#define almMinTableLength	2		// minimum # of entries in alarm table;
											// MUST NOT BE ZERO.
											
#define almMaxTableLength		20	// maximum # of enries in alarm table


/*******************************************************************
 * Alarm Manager alarm table structures
 *
 *******************************************************************/

// An entry in the alarm table
typedef struct AlmEntryType {
	DWord				ref;				// alarm reference value passed by caller;

	ULong				alarmSeconds;	// alarm date/time in seconds since 1/1/1904;
											// a value of 0 indicates unused entry;
	
	LocalID			dbID;				// creator app database ID;
	Word				cardNo : 1;		// creator app card number;
	
	Word				quiet : 1;		// 1 indicates that the caller wants
											// to be quietly notified when the alarm
											// goes off without all the alarm bells
											// and whistles;

	Word				triggered : 1;	// 1 indicates the alarm has been triggered;
											
	Word				notified : 1;	// 1 indicates we notified the caller that
											// the alarm went off;
	} AlmEntryType;

typedef AlmEntryType*		AlmEntryPtr;


// The alarm table
typedef struct AlmTableType {
	Short				numEntries;		// Number of entries in alarm Table;
	
											// List of alarm entries;
											// This is a variable size field which
											// ***MUST BE LAST***
	AlmEntryType	list[almMinTableLength];
	} AlmTableType;

typedef AlmTableType*		AlmTablePtr;
typedef AlmTablePtr*			AlmTableHandle;


/*******************************************************************
 * Alarm Manager Globals
 *
 *******************************************************************/
typedef struct AlmGlobalsType {
	// We're not making the alarm table a part of the
	// Alarm Globals structure because it is allowed
	// to resize, thus posing a problem for
	// AlmAlarmCallback() which needs to access the
	// Alarm Globals at interrupt time.
	AlmTableHandle	tableH;			// alarm table handle;

	ULong				lastSoundSeconds;
											// alarm seconds of the last alarm for
											// which an alarm was sounded;

	Word				displaying : 1;// 1 indicates we're blocked waiting for
											// some app to finish displaying an alarm
											// dialog box; set and cleared by
											// AlmDisplayNextAlarm();
											
	Word				triggered : 1;	// 1 indicates an alarm was triggered; this
											// field is set by the AlmAlarmCallback() and
											// is checked and cleared by AlmDisplayAlarm();

	Byte				disableCount;	// if this value is greater than zero, Alarm
											// notifications are disabled (see AlmEnableNotification);
	} AlmGlobalsType;

typedef AlmGlobalsType*		AlmGlobalsPtr;


#endif  // __ALARM_MGR_H__
#endif  // NON_PORTABLE
