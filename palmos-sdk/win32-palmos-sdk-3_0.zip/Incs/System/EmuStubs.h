/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		EmuStubs.h
 *
 * Description:
 *		Stub routines used only when emulating.
 *		
 *		Note: All of these routines must be declared using generic
 *		C types so that this header file can be included in both
 *		Pilot source code and Mac or PC source code. 
 *
 *		The module that contains these routines "MacStubs.c" or
 *		"PCStubs.c" is the glue between the Pilot routines and the OS and
 *		does not include any Pilot headers.
 *
 * History:
 *   	11/03/94  RM - Created by Ron Marianetti
 *
 *
 *******************************************************************/


#ifndef __EMUSTUBS_H__
#define __EMUSTUBS_H__

typedef enum 
	{
	emuSendNoEvent,
	emuSendNilEvent,
	emuSendPenOrKeyEvent
	} StubNilEventIsPendingResults;

/************************************************************
 * Prototypes
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

// Screen Driver Stubs
void 				StubDrawNotify(void* srcWinP, short scrRowBytes, short scrDepth, 
						short fromX, short fromY, short width, short height);

// Console stubs
int 				StubConPutS(char* cstring);
int 				StubConGetS(char* cstring);

// Debugger Stubs
void 				StubDbgSrcBreak(void);
void 				StubDbgSrcMessage(char* debugStr);
void 				StubDbgBreak(void);
void 				StubDbgMessage(char* aStr);

// Time Manager Stubs
unsigned long	StubTimGetTicks(void);
unsigned long	StubTimGetSeconds(void);
void				StubTimSetSeconds(unsigned long seconds);


// Event Manager Stubs
void				StubProcessMacEvents(long timeout);
void				StubEnqueuePenPosition(void);
void				StubFlushEvents (void);


// Emulator Stubs
StubNilEventIsPendingResults			StubNilEventIsPending();
	

// Error Manager stubs
void 				StubErrDisplayFileLineMsg(const char * const filename, 
						unsigned int lineNo, const char * const msg);
	

// Sound Manager stubs
#define	stubSndErrBadParam			-1
#define	stubSndErrBadChannel			-2

#define	stubSndCmdFreqDurationAmp	1		// param1 = freq in hz, param2 = duration in millisec,
														// param3 = relative amplitidue 0-64;
#define	stubSndCmdNoteOn				2		// param1 = MIDI key # (0-127),
														// param2 = 0,
														// param3 = key velocity (0-127)
#define	stubSndCmdQuiet				3		// param1-3 = 0;

#define	stubSndCmdMakeGlobalChannel	4

#define	stubSndCmdFreeGlobalChannel	5

#define	stubSndCmdFrqOn				6		// param1 = freq in hz,
														// param2 = 0,
														// param3 = relative amplitidue 0-64;

short 			StubSndCommand(void* channelP, unsigned short defAmp,
							unsigned short cmd, unsigned long param1,
							unsigned short param2, unsigned short param3,
							char noWait);
							

// Alarm Manager stubs
short				StubAlmSetAlarm(unsigned long alarmType,
						long (*callback)(), unsigned long alarmTime);
unsigned long	StubAlmGetAlarm(unsigned long alarmType);
void				StubAlmDisplayAlarm(void);


// Emulator Utility Functions
void				StubEventTrace(void *eventP);			// Pilot Emulator Event Trace call


// Resource Utility Functions
void**			StubGet1Resource(unsigned long resType, int resID);	

// Graphics Utility functions. 
void 				StubInitCTable(void* cTableP, unsigned int depth);

// Utility functions
unsigned int	StubRandom(void);
	

// Key Manager stubs
unsigned long StubKeyCurrentState(void);

#define stubKeyBitPower			0x0001
#define stubKeyBitPageUp		0x0002
#define stubKeyBitPageDown		0x0004
#define stubKeyBitHard1			0x0008	
#define stubKeyBitHard2			0x0010
#define stubKeyBitHard3			0x0020
#define stubKeyBitHard4			0x0040

char				StubCancelKey(void);

#ifdef __cplusplus 
}
#endif


#endif 	// __EMUSTUBS_H__


