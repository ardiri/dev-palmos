/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot INet Library
 * FILE:     INetLib.h
 * AUTHOR:	 Ron Marianetti 6/2/97
 *
 * DESCRIPTION:
 *	  This header file contains equates for the Internet Library. 
 *
 **********************************************************************/
#ifndef 	__INETLIB_H__
#define	__INETLIB_H__



#pragma mark Constants

// Creator. Used for both the database that contains the INet Library and
//  it's features for the feature manager. 
#define	inetCreator				'inet'			// The Net Library creator

// INet Library features have this creator 
#define	inetLibFtrCreator		inetCreator		// creatorID of INet Lib features. 

// Feature inetCreator, #0 is the version number
// 0xMMmfsbbb, where MM is major version, m is minor version
// f is bug fix, s is stage: 3-release,2-beta,1-alpha,0-development,
// bbb is build number for non-releases 
// V1.12b3   would be: 0x01122003
// V2.00a2   would be: 0x02001002
// V1.01     would be: 0x01013000
#define  inetFtrNumVersion		0


// Database Type if the INet library. 
#define	inetLibType				'libr'			// The INet Library Database type


/********************************************************************
 * flags for the INetLibOpen call
 ********************************************************************/
#define	inetOpenFlagOKWireless			0x00000001		// OK to use wireless network
#define	inetOpenFlagOKWireline			0x00000002		// OK to use wireline network
#define 	inetOpenFlagPreferWireless		0x00000004		// prefer wireless over wireline


#pragma mark ErrorCodes
/********************************************************************
 * Error codes
 ********************************************************************/
#define	inetErrTooManyClients			(inetErrorClass | 1)		// Too many clients already
#define	inetErrHandleInvalid				(inetErrorClass | 2)		// Invalid inetH or sockH
#define	inetErrParamsInvalid				(inetErrorClass | 3)		//  
#define	inetErrURLVersionInvalid		(inetErrorClass | 4)		// 
#define	inetErrURLBufTooSmall			(inetErrorClass | 5)		// 
#define	inetErrURLInvalid					(inetErrorClass | 6)		// 
#define	inetErrTooManySockets			(inetErrorClass | 7)		// 
#define	inetErrNoRequestCreated			(inetErrorClass | 8)
#define	inetErrNotConnected				(inetErrorClass | 9)
#define	inetErrInvalidRequest			(inetErrorClass | 10)
#define	inetErrNeedTime					(inetErrorClass | 11)
#define	inetErrHostnameInvalid			(inetErrorClass | 12)
#define	inetErrInvalidPort				(inetErrorClass | 13)
#define	inetErrInvalidHostAddr			(inetErrorClass | 14)
#define	inetErrNilBuffer					(inetErrorClass | 15)
#define	inetErrConnectTimeout			(inetErrorClass | 16)
#define	inetErrResolveTimeout			(inetErrorClass | 17)
#define	inetErrSendReqTimeout			(inetErrorClass | 18)
#define	inetErrReadTimeout				(inetErrorClass | 19)
#define	inetErrBufTooSmall				(inetErrorClass | 20)
#define	inetErrSchemeNotSupported		(inetErrorClass | 21)
#define	inetErrInvalidResponse			(inetErrorClass | 22)

#pragma mark Types
/********************************************************************
 * Scheme Types
 ********************************************************************/
typedef enum {
	inetSchemeUnknown = -1,
	inetSchemeDefault = 0,
	
	inetSchemeHTTP,								// http:
	inetSchemeHTTPS,								// https:
	inetSchemeFTP,									// ftp:
	inetSchemeGopher,								// gopher:
	inetSchemeFile,								// file:
	inetSchemeNews,								// news:
	inetSchemeMailTo,								// mailto:

	inetSchemeMail,								// not applicable to URLS, but used
														//  for the INetLibSockOpen call when
														//  creating a socket for mail IO
	
	inetSchemeFirst = inetSchemeHTTP,		// first one
	inetSchemeLast	= inetSchemeMail			// last one
	} INetSchemeEnum;


/********************************************************************
 * Structure of a cracked URL. 
 ********************************************************************/
typedef struct {
	Word		version;								// should be 0, for future compatibility
	
	BytePtr	schemeP;								// ptr to scheme portion
	Word		schemeLen;							// size of scheme portion
	Word		schemeEnum;							// INetSchemEnum
	
	BytePtr	hostnameP;							// ptr to host name portion
	Word		hostnameLen;						// size of host name
	
	Word		port;									// port number
	
	BytePtr	usernameP;							// ptr to username portion
	Word		usernameLen;						// size of username
	
	BytePtr	passwordP;							// ptr to password portion
	Word		passwordLen;						// size of password
	
	BytePtr	pathP;								// ptr to path portion
	Word		pathLen;								// size of path
	
	BytePtr	extraInfoP;							// extra info (?params, #params, etc)
	Word		extraInfoLen;						// size of extra info
	
	} INetURLType;
	
	

/********************************************************************
 * Proxy Types
 ********************************************************************/
typedef enum {
	inetProxyNone = 0,							// no proxy
	inetProxyJerry = 1							// Jerry proxy
	} INetProxyEnum;


/********************************************************************
 * Settings for the INetLibSettingSet/Get and INetLibSockSettingSet/Get
 *  calls. 
 ********************************************************************/
typedef enum {
	inetSettingProxyType,						// DWord, INetProxyEnum
	
	inetSettingJerryProxyName,					// Char[], name of proxy
	inetSettingJerryProxyPort,					// DWord,  TCP port # of proxy
	inetSettingJerryProxyAddrGrMAN,			// DWord, Mobitex MAN number
	inetSettingJerryProxyAddrMAN,				// DWord, Mobitex MAN number
	
	inetSettingWirelessNetwork,				// Byte, Read-Only
	
	inetSettingSockContext,						// DWord, read-only
	
	
	inetSettingLast
	} INetSettingEnum;


/********************************************************************
 * Possible socket status values that can be returned from INetLibSockStatus
 ********************************************************************/
typedef enum {
	inetStatusNew,									// just opened
	inetStatusResolvingName,					// looking up host address
	inetStatusNameResolved,						// found host address
	inetStatusConnecting,						// connecting to host
	inetStatusConnected,							// connected to host
	inetStatusSendingRequest,					// sending request
	inetStatusWaitingForResponse,				// waiting for response
	inetStatusReceivingResponse,				// receiving response
	inetStatusResponseReceived,				// response received
	inetStatusClosingConnection				// closing connection
	
	} INetStatusEnum;



/********************************************************************
 * HTTP Attributes which can be set/get using the
 *  INetLibHTTPAttrSet/Get calls.
 *
 * Generally, attributes are only set BEFORE calling 
 *		InetLibSockHTTPReqSend
 * and attributes are only gotten AFTER the complete response
 *		 has been received.
 ********************************************************************/
typedef enum {

	// local error trying to communicate with server, if any
	inetHTTPAttrCommErr,							// DWord, read-only
	
	// object attributes, defined at creation
	inetHTTPAttrEntityURL,						// Char[], which resource was requested
	
	// Request only attributes
	inetHTTPAttrReqAuthorization,				
	inetHTTPAttrReqFrom,
	inetHTTPAttrReqIfModifiedSince,
	inetHTTPAttrReqReferer,
	
	// Response only attributes
	inetHTTPAttrRspAll,							// Char[] - entire HTTP response including
														//   data
	inetHTTPAttrRspVersion,						// Char[]
	inetHTTPAttrStatusCode,						// DWord
	inetHTTPAttrReason,							// Char[]
	inetHTTPAttrDate,								// DWord
	inetHTTPAttrNoCache,							// DWord
	inetHTTPAttrPragma,							// Char[]
	inetHTTPAttrServer,							// Char[]
	inetHTTPAttrWWWAuthentication,			// Char[]
	
	// Returned entity attributes
	inetHTTPAttrContentAllow,					// Char[]
	inetHTTPAttrContentEncoding,				// Char[]
	inetHTTPAttrContentLength,					// DWord
	inetHTTPAttrContentPtr,						// CharPtr
	inetHTTPAttrContentType,					// Char[]
	inetHTTPAttrContentExpires,				// DWord
	inetHTTPAttrContentLastModified,			// DWord
	inetHTTPAttrContentLocation				// Char[]
	
	} INetHTTPAttrEnum;




/********************************************************************
 * Structure of our Internet events. This structure is a superset of
 *  the regular event type. Note that we use the first 2 user events
 *  for the Internet Library so any app that uses this library must be
 *  to use user event IDs greater than inetLastEvent.
 ********************************************************************/
#define		inetSockReadyEvent				firstUserEvent
#define		inetSockStatusChangeEvent		firstUserEvent+1
#define		inetLastEvent						firstUserEvent+1

typedef struct {
	enum events    eType;
	Boolean        penDown;
	SWord          screenX;
	SWord          screenY;
	union {
		struct  {
			Word data1;
			Word data2;
			Word data3;
			Word data4;
			Word data5;
			Word data6;
			Word data7;
			Word data8;
			} generic;

		struct  {
			Handle	sockH;								// socket handle
			DWord		context;								// application defined
			Boolean	inputReady;							// true if ready for reads
			Boolean	outputReady;						// true if ready for writes
			} inetSockReady;

		struct  {
			Handle	sockH;								// socket handle
			DWord		context;								// application defined
			Word		status;								// new status
			Err		sockErr;								// socket err, if any
			}inetSockStatusChange;
		} data;
	} INetEventType;


/********************************************************************
 * INet Library functions. 
 ********************************************************************/
#pragma mark Traps
typedef enum {
	inetLibTrapSettingGet = sysLibTrapCustom,
	inetLibTrapSettingSet,
	
	inetLibTrapGetEvent,
	
	inetLibTrapURLOpen,
	
	inetLibTrapSockRead,
	inetLibTrapSockWrite,
	
	inetLibTrapSockOpen,
	inetLibTrapSockClose,
	inetLibTrapSockStatus,
	inetLibTrapSockSettingGet,
	inetLibTrapSockSettingSet,
	inetLibTrapSockConnect,
	
	// Utilities
	inetLibTrapURLCrack,
	
	// HTTP calls
	inetLibTrapSockHTTPReqCreate,
	inetLibTrapSockHTTPAttrSet,
	inetLibTrapSockHTTPReqSend,
	inetLibTrapSockHTTPAttrGet,
	
	// Mail traps
	inetLibTrapSockMailReqCreate,
	inetLibTrapSockMailAttrSet,
	inetLibTrapSockMailReqAdd,
	inetLibTrapSockMailReqSend,
	inetLibTrapSockMailAttrGet,
	inetLibTrapSockMailQueryProgress,
	
	inetLibTrapLast
	} INetLibTrapNumberEnum;


/********************************************************************
 * Mail Specific Equates
 ********************************************************************/
#include <INetMgrMail.h>


#pragma mark Functions
//--------------------------------------------------
// Library initialization, shutdown, sleep and wake
//--------------------------------------------------
Err				INetLibOpen (Word libRefnum, DWord flags, Handle* inetHP)
						SYS_TRAP(sysLibTrapOpen);
					
Err				INetLibClose (Word libRefnum, Handle inetH)
						SYS_TRAP(sysLibTrapClose);
					
Err				INetLibSleep (Word libRefnum)
						SYS_TRAP(sysLibTrapSleep);
					
Err				INetLibWake (Word libRefnum)
						SYS_TRAP(sysLibTrapWake);
					
//--------------------------------------------------
// Global settings
//--------------------------------------------------
Err				INetLibSettingGet(Word libRefnum, Handle inetH, 
							Word /*INetSettingEnum */ setting,
							VoidPtr bufP, WordPtr bufLenP)
						SYS_TRAP(inetLibTrapSettingGet);

Err				INetLibSettingSet(Word libRefnum, Handle inetH, 
							Word /*INetSettingEnum*/ setting,
							VoidPtr bufP, Word bufLen)
						SYS_TRAP(inetLibTrapSettingSet);


//--------------------------------------------------
// Event Management
//--------------------------------------------------

void			INetLibGetEvent(Word libRefnum, Handle clientParamH, 
									INetEventType* eventP, SDWord timeout)
						SYS_TRAP(inetLibTrapGetEvent);

						

//--------------------------------------------------
// High level calls
//--------------------------------------------------

Err				INetLibURLOpen(Word libRefnum, Handle inetH, BytePtr urlP, 
							Handle* sockHP, SDWord timeou)
						SYS_TRAP(inetLibTrapURLOpen);
						

Err				INetLibSockClose(Word libRefnum, Handle socketH)
						SYS_TRAP(inetLibTrapSockClose);
						

//--------------------------------------------------
// Read/Write
//--------------------------------------------------

Err				INetLibSockRead(Word libRefnum, Handle sockH, VoidPtr bufP,
							DWord reqBytes, DWordPtr actBytesP, SDWord timeout)
						SYS_TRAP(inetLibTrapSockRead);
						
Err				INetLibSockWrite(Word libRefnum, Handle sockH, VoidPtr bufP,
							DWord reqBytes, DWordPtr actBytesP, SDWord timeout)
						SYS_TRAP(inetLibTrapSockWrite);
						

//--------------------------------------------------
// Low level Socket calls
//--------------------------------------------------

Err				INetLibSockOpen(Word libRefnum, Handle inetH,
							Word /*INetSchemEnum*/ scheme,  Handle* sockHP)
						SYS_TRAP(inetLibTrapSockOpen);
						
Err				INetLibSockStatus(Word libRefnum, Handle socketH, WordPtr statusP,
							Err* sockErrP, Boolean* inputReadyP, Boolean* outputReadyP)
						SYS_TRAP(inetLibTrapSockStatus);
						

Err				INetLibSockSettingGet(Word libRefnum, Handle socketH, 
							Word /*INetSettingEnum*/ setting,
							VoidPtr bufP, WordPtr bufLenP)
						SYS_TRAP(inetLibTrapSockSettingGet);

Err				INetLibSockSettingSet(Word libRefnum, Handle socketH, 
							Word /*INetSettingEnum*/ setting,
							VoidPtr bufP, Word bufLen)
						SYS_TRAP(inetLibTrapSockSettingSet);


Err				INetLibSockConnect(Word libRefnum, Handle sockH, BytePtr hostnameP,
							Word port, SDWord timeou)
						SYS_TRAP(inetLibTrapSockConnect);

//--------------------------------------------------
// HTTP specific calls
//--------------------------------------------------

Err				INetLibSockHTTPReqCreate(Word libRefnum, Handle sockH, BytePtr verbP, 
							BytePtr resNameP, BytePtr refererP)
						SYS_TRAP(inetLibTrapSockHTTPReqCreate);
						
Err				INetLibSockHTTPAttrSet(Word libRefnum, Handle sockH, 
							Word /*inetHTTPAttrEnum*/ attr, Word attrIndex, 
							BytePtr bufP,  Word bufLen, Word flags)
						SYS_TRAP(inetLibTrapSockHTTPAttrSet);
						
Err				INetLibSockHTTPReqSend(Word libRefnum, Handle sockH, VoidPtr writeP,
							DWord writeLen, SDWord timeout)
						SYS_TRAP(inetLibTrapSockHTTPReqSend);
						
Err				INetLibSockHTTPAttrGet(Word libRefnum, Handle sockH, 
							Word /*inetHTTPAttrEnum*/ attr, Word attrIndex,
							VoidPtr bufP, DWordPtr bufLenP)
						SYS_TRAP(inetLibTrapSockHTTPAttrGet);
						


//--------------------------------------------------
// Utilities
//--------------------------------------------------

Err				INetLibURLCrack(Word libRefnum, BytePtr urlTextP,
							 INetURLType* urlP)
						SYS_TRAP(inetLibTrapURLCrack);


#endif 	//__INETLIB_H__
