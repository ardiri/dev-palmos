/***********************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     SysUtils.h
 * AUTHOR:	 Roger Flores: April 27, 1995
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  These are miscellaneous routines.
 *
 **********************************************************************/
#ifndef __SYSUTILS_H__
#define __SYSUTILS_H__

// Include elementary types
#include <Common.h>					// Basic types
#include <SysTraps.h>				// Trap Numbers.



//typedef Int _comparF (const void *, const void *, Int other);
typedef Int _comparF (VoidPtr, VoidPtr, Long other);
typedef _comparF * CmpFuncPtr;

typedef Int _searchF (const VoidPtr, const VoidPtr, Long other);
typedef _searchF * SearchFuncPtr;


typedef enum
	{
	GremlinIsOn				// return non zero if gremlins is currently running
	} GremlinFunctionType;
	
typedef struct 
	{
	DWord unused;
	} GremlinParamsType;


/************************************************************
 * Constants
 *************************************************************/
#define	sysRandomMax		0x7FFF			// Max value returned from SysRandom()


/************************************************************
 * Macros
 *************************************************************/
#define Abs(a) ((a >= 0) ? a : (-a))

/************************************************************
 * procedures
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

Boolean	SysBinarySearch (VoidPtr baseP, UInt numOfElements, UInt width, 
				 SearchFuncPtr searchF, const VoidPtr searchData, 
				const Long other, ULongPtr position, Boolean findFirst)
						SYS_TRAP(sysTrapSysBinarySearch);

void 		SysInsertionSort (VoidPtr baseP, UInt numOfElements, UInt width, 
				const CmpFuncPtr comparF, const Long other)
						SYS_TRAP(sysTrapSysInsertionSort);

void 		SysQSort (VoidPtr baseP, UInt numOfElements, UInt width, 
				const CmpFuncPtr comparF, const Long other)
						SYS_TRAP(sysTrapSysQSort);

void		SysCopyStringResource (CharPtr string, UInt theID)
						SYS_TRAP(sysTrapSysCopyStringResource);

VoidHand SysFormPointerArrayToStrings(CharPtr c, Int stringCount)
						SYS_TRAP(sysTrapSysFormPointerArrayToStrings);
						
						
// Return a random number ranging from 0 to sysRandomMax.
// Normally, 0 is passed unless you want to start with a new seed.
Int		SysRandom(ULong newSeed)
						SYS_TRAP(sysTrapSysRandom);


CharPtr SysStringByIndex(Word resID, Word index, CharPtr strP, Word maxLen)
						SYS_TRAP(sysTrapSysStringByIndex);

CharPtr 	SysErrString(Err err, CharPtr strP, Word maxLen)
						SYS_TRAP(sysTrapSysErrString);

DWord SysGremlins(GremlinFunctionType selector, GremlinParamsType *params)
						SYS_TRAP(sysTrapSysGremlins);


#ifdef __cplusplus
}
#endif

#endif // __SYSUTILS_H__

