/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------   
 * FileName:
 *		HardwarePrv.h
 *
 * Description:
 *		Private Hardware Equates. This header file
 *  contains equates that are common across all platforms but that 
 *  change value for each hardware rev and platform.
 *
 * History:
 *   	4/27/95  RM - Created by Ron Marianetti
 *
 *******************************************************************/  

#ifdef	NON_PORTABLE	   // So app's don't mistakenly include this

#ifndef __HARDWAREPRV_H__
#define __HARDWAREPRV_H__


// This must be defined on the command line before using this header!!
#if HW_TARGET != HW_TARGET_NONE
	#ifndef HW_REV
		#error	THE COMPILER VARIABLE HW_REV MUST BE DEFINED!!
	#endif
#endif



/***********************************************************************
 *  Equates for Emulation Mode
 ***********************************************************************/
#if HW_TARGET == HW_TARGET_NONE

#define	hwrCardSize			0x10000000L				// Size of each card slot

// DOLATER.. take this out??? 
// Under native mode, this mask can be used to convert a pointer to a card offse�
//#define	hwrCardOffsetMask	0x0FFFFFFFL


#endif



/***********************************************************************
 *  First Rev of the Pilot Hardware
 ***********************************************************************/
#if HW_TARGET == HW_TARGET_TD1
	

//  Define location and setup for the 68328 Dragonball chip
#define	hwr68328Base		0xFFFFF000L					// Base address of 68328 



// Define the base of card 0 and the size of each card slot.
#define	hwrCardBase0		0x10000000L					// starts here
#define	hwrCardSize			0x10000000L					// Size of each card slot
#define	hwrFlashBase		0x10C00000L					// Base of Flash ROM
#define	hwrFlashSize		0x00100000L					// Size of Flash ROM
#define	hwrCardOffsetMask	0x0FFFFFFFL					// Used to convert a pointer to a card offset


// Define the Flash width
#define	hwrROMWidth			2

//  Define location and setup for the 68681 Duart
#define	hwrDuartBase		0x10E00000				// Base address of DUART

#define	hwrDuartClock		3686400					// in Hertz (3.6864 MHz)
 
// Setting of ACR register except for baud rate select 
// Timer mode - Crystal clock /1
#define	hwrDuartACRReg		0x60					


#endif // 	HW_TARGET == HW_TARGET_TD1



#endif 	//__HARDWARE_H__
#endif 	// NON_PORTABLE
