/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ********************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     ShellCmdMemoPad.cp
 * AUTHOR:	 Roger Flores: Feb 26, 1996
 *
 * DESCRIPTION:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The stub's custom command is useless, but 
 * it does provide a template to add commands.  An application 
 * programmer can copy this file to their application folder and then 
 * customize it to handle as many commands as they wish.  The code here 
 * shows the result of customizing the stub to add a custom command.
 *
 * This file should be used in place of ShellCmdApp.cp.
 *
 **********************************************************************/

#include <Pilot.h>

// The code in the file is not used on the device.  Therefor it is
// acceptable to use standard C library routines.
#include <stdio.h>
#include <string.h>
#include <ctype.h>


// Include routines to insert text to the console window
#include "ShellCmd.h"

// Application database management defines.
// Copied from MemoPad.c
#define memoPadAppType		'Memo'			// P5. type for application.  must be 4 chars, mixed case.
#define memoPadDBType		'Data'			// P5. type for application database.  must be 4 chars, mixed case.


typedef void ShellCmdFuncType (int argc, CharPtr argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	CharPtr				longName;
	CharPtr				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;



/***********************************************************************
 *
 * FUNCTION:    FindOpenedMemoPadDatabase
 *
 * DESCRIPTION: Find an open memo pad database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    dbP - the memo pad database
 *
 ***********************************************************************/
static DmOpenRef FindOpenedMemoPadDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt			mode;
	UInt			cardNo;
	ULong			dbType;
	ULong			dbCreator;
	Err			err;
	
	
	// Find the memo pad's already opened database by checking each 
	// database.  The first database created by the memo pad and 
	// and of the data type is the memo pad's database.
	while (true)
		{
		// Get the next database or stop if no more
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;						// stop if no more databases


		// We need the dbID and cardNo to find the creator and type later
		err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			// Find the creator and type
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			// If the creator and type is the memo pad's then return this database
			if ( (dbType == memoPadDBType) && (dbCreator == memoPadAppType) )
				return (dbP);
			}
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    PrintMemoPadRecord
 *
 * DESCRIPTION: Print the details of a memo record.
 * The index number, unique id, attributes, and data are printed.
 *
 * PARAMETERS:  dbP - the database containing the record
 *              index - index of record to print
 *
 * RETURNED:    nothing.
 *
 ***********************************************************************/
static void PrintMemoPadRecord (DmOpenRef dbP, UInt index)
{
	char					text [256];
	LocalID				chunk;
	UInt					attr;
	ULong					uniqueID;
	VoidHand				recordDataH;
	CharPtr 				memoP;



	// Get record info
	DmRecordInfo (dbP, index, &attr, &uniqueID, &chunk);

	// Print record index.
	sprintf(text, "\nIndex:  %d", index);
	ShlInsertText(text);

	// Print the unique id
	sprintf(text, ",  unique id: %ld", uniqueID);
	ShlInsertText(text);
	
	// Print the various attributes separated by tabs
	if ((attr & dmRecAttrDelete) &&
		 chunk)
		ShlInsertText ("\tArchived");
	else if (attr & dmRecAttrDelete)
		ShlInsertText ("\tDeleted");
	if (attr & dmRecAttrDirty)
		ShlInsertText ("\tDirty");
	if (attr & dmRecAttrBusy)
		ShlInsertText ("\tBusy");
	if (attr & dmRecAttrSecret)
		ShlInsertText ("\tPrivate");

	// Deleted records have no data to print
	if (attr & dmRecAttrDelete)
		return;


	// Now get the record data
	recordDataH = DmQueryRecord(dbP, index);
	if (DmGetLastErr())
		{
		ShlInsertText("\nError querying record");
		return;
		}

	memoP = (CharPtr) MemHandleLock (recordDataH);
	
	
	// Display the memo.  A fancier routine would wrap text which 
	// is too long.
	ShlInsertText("\nDesc:   ");
	ShlInsertText (memoP);
	ShlInsertText("\n");
	

	MemHandleUnlock (recordDataH);
}


/***********************************************************************
 *
 * FUNCTION:    DoMemoPadGetAll
 *
 * DESCRIPTION: Print all memo pad records
 *
 *					 Syntax: DoMemoPadGetAll [access ptr]
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    nothing.
 *
 ***********************************************************************/
static void DoMemoPadGetAll(int argc, CharPtr argv[])
{
	int					i;
	UInt 					index = 0;
	char					text[256];
	Boolean				usageErr = false;
	DmOpenRef			dbP=0;


	// Commands followed by a question mark mean the user wants help 
	// for the command		.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	
	// parse through the command arguments
	// This command has one optional argument [access pointer]
	for (i=1; i<argc; i++)
		{
		if (isxdigit(argv[i][0]))
			sscanf(argv[i], "%d", &dbP);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}


	// If the user didn't specify a database try to find the memo pad's
	if (!dbP)
		dbP = FindOpenedMemoPadDatabase();
		
	if (!dbP)
		{
		ShlInsertText("Could not find an open memo pad database\n");
		return;
		}


	// Now print all the records
	for (index = 0; index < DmNumRecords(dbP); index++)
		PrintMemoPadRecord (dbP, index);

	ShlInsertText("\n");

	return;


Help:
	ShlInsertText("\nPrint all records in the memo pad database\n");
	ShlInsertText("Both the record info and data are printed.\n");

SyntaxOnly:
	sprintf(text, "Syntax: %s [access ptr]\n", argv[0]);  
	ShlInsertText(text);
}


/***********************************************************************
 *
 * FUNCTION:    ShlDoAppCmd
 *
 * DESCRIPTION: This routine check if a command is a user defined shell 
 *					 command for the application.  If so is the command is executed.
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was handled.
 *
 ***********************************************************************/
int ShlDoAppCmd (int argc, CharPtr argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 
		// Each command should have a customized line below
		// Full command name, short command name, command handler routine
		"MemoPadGetAll", 		"mpga",  	DoMemoPadGetAll,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;

}

