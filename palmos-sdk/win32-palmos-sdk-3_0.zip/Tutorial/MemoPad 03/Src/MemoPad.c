/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ********************************************************************************
 *
 * PROJECT:			Memo Pad Sample Application
 *
 * FILE:				MemoPad.c (Phase 3)
 *
 *			For best formatting set tab size to 3.
 *
 * DESCRIPTION:	Sample application to demonstrate the various
 *		features available.
 *	  
 *	OBJECTIVE:		Add a second form (the edit form) that is brought up
 *		by pressing the �New� button in the main form.
 *
 * REVISION HISTORY:
 * 	 9/1/95	David		Initial version
 *
 **********************************************************************/
 
#include <Pilot.h>				// all the system toolbox headers
#include "MemoPadRsc.h"			// application resource defines


/***********************************************************************
 * Global variables for this module
 **********************************************************************/
static MenuBarPtr		CurrentMenu = NULL;	// P2. ptr to current menu
static Word				CurrentView;			// P3. id of current form


/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static void StartApplication(void);
// static void SetCurrentMenu(Word rscID);	// P3. current menu now set in form resource
static Boolean EditFormHandleEvent(EventPtr event);
static Boolean MainFormHandleEvent(EventPtr event);
static Boolean ApplicationHandleEvent (EventPtr event);	// P3. handle form load events
static void EventLoop(void);


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     Nothing.
 *
 ***********************************************************************/
static void StartApplication(void)
{
	CurrentView = MemoPadMainForm;

	#ifdef saveForReference
	// P3. form now initialized via GoToForm and frmLoadEvent.
	// and current menu now set in form resource.

	// Initialize and draw the main memo pad form.
	frm = FrmInitForm(MemoPadMainForm);	
	FrmSetActiveForm(frm);
	FrmDrawForm(frm);

	SetCurrentMenu(MainMenuMenuBar);		// P2. set the current menu to the main menu
	#endif
}


#ifdef saveForReference
// P3. current menu now set in form resource.  this routine no longer necessary.
	
/***********************************************************************
 *
 * FUNCTION:    SetCurrentMenu
 *
 * DESCRIPTION: P2. This routine loads the specified menu resource and makes
 *              it the current menu.  
 *
 * PARAMETERS:  rscID  - resource id of the new menu
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void SetCurrentMenu(Word rscID)
{
	// Dispose of an existing current menu.
	if (CurrentMenu)
		MenuDispose(CurrentMenu);
	
	// Set the current menu and remember it.
	CurrentMenu = MenuInit(rscID);
}
#endif


/***********************************************************************
 *
 * FUNCTION:		EditFormHandleEvent
 *
 * DESCRIPTION:	P3. Handles processing of events for the �edit� form.
 *
 * PARAMETERS:		event		- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean EditFormHandleEvent(EventPtr event)
{
	Boolean	handled = false;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (event->data.ctlEnter.controlID == MemoPadEditDoneButton)
	   		{
	   		FrmGotoForm(MemoPadMainForm);
				handled = true;
				}
			break;
  	
  		case frmOpenEvent:	// The form was told to open.
  			// It has already been loaded and activated so just draw it.
			FrmDrawForm (FrmGetActiveForm());
			handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:		MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:		event		- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean		handled = false;
	EventType	newEvent;
	FormPtr		frm;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// P3. If the exit button is pressed, stop the application.
	   	if (event->data.ctlEnter.controlID == MemoPadMainExitButton)
	   		{
	   		MemSet(&newEvent, sizeof(EventType), 0);
		   	newEvent.eType = appStopEvent;
		   	EvtAddEventToQueue(&newEvent);
				handled = true;
				}
			
			// P3. If the new button is pressed, go to the edit form.
			else if (event->data.ctlEnter.controlID == MemoPadMainNewButton)
				{
				FrmGotoForm(MemoPadEditForm);
				handled = true;
				}
			break;
  	
  		case frmOpenEvent:	// P3. The form was told to open.
  			// It has already been loaded and activated so just draw it.
			FrmDrawForm (FrmGetActiveForm());
			handled = true;
			break;
	
		case menuEvent:		// P2. A menu item was selected.
			// The �get info� being the only menu item, display the info form.
			
			// First clear the menu status from the display.
			MenuEraseStatus(CurrentMenu);
			
			// Load the info form, then display it.
			frm = FrmInitForm(MemoPadInfoForm);
			FrmDoDialog(frm);
			
			// Delete the info form.
	 		FrmDeleteForm(frm);
			handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: P3. This routine loads a form resource and sets the event handler for the form.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    True if the event has been handled and should not be
 *						passed to a higher level handler.
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent (EventPtr event)
{
	FormPtr	frm;
	Word		formId;
	Boolean	handled = false;

	if (event->eType == frmLoadEvent)
		{
		// load the form resource specified in the event then activate the form.
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);

		// set the event handler for the form.  The handler of the currently 
		// active form is called by FrmDispatchEvent each time it receives an event.
		switch (formId)
			{
			case MemoPadMainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				break;
		
			case MemoPadEditForm:
				FrmSetEventHandler(frm, EditFormHandleEvent);
				break;
			}
		handled = true;
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:		EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *						Manager and passes them on to various applications and
 *						system event handlers before passing them on to
 *						FrmDispatchEvent for default processing.
 *
 * PARAMETERS:		None.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType	event;
	Word			error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent(&event))

			// P2. Give the menu bar a chance to update and handle the event.	
			if (! MenuHandleEvent(CurrentMenu, &event, &error))

				// P3. Give the application a chance to handle the event.
				if (! ApplicationHandleEvent(&event))

					// P3. Let the form object provide default handling of the event.
					FrmDispatchEvent(&event);
		}
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:		PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *						under standard �C�.  It is called by the Emulator to begin
 *						execution of this application.
 *
 * PARAMETERS:		cmd - command specifying how to launch the application.
 *						cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:		Any applicable error codes.
 *
 ***********************************************************************/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
	// Check for a normal launch.
	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		// Initialize the application's data structures, ...
		StartApplication();

		// P3. Start the first form
		FrmGotoForm(CurrentView);
			
		// Start the event loop.
		EventLoop();
		}
	return 0;
}
