/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ********************************************************************************
 *
 * PROJECT:			Memo Pad Sample Application
 *
 * FILE:				MemoPad.c (Phase 2)
 *
 *       For best formatting set tab size to 3.
 *
 * DESCRIPTION:	Sample application to demonstrate the various
 *		features available.
 *
 *	OBJECTIVE:		Add a menu bar in the main form with a menu item that
 *		triggers an info dialog.
 *
 * REVISION HISTORY:
 * 	 9/1/95	David		Initial version
 *
 **********************************************************************/
 
#include <Pilot.h>				// all the system toolbox headers
#include "MemoPadRsc.h"			// application resource defines


/***********************************************************************
 * Global variables for this module
 **********************************************************************/
static MenuBarPtr		CurrentMenu = NULL;	// P2. ptr to current menu


/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static void StartApplication(void);
static void SetCurrentMenu(Word rscID);	// P2. set new current menu
static Boolean MainFormHandleEvent(EventPtr event);
static void EventLoop(void);


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     Nothing.
 *
 ***********************************************************************/
static void StartApplication(void)
{
	FormPtr	frm;

	// Initialize and draw the main memo pad form.
	frm = FrmInitForm(MemoPadMainForm);	
	FrmSetActiveForm(frm);
	FrmDrawForm(frm);

	SetCurrentMenu(MainFormMenuBar);		// P2. set the current menu to the main menu
}

/***********************************************************************
 *
 * FUNCTION:    SetCurrentMenu
 *
 * DESCRIPTION: P2. This routine loads the specified menu resource and makes
 *              it the current menu.  
 *
 * PARAMETERS:  rscID  - resource id of the new menu
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void SetCurrentMenu(Word rscID)
{
	// Dispose of an existing current menu.
	if (CurrentMenu)
		MenuDispose(CurrentMenu);
	
	// Set the current menu and remember it.
	CurrentMenu = MenuInit(rscID);
}


/***********************************************************************
 *
 * FUNCTION:		MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:		event		- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean		handled = false;
	EventType	newEvent;
	FormPtr		frm;

   if (event->eType == ctlSelectEvent)
	   {
		// A control button is pressed and released.
		// The exit button being the only button, stop the application.
   	MemSet(&newEvent, sizeof(EventType), 0);
   	newEvent.eType = appStopEvent;
   	EvtAddEventToQueue(&newEvent);
		handled = true;
  		}

	else if (event->eType == menuEvent)		// P2. process menu events for this form
		{
		// A menu item was selected.
		// The �get info� being the only menu item, display the info form.
		
		// First clear the menu status from the display.
		MenuEraseStatus(CurrentMenu);
		
		// Load the info form, then display it.
		frm = FrmInitForm(MemoPadInfoForm);
		FrmDoDialog(frm);
		
		// Delete the info form.
 		FrmDeleteForm(frm);
		handled = true;
		}
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:		EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *						Manager and passes them on to various applications and
 *						system event handlers before passing them on to
 *						FrmHandleEvent for default processing.
 *
 * PARAMETERS:		None.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType	event;
	Word			error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent(&event))

			// P2. Give the menu bar a chance to update and handle the event.	
			if (! MenuHandleEvent(CurrentMenu, &event, &error))

				// Give the application a chance to handle the event.
				if (! MainFormHandleEvent(&event))

					// Let the form object provide default handling of the event.
					FrmHandleEvent(FrmGetActiveForm(), &event);
		}
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:		PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *						under standard �C�.  It is called by the Emulator to begin
 *						execution of this application.
 *
 * PARAMETERS:		cmd - command specifying how to launch the application.
 *						cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:		Any applicable error code.
 *
 ***********************************************************************/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
	// Check for a normal launch.
	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		// Set up initial form.
		StartApplication();
		
		// Start up the event loop.
		EventLoop();
		}
		
	return 0;
}



