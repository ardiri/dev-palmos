/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ********************************************************************************
 *
 * PROJECT:			Memo Pad Sample Application
 *
 * FILE:				MemoPad.c (Phase 4)
 *
 *		For best formatting set tab size to 3.
 *
 * DESCRIPTION:	Sample application to demonstrate the various
 *		features available.
 *	  
 * OBJECTIVE:		Add text field with menu options to copy, cut, paste,
 *		go to the top, and got to the bottom.
 *
 * REVISION HISTORY:
 * 	 9/1/95	David		Initial version
 *
 **********************************************************************/
 
#include <Pilot.h>				// all the system toolbox headers
#include <FeatureMgr.h>			//	P4. Needed to get the ROM version
#include "MemoPadRsc.h"			// application resource defines


/***********************************************************************
 * Global defines for this module
 **********************************************************************/

#define version20	0x02000000	// P4. PalmOS 2.0 version number


/***********************************************************************
 * Global variables for this module
 **********************************************************************/
static Word				CurrentView;			// P3. id of current form


/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static void StartApplication(void);
static FieldPtr GetFocusObjectPtr (void);						// P4. get ptr to text field
static void EditDoMenuCommand (Word command);				// P4. perform commands for edit form menu
static Boolean EditFormHandleEvent(EventPtr event);
static Boolean MainFormHandleEvent(EventPtr event);
static Boolean ApplicationHandleEvent (EventPtr event);	// P3. handle form load events
static void EventLoop(void);


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     Nothing.
 *
 ***********************************************************************/
static void StartApplication(void)
{
	CurrentView = MemoPadMainForm;
}


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: P4. Check that the ROM version meets your
 *              minimum requirement.  Warn if the app was switched to.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags indicating how the application was
 *											 launched.  A warning is displayed only if
 *                                these flags indicate that the app is 
 *											 launched normally.
 *
 * RETURNED:    zero if rom is compatible else an error code
 *                             
 ***********************************************************************/
static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;
	
	
	// See if we're on in minimum required version of the ROM or later.
	// The system records the version number in a feature.  A feature is a
	// piece of information which can be looked up by a creator and feature
	// number.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		// If the user launched the app from the launcher, explain
		// why the app shouldn't run.  If the app was contacted for something
		// else, like it was asked to find a string by the system find, then
		// don't bother the user with a warning dialog.  These flags tell how
		// the app was launched to decided if a warning should be displayed.
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.  The sysFileCDefaultApp is considered "safe".
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    GetFocusObjectPtr
 *
 * DESCRIPTION: P4. This routine returns a pointer to the field object, in 
 *              the current form, that has the focus.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    pointer to a field object or NULL of there is no focus
 *
 ***********************************************************************/
static FieldPtr GetFocusObjectPtr (void)
{
	FormPtr frm;
	Word focus;
	
	// get a pointer to tha active form and the index of the form object with focus
	frm = FrmGetActiveForm ();
	focus = FrmGetFocus (frm);
	
	// if no object has the focus return NULL pointer
	if (focus == noFocus)
		return (NULL);
		
	// return a pointer to the object with focus
	return (FrmGetObjectPtr (frm, focus));
}


/***********************************************************************
 *
 * FUNCTION:    EditDoMenuCommand
 *
 * DESCRIPTION: P4. This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void EditDoMenuCommand (Word command)
{
	FieldPtr	fld;
	FormPtr	frm;

	// Do the appropriate action for the menu command selected.
	switch (command)
		{
		case EditOptionsGetInfo:		// display the info form
			// Load the info form, then display it.
			frm = FrmInitForm(MemoPadInfoForm);
			FrmDoDialog(frm);
			
			// Delete the info form.
	 		FrmDeleteForm(frm);
			break;
		
		case EditOptionsGototopofpage:		// Go to the top of the field.	
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetInsPtPosition(fld, 0);
			break;
		
		case EditOptionsGotobottomofpage:	// Go to the bottom of the field.
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetInsPtPosition(fld, FldGetTextLength(fld));
			break;
		
		case EditEditCut:			// Do a cut to the clipboard if text is highlighted.
			fld = GetFocusObjectPtr();
			if (fld)
				FldCut(fld);
			break;
		
		case EditEditCopy:			// Copy the highlighted text to the clipboard.
			fld = GetFocusObjectPtr();
			if (fld)
				FldCopy(fld);	
			break;
		
		case EditEditPaste:			// Do a paste from the clipboard.
			fld = GetFocusObjectPtr();
			if (fld)
				FldPaste(fld);		
			break;
			
		case EditEditUndo:			// undo the last text change.
			fld = GetFocusObjectPtr();
			if (fld)
				FldUndo(fld);
			break;
		
		case EditEditSelectAll:	// Select all the existing text.
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetSelection(fld, 0, FldGetTextLength(fld));
			break;
			
		case EditEditKeyboard:		// display the on screen keyboard
			SysKeyboardDialog (kbdAlpha);
			break;
			
		case EditEditGraffiti:		// Display the graffiti reference screen
			SysGraffitiReferenceDialog (referenceDefault);
			break;
			
		}	
}


/***********************************************************************
 *
 * FUNCTION:		EditFormHandleEvent
 *
 * DESCRIPTION:	P3. Handles processing of events for the �edit� form.
 *
 * PARAMETERS:		event		- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean EditFormHandleEvent(EventPtr event)
{
	FormPtr		frm;
	Boolean	handled = false;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (event->data.ctlEnter.controlID == MemoPadEditDoneButton)
	   	{
	   		FrmGotoForm(MemoPadMainForm);
				handled = true;
			}
			break;
  	
  		case frmOpenEvent:	// The form was told to open.
  			// It has already been loaded and activated so just draw it.
			frm = FrmGetActiveForm();
			FrmDrawForm (frm);
			
			// P4. set the focus, and the insertion point, to the text edit field
			FrmSetFocus(frm, FrmGetObjectIndex(frm, MemoPadEditEditFieldField));
			handled = true;
			break;
			
		case menuEvent:		// P4. A menu item was selected.
			// First clear the menu status from the display.
			MenuEraseStatus(0);
			
			// process menu commands for the edit form
			EditDoMenuCommand(event->data.menu.itemID);
			handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:		MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:		event		- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean		handled = false;
	EventType	newEvent;
	FormPtr		frm;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.

	   	// P3. If the exit button is pressed, stop the application.
	   	if (event->data.ctlEnter.controlID == MemoPadMainExitButton)
	   		{
	   		MemSet(&newEvent, sizeof(EventType), 0);
		   	newEvent.eType = appStopEvent;
		   	EvtAddEventToQueue(&newEvent);
				handled = true;
				}
			
			// P3. If the new button is pressed, go to the edit form.
			else if (event->data.ctlEnter.controlID == MemoPadMainNewButton)
				{
				FrmGotoForm(MemoPadEditForm);
				handled = true;
				}
			break;
  	
  		case frmOpenEvent:	// P3. The form was told to open.
  			// It has already been loaded and activated so just draw it.
			FrmDrawForm (FrmGetActiveForm());
			handled = true;
			break;
	
		case menuEvent:		// P2. A menu item was selected.
			// The �get info� being the only menu item, display the info form.
			
			// First clear the menu status from the display.
			MenuEraseStatus(0);
			
			// Load the info form, then display it.
			frm = FrmInitForm(MemoPadInfoForm);
			FrmDoDialog(frm);
			
			// Delete the info form.
	 		FrmDeleteForm(frm);
			handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: P3. This routine loads a form resource and sets the event handler for the form.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    True if the event has been handled and should not be
 *						passed to a higher level handler.
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent (EventPtr event)
{
	FormPtr	frm;
	Word		formId;
	Boolean	handled = false;

	if (event->eType == frmLoadEvent)
		{
		// load the form resource specified in the event then activate the form.
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);

		// set the event handler for the form.  The handler of the currently 
		// active form is called by FrmDispatchEvent each time it receives an event.
		switch (formId)
			{
			case MemoPadMainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				break;
		
			case MemoPadEditForm:
				FrmSetEventHandler(frm, EditFormHandleEvent);
				break;
			}
		handled = true;
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:		EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *						Manager and passes them on to various applications and
 *						system event handlers before passing them on to
 *						FrmDispatchEvent for default processing.
 *
 * PARAMETERS:		None.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType	event;
	Word			error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent(&event))

			// P2. Give the menu bar a chance to update and handle the event.	
			if (! MenuHandleEvent(0, &event, &error))

				// P3. Give the application a chance to handle the event.
				if (! ApplicationHandleEvent(&event))

					// P3. Let the form object provide default handling of the event.
					FrmDispatchEvent(&event);
		}
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:		PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *						under standard �C�.  It is called by the Emulator to begin
 *						execution of this application.
 *
 * PARAMETERS:		cmd - command specifying how to launch the application.
 *						cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:		Any applicable error codes.
 *
 ***********************************************************************/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
	Word error;		// P4. error starting the app
	
	
	// P4. This app makes use of PalmOS 2.0 features.  It will crash if
	// run on an earlier version of PalmOS.  Detect and warn if this happens,
	// then exit.
	error = RomVersionCompatible (version20, launchFlags);
	if (error)
		return error;
	
	// P4. This app doesn't support any action codes.
	if (cmd != sysAppLaunchCmdNormalLaunch) return sysErrParamErr;
	
	// Initialize the application's data structures, ...
	StartApplication();

	// P3. Start the first form
	FrmGotoForm(CurrentView);
		
	// Start the event loop.
	EventLoop();
	
	return 0;
}
