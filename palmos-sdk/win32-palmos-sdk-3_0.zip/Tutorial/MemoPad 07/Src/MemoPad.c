/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 ********************************************************************************
 *
 * PROJECT:			Memo Pad Sample Application
 *
 * FILE:				MemoPad.c (Phase 7)
 *
 *		For best formatting set tab size to 3.
 *
 * DESCRIPTION:	Sample application to demonstrate the various
 *		features available.
 *	  
 * OBJECTIVE:		Add list of records to main view and support for 
 *		multiple records in application database.
 *
 * REVISION HISTORY:
 * 	 9/1/95	David		Initial version
 *
 **********************************************************************/
 
#include <Pilot.h>				// all the system toolbox headers
#include <FeatureMgr.h>			//	P4. Needed to get the ROM version
#include "MemoPadRsc.h"			// application resource defines


/***********************************************************************
 * Global defines for this module
 **********************************************************************/
#define version20	0x02000000	// P4. PalmOS 2.0 version number

// Application database management defines.
#define memoPadAppType		'Memo'			// P5. type for application.  must be 4 chars, mixed case.
#define memoPadDBType		'Data'			// P5. type for application database.  must be 4 chars, mixed case.
#define memoPadDBName		"MemoPadDB"		// P5. name for application database.  up to 31 characters.
#define noRecordSelected	-1					// P5. index for no current record.
#define newMemoSize  		64					// P6. initial size for new database record.


/***********************************************************************
 * Global variables for this module
 **********************************************************************/
static Word				CurrentView;			// P3. id of current form
static DmOpenRef		MemoPadDB;				// P5. handle for database
static Word				CurrentRecord;			// P5. index of current database record
static VoidHand 		ChoicesHandle = 0, ChoicesPtrsHandle;	// P7. handles for list data


/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static void StartApplication(void);
static void StopApplication(void);								// P5. clean up before app exit
static FieldPtr GetFocusObjectPtr(void);						// P4. get ptr to text field
static Boolean CreateRecord(void);								// P6. create a new record in the application database
static void EditDoMenuCommand(Word command);					// P4. perform commands for edit form menu
static void EditSaveData(FieldPtr fld);						// P5. save data to application database
static void EditRetrieveData(FieldPtr fld);					// P5. get data from application database
static Boolean EditFormHandleEvent(EventPtr event);
static void MainFormInit(void);									// P7. initialize data, objects for the main form
static Boolean MainFormHandleEvent(EventPtr event);
static Boolean ApplicationHandleEvent(EventPtr event);	// P3. handle form load events
static void EventLoop(void);


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *               It opens the application's database and sets up global variables. 
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     nothing.
 *
 ***********************************************************************/
static void StartApplication(void)
{
	Word		error;			// P5. error code
	UInt		cardNo;			// P5. card containing the application database
	LocalID	dbID;				// P5. handle for application database
	UInt		dbAttrs;
	UInt mode;

	// P5. Find the application's database.
	mode = dmModeReadWrite;
	MemoPadDB = DmOpenDatabaseByTypeCreator(memoPadDBType, memoPadAppType, mode);
	if (! MemoPadDB)
		{
		// P5. The database doesn't exist, create it now.
		error = DmCreateDatabase(0, memoPadDBName, memoPadAppType, memoPadDBType, false);

		// P5. Check for fatal error.
		ErrFatalDisplayIf(error, "Could not create new database.");
		
		// P5. Find the application's database.
		MemoPadDB = DmOpenDatabaseByTypeCreator(memoPadDBType, memoPadAppType, mode);

		// P5. Get info about the database
		error = DmOpenDatabaseInfo(MemoPadDB, &dbID, NULL, NULL, &cardNo, NULL);

		// P5. Check for fatal error.
		ErrFatalDisplayIf(error, "Could not get database info.");
	
		// P5. Get attributes for the database
		error = DmDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

		// P5. Check for fatal error.
		ErrFatalDisplayIf(error, "Could not get database info.");
	
		// P5. Set the new attributes in the database
		error = DmSetDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

		// P5. Check for fatal error.
		ErrFatalDisplayIf(error, "Could not set database info.");
		}
	
	// P5. Set current database record to no current record.
	CurrentRecord = noRecordSelected;

	// Set current view so the first form to display is the main form.
	CurrentView = MemoPadMainForm;
}


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: P4. Check that the ROM version meets your
 *              minimum requirement.  Warn if the app was switched to.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags indicating how the application was
 *											 launched.  A warning is displayed only if
 *                                these flags indicate that the app is 
 *											 launched normally.
 *
 * RETURNED:    zero if rom is compatible else an error code
 *                             
 ***********************************************************************/
static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;
	
	
	// See if we're on in minimum required version of the ROM or later.
	// The system records the version number in a feature.  A feature is a
	// piece of information which can be looked up by a creator and feature
	// number.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		// If the user launched the app from the launcher, explain
		// why the app shouldn't run.  If the app was contacted for something
		// else, like it was asked to find a string by the system find, then
		// don't bother the user with a warning dialog.  These flags tell how
		// the app was launched to decided if a warning should be displayed.
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.  The sysFileCDefaultApp is considered "safe".
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    StopApplication
 *
 * DESCRIPTION: P5. This routine closes the application's database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void StopApplication(void)
{
	// Close all open forms to allow their frmCloseEvent handlers
	// to execute.  An appStopEvent doesn't send frmCloseEvents.
	FrmCloseAllForms ();

	// Close the application's database.
	DmCloseDatabase(MemoPadDB);
}


/***********************************************************************
 *
 * FUNCTION:    GetFocusObjectPtr
 *
 * DESCRIPTION: P4. This routine returns a pointer to the field object, in 
 *              the current form, that has the focus.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    pointer to a field object or NULL of there is no focus
 *
 ***********************************************************************/
static FieldPtr GetFocusObjectPtr(void)
{
	FormPtr frm;
	Word focus;
	
	// Get a pointer to tha active form and the index of the form object with focus.
	frm = FrmGetActiveForm();
	focus = FrmGetFocus(frm);
	
	// If no object has the focus return NULL pointer.
	if (focus == noFocus)
		return (NULL);
		
	// Return a pointer to the object with focus.
	return (FrmGetObjectPtr(frm, focus));
}


/***********************************************************************
 *
 * FUNCTION:    CreateRecord
 *
 * DESCRIPTION: P6. This routine creates a new memo record.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true if the record was sucessfully created.
 *
 ***********************************************************************/
static Boolean CreateRecord(void)
{
	Ptr		p;
	VoidHand memoRec;
	UInt		index = 0;
	Err		error;
	Char		zero = 0;

	// Create a new first record in the database
	memoRec = DmNewRecord(MemoPadDB, &index, newMemoSize);

	// Lock down the block containing the new record.
	p = MemHandleLock(memoRec);

	// Write a zero to the first byte of the record to null terminate the new memo string.
	error = DmWrite(p, 0, &zero, sizeof(Char));
	
	// Check for fatal error.
	ErrFatalDisplayIf(error, "Could not write to new record.");
	
	// Unlock the block of the new record.
	MemPtrUnlock(p);

	// Release the record to the database manager.  The true value indicates that
	// the record contains "dirty" data.  Release Record will set the record's 
	// dirty flag and update the database modification count.
	DmReleaseRecord(MemoPadDB, index, true);

	// Remember the index of the current record.
	CurrentRecord = 0;
	return(true);	
}


/***********************************************************************
 *
 * FUNCTION:    EditDoMenuCommand
 *
 * DESCRIPTION: P4. This routine performs the menu command specified.
 *
 * PARAMETERS:  command - menu item id
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void EditDoMenuCommand(Word command)
{
	FieldPtr	fld;
	FormPtr	frm;

	// Do the appropriate action for the menu command selected.
	switch (command)
		{
		case EditOptionsGetInfo:		// Display the info form.
			// Load the info form, then display it.
			frm = FrmInitForm(MemoPadInfoForm);
			FrmDoDialog(frm);
			
			// Delete the info form.
	 		FrmDeleteForm(frm);
			break;
		
		case EditOptionsGototopofpage:		// Go to the top of the field.	
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetInsPtPosition(fld, 0);
			break;
		
		case EditOptionsGotobottomofpage:	// Go to the bottom of the field.
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetInsPtPosition(fld, FldGetTextLength(fld));
			break;
		
		case EditEditCut:			// Do a cut to the clipboard if text is highlighted.
			fld = GetFocusObjectPtr();
			if (fld)
				FldCut(fld);
			break;
		
		case EditEditCopy:			// Copy the highlighted text to the clipboard.
			fld = GetFocusObjectPtr();
			if (fld)
				FldCopy(fld);	
			break;
		
		case EditEditPaste:			// Do a paste from the clipboard.
			fld = GetFocusObjectPtr();
			if (fld)
				FldPaste(fld);		
			break;
			
		case EditEditUndo:			// Undo the last text change.
			fld = GetFocusObjectPtr();
			if (fld)
				FldUndo(fld);
			break;
		
		case EditEditSelectAll:	// Select all the existing text.
			fld = GetFocusObjectPtr();
			if (fld)
				FldSetSelection(fld, 0, FldGetTextLength(fld));
			break;
			
		case EditEditKeyboard:		// Display the on screen keyboard.
			SysKeyboardDialog(kbdAlpha);
			break;

		case EditEditGraffiti:		// Display the graffiti reference screen
			SysGraffitiReferenceDialog (referenceDefault);
			break;

		}	
}


/***********************************************************************
 *
 * FUNCTION:		EditSaveData
 *
 * DESCRIPTION:	P5. Saves the data in the field as the first record in 
 *                the application's database.
 *
 * PARAMETERS:		fld - the field that contains the text.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EditSaveData(FieldPtr fld)
{
	CharPtr	text;
	
	// Get a pointer to the field's text.
	text = FldGetTextPtr(fld);

	// P6. Clear the handle value in the field, otherwise the handle
	// will be freed when the form is closed.
	// This will cause problems since the handle is to the data
	// IN the database record, not a separate copy.
	FldSetTextHandle(fld, 0);

	// Is there data in the field?
	if (text != NULL && *text != 0)
		{
		// Release the record to the database manager.  The true value indicates that
		// the record contains "dirty" data.  Release Record will set the record's 
		// dirty flag and update the database modification count.
		DmReleaseRecord(MemoPadDB, CurrentRecord, true);
		}
	else 
		{
		// P7. The record is empty, remove it from the database.
		DmRemoveRecord(MemoPadDB, CurrentRecord);
		CurrentRecord = noRecordSelected;
		}
}


/***********************************************************************
 *
 * FUNCTION:		EditRetrieveData
 *
 * DESCRIPTION:	P5. Retrieves the data from the first record of a database 
 *						and places it in a field.
 *
 * PARAMETERS:		fld - the field to contain the text.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EditRetrieveData(FieldPtr fld)
{
	VoidHand	recHandle;
	
	// Check to make sure there is a record to retrieve.
	if (CurrentRecord != noRecordSelected && DmNumRecords(MemoPadDB) > 0)
		{
		// Get a handle for the first record.
		recHandle = DmGetRecord(MemoPadDB, CurrentRecord);
		
		// P6. Set the field's text to the data in the record.
		FldSetTextHandle(fld, recHandle);
		}
}


/***********************************************************************
 *
 * FUNCTION:		EditFormHandleEvent
 *
 * DESCRIPTION:	P3. Handles processing of events for the �edit� form.
 *
 * PARAMETERS:		event	- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean EditFormHandleEvent(EventPtr event)
{
	FormPtr	frm;
	Word		fldIndex;
	Boolean	handled = false;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.
			
	   	// If the done button is pressed, go back to the main form.
	   	if (event->data.ctlEnter.controlID == MemoPadEditDoneButton)
	  		 	{
				// Remove the edit form and display the main form.
	   		FrmGotoForm(MemoPadMainForm);
				handled = true;
				}
			break;
  	
  		case frmOpenEvent:	// The form was told to open.
  			// It has already been loaded and activated.
  			
  			// P5. Get a pointer to the form and the index of the text field.
			frm = FrmGetActiveForm();
			fldIndex = FrmGetObjectIndex(frm, MemoPadEditEditFieldField);

   		// P5. Get the data for the field from the application's database.
   		EditRetrieveData(FrmGetObjectPtr(frm, fldIndex));
			
  			// Draw the form with the text field data in place.
			FrmDrawForm(frm);
			
			// P4. Set the focus, and the insertion point, to the text edit field.
			FrmSetFocus(frm, fldIndex);
			handled = true;
			break;
			
		case menuEvent:		// P4. A menu item was selected.
			// First clear the menu status from the display.
			MenuEraseStatus(0);
			
			// Process menu commands for the edit form.
			EditDoMenuCommand(event->data.menu.itemID);
			handled = true;
			break;

  		case frmCloseEvent:
  			// P5. Get a pointer to the form and the index of the text field.
   		frm = FrmGetActiveForm();
   		fldIndex = FrmGetObjectIndex(frm, MemoPadEditEditFieldField);
   		
   		// P5. Save the data from the field to the application's database.
   		EditSaveData(FrmGetObjectPtr(frm, fldIndex));
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:		MainFormInit
 *
 * DESCRIPTION:	P7. Initializes the main form and the list object.
 *
 * PARAMETERS:		frm - pointer to the main form.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void MainFormInit(void)
{
	CharPtr			choices, recText;
	FormPtr			frm;
	ListPtr			lst;
	Handle			recHandle;
	RectangleType	lstRect;
	Int				itemIndex, textLen, lstWidth, choicesOffset = 0, i;
	UInt				numRecords;
	Err				error;
	Boolean			fits;


	// Get a pointer to the main form.
	frm = FrmGetActiveForm();
	
	// Get the number of records currently in the application's database.
	numRecords = DmNumRecords(MemoPadDB);
	if (numRecords)
		{
		// Prepare to setup the contents of the list for the main form.
		
		// Get a pointer to the list object.
		itemIndex = FrmGetObjectIndex(frm, MemoPadMainMemolistList);
		lst = FrmGetObjectPtr(frm, itemIndex);
	
		// Get the usable width of the list rectangle.
		FrmGetObjectBounds (frm, itemIndex, &lstRect);
		lstWidth = lstRect.extent.x - 2;
		
		// Allocate an initial block for the list choices.
		ChoicesHandle = MemHandleNew(sizeof(char));
	
		// Lock down the block and set it's initial value to an empty string.
		choices = MemHandleLock(ChoicesHandle);
		*choices = 0;
		
		// Build up the choices.  
		// A sequence of strings packed one after another, one for each record.
		for (itemIndex = 0; itemIndex < numRecords; itemIndex++)
			{
			// Retrieve the record from the database and lock it down.
			recHandle = DmGetRecord(MemoPadDB, itemIndex);
			recText = MemHandleLock(recHandle);
			
			// Determine the length of text that will fit within the list bounds.
			i = lstWidth;
			textLen = StrLen(recText);
			FntCharsInWidth(recText, &i, &textLen, &fits);
			
			// Grow the choices buffer to accomodate the new string. We must unlock
			// the chunk so that the Memory Manager can move the chunk if neccessary to
			// grow it.
			MemHandleUnlock(ChoicesHandle);
			error = MemHandleResize(ChoicesHandle, textLen + choicesOffset + sizeof('\0'));
			choices = MemHandleLock(ChoicesHandle);
			
			// Check for fatal error.
			ErrFatalDisplayIf(error, "Could not grow choices for list.");
		
			// Copy the text from the record to the choices buffer.
			for (i = 0; i < textLen; i++)
				choices[choicesOffset + i] = recText[i];
	
			// Update the end of choices offset and set a zero terminator 
			// on the string in the choices buffer.
			choicesOffset += textLen;
			choices[choicesOffset++] = 0;
	
			// Unlock the handle to the record.
			MemHandleUnlock(recHandle);
			
			// Release the record, not dirty.
			DmReleaseRecord(MemoPadDB, itemIndex, false);
			}
		
		// Create an array of pointers from the choices strings.
		ChoicesPtrsHandle = SysFormPointerArrayToStrings(choices, numRecords);
		
		// Set the list choices from the array of pointers.
		LstSetListChoices(lst, MemHandleLock(ChoicesPtrsHandle), numRecords);
		}
	
	// Draw the form.
	FrmDrawForm(frm);
}


/***********************************************************************
 *
 * FUNCTION:		MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:		event	- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean		handled = false;
	// EventType	newEvent;
	FormPtr		frm;
	ListPtr		lst;

	switch (event->eType)
		{
   	case ctlSelectEvent:  // A control button was pressed and released.
	   	switch (event->data.ctlEnter.controlID)
	   		{
	   		#ifdef saveForReference
	   		/* P7. Touchdown applications generally don't exit.  
	   		   They are stopped by the system when a new application is launched.
	   		*/
	   		case MemoPadMainExitButton:
					// P3. If the exit button is pressed, stop the application.
		   		MemSet(&newEvent, sizeof(EventType), 0);
			   	newEvent.eType = appStopEvent;
			   	EvtAddEventToQueue(&newEvent);
					handled = true;
					break;
				#endif
			
				case MemoPadMainNewButton:
					// P5. Flag to the edit form that a new record is needed.
					// CurrentRecord = noRecordSelected;
					
					// P6. Create a new database record.
					if (CreateRecord())
						{
						// P3. The new button is pressed, go to the edit form.
						FrmGotoForm(MemoPadEditForm);
						}
					handled = true;
					break;

	   		#ifdef saveForReference
				/* P7. The record edit is now initiated by tapping an item on the list.
				*/
				case MemoPadMainEditButton:
					// P5. Flag to the edit form that the first database record is needed.
					CurrentRecord = 0;
					
					// P6. Make sure there is at least one record to edit.
					// If not then create one.
					if (DmNumRecords(MemoPadDB) == 0)
						{
						if (!CreateRecord())
							{
							// A record couldn't be created to edit.  Do not edit anything.
							handled = true;
							break;
							}
						}
											
					// P5. The edit button is pressed, go to the edit form.
					FrmGotoForm(MemoPadEditForm);
					handled = true;
					break;
				#endif
				}
			break;
  	
  		case lstSelectEvent:  // P7. An entry in the list was selected.
			// Get the current selection from the list and set the current record to edit.
			frm = FrmGetActiveForm();
			lst = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MemoPadMainMemolistList));
			CurrentRecord = LstGetSelection(lst);
			
			// Go to the edit form.	
			FrmGotoForm(MemoPadEditForm);
			handled = true;
			break;

  		case frmOpenEvent:	// P3. The form was told to open.
  			// P7. Initialize the main form.
			MainFormInit();
			handled = true;
			break;
			
		case frmCloseEvent:	// P7. The form was told to close.
			// Free the memory blocks allocated for the list.
			if (ChoicesHandle)
				{
				MemHandleFree(ChoicesHandle);
				ChoicesHandle = 0;
				MemHandleFree(ChoicesPtrsHandle);
				}
			break;
	
		case menuEvent:		// P2. A menu item was selected.
			// The �get info� being the only menu item, display the info form.
			
			// First clear the menu status from the display.
			MenuEraseStatus(0);
			
			// Load the info form, then display it.
			frm = FrmInitForm(MemoPadInfoForm);
			FrmDoDialog(frm);
			
			// Delete the info form.
	 		FrmDeleteForm(frm);
			handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: P3. This routine loads a form resource and sets the event handler for the form.
 *
 * PARAMETERS:  event - a pointer to an EventType structure
 *
 * RETURNED:    True if the event has been handled and should not be
 *						passed to a higher level handler.
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent(EventPtr event)
{
	FormPtr	frm;
	Word		formId;
	Boolean	handled = false;

	if (event->eType == frmLoadEvent)
		{
		// Load the form resource specified in the event then activate the form.
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);

		// Set the event handler for the form.  The handler of the currently 
		// active form is called by FrmDispatchEvent each time it receives an event.
		switch (formId)
			{
			case MemoPadMainForm:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				break;
		
			case MemoPadEditForm:
				FrmSetEventHandler(frm, EditFormHandleEvent);
				break;
			}
		handled = true;
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:		EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *						Manager and passes them on to various applications and
 *						system event handlers before passing them on to
 *						FrmDispatchEvent for default processing.
 *
 * PARAMETERS:		None.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType	event;
	Word			error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent(&event))

			// P2. Give the menu bar a chance to update and handle the event.	
			if (! MenuHandleEvent(0, &event, &error))

				// P3. Give the application a chance to handle the event.
				if (! ApplicationHandleEvent(&event))

					// P3. Let the form object provide default handling of the event.
					FrmDispatchEvent(&event);
		}
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:		PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *						under standard �C�.  It is called by the Emulator to begin
 *						execution of this application.
 *
 * PARAMETERS:		cmd - command specifying how to launch the application.
 *						cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:		Any applicable error codes.
 *
 ***********************************************************************/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
	Word error;		// P4. error starting the app
	
	// P4. This app makes use of PalmOS 2.0 features.  It will crash if
	// run on an earlier version of PalmOS.  Detect and warn if this happens,
	// then exit.
	error = RomVersionCompatible (version20, launchFlags);
	if (error)
		return error;

	// P4. This app doesn't support any action codes.
	if (cmd != sysAppLaunchCmdNormalLaunch) return sysErrParamErr;
	
	// Initialize the application's global variables and database.
	StartApplication();

	// P3. Start the first form.
	FrmGotoForm(CurrentView);
		
	// Start the event loop.
	EventLoop();
	
	// P5. Clean up before exiting the applcation.
	StopApplication();
	
	return 0;
}
