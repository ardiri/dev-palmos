/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Elloit
 *
 * FILE:     MailDB.c
 *
 * AUTHOR:	 Art Lamb: May 30, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This file contains the database functions of the Mail application.
 *
 ***********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>
#include "Mail.h"

#define	NON_PORTABLE
#include <DataPrv.h>

/************************************************************
 * DB initialization date
 *************************************************************/

 MailAppInfoType DefaultMailApplicationInfo = {
 	// Renamed categories
 	0x000f,
 	
 	// Category labels
	"Inbox",
	"Outbox",
	"Deleted",
	"Filed",
	"Draft",	"",	"",	"",
	"",	"",	"",	"",
	"",	"",	"",	"",
	
	// Category Uniq IDs
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 
	
	// Last Uniq ID
	15,

	// Reserved
	0, 0,

 	// Dirty app info
 	0xFFFF,
	
	// sort by priority, due date
	sortByDate,

	// unsend message handle
	0,
	
	// signature offset
	sizeof (MailAppInfoType),
	};




/************************************************************
 *
 *  FUNCTION: ECMailDBValidate
 *
 *  DESCRIPTION: This routine validates the integrity of the mail
 *		datebase.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: nothing
 *
 *  CREATED: 11/6/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

void ECMailDBValidate (DmOpenRef dbP)
{
	UInt 					i;
	UInt 					numRecord;
	VoidHand				recordH;
	MailDBRecordType	record;
	
	numRecord = DmNumRecords (dbP);
	for (i = 0 ; i < numRecord; i++)
		{
		recordH = DmQueryRecord (dbP, i);
		if (! recordH) continue;

		MailGetRecord (dbP, i, &record, &recordH);

		ErrFatalDisplayIf ((record.flags.priority > priorityLow),
			"Invalid priority");
		
		ErrFatalDisplayIf ((record.flags.addressing > sentBCC),
			"Invalid addressing flag");
		
		MemHandleUnlock (recordH);
		}
}
#endif


/***********************************************************************
 *
 * FUNCTION:    DateCompare
 *
 * DESCRIPTION: This routine compares two dates.
 *
 * PARAMETERS:  d1 - a date 
 *              d2 - a date 
 *
 * RETURNED:    if d1 > d2  returns a positive int
 *              if d1 < d2  returns a negative int
 *              if d1 = d2  returns zero
 *
 * NOTE: This routine treats the DateType structure like an unsigned int,
 *       it depends on the fact the the members of the structure are ordered
 *       year, month, day form high bit to low low bit.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/95		Initial Revision
 *
 ***********************************************************************/
static Int DateCompare (DateType d1, DateType d2)
{
	UInt int1, int2;
	
	int1 = DateToInt(d1);
	int2 = DateToInt(d2);
	
	if (int1 > int2)
		return (1);
	else if (int1 < int2)
		return (-1);
	return 0;
}

/***********************************************************************
 *
 * FUNCTION:    TimeCompare
 *
 * DESCRIPTION: This routine compares two times.  "No time" is represented
 *              by minus one, and is considered less than all times.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    if t1 > t2  returns a positive int
 *              if t1 < t2  returns a negative int
 *              if t1 = t2  returns zero
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/95	Initial Revision
 *
 ***********************************************************************/
static Int TimeCompare (TimeType t1, TimeType t2)
{
	Int int1, int2;
	
	int1 = TimeToInt(t1);
	int2 = TimeToInt(t2);
	
	if (int1 > int2)
		return (1);
	else if (int1 < int2)
		return (-1);
	return 0;

}


/************************************************************
 *
 *  FUNCTION: CompareRecords
 *
 *  DESCRIPTION: Compare two records.
 *
 *  PARAMETERS: database record 1
 *				    database record 2
 *
 *  RETURNS: -n if record one is less (n != 0)
 *			     n if record two is less
 *
 *  CREATED: 1/23/95 
 *
 *  BY: Roger Flores
 *
 *	COMMENTS:	Compare the two records key by key until
 *	there is a difference.  Return -n if r1 is less or n if r2
 *	is less.  A zero is never returned because if two records
 *	seem identical then their unique IDs are compared!
 *
 * This function accepts record data chunk pointers to avoid
 * requiring that the record be within the database.  This is
 * important when adding records to a database.  This prevents
 * determining if a record is a deleted record (which are kept
 * at the end of the database and should be considered "greater").
 * The caller should test for deleted records before calling this
 * function!
 *
 * REVISION HISTORY:
 *			Name				Date		Description
 *			----				----		-----------
 *			Roger Flores	1/23/95	Initial Revision
 *			MGolden			7/14/97	added sort by read at the end if the result was 0.
 *
 *************************************************************/
static Int CompareRecords (MailPackedDBRecordPtr r1, MailPackedDBRecordPtr r2,
		 		Int sortOrder, SortRecordInfoPtr info1, 
				SortRecordInfoPtr info2, VoidHand appInfoH)
{
	Int		i;
	Int 		result;
	Char 		name1 [maxFriendlyNameLen];
	Char 		name2 [maxFriendlyNameLen];
	CharPtr	p1;
	CharPtr	p2;

	// Sort high priority message to the top.
	if (r1->flags.priority == priorityHigh || 
		 r2->flags.priority == priorityHigh)
		result = (short)r1->flags.priority - (short)r2->flags.priority;
	else
		result = 0;


	if (result == 0)
		{
		// Sort by date
		if (sortOrder == sortByDate)
			{
			result = DateCompare (r2->date, r1->date);
			if (result == 0)
				{
				result = TimeCompare (r2->time, r1->time);
				}
			}
	
		// Sort by subject.
		else if (sortOrder == sortBySubject)
			result = StrCaselessCompare (&r1->firstField, &r2->firstField);
		
		// Sort by "from" field.
		else
			{
			p1 = &r1->firstField;
			p2 = &r2->firstField;
			for (i = mailFieldSubject; i < mailFieldFrom; i++)
				{
				p1 += StrLen(p1) + 1;
				p2 += StrLen(p2) + 1;
				}
			MailParseAddress (p1, true, name1, maxFriendlyNameLen);
			MailParseAddress (p2, true, name2, maxFriendlyNameLen);

			result = StrCaselessCompare (name1, name2);
			}
		}

//mgmg
	if (result == 0)
		{
		//sort by the read flag
		if (r2->flags.read != r1->flags.read)
			{
			if (r1->flags.read)
				result = 1;
			else
				result = -1;
			}
		}	

	return result;
}


/************************************************************
 *
 *  FUNCTION: FindSortPosition
 *
 *  DESCRIPTION: Return where a record is or should be
 *		           Useful to find or find where to insert a record.
 *
 *  PARAMETERS: database record (not deleted!)
 *
 *  RETURNS: the size in bytes
 *
 *  CREATED: 5/30/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
static UInt FindSortPosition (DmOpenRef dbP, MailPackedDBRecordPtr r)
{
	int sortOrder;
	
	sortOrder = MailGetSortOrder (dbP);
	
	return (DmFindSortPosition (dbP, r, NULL, (DmComparF *) CompareRecords, sortOrder));
}


/************************************************************
 *
 *  FUNCTION: PackedRecordSize
 *
 *  DESCRIPTION: Return the packed size of an MailDBRecordType 
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the size in bytes
 *
 *  CREATED: 5/30/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
static UInt PackedRecordSize (MailDBRecordPtr r)
{
	UInt size;
	
	size = sizeof (MailPackedDBRecordType) + 
		(mailFieldBody - mailFieldSubject);
	
	if (r->subject != NULL)
		size += StrLen (r->subject);
	
	if (r->from != NULL)
		size += StrLen (r->from);
	
	if (r->to != NULL)
		size += StrLen (r->to);
	
	if (r->cc != NULL)
		size += StrLen (r->cc);
	
	if (r->bcc != NULL)
		size += StrLen (r->bcc);
	
	if (r->replyTo != NULL)
		size += StrLen (r->replyTo);
	
	if (r->sentTo != NULL)
		size += StrLen (r->sentTo);
	
	if (r->body != NULL)
		size += StrLen (r->body);
	
	return size;
}


/************************************************************
 *
 *  FUNCTION: PackRecord
 *
 *  DESCRIPTION: Pack an MailDBRecordType
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the MailPackedDBRecord is packed
 *
 *  CREATED: 5/30/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
static void PackRecord (MailDBRecordPtr s, MailPackedDBRecordPtr d)
{
	UInt 	size;
	Char	zero = 0;
	ULong	offset = 0;
	
	
	// Write date field.
	DmWrite (d, offset, &s->date, sizeof(DateType));
	offset += sizeof (DateType);
	
	// Write time field.
	DmWrite (d, offset, &s->time, sizeof(TimeType));
	offset += sizeof (TimeType);
	
	// Write flags field.
	DmWrite (d, offset, &s->flags, sizeof(MailFlagsType));
	offset += sizeof (MailFlagsType);

	// Write subject field.
	if (s->subject != NULL)
		{
		size = StrLen (s->subject) + 1;
		DmWrite (d, offset, s->subject, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "from" field.
	if (s->from != NULL)
		{
		size = StrLen (s->from) + 1;
		DmWrite (d, offset, s->from, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "to" field.
	if (s->to != NULL)
		{
		size = StrLen (s->to) + 1;
		DmWrite (d, offset, s->to, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "cc" field.
	if (s->cc != NULL)
		{
		size = StrLen (s->cc) + 1;
		DmWrite (d, offset, s->cc, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "bcc" field.
	if (s->bcc != NULL)
		{
		size = StrLen (s->bcc) + 1;
		DmWrite (d, offset, s->bcc, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "reply to" field.
	if (s->replyTo != NULL)
		{
		size = StrLen (s->replyTo) + 1;
		DmWrite (d, offset, s->replyTo, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}
	
	// Write "sent to" field.
	if (s->sentTo != NULL)
		{
		size = StrLen (s->sentTo) + 1;
		DmWrite (d, offset, s->sentTo, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}

	// Write "body" field.
	if (s->body != NULL)
		{
		size = StrLen (s->body) + 1;
		DmWrite (d, offset, s->body, size);
		offset += size;
		}
	else
		{
		DmWrite (d, offset, &zero, 1);
		offset++;
		}	
}


/************************************************************
 *
 *  FUNCTION: MailUnpackRecord
 *
 *  DESCRIPTION: Fills in the MailDBRecord structure
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the record unpacked
 *
 *  CREATED: 5/30/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
void MailUnpackRecord (MailPackedDBRecordPtr src, MailDBRecordPtr dest)
{
	char *p;

	
	dest->date = src->date;
	dest->time = src->time;
	dest->flags = src->flags;

	p = &src->firstField;

	// Get the "subject" field.
	if (*p)
		{
		dest->subject = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->subject = p;
		p++;
		}
	
	// Get the "from" field.	
	if (*p)
		{
		dest->from = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->from = p;
		p++;
		}
	
	// Get the "to" field.	
	if (*p)
		{
		dest->to = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->to = p;
		p++;
		}
	
	// Get the "cc" field.	
	if (*p)
		{
		dest->cc = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->cc = p;
		p++;
		}
	
	// Get the "bcc" field.	
	if (*p)
		{
		dest->bcc = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->bcc = p;
		p++;
		}
	
	// Get the "reply to" field.	
	if (*p)
		{
		dest->replyTo = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->replyTo = p;
		p++;
		}
	
	// Get the "sent to" field.	
	if (*p)
		{
		dest->sentTo = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->sentTo = p;
		p++;
		}
	
	// Get the "body" field.	
	if (*p)
		{
		dest->body = p;
		p += StrLen(p) + 1;
		}
	else
		{
		dest->body = p;
		p++;
		}
}


/************************************************************
 *
 *  FUNCTION: MailLocalizeAppInfo
 *
 *  DESCRIPTION: Look for localize app info strings and copy
 *  them into the app info block.
 *
 *  PARAMETERS: application info ptr
 *
 *  RETURNS: nothing
 *
 *  CREATED: 12/13/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static void MailLocalizeAppInfo (MailAppInfoPtr appInfoP)
{
	VoidHand 		localizedAppInfoH;
	CharPtr	 		localizedAppInfoP;
	MailAppInfoPtr	nilP = 0;
	VoidHand 		stringsH;
	CharPtr			*stringsP;
	int 				i;


	localizedAppInfoH = DmGetResource (appInfoStringsRsc, mailLocalizedAppInfoStr);
	if (localizedAppInfoH)
		{
		localizedAppInfoP = MemHandleLock (localizedAppInfoH);
		stringsH = SysFormPointerArrayToStrings (localizedAppInfoP, 
			dmRecNumCategories);
		stringsP = MemHandleLock (stringsH);
		
		// Copy each category
		for (i = 0; i < dmRecNumCategories; i++)
			{
			if (stringsP[i][0] != '\0')
				DmStrCopy (appInfoP, (ULong) nilP->categoryLabels[i], stringsP[i]);
			}
		
		MemPtrFree (stringsP);
		MemPtrFree (localizedAppInfoP);
		}
}


/************************************************************
 *
 *  FUNCTION: MailAppInfoInit
 *
 *  DESCRIPTION: Create an app info chunk if missing.  Set
 *		the strings to a default.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 1/20/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err	MailAppInfoInit (DmOpenRef dbP)
{
	UInt size;
	UInt cardNo;
	UInt wordValue;
	VoidHand h;
	LocalID dbID;
	LocalID appInfoID;
	MailAppInfoPtr	nilP = 0;
	MailAppInfoPtr appInfoP;
	
	if (DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL))
		return dmErrInvalidParam;

	if (DmDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, 
		 NULL, &appInfoID, NULL, NULL, NULL))
		return dmErrInvalidParam;
	
	if (appInfoID == NULL)
		{
		// Add one for signature null-terminator.
		size = sizeof (MailAppInfoType) + 1;
		h = DmNewHandle (dbP, size);
		if (! h) return dmErrMemError;

		appInfoID = MemHandleToLocalID (h);
		DmSetDatabaseInfo(cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, 
			NULL, &appInfoID, NULL, NULL, NULL);
		}
	
	appInfoP = MemLocalIDToLockedPtr (appInfoID, cardNo);

	// Clear the app info block.
	DmSet (appInfoP, 0, size, 0);

	// Initialize the categories.
	CategoryInitialize ((AppInfoPtr) appInfoP, mailLocalizedAppInfoStr);

	// I don't know this field is used for.
	wordValue = 0xFFFF;
	DmWrite (appInfoP, (ULong)&nilP->dirtyAppInfo, &wordValue,
		sizeof(appInfoP->dirtyAppInfo));

	// Initialize the sort order.
	DmSet (appInfoP, (ULong)&nilP->sortOrder, sizeof(appInfoP->sortOrder), 
		sortByDate);

	// Initialize the field the holds the index of the last unsent message.
//	wordValue= noUnsendMessage;
//	DmWrite (appInfoP, (ULong)&nilP->unsentMessage, &wordValue,
//		sizeof(appInfoP->unsentMessage));

	// Initialize the offset of message signature.
	wordValue = sizeof (MailAppInfoType);
	DmWrite (appInfoP, (ULong)&nilP->signatureOffset, &wordValue,
		sizeof(appInfoP->signatureOffset));

	// Initialize the message signature.
	DmSet (appInfoP, appInfoP->signatureOffset, 1, 0);

	MemPtrUnlock (appInfoP);

	return 0;
}


/************************************************************
 *
 *  FUNCTION: MailGetAppInfo
 *
 *  DESCRIPTION: Get the app info chunk 
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: handle to the to do application info block (MailAppInfoType)
 *
 *  CREATED: 5/12/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
VoidHand MailGetAppInfo (DmOpenRef dbP)
{
	Err error;
	UInt cardNo;
	LocalID dbID;
	LocalID appInfoID;
	
	error = DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL);
	ErrFatalDisplayIf (error,  "Get getting app info");

	error = DmDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, &appInfoID, NULL, NULL, NULL);
	ErrFatalDisplayIf (error,  "Get getting app info");

	return ((VoidHand) MemLocalIDToGlobal (appInfoID, cardNo));
}


/************************************************************
 *
 *  FUNCTION: MailGetSortOrder
 *
 *  DESCRIPTION: This routine get the sort order value from the 
 *               mail application info block.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS:    sort order:
 *                  0 - by date
 *						  1 - by subject
 *						  2 - by form
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/30/96	Initial Revision
 *
 *************************************************************/
Byte MailGetSortOrder (DmOpenRef dbP)
{
	Byte sortOrder;
	MailAppInfoPtr appInfoP;
			
	appInfoP = MemHandleLock (MailGetAppInfo (dbP));
	sortOrder = appInfoP->sortOrder;
	MemPtrUnlock (appInfoP);	

	return (sortOrder);
}


/************************************************************
 *
 *  FUNCTION: MailChangeSortOrder
 *
 *  DESCRIPTION: Change the Mail Database's sort order
 *
 *  PARAMETERS: database pointer
 *				TRUE if sort by company
 *
 *  RETURNS: nothing
 *
 *  CREATED: 1/17/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err MailChangeSortOrder(DmOpenRef dbP, Boolean sortOrder)
{
	MailAppInfoPtr appInfoP;
	MailAppInfoPtr	nilP = 0;
	UInt				dirtyAppInfo;


	appInfoP = MemHandleLock (MailGetAppInfo (dbP));

	if (appInfoP->sortOrder != sortOrder)
		{
		dirtyAppInfo = appInfoP->dirtyAppInfo | mailSortByDirty;
		DmWrite(appInfoP, (ULong)&nilP->dirtyAppInfo, &dirtyAppInfo, sizeof(appInfoP->dirtyAppInfo)); 
		DmWrite(appInfoP, (ULong)&nilP->sortOrder, &sortOrder, sizeof(appInfoP->sortOrder));
		
		DmInsertionSort(dbP, (DmComparF *) &CompareRecords, (Int) sortOrder);
		}
		
	MemPtrUnlock (appInfoP);	

	return 0;
}


/************************************************************
 *
 *  FUNCTION: MailSort
 *
 *  DESCRIPTION: Sort the appointment database.
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: nothing
 *
 *  CREATED: 10/17/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
void MailSort (DmOpenRef dbP)
{
	int sortOrder;
	
	sortOrder = MailGetSortOrder (dbP);
	DmInsertionSort(dbP, (DmComparF *) &CompareRecords, (Int) sortOrder);
}


/***********************************************************************
 *
 * FUNCTION:    MailGetUnsentMessage
 *
 * DESCRIPTION: This routine returns the ihndex of the unsent message,
 *              if there is one.  If the application is exited while 
 *              a new message is being edited, the handle of the unsent 
 *              message is save in the application info block.  The 
 *              record is not yet attached to the database index.
 *
 * PARAMETERS:  dpP - database pointer
 *
 * RETURNED:    unique id of a packed record or -1
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/96	Initial Revision
 *
 ***********************************************************************/
ULong MailGetUnsentMessage (DmOpenRef dbP)
{
	ULong uniqueID;
	MailAppInfoPtr appInfoP;
			
	appInfoP = MemHandleLock (MailGetAppInfo (dbP));
	uniqueID = appInfoP->unsentMessage;
	MemPtrUnlock (appInfoP);	

	return (uniqueID);
}


/***********************************************************************
 *
 * FUNCTION:    MailSetUnsentMessage
 *
 * DESCRIPTION: This routine sets the index of the unsent message.
 *              If the application is exited while a new message 
 *              is being edited, the index of the unsent message 
 *              is save in the application info block.
 *
 * PARAMETERS:  dpP      - database pointer
 *					 uniqueID - unique id of a packed record or -1
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/96	Initial Revision
 *
 ***********************************************************************/
void MailSetUnsentMessage (DmOpenRef dbP, ULong uniqueID)
{
	MailAppInfoPtr	nilP = 0;
	MailAppInfoPtr appInfoP;
			
	appInfoP = MemHandleLock (MailGetAppInfo (dbP));
	DmWrite(appInfoP, (ULong)&nilP->unsentMessage, &uniqueID, 
		sizeof(appInfoP->unsentMessage));

	MemPtrUnlock (appInfoP);	
}


/***********************************************************************
 *
 * FUNCTION:    MailGetSignature
 *
 * DESCRIPTION: This routine returns a copy of the message signature 
 *              string.  This routine allocates a new handle to hold
 *              signature,  the caller is responsible for freeing this 
 *              handle.
 *              
 * PARAMETERS:  dpP - database pointer
 *
 * RETURNED:    handle of a signature or zero
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/25/96	Initial Revision
 *
 ***********************************************************************/
VoidHand MailGetSignature (DmOpenRef dbP)
{
	Word len;
	CharPtr p;
	CharPtr signatureP;
	VoidHand h = 0;
	MailAppInfoPtr appInfoP;
			
	appInfoP = MemHandleLock (MailGetAppInfo (dbP));

	signatureP = ((CharPtr)appInfoP) + appInfoP->signatureOffset;
	len = StrLen (signatureP);
	
	if (len)
		{
		h = MemHandleNew (len + 1);
		p = MemHandleLock (h);
		StrCopy (p, signatureP);
		MemPtrUnlock (p);
		}

	MemPtrUnlock (appInfoP);	

	return (h);
}


/***********************************************************************
 *
 * FUNCTION:    MailSetSignature
 *
 * DESCRIPTION: This routine save the passed signature to the 
 *              applicatiion information block.
 *
 * PARAMETERS:  dpP - database pointer
 *					 h   - handle of the signature
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/25/96	Initial Revision
 *
 ***********************************************************************/
void MailSetSignature (DmOpenRef dbP, VoidHand h)
{
	Err				err = 0;
	UInt				cardNo;
	LocalID			dbID;
	ULong				size;
	WordPtr			srcP=0;
	WordPtr			dstP=0;
	Handle			newH=0;
	CharPtr			p;
	CharPtr			signatureP;
	VoidHand			appInfoH;
	LocalID 			appInfoID;
	MailAppInfoPtr appInfoP;
			
	// Compute the new size of the app info block.
	p = MemHandleLock (h);
	appInfoH = MailGetAppInfo (dbP);
	appInfoP = MemHandleLock (appInfoH);
	signatureP = ((CharPtr)appInfoP) + appInfoP->signatureOffset;
	size = MemPtrSize (appInfoP) + StrLen (p) - StrLen (signatureP);
	MemPtrUnlock (appInfoP);
	MemPtrUnlock (p);

	// Resize the app info block
	err = MemHandleResize (appInfoH, size);

	// If we couldn't resize it, try and reallocate it in another heap
	if (err)
		{
		newH = DmNewHandle(dbP, size);
		if (!newH) return;

		srcP = (WordPtr) MemHandleLock (appInfoH);
		dstP = (WordPtr) MemHandleLock (newH);
		
//		MemMove (dstP, srcP, sizeof (MailAppInfoType));
		DmWrite (dstP, 0, srcP, sizeof (MailAppInfoType));

		MemHandleFree (appInfoH);
		MemPtrUnlock (dstP);

		MemHandleSetOwner (newH, dmRecOwnerID);

		appInfoID = MemHandleToLocalID (newH);
		DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL);
		DmSetDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, 
			NULL, &appInfoID, NULL, NULL, NULL);

		appInfoH = newH;
		err = 0;
		}
		
	// Copy the new signature.
	appInfoP = MemHandleLock (appInfoH);
	dstP = (WordPtr) (((CharPtr)appInfoP) + appInfoP->signatureOffset);
	srcP = MemHandleLock (h);
//	MemMove (dstP, srcP, StrLen ((CharPtr)srcP) + 1);
	DmWrite (appInfoP, appInfoP->signatureOffset, srcP, StrLen ((CharPtr)srcP) + 1);

	MemPtrUnlock (appInfoP);
	MemPtrUnlock (p);
}


/***********************************************************************
 *
 * FUNCTION:    MailParseAddress
 *
 * DESCRIPTION: This routine parses a mail address
 *
 * PARAMETERS:  address  - address string, ex: "art@palm (Art Lamb)"
 *              realName - if true return the name part, else return the 
 *                         address part
 *              buffer   - buffer to hold return value
 *              len      - length of buffer
 *              
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/96		Initial Revision
 *
 ***********************************************************************/
void MailParseAddress (CharPtr address, Boolean realName, CharPtr buffer,
			Word bufferLen)
{
	Char chr;
	Word len;
	CharPtr p;
	CharPtr endP;
	CharPtr startP;
	WordPtr charAttrs;

	charAttrs = GetCharAttr();

	*buffer = 0;

	if (realName)
		{
		// Get the name portion of the string passed.
		endP = StrChr (address, linefeedChr);
		if (! endP)
			endP = StrChr (address, 0);

		startP = StrChr (address, '(');

		if (startP && startP < endP)
			{
			startP++;
			len = endP - startP;
			while (endP-- > startP)
				{
				if (*endP == ')')
					{
					len = endP - startP;
					break;
					}
				}
			if (len > bufferLen - 1)
				len =  bufferLen - 1;

			p = buffer;
			while (len--)
				{
				*p++ = *startP++;
				}
			*p = 0;
			}
		}

	if (*buffer == 0)	
		{
		// Get the email address portion of the string passed.
		p = buffer;
		len =  bufferLen - 1;
		while (true)
			{
			chr = *address;
			if (IsCntrl(charAttrs, chr) || (chr == '(') || len == 0)
				{
				*p = 0;
				break;
				}
			else
				*p++ = *address++;
			len--;
			}

		// Remove trailing spaces.
		len = StrLen (buffer);
		while (len && (IsSpace (charAttrs, buffer[len-1])))
			buffer[--len] = 0;
		}		
}


/************************************************************
 *
 *  FUNCTION: MailNewRecord
 *
 *  DESCRIPTION: Create a new packed record.  The new record is 
 *
 *  PARAMETERS: database pointer
 *				    database record
 *
 *  RETURNS:    record handle or 0 if error
 *
 *  CREATED: 6/6/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
Err MailNewRecord (DmOpenRef dbP, MailDBRecordPtr r, UInt *indexP)
{
	Err err;
	Word index;
	VoidHand recordH;
	MailPackedDBRecordPtr recordP;
	
	// Make a new chunk with the correct size.
	recordH = DmNewHandle (dbP, (ULong) PackedRecordSize (r));
	if (recordH == NULL)
		return dmErrMemError;

	// Copy the data from the unpacked record to the packed one.
	recordP = MemHandleLock (recordH);
	PackRecord (r, recordP);

	// Determine the sort position of the new record.
	index = FindSortPosition (dbP, recordP);

	MemPtrUnlock (recordP);

	err = DmAttachRecord (dbP, &index, recordH, 0);
	if (err) 
		MemHandleFree (recordH);
	else
		*indexP = index;

	return (err);
}


/************************************************************
 *
 *  FUNCTION: MailAttachRecord
 *
 *  DESCRIPTION: Attach a packed record in sorted position.
 *
 *  PARAMETERS: database pointer
 *              database record handle
 *
 *  RETURNS: 0 if successful, error code if not
 *
 *  CREATED: 6/6/96
 *
 *  BY: Art Lamb
 *
 *************************************************************/
Err MailAttachRecord (DmOpenRef dbP, VoidHand recordH, WordPtr indexP)
{
	Err err;
	Word index;
	MailPackedDBRecordPtr recordP;

	recordP = MemHandleLock (recordH);

	index = FindSortPosition (dbP, recordP);

	MemPtrUnlock (recordP);

	err = DmAttachRecord (dbP, &index, recordH, 0);
	if (err) 
		MemHandleFree (recordH);
	else
		*indexP = index;
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: MailGetRecord
 *
 *  DESCRIPTION: Get a record from a Mail database
 *
 *  PARAMETERS: database pointer
 *				    database index
 *				    database record
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 5/12/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
Err MailGetRecord (DmOpenRef dbP, Word index, MailDBRecordPtr r, 
	VoidHand * handleP)
{
	VoidHand handle;
	MailPackedDBRecordPtr src;
	

	handle = DmQueryRecord(dbP, index);
	ErrFatalDisplayIf(DmGetLastErr(), "Error Querying record");
	
	src = (MailPackedDBRecordPtr) MemHandleLock (handle);

	if (DmGetLastErr())
		{
		*handleP = 0;
		return DmGetLastErr();
		}
	
	MailUnpackRecord (src, r);
	
	*handleP = handle;
	return 0;
}


/************************************************************
 *
 *  FUNCTION: MailChangeRecord
 *
 *  DESCRIPTION: Change a record in the Appointment Database
 *
 *  PARAMETERS: database pointer
 *					 database index
 *					 database record
 *					 changed fields
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 5/12/95 
 *
 *	COMMENTS:	Records are not stored with extra padding - they
 *	are always resized to their exact storage space.  This avoids
 *	a database compression issue.  The code works as follows:
 *	
 *	1)	get the size of the new record
 *	2)	make the new record
 *	3)	pack the packed record plus the changes into the new record
 *	4)	if the sort position is changes move to the new position
 *	5)	attach in position
 *
 *************************************************************/
Err MailChangeRecord (DmOpenRef dbP, WordPtr index, MailDBRecordPtr r, 
	MailChangedFieldsType changedFields)
{
	Err 							result;
	Int 							newIndex;
	UInt 							attributes;
	Boolean 						dontMove;
	VoidHand 					oldH;
	VoidHand 					srcH;
	VoidHand 					dstH;
	MailDBRecordType 			src;
	MailPackedDBRecordPtr 	dst;
	MailPackedDBRecordPtr 	cmp;
	
	// We do not assume that r is completely valid so we get a valid
	// MailDBRecordPtr...
	if ((result = MailGetRecord(dbP, *index, &src, &srcH)) != 0)
		return result;
	
	// and we apply the changes to it.
	if (changedFields.date) 
		src.date = r->date;
	
	if (changedFields.time) 
		src.time = r->time;

	if (changedFields.flags) 
		src.flags = r->flags;
	
	if (changedFields.subject)
		src.subject = r->subject;
	
	if (changedFields.from)
		src.from = r->from;
		
	if (changedFields.to)
		src.to = r->to;
		
	if (changedFields.cc)
		src.cc = r->cc;
		
	if (changedFields.bcc)
		src.bcc = r->bcc;
		
	if (changedFields.replyTo)
		src.replyTo = r->replyTo;
		
	if (changedFields.sentTo)
		src.sentTo = r->sentTo;
		
	if (changedFields.body)
		src.body = r->body;
		

	// Allocate a new chunk with the correct size and pack the data from 
	// the unpacked record into it.
	dstH = DmNewHandle(dbP, (ULong) PackedRecordSize (&src));
	if (dstH)
		{
		dst = MemHandleLock (dstH);
		PackRecord (&src, dst);
		}

	MemHandleUnlock (srcH);
	if (dstH == NULL)
		return dmErrMemError;


	// If the sort position is changed move to the new position.
	// Check if any of the key fields have changed. 
	if ((! changedFields.date) && 
	    (! changedFields.time) && 
	    (! changedFields.subject) && 
	    (! changedFields.from))
		goto attachRecord;
	
		
	// Make sure *index-1 < *index < *index+1, if so it's in sorted 
	// order.  Leave it there.	
	if (*index > 0)
		{
		// This record wasn't deleted and deleted records are at the end of the
		// database so the prior record may not be deleted!
		cmp = MemHandleLock (DmQueryRecord(dbP, *index-1));		
		dontMove = (CompareRecords (cmp, dst, 0, NULL, NULL, 0) == -1);
		MemPtrUnlock (cmp);
		}
	else 
		dontMove = true;


	if (dontMove && (*index+1 < DmNumRecords (dbP)))
		{
		DmRecordInfo(dbP, *index+1, &attributes, NULL, NULL);
		if ( ! (attributes & dmRecAttrDelete) )
			{
			cmp = MemHandleLock (DmQueryRecord(dbP, *index+1));
			dontMove &= (CompareRecords (dst, cmp, 0, NULL, NULL, 0) == -1);
			MemPtrUnlock (cmp);
			}
		}
		
	if (dontMove)
		goto attachRecord;
	
	
	// The record isn't in the right position.  Move it.
	newIndex = FindSortPosition (dbP, dst);
	DmMoveRecord (dbP, *index, newIndex);
	if (newIndex > *index) newIndex--;
	*index = newIndex;						// return new position


attachRecord:
	// Attach the new record to the old index,  the preserves the 
	// category and record id.
	result = DmAttachRecord (dbP, index, dstH, &oldH);
	
	MemPtrUnlock (dst);

	if (result) return result;

	MemHandleFree (oldH);

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    GetRecordField
 *
 * DESCRIPTION: This routine changes a field of the passed record.
 *
 * PARAMETERS:  dpP         - database pointer
 *					 recordField - fields to chance
 *              data        - new field value
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/17/96	Initial Revision
 *
 ***********************************************************************/
static VoidPtr GetRecordField (MailDBRecordPtr recordP, 
		MailRecordFieldType recordField)
{
	VoidPtr ptr;

	switch (recordField)
		{
		case mailFieldSubject:
			ptr = recordP->subject;
			break;
			
		case mailFieldFrom:
			ptr = recordP->from;
			break;
			
		case mailFieldTo:
			ptr = recordP->to;
			break;
			
		case mailFieldCC:			
			ptr = recordP->cc;
			break;
			
		case mailFieldBCC:		
			ptr = recordP->bcc;
			break;
			
		case mailFieldReplyTo:		
			ptr = recordP->replyTo;
			break;
			
		case mailFieldSentTo:		
			ptr = recordP->sentTo;
			break;
			
		case mailFieldBody:				
			ptr = recordP->body;
			break;

		default:
			ErrDisplay ("Invalid record field");
		}

	return (ptr);
}


/***********************************************************************
 *
 * FUNCTION:    MailChangeRecordField
 *
 * DESCRIPTION: This routine changes a field of the passed record.
 *
 * PARAMETERS:  dpP         - database pointer
 *					 hP          - pointer to the handle of a packed database
 *                            record. A new handle may be returned as
 *                            the result of resizing the record.
 *					 recordField - fields to chance
 *
 * RETURNED:    nothing
 *
 *	COMMENTS:   This routine does not move the modified record to to 
 *             correct sort position if one of the sort key field is
 *             modified.  This function is intented for use on 
 *             records that have not been attached to the database.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/11/96	Initial Revision
 *
 ***********************************************************************/
/*
Err MailChangeRecordField (DmOpenRef dbP, Word index, 
	MailRecordFieldType recordField, VoidPtr data)
{
	Err							err = 0;
	UInt							newSize;
	UInt							oldSize;
	VoidHand						recordH;
	MailDBRecordType 			record;
	MailPackedDBRecordPtr	r;

	
	recordH = DmQueryRecord (dbP, index);;
	r = MemHandleLock (recordH);
	MailUnpackRecord (r, &record);
	oldSize = PackedRecordSize (&record);

	ChangeRecordField (&record, recordField, data);

	newSize = PackedRecordSize (&record);

	// If the record the same size?
	if (oldSize == newSize)
		{
		PackRecord (&record, r);
		MemPtrUnlock (r);
		}
		
	// Is the record smaller?
	else if (oldSize > newSize)
		{
		PackRecord (&record, r);
		MemPtrUnlock (r);
		err = MemHandleResize (recordH, newSize);
		}

	// The record is larger.
	else
		{
		MemPtrUnlock (r);
		
		recordH = DmResizeRecord (dbP, index, newSize);
		if (! recordH) return (err);

		r = MemHandleLock (recordH);
		MailUnpackRecord (r, &record);
		ChangeRecordField (&record, recordField, data);
		PackRecord (&record, r);
		MemPtrUnlock (r);
		}

	return (err);
}
*/

/***********************************************************************
 *
 * FUNCTION:    MailInsertIntoField
 *
 * DESCRIPTION: This routine inserts the passed string into the 
 *              specified a field of the passed record.
 *
 * PARAMETERS:  dpP          - database pointer
 *					 index        - index of a packed database record
 *					 recordField  - fields to insert into
 *              insertData	  - string to insert
 *              insertLen    - length of insert string
 *              insertOffset - offset from start of field to insert at
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/17/96	Initial Revision
 *
 ***********************************************************************/
Err MailInsertIntoField (DmOpenRef dbP, Word index, 
	MailRecordFieldType recordField, CharPtr insertData, Word insertLen,
	Word insertOffset)
{
	Err							err = 0;
	UInt							newSize;
	UInt							oldSize;
	ULong							offset;
	ULong							bytes;
	CharPtr 						ptr;
	WordPtr						srcP=0, dstP=0;
	VoidHand						recordH;
	MailDBRecordType 			record;
	MailPackedDBRecordPtr	r;


	if (! insertLen) return (0);
	
	// Resize the record.
	recordH = DmQueryRecord (dbP, index);;
	oldSize = MemHandleSize (recordH);
	newSize = oldSize + insertLen;
	recordH = DmResizeRecord (dbP, index, newSize);
	if (recordH == NULL)
		return dmErrMemError;

	
	r = MemHandleLock (recordH);
	MailUnpackRecord (r, &record);

	switch (recordField)
		{
		case mailFieldSubject:
			ptr = record.subject;
			break;
			
		case mailFieldFrom:
			ptr = record.from;
			break;
			
		case mailFieldTo:
			ptr = record.to;
			break;
			
		case mailFieldCC:			
			ptr = record.cc;
			break;
			
		case mailFieldBCC:		
			ptr = record.bcc;
			break;
			
		case mailFieldReplyTo:		
			ptr = record.replyTo;
			break;
			
		case mailFieldSentTo:		
			ptr = record.sentTo;
			break;
			
		case mailFieldBody:				
			ptr = record.body;
			break;

		default:
			ErrDisplay ("Invalid record field");
		}


	// Move the rest of the record.
	ptr += insertOffset;
	offset = (ptr - (CharPtr)r) + insertLen;
	bytes = oldSize - (ULong)(ptr - (CharPtr)r);
	if (bytes)
		DmWrite (r, offset, ptr, bytes);
			
	// Write the new field.
	offset = (ptr - (CharPtr)r);
	DmWrite (r, offset, insertData, insertLen);

	MemHandleUnlock (recordH);


	return (err);
}

/************************************************************
 *
 * FUNCTION:    MailSortRecord
 *
 * DESCRIPTION: Move the passed record to its correct sort
 *              position.
 *
 * PARAMETERS:  database pointer
 *				    record index
 *
 * RETURNS:     zero if successful, errorcode if not
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/18/96	Initial Revision
 *
 *************************************************************/
Err MailSortRecord (DmOpenRef dbP, WordPtr indexP)
{
	Err err;
	Int sortOrder;
	Word index;
	Word attributes;
	ULong uniqueID;
	Handle recordH;
	Boolean dontMove;
	MailPackedDBRecordPtr cmp;
	MailPackedDBRecordPtr recordP;
	
	sortOrder = MailGetSortOrder (dbP);

	// Check if the record is already in the correct position.
	recordP = MemHandleLock (DmQueryRecord (dbP, *indexP));		
	if (*indexP > 0)
		{
		// This record wasn't deleted and deleted records are at the end of the
		// database so the prior record may not be deleted!
		cmp = MemHandleLock (DmQueryRecord (dbP, *indexP-1));		
		dontMove = (CompareRecords (cmp, recordP, sortOrder, NULL, NULL, 0) <= 0);
		MemPtrUnlock (cmp);
		}
	else 
		dontMove = true;

	if (dontMove && (*indexP+1 < DmNumRecords (dbP)))
		{
		DmRecordInfo(dbP, *indexP+1, &attributes, NULL, NULL);
		if ( ! (attributes & dmRecAttrDelete) )
			{
			cmp = MemHandleLock (DmQueryRecord (dbP, *indexP+1));
			dontMove &= (CompareRecords (recordP, cmp, sortOrder, NULL, NULL, 0) <= 0);
			MemPtrUnlock (cmp);
			}
		}
	MemPtrUnlock (recordP);

	if (dontMove) return (0);


	// Since the routine that determines the records sort position uses a 
	// binary search algorythm we need to remove the record from the database 
	// before we can determine its new position.  We will also save and restore the 
	// record's attributes and unique ID.
	DmRecordInfo (dbP, *indexP, &attributes, &uniqueID, NULL);

	err = DmDetachRecord (dbP, *indexP, &recordH);
	if (err) return (err);
	
	recordP = MemHandleLock (recordH);		
	index = DmFindSortPosition (dbP, recordP, NULL, (DmComparF *) CompareRecords, sortOrder);
	MemPtrUnlock (recordP);
	
	err = DmAttachRecord (dbP, &index, recordH, 0);
	if (err) return (err);

	DmSetRecordInfo (dbP, index, &attributes, &uniqueID);	

	*indexP = index;
	
	return (err);
}


/***********************************************************************
 *
 * FUNCTION:    MailChangeRecordField
 *
 * DESCRIPTION: This routine changes a field of the passed record.
 *
 * PARAMETERS:  dpP         - database pointer
 *					 hP          - pointer to the handle of a packed database
 *                            record. A new handle may be returned as
 *                            the result of resizing the record.
 *					 recordField - fields to chance
 *
 * RETURNED:    nothing
 *
 *	COMMENTS:   This routine does not move the modified record to to 
 *             correct sort position if one of the sort key field is
 *             modified.  This function is intented for use on 
 *             records that have not been attached to the database.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/17/96	Initial Revision
 *
 ***********************************************************************/
Err MailChangeRecordField (DmOpenRef dbP, WordPtr indexP, 
	MailRecordFieldType recordField, VoidPtr data)
{
	Err							err = 0;
	UInt							newSize;
	UInt							curSize;
	ULong							offset;
	ULong							bytes;
	CharPtr 						ptr;
	CharPtr						fieldP;
	VoidHand						recordH;
	MailDBRecordType 			record;
	MailPackedDBRecordPtr	r;
	MailPackedDBRecordPtr 	nilP = 0;
	
	// Get the record which we are going to change
	recordH = DmQueryRecord (dbP, *indexP);;
	r = MemHandleLock (recordH);
	

	// We handle the fixed size fields here.
	switch (recordField)
		{
		case mailFieldDate:
			DmWrite (r, (ULong)&nilP->date, data, sizeof(r->date));
			goto sort;
			
		case mailFieldTime:
			DmWrite (r, (ULong)&nilP->time, data, sizeof(r->time));
			goto sort;
			
		case mailFieldFlags:
			DmWrite (r, (ULong)&nilP->flags, data, sizeof(r->flags));
			goto sort;
		}



	// Calculate the size of the changed record
	MailUnpackRecord (r, &record);
	fieldP = GetRecordField (&record, recordField);
	curSize = MemPtrSize (r);
	newSize = curSize + StrLen (data) - StrLen (fieldP);


	// If the new record is longer, expand the record.
	if (newSize > curSize)
		{
		MemPtrUnlock (r);

		recordH = DmResizeRecord (dbP, *indexP, newSize);
		if (! recordH) return (dmErrMemError);

		r = MemHandleLock (recordH);
		MailUnpackRecord (r, &record);
		}


	// Change the record field. First Move the rest of the record.
	fieldP = GetRecordField (&record, recordField);
	offset = (fieldP - (CharPtr)r) + StrLen (data) + 1;
	ptr = fieldP + StrLen (fieldP) + 1;
	bytes = curSize - (ULong)(ptr - (CharPtr)r);
	if (bytes)
		DmWrite (r, offset, ptr, bytes);
			
	// Write the new field.
	offset = (fieldP - (CharPtr)r);
	DmStrCopy (r, offset, data);
	

	// If the new record is shorter, shrink the record.
	if (newSize < curSize)
		MemPtrResize (r, newSize);


sort:
	MemPtrUnlock (r);


	// If the sort position is changed move to the new position.
	// Check if any of the key fields have changed. 
	switch (recordField)
		{
		case mailFieldDate:
		case mailFieldTime:
		case mailFieldSubject:
		case mailFieldFrom:
			err = MailSortRecord (dbP, indexP);
		}


	return err;
}



