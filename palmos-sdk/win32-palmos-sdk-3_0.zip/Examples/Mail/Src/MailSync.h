/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot 2.0
 *
 * FILE:     MailSync.h
 *
 * AUTHOR:	 Art Lamb: July 26, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This file defines the structures and functions of the Mail Sync 
 *   options.
 *
 ***********************************************************************/



// The mail sync options are stored in the following format.
//		SyncFilterType
//		To filter		- null terminated string
//		From filter		- null terminated string
//		Subject filter	- null terminated string

//mgmg added syncUnread for unreadOnly Sync feature
typedef enum { syncAll, syncSendOnly, syncFilter, syncUnread } MailSyncType;
//typedef enum { syncAll, syncSendOnly, syncFilter } MailSyncType;

typedef enum { ingoreContaining, retrieveContaining } MailFilterType;


typedef struct {

	MailSyncType	syncType;				// all, send only, filter

	Boolean			retrieveHighPriority;// If true then high priority messages are
													// always retrieved.

	MailFilterType	messageContaing;		// If true then messages containing the "to",
													// "from" and "subject" are retrived.  If false
													// then messages containing the "to", "from" and
													//  "subject" are ignored.

	Word				maxLength;				// The length that retrieved message should be 
													// truncated to.
} SyncPreferencesType;

typedef SyncPreferencesType * SyncPreferencesPtr;




// This structure is used to save the current HotSync options ui settings
// before we go the the Edit View to edit the to, from or subject filters.  
// The HotSync Options dialog is dismiss when we edit the filter so we need
// to save the UI state.
typedef struct {

	Boolean			local;					// true of local, false for remote

	Byte				syncType;				// index of selected sync type push button
													// (all, send only, filter).

	Boolean			retrieveHighPriority;// If true then high priority messages are
													// always retrieved.

	MailFilterType	messageContaing;		// If true then messages containing the "to",
													// "from" and "subject" are retrived.  If false
													// then messages containing the "to", "from" and
													//  "subject" are ignored.

	Word				maxLength;				// The length that retrieved message should be 
													// truncated to.

	VoidHand			to;
	
	VoidHand			from;

	VoidHand			subject;

} SyncUIStateType;

typedef SyncUIStateType * SyncUIStatePtr;


extern Boolean SyncHandleEvent (EventPtr event);
