/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Elloit
 * FILE:     MailSync.c
 * AUTHOR:	 Art Lamb: July 29, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  The file contains routines the manage the Mail application's 
 *   HotSync options.
 *
 **********************************************************************/

#include <Pilot.h>

#include "Mail.h"

/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/

#define localHotSyncItem			0
#define remoteHotSyncItem			1

static void SyncApply (void);
static void SyncChangeSyncType (Word controlID);
static VoidHand SyncSaveUIState (Boolean local);
static void SyncSavePreferences (Boolean local);
static void SyncLoadPreferences (Boolean local);
static void SyncInitFilter (Word fieldID, CharPtr filter, Word len);
static void SyncInit (void);
static void SyncRestoreUIState (VoidHand stateH);



/***********************************************************************
 *
 * FUNCTION:    ShowObject
 *
 * DESCRIPTION: This routine set an object usable and draws the object if
 *              the form it is in is visible.
 *
 * PARAMETERS:  frm      - pointer to a form
 *              objectID - id of the object to set usable
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void ShowObject (FormPtr frm, Word objectID)
{
	FrmShowObject (frm, FrmGetObjectIndex (frm, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    HideObject
 *
 * DESCRIPTION: This routine set an object not-usable and erases it
 *              if the form it is in is visible.
 *
 * PARAMETERS:  frm      - pointer to a form
 *              objectID - id of the object to set not usable
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void HideObject (FormPtr frm, Word objectID)
{
	FrmHideObject (frm, FrmGetObjectIndex (frm, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    SyncInitFilter
 *
 * DESCRIPTION: This routine initialize the text value of the specified
 *              filter field with the string passed.
 *
 * PARAMETERS:  fieldID  id of field to initialize
 *              filter   filter string
 *              len      length of the filter string
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/1/96	Initial Revision
 *
 ***********************************************************************/
static void SyncInitFilter (Word fieldID, CharPtr filter, Word len)
{
	VoidHand h;
	CharPtr p;
	FieldPtr fld;

	fld = GetObjectPtr (fieldID);
	FldFreeMemory (fld);

	if (len)
		{
		// Copy the filter string into a new handle.
		h = MemHandleNew (len+1);
		p = MemHandleLock (h);
		StrCopy (p, filter);
		MemPtrUnlock (p);

		FldSetTextHandle (fld, h);
		}

	if (FrmVisible(FrmGetActiveForm ()))
		FldDrawField (fld);
}


/***********************************************************************
 *
 * FUNCTION:    SyncChangeSyncType
 *
 * DESCRIPTION: This routine changes the ui gadgets in the Sync Options
 *              Dialog Box such that they match the newly selected sync
 *              type.  The routine is called when one of the sync type 
 *              push buttons are pushed.
 *
 * PARAMETERS:  controlID - id of the newly selected sync type push button
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art		7/30/96	Initial Revision
 *			MGolden	7/7/97	added syncUnread option
 *
 ***********************************************************************/
static void SyncChangeSyncType (Word controlID)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm ();

	switch (controlID)
		{
		case SyncAllPushButton:
			HideObject (frm, SyncSendOnlyLabel);
			HideObject (frm, SyncRetrieveAllCheckbox);
			HideObject (frm, SyncMessageContaingTrigger);
			HideObject (frm, SyncToButton);
			HideObject (frm, SyncToField);
			HideObject (frm, SyncFromButton);
			HideObject (frm, SyncFromField);
			HideObject (frm, SyncSubjectButton);
			HideObject (frm, SyncSubjectField);
//mgmg added for syncUnread
			HideObject(frm, SyncUnreadLabel);

			ShowObject (frm, SyncAllLabel);
			break;

		
		case SyncSendOnlyPushButton:
			HideObject (frm, SyncAllLabel);
			HideObject (frm, SyncRetrieveAllCheckbox);
			HideObject (frm, SyncMessageContaingTrigger);
			HideObject (frm, SyncToButton);
			HideObject (frm, SyncToField);
			HideObject (frm, SyncFromButton);
			HideObject (frm, SyncFromField);
			HideObject (frm, SyncSubjectButton);
			HideObject (frm, SyncSubjectField);
//mgmg added for syncUnread
			HideObject(frm, SyncUnreadLabel);

			ShowObject (frm, SyncSendOnlyLabel);
			break;


		case SyncFilterPushButton:			
			HideObject (frm, SyncAllLabel);
			HideObject (frm, SyncSendOnlyLabel);
//mgmg added for syncUnread
			HideObject(frm, SyncUnreadLabel);

			ShowObject (frm, SyncRetrieveAllCheckbox);
			ShowObject (frm, SyncMessageContaingTrigger);
			ShowObject (frm, SyncToButton);
			ShowObject (frm, SyncToField);
			ShowObject (frm, SyncFromButton);
			ShowObject (frm, SyncFromField);
			ShowObject (frm, SyncSubjectButton);
			ShowObject (frm, SyncSubjectField);
			break;

//mgmg added for syncUnread
		case SyncUnreadPushButton:
			HideObject (frm, SyncAllLabel);
			HideObject (frm, SyncSendOnlyLabel);
			HideObject (frm, SyncRetrieveAllCheckbox);
			HideObject (frm, SyncMessageContaingTrigger);
			HideObject (frm, SyncToButton);
			HideObject (frm, SyncToField);
			HideObject (frm, SyncFromButton);
			HideObject (frm, SyncFromField);
			HideObject (frm, SyncSubjectButton);
			HideObject (frm, SyncSubjectField);
//mgmg added for syncUnread
			ShowObject(frm, SyncUnreadLabel);
			break;
		}
}


/***********************************************************************
 *
 * FUNCTION:    SyncSaveUIState
 *
 * DESCRIPTION: This routine save the current ui settings. It is call
 *              before go the the Edit View to edit the to, from or 
 *              subject filters.  We will dismiss the HotSync Options 
 *              dialog so we need to save the UI state.
 *
 * PARAMETERS:  local - true for local sync preferences, false for 
 *                      remote sync preferences.
 *
 * RETURNED:    handle of SyncUIStateType structure
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/20/96	Initial Revision
 *
 ***********************************************************************/
static VoidHand SyncSaveUIState (Boolean local)
{
	FormPtr frm;
	ListPtr lst;
	FieldPtr fld;
	ControlPtr ctl;
	VoidHand stateH;
	SyncUIStatePtr	stateP;


	frm = FrmGetActiveForm ();

	// Allocate a handle to hold the UI state.
	stateH = MemHandleNew (sizeof (SyncUIStateType));
	if (! stateH) return (NULL);
	stateP = MemHandleLock (stateH);

	// Local or remote HotSync options?
	stateP->local = local;

	// Get the sync type (all, send only, or filter or Unread).
	stateP->syncType = FrmGetControlGroupSelection (frm, SyncTypeGroup);

	// Get the "Retrieve All High Priority" checkbox setting.
	ctl = GetObjectPtr (SyncRetrieveAllCheckbox);
	stateP->retrieveHighPriority = (CtlGetValue (ctl) == true);

	// Get the "Ignore / Retrive Messages Containing" setting.
	lst = GetObjectPtr (SyncMessageContaingList);
	stateP->messageContaing = (MailFilterType) LstGetSelection (lst);

	// Get length that retrieved message should be truncated to.
	stateP->maxLength = TruncateLen;

	// Get the to, from and subject filters.
	fld = GetObjectPtr (SyncToField);
	stateP->to = FldGetTextHandle (fld);
	FldSetTextHandle (fld, 0);

	fld = GetObjectPtr (SyncFromField);
	stateP->from = FldGetTextHandle (fld);
	FldSetTextHandle (fld, 0);

	fld = GetObjectPtr (SyncSubjectField);
	stateP->subject = FldGetTextHandle (fld);
	FldSetTextHandle (fld, 0);

	MemHandleUnlock (stateH);
	
	return (stateH);
}


/***********************************************************************
 *
 * FUNCTION:    SyncRestoreUIState
 *
 * DESCRIPTION: This routine restores the ui settings of the HotSync 
 *              options dialog.  It is call after we return from
 *              editing the to, from or subject filters, in the Edit
 *              View.  We dismissed the HotSync Options before going
 *              to the Edit View  so we need to restore the UI state.
 *
 * PARAMETERS:  handle of SyncUIStateType structure
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/20/96	Initial Revision
 *
 ***********************************************************************/

static void SyncRestoreUIState (VoidHand stateH)
{
	Word item;
	Word controlID;
	CharPtr label;
	ListPtr lst;
	FormPtr frm;
	ControlPtr ctl;
	SyncUIStatePtr	stateP;


	frm = FrmGetActiveForm ();

	stateP = MemHandleLock (stateH);

	// Set the local / remote settings trigger.
	ctl = GetObjectPtr (SyncSettingsTrigger);
	lst = GetObjectPtr (SyncSettingsList);
	if (stateP->local)
		item = localHotSyncItem;
	else
		item = remoteHotSyncItem;
	label = LstGetSelectionText (lst, item);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, item);


	// Set the Sync tye (All, Send Only, or Filter) push button.
	controlID = FrmGetObjectId (frm, stateP->syncType);
	FrmSetControlGroupSelection (frm, SyncTypeGroup, controlID);

	// Enable / Disable the proper ui gadgets.
	SyncChangeSyncType (controlID);

	// Set the "Retrieve All High Priority" checkbox.
	ctl = GetObjectPtr (SyncRetrieveAllCheckbox);
	CtlSetValue (ctl, (stateP->retrieveHighPriority == true));

	
	// Set the "Ignore / Retrive Messages Containing" trigger and poup
	// list.
	ctl = GetObjectPtr (SyncMessageContaingTrigger);
	lst = GetObjectPtr (SyncMessageContaingList);
	label = LstGetSelectionText (lst, stateP->messageContaing);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, stateP->messageContaing);
	
	// Set length that retrieved message should be truncated to.
	TruncateLen = stateP->maxLength;

	// Set the to, from and subject filters.
	FldSetTextHandle (GetObjectPtr (SyncToField), stateP->to);
	FldSetTextHandle (GetObjectPtr (SyncFromField), stateP->from);
	FldSetTextHandle (GetObjectPtr (SyncSubjectField), stateP->subject);
		
	MemPtrFree (stateP);
}


/***********************************************************************
 *
 * FUNCTION:    SyncLoadPreferences
 *
 * DESCRIPTION: This routine load the specified HotSync preferences 
 *              (local or remote) and initial the dialog's ui.
 *
 * PARAMETERS:  local - true for local sync preferences, false for 
 *                      remote sync preferences.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/30/96	Initial Revision
 * 			MGolden	7/7/97	added syncUnread option
 *
 ***********************************************************************/
static void SyncLoadPreferences (Boolean local)
{
	Word len;
	Word rscID;
	Word prefsSize;
	Word controlID;
	SWord version;
	CharPtr label;
	CharPtr filter;
	ListPtr lst;
	FormPtr frm;
	ControlPtr ctl;
	SyncPreferencesType prefs;
	SyncPreferencesPtr  prefsP;

	frm = FrmGetActiveForm ();

	if (local)
		rscID = mailLocalSyncPrefID;
	else
		rscID = mailRemoteSyncPrefID;
		

	// Get the HotSync preferences.
	prefsSize = sizeof (SyncPreferencesType);
	version = PrefGetAppPreferences (sysFileCMail, rscID, &prefs, &prefsSize, true);
	if (version == noPreferenceFound)
		{
		controlID = SyncAllPushButton;
		prefs.retrieveHighPriority = true;
		prefs.messageContaing = ingoreContaining;

		TruncateLen = syncDefaultMaxMsgLen;
		}

	else 
		{
//mgmg syncUnread
		switch (prefs.syncType)
			{
			case syncAll:
				controlID = SyncAllPushButton;
				break;
				
			case syncSendOnly:
				controlID = SyncSendOnlyPushButton;
				break;

			case syncFilter:
				controlID = SyncFilterPushButton;
				break;

			case syncUnread:
				controlID = SyncUnreadPushButton;
				break;
			
			default:
				//just in case...set it to all
				controlID = SyncAllPushButton;
				break;
			}//switch
/* old
		if (prefs.syncType == syncAll)
			{
			controlID = SyncAllPushButton;
			}
			
		else if (prefs.syncType == syncSendOnly)
			{
			controlID = SyncSendOnlyPushButton;
			}
	
		else
			{
			controlID = SyncFilterPushButton;
			}
*/

		TruncateLen = prefs.maxLength;
		}


	// Set the Sync tye (All, Send Only, or Filter) push button.
	FrmSetControlGroupSelection (frm, SyncTypeGroup, controlID);


	// Enable / Disable the proper ui gadgets.
	SyncChangeSyncType (controlID);

	// Set the "Retrieve All High Priority" checkbox.
	ctl = GetObjectPtr (SyncRetrieveAllCheckbox);
	CtlSetValue (ctl, (prefs.retrieveHighPriority == true));

	
	// Set the "Ignore / Retrive Messages Containing" trigger and poup
	// list.
	ctl = GetObjectPtr (SyncMessageContaingTrigger);
	lst = GetObjectPtr (SyncMessageContaingList);
	label = LstGetSelectionText (lst, prefs.messageContaing);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, prefs.messageContaing);
	

	// Get the rest of the preferences, the filter strings are at the 
	// of the preferences.
	if (version != noPreferenceFound)
		{
		prefsP = MemPtrNew (prefsSize);
		if (! prefsP) return;
		
		PrefGetAppPreferences (sysFileCMail, rscID, prefsP, &prefsSize, true);

		filter = ((CharPtr)prefsP) + sizeof (SyncPreferencesType);
		len = StrLen (filter);
		SyncInitFilter (SyncToField, filter, len);
		
		filter += len + 1;
		len = StrLen (filter);
		SyncInitFilter (SyncFromField, filter, len);
		
		filter += len + 1;
		len = StrLen (filter);
		SyncInitFilter (SyncSubjectField, filter, len);
		
		MemPtrFree (prefsP);
		}

	else
		{
		SyncInitFilter (SyncToField, NULL, 0);
		SyncInitFilter (SyncFromField, NULL, 0);
		SyncInitFilter (SyncSubjectField, NULL, 0);
		}
}


/***********************************************************************
 *
 * FUNCTION:    SyncSavePreferences
 *
 * DESCRIPTION: This routine save the specified HotSync preferences 
 *              (local or remote) based on the dialog's ui settings
 *
 * PARAMETERS:  local - true for local sync preferences, false for 
 *                      remote sync preferences.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/1/96	Initial Revision
 * 			MGolden	7/7/97	added syncUnread option
 *
 ***********************************************************************/
static void SyncSavePreferences (Boolean local)
{
	Word prefID;
	Word prefsSize;
	Word controlID;
	CharPtr ptr;
	CharPtr filter;
	FormPtr frm;
	ListPtr lst;
	FieldPtr toFld;
	FieldPtr fromFld;
	FieldPtr subjectFld;
	ControlPtr ctl;
	SyncPreferencesPtr  prefsP;


	// Local or remote HotSync options?
	if (local)
		prefID = mailLocalSyncPrefID;
	else
		prefID = mailRemoteSyncPrefID;


	// Allocate a handle to hold the preferences.
	toFld = GetObjectPtr (SyncToField);
	fromFld = GetObjectPtr (SyncFromField);
	subjectFld = GetObjectPtr (SyncSubjectField);
		
	prefsSize = sizeof (SyncPreferencesType) + 
					FldGetTextLength (toFld) + 
					FldGetTextLength (fromFld) + 
					FldGetTextLength (subjectFld) + 3;
	
	prefsP = MemPtrNew (prefsSize);
	if (! prefsP) return;


	// Get the sync type (all, send only, or filter).
	frm = FrmGetActiveForm ();
	controlID = FrmGetObjectId (frm, 
		FrmGetControlGroupSelection (frm, SyncTypeGroup));
//new syncUnread
	switch(	controlID )
		{
		case SyncAllPushButton:
			prefsP->syncType = syncAll;		
			break;
		
		case SyncSendOnlyPushButton:
			prefsP->syncType = syncSendOnly;
			break;
		
		case SyncFilterPushButton:
			prefsP->syncType = syncFilter;
			break;
		
		case SyncUnreadPushButton:
			prefsP->syncType = syncUnread;
			break;
		
		default:
			//just in case...set it to all...
			prefsP->syncType = syncAll;		
			break;
				
		}//switch
/* old
	if (controlID == SyncAllPushButton)
		prefsP->syncType = syncAll;		
	else if (controlID == SyncSendOnlyPushButton)
		prefsP->syncType = syncSendOnly;
	else
		prefsP->syncType = syncFilter;
*/

	// Get the "Retrieve All High Priority" checkbox setting.
	ctl = GetObjectPtr (SyncRetrieveAllCheckbox);
	prefsP->retrieveHighPriority = (CtlGetValue (ctl) == true);


	// Get the "Ignore / Retrive Messages Containing" setting.
	lst = GetObjectPtr (SyncMessageContaingList);
	prefsP->messageContaing = (MailFilterType) LstGetSelection (lst);


	prefsP->maxLength = TruncateLen;


	// Copy the filter strings to the end of the preferences.
	filter = ((CharPtr)prefsP) + sizeof (SyncPreferencesType);
	ptr = FldGetTextPtr (toFld);
	if (ptr)
		{
		StrCopy (filter, ptr);
		filter += StrLen(ptr) + 1;
		}
	else
		{
		*filter = 0;
		filter++;
		}

	ptr = FldGetTextPtr (fromFld);
	if (ptr)
		{
		StrCopy (filter, ptr);
		filter += StrLen(ptr) + 1;
		}
	else
		{
		*filter = 0;
		filter++;
		}


	ptr = FldGetTextPtr (subjectFld);
	if (ptr)
		{
		StrCopy (filter, ptr);
		}
	else
		{
		*filter = 0;
		}
		
	
	// Save the preferences.
	PrefSetAppPreferences (sysFileCMail, prefID, mailVersionNum, prefsP, prefsSize, true);

	MemPtrFree (prefsP);
}


/***********************************************************************
 *
 * FUNCTION:    SyncApply
 *
 * DESCRIPTION: This routine applies the changes made in the Sync
 *              Option Dialog.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/30/96	Initial Revision
 *
 ***********************************************************************/
static void SyncApply (void)
{
	ListPtr lst;

	// Local or remote HotSync options?
	lst = GetObjectPtr (SyncSettingsList);
	SyncSavePreferences (LstGetSelection (lst) == localHotSyncItem);
}


/***********************************************************************
 *
 * FUNCTION:    SyncInit
 *
 * DESCRIPTION: This routine initializes the Sync Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/29/96	Initial Revision
 *
 ***********************************************************************/
static void SyncInit (void)
{
	CharPtr label;
	ListPtr lst;
	FormPtr frm;
	ControlPtr ctl;

	frm = FrmGetActiveForm ();

	// Set the local / remote settings trigger.
	ctl = GetObjectPtr (SyncSettingsTrigger);
	lst = GetObjectPtr (SyncSettingsList);
	label = LstGetSelectionText (lst, localHotSyncItem);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, localHotSyncItem);


	// Get the local HotSync preferences and initial the dialog's ui.
	SyncLoadPreferences (true);
}



/***********************************************************************
 *
 * FUNCTION:    SyncHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Sync
 *              Options Dialog Box".
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/29/96	Initial Revision
 * 			MGolden	7/7/97	added syncUnread option
 *
 ***********************************************************************/
Boolean SyncHandleEvent (EventPtr event)
{
	Word controlID;
	FormPtr frm;
	Boolean local;
	Boolean handled = false;

	if (event->eType == ctlSelectEvent)
		{
		controlID = event->data.ctlSelect.controlID;
		if (controlID == SyncOkButton)
			{
				SyncApply ();
				FrmReturnToForm (0);
				handled = true;
			}
		else if (controlID == SyncCancelButton)
			{
				FrmReturnToForm (0);
				handled = true;
			}
		else if (controlID == SyncTruncateButton)
			{
				FrmPopupForm (TruncateDialog);
			}
		else if ( (controlID == SyncAllPushButton) 		||
					 (controlID == SyncSendOnlyPushButton) 	||
					 (controlID == SyncFilterPushButton)   	||
					 (controlID == SyncUnreadPushButton))
			{
			SyncChangeSyncType (event->data.ctlSelect.controlID);
			}

		else if ( (controlID == SyncToButton) 		||
					 (controlID == SyncFromButton) 	||
					 (controlID == SyncSubjectButton))
			{
				if (controlID == SyncToButton)
					EditViewField = editToField;
				else if (controlID ==  SyncFromButton)
					EditViewField = editFromField;
				else
					EditViewField = editSubjectField;

				EditViewEditRecord = false;
				local = (LstGetSelection (GetObjectPtr (SyncSettingsList)) == localHotSyncItem);
				SyncUIStateH = SyncSaveUIState (local);
				FrmGotoForm (EditView);
			}

#ifdef USE_SWITCH_STATEMENT
		switch (controlID)
			{
			case SyncOkButton:
				SyncApply ();
				FrmReturnToForm (0);
				handled = true;
				break;

			case SyncCancelButton:
				FrmReturnToForm (0);
				handled = true;
				break;

			case SyncTruncateButton:
				FrmPopupForm (TruncateDialog);
				break;

			case SyncAllPushButton:
			case SyncSendOnlyPushButton:
			case SyncFilterPushButton:			

//mgmg syncUnread
			case SyncUnreadPushButton:			
				SyncChangeSyncType (event->data.ctlSelect.controlID);
				break;

			case SyncToButton:
			case SyncFromButton:
			case SyncSubjectButton:
				if (controlID == SyncToButton)
					EditViewField = editToField;
				else if (controlID ==  SyncFromButton)
					EditViewField = editFromField;
				else
					EditViewField = editSubjectField;

				EditViewEditRecord = false;
				local = (LstGetSelection (GetObjectPtr (SyncSettingsList)) == localHotSyncItem);
				SyncUIStateH = SyncSaveUIState (local);
				FrmGotoForm (EditView);
				break;
			}
#endif
		}


	else if (event->eType == popSelectEvent)
		{
		if (event->data.popSelect.controlID == SyncSettingsTrigger &&
			 event->data.popSelect.selection != event->data.popSelect.priorSelection)
			{
			local = event->data.popSelect.selection == localHotSyncItem;
			SyncSavePreferences (! local);
			SyncLoadPreferences (local);
			}
		}


	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		if ( ! SyncUIStateH)
			SyncInit ();
		else
			{
			SyncRestoreUIState (SyncUIStateH);
			SyncUIStateH = 0;
			}
		FrmDrawForm (frm);
		handled = true;
		}

	return (handled);
}
