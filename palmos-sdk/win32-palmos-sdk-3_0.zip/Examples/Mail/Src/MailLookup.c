/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Elloit
 * FILE:     MailLookup.c
 * AUTHOR:	 Art Lamb: June 26, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This is the Mail application's main module.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>

#include "Mail.h"


/***********************************************************************
 *
 *	Internal Structutes
 *
 ***********************************************************************/


/***********************************************************************
 *
 * FUNCTION:    CallAddressApp
 *
 * DESCRIPTION: This routine sends the Address application a launch 
 *              code to lookup an email address
 *
 * PARAMETERS:  key - key to search for
 *
 * RETURNED:    handle of string return by address application.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/26/96	Initial Revision
 *
 ***********************************************************************/
static VoidHand CallAddressApp (CharPtr keyP)
{
	Err						err = 0;
	UInt						titleStrID;
	AddrLookupParamsType	params;


	// parameters for the lookup
	switch (EditViewField)
		{
		case editToField:		titleStrID = mailToLookupTitleStrID;		break;
		case editFromField:	titleStrID = mailFromLookupTitleStrID;		break;
		case editCCField:		titleStrID = mailCCLookupTitleStrID;		break;
		case editBCCField:	titleStrID = mailBCCLookupTitleStrID;		break;
		}

	params.title = MemHandleLock (DmGetResource (strRsc, titleStrID));

	params.pasteButtonText = MemHandleLock (DmGetResource (strRsc, 
							mailLookupAddStrID));

	params.formatStringP = MemHandleLock (DmGetResource (strRsc, 
							mailLookupFormatStrID));

	params.field1 = addrLookupSortField;
	params.field2 = addrLookupEmail;
	params.field2Optional = false;

	if (keyP)
		{
		MemSet(params.lookupString, addrLookupStringLength, 0);	
		StrNCopy(params.lookupString, keyP, addrLookupStringLength - 1);
		}
	else
		*params.lookupString = 0;
			

#if EMULATION_LEVEL == EMULATION_NONE
	{
	UInt						cardNo;
	DWord						result;
	LocalID					dbID;
	DmSearchStateType		searchState;

	// Get the card number and database id of the Address application.
	err = DmGetNextDatabaseByTypeCreator (true, &searchState, 
		sysFileTApplication, sysFileCAddress, true, &cardNo, &dbID);
	ErrFatalDisplayIf(err, "Address app not found");
	if (! err)
		{
	// <RM> 1-19-98, Fixed to pass 0 for flags, instead of sysAppLaunchFlagSubCall
	//  The sysAppLaunchFlagSubCall flag is for internal use by SysAppLaunch only
	//  and should NOT be set  on entry.
		err = SysAppLaunch (cardNo, dbID, 0,
				sysAppLaunchCmdLookup, (Ptr)&params, &result);
		ErrFatalDisplayIf(err, "Error sending lookup action to app");
		}
	}

#else
	{
	CharPtr p;
	CharPtr str = ", #LOOKUP#";
	
	params.resultStringH = MemHandleNew (StrLen(str) + 1);
	p = MemHandleLock (params.resultStringH);
	StrCopy (p, str);
	MemPtrUnlock (p);
	}

#endif


	MemPtrUnlock (params.title);
	MemPtrUnlock (params.pasteButtonText);
	MemPtrUnlock (params.formatStringP);

	if (err) return (0);
	
	return (params.resultStringH);
}


/***********************************************************************
 *
 * FUNCTION:    AddressLookup
 *
 * DESCRIPTION: This routine initializes a row of the "Edit View" table.
 *
 * PARAMETERS:  fld - 
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/26/96	Initial Revision
 *
 ***********************************************************************/
void AddressLookup (FieldPtr fld)
{
	Word		len;
	Word		pos;
	Word		end;
	Word		start;
	Word		resultLen;
	WordPtr	charAttrs;
	CharPtr	keyP;
	CharPtr	text;
	CharPtr	resultP;
	VoidHand	keyH;
	VoidHand	resultH;
	Boolean	isSelection = true;


	// If there is a selection then use it as the key.
	text = FldGetTextPtr (fld);
	FldGetSelection (fld, &start, &end);
	if (start == end)
		{
		isSelection = false;
		pos = FldGetInsPtPosition (fld);
		if (text && pos)
			{
			charAttrs = GetCharAttr ();

			// Find the start of the key value. Search backwards from the 
			// insertion point position for a delimiter.
			start = pos;
			end = start;
			while (start && ! 
					 (IsSpace(charAttrs, text[start-1]) || 
				 	  IsPunct(charAttrs, text[start-1])))
				start--;

			// If there are characters between the insertion point and the 
			// delimiter or start of the field if there are no deleimiter,
			// then find the end of the key.
			if (start != pos - 1)
				{
				len = FldGetTextLength (fld);
				while (end < len && ! 
						 (IsSpace(charAttrs, text[end]) || 
						  IsPunct(charAttrs, text[end])))
					end++;
				}
			}
		}

	// Copy the key value for the string.
	if (start != end)
		{
		keyH = MemHandleNew (end - start + 1);
		keyP = MemHandleLock (keyH);
		MemMove (keyP, &text[start], end - start);
		keyP[end - start] = 0;
		}
	else
		keyP = NULL;


	resultH = CallAddressApp (keyP);
	if (keyP) MemPtrFree (keyP);

	// Replace the key string with the value returned by the Address 
	//application.
	if (resultH)
		{
		resultP = MemHandleLock (resultH);
		resultLen = StrLen(resultP);


		// Remove the comma and space delimiter, that are at the start of the 
		// string,  if there is already a comma,
		text = FldGetTextPtr (fld);
		pos = start;

		while (pos && text[pos-1] == spaceChr)
			pos--;
		if ((!pos) || text[pos-1] == commaChr || text[pos-1] == linefeedChr)
			{
			resultLen -= 2;
			MemMove (resultP, resultP+2, resultLen+1);
			}


		// I we can paste the result into the field through the clipboard so that
		// change can be undone with to "undo" command.
		if (resultLen <= cbdMaxTextLength)
			{
			ClipboardAddItem (clipboardText, resultP, resultLen);
			if (! isSelection)
				FldSetSelection (fld, start, end);
			FldPaste (fld);
			}
		else
			{
			if (start != end)
				FldDelete (fld, start, end);
			FldInsert (fld, resultP, resultLen);
			}
		}
}