/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Elloit
 * FILE:     MailTruncate.c
 * AUTHOR:	 Art Lamb: Aug 1, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  The file contains routines the manage the Mail application's 
 *   HotSync truncation options.
 *
 **********************************************************************/

#include <Pilot.h>

#include "Mail.h"



/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/

extern Word				TruncateLen;							// Maximun length of retrieved message


/***********************************************************************
 *
 * Internal Constants
 *
 ***********************************************************************/
#define truncateLen0		250
#define truncateLen1		500
#define truncateLen2		1000
#define truncateLen3		2000
#define truncateLen4		4000
#define truncateLen5		6000
#define truncateLen6		8000


/***********************************************************************
 *
 * FUNCTION:    TruncateApply
 *
 * DESCRIPTION: This routine applies the changes made in the Truncate
 *              Option Dialog.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/1/96	Initial Revision
 *			MGolden	7/14/97	Removed the switch due to 16 bit link errors...
 *
 ***********************************************************************/
static void TruncateApply (void)
{
	ListPtr lst;
	Word selection;
	
	lst = GetObjectPtr (TruncateList);

	selection = LstGetSelection (lst);

	if (selection == 0)
		TruncateLen = truncateLen0;
	else if (selection == 1)
		TruncateLen = truncateLen1;
	else if (selection == 2)
		TruncateLen = truncateLen2;
	else if (selection == 3)
		TruncateLen = truncateLen3;
	else if (selection == 4)
		TruncateLen = truncateLen4;
	else if (selection == 5)
		TruncateLen = truncateLen5;
	else if (selection == 6)
		TruncateLen = truncateLen6;
	else
		TruncateLen = syncDefaultMaxMsgLen;

/*
	switch (LstGetSelection (lst))
		{
		case 0:	TruncateLen = truncateLen0;	break;
		case 1:	TruncateLen = truncateLen1;	break;
		case 2:	TruncateLen = truncateLen2;	break;
		case 3:	TruncateLen = truncateLen3;	break;
		case 4:	TruncateLen = truncateLen4;	break;
		case 5:	TruncateLen = truncateLen5;	break;
		case 6:	TruncateLen = truncateLen6;	break;
		default:	TruncateLen = syncDefaultMaxMsgLen;
		}
*/
}


/***********************************************************************
 *
 * FUNCTION:    TruncateInit
 *
 * DESCRIPTION: This routine initializes the Truncate Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/1/96	Initial Revision
 *			 MGolden	7/14/97	Removed the switch due to 16 bit link errors...
 *
 ***********************************************************************/
static void TruncateInit (void)
{
	Word item;
	ListPtr lst;

	lst = GetObjectPtr (TruncateList);
	
	if (TruncateLen == truncateLen0)
		item = 0;
	else if (TruncateLen == truncateLen1)
		item = 1;
	else if (TruncateLen == truncateLen2)
		item = 2;
	else if (TruncateLen == truncateLen3)
		item = 3;
	else if (TruncateLen == truncateLen4)
		item = 4;
	else if (TruncateLen == truncateLen5)
		item = 5;
	else if (TruncateLen == truncateLen6)
		item = 6;
	else
		{
		item = 4;
		TruncateLen = syncDefaultMaxMsgLen;
		}
		
/*
	switch (TruncateLen)
		{
		case truncateLen0:	item = 0;	break;
		case truncateLen1:	item = 1;	break;
		case truncateLen2:	item = 2;	break;
		case truncateLen3:	item = 3;	break;
		case truncateLen4:	item = 4;	break;
		case truncateLen5:	item = 5;	break;
		case truncateLen6:	item = 6;	break;
		default:
			item = 4;
			TruncateLen = syncDefaultMaxMsgLen;
		}
*/

	LstSetSelection (lst, item);
}


/***********************************************************************
 *
 * FUNCTION:    TruncateHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Truncate
 *              Options Dialog Box".
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/1/96	Initial Revision
 *
 ***********************************************************************/
Boolean TruncateHandleEvent (EventPtr event)
{
	FormPtr frm;
	Boolean handled = false;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case TruncateOkButton:
				TruncateApply ();
				FrmReturnToForm (0);
				handled = true;
				break;

			case TruncateCancelButton:
				FrmReturnToForm (0);
				handled = true;
				break;
			}
		}

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		TruncateInit ();
		FrmDrawForm (frm);
		handled = true;
		}

	return (handled);
}


