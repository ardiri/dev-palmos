/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot 2.0
 *
 * FILE:     Mail.h
 *
 * AUTHOR:	 Art Lamb: July 30, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This file defines the structures and functions of the Mail Application. 
 *
 ***********************************************************************/

#include "MailDB.h"
#include "MailRsc.h"
#include "MailMessage.h"
#include "MailLookup.h"
#include "MailSync.h"
#include "MailTruncate.h"

/***********************************************************************
 *
 * Constants
 *
 ***********************************************************************/

#define mailDBType						'DATA'
#define mailDBName						"MailDB"
#define mailVersionNum					3
#define mailPrefsVersionNum			3


// Mail application's preferences
#define mailPrefID						0
#define mailLocalSyncPrefID			1
#define mailRemoteSyncPrefID			2
#define mailSignaturePrefID			3	


// The default length that retrieved message are truncated to.										
#define syncDefaultMaxMsgLen			4000


#define maxListFromNameLen				40
#define maxFriendlyNameLen				60


/***********************************************************************
 *
 * Structutes
 *
 ***********************************************************************/

// This enumeriated type define the field being edited the the "Edit View"
typedef enum {
	editToField,
	editFromField,
	editCCField,
	editBCCField,
	editSubjectField,
	editBodyField
} EditFieldType;


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/

extern DmOpenRef				MailDB;							// Mail database
extern Word						CurrentRecord;					// record being edited

extern FontID					MessageFont;					// font used in message view
extern Boolean					ShowFullHeader;				// True to display full header in message view

extern MsgFieldType			MessageTopField;
extern Word 					MessageScrollPos;
extern MsgSelectFieldType	MessageSelectStartField;
extern MsgSelectFieldType	MessageSelectEndField;
extern Word						MessageSelectStartPos;
extern Word						MessageSelectEndPos;

extern TimeFormatType		TimeFormat;						// system preference
extern DateFormatType		DateFormat;

extern Word						TruncateLen;					// Maximun length of retrieved message
extern VoidHand				SyncUIStateH;					// Save save of the HotSync dialog
extern EditFieldType			EditViewField;					// field to edit in the Edit view
extern Boolean					EditViewEditRecord;			// true if editing a record, false if editing hotsync options





/***********************************************************************
 *
 * Routines
 *
 ***********************************************************************/

extern VoidPtr GetObjectPtr (Word objectID);