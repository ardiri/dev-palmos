/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Elloit
 * FILE:     MailMessage.c
 * AUTHOR:	 Art Lamb: June 19, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This is the Mail application's main module.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>

#include "Mail.h"


/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define tabChrWidth				20

#define messageStdTabStop		27
#define messageBoldTabStop		37

#define maxCopyLength			1000


/***********************************************************************
 *
 *	Internal Structutes
 *
 ***********************************************************************/

typedef struct {
	Word						tabStop;
	Word						fieldTextPos;
	CharPtr					fieldText;
	MsgFieldType			fieldType;
	MsgSelectFieldType	selectStartField;
	MsgSelectFieldType	selectEndField;
	Word						selectStartPos;
	Word						selectEndPos;
	RectangleType			bounds;
	MailDBRecordType		record;
	VoidHand					recordH;
	Char						dateStr [timeStringLength + timeStringLength + 1];
	Char						toFriendlyName [maxFriendlyNameLen];
	Char						fromFriendlyName [maxFriendlyNameLen];
} MessegeInfoType;

typedef MessegeInfoType * MessegeInfoPtr;


/***********************************************************************
 *
 *	Internal Routines
 *
 ***********************************************************************/

static CharPtr MsgGetFieldPtr (MessegeInfoPtr msg);


/***********************************************************************
 *
 * FUNCTION:    MsgInit
 *
 * DESCRIPTION: This routine initialize the structure used to draw and
 *              scroll a mesage.
 *
 * PARAMETERS:  msg  - structure to initilize
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static void MsgInit (MessegeInfoPtr msg, MsgFieldType	fieldType, 
	Word fieldTextPos)
{
	Word		len;
	Word		objIndex;
	FormPtr	frm;
	
	// Get the tab stop for the start of the header text.
	if (MessageFont == stdFont)
		msg->tabStop = messageStdTabStop;
	else
		msg->tabStop = messageBoldTabStop;
		
	// Get the bounds of the message.
	frm = FrmGetActiveForm ();
	objIndex = FrmGetObjectIndex (frm, MessageGadget);
	FrmGetObjectBounds (frm, objIndex, &msg->bounds);

	// Get the current record
	MailGetRecord (MailDB, CurrentRecord, &msg->record, &msg->recordH);

	// Get the friendly mame of the recipent and the sender of the message.
	*msg->toFriendlyName = 0;
	if ((msg->record.sentTo) && StrChr (msg->record.sentTo, '('))
		{
		MailParseAddress (msg->record.sentTo, true, msg->toFriendlyName, 
			maxFriendlyNameLen);
		}

	*msg->fromFriendlyName = 0;
	if ((msg->record.from) && StrChr (msg->record.from, '('))
		{
		MailParseAddress (msg->record.from, true, msg->fromFriendlyName, 
			maxFriendlyNameLen);
		}


	msg->fieldTextPos = fieldTextPos;
	msg->fieldType = fieldType;

	msg->fieldText = MsgGetFieldPtr (msg);

	msg->selectStartField = MessageSelectStartField;
	msg->selectEndField = MessageSelectEndField;
	msg->selectStartPos = MessageSelectStartPos;
	msg->selectEndPos = MessageSelectEndPos;	

	if (DateToInt (msg->record.date))
		{
		// Format the date and time.
		DateToAscii (msg->record.date.month, 
						 msg->record.date.day, 
						 (msg->record.date.year+firstYear) % 100,
						 DateFormat,
						 msg->dateStr);
	
		len = StrLen (msg->dateStr);
		msg->dateStr [len++] = spaceChr;
	
		TimeToAscii (msg->record.time.hours, 
						 msg->record.time.minutes,
						 TimeFormat,
						 &msg->dateStr[len]);
		}
	else
		{
		*msg->dateStr = 0;
		}
}



/***********************************************************************
 *
 * FUNCTION:    MsgSearch
 *
 * DESCRIPTION: This routine searchs the fields of the mail message 
 *              that are displayable in the Message View. 
 *
 * PARAMETERS:	 strToFind - string to find
 *              fieldP    - returned: field the match occurred in
 *              posP      - starting character position of the match             
 *
 * RETURNED:	 true if a match was found
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/27/96	Initial Revision
 *
 ***********************************************************************/
Boolean MsgSearch (MailDBRecordPtr recordP, CharPtr strToFind, 
	WordPtr fieldNumP, WordPtr posP)
{
	Word		pos;
	Word		fieldType;
	CharPtr	ptr;
	Char		friendlyName [maxFriendlyNameLen];


	for (fieldType = msgFieldSentTo; fieldType <= msgFieldBody; fieldType++)
		{
		switch (fieldType)
			{
			case msgFieldSentTo:
				if ((recordP->sentTo) && StrChr (recordP->sentTo, '(' ))
					{
					MailParseAddress (recordP->sentTo, true, friendlyName, maxFriendlyNameLen);
					ptr = friendlyName;
					}
				else
					ptr = recordP->sentTo;
				break;
				
			case msgFieldTo:
				ptr = recordP->to;
				break;
				
			case msgFieldFrom:
				ptr = recordP->from;
				break;
				
			case msgFieldSubject:
				ptr = recordP->subject;
				break;
				
			case msgFieldCC:
				ptr = recordP->cc;
				break;
				
			case msgFieldBody:
				ptr = recordP->body;
				break;

			default:
				ptr = NULL;
			}

		if (ptr && *ptr)
			{
			if (FindStrInStr (ptr, strToFind, &pos))
				{
				*fieldNumP = fieldType;
				*posP = pos;
				return (true);
				}
			}
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    MsgIsHeaderField
 *
 * DESCRIPTION: Returns true if the mail field passed is a header field.
 *
 * PARAMETERS:  fieldType - type a a mail record field.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static Boolean MsgIsHeaderField (MsgFieldType fieldType) 
{
	switch (fieldType)
		{
		case msgFieldSentTo:
		case msgFieldTo:
		case msgFieldFrom:
		case msgFieldSubject:
		case msgFieldCC:
		case msgFieldDate:
			return (true);
			break;
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    MsgGetHeaderLabel
 *
 * DESCRIPTION: Returns a pointer to a header line's label.
 *
 * PARAMETERS:  fieldType - type a a mail record field.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static VoidHand MsgGetHeaderLabel (MsgFieldType fieldType, MailAddressingType addressing)
{
	Word id;
	
	switch (fieldType)
		{
		case msgFieldSentTo:
			switch (addressing)
				{
				case sentTo:
					id = toStrId;
					break;
				case sentCC:
					id = ccStrId;
					break;
				case sentBCC:
					id = bccStrId;
					break;
				}
			break;
				

		case msgFieldTo:
			id = toStrId;
			break;
			
		case msgFieldFrom:
			id = fromStrId;
			break;
			
		case msgFieldSubject:
			id = subjectStrId;
			break;
			
		case msgFieldCC:
			id = ccStrId;
			break;
			
		case msgFieldDate:
			id = dateStrId;
			break;
			
		default:
			return (0);
			
		}

	return (DmGetResource (strRsc, id));
}


/***********************************************************************
 *
 * FUNCTION:    MsgGetFieldPtr
 *
 * DESCRIPTION: This routine returns a pointer to the specified field
 *              of the record passed.
 *
 * PARAMETERS:  fieldType - type a a mail record field.
 *              repordP   - pointer to a mail record.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static CharPtr MsgGetFieldPtr (MessegeInfoPtr msg)
{
	switch (msg->fieldType)
		{
		case msgFieldSentTo:
			if (*msg->toFriendlyName)
				return (msg->toFriendlyName);
			else
				return (msg->record.sentTo);
			
		case msgFieldTo:
			return (msg->record.to);
			
		case msgFieldFrom:
			if (ShowFullHeader)
				return (msg->record.from);
			else if (*msg->fromFriendlyName)
				return (msg->fromFriendlyName);
			else
				return (msg->record.from);			
			
		case msgFieldSubject:
			return (msg->record.subject);
			
		case msgFieldCC:
			return (msg->record.cc);
			
		case msgFieldBody:
			return (msg->record.body);
			
		case msgFieldDate:
			return (msg->dateStr);
		}
	return (NULL);
}


/***********************************************************************
 *
 * FUNCTION:    MsgNextField
 *
 * DESCRIPTION: This routine the previous field of a message.
 *
 * PARAMETERS:  msg  -  used to draw and scroll a mesage.
 *
 * RETURNED:    false if there is no next field
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/21/96	Initial Revision
 *
 ***********************************************************************/
static Boolean MsgPreviousField (MessegeInfoPtr msg)
{
	if (ShowFullHeader)
		{
		switch (msg->fieldType)
			{
			case msgFieldTo:
			case msgFieldSentTo:
				msg->fieldText = NULL;
				return (false);

			case msgFieldFrom:
				msg->fieldType = msgFieldTo;
				msg->fieldText = msg->record.to;
				break;
				
			case msgFieldCC:
				msg->fieldType = msgFieldFrom;
				msg->fieldText = msg->record.from;
				break;

			case msgFieldSubject:
				msg->fieldType = msgFieldCC;
				msg->fieldText = msg->record.cc;
				break;
								
			case msgFieldDate:
				msg->fieldType = msgFieldSubject;
				msg->fieldText = msg->record.subject;
				break;
				
			case msgFieldBlankLine:
				msg->fieldType = msgFieldDate;
				msg->fieldText = msg->dateStr;
				break;
				
			case msgFieldBody:
				msg->fieldType = msgFieldBlankLine;
				msg->fieldText = NULL;
				break;
			}
		}
/*
		switch (msg->fieldType)
			{
			case msgFieldTo:
			case msgFieldSentTo:
				msg->fieldText = NULL;
				return (false);

			case msgFieldFrom:
				msg->fieldType = msgFieldTo;
				msg->fieldText = msg->record.to;
				break;

			case msgFieldSubject:
				msg->fieldType = msgFieldFrom;
				msg->fieldText = msg->record.from;
				break;
				
			case msgFieldCC:
				msg->fieldType = msgFieldSubject;
				msg->fieldText = msg->record.subject;
				break;
				
			case msgFieldDate:
				msg->fieldType = msgFieldCC;
				msg->fieldText = msg->record.cc;
				break;
				
			case msgFieldBlankLine:
				msg->fieldType = msgFieldDate;
				msg->fieldText = msg->dateStr;
				break;
				
			case msgFieldBody:
				msg->fieldType = msgFieldBlankLine;
				msg->fieldText = NULL;
				break;
			}
		}
*/

	else
		{
		switch (msg->fieldType)
			{
			case msgFieldTo:
			case msgFieldSentTo:
				return (false);

			case msgFieldFrom:
			case msgFieldSubject:
			case msgFieldCC:
			case msgFieldDate:
				msg->fieldType = msgFieldSentTo;
				if (*msg->toFriendlyName)
					msg->fieldText = msg->toFriendlyName;
				else
					msg->fieldText = msg->record.sentTo;
				break;
			
			case msgFieldBlankLine:
				msg->fieldType = msgFieldFrom;
				if (*msg->fromFriendlyName)
					msg->fieldText = msg->fromFriendlyName;
				else
					msg->fieldText = msg->record.from;
				break;
				
			case msgFieldBody:
				msg->fieldType = msgFieldBlankLine;
				msg->fieldText = NULL;
				break;
			}
		}

	if (msg->fieldText)
		msg->fieldTextPos = StrLen (msg->fieldText);
	else
		msg->fieldTextPos = 0;

	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    MsgNextField
 *
 * DESCRIPTION: This routine the next field of a message.
 *
 * PARAMETERS:  msg  -  used to draw and scroll a mesage.
 *
 * RETURNED:    false if there is no next field
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			art		6/19/96	Initial Revision
 *			MGolden	7/11/97	Added the subject view to the short header
 *
 ***********************************************************************/
static Boolean MsgNextField (MessegeInfoPtr msg)
{
	if (ShowFullHeader)
		{
		switch (msg->fieldType)
			{
			case msgFieldTo:
			case msgFieldSentTo:
				msg->fieldType = msgFieldFrom;
				msg->fieldText = msg->record.from;
				break;
				
			case msgFieldFrom:
				msg->fieldType = msgFieldCC;
				msg->fieldText = msg->record.cc;
				break;
				
			case msgFieldCC:
				msg->fieldType = msgFieldSubject;
				msg->fieldText = msg->record.subject;
				break;

			case msgFieldSubject:
				msg->fieldType = msgFieldDate;
				msg->fieldText = msg->dateStr;
				break;
				
			case msgFieldDate:
				msg->fieldType = msgFieldBlankLine;
				msg->fieldText = NULL;
				break;
			
			case msgFieldBlankLine:
				msg->fieldType = msgFieldBody;
				msg->fieldText = msg->record.body;
				break;
				
			case msgFieldBody:
				return (false);
			}
		}

	else
		{
		switch (msg->fieldType)
			{
			case msgFieldTo:
			case msgFieldSentTo:
				msg->fieldType = msgFieldFrom;
				if (*msg->fromFriendlyName)
					msg->fieldText = msg->fromFriendlyName;
				else
					msg->fieldText = msg->record.from;
				break;

//mgmg new add the subject field to the short header...				
			case msgFieldFrom:
				msg->fieldType = msgFieldSubject;
				msg->fieldText = msg->record.subject;
				break;
			
			
			case msgFieldSubject:
			case msgFieldCC:
			case msgFieldDate:
				msg->fieldType = msgFieldBlankLine;
				msg->fieldText = NULL;
				break;
			
			case msgFieldBlankLine:
				msg->fieldType = msgFieldBody;
				msg->fieldText = msg->record.body;
				break;
				
			case msgFieldBody:
				return (false);
			}
		}
	
	msg->fieldTextPos = 0;

	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    MsgSelectFieldVisible
 *
 * DESCRIPTION: This routine returns true if the selection field is 
 *              visible in the current message line.
 *
 * PARAMETERS:  msg         - used to draw and scroll a mesage.
 *              selectField - label of field of message
 *
 * RETURNED:    true if selection field is visible
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/28/96	Initial Revision
 *
 ***********************************************************************/
static Boolean MsgSelectFieldVisible (MessegeInfoPtr msg, 
	MsgSelectFieldType selectField)
{
	Word pos;
	MsgFieldType fieldType;

	if (msg->selectStartField > selectField ||
		 msg->selectEndField < selectField)
		return (false);


	fieldType = msg->fieldType;
	pos = msg->fieldTextPos;

	switch (selectField)
		{
		case msgSelectSentToLabel:
			return (fieldType == msgFieldSentTo && pos == 0);

		case msgSelectSentTo:
			return (fieldType == msgFieldSentTo);

		case msgSelectToLabel:
			return (fieldType == msgFieldTo && pos == 0);

		case msgSelectTo:
			return (fieldType == msgFieldTo);

		case msgSelectFromLabel:
			return (fieldType == msgFieldFrom && pos == 0);

		case msgSelectFrom:
			return (fieldType == msgFieldFrom);

		case msgSelectSubjectLabel:
			return (fieldType == msgFieldSubject && pos == 0);

		case msgSelectSubject:
			return (fieldType == msgFieldSubject);

		case msgSelectCC:
			return (fieldType == msgFieldCC && ShowFullHeader);

		case msgSelectCCLabel:
			return (fieldType == msgFieldCC && pos == 0 && ShowFullHeader);

		case msgSelectDate:
			return (fieldType == msgFieldDate && ShowFullHeader);

		case msgSelectDateLabel:
			return (fieldType == msgFieldDate && pos == 0 && ShowFullHeader);

		case msgSelectBlankLine:
			return (fieldType == msgFieldBlankLine);

		case msgSelectBody:
			return (fieldType == msgFieldBody);
			
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    MsgWordWrap
 *
 * DESCRIPTION: Given a string, determine the number of characters that
 *              can be displayed within the specified width.
 *
 * PARAMETERS:  msg  - structure contain info for word wrapping
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static Word MsgWordWrap (MessegeInfoPtr msg)
{
	Word width;
	Word length = 0;
	CharPtr ptr;
	Boolean header;

		
	// Leave room for the field description (ex: "To:") if the field 
	// has a description.
	header = MsgIsHeaderField (msg->fieldType);
	if (header)
		{
		width = msg->bounds.extent.x - msg->tabStop;
		}
	else
		width = msg->bounds.extent.x;

	ptr = MsgGetFieldPtr (msg);

	if (ptr)
		{
		ptr += msg->fieldTextPos;
		length = FntWordWrap (ptr, width);
		}



/*
	// If the field is a header and we didn't wrap on a space of linefeed
	// character then wrap on the last address punctuation character.
	if (header && length)
		{
		count = 0;
		ptr += length - 1;
		if (*(ptr+1) != nullChr  &&  *ptr != spaceChr  &&  *ptr != linefeedChr)
			{
			while (count < length)
				{
				// Wrap after right paren.
				if (*ptr == ')')
					{ 
					length -= count;
					break;
					}
				// Wrap before left paren, @, and period.
				else if (*ptr == '(' || *ptr == '@' || *ptr == periodChr)
					{
					if (length > count + 1)
						length -= count + 1;
					break;
					}
				count++;
				ptr--;		
				}
			}
		}
*/
	return (length);
}


/***********************************************************************
 *
 * FUNCTION:    MsgIsLableField
 *
 * DESCRIPTION: Returns true if the field passed is a label field.
 *
 * PARAMETERS:  selectField - masseage label a field
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static Boolean MsgIsLableField (MsgSelectFieldType selectField) 
{
	switch (selectField)
		{
		case msgSelectSentToLabel:
		case msgSelectToLabel:
		case msgSelectFromLabel:
		case msgSelectSubjectLabel:
		case msgSelectCCLabel:
		case msgSelectDateLabel:
			return (true);
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    InvertCharsRange
 *
 * DESCRIPTION: Invert specified characer range on the specified line.
 *              This rountine performs the actual inverting.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              lineNum  line number
 *              startPos character position of start of range
 *              endPos   character position of end of range.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/28/96	Initial Revision
 *
 ***********************************************************************/
static void MsgInvertCharsRange (MessegeInfoPtr msg, MsgSelectFieldType selectField, 
	Word lineNumber, Word startPos, Word endPos)
{
	Word 				length;
	Short				left;
	Short				width;
	CharPtr			ptr;
	VoidHand			resH;
	Boolean 			label;
	RectangleType	r;
	

	label = MsgIsLableField (selectField);

	if (label)
		{
		resH = MsgGetHeaderLabel (msg->fieldType, 
			(MailAddressingType) msg->record.flags.addressing);
		ptr = MemHandleLock (resH);

		length = FntLineWidth (ptr, StrLen(ptr));
		left = msg->bounds.topLeft.x + 
		       (msg->tabStop - length) +
				 FntLineWidth (ptr, startPos);
		}

	else if (msg->fieldText)
		{
		ptr = msg->fieldText;

		left = msg->bounds.topLeft.x + 
			FntLineWidth (&ptr[msg->fieldTextPos], startPos - msg->fieldTextPos);

		if (MsgIsHeaderField (msg->fieldType))
			left += msg->tabStop;
		}
	else
		return;


	width = FntLineWidth (&ptr[startPos], endPos - startPos);

	
	r.topLeft.x = left;
	r.extent.x = width;

	r.extent.y = FntLineHeight ();
	r.topLeft.y = msg->bounds.topLeft.y + (lineNumber * FntLineHeight ());

	if (r.topLeft.x + r.extent.x > msg->bounds.topLeft.x + msg->bounds.extent.x)
		r.extent.x = msg->bounds.extent.x - (r.topLeft.x - msg->bounds.topLeft.x);

	WinInvertRectangle (&r, 0);


	if (label)
		{
		MemHandleUnlock (resH);
		DmReleaseResource (resH);
		}
}


/***********************************************************************
 *
 * FUNCTION:    MsgInvertSelection
 *
 * DESCRIPTION: Invert the current selection.
 *
 * PARAMETERS:	 nothing
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/28/96	Initial Revision
 *
 ***********************************************************************/
static void MsgInvertSelection (MessegeInfoPtr msg)
{
	Word length;
	Word lineNumber;
	Word numLines;
	Word startPos;
	Word endPos;
	CharPtr ptr;
	VoidHand resH;
	MsgSelectFieldType selectField;

	if (msg->selectStartField == msgSelectNone)
		return;

	lineNumber = 0;
	numLines = msg->bounds.extent.y / FntLineHeight ();

	while (lineNumber < numLines)
		{
		length = MsgWordWrap (msg);
		if (length)
			{
			for (selectField = msg->selectStartField; 
				  selectField <= msg->selectEndField; selectField++)
				{
				if (MsgSelectFieldVisible (msg, selectField))
					{
					if (MsgIsLableField (selectField))
						{
						if (selectField == msg->selectStartField)
							startPos = msg->selectStartPos;
						else 
							startPos = 0;
							
						if (selectField == msg->selectEndField)
							endPos = msg->selectEndPos;
						else
							{
							resH = MsgGetHeaderLabel (msg->fieldType, 
								(MailAddressingType) msg->record.flags.addressing);
							ptr = MemHandleLock (resH);
							endPos = StrLen (ptr);
							MemHandleUnlock (resH);
							DmReleaseResource (resH);
							}
						}

					else
						{
						if (selectField == msg->selectStartField)
							{
							if (msg->selectStartPos < msg->fieldTextPos + length)
								startPos = max (msg->selectStartPos, msg->fieldTextPos);
							else
								continue;
							}
						else
							startPos = msg->fieldTextPos;
							

						if (selectField == msg->selectEndField)
							{
							if (msg->selectEndPos >= msg->fieldTextPos)
								endPos = min (msg->selectEndPos, msg->fieldTextPos + length);
							else
								continue;
							}
						else
							endPos = msg->fieldTextPos + length;
						}


					MsgInvertCharsRange (msg, selectField, lineNumber, startPos, endPos);
					}
				}

			msg->fieldTextPos += length;
			lineNumber++;
			}
		else
			{ 
			if (msg->fieldType == msgFieldBlankLine)
				lineNumber++;
			if (! MsgNextField (msg))
				break;
			}
		}
}



/***********************************************************************
 *
 * FUNCTION:    MsgDrawLine
 *
 * DESCRIPTION: This routine draws a line of the message.
 *
 * PARAMETERS:  msg         - structure contain info for drawing
 *              charsToDraw - the number of characters to draw
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
static void MsgDrawLine (MessegeInfoPtr msg, Word charsToDraw, 
		Word lineNumber)
{
	Word		len;
	Word		count;
	Word		charsDrawn;
	Short 	x, y;
	Short 	drawX;
	CharPtr	ptr;
	Boolean	header;

	// Calculate the draw position of the line.
	x = msg->bounds.topLeft.x;
	y = msg->bounds.topLeft.y + (lineNumber * FntLineHeight ());

	// If the line is the start of of the header draw the header label.  
	header = MsgIsHeaderField (msg->fieldType);
	if (header)
		{
		if (msg->fieldTextPos == 0)
			{
			ptr = MemHandleLock (MsgGetHeaderLabel (msg->fieldType, 
				(MailAddressingType) msg->record.flags.addressing));
			len = StrLen (ptr);
			drawX = x +( short)msg->tabStop - (Short)FntCharsWidth (ptr, len);
			WinDrawChars (ptr, len, drawX, y);
			MemPtrUnlock (ptr);
			}
		x += msg->tabStop;
		}
	
	// Get a pointer to the start of the text to draw.
	ptr = MsgGetFieldPtr (msg);
	ptr += msg->fieldTextPos;
	
	// Don't draw the linefeedChr character.
	if ((charsToDraw) && ptr[charsToDraw-1] == linefeedChr)
		charsToDraw--;

	// Don't draw trailing spaceChrs.
	while (charsToDraw && ptr[charsToDraw-1] == spaceChr)
		charsToDraw--;

	// Draw the text.
	count = 0;
	charsDrawn = 0;
	while (true)
		{
		// Count until we reach a tab character.
		while ((count < charsToDraw) && (ptr[count] != tabChr))
			count++;
			
		// Draw the characters until/between the tab characters.
		WinDrawChars (&ptr[charsDrawn], count-charsDrawn, x, y);
		if (count >= charsToDraw) break;
		
		// Move the draw position past the tab.
		x += FntLineWidth (&ptr[charsDrawn], count-charsDrawn);
		x += tabChrWidth - ((x - msg->bounds.topLeft.x) % tabChrWidth);

		// Skip over the tab.
		count++;
		charsDrawn = count;
		}
}



/***********************************************************************
 *
 * FUNCTION:    MsgDraw
 *
 * DESCRIPTION: This routine draws an mail message.
 *
 * PARAMETERS:  msg         - structure contain info for drawing.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
void MsgDraw (void)
{
	Word					length;
	Word					lineNumber;
	Word					linesToDraw;
	FontID				currFont;
	MessegeInfoType	msg;
	Boolean isHeader;
	
	currFont = FntSetFont (MessageFont);

	MsgInit (&msg, MessageTopField, MessageScrollPos);

	lineNumber = 0;
	linesToDraw = msg.bounds.extent.y / FntLineHeight ();
	
	while (lineNumber < linesToDraw)
		{
		isHeader = false;
		//mgmg change this to draw the empty header if needed...
		length = MsgWordWrap (&msg);
		if (length)
			{
			MsgDrawLine (&msg, length, lineNumber);
			msg.fieldTextPos += length;
			lineNumber++;
			}
		else if (msg.fieldType == msgFieldBlankLine)
			{
			lineNumber++;
			if (! MsgNextField (&msg))
				break;
			}
		else if (!MsgNextField (&msg))
			break;
		}

	MemHandleUnlock (msg.recordH);


	MsgInit (&msg, MessageTopField, MessageScrollPos);
	MsgInvertSelection (&msg);
	MemHandleUnlock (msg.recordH);

	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    MsgErase
 *
 * DESCRIPTION: This routine erase the current mail message.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/19/96	Initial Revision
 *
 ***********************************************************************/
void MsgErase (void)
{
	Word objIndex;
	FormPtr frm;
	RectangleType bounds;
	
	frm = FrmGetActiveForm ();
	objIndex = FrmGetObjectIndex (frm, MessageGadget);
	FrmGetObjectBounds (frm, objIndex, &bounds);
	WinEraseRectangle (&bounds, 0);
}


/***********************************************************************
 *
 * FUNCTION:    MsgGetFieldHeight
 *
 * DESCRIPTION: This routine returns the height of a format message 
 *              field.
 *
 * PARAMETERS:  fld - pointer to a FieldType structure.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/20/96	Initial Revision
 *
 ***********************************************************************/
static Word MsgGetFieldHeight (MessegeInfoPtr msg)
{
	Word		length;
	Word		lines;
	
	if (msg->fieldType == msgFieldBlankLine)
		return (1);

	lines = 0;
	length = 0;
	msg->fieldTextPos = 0;

	do
		{
		length += MsgWordWrap (msg);
		msg->fieldTextPos = length;
		lines++;
		}
	while (msg->fieldText[length]);
	
	// If the text end with a linefeed add one to the height.
	if (length && msg->fieldText[length-1] == linefeedChr) 
		lines++;

	return (lines);
}


/***********************************************************************
 *
 * FUNCTION:    MsgGetScrollValues
 *
 * DESCRIPTION: This routine returns the values necessary to update a 
 *              scroll bar.
 *
 * PARAMETERS:  fld - pointer to a FieldType structure.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/20/96	Initial Revision
 *
 ***********************************************************************/
/*
void MsgGetScrollValues (WordPtr textHeightP, WordPtr pageHeightP)
{
	Word					lines = 0;
	FontID				currFont;
	MessegeInfoType	msg;

	currFont = FntSetFont (MessageFont);
	
	MsgInit (&msg, msgFieldTo, 0);

	while (true)
	 	{
		lines += MsgGetFieldHeight (&msg);
		
		if (! MsgNextField (&msg))
			break;
		}
		
	MemHandleUnlock (msg.recordH);
	FntSetFont (currFont);

	*textHeightP = lines;
	*pageHeightP = msg.bounds.extent.y / FntLineHeight ();;
}
*/


/***********************************************************************
 *
 * FUNCTION:    MsgGetScrollValues
 *
 * DESCRIPTION: This routine returns the values necessary to update a 
 *              scroll bar.
 *
 * PARAMETERS:  fld - pointer to a FieldType structure.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/20/96	Initial Revision
 *
 ***********************************************************************/
void MsgGetScrollValues (WordPtr textHeightP, WordPtr pageHeightP, WordPtr topLineP)
{
	Word					length;
	Word					lines = 0;
	Word					topLine = 0;
	FontID				currFont;
	MsgFieldType		fieldType;
	MessegeInfoType	msg;

	currFont = FntSetFont (MessageFont);

	if (ShowFullHeader)
		fieldType = msgFieldTo;
	else
		fieldType = msgFieldSentTo;
	
	MsgInit (&msg, fieldType, 0);

	while (true)
	 	{
		if (msg.fieldType == MessageTopField)
			topLine = lines;

		if (msg.fieldType == msgFieldBlankLine)
			lines++;
		else
			{
			length = 0;
			msg.fieldTextPos = 0;
		
			do
				{
				length = MsgWordWrap (&msg);

				if (msg.fieldType == MessageTopField)
					{
					if (msg.fieldTextPos < MessageScrollPos && 
						 msg.fieldTextPos + length > MessageScrollPos)
						{
						MessageScrollPos = msg.fieldTextPos;
						topLine = lines;
						}
					else if (msg.fieldTextPos + length == MessageScrollPos)
						//mgmg
						//topLine = lines;
						topLine = lines;
					}

				if (length)
					{
					msg.fieldTextPos += length;
					lines++;
					}
				}
			while (msg.fieldText[msg.fieldTextPos]);
			
			// If the text end with a linefeed add one to the height.
			if (length && msg.fieldText[length-1] == linefeedChr) 
				lines++;
			}
		
		if (! MsgNextField (&msg))
			break;
		}
		
	MemHandleUnlock (msg.recordH);

	*topLineP = topLine;
	*textHeightP = lines;
	*pageHeightP = msg.bounds.extent.y / FntLineHeight ();;

	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    MsgScrollUpNLines
 *
 * DESCRIPTION: This routine scrolls a field of the message up by the
 *              number of lines specified.
 *
 * PARAMETERS:	 msg          structure contain message info
 *             linesToScroll number of lines to scroll.
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/1/96	Initial Revision
 *
 ***********************************************************************/
static Word MsgScrollUpNLines (MessegeInfoPtr msg, Word linesToScroll)
{
	Word					width;
	Word					lineCount = 0;

	if (msg->fieldText && msg->fieldTextPos)
		{
		if (MsgIsHeaderField (msg->fieldType))
			width = msg->bounds.extent.x - msg->tabStop;
		else
			width = msg->bounds.extent.x;

		lineCount = linesToScroll;
		FntWordWrapReverseNLines (msg->fieldText, width, 
			&lineCount, &msg->fieldTextPos);
		}

	if (msg->fieldType == msgFieldBlankLine  && linesToScroll > 1)
		lineCount = 1;

	return (lineCount);
}


/***********************************************************************
 *
 * FUNCTION:    MsgScroll
 *
 * DESCRIPTION: This routine scrolls the message view by the number of
 *              lines specified.
 *
 * PARAMETERS:  direction - up or dowm
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/20/96	Initial Revision
 *
 ***********************************************************************/
void MsgScroll (Short linesToScroll, DirectionType direction)
{
	Word					length;
	Word					linesScrolled;
	FontID				currFont;
	MessegeInfoType	msg;

	currFont = FntSetFont (MessageFont);
	MsgInit (&msg, MessageTopField, MessageScrollPos);

	if (direction == up)
		{
		while (true)
			{
			linesScrolled = MsgScrollUpNLines (&msg, linesToScroll);
			if (linesScrolled == linesToScroll)
				break;
			linesToScroll -= linesScrolled;

			if (! MsgPreviousField (&msg))
				break;
			}
		}


	else if (direction == down)
		{
		while (linesToScroll)
			{
			length = MsgWordWrap (&msg);
			if (length)
				{
				msg.fieldTextPos += length;
				linesToScroll--;
				}
			else
				{
				if (msg.fieldType == msgFieldBlankLine)
					linesToScroll--;
				if (! MsgNextField (&msg))
					break;
				}
			}

		// If we at the end of the current field move to the next field so that
		// the field position and field top of the top line will be correct.
		if (length && msg.fieldText[msg.fieldTextPos] == 0)
			MsgNextField (&msg);
		}

	MemHandleUnlock (msg.recordH);
	FntSetFont (currFont);

	MessageScrollPos = msg.fieldTextPos;
	MessageTopField = msg.fieldType;

	// zzz - Optimize redraw
	WinEraseRectangle (&msg.bounds, 0);
	MsgDraw ();
}


/***********************************************************************
 *
 * FUNCTION:    MsgUpdateHighlight
 *
 * DESCRIPTION: Adjust the current highlighted region to include or exclude
 *              the specified range of characters.
 *
 * PARAMETERS:	 msg       - structure contain message info
 *              startPos character position of start of range
 *              endPos   character position of end of range.           
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/29/96	Initial Revision
 *
 ***********************************************************************/
static void MsgUpdateHighlight (MessegeInfoPtr msg,
	 MsgSelectFieldType startField, Word startPos, 
	 MsgSelectFieldType endField, Word endPos)
{
	MsgSelectFieldType invertStartField;
	MsgSelectFieldType invertEndField;
	Word invertStartPos;
	Word invertEndPos;


	// No current selection?
	if (msg->selectStartField == msg->selectEndField &&
		 msg->selectStartPos == msg->selectEndPos)
		{
		invertStartField = startField;
		invertEndField = endField;
		invertStartPos = startPos;
		invertEndPos = endPos;
		}

	// Add to the end of the selection.
	else if (msg->selectStartField == startField &&
				msg->selectStartPos == startPos)
		{
		if (msg->selectEndField < endField)
			{
			invertStartField = msg->selectEndField;
			invertStartPos = msg->selectEndPos;
			invertEndField = endField;
			invertEndPos = endPos;
			}
		else if (msg->selectEndField > endField)
			{
			invertStartField = endField;
			invertStartPos = endPos;
			invertEndField = msg->selectEndField;
			invertEndPos = msg->selectEndPos;
			}
		else
			{
			invertStartField = msg->selectEndField;
			invertEndField = msg->selectEndField;
			if (msg->selectEndPos < endPos)
				{
				invertStartPos = msg->selectEndPos;
				invertEndPos = endPos;
				}
			else
				{
				invertStartPos = endPos;
				invertEndPos = msg->selectEndPos;
				}
			}
		}

	// Add to the start of the selection.
	else if (msg->selectEndField == endField &&
				msg->selectEndPos == endPos)
		{
		if (msg->selectStartField < startField)
			{
			invertStartField = msg->selectStartField;
			invertStartPos = msg->selectStartPos;
			invertEndField = startField;
			invertEndPos = startPos;
			}
		else if (msg->selectStartField > startField)
			{
			invertStartField = startField;
			invertStartPos = startPos;
			invertEndField = msg->selectStartField;
			invertEndPos = msg->selectStartPos;
			}
		else
			{
			invertStartField = msg->selectStartField;
			invertEndField = msg->selectStartField;
			if (msg->selectStartPos < startPos)
				{
				invertStartPos = msg->selectStartPos;
				invertEndPos = startPos;
				}
			else
				{
				invertStartPos = startPos;
				invertEndPos = msg->selectStartPos;
				}
			}
		}

	else
		{
		if (msg->selectStartField < startField)
			{
			invertStartField = msg->selectStartField;
			invertStartPos = msg->selectStartPos;
			}
		else if (msg->selectStartField > startField)
			{
			invertStartField = startField;
			invertStartPos = startPos;
			}
		else
			{
			invertStartField = msg->selectStartField;
			invertStartPos = min (msg->selectStartPos, startPos);
			}
			
		if (msg->selectEndField < endField)
			{
			invertEndField = endField;
			invertEndPos = endPos;
			}
		else if (msg->selectEndField > endField)
			{
			invertEndField = msg->selectEndField;
			invertEndPos = msg->selectEndPos;
			}
		else
			{
			invertEndField = msg->selectEndField;
			invertEndPos = max (msg->selectEndPos, endPos);
			}
		}

	msg->selectStartField = invertStartField;
	msg->selectStartPos = invertStartPos;
	msg->selectEndField = invertEndField;
	msg->selectEndPos = invertEndPos;

	MsgInvertSelection (msg);

	msg->selectStartField = startField;
	msg->selectStartPos = startPos;
	msg->selectEndField = endField;
	msg->selectEndPos = endPos;
}


/***********************************************************************
 *
 * FUNCTION:    MsgSetSelection
 *
 * DESCRIPTION: This 
 *
 * PARAMETERS:	 
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/28/96	Initial Revision
 *
 ***********************************************************************/
static void MsgSetSelection (MessegeInfoPtr msg, 
	MsgSelectFieldType startField, Word	startPos,
	MsgSelectFieldType endField, Word endPos)
{
	Word tempPos;
	MsgSelectFieldType tempField;

    if (startField == endField && startPos == endPos)
    	{
    	MsgInvertSelection (msg);
		msg->selectStartField = msgSelectNone;
		msg->selectStartPos = 0;
		msg->selectEndField = msgSelectNone;
		msg->selectEndPos = 0;
    	}

    else if (startField > endField)
    	{
    	tempField = startField;
    	startField = endField;
		endField = tempField;

    	tempPos = startPos;
    	startPos = endPos;
		endPos = tempPos;
    	}

    else if (startField == endField && startPos > endPos)
		{
    	tempPos = startPos;
    	startPos = endPos;
		endPos = tempPos;
		}

	MsgUpdateHighlight (msg, startField, startPos, endField, endPos);

	MessageSelectStartField = msg->selectStartField;
	MessageSelectEndField = msg->selectEndField;
	MessageSelectStartPos = msg->selectStartPos;
	MessageSelectEndPos = msg->selectEndPos;
}


/***********************************************************************
 *
 * FUNCTION:    MsgGetPositionOfPoint
 *
 * DESCRIPTION: Given the position in the pen this routine will 
 *              return the message field and character position 
 *              of the point.
 *
 * PARAMETERS:	 msg       - structure contain message info
 *              x, y      - pen position
 *              fieldP 	  - returned: field the pen is in
 *              posP 	  - returned: character position the pen is on
 *					 r         - returned: bounds of character position
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/28/96	Initial Revision
 *
 ***********************************************************************/
static void MsgGetPositionOfPoint (MessegeInfoPtr msg, Short x, Short y,
	MsgSelectFieldType * fldP,  WordPtr posP, RectanglePtr r)
{
	Word				length;
	Word				lineNumber;
	Word				lines;
	Word				width;
	Word				lastWidth;
	Short				xPos;
	Short				yPos;
	CharPtr			ptr;
	Boolean			more;
	Boolean			heading;
	VoidHand			resH = 0;


	// Find the line the point is on.
	y = max (y, msg->bounds.topLeft.y);
	y = min (y, msg->bounds.topLeft.y + msg->bounds.extent.y - 1);
	yPos = (y - msg->bounds.topLeft.y) / FntLineHeight ();

	lineNumber = 0;
	lines = msg->bounds.extent.y / FntLineHeight ();
	length = 0;
	
	while (lineNumber < lines)
		{
		if (lineNumber >= yPos)
			break;
			
		length = MsgWordWrap (msg);
		if (length)
			{
			msg->fieldTextPos += length;
			lineNumber++;
			}


		if ((! length) || (msg->fieldText [msg->fieldTextPos] == 0))
			{
			while (true)
				{
				if (msg->fieldType == msgFieldBlankLine)
					{
					if (lineNumber >= yPos)
						break;
					lineNumber++;
					}

				more = MsgNextField (msg);
				if (! more)
					break;
					
				if (msg->fieldText && *msg->fieldText)
					break;
				}
			if (! more) break;
			}
		}



	// Find the field the point in on.
	x = max (x, msg->bounds.topLeft.x);
	x = min (x, msg->bounds.topLeft.y + msg->bounds.extent.x - 1);

	heading = MsgIsHeaderField (msg->fieldType);
	if (heading && 
		 (msg->fieldTextPos == 0) &&
		 (x - msg->bounds.topLeft.x <= msg->tabStop))
		{
		switch (msg->fieldType)
			{
			case msgFieldSentTo:			*fldP = msgSelectSentToLabel;		break;
			case msgFieldTo:				*fldP = msgSelectToLabel;			break;
			case msgFieldFrom:			*fldP = msgSelectFromLabel;		break;
			case msgFieldSubject:		*fldP = msgSelectSubjectLabel;	break;
			case msgFieldCC:				*fldP = msgSelectCCLabel;			break;
			case msgFieldDate:			*fldP = msgSelectDateLabel;		break;
			}

		resH = MsgGetHeaderLabel (msg->fieldType, 
			(MailAddressingType) msg->record.flags.addressing);
		ptr = MemHandleLock (resH);
		length = FntCharsWidth (ptr, StrLen (ptr));

		x -= (msg->tabStop - length);
		if (x < 0) x = 0;
		}

	else 
		{
		switch (msg->fieldType)
			{
			case msgFieldSentTo:			*fldP = msgSelectSentTo;			break;
			case msgFieldTo:				*fldP = msgSelectTo;					break;
			case msgFieldFrom:			*fldP = msgSelectFrom;				break;
			case msgFieldSubject:		*fldP = msgSelectSubject;			break;
			case msgFieldCC:				*fldP = msgSelectCC;					break;
			case msgFieldDate:			*fldP = msgSelectDate;				break;
			case msgFieldBlankLine:		*fldP = msgSelectBlankLine;		break;
			case msgFieldBody:			*fldP = msgSelectBody;				break;
			}

		ptr = msg->fieldText + msg->fieldTextPos;
		length = MsgWordWrap (msg);
		if (length && ptr[length-1] == linefeedChr)
			length--;
			
		if (heading)
			x -= msg->tabStop;
		}
	

	// Determine the character position of the point.
//	if ((! ptr) || (! *ptr))
//		{
//		*posP = 0;
//		}

	if (! ptr)
		*posP = 0;
	
	else if  (! *ptr)
		*posP = msg->fieldTextPos;
	
	else
		{
		xPos = 0;
		width = 0;
		lastWidth = 0;
		while (xPos < length) 
			{
			if (ptr[xPos] != tabChr)
				width += FntCharWidth (ptr[xPos]);
			else
				width += tabChrWidth - (width % tabChrWidth);
			
			if (width >= x)
				{
				if ((x - lastWidth) >= ((width - lastWidth) >> 1))
					xPos++;
				break;
				}
			xPos++;
			lastWidth = width;
			}
		if (! resH)
			xPos += msg->fieldTextPos;
		*posP = xPos;
		}


	// Determine the bounds of the character position.
	r->topLeft.x = msg->bounds.topLeft.x;
	r->extent.x = msg->bounds.extent.x;
	r->topLeft.y = msg->bounds.topLeft.y + (yPos * FntLineHeight()); 
	r->extent.y = FntLineHeight();

	if (length)
		{
		width = 0;

		// Calculate the size of half of the width of the character before
		// the insertion point.
		if (xPos > 0)
			{
			if (ptr[xPos-1] != tabChr)
				width = (FntCharWidth (ptr[xPos-1]) + 1) / 2;
			else if (xPos > 1)
				width = (FntLineWidth (ptr, xPos) - 
							FntLineWidth (ptr, xPos-1) + 1) / 2;
			else
				width = (tabChrWidth + 1) / 2;


			r->topLeft.x += FntLineWidth (ptr, xPos) - width;
			}

		// Add half of the width of the character following the insertion point.
		if (ptr[xPos] != tabChr)
			width += FntCharWidth (ptr[xPos]) / 2;

		else if (length > 1)
			width += (FntLineWidth (ptr, xPos+1) - 
						 FntLineWidth (ptr, xPos)) / 2;
		else
			width += tabChrWidth / 2;

		r->extent.x = width;
		}

	switch (*fldP)
		{
		case msgSelectSentToLabel:
		case msgSelectToLabel:
		case msgSelectFromLabel:
		case msgSelectSubjectLabel:
		case msgSelectCCLabel:
		case msgSelectDateLabel:
			r->topLeft.x += (msg->tabStop - length);
			break;
	
		case msgSelectSentTo:
		case msgSelectTo:
		case msgSelectFrom:
		case msgSelectSubject:
		case msgSelectCC:
		case msgSelectDate:
			r->topLeft.x += msg->tabStop;
			break;
		}


//	WinInvertRectangle (r, 0);

	if (resH)
		MemHandleUnlock (resH);
}


/***********************************************************************
 *
 * FUNCTION:    MsgSelect
 *
 * DESCRIPTION: This is the massage selection routine.
 *
 * PARAMETERS:	 x, y - starting pen position
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/28/96	Initial Revision
 *
 ***********************************************************************/
void MsgSelect (Short x, Short y)
{
	FontID					currFont;
	Word						penPos;
	Word						anchorPos;
	Short						value;
	Short						min;
	Short						max;
	Short						pageSize;
	FormPtr					frm;
	Boolean					penDown;
	Boolean					update;
	ScrollBarPtr			bar;
	RectangleType			r;
	MessegeInfoType		msg;
	MsgSelectFieldType	penFld;
	MsgSelectFieldType	anchorFld;

	currFont = FntSetFont (MessageFont);

	MsgInit (&msg, MessageTopField, MessageScrollPos);
	
	// Cancel the existing selection
	MsgSetSelection (&msg, msgSelectNone, 0, msgSelectNone, 0);

	msg.fieldTextPos = MessageScrollPos;
	msg.fieldType = MessageTopField;
	msg.fieldText = MsgGetFieldPtr (&msg);
	MsgGetPositionOfPoint (&msg, x, y, &anchorFld, &anchorPos, &r);	

	msg.fieldTextPos = MessageScrollPos;
	msg.fieldType = MessageTopField;
	msg.fieldText = MsgGetFieldPtr (&msg);
	MsgSetSelection (&msg, anchorFld, anchorPos, anchorFld, anchorPos);


	frm = FrmGetActiveForm ();
	bar = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, MessageScrollBar));

	do
		{
		// Above the message bounds?
		if (y < msg.bounds.topLeft.y)
			{
			SclGetScrollBar (bar, &value, &min, &max, &pageSize);
			if (value)
				{
				MsgScroll (1, up);
				SclSetScrollBar (bar, value-1, min, max, pageSize);
				update = true;			
				}
			else
				update = false;
			}
				
			
		// Below the message bounds?
		else if (y >= msg.bounds.topLeft.y + msg.bounds.extent.y)
			{
			SclGetScrollBar (bar, &value, &min, &max, &pageSize);
			if (value < max)
				{
				MsgScroll (1, down);
				SclSetScrollBar (bar, value+1, min, max, pageSize);
				update = true;			
				}
			else
				update = false;
			}


		// Over a different character?
		else if (! RctPtInRectangle (x, y, &r))
			update =  true;
			
		else
			update = false;

		if (update)
			{
			msg.fieldTextPos = MessageScrollPos;
			msg.fieldType = MessageTopField;
			msg.fieldText = MsgGetFieldPtr (&msg);
			MsgGetPositionOfPoint (&msg, x, y, &penFld, &penPos, &r);	

			msg.fieldTextPos = MessageScrollPos;
			msg.fieldType = MessageTopField;
			msg.fieldText = MsgGetFieldPtr (&msg);
			MsgSetSelection (&msg, penFld, penPos, anchorFld, anchorPos);
			}

		PenGetPoint (&x, &y, &penDown);
		} while (penDown);

	MemHandleUnlock (msg.recordH);
	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    MsgCopySelectedField
 *
 * DESCRIPTION: This routine a selected message field to the passed handle.
 *
 * PARAMETERS:  msg            - structure containing message info
 *              selectField    - type of the field to copy
 *              destH          - handle to copy to
 *              srcP           - text of the message field to copy
 *              appendLinefeed - true 
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/2/96	Initial Revision
 *
 ***********************************************************************/
static Boolean MsgCopySelectedField (MessegeInfoPtr msg, MsgSelectFieldType selectField,
			VoidHand destH, CharPtr srcP, Boolean appendLinefeed)
{
	Err err;
	Word size;
	Word newSize;
	Word length = 0;
	Word endPos;
	Word startPos;
	CharPtr destP;
	Boolean truncated = false;

	if (srcP)
		{
		if (selectField == msg->selectStartField)
			startPos = msg->selectStartPos;
		else 
			startPos = 0;
			
		if (selectField == msg->selectEndField)
			endPos = msg->selectEndPos;
		else
			endPos = StrLen (srcP);

		length = endPos - startPos;
		}


	size = MemHandleSize (destH);

	if (size + length > maxCopyLength)
		{
		length = maxCopyLength - size;
		truncated = true;
		}
	
	newSize = size + length;
	if (appendLinefeed)
		newSize++;
	 
	err = MemHandleResize (destH, newSize);
	if (err) return (true);
	
	destP = MemHandleLock (destH);
	destP += size-1;
	if (srcP)
		{
		MemMove (destP, srcP+startPos, length);
		destP += length;
		}
	
	// Add a linefeed to the end of the string.
	if (appendLinefeed)
		{
		*destP = linefeedChr;
		destP++;
		}

	// Null terminate the string.
	*destP = 0;
	MemHandleUnlock (destH);
	
	return (truncated);
}


/***********************************************************************
 *
 * FUNCTION:    MsgCopy
 *
 * DESCRIPTION: This routine copies the current selection to the clipboard.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/2/96	Initial Revision
 *
 ***********************************************************************/
void MsgCopy (void)
{
	CharPtr ptr;
	VoidHand resH = 0;
	VoidHand destH;
	Boolean appendLinefeed;
	Boolean truncated = false;
	MsgFieldType topField;
	MessegeInfoType msg;
	MsgSelectFieldType selectField;

	if (MessageSelectStartField == msgSelectNone)
		return;

	// Allocate a handle just large enough to hold a null-terminator.
	destH = MemHandleNew (1);
	if (! destH) return;
	
	ptr = MemHandleLock (destH);
	*ptr = 0;
	MemPtrUnlock (ptr);


	if (ShowFullHeader)
		topField = msgFieldTo;
	else
		topField = msgFieldSentTo;

	MsgInit (&msg, topField, 0);

	while (true)
		{
		if (msg.fieldText && *msg.fieldText)
			{
			for (selectField = msg.selectStartField; 
				  selectField <= msg.selectEndField; selectField++)
				{
				if (MsgSelectFieldVisible (&msg, selectField))
					{
					if (MsgIsLableField (selectField))
						{
						resH = MsgGetHeaderLabel (msg.fieldType, 
							(MailAddressingType) msg.record.flags.addressing);
						ptr = MemHandleLock (resH);
						appendLinefeed = false;
						}
					else
						{
						ptr = msg.fieldText + msg.fieldTextPos;
						switch (selectField)
							{
							case msgSelectSentTo:
							case msgSelectTo:
							case msgSelectFrom:
							case msgSelectSubject:
							case msgSelectCC:
							case msgSelectDate:
								appendLinefeed = (msg.selectEndField > selectField ||
									(msg.selectEndField == selectField &&
									msg.selectEndPos == StrLen (ptr)));
								break;
							default:
								appendLinefeed = false;
							}
						}
					
					if (MsgCopySelectedField (&msg, selectField, destH, ptr, appendLinefeed))
						truncated = true;

					if (resH)
						{
						MemHandleUnlock (resH);
						DmReleaseResource (resH);
						resH = 0;
						}
					}
				}
			}

		else if (msg.fieldType == msgFieldBlankLine && 
		         msg.selectStartField <= msgSelectBlankLine &&
		         msg.selectEndField >= msgSelectBlankLine)
			{
			if (MsgCopySelectedField (&msg, msgSelectBlankLine, destH, NULL, true))
				truncated = true;
			}

		if (! MsgNextField (&msg))
			break;
		}

	MemHandleUnlock (msg.recordH);


	ptr = MemHandleLock (destH);

	if (! truncated)
		ClipboardAddItem (clipboardText, ptr, StrLen (ptr));
	else
		FrmAlert (ClipboardLimitAlert);


	MemPtrFree (ptr);
}


/***********************************************************************
 *
 * FUNCTION:    MsgSelectAll
 *
 * DESCRIPTION: This routine selects an entire message.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/3/96	Initial Revision
 *
 ***********************************************************************/
void MsgSelectAll (void)
{
	FontID					currFont;
	Word						endPos;
	MessegeInfoType		msg;

	currFont = FntSetFont (MessageFont);

	MsgInit (&msg, MessageTopField, MessageScrollPos);
	
	// Cancel the existing selection
	MsgSetSelection (&msg, msgSelectNone, 0, msgSelectNone, 0);

	msg.fieldTextPos = MessageScrollPos;
	msg.fieldType = MessageTopField;
	msg.fieldText = MsgGetFieldPtr (&msg);

	endPos = StrLen (msg.record.body);
	MsgSetSelection (&msg, msgSelectSentToLabel, 0, msgSelectBody, endPos);

	MemHandleUnlock (msg.recordH);
	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    MsgChangeFont
 *
 * DESCRIPTION: This routine change the font used to display a mail message.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/96	Initial Revision
 *
 ***********************************************************************/
void MsgChangeFont (void)
{
	Word					pos;
	Word					length;
	Word					lineNumber;
	Word					linesToDraw;
	FontID				currFont;
	MessegeInfoType	msg;

	currFont = FntSetFont (MessageFont);

	MsgInit (&msg, MessageTopField, 0);

//set the view to the top of the current field
MsgPreviousField (&msg);
MsgNextField (&msg);
MessageScrollPos = 0;

	pos = 0;
	lineNumber = 0;
	linesToDraw = msg.bounds.extent.y / FntLineHeight ();
	
	while (lineNumber < linesToDraw)
		{
		length = MsgWordWrap (&msg);
		if (length)
			{
			msg.fieldTextPos += length;
			if (MessageTopField == msg.fieldType)
				{
				if (msg.fieldTextPos < MessageScrollPos)
					pos = msg.fieldTextPos;
				else if (msg.fieldTextPos == MessageScrollPos)
					{
					pos = msg.fieldTextPos;
					lineNumber++;
					}
				else
					lineNumber++;
				}
			else
				lineNumber++;
			}
		else if (msg.fieldType == msgFieldBlankLine)
			{
			lineNumber++;
			if (! MsgNextField (&msg))
				break;
			}
		else if (!MsgNextField (&msg))
			break;
		}
			
	MessageScrollPos = pos;

	MemHandleUnlock (msg.recordH);

	if (lineNumber < linesToDraw && pos != 0 &&
		 (MessageTopField != msgFieldTo || MessageTopField == msgFieldSentTo))
		{
		 MsgScroll (linesToDraw - lineNumber, up);
		}
	else
		{
		MsgErase ();
		MsgDraw ();
		}	

	FntSetFont (currFont);
}



