/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     Expense.h
 * AUTHOR:	 Art Lamb: August 22, 1996
 *
 * DECLARER: Expense
 *
 * DESCRIPTION:
 *	  This file defines the structures and routines of the Expense 
 *   Application
 *
 ***********************************************************************/

#include "ExpAttendees.h"
#include "ExpCurrency.h"
#include "ExpDB.h"
#include "ExpRsc.h"
#include "ExpLookup.h"


/***********************************************************************
 *
 * Constants
 *
 ***********************************************************************/
// Feature number of the sorted array of expense types
#define expFeatureNum					0
#define expRevFeatureNum				1

#define noExpenseType					255


// Update codes, used to determine how the views should be redrawn.

// ListView Update codes
#define updateRedrawAll					0x00
#define updateItemDelete				0x01
#define updateItemMove					0x02
#define updateItemChanged				0x04
#define updateCategoryChanged			0x08
#define updateGoTo						0x10
#define updateDisplayOptsChanged		0x20
#define updateCustomCurrencyChanged	0x40

// Details Dialog update codes.
#define updateAttendees					0x01

// Maximun number of currencies that appear in the currency popup list.
#define maxCurrenciesDisplayed		7


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
extern DmOpenRef			ExpenseDB;									// expense database
extern Word					CurrentRecord;								// record being edited
extern Boolean				ItemSelected;								// true if a list view item is selected
extern FontID				NoteFont;

extern Byte					Currencies [maxCurrenciesDisplayed];
extern Byte					CurrentCustomCurrency;					

extern Word					HomeCountry;

/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/
extern VoidPtr GetObjectPtr (Word objectID);
