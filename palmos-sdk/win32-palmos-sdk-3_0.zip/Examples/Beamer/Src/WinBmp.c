/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
 *
 * PROJECT:  Palm OS
 * FILE:     WinBmp.c
 * AUTHOR:	 Gavin Peacock Feb 24, 1998
 *
 *
 * ROUTINES:
 *		WinCreateBitmap
 *      WinCreateBitmapWindow
 *      WinDeleteBitmapWindow
 *
 * DESCRIPTION:
 *	  This file contains some Bitmap window routines.
 *    WARNING: these routines depend on internal window structures that
 *		may be subject to change.
 *
 **********************************************************************/
#include <Pilot.h>
#include "WinBmp.h"
#include <WindowNew.h>

/***********************************************************************
 *
 * FUNCTION:   WinCreateBitmap
 *
 * DESCRIPTION: This routine creates a new blank bitmap
 *
 * PARAMETERS:  width   	 width of the bitmap in pixels
 *              height  	 height of the bitmap in pixels
 *              compressed 	compressed or not
 *				depth		pixel depth of the bitmap
 *              error   	 pointer to any error encountered by this function
 *
 * RETURNED:    Handle to the new bitmap
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	7/2/96		Initial Revision
 *
 ***********************************************************************/
VoidHand WinCreateBitmap (short width, short height,
	Boolean compressed, Byte depth, Err *error)
{
	Word 		rowBytes;
	ULong 		size;
	BitmapPtr	bitmapP;
	Handle		bitmapH;

	//ErrFatalDisplayIf( ((width == 0) || (height == 0)), 
	//	"Invalid window size");

	*error = 0;
	
	if ((width == 0) || (height == 0))
	{	*error = memErrNotEnoughSpace;
		return NULL;
	}
	// Create a display buffer for the window.  Round the line width
	// up to an even word boundary. 
	// (width + (sizeof (Word) - 1)) / sizeof (Word) * bytes per Word.
	rowBytes = ((((width*depth)+15) >> 4) << 1);
	size = (rowBytes * height) + sizeof(BitmapType);
	
	bitmapH = MemHandleNew (size);
	if (! bitmapH)
		{
		*error = memErrNotEnoughSpace;
		return (NULL);
		}
	bitmapP = (BitmapPtr) MemHandleLock(bitmapH);	
		
	MemSet(bitmapP,size,0);  // erase it ...
	
	bitmapP->width = width;
	bitmapP->height = height;
	bitmapP->rowBytes = rowBytes;
	bitmapP->pixelSize = depth;
	bitmapP->version = 1;
	bitmapP->flags.compressed = compressed;
	// bitmapP->flags = flags; 

	MemHandleUnlock(bitmapH);
	return (bitmapH);
}

/***********************************************************************
 *
 * FUNCTION:    WinCreateBitmapWindow
 *
 * DESCRIPTION: This routine creates a window reference to a bitmap
 *				image. Thsi allows the normal window functions to be used
 *				to manipulate the bitmap image. The window is NOT added to 
 *				the window list. The bitmap must remain allocated while this
 *				window is in use. This window should only be deleted with 
 *				WinDeleteBitmapWindow.
 *
 * PARAMETERS:  bitmapP - pointer to the existing bitmap
 *
 * RETURNED:    handle to the new window
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			Gavin	2/24/98		Initial Revision
 *
 ***********************************************************************/
WinHandle WinCreateBitmapWindow (BitmapPtr bitmapP)
{
	WinHandle	winH;
	WinPtr 	winP;
	WinHandle 	drawWindow;
	WindowType*	drawWinP;
	GDeviceType *gDeviceP;
	Word		depth;
	BytePtr		bitsP;
	BitmapPtr	lastBitmapP;
	
	
	// Get the depth of the draw window so that we can search for the
	//  best depth in the source bitmap to use
	drawWinP = (WindowType*)DrawWindow;
	depth = drawWinP->gDeviceP->pixelSize;
	

	// Allocate the window and a buffer to hold its image.
	winH = MemPtrNew (sizeof (WindowType) + sizeof(GDeviceType));
	if (! winH) return (0);
	
	winP = WinGetWindowPointer (winH);
	// Initialize to zeros
	MemSet(winP, sizeof (WindowType) + sizeof(GDeviceType), 0);
	
	// Find the portion of the bitmap resource that has the best possible
	//  source depth
	lastBitmapP = bitmapP;
	do {
		if (bitmapP->version < 1) break;
		if (bitmapP->pixelSize == depth) break;
		if (bitmapP->pixelSize > depth) {bitmapP = lastBitmapP; break;}
		if (!bitmapP->nextDepthOffset) break;
		bitmapP = (BitmapPtr)((DWordPtr)bitmapP + bitmapP->nextDepthOffset);
		} while (1);
	

	// Fill in the device info
	gDeviceP = (GDevicePtr)(((BytePtr)winP) + sizeof(WindowType));
	gDeviceP->width = bitmapP->width;
	gDeviceP->height = bitmapP->height;
	bitsP = (BytePtr)(bitmapP + 1);
	if (bitmapP->flags.hasColorTable) {
		ColorTablePtr	cTableP;
		cTableP = (ColorTablePtr)bitsP;
		bitsP += cTableP->numEntries * sizeof(RGBColorType) + sizeof(cTableP->numEntries);
		}
	gDeviceP->baseAddr = bitsP;
	if (bitmapP->version >= 1)
		gDeviceP->pixelSize = bitmapP->pixelSize;
	else
		gDeviceP->pixelSize = 1;
	gDeviceP->rowBytes = bitmapP->rowBytes;
	
	
	// Fill in the window info
	winP->gDeviceP = gDeviceP;
	winP->windowFlags.offscreen = true;
	winP->gDeviceP->compressed = bitmapP->flags.compressed;
	
	//winP->windowBounds.topLeft.x = 0;
	//winP->windowBounds.topLeft.y = 0;
	winP->windowBounds.extent.x = bitmapP->width;
	winP->windowBounds.extent.y = bitmapP->height;

	//winP->frameType.word = 0;
	winP->gstate = &GState;
	//winP->nextWindow = 0;

	// copy these fields for compatibility
	winP->displayWidthV20 = gDeviceP->width;
	winP->displayHeightV20 = gDeviceP->height;
	winP->displayAddrV20 = gDeviceP->baseAddr;
	
	//winP->windowFlags.reserved = 0;
	
	drawWindow = DrawWindow;
	DrawWindow = winH;
	WinResetClip ();
	DrawWindow = drawWindow;
	
	return winH;
}

/***********************************************************************
 *
 * FUNCTION:    WinDeleteBitmapWindow
 *
 * DESCRIPTION: This routine frees memory used by a bitmap window. It does
 *				not delete the bitmap memory. This should ONLY be used with
 *				a window created with WinCreateBitmapWindow.
 *
 * PARAMETERS:  winHandle  handle of window to delete
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			Gavin   2/24/98		Initial Revision
 *
 ***********************************************************************/
void WinDeleteBitmapWindow(WinHandle winH)
{
	// make sure we do not have system references to this window
	if (winH==WinGetDrawWindow())
		WinSetDrawWindow(WinGetDisplayWindow());
	if (winH==WinGetActiveWindow())
		WinSetActiveWindow(0);
	MemPtrFree(winH);  // release the memory
}

/***********************************************************************
 *
 * FUNCTION:    WinGetImageSize
 *
 * DESCRIPTION: This routine returns the size of the image data referenced
 *				byte displayAddr
 *
 * PARAMETERS:  winHandle  handle of window to examine
 *
 * RETURNED:    size of data in bytes
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			Gavin   2/24/98		Initial Revision
 *
 ***********************************************************************/
ULong WinGetImageSize(WinHandle winH)
{
	WinPtr winP = WinGetWindowPointer(winH);
	if (winP->gDeviceP->compressed) 
		return *((WordPtr)winP->gDeviceP->baseAddr);
	else
		return winP->gDeviceP->rowBytes*winP->gDeviceP->height;
}

