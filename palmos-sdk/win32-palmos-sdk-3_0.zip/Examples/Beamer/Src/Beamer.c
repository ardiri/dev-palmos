/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
 *
 * PROJECT: Exchange System Test Application
 *
 * FILE: Beamer.c
 *
 *
 * DESCRIPTION: Sample application to demonstrate the various
 * 	features available.
 *
  *
 * REVISION HISTORY:
 * 	 6/5/97	Gavin Peacock		Initial version
 *
 **********************************************************************/
 
#include <Pilot.h>				// all the system toolbox headers
#include "Beamer_Res.h"			// application resource defines
#include "ExgMgr.h"				// object exchange functions
#include "WinBmp.h"

#define ChunkSize 		20			// memory block allocate size for receive
#define BeamerCreator	'Bemr' 		// Creator ID for ExgTest app
#define BitmapExt		"pbm"		// Palm Bitmap file extension
#define version30		0x03000000	// PalmOS 3.0 version number

#define DrawAreaTop		16			// Top of drawing area (leave room for title)
#define DrawAreaBottom	120			// Bottom of drawing area (room for buttons)

// This is used to work around a clipping bug in the PalmOS drawLine logic
#define BottomClip		DrawAreaTop+DrawAreaBottom  

/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static Err StartApplication(void);
static Boolean MainFormHandleEvent(EventPtr event);
static void EventLoop(void);

/***********************************************************************
 * Data type declarations
 **********************************************************************/
enum drawChoices {penChoice=0,eraserChoice};
				  
typedef enum drawChoices drawChoiceType;

/***********************************************************************
 * Global data
 **********************************************************************/
drawChoiceType 	curDrawChoice = penChoice;
RectangleType 	drawArea;

/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     Nothing.
 *
 ***********************************************************************/
static Err StartApplication(void)
{
	FormPtr	frm;

	ExgRegisterData(BeamerCreator,exgRegExtensionID,BitmapExt);
	
	// Initialize and draw the main memo pad form.
	frm = FrmInitForm(BeamerMainForm);	
	FrmSetActiveForm(frm);
	FrmDrawForm(frm);
	RctSetRectangle(&drawArea,0,DrawAreaTop,160,DrawAreaBottom);
	return 0;
}



/***********************************************************************
 *
 * FUNCTION:		ReceiveData
 *
 * DESCRIPTION:		Receives data into the output field using the Exg API
 *
 * PARAMETERS:		exgSocketP, socket from the app code
 *						 sysAppLaunchCmdExgReceiveData
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
static Err ReceiveData(ExgSocketPtr exgSocketP)
{
	Err err;
	Handle dataH;
	Word size;
	BytePtr dataP;
	Int len;
	Word dataLen = 0;
	
	if (exgSocketP->length)
		size = exgSocketP->length;
	else
		size = ChunkSize;  // allocate in chunks just as an example
							// could use data size from header if available
	dataH = MemHandleNew(size);  
	if (!dataH) return -1;  // 
	// This block needs to belong to the system since it could be disposed when apps switch
	MemHandleSetOwner(dataH,0);
	// accept will open a progress dialog and wait for your receive commands
	err = ExgAccept(exgSocketP);
	if (!err)
		{
		dataP = MemHandleLock(dataH);
		do {
			len = ExgReceive(exgSocketP,&dataP[dataLen],size-dataLen,&err);
			if (len && !err)
				{
				dataLen+=len;
				// resize block when we reach the limit of this one...
				if (dataLen >= size)
					{
					MemHandleUnlock(dataH);
					err = MemHandleResize(dataH,size+ChunkSize);
					dataP = MemHandleLock(dataH);
					if (!err) size += ChunkSize;
					}
				}
			}
		while (len && !err);   // reading 0 bytes means end of file....
		MemHandleUnlock(dataH);
		
		ExgDisconnect(exgSocketP,err); // closes transfer dialog
		
		if (!err)
			{
			exgSocketP->goToCreator = BeamerCreator;  // tell exgmgr to launch this app after receive...
			exgSocketP->goToParams.matchCustom = (DWord)dataH;
			}
		}
	// release memory if an error occured	
	if (err) MemHandleFree(dataH);
	return err;
}


/***********************************************************************
 *
 * FUNCTION:		SendData
 *
 * DESCRIPTION:	Sends data in the input field using the Exg API
 *
 * PARAMETERS:		none
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
static Err SendData(void)
{
	ExgSocketType exgSocket;
	WinHandle win;
	ULong size = 0;
	Err err = 0;
	VoidHand bmpH;
	BitmapPtr bmpP;
	
	bmpH = WinCreateBitmap(drawArea.extent.x,drawArea.extent.y,true,1,&err);
	if (err) return err;
	bmpP = (BitmapPtr)MemHandleLock(bmpH);
	// make a window reference to the bitmap
	win = WinCreateBitmapWindow(bmpP);
	if (!win) 
	{	MemHandleUnlock(bmpH);
		MemHandleFree(bmpH);
		return memErrNotEnoughSpace; // returns no error when out of memory!
	}
	
	// copy draw area into the bitmap
	WinCopyRectangle (WinGetDrawWindow(), win, &drawArea, 0, 0, scrCopy);
	// get the size of the actual image data
	size = WinGetImageSize(win) + sizeof(BitmapType);
	
	// now get rid of bitmap window (we don't need it anymore) 
	WinDeleteBitmapWindow(win);
	
 	// Is there data in the field?
	if (size)
		{
		// important to init structure to zeros...
		MemSet(&exgSocket,sizeof(exgSocket),0);
		exgSocket.description = "Beamer picture";
		exgSocket.name = "Beamer.pbm";
		exgSocket.length = size;
		exgSocket.target = BeamerCreator;
		err = ExgPut(&exgSocket);   // put data to destination
		if (!err)
			{
			ExgSend(&exgSocket,bmpP,size,&err);
			ExgDisconnect(&exgSocket,err);
			}
		}	
	// get rid of window and bitmap	
	MemHandleUnlock(bmpH);
	MemHandleFree(bmpH);
	return err;
}

/***********************************************************************
 *
 * FUNCTION:		GotoItem
 *
 * DESCRIPTION: 	Displays data referenced by GotoParam
 *
 * PARAMETERS:		standard goto parameters and launched flags
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
static Err GoToItem(GoToParamsPtr gtP,Boolean launched)
{
	WinHandle win;
	VoidHand  bmpH;
	BitmapPtr bmpP;
	RectangleType r;
	Err err = 0;
	
	// get bits that were stored in matchCustom field
	bmpH = (Handle)gtP->matchCustom;
	ErrFatalDisplayIf(!bmpH,"null bitmap on goto");
	
	bmpP = (BitmapPtr)MemHandleLock(bmpH);
	
	// make a window reference to the bitmap structure
	win = WinCreateBitmapWindow(bmpP);
	
	if (win) {
		// copy bitmap to draw area (and make sure it stays within the draw area)
		RctSetRectangle(&r,0,0,
			min(bmpP->width,drawArea.extent.x),min(bmpP->height,drawArea.extent.y));
		WinCopyRectangle (win,WinGetDrawWindow(), &r, drawArea.topLeft.x, drawArea.topLeft.y, scrCopy);
		// get rid of the bitmap window before releasing the bitmap
		WinDeleteBitmapWindow(win);
	} else
		err = memErrNotEnoughSpace;
	
	MemHandleFree(bmpH);  //  get rid of the bitmap now.
	return err;
}

/**********************************************************
***********************************************************/
static Boolean GetNextPoint(short *screenX, short *screenY)
{	Boolean penDown;
	SWord lastScreenX, lastScreenY;
	
	lastScreenX = *screenX;
	lastScreenY = *screenY;
	
 	do {
		/* should do filtering here... */
	  EvtGetPen(screenX,screenY,&penDown);
	} while (penDown &&
             (*screenX == lastScreenX) && (*screenY == lastScreenY));

	return(penDown);
}

// draw ink
static void DoPen(short screenX, short screenY)
{
	SWord lastScreenX, lastScreenY;
	
	lastScreenX = screenX;
	lastScreenY = screenY;
	do {
		
	  	// clip Y coordinate to avoid clipping bug in WinDrawLine
	  	// This doesn't clip, it just drops the whole line...
	  	if (screenY < BottomClip && lastScreenY < BottomClip)
			WinDrawLine(lastScreenX,lastScreenY,screenX,screenY);
		
		lastScreenX = screenX;
		lastScreenY = screenY;
	} while (GetNextPoint(&screenX,&screenY));
}

static void DoErase(short screenX, short screenY)
{
	// not implemented yet...
}


/***********************************************************************
 *
 * FUNCTION:		MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:		event	- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean		handled = false;
	RectangleType saveClip;

	
	switch (event->eType)
	{
		case penDownEvent:
				if (RctPtInRectangle(event->screenX,event->screenY,&drawArea) ) 
				{
					WinGetClip(&saveClip);
					WinSetClip(&drawArea);
  					
					switch (curDrawChoice)
					{
						case penChoice:
							DoPen( event->screenX,event->screenY);
							break;
						case eraserChoice:
							DoErase(event->screenX,event->screenY);
							break;
					}
					WinSetClip(&saveClip);
					handled = true;
				}
			break;
			
  		 case ctlSelectEvent:
	  	 	if (event->data.ctlEnter.controlID == BeamerMainSendButton)
				{
				SendData();
		 	 	}
	 		 else if (event->data.ctlEnter.controlID == BeamerMainClearButton)
	 		 	{
	 		 	WinEraseRectangle(&drawArea,0);
				}
			break;
			
		case menuEvent:	
			// The �get info� being the only menu item, display the info form.
			
			// First clear the menu status from the display.
			MenuEraseStatus(0);
			
			// display the info alert.
			FrmAlert(InfoAlert);
			handled = true;
			break;

      	case keyDownEvent:
      		// handle the send data (ronamatic stroke) chr
      		if (event->data.keyDown.chr == sendDataChr)
  				{
           		SendData();
           		handled = true;
           		}	
           	break;
            
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:		EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *						Manager and passes them on to various applications and
 *						system event handlers before passing them on to
 *						FrmHandleEvent for default processing.
 *
 * PARAMETERS:		None.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType	event;
	Word		error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent (&event))

			// Give the menu a chance to handle the event
			if (! MenuHandleEvent(0, &event, &error))

				// Give the application a chance to handle the event.
				if (! MainFormHandleEvent(&event))

					// Let the form object provide default handling of the event.
					FrmHandleEvent(FrmGetActiveForm(), &event);
		} 
	while (event.eType != appStopEvent);
}

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check that the ROM version meets your
 *              minimum requirement.  Warn if the app was switched to.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags indicating how the application was
 *											 launched.  A warning is displayed only if
 *                                these flags indicate that the app is 
 *											 launched normally.
 *
 * RETURNED:    zero if rom is compatible else an error code
 *                             
 ***********************************************************************/
static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;
	
	
	// See if we're on in minimum required version of the ROM or later.
	// The system records the version number in a feature.  A feature is a
	// piece of information which can be looked up by a creator and feature
	// number.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		// If the user launched the app from the launcher, explain
		// why the app shouldn't run.  If the app was contacted for something
		// else, like it was asked to find a string by the system find, then
		// don't bother the user with a warning dialog.  These flags tell how
		// the app was launched to decided if a warning should be displayed.
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.  The sysFileCDefaultApp is considered "safe".
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:		PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *						in standard �C�.  It is called by the Emulator to begin
 *						execution of this application.
 *
 * PARAMETERS:		cmd - command specifying how to launch the application.
 *						cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:		Any applicable error code.
 *
 ***********************************************************************/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
	DWord err = 0;
	
	// This app makes use of PalmOS 3.0 features.  It will crash if
	// run on an earlier version of PalmOS.  Detect and warn if this happens,
	// then exit.
	err = RomVersionCompatible (version30, launchFlags);
	if (err)
		return err;

	// Check for a normal launch.
	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		// Set up initial form.
		err = StartApplication();
			
		// Start up the event loop.
		EventLoop();
		}
	else if (cmd == sysAppLaunchCmdSyncNotify)
		{
		// register our extension on syncNotify so we do not need to
		// be run before we can receive data.
		ExgRegisterData(BeamerCreator,exgRegExtensionID,BitmapExt);
		}
	else if (cmd == sysAppLaunchCmdExgAskUser)
		{
		ExgAskParamPtr paramP = (ExgAskParamPtr)cmdPBP;
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
		Boolean appIsActive = launchFlags & sysAppLaunchFlagSubCall;
    	if (!appIsActive)
    		{
    		// app is not currently running, so
      		// pop up dialog here asking if user wants to get data
    		if ( FrmAlert(AskAlert) == AskYes)
    			paramP->result = exgAskOk;
    		else
    			paramP->result = exgAskCancel;
    		}
    	else
    		{ // app is running so always autoconfirm the ask dialog
    		paramP->result = exgAskOk;
    		}
		}
	else if (cmd == sysAppLaunchCmdExgReceiveData)
		{
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
		Boolean appIsActive = launchFlags & sysAppLaunchFlagSubCall;
    	if (!appIsActive)
    		{
    		// if this test passses,
    		// your app is NOT running,so you cannot use app globals
    		}
		err = ReceiveData((ExgSocketPtr)cmdPBP);
		}
	else if (cmd == sysAppLaunchCmdGoTo)
    	{
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
       	Boolean launched;
        
        
        launched = launchFlags & sysAppLaunchFlagNewGlobals;

        if (launched) 
        	{
           err = StartApplication ();
           if (err) 
              return (err);
        	}

        GoToItem((GoToParamsPtr)cmdPBP, launched);

        if (launched) 
        	{
           	EventLoop ();
          	// StopApplication ();   
        	}      
         }
	
	return(err);
}



