/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     DateDisplay.c
 * AUTHOR:	 Art Lamb: July 17, 1996
 *
 * DECLARER: Datebook
 *
 * DESCRIPTION:
 *	  This module contains the routines that handle the Datebook 
 *   applications's display optiions.
 *
 **********************************************************************/

#include <Pilot.h>
#include "Datebook.h"


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static VoidPtr GetObjectPtr (Word objectID)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm ();
	return (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objectID)));

}

/***********************************************************************
 *
 * FUNCTION:    DisplayOptionsApply
 *
 * DESCRIPTION: This routine applies the changes made in the Display
 *              Options Dialog.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/17/95	Initial Revision
 *
 ***********************************************************************/
static Word DisplayOptionsApply (void)
{	
	Word updateCode = 0;
	Boolean on;
		
	// Get the "Show Time Bars" setting.
	on = (CtlGetValue (GetObjectPtr (DisplayShowTimeBarsCheckbox)) != 0);
	if (on != ShowTimeBars)
		{
		ShowTimeBars = on;
		updateCode = updateDisplayOptsChanged;
		}		

	// Get the "Compress Day View" setting.
	on = (CtlGetValue (GetObjectPtr (DisplayCompressDayViewCheckbox)) != 0);
	if (on != CompressDayView)
		{
		CompressDayView = on;
		updateCode = updateDisplayOptsChanged;
		}		

	// Get the "Show Timed Events" setting
	on = (CtlGetValue (GetObjectPtr (DisplayShowTimedCheckbox)) != 0);
	if (on != ShowTimedAppts)
		{
		ShowTimedAppts = on;
		updateCode = updateDisplayOptsChanged;
		}		

	// Get the "Show Untimed Events" setting
	on = (CtlGetValue (GetObjectPtr (DisplayShowUntimedCheckbox)) != 0);
	if (on != ShowUntimedAppts)
		{
		ShowUntimedAppts = on;
		updateCode = updateDisplayOptsChanged;
		}		

	// Get the "Show Daily repeating Events" setting
	on = (CtlGetValue (GetObjectPtr (DisplayShowRepeatingCheckbox)) != 0);
	if (on != ShowDailyRepeatingAppts)
		{
		ShowDailyRepeatingAppts = on;
		updateCode = updateDisplayOptsChanged;
		}		

	return (updateCode);
}


/***********************************************************************
 *
 * FUNCTION:    DisplayOptionsInit
 *
 * DESCRIPTION: This routine initializes the DisplayOptions Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/17/96	Initial Revision
 *
 ***********************************************************************/
static void DisplayOptionsInit (void)
{
	// Set the "Show Time Bars" setting.
	CtlSetValue (GetObjectPtr (DisplayShowTimeBarsCheckbox), ShowTimeBars);

	// Set the "Compress Day View" setting.
	CtlSetValue (GetObjectPtr (DisplayCompressDayViewCheckbox), CompressDayView);
	
	// Set the "Show Timed Events" setting
	CtlSetValue (GetObjectPtr (DisplayShowTimedCheckbox), ShowTimedAppts);
	
	// Set the "Show Untimed Events" setting
	CtlSetValue (GetObjectPtr (DisplayShowUntimedCheckbox), ShowUntimedAppts);

	// Set the "Show Daily repeating Events" setting
	CtlSetValue (GetObjectPtr (DisplayShowRepeatingCheckbox), ShowDailyRepeatingAppts);
	}


/***********************************************************************
 *
 * FUNCTION:    DisplayOptionsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Display Options
 *              Dialog Box".
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/17/96	Initial Revision
 *
 ***********************************************************************/
Boolean DisplayOptionsHandleEvent (EventPtr event)
{
	Word updateCode;
	FormPtr frm;
	Boolean handled = false;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case DisplayOkButton:
				updateCode = DisplayOptionsApply ();
				FrmReturnToForm (0);
				if (updateCode)
					FrmUpdateForm (FrmGetFormId (FrmGetActiveForm()), updateCode);
				handled = true;
				break;

			case DisplayCancelButton:
				FrmReturnToForm (0);
				handled = true;
				break;
			}
		}


	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		DisplayOptionsInit ();
		FrmDrawForm (frm);
		handled = true;
		}

	return (handled);
}

