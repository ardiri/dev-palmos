
// Day View
#define DayView								1000
#define DayTitle								1001
#define DayPrevWeekButton					1002
#define DayDOW1Button						1003		// first day of week push button
#define DayDOW2Button						1004		// second day of week push button
#define DayDOW3Button						1005
#define DayDOW4Button						1006
#define DayDOW5Button						1007
#define DayDOW6Button						1008
#define DayDOW7Button						1009
#define DayNextWeekButton					1010
#define DayDayViewButton					1012
#define DayWeekViewButton					1013
#define DayMonthViewButton					1014
#define DayNewButton							1015
#define DayDetailsButton					1016
#define DayGoToButton						1017
#define DayUpButton							1018
#define DayDownButton						1019
#define DayTable								1020
#define DayOfWeekGroup						1
#define DayViewGroup							2


// Week View
#define WeekView								1100
#define WeekPrevButton						1102
#define WeekNextButton						1103
#define WeekNumberLabel						1104
#define WeekDayViewButton					1106
#define WeekWeekViewButton					1107
#define WeekMonthViewButton				1108
#define WeekGoToButton						1109
#define WeekUpButton							1110
#define WeekDownButton						1111
#define WeekDayDisplay						1112


// Month View 
#define MonthView								1200
#define MonthPrevButton						1202
#define MonthNextButton						1203
#define MonthDayViewButton					1205
#define MonthWeekViewButton				1206
#define MonthMonthViewButton				1207
#define MonthGoToButton						1208
#define MonthGadget							1209


// Details Dialog Box
#define DetailsDialog						1300
#define DetailsTimeSelector				1303
#define DetailsDateSelector				1305
#define DetailsAlarmCheckbox				1307
#define DetailsAlarmAdvanceField			1308
#define DetailsAlarmAdvanceSelector		1310
#define DetailsAlarmAdvanceList			1311
#define DetailsRepeatSelector				1313
#define DetailsPrivateCheckbox			1315
#define DetailsOkButton						1316
#define DetailsCancelButton				1317
#define DetailsDeleteButton				1318
#define DetailsNoteButton					1319


// Repeat Dialog Box.
// Note: the code is depends on the current order of the ui object.
#define RepeatDialog							1400
#define RepeatNone							1402
#define RepeatDaily							1403
#define RepeatWeekly							1404
#define RepeatMonthly						1405
#define RepeatYearly							1406
#define RepeatEveryLabel					1407
#define RepeatFrequenceField				1408
#define RepeatDaysLabel						1409
#define RepeatWeeksLabel					1410
#define RepeatMonthsLabel					1411
#define RepeatYearsLabel					1412
#define RepeatEndOnLabel					1413
#define RepeatEndOnTrigger					1415
#define RepeatEndOnList						1416
#define RepeatRepeatOnLabel				1417
#define RepeatDayOfWeek1PushButton		1418
#define RepeatDayOfWeek2PushButton		1419
#define RepeatDayOfWeek3PushButton		1420
#define RepeatDayOfWeek4PushButton		1421
#define RepeatDayOfWeek5PushButton		1422
#define RepeatDayOfWeek6PushButton		1423
#define RepeatDayOfWeek7PushButton		1424
#define RepeatByLabel						1425
#define RepeatByDayPushButon				1426
#define RepeatByDatePushButon				1427
#define RepeatDescField						1428
#define RepeatNoRepeatLabel				1429
#define RepeatOkButton						1430
#define RepeatCancelButton					1431
#if COUNTRY == COUNTRY_FRANCE
#define RepeatEveryWeekLabel				1432
#endif
#define RepeatTypeGroup						1
#define RepeatByGroup						2

// Purge Dialog
#define PurgeDialog							1500
#define PurgeRangeList						1506
#define PurgeSaveBackup						1507
#define PurgeOk								1508
#define PurgeCancel							1509


// Delete Appt Dialog
#define DeleteApptDialog					1600
#define DeleteApptSaveBackup				1604
#define DeleteApptOk							1606
#define DeleteApptCancel					1607


// Monthly Repeat Dialog
#define MonthlyRepeatDialog				1700
#define MonthlyRepeatFourthButton		1704
#define MonthlyRepeatLastButton			1705
#define MonthlyRepeatOk						1706
#define MonthlyRepeatCancel				1707
#define MonthlyRepeatWeekGroup			1


// Preference Dialog
#define PreferencesDialog					1800
#define PreferStartUpButton				1803
#define PreferStartDownButton				1804
#define PreferEndUpButton					1806
#define PreferEndDownButton				1807
#define PreferAlarmCheckbox				1809
#define PreferAlarmField					1810
#define PreferAlarmUnitTrigger			1812
#define PreferAlarmList						1813
#define PreferOkButton						1814
#define PreferCancelButton					1815
#define PreferAlarmSoundTrigger			1817
#define PreferAlarmSoundList				1818
#define PreferRemindMeTrigger				1819
#define PreferRemindMeList					1820
#define PreferPlayEveryTrigger			1821
#define PreferPlayEveryList				1822


// Display Options Dialog
#define DisplayDialog						1900
#define DisplayShowTimeBarsCheckbox		1903
#define DisplayCompressDayViewCheckbox	1904
#define DisplayShowTimedCheckbox			1906
#define DisplayShowUntimedCheckbox		1907
#define DisplayShowRepeatingCheckbox	1908
#define DisplayOkButton						1909
#define DisplayCancelButton				1910


// Alarm Dialog
#define AlarmDialog							2000
#define AlarmDescGadget						2004


// Delete Note Alert
#define DeleteNoteAlert						2001
#define DeleteNoteYes						0
#define DeleteNoteNo             		1

// Select An Item Alert
#define SelectItemAlert						2002

// Excetion Alert
#define ExceptionAlert						2003
#define ExceptionCurrentButton			0
#define ExceptionAllButton					1
#define ExceptionCancelButton				2

// Attach note to a repeating appointment Alert
#define RepeatAddNoteAlert					2004
#define RepeatAddNoteCurrentButton		0
#define RepeatAddNoteAllButton			1
#define RepeatAddNoteCancelButton		2

// Delete note attached a repeating appointment Alert
#define RepeatDeleteNoteAlert				2005
#define RepeatDeleteNoteCurrentButton	0
#define RepeatDeleteNoteAllButton		1
#define RepeatDeleteNoteCancelButton	2

// Repeat type changed Alert
#define RepeatTypeChangedAlert			2006
#define RepeatTypeChangedOkButton		0
#define RepeatTypeChangedCancelButton	1


// Bitmaps
#define AlarmClockBitmap					1000

// Menus
#define DayViewMenu							1000
#define NoteViewMenu							1001
#define WeekViewMenu							1002

// Menu commands
#define NewItemCmd							100
#define DeleteCmd								101
#define CreateNoteCmd						102
#define DeleteNoteCmd						103
#define PurgeCmd								104
#define SendRecordCmd						105
#define UndoCmd								200
#define CutCmd									201
#define CopyCmd								202
#define PasteCmd								203
#define KeyboardCmd							205

#define DayFontsCmd							300
#define DayPreferencesCmd					301
#define DayDisplayOptionsCmd				302
#define DayPhoneLookup						303
#define DayGetInfoCmd						304

#define WeekPreferencesCmd					300
#define WeekGetInfoCmd						301

#define MonthPreferencesCmd				300
#define MonthDisplayOptionsCmd			301
#define MonthGetInfoCmd						302


// Strings
#define findDatebookHeaderStrID			100	// Find results section header
#define goToDateTitleStrID					101	// Date picker title
#define setTimeTitleStrID					102	// Time picker title
#define startDateTitleStrID				103	// Date picker title for selecting appt's date
#define endDateTitleStrID					104	// Date picker title for selecting repeat end date
#define daysOfWeekInitialsStrID			105	// Initials of the days of the week names	
#define noTimeStrID							126   // No time
#define repeatTypesStrID					127	// Names of repeat types.
#define dailyRepeatStrID					128	// description template
#define weeklyRepeat1DayStrID				129	// repeat description template
#define weeklyRepeat2DayStrID				130	// repeat description template
#define weeklyRepeat3DayStrID				131	// repeat description template
#define weeklyRepeat4DayStrID				132	// repeat description template
#define weeklyRepeat5DayStrID				133	// repeat description template
#define weeklyRepeat6DayStrID				134	// repeat description template
#define weeklyRepeat7DayStrID				135	// repeat description template
#define monthtlByDayRepeatStrID			136	// repeat description template
#define monthtlByDateRepeatStrID			137	// repeat description template
#define yearlyRepeatStrID					138	// repeat description template
#define freqOrdinalsStrID					139	// other, 2nd, ..., 99st
#define weekOrdinalsStrID					140	// 1st, 2nd, 3rd, 4th, and last
#define beamDescriptionStrID				1000
#define beamFilenameStrID					1001

// MIDI resources
#define midiRsc		'tmid'

#define	sound0Mid						128
#define	sound1Mid						129
#define	sound2Mid						130
#define	sound3Mid						131
#define	sound4Mid						132
#define	sound5Mid						133
#define	sound6Mid						134

#define dayOrdinalsStrID					141	// 1st - 31st
#define repeatNoneStrID						142	// repeat description


