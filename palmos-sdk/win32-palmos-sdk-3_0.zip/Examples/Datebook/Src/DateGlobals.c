/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     DateGlobals.c
 * AUTHOR:	 Art Lamb: June 12, 1995
 *
 * DECLARER: Datebook
 *
 * DESCRIPTION:
 *	  Because of a bug in Metrowerks, we must compile the globals separately with
 *		PC-relative strings turned off. Otherwise, we get linker errors with
 *		pre-initialized structures.
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			frigino	9/9/97	Added initial values to AlarmSoundXXXX vars
 *
 **********************************************************************/

#include <Pilot.h>

#define	NON_PORTABLE
#include <MemoryPrv.h>

#include "Datebook.h"

/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
VoidHand				ApptsOnlyH;
Word					NumApptsOnly;
VoidHand				ApptsH;
Word					NumAppts;

DmOpenRef			ApptDB;									// datebook database
DateType				Date = { 91, 7, 31 };				// date currently displayed
TimeFormatType		TimeFormat;
DateFormatType		LongDateFormat;
DateFormatType		ShortDateFormat;
Word					TopVisibleAppt;
Boolean				HideSecretRecords;					// true if serect records are hidden
Boolean				NoteUpScrollerVisible;				// true if note can be scroll up
Boolean				NoteDownScrollerVisible;			// true if note can be scroll up
Word					PendingUpdate = 0;					// code of pending day view update

// The following global variables are used to keep track of the edit
// state of the application.
Word					DayEditPosition = 0;					// position of the insertion point in the desc field
Word					DayEditSelectionLength;				// length of the current selection.
Word					CurrentRecord = -1;					// record being edited
Boolean				ItemSelected = false;				// true if a day view item is selected
Boolean				RecordDirty = false;					// true if a record has been modified


// The following global variable are only valid while editng the detail
// of an appointment.
VoidHand				DetailsH;
DateType				RepeatEndDate;
RepeatType			RepeatingEventType;

// The following global variable are saved to a state file.
Word					DayStartHour = defaultDayStartHour;	// start of the day 8:00am
Word					DayEndHour = defaultDayEndHour;		// end of the day 6:00pm
Word					StartDayOfWeek = sunday;
Word					RepeatStartOfWeek = sunday;		//	status of Repeat Dialog
FontID				NoteFont = defaultNoteFont;		// font used in note view
AlarmInfoType		AlarmPreset = { defaultAlarmPresetAdvance, defaultAlarmPresetUnit };
Boolean				SaveBackup = defaultSaveBackup;				// default setting "Backuo tp PC" checkbox
Boolean				ShowTimeBars = defaultShowTimeBars;			// show time bars in the day view
Boolean				CompressDayView = defaultCompressDayView;	// remove empty time slot to prevent scrolling
Boolean				ShowTimedAppts = defaultShowTimedAppts;	// show timed appointments in month view
Boolean				ShowUntimedAppts = defaultShowUntimedAppts;	// show untimed appointments in month view
Boolean				ShowDailyRepeatingAppts = defaultShowDailyRepeatingAppts;	// show daily repeating appointments in month view

#if 0		// moved to DatePref.c	vmk 12/9/97
	// The following global variable are only valid while editng the datebook's
	// preferences.
	Word					PrefDayStartHour;
	Word					PrefDayEndHour;
#endif

// The following global variable is used to control the behavior Datebook
// Hard Button when pressed from the week view.  If no pen or key event 
// when occurred since enter the Week View then pressing the Datebook button
// will nagivate to the Month View, otherwise we go the the Day View of Today.
Boolean				EventInWeekView;


Word					TimeBarColumns;						// Number of columns of time bars.


// The following global variable is used to control the displaying of the
// current time in the title of a view.
Boolean				TimeDisplayed = false;				// True if time in been displayed
ULong					TimeDisplayTick;						// Tick count when we stop showing time

// Table of far calls used to avoid the 32k relative jump limitation.
FarCallsType		FarCalls;

// The following globals are for the repeat rates of the alarms.
																		// number of times to repeat alarm sound 
UInt					AlarmSoundRepeatCount = defaultAlarmSoundRepeatCount;
																		
																		// interval between repeat sounds, in seconds
UInt					AlarmSoundRepeatInterval = defaultAlarmSoundRepeatInterval;

																		// Alarm sound MIDI file unique ID record identifier
ULong					AlarmSoundUniqueRecID = defaultAlarmSoundUniqueRecID;


FontID				ApptDescFont = defaultApptDescFont;	// font for drawing event description.

