/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *****************************************************************************
 * FileName:
 *		ToDoDB.c
 *
 * Description:
 *		To Do Manager routines
 *
 * History:
 *   	1/20/95  rsf - Created
 *
 *******************************************************************/


// Set this to get to private database defines
#define __TODOMGR_PRIVATE__

#include <Pilot.h>
#include "ToDoDB.h"

// Export error checking routines
void ECToDoDBValidate(DmOpenRef dbP);


/************************************************************
 * Private routines used only in this module
 *************************************************************/


/************************************************************
 *
 *  FUNCTION: ECToDoDBValidate
 *
 *  DESCRIPTION: This routine validates the integrity of the to do
 *		datebase.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: nothing
 *
 *  CREATED: 6/22/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

#define maxDescLen	256
#define maxNoteLen	4000

void ECToDoDBValidate (DmOpenRef dbP)
{
	UInt i;
	UInt size;
	UInt cLen;
	UInt recSize;
	UInt descLen;
	UInt noteLen;
	UInt numRecord;
	UInt priority;
	CharPtr c;
	CharPtr note;
	VoidHand recH;
	ToDoDBRecordPtr rec;
	
	numRecord = DmNumRecords (dbP);
	for (i = 0 ; i < numRecord; i++)
		{
		recH = DmQueryRecord (dbP, i);
		if (! recH) continue;

		rec = MemHandleLock (recH);
		
		priority = rec->priority & priorityOnly;
		ErrFatalDisplayIf (priority > toDoMaxPriority,  "DB integrity error");
		
		descLen = StrLen (&rec->description);
		ErrFatalDisplayIf (descLen > maxDescLen, "DB integrity error");

		note = &rec->description + descLen + 1;
		noteLen = StrLen (note);
		ErrFatalDisplayIf (descLen > maxNoteLen, "DB integrity error");
		
		// Validate the record size.
		size = sizeof (DateType) + 1;
		c = &rec->description;
		cLen = StrLen(c) + 1;
		size += cLen;
		c += cLen;
		size += StrLen(c) + 1;
		recSize = MemPtrSize (rec);
		ErrFatalDisplayIf ( (recSize != size), "DB integrity error");

		MemPtrUnlock (rec);
		}
}
#endif

/************************************************************
 *
 *  FUNCTION: DateTypeCmp
 *
 *  DESCRIPTION: Compare two dates
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 
 *
 *  CREATED: 1/20/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static Int DateTypeCmp(DateType d1, DateType d2)
{
	Int result;
	
	result = d1.year - d2.year;
	if (result != 0)
		{
		if ((*(int *) &d1) == -1)
			return 1;
		if ((*(int *) &d2) == -1)
			return -1;
		return result;
		}
	
	result = d1.month - d2.month;
	if (result != 0)
		return result;
	
	result = d1.day - d2.day;

	return result;

}


/************************************************************
 *
 *  FUNCTION: CategoryCompare
 *
 *  DESCRIPTION: Compare two categories
 *
 *  PARAMETERS:  attr1, attr2 - record attributes, which contain 
 *						  the category. 
 *					  appInfoH - handle of the applications category info
 *
 *  RETURNS: 0 if they match, non-zero if not
 *				 + if s1 > s2
 *				 - if s1 < s2
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/5/96	Initial Revision
 *
 *************************************************************/
static Int CategoryCompare (Byte attr1, Byte attr2, VoidHand appInfoH)
{
	Int result;
	Byte category1;
	Byte category2;
	ToDoAppInfoPtr appInfoP;
	
	
	category1 = attr1 & dmRecAttrCategoryMask;
	category2 = attr2 & dmRecAttrCategoryMask;

	result = category1 - category2;
	if (result != 0)
		{
		if (category1 == dmUnfiledCategory)
			return (1);
		else if (category2 == dmUnfiledCategory)
			return (-1);
		
		appInfoP = MemHandleLock (appInfoH);
		result = StrCompare (appInfoP->categoryLabels[category1],
									appInfoP->categoryLabels[category2]);

		MemPtrUnlock (appInfoP);
		return result;
		}
	
	return result;
}


/************************************************************
 *
 *  FUNCTION: ToDoAppInfoInit
 *
 *  DESCRIPTION: Create an app info chunk if missing.  Set
 *		the strings to a default.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 1/20/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err	ToDoAppInfoInit(DmOpenRef dbP)
{
	UInt cardNo;
	UInt wordValue;
	VoidHand h;
	LocalID dbID;
	LocalID appInfoID;
	ToDoAppInfoPtr	nilP = 0;
	ToDoAppInfoPtr appInfoP;
	
	if (DmOpenDatabaseInfo(dbP, &dbID, NULL, NULL, &cardNo, NULL))
		return dmErrInvalidParam;

	if (DmDatabaseInfo(cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, 
		 NULL, &appInfoID, NULL, NULL, NULL))
		return dmErrInvalidParam;
	
	if (appInfoID == NULL)
		{
		h = DmNewHandle(dbP, sizeof (ToDoAppInfoType));
		if (! h) return dmErrMemError;

		appInfoID = MemHandleToLocalID (h);
		DmSetDatabaseInfo(cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, 
			NULL, &appInfoID, NULL, NULL, NULL);
		}
	
	appInfoP = MemLocalIDToLockedPtr(appInfoID, cardNo);

	// Clear the app info block.
	DmSet (appInfoP, 0, sizeof(ToDoAppInfoType), 0);

	// Initialize the categories.
	CategoryInitialize ((AppInfoPtr) appInfoP, LocalizedAppInfoStr);

	// I don't know what this field is used for.
	wordValue = 0xFFFF;
	DmWrite (appInfoP, (ULong)&nilP->dirtyAppInfo, &wordValue,
		sizeof(appInfoP->dirtyAppInfo));

	// Initialize the sort order.
	DmSet (appInfoP, (ULong)&nilP->sortOrder, sizeof(appInfoP->sortOrder), 
		soPriorityDueDate);

	MemPtrUnlock (appInfoP);

	return 0;
}


/************************************************************
 *
 *  FUNCTION: ToDoGetAppInfo
 *
 *  DESCRIPTION: Get the app info chunk 
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS: handle to the to do application info block (ToDoAppInfoType)
 *
 *  CREATED: 5/12/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
VoidHand ToDoGetAppInfo (DmOpenRef dbP)
{
	Err error;
	UInt cardNo;
	LocalID dbID;
	LocalID appInfoID;
	
	error = DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL);
	ErrFatalDisplayIf (error,  "Get getting to do app info block");

	error = DmDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL, 
			NULL, NULL, &appInfoID, NULL, NULL, NULL);
	ErrFatalDisplayIf (error,  "Get getting to do app info block");

	return ((VoidHand) MemLocalIDToGlobal (appInfoID, cardNo));
}


/************************************************************
 *
 *  FUNCTION: ToDoGetSortOrder
 *
 *  DESCRIPTION: This routine gets the sort order value from the 
 *               'to do' application info block.
 *
 *  PARAMETERS: database pointer
 *
 *  RETURNS:    true - if the 'to do' record are sorted by priority, 
 *              false - if the records are sorted by due date.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/12/95	Initial Revision
 *       art	3/22/96	Rename routine and added more sort orders
 *
 *************************************************************/
Byte ToDoGetSortOrder (DmOpenRef dbP)
{
	Byte sortOrder;
	ToDoAppInfoPtr appInfoP;
			
	appInfoP = MemHandleLock (ToDoGetAppInfo (dbP));
	sortOrder = appInfoP->sortOrder;
	MemPtrUnlock (appInfoP);	

	return (sortOrder);
}


/************************************************************
 *
 *  FUNCTION: ToDoCompareRecords
 *
 *  DESCRIPTION: Compare two records.
 *
 *  PARAMETERS: database record 1
 *				database record 2
 *
 *  RETURNS: -n if record one is less (n != 0)
 *			  n if record two is less
 *
 *  CREATED: 1/23/95 
 *
 *  BY: Roger Flores
 *
 *	COMMENTS:	Compare the two records key by key until
 *	there is a difference.  Return -n if r1 is less or n if r2
 *	is less.  A zero is never returned because if two records
 *	seem identical then their unique IDs are compared!
 *
 * This function accepts record data chunk pointers to avoid
 * requiring that the record be within the database.  This is
 * important when adding records to a database.  This prevents
 * determining if a record is a deleted record (which are kept
 * at the end of the database and should be considered "greater").
 * The caller should test for deleted records before calling this
 * function!
 *
 *************************************************************/
 
static Int ToDoCompareRecords(ToDoDBRecordPtr r1, 
	ToDoDBRecordPtr r2, Int sortOrder, 
	SortRecordInfoPtr info1, SortRecordInfoPtr info2,
	VoidHand appInfoH)
{
	Int result;

	// Sort by priority, due date, and category.
	if (sortOrder == soPriorityDueDate)
		{
		result = (r1->priority & priorityOnly) - (r2->priority & priorityOnly);
		if (result == 0)
			{
			result = DateTypeCmp (r1->dueDate, r2->dueDate);
			if (result == 0)
				{
				result = CategoryCompare (info1->attributes, info2->attributes, appInfoH);
				}
			}
		}

	// Sort by due date, priority, and category.
	else if (sortOrder == soDueDatePriority)
		{
		result = DateTypeCmp(r1->dueDate, r2->dueDate);
		if (result == 0)
			{
			result = (r1->priority & priorityOnly) - (r2->priority & priorityOnly);
			if (result == 0)
				{
				result = CategoryCompare (info1->attributes, info2->attributes, appInfoH);
				}
			}
		}
	
	// Sort by category, priority, due date
	else if (sortOrder == soCategoryPriority)
		{
		result = CategoryCompare (info1->attributes, info2->attributes, appInfoH);
		if (result == 0)
			{
			result = (r1->priority & priorityOnly) - (r2->priority & priorityOnly);
			if (result == 0)
				{
				result = DateTypeCmp (r1->dueDate, r2->dueDate);
				}
			}
		}

	// Sort by category, due date, priority
	else if (sortOrder == soCategoryDueDate)
		{
		result = CategoryCompare (info1->attributes, info2->attributes, appInfoH);
		if (result == 0)
			{
			result = DateTypeCmp (r1->dueDate, r2->dueDate);
			if (result == 0)
				{
				result = (r1->priority & priorityOnly) - (r2->priority & priorityOnly);
				}
			}
		}
	
	return result;
}


/************************************************************
 *
 *  FUNCTION: ToDoSize
 *
 *  DESCRIPTION: Return the size of a ToDoDBRecordType
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the size in bytes
 *
 *  CREATED: 1/10/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static UInt ToDoSize(ToDoDBRecordPtr r)
{
	UInt size;
	char *c;
	int cLen;
	
	c = &r->description;
	cLen = StrLen(c) + 1;
	size = sizeof (DateType) + 1 + cLen;
	c += cLen;
	
	size += StrLen(c) + 1;

	return size;
}


/************************************************************
 *
 *  FUNCTION: ToDoFindSortPosition
 *
 *  DESCRIPTION: Return where a record is or should be.
 *		Useful to find a record or find where to insert a record.
 *
 *  PARAMETERS: database record (not deleted!)
 *
 *  RETURNS: the size in bytes
 *
 *  CREATED: 1/11/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static UInt ToDoFindSortPosition(DmOpenRef dbP, ToDoDBRecord *newRecord, 
		SortRecordInfoPtr newRecordInfo)
{
	int sortOrder;
	
	sortOrder = ToDoGetSortOrder (dbP);
		
	return (DmFindSortPosition (dbP, newRecord, newRecordInfo, 
		(DmComparF *)ToDoCompareRecords, sortOrder));
}


/************************************************************
 *
 *  FUNCTION: ToDoNewRecord
 *
 *  DESCRIPTION: Create a new record in sorted position
 *
 *  PARAMETERS: database pointer
 *				database record
 *
 *  RETURNS: ##0 if successful, errorcode if not
 *
 *  CREATED: 1/10/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err ToDoNewRecord(DmOpenRef dbP, ToDoItemPtr item, UInt category, UInt *index)
{
	Err 						err;
	UInt						size;
	Char						zero=0;
	UInt						attr;
	UInt 						newIndex;
	ULong						offset;
	ToDoDBRecordPtr		nilP=0;
	ToDoDBRecordPtr		recordP;
	VoidHand 				recordH;
	SortRecordInfoType	sortInfo;

	// Compute the size of the new to do record.
	size = sizeDBRecord;
	if (item->description)
		size += StrLen (item->description);
	if (item->note)
		size += StrLen (item->note);
		

	//  Allocate a chunk in the database for the new record.
	recordH = (Handle)DmNewHandle(dbP, size);
	if (recordH == NULL)
		return dmErrMemError;

	// Pack the the data into the new record.
	recordP = MemHandleLock (recordH);
	DmWrite(recordP, (ULong)&nilP->dueDate, &item->dueDate, sizeof(nilP->dueDate));
	DmWrite(recordP, (ULong)&nilP->priority, &item->priority, sizeof(nilP->priority));

	offset = (ULong)&nilP->description;
	if (item->description)
		{
		DmStrCopy(recordP, offset, item->description);
		offset += StrLen (item->description) + 1;
		}
	else
		{
		DmWrite(recordP, offset, &zero, 1);
		offset++;
		}
	
	if (item->note) 
		DmStrCopy(recordP, offset, item->note);
	else
		DmWrite(recordP, offset, &zero, 1);
	
	
	sortInfo.attributes = category;
	sortInfo.uniqueID[0] = 0;
	sortInfo.uniqueID[1] = 0;
	sortInfo.uniqueID[2] = 0;
	
	// Determine the sort position of the new record.
	newIndex = ToDoFindSortPosition (dbP, recordP, &sortInfo);

	MemPtrUnlock (recordP);

	// Insert the record.
	err = DmAttachRecord(dbP, &newIndex, recordH, 0);
	if (err) 
		MemHandleFree(recordH);
	else
		{
		*index = newIndex;

		// Set the category.
		DmRecordInfo (dbP, newIndex, &attr, NULL, NULL);
		attr &= ~dmRecAttrCategoryMask;
		attr |= category;
		DmSetRecordInfo (dbP, newIndex, &attr, NULL);
		}

	return err;
}


/***********************************************************************
 *
 * FUNCTION:    ToDoInsertNewRecord
 *
 * DESCRIPTION: This routine creates a new record and inserts it after
 *              the specified position.  The new record is assigned the 
 *              same priority and due date as the record it is 
 *              inserted after.
 *
 * PARAMETERS:  database pointer
 *              database record
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95	Initial Revision
 *
 ***********************************************************************/
Err ToDoInsertNewRecord (DmOpenRef dbP, UIntPtr index)
{
	Byte					priority;
	ToDoDBRecordPtr 	rec;
	ToDoDBRecordPtr 	newRec;
	VoidHand 		 	recH;
	VoidHand			 	newRecH;
	Err				 	err;
	UInt 					size;
	ToDoDBRecordPtr	nilP=0;
	Word					zero=0;
	UInt 					newIndex;
	UInt					category;
	UInt					attr;


	// Make a new chunk
	size = sizeof (ToDoDBRecord) + 1;
	newRecH = DmNewHandle (dbP, size);
	if (! newRecH) return dmErrMemError;


	// Get the record that the new record will be inserted after.
	recH = DmQueryRecord (dbP, *index);
	ErrFatalDisplayIf (!recH, "Error inserting new to do record");
	rec = MemHandleLock (recH);

	// Get the category of the current record.
	DmRecordInfo (dbP, *index, &attr, NULL, NULL);
	category = (attr & dmRecAttrCategoryMask);
		
	// Set the priority and the due date of the new record to the same
	// values as the record we're inserting after.  This will insure
	// that the records are in the proper sort order.
	newRec = (ToDoDBRecord *) MemHandleLock (newRecH);
	DmWrite(newRec, (ULong)&nilP->dueDate, &rec->dueDate, sizeof(rec->dueDate));

	priority = rec->priority & priorityOnly;
	DmWrite(newRec, (ULong)&nilP->priority, &priority, sizeof(rec->priority));
	
	// Description is 1 byte, plus add extra byte for note field
	DmWrite(newRec, (ULong)&nilP->description, &zero, 2);

	MemPtrUnlock (rec);

	// Attach in place
	newIndex = *index + 1;
	err = DmAttachRecord(dbP, &newIndex, newRecH, 0);
	if (err) 
		{
		MemHandleFree(newRecH);
		}
	else
		{
		MemPtrUnlock (newRec);

		// Set the category of the new record.
		DmRecordInfo (dbP, newIndex, &attr, NULL, NULL);
		attr |= category;
		DmSetRecordInfo (dbP, newIndex, &attr, NULL);

		*index = newIndex;
		}

	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	ECToDoDBValidate (dbP);
	#endif
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: ToDoChangeSortOrder
 *
 *  DESCRIPTION: Change the ToDo Database's sort order
 *
 *  PARAMETERS: database pointer
 *				TRUE if sort by company
 *
 *  RETURNS: nothing
 *
 *  CREATED: 1/17/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err ToDoChangeSortOrder(DmOpenRef dbP, Boolean sortOrder)
{
	ToDoAppInfoPtr appInfoP;
	ToDoAppInfoPtr	nilP = 0;
	UInt				dirtyAppInfo;


	appInfoP = MemHandleLock (ToDoGetAppInfo (dbP));

	if (appInfoP->sortOrder != sortOrder)
		{
		dirtyAppInfo = appInfoP->dirtyAppInfo | toDoSortByPriorityDirty;
		DmWrite(appInfoP, (ULong)&nilP->dirtyAppInfo, &dirtyAppInfo, sizeof(appInfoP->dirtyAppInfo)); 
		DmWrite(appInfoP, (ULong)&nilP->sortOrder, &sortOrder, sizeof(appInfoP->sortOrder));
		
		DmInsertionSort(dbP, (DmComparF *) &ToDoCompareRecords, (Int) sortOrder);
		}
		
	MemPtrUnlock (appInfoP);	

	return 0;
}


/************************************************************
 *
 *  FUNCTION: ToDoSort
 *
 *  DESCRIPTION: Sort the appointment database.
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: nothing
 *
 *  CREATED: 10/17/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
void ToDoSort (DmOpenRef dbP)
{
	int sortOrder;
	
	sortOrder = ToDoGetSortOrder (dbP);
	DmInsertionSort(dbP, (DmComparF *) &ToDoCompareRecords, (Int) sortOrder);
}


/************************************************************
 *
 *  FUNCTION: ToDoChangeRecord
 *
 *  DESCRIPTION: Change a record in the ToDo Database
 *
 *  PARAMETERS: database pointer
 *					 database index
 *					 database record
 *					 changed fields
 *
 *  RETURNS: ##0 if successful, errorcode if not
 *
 *  CREATED: 1/14/95 
 *
 *  BY: Roger Flores
 *
 *	COMMENTS:	Records are not stored with extra padding - they
 *	are always resized to their exact storage space.  This avoids
 *	a database compression issue.  The code works as follows:
 *	
 *
 *************************************************************/
Err ToDoChangeRecord(DmOpenRef dbP, UInt *index, 
	ToDoRecordFieldType changedField, VoidPtr data)
{
	Err 						err;
	Int 						cLen;
	UInt						attr;
	UInt 						curSize;
	UInt 						newSize;
	UInt 						newIndex;
	Byte						priority;
	ULong						offset;
	CharPtr 					c;
	VoidHand 				recordH=0;
	ToDoDBRecord			temp;
	ToDoDBRecordPtr 		src;
	ToDoDBRecordPtr 		nilP = 0;
	SortRecordInfoType	sortInfo;
	
	// Get the record which we are going to change
	recordH = DmQueryRecord(dbP, *index);
	src = MemHandleLock (recordH);
	

	// If the  record is being change such that its sort position will 
	// change,  move the record to its new sort position.
	if ( (changedField == toDoPriority) || 
		  (changedField == toDoDueDate)  ||
		  (changedField == toDoCategory) )
		{
		MemSet (&sortInfo, sizeof (sortInfo), 0);
		DmRecordInfo (dbP, *index, &attr, NULL, NULL);
		sortInfo.attributes = attr;

		if (changedField == toDoPriority)
			{
			temp.priority = *(WordPtr) data;
			temp.dueDate = src->dueDate;
			sortInfo.attributes = attr;
			}
		else if (changedField == toDoDueDate) 
			{
			temp.priority = src->priority;
			temp.dueDate = *((DatePtr)data);
			sortInfo.attributes = attr;
			}
		else
			{
			temp.priority = src->priority;
			temp.dueDate = src->dueDate;
			sortInfo.attributes = *(WordPtr) data;			
			}

		newIndex = ToDoFindSortPosition (dbP, &temp, &sortInfo);
		DmMoveRecord (dbP, *index, newIndex);
		if (newIndex > *index) newIndex--;
		*index = newIndex;
		}


	if (changedField == toDoPriority)
		{
		priority = *(WordPtr) data | (src->priority & completeFlag);
		DmWrite (src, (ULong)&nilP->priority, &priority, sizeof(src->priority));
		goto exit;
		}
			
	if (changedField == toDoComplete) 
		{
		priority = (*(WordPtr) data << 7) |  (src->priority & priorityOnly);
		DmWrite (src, (ULong)&nilP->priority, &priority, sizeof(src->priority));
		goto exit;
		}

	if (changedField == toDoDueDate)
		{ 
		DmWrite (src, (ULong)&nilP->dueDate, data, sizeof(src->dueDate));
		goto exit;
		}
		
	if (changedField == toDoCategory)
		{
		attr = (attr & ~dmRecAttrCategoryMask) | *(WordPtr) data;
		DmSetRecordInfo (dbP, newIndex, &attr, NULL);
		goto exit;
		}


	// Calculate the size of the changed record. First,
	// find the size of the data used from the old record.
	newSize = sizeof (DateType) + 1;
	newSize += StrLen((CharPtr) data) + 1;
	c = &src->description;
	cLen = StrLen(c) + 1;
	if (changedField != toDoDescription)
		newSize += cLen;
	if (changedField != toDoNote)
		{
		c += cLen;
		newSize += StrLen(c) + 1;
		}
		

	// Change the description field.
	if (changedField == toDoDescription)
		{
		// If the new description is longer, expand the record.
		curSize = MemPtrSize (src);
		if (newSize > curSize)
			{
			MemPtrUnlock (src);
			err = MemHandleResize (recordH, newSize);
			if (err) return (err);
			src = MemHandleLock (recordH);
			}
		
		// Move the note field.
		offset = sizeof(DateType) + 1 + StrLen (data) + 1;
		c = &src->description;
		c += StrLen(c) + 1;
		DmWrite (src, offset, c, StrLen(c) + 1);
		
		
		// Write the new description field.
		offset = sizeof(DateType) + 1;
		DmStrCopy (src, offset, data);

		// If the new description is shorter, shrink the record.
		if (newSize < curSize)
			MemPtrResize (recordH, newSize);
		goto exit;
		}


	// Change the note field
	if (changedField == toDoNote)
		{
		offset = sizeof(DateType) + 1 + StrLen((CharPtr)&src->description) + 1;
		MemPtrUnlock (src);
		err = MemHandleResize (recordH, newSize);
		if (err) return (err);

		src = MemHandleLock (recordH);
		DmStrCopy (src, offset, data);
		goto exit;
		}

exit:
	MemPtrUnlock (src);

	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		ECToDoDBValidate (dbP);
	#endif

	return 0;
}





