/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *****************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     ToDo.c
 * AUTHOR:	 Art Lamb: April 24, 1995
 *
 * DECLARER: ToDo
 *
 * DESCRIPTION:
 *	  This is the ToDo application's main module.  
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>
#include <Keyboard.h>
#include <Graffiti.h>
#include <SysEvtMgr.h>
#include "ToDo.h"
#include "ToDoDB.h"
#include "ToDoRsc.h"

// Error checking routines
void ECToDoDBValidate(DmOpenRef dbP);

// Exported routines
extern CharPtr GetToDoNotePtr (ToDoDBRecordPtr recordP);


/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define toDoVersionNum					3
#define toDoPrefsVersionNum			3
#define todoPrefID						0x00
#define toDoDBName						"ToDoDB"
#define toDoDBType						'DATA'

// Fonts used by application
#define noteTitleFont					boldFont

// Columns in the ToDo table of the list view.
#define completedColumn					0
#define priorityColumn					1
#define descColumn						2
#define dueDateColumn					3
#define categoryColumn					4

#define spaceBeforeDesc					2
#define spaceBeforeCategory			2

#define newToDoSize  					16
#define defaultPriority					1

#define maxNoteTitleLen					40

// Due Date popup list chooses
#define dueTodayItem						0
#define dueTomorrowItem					1
#define dueOneWeekLaterItem			2
#define noDueDateItem					3
#define selectDateItem					4

// Sort Order popup list choices
#define priorityDueDateItem			0
#define dueDatePriorityItem			1
#define categoryPriorityItem			2
#define categoryDueDateItem			3

// Update codes, used to determine how the ToDo list should 
// be redrawn.
#define updateRedrawAll					0x00
#define updateItemDelete				0x01
#define updateItemMove					0x02
#define updateItemHide					0x04
#define updateCategoryChanged			0x08
#define updateDisplayOptsChanged		0x10
#define updateGoTo						0x20
#define updateFontChanged				0x40

// Field numbers, used to indicate where search string was found.
#define descSeacrchFieldNum			0
#define noteSeacrchFieldNum			1

#define noRecordSelected				0xffff

// Number of system ticks (1/60 seconds) to display crossed out item
// before they're erased.
#define crossOutDelay					40


/***********************************************************************
 *
 *	Internal Structutes
 *
 ***********************************************************************/

// This is the structure of the data stored in the state file.
typedef struct {
	Word				currentCategory;
	FontID			v20NoteFont;		// For 2.0 compatibility (BGT)
	Boolean			showAllCategories;
	Boolean 			showCompletedItems;
	Boolean 			showOnlyDueItems;
	Boolean			showDueDates;
	Boolean			showPriorities;
	Boolean			showCategories;
	Boolean			saveBackup;
	Boolean			changeDueDate;
	
	// Version 3 preferences
	FontID			listFont;
	FontID			noteFont;		// For 3.0 and later units.	(BGT)
} ToDoPreferenceType;


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/

static DmOpenRef			ToDoDB;										// ToDo database
static char					CategoryName [dmCategoryLength];		// name of the current category
static Boolean				HideSecretRecords;						// true if secret records are hidden
static MenuBarPtr			CurrentMenu;								// pointer to the current menu bar
static Word					TopVisibleRecord = 0;					// top visible record in list view
static Word					PendingUpdate = 0;						// code of pending list view update
static DateFormatType	DateFormat;
static DateType			Today;										// Date when the device was powered on.

// The following global variables are used to keep track of the edit
// state of the application.
static Word					CurrentRecord = noRecordSelected;	// record being edited
static Boolean				ItemSelected = false;					// true if a list view item is selected
static Boolean				RecordDirty = false;						// true if a record has been modified
static Word					ListEditPosition = 0;					// position of the insertion point in the desc field
static Word					ListEditSelectionLength;				// length of the current selection.

// The following global variables are saved to a state file.
static FontID				NoteFont = stdFont;						// font used in note view
static Word					CurrentCategory = dmAllCategories;	// currently displayed category
static Boolean				ShowAllCategories = true;				// true if all categories are being displayed
static Boolean 			ShowCompletedItems = true;				// true if completed items are being displayed
static Boolean 			ShowOnlyDueItems = false;				// true if only due items are displayed
static Boolean				ShowDueDates = false;					// true if due dates are displayed in the list view
static Boolean				ShowPriorities = true;					// true if priorities are displayed in the list view
static Boolean				ShowCategories = false;					// true if categories are displayed in the list view
static Boolean				SaveBackup = true;						// true if save backup to PC is the default
static Boolean				ChangeDueDate = false;					// true if due date is changed to completion date when completed
static FontID				ListFont = stdFont;						// font used to draw to do item


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/
static void ListViewLoadTable (Boolean fillTable);

static Boolean ClearEditState (void);

static void ToDoLoadPrefs(void);		// (BGT)
static void ToDoSavePrefs(void);		// (BGT)

static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags);

/***********************************************************************
 *
 * FUNCTION:    ECToDoValidateAll
 *
 * DESCRIPTION: This routine preforms various edit checks on the ToDo
 *              application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE

static void ECToDoValidateAll ()
{
	VoidHand recordH;


	// If a record in the list view is selected, make sure it exists.
	if (ItemSelected)
		{
		recordH = DmQueryRecord (ToDoDB, CurrentRecord);
		ErrFatalDisplayIf (!recordH, "Selected record does not exist");
		}
		
	else if (CurrentRecord == noRecordSelected)
		{
		// Check the in integrity of the ToDo database.
		#if EMULATION_LEVEL != EMULATION_NONE
			ECToDoDBValidate (ToDoDB);
		#endif
		}

}
#endif


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine opens the application's database, loads the 
 *               saved-state information and initializes global variables.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static Word StartApplication (void)
{
	Word error = 0;
	Err err = 0;
	UInt mode;
	Boolean synchronize = false;
	SystemPreferencesType sysPrefs;
	UInt cardNo;
	LocalID dbID;
	Word attributes;

	
	// Determime if secret record should be shown.
	PrefGetPreferences (&sysPrefs);
	HideSecretRecords = sysPrefs.hideSecretRecords;
	if (HideSecretRecords)
		mode = dmModeReadWrite;
	else
		mode = dmModeReadWrite | dmModeShowSecret;

	// Get the date format from the system preferences.
	DateFormat = sysPrefs.dateFormat;

	// Find the application's data file.  If it doesn't exist create it.
	ToDoDB = DmOpenDatabaseByTypeCreator (toDoDBType, sysFileCToDo, mode);
	if (! ToDoDB)
		{
		error = DmCreateDatabase (0, toDoDBName, sysFileCToDo, toDoDBType, false);
		if (error) return error;
		
		ToDoDB = DmOpenDatabaseByTypeCreator (toDoDBType, sysFileCToDo, mode);
		if (! ToDoDB) return (1);
		
		// Set the backup bit.  This is to aid syncs with non Palm software.
		DmOpenDatabaseInfo(ToDoDB, &dbID, NULL, NULL, &cardNo, NULL);
		DmDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL,
					NULL, NULL, NULL, NULL, NULL, NULL, NULL);
		attributes |= dmHdrAttrBackup;
		DmSetDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL,
					NULL, NULL, NULL, NULL, NULL, NULL, NULL);
		
		err = ToDoAppInfoInit (ToDoDB);
      if (err) 
      	{
      	DmCloseDatabase(ToDoDB);
      	DmDeleteDatabase(cardNo, dbID);
         return err;
         }
		}
	

	// Read the preferences.
	ToDoLoadPrefs();
	TopVisibleRecord = 0;
	CurrentRecord = noRecordSelected;
	

	// Get today's date.  Will will use it to determine if passed due items
	// need to be redrawn when the device is powered on the next time.
	DateSecondsToDate (TimGetSeconds (), &Today);


	return (error);
}


/***********************************************************************
 *
 * FUNCTION:    StopApplication
 *
 * DESCRIPTION: This routine closes the application's database
 *              and saves the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void StopApplication (void)
{
	ToDoSavePrefs();					// BGT

	// Send a frmSave event to all the open forms.
	FrmSaveAllForms ();
	
	// Close all the open forms.
	FrmCloseAllForms ();

	// Close the application's data file.
	DmCloseDatabase (ToDoDB);
}


/***********************************************************************
 *
 * FUNCTION:    SyncNotification
 *
 * DESCRIPTION: This routine is a entry point of the ToDo application.
 *              It is called when the ToDo application's database is 
 *              synchronized.  This routine will re-sort the database and
 *              reset the state file info if necessary.
 *
 * PARAMETERS:	 nothing
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/6/95	Initial Revision
 *
 ***********************************************************************/
static void SyncNotification (void)
{
	Err err = 0;
	char name [dmCategoryLength];
	DmOpenRef dbP;
	ToDoPreferenceType prefs;
	Word prefsSize;

	// Open the application's data file.
	dbP = DmOpenDatabaseByTypeCreator(toDoDBType, sysFileCToDo, dmModeReadWrite);
	if (!dbP) return;
	
	// Re-sort the database.
	ToDoSort (dbP);
	
	// Check if the currrent category still exists.
	prefsSize = sizeof (ToDoPreferenceType);
	if (PrefGetAppPreferences (sysFileCToDo, todoPrefID, &prefs, &prefsSize, true) != noPreferenceFound)
		{
		CategoryGetName (dbP, prefs.currentCategory, name);	
		if (*name == 0) 
			{
			prefs.currentCategory = dmAllCategories;
			prefs.showAllCategories = true;
	
			PrefSetAppPreferences (sysFileCToDo, todoPrefID, toDoVersionNum, &prefs, 
				sizeof (ToDoPreferenceType), true);
			}
		}

	DmCloseDatabase (dbP);
}


/***********************************************************************
 *
 * FUNCTION:    SearchDraw
 *
 * DESCRIPTION: This routine draws the description of a ToDo item found
 *              by the text search routine 
 *
 * PARAMETERS:	 desc  - pointer to a descrition field
 *              x     - draw position
 *              y     - draw position
 *              width - maximum width to draw.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/18/95	Initial Revision
 *
 ***********************************************************************/
static void SearchDraw (CharPtr desc, short x, short y, short width)
{
	Word charsToDraw;
	short maxWidth;
	short titleWidth;
	CharPtr ptr;

	ptr = StrChr (desc, linefeedChr);
	if (ptr)
		{
		charsToDraw = (Word) (ptr - desc);
		titleWidth = FntCharsWidth (desc, charsToDraw);
		if (titleWidth <= width)
			WinDrawChars (desc, charsToDraw, x, y);
		else
			{
			maxWidth = titleWidth - (FntCharWidth ('.') * 3);
			while (maxWidth > width)
				{
				maxWidth -= FntCharWidth (desc[charsToDraw--]);
				}
				WinDrawChars (desc, charsToDraw, x, y);
				x += maxWidth;
				WinDrawChars ("...", 3, x, y);
			}
		}
	else
		{
		maxWidth = width - (FntCharWidth ('.') * 3);
		charsToDraw = 0;
		while (true)
			{
			if ( ! desc[charsToDraw]) break;
			maxWidth -= FntCharWidth (desc[charsToDraw]);
			if (maxWidth >= 0)
				charsToDraw++;
			else
				break;
			}
			
		WinDrawChars (desc, charsToDraw, x, y);
		if (maxWidth < 0)
			{
			x += FntCharsWidth (desc, charsToDraw);
			WinDrawChars ("...", 3, x, y);
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    Search
 *
 * DESCRIPTION: This routine searchs the ToDo database for records 
 *              that contain the findParams string. 
 *
 * PARAMETERS:	 findParams - text search parameter block
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/18/95	Initial Revision
 *
 ***********************************************************************/
static void Search (FindParamsPtr findParams)
{
	Err err;
	Word pos;
	UInt fieldNum;
	CharPtr desc;
	CharPtr note;
	CharPtr header;
	UInt recordNum;
	VoidHand recordH;
	VoidHand headerH;
	RectangleType r;
	Boolean done;
	Boolean match;
	LocalID dbID;
	DmOpenRef dbP;
	FindParamsPtr params;
	ToDoDBRecordPtr toDoRec;
	UInt				cardNo = 0;
	DmSearchStateType	searchState;

	params = (FindParamsPtr)findParams;
	
	// Find the application's data file.
	err = DmGetNextDatabaseByTypeCreator (true, &searchState, toDoDBType,
					sysFileCToDo, true, &cardNo, &dbID);
	if (err)
		{
		findParams->more = false;
		return;
		}

	// Open the ToDo database.
	dbP = DmOpenDatabase(cardNo, dbID, params->dbAccesMode);
	if (! dbP) 
		{
		params->more = false;
		return;
		}

	// Display the heading line.
	headerH = DmGetResource (strRsc, FindToDoHeaderStr);
	header = MemHandleLock (headerH);
	done = FindDrawHeader (findParams, header);
	MemHandleUnlock(headerH);
	if (done) goto Exit;
	

	// Search the description and note fields for the "find" string.
	recordNum = params->recordNum;
	while (true)
		{
		// Because applications can take a long time to finish a find when
		// the result may be on the screen or for other reasons, users like
		// to be able to stop the find.  Stop the find if an event is pending.
		// This stops if the user does something with the device.  Because
		// this call slows down the search we perform it every so many 
		// records instead of every record.  The response time should still
		// be short without introducing much extra work to the search.
		
		// Note that in the implementation below, if the next 16th record is  
		// secret the check doesn't happen.  Generally, this shouldn't be a 
		// problem if most of the records are secret then the search 
		// won't take long.
		if ((recordNum & 0x000f) == 0 &&			// every 16th record
			EvtSysEventAvail(true))
			{
			// Stop the search process.
			params->more = true;
			break;
			}
		
		
		recordH = DmQueryNextInCategory (dbP, &recordNum, dmAllCategories);

		// Have we run out of records?
		if (! recordH)
			{
			params->more = false;			
			break;
			}

		toDoRec = MemHandleLock (recordH);
		 
		// Search the description field,  if a match is not found search the
		// note field.
		fieldNum = descSeacrchFieldNum;
		desc = &toDoRec->description;
		match = FindStrInStr (desc, params->strToFind, &pos);
		if (! match)
			{
			note = desc + StrLen (desc) + 1;
			if (*note)
				{
				fieldNum = noteSeacrchFieldNum;
				match = FindStrInStr (note, params->strToFind, &pos);
				}
			}
		
		if (match)
			{
			done = FindSaveMatch (findParams, recordNum, pos, fieldNum, 0, cardNo, dbID);
			if (done)
				{
				MemHandleUnlock (recordH);
				break;
				}

			// Get the bounds of the region where we will draw the results.
			FindGetLineBounds (findParams, &r);
			
			// Display the description.
			SearchDraw (desc, r.topLeft.x+1, r.topLeft.y, r.extent.x-2);

			params->lineNumber++;
			}

		MemHandleUnlock (recordH);
		recordNum++;
		}
		
		
Exit:
	DmCloseDatabase (dbP);	
}


/***********************************************************************
 *
 * FUNCTION:    GoToItem
 *
 * DESCRIPTION: This routine is called when the "Go to" button 
 *              in the text search dialog is pressed.
 *
 * PARAMETERS:	 goToParams   - where to go to
 *              launchingApp - true is the application is being launched
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/6/95	Initial Revision
 *
 ***********************************************************************/
static void GoToItem (GoToParamsPtr goToParams, Boolean launchingApp)
{
	Word formID;
	Word recordNum;
	UInt attr;
	Long dateL;
	Long todayL;
	ULong uniqueID;
	VoidHand recordH;
	EventType event;
	DateTimeType today;
	ToDoDBRecordPtr toDoRec;

	recordNum = goToParams->recordNum;


	// If the application is already running, close all the open forms.  If
	// the current record is blank, then it will be deleted, so we'll get 
	// the unique id of the record and use it to find the record index 
	// after all the forms are closed.
	if (! launchingApp)
		{
		DmRecordInfo (ToDoDB, recordNum, NULL, &uniqueID, NULL); 
		FrmCloseAllForms ();
		ClearEditState ();
		DmFindRecordByID (ToDoDB, uniqueID, &recordNum);
		}
		

	// Make the item the first item displayed.
	TopVisibleRecord = recordNum;

	// Change the current category if necessary.
	if (CurrentCategory != dmAllCategories)
		{
		DmRecordInfo (ToDoDB, recordNum, &attr, NULL, NULL);
		if (CurrentCategory != (attr & dmRecAttrCategoryMask))
			{
			CurrentCategory = dmAllCategories;
			ShowAllCategories = true;
			}
		}


	// If the item is not displayable given the current display options,
	// change the display options so that it will be.
	recordH = DmQueryRecord (ToDoDB, recordNum);
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);

	// If only completed items are not being displayed, and the item is complete,
	// change the "show completed" option setting.
	if ((! ShowCompletedItems) && (toDoRec->priority & completeFlag))
		ShowCompletedItems = true;

	// If only due items are being show, and the item is not due, 
	// change the "show only due items" option.
	if (ShowOnlyDueItems)
		if (DateToInt (toDoRec->dueDate) != toDoNoDueDate)
			{
			// Check if the item is due.
			TimSecondsToDateTime (TimGetSeconds(), &today);
			todayL = ( ((long) today.year) << 16) + 
						( ((long) today.month) << 8) + 
						  ((long) today.day);

			dateL = ( ((long) toDoRec->dueDate.year + firstYear) << 16) + 
					  ( ((long) toDoRec->dueDate.month) << 8) + 
						 ((long) toDoRec->dueDate.day);

			if (dateL > todayL)
				ShowOnlyDueItems = false;
			}

	MemHandleUnlock (recordH);	



	if (goToParams->matchFieldNum == noteSeacrchFieldNum)
		formID = NoteView;
	else
		formID = ListView;

	// Send an event to goto a form and select the matching text.
	MemSet (&event, 0, sizeof(EventType));

	event.eType = frmLoadEvent;
	event.data.frmLoad.formID = formID;
	EvtAddEventToQueue (&event);
 
	event.eType = frmGotoEvent;
	event.data.frmGoto.formID = formID;
	event.data.frmGoto.recordNum = recordNum;
	event.data.frmGoto.matchPos = goToParams->matchPos;
	event.data.frmGoto.matchLen = goToParams->searchStrLen;
	event.data.frmGoto.matchFieldNum = goToParams->matchFieldNum;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static VoidPtr GetObjectPtr (Word objectID)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm ();
	return (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objectID)));

}

/***********************************************************************
 *
 * FUNCTION:    GetFocusObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to the field object, in 
 *              the current form, that has the focus.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    pointer to a field object or NULL of there is no fucus
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static FieldPtr GetFocusObjectPtr (void)
{
	FormPtr frm;
	Word focus;
	FormObjectKind objType;
	
	frm = FrmGetActiveForm ();
	focus = FrmGetFocus (frm);
	if (focus == noFocus)
		return (NULL);
		
	objType = FrmGetObjectType (frm, focus);
	
	if (objType == frmFieldObj)
		return (FrmGetObjectPtr (frm, focus));
	
	else if (objType == frmTableObj)
		return (TblGetCurrentField (FrmGetObjectPtr (frm, focus)));
	
	return (NULL);
}


/***********************************************************************
 *
 * FUNCTION:    ChangeCategory
 *
 * DESCRIPTION: This routine updates the global variables that keep track
 *              of category information.  
 *
 * PARAMETERS:  category  - new category (index)
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static void ChangeCategory (Word category)
{
	CurrentCategory = category;
	TopVisibleRecord = 0;
}


/***********************************************************************
 *
 * FUNCTION:    SelectFont
 *
 * DESCRIPTION: This routine handles selection of a font in the List 
 *              View. 
 *
 * PARAMETERS:  currFontID - id of current font
 *
 * RETURNED:    id of new font
 *
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/10/97	Initial Revision
 *
 ***********************************************************************/
static FontID SelectFont (FontID currFontID)
{
	Word formID;
	FontID fontID;
	
	formID = (FrmGetFormId (FrmGetActiveForm ()));

	// Call the OS font selector to get the id of a font.
	fontID = FontSelect (currFontID);

	if (fontID != currFontID)
		FrmUpdateForm (formID, updateFontChanged);

	return (fontID);
}


/***********************************************************************
 *
 * FUNCTION:    SeekRecord
 *
 * DESCRIPTION: Given the index of a ToDo record, this routine scans 
 *              forwards or backwards for displayable ToDo records.           
 *
 * PARAMETERS:  indexP  - pointer to the index of a record to start from;
 *                        the index of the record sought is returned in
 *                        this parameter.
 *
 *              offset  - number of records to skip:   
 *                        	0 - seek from the current record to the
 *                             next display record, if the current record is
 *                             a display record, its index is retuned.
 *                         1 - seek foreward, skipping one displayable 
 *                             record
 *                        -1 - seek backwards, skipping one displayable 
 *                             record
 *                             
 *
 * RETURNED:    false is return if a displayable record was not found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/11/95	Initial Revision
 *
 ***********************************************************************/
static Boolean SeekRecord (UIntPtr indexP, Int offset, Int direction)
{
	long dateL;
	long todayL;
	VoidHand recordH;
	DateTimeType today;
	ToDoDBRecordPtr toDoRec;

	ErrFatalDisplayIf ( (offset < -1 || offset > 1) , "Invalid offset");

	while (true)
		{
		DmSeekRecordInCategory (ToDoDB, indexP, offset, direction, CurrentCategory);
		if (DmGetLastErr()) return (false);
	
		if ( ShowCompletedItems && (! ShowOnlyDueItems))
			return (true);
		
		recordH = DmQueryRecord (ToDoDB, *indexP);
		toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);
		
		if ( (ShowCompletedItems) || (! (toDoRec->priority & completeFlag)))
			{
			if (! ShowOnlyDueItems) break;
			
			if (DateToInt (toDoRec->dueDate) == toDoNoDueDate) break;

			// Check if the item is due.
			TimSecondsToDateTime (TimGetSeconds(), &today);
			todayL = ( ((long) today.year) << 16) + 
						( ((long) today.month) << 8) + 
						  ((long) today.day);

			dateL = ( ((long) toDoRec->dueDate.year + firstYear) << 16) + 
					  ( ((long) toDoRec->dueDate.month) << 8) + 
						 ((long) toDoRec->dueDate.day);

			if (dateL <= todayL)	break;
			}
		
		if (offset == 0) offset = 1;
		
		MemHandleUnlock (recordH);	
		}

	MemHandleUnlock (recordH);	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    GetToDoNotePtr
 *
 * DESCRIPTION: This routine returns a pointer to the note field in a to 
 *              do record.
 *
 * PARAMETERS:  recordP - pointer to a ToDo record
 *
 * RETURNED:    pointer to a null-terminated note
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/15/95	Initial Revision
 *
 ***********************************************************************/
CharPtr GetToDoNotePtr (ToDoDBRecordPtr recordP)
{
	return (&recordP->description + StrLen (&recordP->description) + 1);
}


/***********************************************************************
 *
 * FUNCTION:    DirtyRecord
 *
 * DESCRIPTION: Mark a record dirty (modified).  Record marked dirty 
 *              will be synchronized.
 *
 * PARAMETERS:  index
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/15/95	Initial Revision
 *
 ***********************************************************************/
static void DirtyRecord (UInt index)
{
	UInt		attr;

	DmRecordInfo (ToDoDB, index, &attr, NULL, NULL);
	attr |= dmRecAttrDirty;
	DmSetRecordInfo (ToDoDB, index, &attr, NULL);
}


/***********************************************************************
 *
 * FUNCTION:    DeleteRecord
 *
 * DESCRIPTION: This routine deletes the selected ToDo item.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true if the delete occurred,  false if it was canceled.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/30/95		Initial Revision
 *
 ***********************************************************************/
static Boolean DeleteRecord (UInt index)
{
	Word ctlIndex;
	Word buttonHit;
	FormPtr alert;
	Boolean saveBackup;

	// Display an alert to comfirm the operation.
	alert = FrmInitForm (DeleteToDoDialog);

	ctlIndex = FrmGetObjectIndex (alert, DeleteToDoSaveBackup);
	FrmSetControlValue (alert, ctlIndex, SaveBackup);
	buttonHit = FrmDoDialog (alert);
	saveBackup = FrmGetControlValue (alert, ctlIndex);;

	FrmDeleteForm (alert);

	if (buttonHit == DeleteToDoCancel)
		return (false);

	SaveBackup = saveBackup;

	// Delete or archive the record.
	if (SaveBackup)
		DmArchiveRecord (ToDoDB, index);
	else
		DmDeleteRecord (ToDoDB, index);
	DmMoveRecord (ToDoDB, index, DmNumRecords (ToDoDB));

	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    ClearEditState
 *
 * DESCRIPTION: This routine take the application out of edit mode.
 *              The edit state of the current record is remember until
 *              this routine is called.  
 *
 *              If the current record is empty, it will be deleted 
 *              by this routine.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true is current record is deleted by this routine.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/14/95	Initial Revision
 *
 ***********************************************************************/
static Boolean ClearEditState (void)
{
	Word recordNum;
	Boolean empty;
	VoidHand recordH;
	ToDoDBRecordPtr recordP;

	if (! ItemSelected)
		{
		CurrentRecord = noRecordSelected;
		return (false);
		}
	
	recordNum = CurrentRecord;

	// Clear the global variables that keeps track of the edit start of the
	// current record.
	ItemSelected = false;
	CurrentRecord = noRecordSelected;
	ListEditPosition = 0;
	ListEditSelectionLength = 0;
	PendingUpdate = 0;
	
	// If the description field is empty and the note field is empty, delete
	// the ToDo record.
	recordH = DmQueryRecord (ToDoDB, recordNum);
	recordP = MemHandleLock (recordH);
	empty = (! recordP->description) && (! *GetToDoNotePtr(recordP));
	MemHandleUnlock (recordH);

	if (empty)
		{
		// If the description was not modified, and the description and 
		// note fields are empty, remove the record from the database.
		// This can occur when a new empty record is deleted.
		if (RecordDirty)
			{
			DmDeleteRecord (ToDoDB, recordNum);
			DmMoveRecord (ToDoDB, recordNum, DmNumRecords (ToDoDB));
			}
		else
			DmRemoveRecord (ToDoDB, recordNum);
		
		return (true);
		}

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    DetemineDueDate
 *
 * DESCRIPTION: This routine is called when an item of the "due date" 
 *              popup list is selected.  For items such as "today" and 
 *              "end of week" the due date is computed,  for "select
 *              date" the date picker is displayed.
 *
 * PARAMETERS:  item selected in due date popup list.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/31/95	Initial Revision
 *
 ***********************************************************************/
static void DetermineDueDate (Word itemSelected, DateType * dueDateP)
{
	SWord month, day, year;
	Long adjustment;
	ULong timeInSeconds;
	CharPtr titleP;
	VoidHand titleH;
	DateTimeType date;
	
	// "No due date" items selected?
	if (itemSelected == noDueDateItem)
		{
		*((ShortPtr) dueDateP) = -1;
		return;
		}

	// "Select date" item selected?
	else if (itemSelected == selectDateItem)
		{
		if ( *((ShortPtr) dueDateP) == -1)
			{
			timeInSeconds = TimGetSeconds ();
			TimSecondsToDateTime (timeInSeconds, &date);
			year = date.year;
			month = date.month;
			day = date.day;
			}
		else
			{
			year = dueDateP->year + firstYear;
			month = dueDateP->month;
			day = dueDateP->day;
			}

		titleH = DmGetResource (strRsc, DueDateTitleStr);
		titleP = (CharPtr) MemHandleLock (titleH);

		if (SelectDay (selectDayByDay, &month, &day, &year, titleP))
			{
			dueDateP->day = day;
			dueDateP->month = month;
			dueDateP->year = year - firstYear;
			}

		MemHandleUnlock (titleH);
		return;
		}


	// "Today" item seleted?
	else if (itemSelected == dueTodayItem)
		adjustment = 0;

	// "Tomorrow" item selected?
	else if (itemSelected == dueTomorrowItem)
		adjustment = daysInSeconds;

	// "One week later" item selected?
	else if (itemSelected == dueOneWeekLaterItem)
		{
		adjustment = ((Long) daysInSeconds) * ((Long) daysInWeek);
		}

	timeInSeconds = TimGetSeconds ();
	TimSecondsToDateTime (timeInSeconds, &date);
	TimAdjust (&date, adjustment);
	
	dueDateP->year = date.year - firstYear;
	dueDateP->month = date.month;
	dueDateP->day = date.day;
}


#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    OptionsApply
 *
 * DESCRIPTION: This routine applies the changes made in the Options Dialog
 *              (aka Preferences).
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95	Initial Revision
 *
 ***********************************************************************/
static void OptionsApply (void)
{
	Byte sortOrder;
	Word listItem;
	ControlPtr ctl;
	
	// Update the sort order.  Reset the ToDo list to the top.
	listItem = LstGetSelection (GetObjectPtr (OptionsSortByList));
	switch (listItem)
		{
		case priorityDueDateItem:	sortOrder = soPriorityDueDate;	break;
		case dueDatePriorityItem:	sortOrder = soDueDatePriority;	break;
		case categoryPriorityItem:	sortOrder = soCategoryPriority;	break;
		case categoryDueDateItem:	sortOrder = soCategoryDueDate;	break;
		}


	if (ToDoGetSortOrder (ToDoDB) != sortOrder)
		{
		ToDoChangeSortOrder (ToDoDB, sortOrder);
		TopVisibleRecord = 0;
		}

	// Show or hide items marked complete.  Reset the list to the top.
	ctl = GetObjectPtr (OptionsShowCompleted);
	if (ShowCompletedItems != CtlGetValue (ctl))
		{
		ShowCompletedItems = CtlGetValue (ctl);
		TopVisibleRecord = 0;
		}
		
	// Show only items due today or show all items (in the current 
	// category).
	ctl = GetObjectPtr (OptionsShowDueItems);
	if (ShowOnlyDueItems != CtlGetValue (ctl))
		{
		ShowOnlyDueItems = CtlGetValue (ctl);
		TopVisibleRecord = 0;
		}
		
	// Change the due date field, in the record, to the completion
	// date when the item is mark complete.
	ctl = GetObjectPtr (OptionsChangeDueDate);
	ChangeDueDate = CtlGetValue (ctl);

	// Show or hide the due date column.
	ctl = GetObjectPtr (OptionsShowDueDates);
	ShowDueDates = CtlGetValue (ctl);
	
	// Show or hide the priorities column.
	ctl = GetObjectPtr (OptionsShowPriorities);		
	ShowPriorities = CtlGetValue (ctl);
	
	// Show or hide the priorities column.
	ctl = GetObjectPtr (OptionsShowCategories);
	ShowCategories = CtlGetValue (ctl);
}


/***********************************************************************
 *
 * FUNCTION:    OptionsInit
 *
 * DESCRIPTION: This routine initializes the Options Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95	Initial Revision
 *
 ***********************************************************************/
static void OptionsInit (void)
{
	Byte sortOrder;
	Word listItem;
	CharPtr label;
	ListPtr lst;
	ControlPtr ctl;
	
	// Set the trigger and popup list that indicates the sort order.
	sortOrder = ToDoGetSortOrder (ToDoDB);

	if (sortOrder == soPriorityDueDate)
		listItem = priorityDueDateItem;		
	else if (sortOrder == soDueDatePriority)
		listItem = dueDatePriorityItem;
	else if (sortOrder == soCategoryPriority)
		listItem = categoryPriorityItem;
	else
		listItem = categoryDueDateItem;
		
	lst = GetObjectPtr (OptionsSortByList);
	label = LstGetSelectionText (lst, listItem);
	ctl = GetObjectPtr (OptionsSortByTrigger);
	CtlSetLabel (ctl, label);
	LstSetSelection (lst, listItem);


	// Initialize the checkboxes in the dialog box.
	ctl = GetObjectPtr (OptionsShowCompleted);
	CtlSetValue (ctl, ShowCompletedItems);
		
	ctl = GetObjectPtr (OptionsShowDueItems);
	CtlSetValue (ctl, ShowOnlyDueItems);
		
	ctl = GetObjectPtr (OptionsChangeDueDate);
	CtlSetValue (ctl, ChangeDueDate);

	ctl = GetObjectPtr (OptionsShowDueDates);
	CtlSetValue (ctl, ShowDueDates);
		
	ctl = GetObjectPtr (OptionsShowPriorities);		
	CtlSetValue (ctl, ShowPriorities);
	
	ctl = GetObjectPtr (OptionsShowCategories);		
	CtlSetValue (ctl, ShowCategories);
}


/***********************************************************************
 *
 * FUNCTION:    OptionsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Options
 *              Dialog Box" of the ToDo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95		Initial Revision
 *
 ***********************************************************************/
static Boolean OptionsHandleEvent (EventPtr event)
{
	Boolean handled = false;
	FormPtr frm;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case OptionsOkButton:
				OptionsApply ();
				FrmReturnToForm (ListView);
				FrmUpdateForm (ListView, updateDisplayOptsChanged);
				handled = true;
				break;

			case OptionsCancelButton:
				FrmReturnToForm (ListView);
				handled = true;
				break;
				
			}
		}

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		OptionsInit ();
		FrmDrawForm (frm);
		handled = true;
		}

	return (handled);
}


#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    DetailsSetDateTrigger
 *
 * DESCRIPTION: This routine sets the date trigger, in the details dialog,
 *              to the specified date.  
 *
 * PARAMETERS:  year	  - years (since 1904)
 *              month  - months (1-12)
 *              day    - days (1-31)
 *
 * RETURNED:    nothing
 *
 * NOTES:
 *      This routine assumes that the memory allocated for the label of 
 *      the due date trigger is large enough to hold the largest possible
 *      label.  This label memory is reserved by initializing the label
 *      in the resource file.     
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/31/95	Initial Revision
 *
 ***********************************************************************/
static void DetailsSetDateTrigger (DateType date)
{
	Int dayOfWeek;
	CharPtr str;
	CharPtr label;
	ListPtr lst;
	ControlPtr ctl;
	SystemPreferencesType sysPrefs;
	
	lst = GetObjectPtr (DetailsDueDateList);
	LstSetSelection (lst, noDueDateItem);

	ctl = GetObjectPtr (DetailsDueDateTrigger);
	label = CtlGetLabel (ctl);

	// Minus one means no date.  Set the label of the trigger to the 
	// first choice of the popup list, which is "no date".
	if (DateToInt (date) == toDoNoDueDate)
		{
		str = LstGetSelectionText (lst, noDueDateItem);
		StrCopy (label, str);
		CtlSetLabel (ctl, label);
		LstSetSelection (lst, noDueDateItem);
		}

	// Format the date into a string and set it as the label of the trigger.
	else
		{	
		// Get the data format.
		PrefGetPreferences (&sysPrefs);
	
		// Format the date into a string.
		dayOfWeek = DayOfWeek (date.month, date.day, date.year+firstYear);
		DateToDOWDMFormat (date.month, date.day, date.year+firstYear,
			sysPrefs.dateFormat, label);
		
		CtlSetLabel (ctl, label);
		LstSetSelection (lst, selectDateItem);
		}
}


/***********************************************************************
 *
 * FUNCTION:    DetailsSelectCategory
 *
 * DESCRIPTION: This routine handles selection, creation and deletion of
 *              categories in the Details Dialog.  
 *
 * PARAMETERS:  category - the current catagory, returns to new
 *                         category
 *
 * RETURNED:    true if the category was changed in a way that 
 *              require the list view to be redrawn.
 *
 *              The following global variables are modified:
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static Boolean DetailsSelectCategory (WordPtr category)
{
	CharPtr name;
	Boolean categoryEdited;
	
	name = CtlGetLabel (GetObjectPtr (DetailsCategoryTrigger));

	categoryEdited = CategorySelect (ToDoDB, FrmGetActiveForm (),
		DetailsCategoryTrigger, DetailsCategoryList,
		false, category, name, 1, 0);
	
	return (categoryEdited);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsDeleteToDo
 *
 * DESCRIPTION: This routine deletes a ToDo item.  This routine is called 
 *              when the delete button in the details dialog is pressed.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true if the record was delete or archived.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static Boolean DetailsDeleteToDo (void)
{
	Word recordNum;
	Boolean empty;
	VoidHand recordH;
	ToDoDBRecordPtr recordP;
		
	recordNum = CurrentRecord;

	// Check if the record is empty. If it is, clear the edit state, 
	// this will delete the current record if it is blank.
	recordH = DmQueryRecord (ToDoDB, recordNum);
	recordP = MemHandleLock (recordH);
	empty = (! recordP->description) && (! *GetToDoNotePtr(recordP));
	MemHandleUnlock (recordH);

	if (empty)
		{
		ClearEditState ();
		return (true);
		}
		
	// Display an alert to confirm the delete operation, and delete the
	// record if the alert is confirmed.
	if (!  DeleteRecord (recordNum) )
		return (false);
	
	ItemSelected = false;
	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsApply
 *
 * DESCRIPTION: This routine applies the changes made in the Details Dialog.
 *
 * PARAMETERS:  category        - new catagory
 *              dueDateP        - new due date
 *              categoryEdited  - true if current category has been moved, 
 *                 deleted, renamed, or merged with another category
 *
 * RETURNED:    code which indicates how the ToDo list was changed,  this
 *              code is sent as the update code in a frmUpdate event.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *			kcr	10/9/95	Added 'private records' alert
 *
 ***********************************************************************/
static Word DetailsApply (Word category, DateType * dueDateP, 
	Boolean categoryEdited)
{
	FormPtr				frm;
	UInt					attr;
	Word 					index;
	Word 					updateCode = 0;
	Word 					curPriority;
	Word 					newPriority;
	Boolean  			secret;
	Boolean				dirty = false;
	VoidHand 			recordH;
	DateType				curDueDate;
	ToDoDBRecordPtr	toDoRec;
	

	// Get the secret attribute of the current record.
	DmRecordInfo (ToDoDB, CurrentRecord, &attr, NULL, NULL);	


	// Get the priority setting from the dialog and compare it with the
	// priortity value in the current record.
	frm = FrmGetActiveForm ();
	index = FrmGetControlGroupSelection (frm, DetailsPrioritiesGroup);
	
	recordH = DmQueryRecord (ToDoDB, CurrentRecord);
	ErrFatalDisplayIf ((! recordH), "Record not found");

	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);
	curPriority = toDoRec->priority & priorityOnly;
	MemHandleUnlock (recordH);
	
	newPriority = FrmGetObjectId (frm, index) - DetailsPriority1Trigger + 1;

	if (curPriority != newPriority)
		{		
		ToDoChangeRecord (ToDoDB, &CurrentRecord, toDoPriority, &newPriority);
		updateCode |= updateItemMove;
		dirty = true;
		}


	// Compare the due date setting in the dialog with the due date in the
	// current record.  Update the record if necessary.
	recordH = DmQueryRecord (ToDoDB, CurrentRecord);
	ErrFatalDisplayIf ((! recordH), "Record not found");

	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);
	curDueDate = toDoRec->dueDate;
	MemHandleUnlock (recordH);

	if (MemCmp (dueDateP, &curDueDate, sizeof (DateType)))
		{
		ToDoChangeRecord (ToDoDB, &CurrentRecord, toDoDueDate, dueDateP);
		updateCode |= updateItemMove;
		dirty = true;
		}
	

	// Compare the current category to the category setting of the dialog.
	// Update the record if the categories are different.	
	if ((attr & dmRecAttrCategoryMask) != category)
		{
		ToDoChangeRecord (ToDoDB, &CurrentRecord, toDoCategory, &category);

		attr &= ~dmRecAttrCategoryMask;
		attr |= category;
		dirty = true;

		updateCode |= updateItemMove;
		}
	

	// Get the current setting of the secret checkbox and compare it the
	// the setting of the record.  Update the record if the values 
	// are different.
	secret = CtlGetValue (GetObjectPtr (DetailsSecretCheckbox));
	if (((attr & dmRecAttrSecret) == dmRecAttrSecret) != secret)
		{
		if (HideSecretRecords)
			updateCode |= updateItemHide;

		else if (secret)
			FrmAlert (privateRecordInfoAlert);

		dirty = true;
		if (secret)
			attr |= dmRecAttrSecret;
		else
			attr &= ~dmRecAttrSecret;
		}


	// If the current category was deleted, renamed, or merged with
	// another category, then the list view needs to be redrawn.
	if (categoryEdited)
		{
		CurrentCategory = category;
		updateCode |= updateCategoryChanged;
		}


	// Save the new category and/or secret status, and mark the record dirty.
	if (dirty)
		{
		attr |= dmRecAttrDirty;
		DmSetRecordInfo (ToDoDB, CurrentRecord, &attr, NULL);
		}

	return (updateCode);
}


/***********************************************************************
 *
 * FUNCTION:    DetailsInit
 *
 * DESCRIPTION: This routine initializes the Details Dialog.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static void DetailsInit (WordPtr categoryP, DateType * dueDateP)
{
	UInt attr;
	UInt category;
	Word priority;
	CharPtr name;
	ControlPtr ctl;
	VoidHand recordH;
	ToDoDBRecordPtr	toDoRec;

	// If the record is marked secret, turn on the secret checkbox.
	DmRecordInfo (ToDoDB, CurrentRecord, &attr, NULL, NULL);
	ctl = GetObjectPtr (DetailsSecretCheckbox);
	CtlSetValue (ctl, (attr & dmRecAttrSecret) != 0);

	// Set the label of the category trigger.
	category = attr & dmRecAttrCategoryMask;
	ctl = GetObjectPtr (DetailsCategoryTrigger);
	name = CtlGetLabel (ctl);
	CategoryGetName (ToDoDB, category, name);
	CategorySetTriggerLabel (ctl, name);

	// Get a pointer to the ToDo record.
	recordH = DmQueryRecord (ToDoDB, CurrentRecord);
	ErrFatalDisplayIf ((! recordH), "Record not found");

	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);
	
	// Set the priority push button.
	priority = toDoRec->priority & priorityOnly;
	ctl = GetObjectPtr (DetailsPriority1Trigger + priority - 1);
	CtlSetValue (ctl, true);
	
	// Set the due date trigger.
	DetailsSetDateTrigger (toDoRec->dueDate);

	// Return the current category and due date.
	*categoryP = category;
	*dueDateP = toDoRec->dueDate;

	// Unlock the ToDo record
	MemHandleUnlock (recordH);	
}


/***********************************************************************
 *
 * FUNCTION:    DetailsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Details
 *              Dialog Box" of the ToDo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static Boolean DetailsHandleEvent (EventPtr event)
{
	static Word 		category;
	static DateType 	dueDate;
	static Boolean		categoryEdited;

	Word updateCode;
	Boolean handled = false;
	FormPtr frm;

	if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case DetailsOkButton:
				updateCode = DetailsApply (category, &dueDate, categoryEdited);
				FrmReturnToForm (ListView);
				FrmUpdateForm (ListView, updateCode);
				handled = true;
				break;

			case DetailsCancelButton:
				if (categoryEdited)
					updateCode = updateCategoryChanged;
				else
					updateCode = 0;
				FrmUpdateForm (ListView, updateCode);
				FrmReturnToForm (ListView);
				handled = true;
				break;
				
			case DetailsDeleteButton:
				FrmReturnToForm (ListView);
				if ( DetailsDeleteToDo ()) 
					FrmUpdateForm (ListView, updateItemDelete);
				else
					FrmUpdateForm (ListView, 0);
				handled = true;
				break;
				
			case DetailsNoteButton:
				PendingUpdate = DetailsApply (category, &dueDate, categoryEdited);
				FrmCloseAllForms ();
				FrmGotoForm (NoteView);
				handled = true;
				break;

			case DetailsCategoryTrigger:
				categoryEdited = DetailsSelectCategory (&category);
				handled = true;
				break;
			}
		}


	else if (event->eType == popSelectEvent)
		{
		if (event->data.popSelect.listID == DetailsDueDateList)
			{
			DetermineDueDate (event->data.popSelect.selection, &dueDate);
			DetailsSetDateTrigger (dueDate);
			handled = true;
			}
		}
	
	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		DetailsInit (&category, &dueDate);
		FrmDrawForm (frm);
		categoryEdited = false;
		handled = true;
		}

	return (handled);
}


#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    NoteViewDrawTitle
 *
 * DESCRIPTION: This routine draws the title of the note view.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
 static void NoteViewDrawTitle (void)
 {
 	short x;
	short maxWidth;
	short winWidth;
	short winHeight;
	Word len;
	Word width;
	FontID curFont;
	CharPtr desc;
	char title[maxNoteTitleLen+4];
	VoidHand recordH;
	RectangleType r;
	ToDoDBRecordPtr recordP;
	
	curFont = FntSetFont (noteTitleFont);

	recordH = DmQueryRecord (ToDoDB, CurrentRecord);
	ErrFatalDisplayIf ((! recordH), "Record not found");

	recordP = MemHandleLock (recordH);
	desc = &recordP->description;

	WinGetWindowExtent (&winWidth, &winHeight);
	maxWidth = winWidth - 8;
	width = 0;
	*title = 0;
	desc = &recordP->description;
	for (len = 0; len < maxNoteTitleLen; len++)
		{
		if (desc[len] == linefeedChr) break;
		
		title[len] = desc[len];
		title[len+1] = 0;
		width += FntCharWidth (desc[len]);
		
		if (width >= maxWidth) break;
		}

	if ( (width >= maxWidth) && (desc[len] != linefeedChr) )
		{
		maxWidth -= FntCharWidth ('.') * 3;
		while (width > maxWidth)
			{
			width -= FntCharWidth (title[len]);
			len--;
			}
		title[len+1] = '.';
		title[len+2] = '.';
		title[len+3] = '.';
		title[len+4] = 0;
		}

	RctSetRectangle (&r, 0, 0, winWidth, FntLineHeight()+2 );
	WinDrawRectangle (&r, 3);
	x = (winWidth - FntCharsWidth (title, StrLen (title)) + 1 ) / 2;
	WinInvertChars (title, StrLen(title), x, 1);

	MemHandleUnlock (recordH);
	FntSetFont (curFont);
 }
 

/***********************************************************************
 *
 * FUNCTION:    NoteViewUpdateScrollBar
 *
 * DESCRIPTION: This routine update the scroll bar.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void NoteViewUpdateScrollBar (void)
{
	Word scrollPos;
	Word textHeight;
	Word fieldHeight;
	Short maxValue;
	FieldPtr fld;
	ScrollBarPtr bar;

	fld = GetObjectPtr (NoteField);
	bar = GetObjectPtr (NoteScrollBar);
	
	FldGetScrollValues (fld, &scrollPos, &textHeight,  &fieldHeight);

	if (textHeight > fieldHeight)
		maxValue = textHeight - fieldHeight;
	else if (scrollPos)
		maxValue = scrollPos;
	else
		maxValue = 0;

	SclSetScrollBar (bar, scrollPos, 0, maxValue, fieldHeight-1);
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewLoadRecord
 *
 * DESCRIPTION: This routine loads a note from a ToDo record into 
 *              the note edit field.
 *
 * PARAMETERS:  frm - pointer to the Note View form
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void NoteViewLoadRecord (void)
{
	Word offset;
	FieldPtr fld;
	VoidHand recordH;
	CharPtr ptr;
	ToDoDBRecordPtr recordP;
	
	// Get a pointer to the note field.
	fld = GetObjectPtr (NoteField);
	
	// Set the font used in the note field.
	FldSetFont (fld, NoteFont);
	
	recordH = DmQueryRecord (ToDoDB, CurrentRecord);
	ErrFatalDisplayIf ((! recordH), "Bad record");
	
	// Compute the offset within the do to record of the note string, the
	// note string follows the description string.
	recordP = MemHandleLock (recordH);
	ptr = &recordP->description;
	ptr += StrLen (ptr) + 1;
	offset = ptr - (CharPtr)recordP;

	FldSetText (fld, recordH, offset, StrLen(ptr)+1);
	MemHandleUnlock (recordH);
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewSave
 *
 * DESCRIPTION: This routine release any unused memory allocated for
 *              the note and mark the ToDo record dirty.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static void NoteViewSave (void)
{
	FieldPtr fld;
	
	fld = GetObjectPtr (NoteField);

	// Was the note string modified by the user.
	if (FldDirty (fld))
		{
		// Release any free space in the note field.
		FldCompactText (fld);

		// Mark the record dirty.	
		DirtyRecord (CurrentRecord);
		}


	// Clear the handle value in the field, otherwise the handle
	// will be freed when the form is disposed of,  this call also unlocks
	// the handle that contains the note string.
	FldSetTextHandle (fld, 0);

	#if EMULATION_LEVEL != EMULATION_NONE
		ECToDoDBValidate (ToDoDB);
	#endif
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewDeleteNote
 *
 * DESCRIPTION: This routine deletes a note in a ToDo record.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true if the note was deleted.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Boolean NoteViewDeleteNote (void)
{
	FieldPtr fld;
	
	if (FrmAlert(DeleteNoteAlert) != DeleteNoteYes)
		return (false);

	// Unlock the handle that contains the text of the note.
	fld = GetObjectPtr (NoteField);
	ErrFatalDisplayIf ((! fld), "Bad field");

	// Clear the handle value in the field, otherwise the handle
	// will be freed when the form is disposed of. this call also 
	// unlocks the handle the contains the note string.
	FldSetTextHandle (fld, 0);	

	ToDoChangeRecord (ToDoDB, &CurrentRecord, toDoNote, "");

	// Mark the record dirty.	
	DirtyRecord (CurrentRecord);
	
	return (true);
}



/***********************************************************************
 *
 * FUNCTION:    NoteViewDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/29/95		Initial Revision
 *
 ***********************************************************************/
static Boolean NoteViewDoCommand (Word command)
{
	FieldPtr fld;
	Boolean handled = true;
	
	switch (command)
		{
		case noteTopOfPageCmd:
			fld = GetObjectPtr (NoteField);
			FldSetScrollPosition (fld, 0);
			NoteViewUpdateScrollBar ();
			break;

		case noteBottomOfPageCmd:
			fld = GetObjectPtr (NoteField);
			FldSetScrollPosition (fld, FldGetTextLength (fld));
			NoteViewUpdateScrollBar ();
			break;
			
		case notePhoneLookupCmd:
			fld = GetObjectPtr (NoteField);
			PhoneNumberLookup (fld);
			break;
			
		case noteFontCmd:
			NoteFont = SelectFont (NoteFont);
			break; 

		default:
			handled = false;
		}	
	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewScroll
 *
 * DESCRIPTION: This routine scrolls the Note View a page or a 
 *              line at a time.
 *
 * PARAMETERS:  direction - up or down
 *              oneLine   - true if scrolling a single line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void NoteViewScroll (Short linesToScroll)
{
	Word				blankLines;
	Short				min;
	Short				max;
	Short				value;
	Short				pageSize;
	FieldPtr			fld;
	ScrollBarPtr	bar;
	
	fld = GetObjectPtr (NoteField);

	if (linesToScroll < 0)
		{
		blankLines = FldGetNumberOfBlankLines (fld);
		FldScrollField (fld, -linesToScroll, up);
		
		// If there were blank lines visible at the end of the field
		// then we need to update the scroll bar.
		if (blankLines)
			{
			// Update the scroll bar.
			bar = GetObjectPtr (NoteScrollBar);
			SclGetScrollBar (bar, &value, &min, &max, &pageSize);
			if (blankLines > -linesToScroll)
				max += linesToScroll;
			else
				max -= blankLines;
			SclSetScrollBar (bar, value, min, max, pageSize);
			}
		}

	else if (linesToScroll > 0)
		FldScrollField (fld, linesToScroll, down);
}

/***********************************************************************
 *
 * FUNCTION:    NoteViewPageScroll
 *
 * DESCRIPTION: This routine scrolls the message a page up or down.
 *
 * PARAMETERS:   direction     up or down
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/1/96	Initial Revision
 *
 ***********************************************************************/
static void NoteViewPageScroll (DirectionType direction)
{
	Short value;
	Short min;
	Short max;
	Short pageSize;
	Word linesToScroll;
	FieldPtr fld;
	ScrollBarPtr bar;

	fld = GetObjectPtr (NoteField);
	
	if (FldScrollable (fld, direction))
		{
		linesToScroll = FldGetVisibleLines (fld) - 1;
		FldScrollField (fld, linesToScroll, direction);

		// Update the scroll bar.
		bar = GetObjectPtr (NoteScrollBar);
		SclGetScrollBar (bar, &value, &min, &max, &pageSize);

		if (direction == up)
			value -= linesToScroll;
		else
			value += linesToScroll;
		
		SclSetScrollBar (bar, value, min, max, pageSize);
		return;
		}
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewInit
 *
 * DESCRIPTION: This routine initializes the Note View form.
 *
 * PARAMETERS:  frm - pointer to the Note View form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/31/95	Initial Revision
 *
 ***********************************************************************/
static void NoteViewInit (FormPtr frm)
{
	NoteViewLoadRecord ();

	// Hide the font controls that are used in version 1.0 and 2.0 .
	FrmHideObject (frm, FrmGetObjectIndex (frm, NoteSmallFontButton));
	FrmHideObject (frm, FrmGetObjectIndex (frm, NoteLargeFontButton));
}


/***********************************************************************
 *
 * FUNCTION:    NoteViewHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Note View"
 *              of the ToDo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	2/21/95		Initial Revision
 *			kcr	10/11/95		Set initial shift state when entering an
 *									empty note field.
 *
 ***********************************************************************/
static Boolean NoteViewHandleEvent (EventPtr event)
{
	Word pos;
	FormPtr frm;
	FieldPtr fld;
	Boolean handled = false;


	if (event->eType == keyDownEvent)
		{
		if (ChrIsHardKey(event->data.keyDown.chr))
			{
			NoteViewSave ();
			ClearEditState ();
			FrmGotoForm (ListView);
			handled = true;
			}

		else if (event->data.keyDown.chr == pageUpChr)
			{
			NoteViewPageScroll (up);
			handled = true;
			}

		else if (event->data.keyDown.chr == pageDownChr)
			{
			NoteViewPageScroll (down);
			handled = true;
			}
		}


	else if (event->eType == ctlSelectEvent)
		{		
		switch (event->data.ctlSelect.controlID)
			{
			case NoteDoneButton:
				NoteViewSave ();
				FrmGotoForm (ListView);
				handled = true;
				break;

			case NoteDeleteButton:
				if (NoteViewDeleteNote())
					FrmGotoForm (ListView);
				handled = true;
				break;
			}
		}


	else if (event->eType == fldChangedEvent)
		{
		frm = FrmGetActiveForm ();
		NoteViewUpdateScrollBar ();
		handled = true;
		}
		

	else if (event->eType == menuEvent)
		{
		handled = NoteViewDoCommand (event->data.menu.itemID);
		}
		

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		NoteViewInit (frm);
		NoteViewDrawTitle ();
		FrmDrawForm (frm);
		NoteViewUpdateScrollBar ();
		FrmSetFocus (frm, FrmGetObjectIndex (frm, NoteField));
		handled = true;
		}
	

	else if (event->eType == frmGotoEvent)
		{
		frm = FrmGetActiveForm ();

		ItemSelected = true;
		CurrentRecord = event->data.frmGoto.recordNum;
		NoteViewInit (frm);

		fld = GetObjectPtr (NoteField);
		pos = event->data.frmGoto.matchPos;
		FldSetScrollPosition (fld, pos);
		FldSetSelection (fld, pos, pos + event->data.frmGoto.matchLen);
		NoteViewDrawTitle ();
		FrmDrawForm (frm);
		NoteViewUpdateScrollBar ();
		FrmSetFocus (frm, FrmGetObjectIndex (frm, NoteField));
		handled = true;
		}
			
	else if (event->eType == frmUpdateEvent)
		{
		if (event->data.frmUpdate.updateCode & updateFontChanged)
			{
			fld = GetObjectPtr (NoteField);
			FldSetFont (fld, NoteFont);
			NoteViewUpdateScrollBar ();
			}
		else
			{
			frm = FrmGetActiveForm ();
			NoteViewDrawTitle ();
			FrmDrawForm (frm);
			}
		handled = true;
		}


	else if (event->eType == frmCloseEvent)
		{
		if ( FldGetTextHandle (GetObjectPtr (NoteField)))
			NoteViewSave ();
		}

	
	else if (event->eType == sclRepeatEvent)
		{
		NoteViewScroll (event->data.sclRepeat.newValue - 
			event->data.sclRepeat.value);
		}

	return (handled);
}


#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    ListViewRestoreEditState
 *
 * DESCRIPTION: This routine restores the edit state of the ToDo list
 *              if the list is in edit mode. This routine is 
 *              called after the priority or due date of an item is
 *              changed, or after returning from the details dialog
 *              or note view.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/17/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewRestoreEditState ()
{
	Word row;
	FormPtr frm;
	TablePtr table;
	FieldPtr fld;

	if ( ! ItemSelected) return;

	// Find the row that the current record is in.  Its possible 
	// that the current record is nolong displayable (ex: only due 
	// item are being display and the due date was changed
	// such that the record don't display).
	table = GetObjectPtr (ListTable);
	if ( ! TblFindRowID (table, CurrentRecord, &row) )
		{
		ClearEditState ();
		return;
		}

	frm = FrmGetActiveForm ();
	FrmSetFocus (frm, FrmGetObjectIndex (frm, ListTable));
	TblGrabFocus (table, row, descColumn);
	
	// Restore the insertion point position.
	fld = TblGetCurrentField (table);
	FldSetInsPtPosition (fld, ListEditPosition);
	if (ListEditSelectionLength)
		FldSetSelection (fld, ListEditPosition, 
			ListEditPosition + ListEditSelectionLength);

	FldGrabFocus (fld);
}



/***********************************************************************
 *
 * FUNCTION:    ListViewClearEditState
 *
 * DESCRIPTION: This routine clears the edit state of the ToDo list.
 *              It is caled whenever a table item is selected.
 *
 *              If the new item selected is in a different row than
 *              the current record, the edit state is cleared,  and if 
 *              current record is empty it is deleted.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    true if the current record is deleted.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/17/95	Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewClearEditState (void)
{
	Word row;
	Word rowsInTable;
	TablePtr table;

	if ( ! ItemSelected) return (false);

	table = GetObjectPtr (ListTable);
	if ( ! TblFindRowID (table, CurrentRecord, &row) )
		return (false);

	TblReleaseFocus (table);

	// If a different row has been selected, clear the edit state, this 
	// will delete the current record if it's empty.
	if (ClearEditState ())
		{
		rowsInTable = TblGetNumberOfRows (table);
		for (; row < rowsInTable; row++)
			TblSetRowUsable (table, row, false);

		ListViewLoadTable (true);
		TblRedrawTable (table);
		
		return (true);
		}

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewGetDescription
 *
 * DESCRIPTION: This routine returns a pointer to the description field
 *              of a ToDo record.  This routine is called by the table 
 *              object as a callback routine when it wants to display or
 *              edit a ToDo description.
 *
 * PARAMETERS:  table  - pointer to the ToDo list table (TablePtr)
 *              row    - row of the table
 *              column - column of the table
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Err ListViewGetDescription (VoidPtr table, Word row, Word column,
	Boolean editable, VoidHand textH, WordPtr textOffset, WordPtr textAllocSize,
	FieldPtr fld)
{
	Word recordNum;
	VoidHand recordH;
	FieldAttrType attr;
	ToDoDBRecordPtr toDoRec;
	
	// Get the record number that corresponds to the table item.
	// The record number is stored as the row id.
	recordNum = TblGetRowID (table, row);
	recordH = DmQueryRecord( ToDoDB, recordNum);
	ErrFatalDisplayIf ((! recordH), "Record not found");
	
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);

	*textOffset = &toDoRec->description - ((CharPtr) toDoRec);
	*textAllocSize = StrLen (&toDoRec->description) + 1;  // one for null terminator
	*textH = recordH;
	
	MemHandleUnlock (recordH);

	// Set the field to support auto-shift.
	if (fld)
		{
		FldGetAttributes (fld, &attr);
		attr.autoShift = true;
		FldSetAttributes (fld, &attr);
		}


	return (0);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSaveDescription
 *
 * DESCRIPTION: This routine is called by the table object, as a callback  
 *              routine, when it wants to save a ToDo description.
 *              The description is edit in place (directly in the database 
 *              record),  so we don't need to save it here,  we do however
 *              want to capture the current edit state.
 *
 * PARAMETERS:  table  - pointer to the memo list table (TablePtr)
 *              row    - row of the table to draw
 *              column - column of the table to draw 
 *
 * RETURNED:    true if the table needs to be redrawn
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewSaveDescription (VoidPtr table, Word row, Word column)
{
	Word recordNum;
	Word selectStart;
	Word selectEnd;
	Boolean dirty;
	FieldPtr fld;
	
	
	// Get the record number that corresponds to the table item to save.
	recordNum = TblGetRowID (table, row);

	// If the description has been modified mark the record dirty, any 
	// change make to the ToDo's description were written directly
	// to the ToDo record.
	fld = TblGetCurrentField (table);
	dirty = FldDirty (fld);
	if (dirty)
		DirtyRecord (recordNum);

	// Save the dirty state, we're need it if we auto-delete an empty record.
	RecordDirty = dirty;

	// Check if the top of the description is scroll off the top of the 
	// field, if it is then redraw the field.
	if (FldGetScrollPosition (fld))
		{
		FldSetSelection (fld, 0, 0);
		FldSetScrollPosition (fld, 0);
		ListEditPosition = 0;
		ListEditSelectionLength = 0;
		}

	// Save the insertion point position, and length of the selection.  
	// We'll need the insertion point position an selection length
	// if we put the table back into edit mode. 
	else
		{
		ListEditPosition = FldGetInsPtPosition (fld);
		
		FldGetSelection (fld, &selectStart, &selectEnd);
		ListEditSelectionLength = selectEnd - selectStart;
		if (ListEditSelectionLength)
			ListEditPosition = selectStart;
		}

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewGetDescriptionHeight
 *
 * DESCRIPTION: This routine returns the height, in pixels, of a ToDo 
 *              description.
 *
 * PARAMETERS:  recordNum - record index
 *              width     - width of description
 *
 * RETURNED:    height in pixels
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static Word ListViewGetDescriptionHeight (Word recordNum, Word width, Word maxHeight)
{
	Word height;
	Word lineHeight;
	CharPtr note;
	FontID curFont;
	VoidHand recordH;
	ToDoDBRecordPtr toDoRec;
	
	// Get a pointer to the ToDo record.
	recordH = DmQueryRecord( ToDoDB, recordNum);
	ErrFatalDisplayIf ((! recordH), "Record not found");
	
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);

	// If the record has a note, leave space for the note indicator.
	note = GetToDoNotePtr (toDoRec);
	if (*note)
		width -= tableNoteIndicatorWidth;

	// Compute the height of the ToDo item's description.
	curFont = FntSetFont (ListFont);

	height = FldCalcFieldHeight (&toDoRec->description, width);
	lineHeight = FntLineHeight ();
	height = min (height, (maxHeight / lineHeight));
	height *= lineHeight;

	FntSetFont (curFont);

	MemHandleUnlock (recordH);

	return (height);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDrawDueDate
 *
 * DESCRIPTION: This routine draws a ToDo items due date.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row the item is in
 *              column - column the item is in
 *              bounds - region to draw in
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/14/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewDrawDueDate (VoidPtr table, Word row, Word column, 
	RectanglePtr bounds)
{
	char dueChr;
	char dateBuffer [dateStringLength];
	CharPtr dateStr;
	Word dateStrLen;
	Word dueChrWidth;
	short drawX, drawY;
	FontID curFont;
	FontID fontID;
	DateType date;
	DateTimeType today;
	long todayL, dateL;
	

	// Get the due date to the item being drawn.
	*((IntPtr) (&date)) = TblGetItemInt (table, row, dueDateColumn);


	// If there is no date draw a dash to indicate such.
	if (DateToInt (date) == -1)
		{
		curFont = FntSetFont (stdFont);
		drawX = bounds->topLeft.x + ((bounds->extent.x - 5) >> 1);
		drawY = bounds->topLeft.y + ((FntLineHeight () + 1) / 2);
		WinDrawLine (drawX, drawY, drawX+5, drawY);		
		FntSetFont (curFont);
		return;
		}
	
	// Get the width of the character that indicates the item is due.  Don't
	// count the whitespace in the character.
	if (ListFont == stdFont)
		fontID = boldFont;
	else
		fontID = ListFont;
	curFont = FntSetFont (fontID);
	dueChr = '!';
	dueChrWidth = FntCharWidth (dueChr) - 1;

	FntSetFont (ListFont);
	
	DateToAscii (date.month, date.day, date.year + firstYear, 
					DateFormat, dateBuffer);

	// Remove the year from the date string.
	dateStr = dateBuffer;
	if ((DateFormat == dfYMDWithSlashes) ||
		 (DateFormat == dfYMDWithDots) ||
		 (DateFormat == dfYMDWithDashes))
		dateStr += 3;
	else
		{
		dateStr[StrLen(dateStr) - 3] = 0;
		}


	// Draw the due date, right aligned.
	dateStrLen = StrLen (dateStr);
	drawX = bounds->topLeft.x + bounds->extent.x - dueChrWidth -
		FntCharsWidth (dateStr, dateStrLen);
	drawY = bounds->topLeft.y ;
	WinDrawChars (dateStr, dateStrLen, drawX, drawY);
	
	
	// If the date is on or before today draw an exclamation mark.
	TimSecondsToDateTime (TimGetSeconds(), &today);

	todayL = ( ((long) today.year) << 16) + 
				( ((long) today.month) << 8) + 
				  ((long) today.day);

	dateL = ( ((long) date.year + firstYear) << 16) + 
			  ( ((long) date.month) << 8) + 
				 ((long) date.day);
	
	if (dateL < todayL)
		{
		drawX = bounds->topLeft.x + bounds->extent.x - dueChrWidth;
		FntSetFont (fontID);
		WinDrawChars (&dueChr, 1, drawX, drawY);
		}

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDrawCategory
 *
 * DESCRIPTION: This routine draws a ToDo item's category name.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row the item is in
 *              column - column the item is in
 *              bounds - region to draw in
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/96	Initial Revision
 *
 ***********************************************************************/
static void ListViewDrawCategory (VoidPtr table, Word row, Word column, 
	RectanglePtr bounds)
{
	Int width;
	Int length;
	Word attr;
	Word category;
	Word recordNum;
	Boolean fits;
	Char categoryName [dmCategoryLength];
	FontID curFont;

	curFont = FntSetFont (ListFont);

	// Get the category of the item in the specified row.
	recordNum = TblGetRowID (table, row);
	DmRecordInfo (ToDoDB, recordNum, &attr, NULL, NULL);
	category = attr & dmRecAttrCategoryMask;

	// Get the name of the category and trunctae it to fix the the 
	// column passed.
	CategoryGetName (ToDoDB, category, categoryName);
	width = bounds->extent.x;
	length = StrLen(categoryName);
	FntCharsInWidth (categoryName, &width, &length, &fits);
	
	// Draw the category name.
	WinDrawChars (categoryName, length, bounds->topLeft.x, 
		bounds->topLeft.y);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewUpdateScrollers
 *
 * DESCRIPTION: This routine draws or erases the list view scroll arrow
 *              buttons.
 *
 * PARAMETERS:  frm             - pointer to the ToDo list form
 *              bottomRecord    - record index of the last visible record
 *              lastItemClipped - true if the last item display is not fully
 *                                visible
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewUpdateScrollers (FormPtr frm, Word bottomRecord,
	Boolean lastItemClipped)
{
	Word upIndex;
	Word downIndex;
	Word recordNum;
	Boolean scrollableUp;
	Boolean scrollableDown;
		
	// If the first record displayed is not the first record in the category,
	// enable the up scroller.
	recordNum = TopVisibleRecord;
	scrollableUp = SeekRecord (&recordNum, 1, dmSeekBackward);


	// If the last record displayed is not the last record in the category,
	// or the list item is clipped, enable the down scroller.
	recordNum = bottomRecord;
	scrollableDown = SeekRecord (&recordNum, 1, dmSeekForward) || lastItemClipped; 


	// Update the scroll button.
	upIndex = FrmGetObjectIndex (frm, ListUpButton);
	downIndex = FrmGetObjectIndex (frm, ListDownButton);
	FrmUpdateScrollers (frm, upIndex, downIndex, scrollableUp, scrollableDown);
}


/***********************************************************************
 *
 * FUNCTION:    ListInitTableRow
 *
 * DESCRIPTION: This routine initialize a row in the ToDo list.
 *
 * PARAMETERS:  table      - pointer to the table of ToDo items
 *              row        - row number (first row is zero)
 *              recordNum  - the index of the record display in the row
 *              rowHeight  - height of the row in pixels
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static void ListInitTableRow (TablePtr table, Word row, Word recordNum, 
	short rowHeight)
{
	CharPtr note;
	ULong	uniqueID;
	VoidHand recordH;
	ToDoDBRecordPtr toDoRec;

	// Get a pointer to the ToDo record.
	recordH = DmQueryRecord( ToDoDB, recordNum);
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);

	// Make the row usable.
	TblSetRowUsable (table, row, true);
	
	// Set the height of the row to the height of the description.
	TblSetRowHeight (table, row, rowHeight);
	
	// Store the record number as the row id.
	TblSetRowID (table, row, recordNum);
	
	// Store the unique id of the record in the table.
	DmRecordInfo (ToDoDB, recordNum, NULL, &uniqueID, NULL);
	TblSetRowData (table, row, uniqueID);

	// Set the checkbox that indicates the completion status.
	TblSetItemInt (table, row, completedColumn, 
		(toDoRec->priority & completeFlag) == completeFlag);

	// Store the priority in the table.
	TblSetItemInt (table, row, priorityColumn, 
		toDoRec->priority & priorityOnly);
	
	// Store the due date in the table.
	TblSetItemInt (table, row, dueDateColumn, (*(int *) &toDoRec->dueDate));

	// Set the table item type for the description, it will differ depending
	// on the presents of a note.
	note = GetToDoNotePtr (toDoRec);
	if (*note)
		TblSetItemStyle (table, row, descColumn, textWithNoteTableItem);
	else
		TblSetItemStyle (table, row, descColumn, textTableItem);		
	

	// Mark the row invalid so that it will drawn when we call the 
	// draw routine.
	TblMarkRowInvalid (table, row);
	
	MemHandleUnlock (recordH);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewLoadTable
 *
 * DESCRIPTION: This routine reloads ToDo database records into
 *              the list view.  This routine is called when:
 *              	o A new item is inserted
 *              	o An item is deleted
 *              	o The priority or due date of an items is changed
 *              	o An item is marked complete
 *              	o Hidden items are shown
 *              	o Completed items are hidden
 *
 * PARAMETERS:  fillTable - if true the top visible item will be scroll down
 *                          such that a full table is displayed
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewLoadTable (Boolean fillTable)
{
	Word				row;
	Word				numRows;
	Word				recordNum;
	Word				lastRecordNum;
	Word				dataHeight;
	Word				lineHeight;
	Word				tableHeight;
	Word				columnWidth;
	Word				pos, oldPos;
	Word				height, oldHeight;
	ULong				uniqueID;
	FontID			currFont;
	Boolean			rowUsable;
	Boolean			rowsInserted = false;
	Boolean			lastItemClipped;
	FormPtr			frm;
	TablePtr			table;
	RectangleType	r;
	
	frm = FrmGetActiveForm ();
	
	// Make sure the global variable that holds the index of the 
	// first visible record has a valid value.
	if (! SeekRecord (&TopVisibleRecord, 0, dmSeekForward))
		if (! SeekRecord (&TopVisibleRecord, 0, dmSeekBackward))
			TopVisibleRecord = 0;

	// If we have a currently selected record, make sure that it is not
	// above the first visible record.
	if (CurrentRecord != noRecordSelected)
		if (CurrentRecord < TopVisibleRecord)
			CurrentRecord = TopVisibleRecord;
		

	// Get the height of the table and the width of the description
	// column.
	table = GetObjectPtr (ListTable);
	TblGetBounds (table, &r);
	tableHeight = r.extent.y;
	columnWidth = TblGetColumnWidth (table, descColumn);

	// Get the height one one line.
	currFont = FntSetFont (ListFont);
	lineHeight = FntLineHeight ();
	FntSetFont (currFont);

	row = 0;
	dataHeight = 0;
	oldPos = pos = 0;
	recordNum = TopVisibleRecord;
	lastRecordNum = recordNum;

	// Load records into the table.
	while (true)
		{		
		// Get the next record in the currunt category.
		if ( ! SeekRecord (&recordNum, 0, dmSeekForward))
			break;

		// Compute the height of the ToDo item's description.
		height = ListViewGetDescriptionHeight (recordNum, columnWidth, tableHeight);

		// Is there enought room for at least one line of the the decription.
		if (tableHeight >= dataHeight + lineHeight)
			{
			// Get the height of the current row.
			rowUsable = TblRowUsable (table, row);
			if (rowUsable)
				oldHeight = TblGetRowHeight (table, row);
			else
				oldHeight = 0;

			// Determine if the row needs to be initialized.  We will initialize 
			// the row if: the row is not usable (not displayed),  the unique
			// id of the record does not match the unique id stored in the 
			// row.
			DmRecordInfo (ToDoDB, recordNum, NULL, &uniqueID, NULL);
			if ((TblGetRowData (table, row) != uniqueID) ||
				 (! TblRowUsable (table, row)) ||
				 (TblRowInvalid (table, row)))
				{
				ListInitTableRow (table, row, recordNum, height);
				}

			// If the height or the position of the item has changed draw the item.
			else 
				{
				TblSetRowID (table, row, recordNum);
				if (height != oldHeight)
					{
					TblSetRowHeight (table, row, height);
					TblMarkRowInvalid (table, row);
					}
				else if (pos != oldPos)
					{
					TblMarkRowInvalid (table, row);
					}
				}
				
			pos += height;
			oldPos += oldHeight;

			lastRecordNum = recordNum;
			row++;
			recordNum++;
			}

		dataHeight += height;

		// Is the table full?
		if (dataHeight >= tableHeight)		
			{
			// If we have a currently selected record, make sure that it is
			// not below  the last visible record.
			if ((CurrentRecord == noRecordSelected) ||
				 (CurrentRecord <= lastRecordNum)) break;

			TopVisibleRecord = recordNum;
			row = 0;
			dataHeight = 0;
			}
		}


	// Hide the items that don't have any data.
	numRows = TblGetNumberOfRows (table);
	while (row < numRows)
		{		
		TblSetRowUsable (table, row, false);
		row++;
		}
		
	// If the table is not full and the first visible record is 
	// not the first record	in the database, displays enough records
	// to fill out the table.
	while (dataHeight < tableHeight)
		{
		if (! fillTable) 
			break;
			
		recordNum = TopVisibleRecord;
		if ( ! SeekRecord (&recordNum, 1, dmSeekBackward))
			break;

		// Compute the height of the ToDo item's description.
		height = ListViewGetDescriptionHeight (recordNum, columnWidth, tableHeight);
			
		// If adding the item to the table will overflow the height of
		// the table, don't add the item.
		if (dataHeight + height > tableHeight)
			break;
		
		// Insert a row before the first row.
		TblInsertRow (table, 0);

		ListInitTableRow (table, 0, recordNum, height);
		
		TopVisibleRecord = recordNum;
		
		rowsInserted = true;

		dataHeight += height;
		}
		
	// If rows were inserted to full out the page, invalidate the whole
	// table, it all needs to be redrawn.
	if (rowsInserted)
		TblMarkTableInvalid (table);

	// If the height of the data in the table is greater than the height
	// of the table, then the bottom of the last row is clipped and the 
	// table is scrollable.
	lastItemClipped = (dataHeight > tableHeight);

	// Update the scroll arrows.
	ListViewUpdateScrollers (frm, lastRecordNum, lastItemClipped);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewNewToDo
 *
 * DESCRIPTION: This routine adds a new ToDo item to the ToDo list. 
 *              If a ToDo item is currently selected, the new items
 *              will be added before the selected item.  If not, the
 *              new item will be added after the last priority "one" item.
 *
 * PARAMETERS:  event - pointer to the keyDown event, or NULL
 *
 * RETURNED:    true if the event has handled
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewNewToDo (EventPtr event)
{
	Err error;
	Word i;
	Word row;
	Word column;
	Word recordNum;
	Word rowsInTable;
	Word category;
	Char desc [2];
	FontID curFont;
	FormPtr frm;
	TablePtr table;
	Boolean empty;
	Boolean handled = false;
	VoidHand recordH;
	ToDoItemType newToDo;
	ToDoDBRecordPtr recordP;
	
	table = GetObjectPtr (ListTable);
	

	// We'll have an event if the ToDo item is being created as the result
	// writing a character.
	if (event)
		{
		// Convert lower case alpha character to upper-case.
		desc[0] = event->data.keyDown.chr;
		desc[1] = 0;
		if ((UChar)desc[0] >= 'a' && (UChar)desc[0] <= 'z')
			desc[0] -= ('a' - 'A');
		handled = true;
		}
	else
		*desc = 0;



	// If a ToDo item is selected, insert the new item before the current 
	// selection.
	if (ItemSelected)
		{
		TblGetSelection (table, &row, &column);
		recordNum = TblGetRowID (table, row);

		// Check if the current record is empty, if it is, don't insert
		// a new record.
		recordH = DmQueryRecord (ToDoDB, recordNum);
		recordP = MemHandleLock (recordH);
		empty = (! recordP->description) && (! *GetToDoNotePtr(recordP));
		MemHandleUnlock (recordH);
		if (empty) 
			{
			ListViewRestoreEditState ();
			return (false);
			}

		error = ToDoInsertNewRecord (ToDoDB, &recordNum);
		if ((! error) && *desc)
			error = ToDoChangeRecord (ToDoDB, &recordNum, toDoDescription, desc);
	
	
		// Display an alert that indicates that the new record could 
		// not be created.
		if (error)
			{
			FrmAlert (DeviceFullAlert);
			return (false);
			}

		// Insert a row into the table, before the currently selected row.
		rowsInTable = TblGetNumberOfRows (table);
		if (row != TblGetLastUsableRow (table))
			{
			TblInsertRow (table, row);
			curFont = FntSetFont (ListFont);
			ListInitTableRow (table, row+1, recordNum, FntLineHeight ());
			FntSetFont (curFont);
			
			// Invalid all the row from the insert row to the end of the 
			// table so that they will be redrawn.
			for (i = row; i < rowsInTable; i++)
				TblMarkRowInvalid (table, i);
			}

		// If we're inserting after the last visible row,  force the table
		// to scroll up one row.
		else if (rowsInTable > 1)
			TopVisibleRecord = TblGetRowID (table, 1);
		}


	// Add a new ToDo item after all the priority "one" items.
	else
		{
		newToDo.priority = defaultPriority;
		*((WordPtr) &newToDo.dueDate) = toDoNoDueDate;
		newToDo.description = desc;
		newToDo.note = NULL;
		
		// If we're showing all categories the new item will be uncategorized.
		if (CurrentCategory == dmAllCategories)
			category = dmUnfiledCategory;
		else
			category = CurrentCategory;

		error = ToDoNewRecord (ToDoDB, &newToDo, category, &recordNum);

		// Display an alert that indicates that the new record could 
		// not be created.
		if (error)
			{
			FrmAlert (DeviceFullAlert);
			return (false);
			}

		if (TopVisibleRecord == recordNum)
			{
			// Invalid all the row so that they be drawn.
			rowsInTable = TblGetNumberOfRows (table);
			for (i = 0; i < rowsInTable; i++)
				TblSetRowUsable (table, i, false);
			}
		else
			TopVisibleRecord = recordNum;		
		}
		
	CurrentRecord = recordNum;

	ListViewLoadTable (true);
	TblRedrawTable (table);

	// Give the focus to the new item.
	TblFindRowID (table, recordNum, &row);
	frm = FrmGetActiveForm ();
	FrmSetFocus (frm, FrmGetObjectIndex (frm, ListTable));
	TblGrabFocus (table, row, descColumn);
	FldGrabFocus (TblGetCurrentField (table));

	ItemSelected = true;

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDeleteToDo
 *
 * DESCRIPTION: This routine deletes the selected ToDo item.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewDeleteToDo (void)
{
	Word i;
	Word row;
	Word column;
	Word numRows;
	Word recordNum;
	TablePtr table;
		
	// If no ToDo item is selected, return.
	table = GetObjectPtr (ListTable);

	// Check if we are editing an item.
	if (! TblEditing (table))
		return;

	TblGetSelection (table, &row, &column);
	TblReleaseFocus (table);

	// Check if the record is empty, if it is, clear the edit state, 
	// this will delete the current record when it's blank.
	recordNum = TblGetRowID (table, row);

	if (ListViewClearEditState ())
		return;

	// Display an alert to confirm the delete operation, and delete the
	// record if the alert is confirmed.
	if (! DeleteRecord (recordNum))
		return;

	// Invalid the row deleted and all the row following the deleted record so 
	// that they will redraw.
	numRows = TblGetNumberOfRows (table);
	for (i = row; i < numRows; i++)
		TblSetRowUsable (table, i, false);

	ListViewLoadTable (true);
	TblRedrawTable (table);
	
	ItemSelected = false;
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDeleteNote
 *
 * DESCRIPTION: This routine deletes the note attached to the selected 
 *              ToDo item.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewDeleteNote ()
{
	Word i;
	Word row;
	Word column;
	Word height;
	Word newHeight;
	Word tableHeight;
	Word columnWidth;
	Word recordNum;
	Word rowsInTable;
	TablePtr table;
	Boolean empty;
	RectangleType r;
	ToDoDBRecordPtr recordP;
		
	table = GetObjectPtr (ListTable);

	// Check if we are editing an item.
	if (! TblEditing (table))
		return;

	// Get the selected record.
	TblGetSelection (table, &row, &column);
	recordNum = TblGetRowID (table, row);
	
	// Check if the record has a note attached.
	recordP = MemHandleLock (DmQueryRecord (ToDoDB, recordNum));
	empty = (! *GetToDoNotePtr(recordP));
	MemPtrUnlock (recordP);
	if (empty) return;

	// Confirm that the note should be deleted.
	if (FrmAlert(DeleteNoteAlert) != DeleteNoteYes)
		return;

	TblReleaseFocus (table);

	// Get the current height of the description.
	height = TblGetRowHeight (table, row);

	// Remove the note from the record.
	ToDoChangeRecord (ToDoDB, &recordNum, toDoNote, "");

	// Mark the record dirty.	
	DirtyRecord (recordNum);
	
	// Mark the current row non-usable so the it will redraw.
	TblSetRowUsable (table, row, false);
	
	// Get the new height of the description, the desciption may be short
	// because we can draw in the space vacated by the note indicator.
	columnWidth = TblGetColumnWidth (table, descColumn);
	TblGetBounds (table, &r);
	tableHeight = r.extent.y;
	newHeight =  ListViewGetDescriptionHeight (recordNum, columnWidth, tableHeight);
	
	// If the height of the description has changed, invalid all the row
	// after the current row so that they be redrawn.
	if (height != newHeight)
		{
		rowsInTable = TblGetNumberOfRows (table);
		for (i = row+1; i < rowsInTable; i++)
			TblSetRowUsable (table, i, false);
		}
	
	ListViewLoadTable (true);
	TblRedrawTable (table);

	ListViewRestoreEditState ();
}

/***********************************************************************
 *
 * FUNCTION:    ListViewCrossOutItem
 *
 * DESCRIPTION: This routine is called when a ToDo item is marked 
 *              complete.  If completed item are not display then
 *              we display an animation of a line being drawn through
 *              the ToDo item.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/96	Initial Revision
 *
 ***********************************************************************/
static void ListViewCrossOutItem (Word row)
{
	Word width;
	Word length;
	Word maxWidth;
	Word recordNum;
	Word charsToDraw;
	Short x, y;
	Short lineHeight;
	FontID curFont;
	CharPtr chars;
	TablePtr table;
	RectangleType r;
	RectangleType tableR;
	VoidHand recordH;
	ToDoDBRecordPtr toDoRec;

	table = GetObjectPtr (ListTable);

	// Get a pointer to the ToDo record.
	recordNum = TblGetRowID (table, row);
	recordH = DmQueryRecord( ToDoDB, recordNum);
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);

	curFont = FntSetFont (ListFont);
	lineHeight = FntLineHeight ();	

	TblGetBounds (table, &tableR);

	TblGetItemBounds (table, row, descColumn, &r);
	maxWidth = r.extent.x;
	
	// If the record has a note, leave space for the note indicator.
	if (*GetToDoNotePtr (toDoRec))
		maxWidth -= tableNoteIndicatorWidth;

	chars = &toDoRec->description;
	length = 0;

	y = r.topLeft.y + (lineHeight >> 1);
	while (*chars)
		{
		// Get the number of character on each line.
		length = FldWordWrap (chars, maxWidth);
		charsToDraw = length;
		
		// Don't draw the linefeedChr character.
		if ((charsToDraw) && chars[charsToDraw-1] == linefeedChr)
			charsToDraw--;
	
		// Don't draw trailing spaces to tabs.
		while (charsToDraw && (chars[charsToDraw-1] == spaceChr || 
			chars[charsToDraw-1] == tabChr))
			charsToDraw--;
		
		// Draw a line over the character.
		width = FntLineWidth (chars, charsToDraw);
		x = r.topLeft.x;
		while (width)
			{
			WinDrawLine (x, y, x, y);
			x++;
			width--;
			}
		chars += length;
		y += FntLineHeight ();
		
		if (y > tableR.topLeft.y + tableR.extent.y)
			break;
		}

	MemHandleUnlock (recordH);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewChangeCompleteStatus
 *
 * DESCRIPTION: This routine is called when a ToDo item is marked 
 *              complete.  If completed items are not displayed
 *              (a preference setting),  this routine will remove the
 *              item from the list.
 *
 * PARAMETERS:  row      - row in the table
 *              complete - true if the item is marked complete
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/1/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewChangeCompleteStatus (Word row, Word complete)
{
	Word recordNum;
	ULong ticks;
	Boolean deleted;
	TablePtr table;
	DateType dueDate;
	DateTimeType today;


	table = GetObjectPtr (ListTable);
	recordNum = TblGetRowID (table, row);
	
	// If completed item are not shown then display an animation 
	// of a line being drawn through the item.
	if (! ShowCompletedItems)
		{
		ticks = TimGetTicks ();
		ListViewCrossOutItem (row);
		}

	// Update the record to reflect the new completion status.
	ToDoChangeRecord (ToDoDB, &recordNum, toDoComplete, &complete);

	// Should the due date be changed to the completion date?
	if (complete && ChangeDueDate)
		{
		TimSecondsToDateTime (TimGetSeconds (), &today);
		dueDate.year = today.year - firstYear;
		dueDate.month = today.month;
		dueDate.day = today.day;
		ToDoChangeRecord (ToDoDB, &recordNum, toDoDueDate, &dueDate);
		CurrentRecord = recordNum;
		}

	// Mark the record dirty.
	DirtyRecord (recordNum);


	// If completed items are shown and the dae date was change, redraw 
	// the list.
	if (ShowCompletedItems)
		{
		if (complete && ChangeDueDate)
			FrmUpdateForm (ListView, updateItemMove);
		else
			ListViewRestoreEditState ();
		}

	// If completed items are hidden, update the table.
	else
		{
		deleted = ClearEditState ();

		ListViewLoadTable (false);
			
		// If the current record wasn't empty, delay before redrawing the 
		// table so that the crossout animation may be seen.
		if (! deleted)
			{
			while (TimGetTicks () - ticks < crossOutDelay)
				;
			}

		TblRedrawTable (table);
		}
}

/***********************************************************************
 *
 * FUNCTION:    ListVewSelectDueDate
 *
 * DESCRIPTION: This routine is called when a "due date" item in the do to list
 *              is selected.  The due date  popup list is displayed; if 
 *              the due date of the item is changed, the record is updated
 *              and the re-sorted list is redrawn.
 *
 * PARAMETERS:  table - ToDo table
 *              row   - row in the table
 *              
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/9/95	Initial Revision
 *
 ***********************************************************************/
static void ListVewSelectDueDate (TablePtr table, Word row)
{
	int itemSeleted;
	Word recordNum;
	Word newRecordNum;
	ListPtr lst;
	DateType dueDate;
	VoidHand recordH;
	RectangleType r;
	ToDoDBRecordPtr toDoRec;

	lst = GetObjectPtr (ListDueDateList);

	// Unhighlight the selected item.
	TblUnhighlightSelection (table);

	// Get the due date from the ToDo record.
	recordNum = TblGetRowID (table, row);
	recordH = DmQueryRecord (ToDoDB, recordNum);
	toDoRec = (ToDoDBRecordPtr) MemHandleLock (recordH);
	dueDate = toDoRec->dueDate;
	MemHandleUnlock (recordH);


	// Set the popup list's selection.
	if (DateToInt (dueDate) == toDoNoDueDate)
		LstSetSelection (lst, noDueDateItem);
	else
		LstSetSelection (lst, selectDateItem);

	
	// Position the list.
	TblGetItemBounds (table, row, dueDateColumn, &r);
	LstSetPosition (lst, r.topLeft.x, r.topLeft.y);
	
	// Display the list until a selection is made.
	itemSeleted = LstPopupList (lst);

	// Minus one indicates the popup list was dismissed without a selection
	// being made.
	if (itemSeleted == -1) return;
	
	DetermineDueDate (itemSeleted, &dueDate);

	// Update the database record.
	newRecordNum = recordNum;
	ToDoChangeRecord (ToDoDB, &newRecordNum, toDoDueDate, &dueDate);

	// Changing the due date may change the record's index.
	CurrentRecord = newRecordNum;

	// Mark the record dirty.
	DirtyRecord (newRecordNum);
	
	// Make sure the row is redrawn.
	TblMarkRowInvalid (table, row);

	// Send an event that will cause the view to be redrawn.
	FrmUpdateForm (ListView, updateItemMove);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSelectPriority
 *
 * DESCRIPTION: This routine is called when a "priority" item in the do to list
 *              is selected.  A popup list of priority is displayed; if 
 *              the priority of an item is changed, the record is updated
 *              and the re-sorted list is redrawn.
 *
 * PARAMETERS:  table - ToDo table
 *              row   - row in the table
 *              
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/9/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewSelectPriority (TablePtr table, Word row)
{
	int priority;
	int newPriority;
	Word recordNum;
	Word newRecordNum;
	ListPtr lst;
	RectangleType r;

	lst = GetObjectPtr (ListPriorityList);

	// Unhighlight the priority.
	TblUnhighlightSelection (table);

	// Set the list's selection to the current priority.
	priority = TblGetItemInt (table, row, priorityColumn);
	LstSetSelection (lst, priority-1);
	
	// Position the list.
	TblGetItemBounds (table, row, priorityColumn, &r);
	LstSetPosition (lst, r.topLeft.x, r.topLeft.y);
	
	newPriority = LstPopupList (lst);

	// Minus one indicates the popup list was dismissed without a selection
	// being made.
	if ((newPriority == -1) || (newPriority+1 == priority) )
		{
		ListViewRestoreEditState ();
		return;
		}
	
	// Update the database record.
	newPriority++;									// one base the priority
	recordNum = TblGetRowID (table, row);
	newRecordNum = recordNum;
	ToDoChangeRecord (ToDoDB, &newRecordNum, toDoPriority, &newPriority);
	
	// Changing the priority may change the record's index.
	CurrentRecord = newRecordNum;

	// Mark the record dirty.
	DirtyRecord (newRecordNum);

	// Make sure the row is redrawn.
	TblMarkRowInvalid (table, row);

	// Send an event that will cause the view to be redrawn.
	FrmUpdateForm (ListView, updateItemMove);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSelectItemsCategory
 *
 * DESCRIPTION: This routine is called when a "category" item in the do to 
 *              list is selected.  A popup list of categories is displayed,
 *              if the category of an item is changed, the record is updated
 *              and the re-sorted list is redrawn.
 *
 * PARAMETERS:  table - ToDo table
 *              row   - row in the table
 *              
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/12/96	Initial Revision
 *
 ***********************************************************************/
static void ListViewSelectItemsCategory (TablePtr table, Word row)
{
	Int				curSelection;
	Int				newSelection;
	Word 				attr;
	Word				category;
	Word				recordNum;
	ListPtr			lst;
	CharPtr			name;
	RectangleType	r;

	lst = GetObjectPtr (ListItemsCategoryList);

	// Get the category of the item in the specified row.
	recordNum = TblGetRowID (table, row);
	DmRecordInfo (ToDoDB, recordNum, &attr, NULL, NULL);
	category = attr & dmRecAttrCategoryMask;

	// Unhighlight the priority.
	TblUnhighlightSelection (table);

	LstSetPosition (lst, 0, 0);
	
	// Create a list of categories.
	CategoryCreateList (ToDoDB, lst, category, false, true, 1, 0, true);

	// Position the list.
	TblGetItemBounds (table, row, categoryColumn, &r);
	LstSetPosition (lst, r.topLeft.x, r.topLeft.y);


	// Display the category list.
	curSelection = LstGetSelection (lst);
	newSelection = LstPopupList (lst);

	// Was a new category selected?
	if ((newSelection != curSelection) && (newSelection != -1))
		{
		name = LstGetSelectionText (lst, newSelection);
		category = CategoryFind (ToDoDB, name);

		// Update the database record's category.
		ToDoChangeRecord (ToDoDB, &recordNum, toDoCategory, &category);

		// Changing the category may change the record's index
		CurrentRecord = recordNum;
	
		// Mark the record dirty.
		DirtyRecord (recordNum);

		// Make sure the row is redrawn.
		TblMarkRowInvalid (table, row);

		// Send an event that will cause the view to be redrawn.
		FrmUpdateForm (ListView, updateItemMove);
		}

	else
		{
		ListViewRestoreEditState ();
		}

	CategoryFreeList (ToDoDB, lst, false, false);
	}


/***********************************************************************
 *
 * FUNCTION:    ListViewItemSelected
 *
 * DESCRIPTION: This routine is called when an item in the do to list
 *              is selected.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/9/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewItemSelected (EventPtr event)
{
	Word on;
	Word row;
	Word column;
	TablePtr table;
	
	table = event->data.tblSelect.pTable;
	row = event->data.tblSelect.row;
	column = event->data.tblSelect.column;

	if (column == completedColumn)
		{
		on = TblGetItemInt (table, row, column);
		ListViewChangeCompleteStatus (row, on);
		}

	else if (column == priorityColumn)
		{
		ListViewSelectPriority (table, row);
		}

	else if (column == descColumn)
		{
		CurrentRecord = TblGetRowID (table, row);
		// If the table is in edit mode then the description field
		// was selected, otherwise the note indicator must have
		// been selected.
		if (TblEditing (table))
			{
			ItemSelected = true;
			}

		else
			FrmGotoForm (NoteView);
		}

	else if (column == dueDateColumn)
		{
		ListVewSelectDueDate (table, row);
		}
	
	else if (column == categoryColumn)
		{
		ListViewSelectItemsCategory (table, row);
		}
	
}


/***********************************************************************
 *
 * FUNCTION:    ListViewResizeDescription
 *
 * DESCRIPTION: This routine is called when the height of a ToDo item's
 *              description is changed as a result of user input.
 *              If the new height of the field is shorter,  more items
 *              may need to be added to the bottom of the list.
 *              
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/18/95		Initial Revision
 *
 ***********************************************************************/
static void ListViewResizeDescription (EventPtr event)
{
	Word lastRow;
	Word lastRecord;
	Word topRecord;
	FieldPtr fld;
	TablePtr table;
	Boolean lastItemClipped;
	RectangleType itemR;
	RectangleType tableR;
	RectangleType fieldR;
	
	// Get the current height of the field;
	fld = event->data.fldHeightChanged.pField;
	FldGetBounds (fld, &fieldR);

	// Have the table object resize the field and move the items below
	// the field up or down.
	table = GetObjectPtr (ListTable);
	TblHandleEvent (table, event);
	
	
	// If the field's height has expanded , and there are no items scrolled
	// off the top of the table, just update the scrollers.
	if (event->data.fldHeightChanged.newHeight >= fieldR.extent.y)
		{
		topRecord = TblGetRowID (table, 0);
		if (topRecord != TopVisibleRecord)
			TopVisibleRecord = topRecord;
		else
			{
			// Update the scroll arrows.
			lastRow = TblGetLastUsableRow (table);
			TblGetBounds (table, &tableR);
			TblGetItemBounds (table, lastRow, descColumn, &itemR);
			lastItemClipped = (itemR.topLeft.y + itemR.extent.y > 
			 	tableR.topLeft.y + tableR.extent.y);
			lastRecord = TblGetRowID (table, lastRow);
			ListViewUpdateScrollers (FrmGetActiveForm (), lastRecord, 
				lastItemClipped);

			return;
			}
		}
		
	// Add items to the table to fill in the space made available by the 
	// shortening the field.
	ListViewLoadTable (false);
	TblRedrawTable (table);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewSelectCategory
 *
 * DESCRIPTION: This routine handles selection, creation and deletion of
 *              categories in the List View. 
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    The index of the new category.
 *
 *              The following global variables are modified:
 *							CurrentCategory
 *							ShowAllCategories
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *
 ***********************************************************************/
static Word ListViewSelectCategory (void)
{
	FormPtr frm;
	TablePtr table;
	Word category;
	Boolean categoryEdited;
	
	// Process the category popup list.  
	category = CurrentCategory;

	frm = FrmGetActiveForm();
	categoryEdited = CategorySelect (ToDoDB, frm, ListCategoryTrigger,
					    ListCategoryList, true, &category, CategoryName, 1, 0);
	
	if (category == dmAllCategories)
		ShowAllCategories = true;
	else
		ShowAllCategories = false;
		
	if ( (categoryEdited) || (CurrentCategory != category) || ShowCategories)
		{
		ChangeCategory (category);

		// Display the new category.
		ListViewLoadTable (true);
		table = GetObjectPtr (ListTable);
		TblEraseTable (table);
		TblDrawTable (table);
		}

	return (category);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewNextCategory
 *
 * DESCRIPTION: This routine displays the next category, if the last
 *              catagory is being displayed we wrap to the first category.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 *              The following global variables are modified:
 *							CurrentCategory
 *							ShowAllCategories
 *							CategoryName
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/15/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewNextCategory (void)
{
	Word index;
	Word category;
	FormPtr frm;
	TablePtr table;
	ControlPtr ctl;

	category = CurrentCategory;

	// Find the next category that has displayable items.
	do
		{
		CurrentCategory = CategoryGetNext (ToDoDB, CurrentCategory);
		
		index = 0;
		if (SeekRecord (&index, 0, dmSeekForward))
			break;
		}
	while (CurrentCategory != dmAllCategories);


	if (category == CurrentCategory) return;

	if (CurrentCategory == dmAllCategories)
		ShowAllCategories = true;
	else
		ShowAllCategories = false;

	ChangeCategory (CurrentCategory);

	// Set the label of the category trigger.
	frm = FrmGetActiveForm ();
	ctl = GetObjectPtr (ListCategoryTrigger);
	CategoryGetName (ToDoDB, CurrentCategory, CategoryName);
	CategorySetTriggerLabel (ctl, CategoryName);


	// Display the new category.
	ListViewLoadTable (true);
	table = GetObjectPtr (ListTable);
	TblEraseTable (table);
	TblDrawTable (table);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewGotoAppointment
 *
 * DESCRIPTION: This routine sets up the global variables such that the 
 *              list view will display the text found by the text search
 *              command.
 *
 * PARAMETERS:  event - frmGotoEvent 
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewGotoItem (EventPtr event)
{
	ItemSelected = true;
	CurrentRecord = event->data.frmGoto.recordNum;
	TopVisibleRecord = CurrentRecord;
	ListEditPosition = event->data.frmGoto.matchPos;
	ListEditSelectionLength = event->data.frmGoto.matchLen;
}


/***********************************************************************
 *
 * FUNCTION:    ListViewScroll
 *
 * DESCRIPTION: This routine scrolls the list of ToDo items
 *              in the direction specified.
 *
 * PARAMETERS:  direction - up or dowm
 *              oneLine   - if true the list is scrolled by a single line,
 *                          if false the list is scrolled by a full screen.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewScroll (DirectionType direction)
{
	Word				row;
	Word				index;
	Word				height;
	Word 				recordNum;
	Word 				columnWidth;
	Word 				tableHeight;
	TablePtr 		table;
	RectangleType	r;

	
	table = GetObjectPtr (ListTable);
	TblReleaseFocus (table);

	CurrentRecord = noRecordSelected;

	// Get the height of the table and the width of the description
	// column.
	TblGetBounds (table, &r);
	tableHeight = r.extent.y;
	height = 0;
	columnWidth = TblGetColumnWidth (table, descColumn);

	// Scroll the table down.
	if (direction == down)
		{
		// Get the record index of the last visible record.  A row 
		// number of minus one indicates that there are no visible rows.
		row = TblGetLastUsableRow (table);
		if (row == -1) return;
		
		recordNum = TblGetRowID (table, row);				

		// If there is only one record visible, this is the case 
		// when a record occupies the whole screeen, move to the 
		// next record.
		if (row == 0)
			SeekRecord (&recordNum, 1, dmSeekForward);
		}

	// Scroll the table up.
	else
		{
		// Scan the records before the first visible record to determine 
		// how many record we need to scroll.  Since the heights of the 
		// records vary,  we sum the heights of the records until we get
		// a screen full.
		recordNum = TblGetRowID (table, 0);
		height = TblGetRowHeight (table, 0);
		if (height >= tableHeight)
			height = 0;

		while (height < tableHeight)
			{
			index = recordNum;
			if ( ! SeekRecord (&index, 1, dmSeekBackward) ) break;
			height += ListViewGetDescriptionHeight (index, columnWidth, tableHeight);
			if ((height <= tableHeight) || (recordNum == TblGetRowID (table, 0)))
				recordNum = index;
			}
		}

	TblMarkTableInvalid (table);
	TopVisibleRecord = recordNum;
	ListViewLoadTable (true);	

	TblUnhighlightSelection (table);
	TblRedrawTable (table);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDeleteCompleted
 *
 * DESCRIPTION: This routine deletes ToDo items that are marked 
 *              complete.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/29/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewDeleteCompleted (void)
{
	Word i;
	Word index;
	Word ctlIndex;
	Word numRecord;
	Word rowsInTable;
	Word buttonHit;
	FormPtr alert;
	TablePtr table;
	Boolean complete;
	Boolean saveBackup;
	VoidHand recordH;
	ToDoDBRecordPtr recordP;


	table = GetObjectPtr (ListTable);
	TblReleaseFocus (table);

	// Display an alert to comfirm the operation.
	alert = FrmInitForm (DeleteCompletedDialog);

	ctlIndex = FrmGetObjectIndex (alert, DeleteCompletedSaveBackup);
	FrmSetControlValue (alert, ctlIndex, SaveBackup);
	buttonHit = FrmDoDialog (alert);
	saveBackup = FrmGetControlValue (alert, ctlIndex);

	FrmDeleteForm (alert);

	if (buttonHit == DeleteCompletedCancel)
		return;

	SaveBackup = saveBackup;

	// Delete records marked complete.
	numRecord = DmNumRecords (ToDoDB);
	if (! numRecord) return;
	
	for (index = numRecord-1; (short) index >= 0; index--)
		{
		recordH = DmGetRecord (ToDoDB, index);
		if (recordH == 0) continue;
		
		recordP = MemHandleLock (recordH);
		complete = ((recordP->priority & completeFlag) == completeFlag);
		MemHandleUnlock (recordH);
		DmReleaseRecord (ToDoDB, index, complete);
		
		if (complete)
			{
			if (SaveBackup)
				DmArchiveRecord (ToDoDB, index);
			else
				DmDeleteRecord (ToDoDB, index);
				
			// Move deleted record to the end of the index so that the 
			// sorting routine will work.
			DmMoveRecord (ToDoDB, index, numRecord);
			}
		}

	// Redraw the ToDo list.
	rowsInTable = TblGetNumberOfRows (table);
	for (i = 0; i < rowsInTable; i++)
		TblSetRowUsable (table, i, false);

	ListViewLoadTable (true);	
	TblRedrawTable (table);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewDoCommand
 *
 * DESCRIPTION: This routine preforms the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/29/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewDoCommand (Word command)
{
	Word 			pasteLen;
	VoidHand 	pasteCharsH;
	FieldPtr 	fld;
	Boolean 		handled = true;
	
	
	switch (command)
		{
		case DeleteCmd:
			if (ItemSelected)
				ListViewDeleteToDo ();
			else
				FrmAlert (SelectItemAlert);
			break;

		case CreateNoteCmd:
			if (ItemSelected)
				FrmGotoForm (NoteView);
			else
				FrmAlert (SelectItemAlert);
			break;

		case DeleteNoteCmd:
			if (ItemSelected)
				ListViewDeleteNote ();
			else
				FrmAlert (SelectItemAlert);
			break;
			
		case SendRecordCmd:
			if (ItemSelected)
				ToDoSendRecord(ToDoDB, CurrentRecord);
			else
				FrmAlert (SelectItemAlert);
			break;
			
		case SendCategoryCmd:
			ToDoSendCategory(ToDoDB, CurrentCategory);
			break;
			
		case FontCmd:
			ListViewClearEditState ();
			ListFont = SelectFont (ListFont);
			break;
			
		case PhoneLookupCmd:
			if (ItemSelected)
				{
				fld = GetFocusObjectPtr ();
				if (! fld) break;
				PhoneNumberLookup (fld);
				}
			else
				FrmAlert (SelectItemAlert);
			break;

		case AboutCmd:
			MenuEraseStatus (0);
			ListViewClearEditState ();
			AbtShowAbout (sysFileCToDo);
			break;
						
		case DeleteCompletedCmd:
			ListViewClearEditState ();
			ListViewDeleteCompleted ();
			break;
						
		case sysEditMenuPasteCmd:
			fld = GetFocusObjectPtr ();
			if (! fld)
				{
				pasteCharsH = ClipboardGetItem (clipboardText, &pasteLen);
				if (pasteCharsH && pasteLen)
					{
					ListViewNewToDo (NULL);
					fld = GetFocusObjectPtr ();
					}
				}
			handled = false;
			break;
			
		default:
			handled = false;
		}	

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewGetColumnWidth
 *
 * DESCRIPTION: This routine returns the width of the specified 
 *              column.
 *
 * PARAMETERS:	 column - column of the list table
 *
 * RETURNED:	 width of the column in pixels
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/10/97	Initial Revision
 *
 ***********************************************************************/
static Word ListViewGetColumnWidth (Word column)
{
	Char		chr;
	Char		dateBuffer [dateStringLength];
	Word		width;
	FontID	curFont;
	CharPtr	dateStr;


	curFont = FntSetFont (ListFont);


	if (column == priorityColumn)
		{
		if (ListFont == stdFont)
			FntSetFont (boldFont);
		chr = '1';
		width = (FntCharWidth (chr) - 1) + 6;
		}

	else if (column == dueDateColumn)
		{
		DateToAscii (12, 31, 1997,	DateFormat, dateBuffer);

		// Remove the year from the date string.
		dateStr = dateBuffer;
		if ((DateFormat == dfYMDWithSlashes) ||
			 (DateFormat == dfYMDWithDots) ||
			 (DateFormat == dfYMDWithDashes))
			dateStr += 3;
		else
			dateStr[StrLen(dateStr) - 3] = 0;

		width = FntCharsWidth (dateStr, StrLen (dateStr));

		// Get the width of the character that indicates the item is due.
		// Don't count the whitespace in the character.
		if (ListFont == stdFont)
			FntSetFont (boldFont);
		chr = '!';
		width += FntCharWidth (chr) - 1;
		}

	// Size the category column such that is can display about five 
	// characters.
	else if (column == categoryColumn)
		{
		chr = '1';
		width = (FntCharWidth (chr) * 5) - 1;
		}

	FntSetFont (curFont);
	
	return (width);
}

/***********************************************************************
 *
 * FUNCTION:    ListViewInit
 *
 * DESCRIPTION: This routine initializes the "List View" of the 
 *              ToDo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void ListViewInit (FormPtr frm)
{
	Word row;
	Word rowsInTable;
	Word width;
	FontID fontID;
	TablePtr table;
	ControlPtr ctl;
	RectangleType r;

	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ListTable));

	rowsInTable = TblGetNumberOfRows (table);
	for (row = 0; row < rowsInTable; row++)
		{		
		TblSetItemStyle (table, row, completedColumn, checkboxTableItem);
		TblSetItemStyle (table, row, priorityColumn, numericTableItem);
		TblSetItemStyle (table, row, descColumn, textTableItem);
		TblSetItemStyle (table, row, dueDateColumn, customTableItem);
		TblSetItemStyle (table, row, categoryColumn, customTableItem);


		// Set the font used to draw the text of the row.
		if (ListFont == stdFont)
			fontID = boldFont;
		else
			fontID = ListFont;
		TblSetItemFont (table, row, priorityColumn, fontID);
		TblSetItemFont (table, row, descColumn, ListFont);
		TblSetItemFont (table, row, dueDateColumn, ListFont);
		TblSetItemFont (table, row, categoryColumn, ListFont);

		TblSetRowUsable (table, row, false);
		}


	TblSetColumnUsable (table, completedColumn, true);
	TblSetColumnUsable (table, priorityColumn, ShowPriorities);
	TblSetColumnUsable (table, descColumn, true);
	TblSetColumnUsable (table, dueDateColumn, ShowDueDates);
	TblSetColumnUsable (table, categoryColumn, ShowCategories);
	
	
	// Set the spacing after the complete column.
	if (ShowPriorities)
		{
		TblSetColumnSpacing (table, completedColumn, 0);
		TblSetColumnSpacing (table, priorityColumn, spaceBeforeDesc);
		}
	else
		{
		TblSetColumnSpacing (table, completedColumn, spaceBeforeDesc);
		}	

	if (ShowDueDates && ShowCategories)
		{
		TblSetColumnSpacing (table, dueDateColumn, spaceBeforeCategory);
		}


	// Set the width of the priorities column.
	if (ShowPriorities)
		{
		width = ListViewGetColumnWidth (priorityColumn);
		TblSetColumnWidth (table, priorityColumn, width);
		}


	// Set the width of the due date column.
	if (ShowDueDates)
		{
		width = ListViewGetColumnWidth (dueDateColumn);
		TblSetColumnWidth (table, dueDateColumn, width);
		}


	// Set the width of the category column.
	if (ShowCategories)
		{
		width = ListViewGetColumnWidth (categoryColumn);
		TblSetColumnWidth (table, categoryColumn, width);
		}


	// Set the width of the description column.
	TblGetBounds (table, &r);
	width = r.extent.x;
	width -= TblGetColumnWidth (table, completedColumn) + 
				TblGetColumnSpacing (table, completedColumn);
	if (ShowPriorities)
		width -= TblGetColumnWidth (table, priorityColumn) + 
				   TblGetColumnSpacing (table, priorityColumn);
	if (ShowDueDates)
		width -= TblGetColumnWidth (table, dueDateColumn) + 
				   TblGetColumnSpacing (table, dueDateColumn);
	if (ShowCategories)
		width -= TblGetColumnWidth (table, categoryColumn) + 
				   TblGetColumnSpacing (table, categoryColumn);


	TblSetColumnWidth (table, descColumn, width);	


	// Set the callback routines that will load and save the 
	// description field.
	TblSetLoadDataProcedure (table, descColumn, (TableLoadDataFuncPtr)ListViewGetDescription);
	TblSetSaveDataProcedure (table, descColumn, (TableSaveDataFuncPtr)ListViewSaveDescription);

	// Set the callback routine that draws the due date field.
	TblSetCustomDrawProcedure (table, dueDateColumn, ListViewDrawDueDate);

	// Set the callback routine that draws the category field.
	TblSetCustomDrawProcedure (table, categoryColumn, ListViewDrawCategory);

	ListViewLoadTable (true);

	// Set the label of the category trigger.
	ctl = GetObjectPtr (ListCategoryTrigger);
	CategoryGetName (ToDoDB, CurrentCategory, CategoryName);
	CategorySetTriggerLabel (ctl, CategoryName);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewUpdateDisplay
 *
 * DESCRIPTION: This routine updates the display of the List View
 *
 * PARAMETERS:  updateCode - a code that indicated what changes have been
 *                           made to the ToDo list.
 *                		
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/2/95		Initial Revision
 *
 ***********************************************************************/
static Boolean ListViewUpdateDisplay (Word updateCode)
{
	UInt attr;
	Word row;
	Word column;
	Word numRows;
	Word recordNum;
	ULong	uniqueID;
	TablePtr table;
	ControlPtr ctl;
	
	table = GetObjectPtr (ListTable);

	// Was the UI unable to save an image of the List View when it 
	// obscured part of the view with another dialog.  If so we'll let 
	// the UI handle this event.
	if (updateCode & frmRedrawUpdateCode)
		{
		return (false);
		}

	// Were the display options modified (ToDoOption dialog) or was the 
	// font changed?
	if (updateCode & (updateDisplayOptsChanged | updateFontChanged))
		{
		TblEraseTable (table);
		ListViewInit (FrmGetActiveForm ());
		TblDrawTable (table);
		return (true);;
		}

	// Was the category of an item changed?
	else if (updateCode & updateCategoryChanged)
		{
		if (ShowAllCategories)
			CurrentCategory = dmAllCategories;
		else
			{
			DmRecordInfo (ToDoDB, CurrentRecord, &attr, NULL, NULL);
			CurrentCategory = attr & dmRecAttrCategoryMask;
			}
		// Set the label of the category trigger.
		ctl = GetObjectPtr (ListCategoryTrigger);
		CategoryGetName (ToDoDB, CurrentCategory, CategoryName);
		CategorySetTriggerLabel (ctl, CategoryName);

		TopVisibleRecord = CurrentRecord;
		}

	// Was an item deleted or marked secret? If so, invalid all the rows 
	// following the deleted/secret record.
	if ( (updateCode & updateItemDelete) || (updateCode & updateItemHide))
		{
		TblGetSelection (table, &row, &column);
		numRows = TblGetNumberOfRows (table);
		for ( ; row < numRows; row++)
			TblSetRowUsable (table, row, false);
		}

	// Was the item move?
	// Items are moved when their priority or due date is changed.  
	else if (updateCode & updateItemMove)
		{

		// Always redraw the current record
		DmRecordInfo (ToDoDB, CurrentRecord, NULL, &uniqueID, NULL);
		if (TblFindRowData (table, uniqueID, &row))
			TblSetRowUsable (table, row, false);

		// We don't want to scroll the current record into view.
		recordNum = CurrentRecord;
		CurrentRecord = noRecordSelected;
		ListViewLoadTable (true);

		TblRedrawTable (table);

		// If the item is still visible we will restore the edit state.
		CurrentRecord = recordNum;
		if (! TblFindRowData (table, uniqueID, &row))
			ClearEditState ();

		return (true);
		}

	ListViewLoadTable (true);
	TblRedrawTable (table);
	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    ListViewHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "List View"
 *              of the ToDo application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	2/21/95		Initial Revision
 *			kcr	10/11/95		set initial shift for new todos created via
 *									'New' button, and for re-edit of empty desc field.
 *
 ***********************************************************************/
static Boolean ListViewHandleEvent (EventPtr event)
{
	Word row;
	FormPtr frm;
	TablePtr table;
	DateType date;
	Boolean handled = false;
	

	if (event->eType == keyDownEvent)
		{
		// ToDo key pressed?
		if (ChrIsHardKey(event->data.keyDown.chr))
			{
			if ((event->data.keyDown.modifiers & poweredOnKeyMask))
				{
				// If the date has changed since the last time the device 
				// was powered on then redraw the ToDo list so that pass 
				// due item will be display correctly.
				DateSecondsToDate (TimGetSeconds (), &date);
				if (DateToInt (date) != DateToInt (Today))
					{
					Today = date;
					table = GetObjectPtr (ListTable);
					TblEraseTable (table);
					TblDrawTable (table);
					}

				}
			// Display the next category
			else
				{
				ListViewClearEditState ();
				ListViewNextCategory ();
				}
			handled = true;
			}

		// Scroll up key presed?
		else if (event->data.keyDown.chr == pageUpChr)
			{
			ListViewClearEditState ();
			ListViewScroll (up);
			handled = true;
			}

		// Scroll down key presed?
		else if (event->data.keyDown.chr == pageDownChr)
			{
			ListViewClearEditState ();
			ListViewScroll (down);
			handled = true;
			}

		// Send Data key presed?
		else if (event->data.keyDown.chr == sendDataChr)
			{
			if (ItemSelected)
				ToDoSendRecord(ToDoDB, CurrentRecord);
			else
				FrmAlert (SelectItemAlert);
			handled = true;
			}

		// If no item is selected and the character is display, 
		// create a new ToDo item.
		else if ((! ItemSelected) && 
			 (IsPrint (GetCharAttr(), event->data.keyDown.chr)))
			{
			handled = ListViewNewToDo (event);
			}
		}
		

	else if (event->eType == penDownEvent)
		{
		handled = FrmHandleEvent (FrmGetActiveForm (), event);
		if (! handled)
			ListViewClearEditState ();
		}


	else if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case ListNewToDoButton:
				ListViewNewToDo (NULL);
				handled = true;
				break;

			case ListDetailsButton:
				if (ItemSelected)
					FrmPopupForm (DetailsDialog);
				else
					FrmAlert (SelectItemAlert);
				handled = true;
				break;

			case ListShowButton:
				FrmPopupForm (OptionsDialog);
				handled = true;
				break;

			case ListUpButton:
				ListViewScroll (up);
				handled = true;
				break;
				
			case ListDownButton:
				ListViewScroll (down);
				handled = true;
				break;
				
			case ListCategoryTrigger:
				ListViewSelectCategory ();
				handled = true;
				break;
			}
		}


	else if (event->eType == ctlEnterEvent)
		{
		switch (event->data.ctlEnter.controlID)
			{
			case ListShowButton:
			case ListUpButton:
			case ListDownButton:
			case ListCategoryTrigger:
				ListViewClearEditState ();
				break;
			}
		}

	else if (event->eType == ctlExitEvent)
		{
		switch (event->data.ctlEnter.controlID)
			{
			case ListNewToDoButton:
			case ListDetailsButton:
				ListViewRestoreEditState ();
				break;
			}
		}


	else if (event->eType == ctlRepeatEvent)
		{
		switch (event->data.ctlRepeat.controlID)
			{
			case ListUpButton:
				ListViewScroll (up);
				break;
				
			case ListDownButton:
				ListViewScroll (down);
				break;
			}
		}


	else if (event->eType == tblSelectEvent)
		{
		ListViewItemSelected (event);
		handled = true;
		}
		

	else if (event->eType == tblEnterEvent)
		{
		if (ItemSelected)
			{
			table = GetObjectPtr (ListTable);
			if (TblFindRowID (table, CurrentRecord, &row))
				{
				if (event->data.tblEnter.row != row)
					handled = ListViewClearEditState ();
				}
			}
		}
		

	else if (event->eType == tblExitEvent)
		{
		ListViewClearEditState ();
		handled = true;
		}

	else if (event->eType == fldHeightChangedEvent)
		{
		ListViewResizeDescription (event);
		handled = true;
		}


	else if (event->eType == menuEvent)
		{
		handled = ListViewDoCommand (event->data.menu.itemID);
		}
		

	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		ListViewInit (frm);
		if (PendingUpdate)
			{
			ListViewUpdateDisplay (PendingUpdate);
			PendingUpdate = 0;
			}
		FrmDrawForm (frm);
		ListViewRestoreEditState ();
		handled = true;
		}


	else if (event->eType == frmGotoEvent)
		{
		frm = FrmGetActiveForm ();
		ListViewGotoItem (event);
		ListViewInit (frm);
		FrmDrawForm (frm);
		ListViewRestoreEditState ();
		handled = true;
		}


	else if (event->eType == frmUpdateEvent)
		{
		handled = ListViewUpdateDisplay (event->data.frmUpdate.updateCode);
		if (handled)
			ListViewRestoreEditState ();
		}


	else if (event->eType == frmSaveEvent)
		{
		ListViewClearEditState ();
		}

	return (handled);
}



#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and sets the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent (EventPtr event)
{
	Word formID;
	FormPtr frm;

	if (event->eType == frmLoadEvent)
		{
		// Load the form resource.
		formID = event->data.frmLoad.formID;
		frm = FrmInitForm (formID);
		FrmSetActiveForm (frm);		
		
		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmDispatchEvent each time is receives an
		// event.
		switch (formID)
			{
			case ListView:
				FrmSetEventHandler (frm, ListViewHandleEvent);
				break;
		
			case NoteView:
				FrmSetEventHandler (frm, NoteViewHandleEvent);
				break;
		
			case DetailsDialog:
				FrmSetEventHandler (frm, DetailsHandleEvent);
				break;
				
			case OptionsDialog:
				FrmSetEventHandler (frm, OptionsHandleEvent);
				break;
			}
		return (true);
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    EventLoop
 *
 * DESCRIPTION: This routine is the event loop for the ToDo
 *              aplication.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
static void EventLoop (void)
{
	Word error;
	EventType event;

	do
		{
		EvtGetEvent (&event, evtWaitForever);

		if (! SysHandleEvent (&event))
		
			if (! MenuHandleEvent (CurrentMenu, &event, &error))
			
				if (! ApplicationHandleEvent (&event))
	
					FrmDispatchEvent (&event); 
		}

	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the ToDo
 *              application.
 *
 * PARAMETERS:  cmd			 - launch code
 *              cmdPBP      - paramenter block (launch code specific)
 *              launchFlags - SysAppLaunch flags (ses SystemMgr.h)
 *
 * RETURNED:    error code
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *
 ***********************************************************************/
DWord	PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
	Word error;
	
	
	/* are we version compliant? */	
	error = RomVersionCompatible (0x03000000, launchFlags);
	if (error) return (error);
	
	// Normal Launch
	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		error = StartApplication ();
		if (error) return (error);

		FrmGotoForm (ListView);
		EventLoop ();
		StopApplication ();
		}
	
	else if (cmd == sysAppLaunchCmdFind)
		{
		Search ((FindParamsPtr)cmdPBP);
		}
	
	
	// This action code is sent to the app when the user hit the "Go To"
	// button in the Find Results dialog.
	else if (cmd == sysAppLaunchCmdGoTo)
		{
		Boolean	launched;
		launched = launchFlags & sysAppLaunchFlagNewGlobals;
		
		if (launched) 
			{
			error = StartApplication ();
			if (error) return (error);

			GoToItem ((GoToParamsPtr) cmdPBP, launched);
			
			EventLoop ();
			StopApplication ();	
			}
		else
			GoToItem ((GoToParamsPtr) cmdPBP, launched);
		}
			

	else if (cmd == sysAppLaunchCmdSyncNotify)
		{
		SyncNotification ();
		}
	

	// This action code is sent after the system is reset. We use this time
	// to create our default database if this is a hard reset.
	// Note: This code is used by ROM based applications only. A RAM based 
	//  application will never receive this event.
	else if (cmd == sysAppLaunchCmdSystemReset) {
		if (((SysAppLaunchCmdSystemResetType*)cmdPBP)->createDefaultDB) {
			Handle	resH;
			resH = DmGet1Resource(sysResTDefaultDB, sysResIDDefaultDB);
			if (resH) {
				DmCreateDatabaseFromImage(MemHandleLock(resH));
				MemHandleUnlock(resH);
				DmReleaseResource(resH);
				}
			}
		}
	

   // Receive the record.  The app will parse the data and add it to the database.
   // This data should be displayed by the app.
	else if (cmd == sysAppLaunchCmdExgReceiveData) 
   	{
       DmOpenRef dbP;
       
       
      // if our app is not active, we need to open the database 
      // the subcall flag is used here since this call can be made without launching the app
      if (!(launchFlags & sysAppLaunchFlagSubCall))
      	{
      	dbP = DmOpenDatabaseByTypeCreator (toDoDBType, sysFileCToDo, dmModeReadWrite);
      	}
      else
      	{
      	dbP = ToDoDB;
      	
			// Save any data the we may be editing.
			FrmSaveAllForms ();
      	}
      
      if (dbP != NULL)
      	{
			error = ToDoReceiveData(dbP, (ExgSocketPtr) cmdPBP);
			
			if (!(launchFlags & sysAppLaunchFlagSubCall))
				error = DmCloseDatabase(dbP);
			}
		}
      
      
	// This action code is sent by the DesktopLink server when it creates
	// a new database.  We will initializes the new database.
	else if (cmd == sysAppLaunchCmdInitDatabase)
		{
		ToDoAppInfoInit (((SysAppLaunchCmdInitDatabaseType*)cmdPBP)->dbP);
		}


	return (0);
}


/***********************************************************************
 *
 * FUNCTION:    ToDoLoadPrefs
 *
 * DESCRIPTION: Read the preferences and handle previous and future
 *					 versions of the prefs.
 *
 * PARAMETERS:  Nothing.
 *
 * RETURNED:    Nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			BGT	1/8/98	Initial Revision
 *
 ***********************************************************************/
 void ToDoLoadPrefs(void)
 {
	ToDoPreferenceType prefs;
	Word prefsSize;
	Int prefsVersion;

	// Read the preferences / saved-state information.  There is only one
	// version of the Address Book preferences so don't worry about multiple
	// versions.
	prefsSize = sizeof (ToDoPreferenceType);
	prefsVersion = PrefGetAppPreferences (sysFileCToDo, todoPrefID, &prefs, &prefsSize, true);
	if (prefsVersion > toDoPrefsVersionNum) {
		prefsVersion = noPreferenceFound;
	}
	if (prefsVersion > noPreferenceFound)
		{
		if (prefsVersion < toDoPrefsVersionNum) {
			prefs.noteFont = prefs.v20NoteFont;
		}
		CurrentCategory = prefs.currentCategory;
		if (prefs.noteFont == largeFont)
			NoteFont = largeBoldFont;
		else
			NoteFont = prefs.noteFont;
		ShowAllCategories = prefs.showAllCategories;
		ShowCompletedItems = prefs.showCompletedItems;
		ShowOnlyDueItems = prefs.showOnlyDueItems;
		ShowDueDates = prefs.showDueDates;
		ShowPriorities = prefs.showPriorities;
		ShowCategories = prefs.showCategories;
		ChangeDueDate = prefs.changeDueDate;
		SaveBackup = prefs.saveBackup;
		
		
		// Support transferal of preferences from the second version of the preferences.
		if (prefsVersion == toDoPrefsVersionNum)
			{
			ListFont = prefs.listFont;
			}
		}
}

/***********************************************************************
 *
 * FUNCTION:    ToDoSavePrefs
 *
 * DESCRIPTION: Save the preferences and handle previous and future
 *					 versions of the prefs.
 *
 * PARAMETERS:  Nothing.
 *
 * RETURNED:    Nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			BGT	1/8/98	Initial Revision
 *
 ***********************************************************************/
void ToDoSavePrefs(void)
{
	ToDoPreferenceType prefs;
	
	// Write the preferences / saved-state information.
	prefs.currentCategory = CurrentCategory;
	prefs.noteFont = NoteFont;
	if (prefs.noteFont > largeFont) {
		prefs.v20NoteFont = stdFont;
	}
	else {
		prefs.v20NoteFont = prefs.noteFont;
	}
	prefs.showAllCategories = ShowAllCategories;
	prefs.showCompletedItems = ShowCompletedItems;
	prefs.showOnlyDueItems = ShowOnlyDueItems;
	prefs.showDueDates = ShowDueDates;
	prefs.showPriorities = ShowPriorities;
	prefs.showCategories = ShowCategories;
	prefs.changeDueDate = ChangeDueDate;
	prefs.saveBackup = SaveBackup;
	prefs.listFont = ListFont;
		
	PrefSetAppPreferences (sysFileCToDo, todoPrefID, toDoPrefsVersionNum, &prefs, 
		sizeof (ToDoPreferenceType), true);
}



/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version meets your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *                             
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/15/96	Initial Revision
 *
 ***********************************************************************/
static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;

	// See if we have at least the minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return (0);
}
