/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 * PROJECT:  Pilot
 * FILE:     FormatsPanel.h
 * AUTHOR:	 Roger Flores: June 3, 1996
 *
 * DECLARER: Formats
 *
 * DESCRIPTION:
 *
 **********************************************************************/
 
/***********************************************************************
 *	Internal Constants
 ***********************************************************************/

#define defaultTimeButton	timeHourButton

#define countriesSelectable	4
#define defaultCountryItem		2				//	default to U.S.

#define timeFormatsSelectable 5
#define defaultTimeFormatItem	0				//	default to tfColonAMPM

#define dateFormatsSelectable	7
#define defaultDateFormatItem	0				//	default to M/D/Y

#define autoOffSettings			3
#define defaultAutoOffSetting	1				//	default to 2 minutes

#define numSoundLevels			2				//	Use defaults from preferences.h


/***********************************************************************
 *	Type Definitions
 ***********************************************************************/

typedef struct {
	DateFormatType			dateFormat;			// Format to display date in
	DateFormatType			longDateFormat;	// Format to display date in
	Byte						weekStartDay;		// Sunday or Monday
	TimeFormatType			timeFormat;			// Format to display time in
	NumberFormatType		numberFormat;		// Format to display numbers in
	} CountrySettingsType;	


/***********************************************************************
 *	Global variables
 ***********************************************************************/
extern Word CurrentRecord;
extern SystemPreferencesType SystemPreferences;


// The Time Set Dialog has storage for the time button labels here.
// The value of each button is also stored here.
extern Word	CurrentTimeButton;
extern Byte	HoursTimeButtonValue;
extern char	HoursTimeButtonString[3];
extern Byte	MinuteTensButtonValue;
extern char	MinuteTensButtonString[2];
extern Byte	MinuteOnesButtonValue;
extern char	MinuteOnesButtonString[2];


// Mappings between system preferences and the ui values
extern TimeFormatType TimeFormatMappings[timeFormatsSelectable];

//	Map ui list positions to short date formats
extern DateFormatType DateFormatMappings[dateFormatsSelectable];

//	Map ui list positions to long date formats
extern DateFormatType LongDateFormatMappings[dateFormatsSelectable];
extern CountrySettingsType CountrySettings[countriesSelectable];



/***********************************************************************
 *	Global functions
 ***********************************************************************/
// Functions used by multiple Preference files.
extern UInt MapToPositionWord (UInt *mappingArray, UInt value,
										 UInt mappings, UInt defaultItem);
extern Boolean GotoForm (Word formId);
extern VoidPtr GetObjectPtr (Word objectID);



//	Formats Form
#define formatsForm					1200

#define formatPanelPickTrigger	1218
#define formatPanelPickList		1219
#define formatPanelNameLabel		1234

#define countryTrigger				1226
#define countryList					1227

#define timeFormatTrigger			1222
#define timeFormatList				1223

#define dateFormatTrigger			1215
#define dateFormatList				1216

#define weekStartTrigger			1204
#define weekStartList				1206

#define numberFormatTrigger		1230
#define numberFormatList			1231

#define formatsDoneButton			1233

#define RomIncompatibleAlert		1001