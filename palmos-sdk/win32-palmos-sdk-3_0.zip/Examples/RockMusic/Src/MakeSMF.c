/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:			RockMusic
 *
 * FILE:			makeSMF.c
 *
 * DESCRIPTION:	utility routines to create an SMF on the fly
 *
 * REVISION HISTORY:  2/12/98 David Fedor - created.
 * 	 
 **********************************************************************/

#include <Pilot.h>				// all the system toolbox headers
#include "makeSMF.h"

// A standard header for MIDI format 0 sounds, with one track.
const Byte MidiHeader[] = {
0x4D, 0x54, 0x68, 0x64,              // MThd
0x00, 0x00, 0x00, 0x06,              // header data is 6 bytes long
0x00, 0x00, 0x00, 0x01, 0x01, 0x90,  // format 0, 1 track, 0190 tempo (microseconds per quarter note)

0x4D, 0x54, 0x72, 0x6B,              // MTrk
0x00, 0x00, 0x00, 0x02,              // length in bytes of following data
0x00, 0x90							 // start playing a sound...
// then things like:
//             0x5C, 0x40,    // note 5c at velocity 40
// 0x81, 0x60, 0x5C, 0x00,    // after 160 ticks, turn off 5c
// (repeat above two lines ad nauseum)
// 0xFF, 0x2F, 0x00     // shut everything down
};
const MidiHeaderLength = 24;

Handle StartSMF()
{
	Byte *buf;
	Handle bufH;

	bufH = MemHandleNew(MidiHeaderLength);
	
	if (bufH) {
		buf = MemHandleLock(bufH);
		MemMove(buf, (void *) MidiHeader, MidiHeaderLength);
		MemHandleUnlock(bufH);
	}
	
	return bufH;
}

Handle AppendNote(Handle bufH, int note, int dur, int vel, int pause)
{
	Byte *buf;
	ULong bufsize, neededSize;
	int pos; // , startpos;
	
	if (!bufH) return 0;		// make error-handling easy for our caller
	
	// how big is our buffer?
	bufsize = MemHandleSize(bufH);
	buf = MemHandleLock(bufH);
	pos = (*((ULong *)(&buf[18]))) + MidiHeaderLength -2;	// position of next spot to put data
	MemHandleUnlock(bufH);
	
	// allocate more memory if necessary
	neededSize = 9 + pos; // 9 is maximum number of bytes we'd use in here
	if (bufsize < neededSize)
		if (MemHandleResize(bufH, neededSize))
			return 0;
	
	buf = MemHandleLock(bufH);
	
	// start the note
	buf[pos++] = note;	// frequency
	if (vel >= 128)		// velocity i.e. volume
		buf[pos++] = 0x80 + ((vel & 0x0780) >> 7);
	buf[pos++] = (vel & 0x07f);

	// wait for the specified duration
	if (dur >= 128)
		buf[pos++] = 0x80 + ((dur & 0x7f80) >> 7);
	buf[pos++] = (dur & 0x07f);

	// stop playing it
	buf[pos++] = note;
	buf[pos++] = 0;

	// pause afterwards
	if (pause >= 128)
		buf[pos++] = 0x80 + ((pause & 0x7f80) >> 7);
	buf[pos++] = (pause & 0x07f);
	
	// update header to show how much data is there
	*((ULong *)(&buf[18])) = pos - (MidiHeaderLength -2);

	MemHandleUnlock(bufH);
	return bufH;
}

Handle FinishSMF(Handle bufH)
{
	Byte *buf;
	ULong bufsize, neededSize;
	int pos;

	if (!bufH) return 0;		// make error-handling easy for our caller

	// how big is our buffer?
	bufsize = MemHandleSize(bufH);
	buf = MemHandleLock(bufH);
	pos = (*((ULong *)(&buf[18]))) + MidiHeaderLength -2;	// position of next spot to put data
	MemHandleUnlock(bufH);
	
	// allocate more memory if necessary
	neededSize = 3 + pos; // 3 more bytes to terminate things
	if (bufsize < neededSize)
		if (MemHandleResize(bufH, neededSize))
			return 0;
	
	buf = MemHandleLock(bufH);

	// now stop everything
	buf[pos++] = 0xff;
	buf[pos++] = 0x2f;
	buf[pos++] = 0x00;

	// update header to show how much data is there
	*((ULong *)(&buf[18])) = pos - (MidiHeaderLength -2);

	MemHandleUnlock(bufH);
	return bufH;
}
