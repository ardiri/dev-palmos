/*******************************************************************
/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 * FileName:
 *		SampleLibPrv.h
 *
 * Description:
 *		Sample library private definitions.
 *
 * History:
 *   	5/20/97	vmk
 *
 *******************************************************************/


#ifndef __SAMPLE_LIB_PRV_H__
#define __SAMPLE_LIB_PRV_H__

// PalmPilot common definitions
#include <Common.h>
#include <SampleLib.h>





/********************************************************************
 * Private Structures
 ********************************************************************/
 
// Library globals
typedef struct SampleLibGlobalsType {
	UInt						thisLibRefNum;			// our library reference number (for convenience and debugging)
	Int						openCount;				// library open count
	
	// Add other library global fields here
	Int						contextCount;			// number of context in existence (for debugging)
	
	} SampleLibGlobalsType;

typedef SampleLibGlobalsType*		SampleLibGlobalsPtr;


// Client context structure for storing each client-specific data
typedef struct SampleLibClientContextType {
	Word						wSignature;				// signature for validating the context
	
	Int						cornerDiam;				// rectangle corner diameter
	} SampleLibClientContextType;

typedef SampleLibClientContextType*		SampleLibClientContextPtr;


// The wSignature field of each SampleLibClientContextType will be set to
// this value for debugging
#define sampleLibContextSignature		(0xFEED)


/********************************************************************
 * Private Macros
 ********************************************************************/

#define sampleDefaultCornerDiameter		(0)


#endif	// __SAMPLE_LIB_PRV_H__
