/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 * FileName:
 *		SampleLib.h
 *
 * Description:
 *		Sample library API definitions.  The Sample library serves as an example
 *		of creating PalmPilot shared libraries.
 *
 * History:
 *   	 5/20/97	vmk
 *   	12/18/97	scl Added BUILDING_SAMPLE_LIB to fix building in CW Pro 2
 *
 *******************************************************************/


#ifndef __SAMPLE_LIB_H__
#define __SAMPLE_LIB_H__


// If we're actually compiling the library code, then we need to
// eliminate the trap glue that would otherwise be generated from
// this header file in order to prevent compiler errors in CW Pro 2.
#ifdef BUILDING_SAMPLE_LIB
	#define SAMPLE_LIB_TRAP(trapNum)
#else
	#define SAMPLE_LIB_TRAP(trapNum) SYS_TRAP(trapNum)
#endif


// PalmPilot common definitions
#include <Common.h>
#include <SystemMgr.rh>


/********************************************************************
 * Type and creator of Sample Library database
 ********************************************************************/
#define		sampleLibCreatorID	'SL??'				// Sample Library database creator
#define		sampleLibTypeID		'libr'				// Standard library database type


/********************************************************************
 * Internal library name which can be passed to SysLibFind()
 ********************************************************************/
#define		sampleLibName			"Sample.lib"		


/************************************************************
 * Sample Library result codes
 * (appErrorClass is reserved for 3rd party apps/libraries.
 * It is defined in SystemMgr.h)
 *************************************************************/

#define sampleErrParam			(appErrorClass | 1)		// invalid parameter
#define sampleErrNotOpen		(appErrorClass | 2)		// library is not open
#define sampleErrStillOpen		(appErrorClass | 3)		// returned from SampleLibClose() if
																		// the library is still open by others
#define sampleErrMemory			(appErrorClass | 4)		// memory error occurred


//-----------------------------------------------------------------------------
// Sample library function trap ID's. Each library call gets a trap number:
//   sampleLibTrapXXXX which serves as an index into the library's dispatch table.
//   The constant sysLibTrapCustom is the first available trap number after
//   the system predefined library traps Open,Close,Sleep & Wake.
//
// WARNING!!! The order of these traps MUST match the order of the dispatch
//  table in SampleLibDispatch.c!!!
//-----------------------------------------------------------------------------

typedef enum {
	sampleLibTrapGetLibAPIVersion = sysLibTrapCustom,
	sampleLibTrapSetCornerDiameter,
	sampleLibTrapGetCornerDiameter,
	sampleLibTrapDrawRectangle,
	
	sampleLibTrapLast
	} SampleLibTrapNumberEnum;



/********************************************************************
 * Public Structures
 ********************************************************************/
 



/********************************************************************
 * API Prototypes
 ********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif


//--------------------------------------------------
// Standard library open, close, sleep and wake functions
//--------------------------------------------------

extern Err SampleLibOpen(UInt refNum, DWordPtr clientContextP)
				SAMPLE_LIB_TRAP(sysLibTrapOpen);
				
extern Err SampleLibClose(UInt refNum, DWord clientContext)
				SAMPLE_LIB_TRAP(sysLibTrapClose);

extern Err SampleLibSleep(UInt refNum)
				SAMPLE_LIB_TRAP(sysLibTrapSleep);

extern Err SampleLibWake(UInt refNum)
				SAMPLE_LIB_TRAP(sysLibTrapWake);


//--------------------------------------------------
// Custom library API functions
//--------------------------------------------------
	
// Get our library API version
extern Err SampleLibGetLibAPIVersion(UInt refNum, DWordPtr dwVerP)
				SAMPLE_LIB_TRAP(sampleLibTrapGetLibAPIVersion);
	
// Set the corner diameter
extern Err SampleLibSetCornerDiameter(UInt refNum, DWord clientContext, Int cornerDiam)
				SAMPLE_LIB_TRAP(sampleLibTrapSetCornerDiameter);
				
// Get the corner diameter
extern Err SampleLibGetCornerDiameter(UInt refNum, DWord clientContext, IntPtr cornerDiamP)
				SAMPLE_LIB_TRAP(sampleLibTrapGetCornerDiameter);
				
// Draw a rectangle to the current draw window
extern Err SampleLibDrawRectangle(UInt refNum, DWord clientContext, Int	x, Int y, Int width, Int height)
				SAMPLE_LIB_TRAP(sampleLibTrapDrawRectangle);



// For loading the library in PalmPilot Mac emulation mode
extern Err SampleLibInstall(UInt refNum, SysLibTblEntryPtr entryP);


#ifdef __cplusplus 
}
#endif


/********************************************************************
 * Public Macros
 ********************************************************************/




#endif	// __SAMPLE_LIB_H__
