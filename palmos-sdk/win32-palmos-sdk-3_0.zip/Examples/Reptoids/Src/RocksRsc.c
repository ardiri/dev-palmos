/***********************************************************************
 *
 *	Copyright 1996 Roger Flores -- All Rights Reserved
 *
 * PROJECT:  Pilot
 * FILE:     RocksRsc.c
 * AUTHOR:	 Roger Flores: May 2, 1996
 *
 * DECLARER: Rocks
 *
 * DESCRIPTION:
 *	  The list of resources are stored here.
 *
 **********************************************************************/

#include <Pilot.h>

char *AppResourceList[] = {
	":Rsc:RocksMain.rsrc", 
	":Rsc:RocksHighScores.rsrc", 
	":Rsc:RocksInfo.rsrc", 
	":Rsc:RocksMisc.rsrc", 
	":Rsc:RocksNewHighScore.rsrc", 
	""
	};
	
