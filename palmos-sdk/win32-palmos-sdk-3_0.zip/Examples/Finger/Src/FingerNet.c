/***************************************************************************
* Network.c
*
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
*
* HISTORY
*		01/04/97		Gregory Toto, created. 
*
********************************************************************************/

#include <Pilot.h>
#include <sys_socket.h>



// Application headers

#include "FingerDemo.h"



// From NetSocket.c
//
// Global that is also declard by standard C library, if linked in.
// Rather than declare it here, possibly redundantly, we'll rely on the
//  app to declare it somewhere in it's source code if it doesn't already
//  link in the standard C library.

#ifdef __PALMOS_TRAPS__
Err errno;
#endif




//=======================================================================
//	globals

Boolean	gNetLibOpen;




//=======================================================================
// InitNetworkGlobals
//
// 
//=======================================================================

void InitNetworkGlobals( void )
{
	AppNetRefnum	= 0;
	gNetLibOpen		= false;
	
}	// InitNetworkGlobals




//=======================================================================
// ValidNetAddress
//
// parse the network address contained in the field with addrFieldID in
// the from on formP. return the address as a two strings: the part before
// the '@' on whoStrHP and the part after the '@' on whereStrHP. 
//=======================================================================

Boolean ValidNetAddress( FormPtr formP, Word addrFieldID, Handle * whoStrHP,
																			 Handle * whereStrHP )
{

	Boolean	addrIsValid = false;
	FieldPtr	addrFieldP;	
	CharPtr	addrStr;


	// initialize the return values.
	
	*whoStrHP   = NULL;
	*whereStrHP = NULL;



	// get a reference to the address field.
		
	addrFieldP = (FieldPtr) FrmGetObjectPtr( formP, FrmGetObjectIndex( formP, addrFieldID ) );
	
	if ( addrFieldP != NULL )
	{
		CharPtr atPtr;

		// get a reference to the field text.
				
		addrStr = FldGetTextPtr( addrFieldP );

		
		// find the '@' in the address.
		
		atPtr   = StrChr( addrStr, '@' );
		
		if  ( atPtr != NULL )
		{
			CharPtr	tmpStr;
			
			// determine the lengths of the components of the address, before and 
			// after the '@'.
			
			Word		whoStrLen	= atPtr - addrStr;
			Word		whereStrLen = StrLen( atPtr + 1 );


			// get some space to contain the address strings.
						
			*whoStrHP	= MemHandleNew( whoStrLen   + 3 );	// extra for \r, \n and null
			*whereStrHP = MemHandleNew( whereStrLen + 1 );	// extra for null


			// copy the address strings, terminating the whoStr with \r\n.
			
			tmpStr = MemHandleLock( *whoStrHP );			
			StrNCopy( tmpStr, addrStr, whoStrLen );
			tmpStr[ whoStrLen     ] = '\r';
			tmpStr[ whoStrLen + 1 ] = '\n';
			tmpStr[ whoStrLen + 2 ] = 0;
			MemHandleUnlock( *whoStrHP );

			tmpStr = MemHandleLock( *whereStrHP );			
			StrCopy( tmpStr, ( atPtr + 1 ) );
			MemHandleUnlock( *whereStrHP );

			
			// indicate a valid address. we could do more checking - for example
			// check for a numeric, correctly formed whereStr for instance...
			
			addrIsValid = true;
		
		}
		else
			ShowErrorDialog( BadAddressString, NULL );
	}
	else
		AlertPrintf( "ValidNetAddress", "FrmGetObjectPtr returned NULL" );
	
	return addrIsValid;

}	// ValidNetAddress




//=======================================================================
// FindNetworkLibrary
//
// find the network library. return true on success, false else.
//
// AppNetRefnum is initialized if it has not already been initialized
// the by the app.
//=======================================================================

Boolean FindNetworkLibrary( void )
{
	Boolean	retVal	= true;
	Err		sysError	= 0;
	DWord		version;
	

	// if we haven't already gotten the net library, check if it
	// is available, and get a reference to it if so.
	
	if ( AppNetRefnum == 0 )
	{
	
		// use the Feature Manager to detemine if the net library is
		// installed.
		
		sysError = FtrGet( netFtrCreator, netFtrNumVersion, &version );
		
		if ( sysError == 0 )
		{
			// get a reference to the Net.lib into AppNetRefnum.

			sysError = SysLibFind( "Net.lib", &AppNetRefnum );

			if ( sysError )
			{
				AppNetRefnum = 0;
				retVal		 = false;
			}
		}
		else
		{
			retVal = false;
		}
	}

	return retVal;

}	// FindNetworkLibrary




//=======================================================================
// OpenNetwork
//
// open a network connection. return true on success, false else.
//
// gNetLibOpen is set true on success.
//
// AppNetRefnum is initialized if it has not already been initialized
// by the app.
//=======================================================================

Boolean OpenNetwork( void )
{

	// if we've already opened the connection, don't do it again...
	 
	if ( !gNetLibOpen )
	{
		Word	ifErrs	= 0;
		Err	sysError	= 0;
		
		
		if ( !FindNetworkLibrary() )
		{
			// couldn't find the network library. assume it's not present on
			// the device.
			
			ShowErrorDialog( NetNotAvailErrorString, NULL );
			AppNetRefnum = 0;
		}
		else
		{
			char errStr[ 10 ];

			// ok, got Net.lib. now open it...
			
			sysError = NetLibOpen( AppNetRefnum, &ifErrs );
			
			if ( ifErrs != 0 )
			{
				NetLibClose( AppNetRefnum, true );
				AppNetRefnum = 0;
				StrPrintF( errStr, "%d", ifErrs );
				ShowErrorDialog( ObscureErrorString, errStr );
			}
			else
			{
				switch ( sysError )
				{
					case 0:
					case netErrAlreadyOpen:
						gNetLibOpen = true;
						break;
						
					case netErrOutOfMemory:
						ShowErrorDialog2( OutOfMemErrorString, OpenConnString );
						break;
					
					case netErrNoInterfaces:
					case netErrPrefNotFound:
						ShowErrorDialog( BadSetupErrorString, NULL );
						break;
						
					default:
						sprintf( errStr, "%d", sysError );
						ShowErrorDialog( ObscureErrorString, errStr );
						break;
				}	// switch
			}	// if ( ifErrs != 0 )		
		}	// if ( !FindNetworkLibrary() )
	}	// if ( !gNetLibOpen )
	
	return gNetLibOpen;
			
}	// OpenNetwork



//=======================================================================
// CloseNetwork
//
// close the network connection. return true if the network is closed,
// false else.
//=======================================================================

Boolean CloseNetwork( Boolean forceToClose )
{
	Boolean closeResult = true;


	// test on gNetLibOpen and also on AppNetRefnum because we may not
	// have opened the connection in this app, or in this instantiation
	// of this app (e.g. we may have opened a connection, gone to another
	// app, and returned).
	
	if ( gNetLibOpen || ( AppNetRefnum != 0 ) )
	{

		closeResult = ( NetLibClose( AppNetRefnum, forceToClose ) != netErrStillOpen );
			
		// the NetLib may really still be open - NetLibClose may have
		// returned netErrStillOpen (because we didn't force a close - 
		// forceToClose may have been false).
		
		gNetLibOpen		= false; 		
		AppNetRefnum	= 0;
	}
	
	return closeResult;
	
}	// CloseNetwork





//=======================================================================
// RefreshNetwork
//
// check the status of the connection and reestablish it (if it is down), 
// if recconnectIfDown is true. returns true if connected when this
// routine returns, false else.
//
// AppNetRefnum is initialized if it has not already been initialized
// the by the app.
//
// don't call this unless OpenNetwork() has been called.
//=======================================================================

Boolean RefreshNetwork( Boolean reconnectIfDown )
{

	Word		ifErrs	= 0;
	Boolean	allUp		= false;
	Boolean	isConn	= false;
	Err		sysError	= 0;
	

	// check the status of the connection, and bring it up if 
	// reconnectIfDown is true. allUp will contain the
	// connection status.

	sysError	= NetLibConnectionRefresh( AppNetRefnum, reconnectIfDown,
													&allUp, &ifErrs );
	
													
	if ( sysError != 0 )
	{
		ShowErrorDialog( NetRefreshErrorString, "." );		
	}
	else if ( ifErrs != 0 )
	{
		char errStr[ 10 ];
		
		StrPrintF( errStr, ": %d", ifErrs );
		ShowErrorDialog( NetRefreshErrorString, errStr );
	}
	else
		isConn = allUp;

	
	return isConn;
			
}	// RefreshNetwork




//=======================================================================
// TestNetwork
//
// a bit of a hack to check whether we have a connection or not - we
// assume that if the net lib is open, that we have a connection. this
// might not really be true: the library might be closed but the connection
// is still open, or the library might be open but the line has dropped...
//
// we can't use RefreshNetwork() to do this, because we must open the
// connection to use RefreshNetwork() (which will bring up the user
// interface for the connection if the connection is not already up).
//
// this routine can also be used to test whether the device supports
// the net library. it puts up a dialog if there is no network support.
//
// AppNetRefnum is initialized if it has not already been initialized
// the by the app.
//
// can be called before OpenNetwork() has been called.
//=======================================================================

Boolean TestNetwork( void )
{

	Word		openCount	= 0;
	Boolean	isConn		= false;
	

	if ( !FindNetworkLibrary() )
	{
		// couldn't find the network library. assume it's not present on
		// the device.
			
		ShowErrorDialog( NetNotAvailErrorString, NULL );
		AppNetRefnum = 0;
	}
	else
	{

		// is the net lib open?
		
		NetLibOpenCount( AppNetRefnum, &openCount );
		
		if ( openCount > 0 ) isConn = true;

	}

	return isConn;
			
}	// TestNetwork



//=======================================================================
// FingerIt
//
// finger the user on whoStrH at server whereStrH and send the result to
// the field on resFldP. the routine grabs data from the server in
// CHUNK_SIZE blocks until all the data is retrieved or an error occurs.
// space for the returned data is allocated outside the dynamic heap.
//=======================================================================

#define CHUNK_SIZE 512

void FingerIt( Handle whoStrH, Handle whereStrH, FieldPtr resFldP )
{

	// get references to the component strings of the address.
	
	CharPtr 			whoP		 = MemHandleLock( whoStrH );
	CharPtr 			whereP	 = MemHandleLock( whereStrH );
	Word				whoLen	 = StrLen( whoP );

	UInt				dbRecIndx = 0;

	VoidHand			rdBufH	 = NULL;		// buffer for NetUWriteN()
	CharPtr			rdBufP	 = NULL;

	VoidHand			bufH		 = NULL; 	// buffer for finger data
	CharPtr			bufP		 = NULL;
	ULong				bufLen	 = 0;
	ULong				bufOffset = 0;

	VoidHand			tmpH		 = NULL;		// tmp buf handle

	NetSocketRef	fd			 = -1;		// socked file descriptor
	int     			port		 = 0;


	// make sure the connection is open!
	
	RefreshNetwork( true );


	// free the text buffer currently in the result field. if there
	// is a handle associated with the field, it belongs to a 
	// DB record  - so free the record. we know the handle belongs to
	// a DB because we freed the default handle associated with the
	// form when our main form opened.
	
	if ( FldGetTextHandle( resFldP ) != NULL )
	{
		FldSetTextHandle( resFldP, NULL );
		DmRemoveRecord( gFingerDB, 0 );
	}
	

	// try to open a finger connection to the server...
	
	if ( ( fd = NetUTCPOpen( whereP, "finger", port ) ) < 0 )
	{
		ShowErrorDialog( CouldNotOpenConnErrorString, NULL );
		goto _FingerExit;
	}
	
	
	// allocate a small buffer for receiving data from the server.
	
	rdBufH = MemHandleNew( CHUNK_SIZE );
	if ( rdBufH == NULL)
	{
		ShowErrorDialog2( OutOfMemErrorString, AllocRxBufString );
		goto _FingerExit;
	}
	rdBufP = MemHandleLock( rdBufH );

	
	// allocate some space outside the dynamic heap but in a DB!. there
	// is a 64K limitation of chunks in the dynamic heap, but not in 
	// a DB. bufH will be associated with form, so we have to make sure
	// the form manager does not free it when the form is closed. instead,
	// we will free it by deleting the DB when the app exits.
	
	bufH = DmNewRecord( gFingerDB, &dbRecIndx, CHUNK_SIZE + 1 );
	if ( bufH == NULL)
	{
		ShowErrorDialog2( OutOfMemErrorString, AllocDBMemString );
		goto _FingerExit;
	}
	bufP		 = MemHandleLock( bufH );
	bufLen	 = CHUNK_SIZE + 1;
	bufOffset = 0;




	
	// null terminate the buffer by writing 0 at the end.
	
	DmSet( bufP, bufOffset, 1, 0 );


	// set the results field to display from the buffer. the
	// the previous display buffer has already been freed.

	FldSetTextHandle( resFldP, bufH );


	// ok cool, the connection is open and we have buffer space for the
	// result - now send the 'fingeree' to the server.
					
	if ( NetUWriteN( fd, (BytePtr) whoP, (DWord) whoLen ) != whoLen )
	{
		ShowErrorDialog( WhoWriteErrorString, NULL );
		goto _FingerExit;
	}


	while ( true ) 
	{
		int	 i;
		SDWord rdLen = NetUReadN( fd, (BytePtr) rdBufP, (DWord) CHUNK_SIZE );

		// exit if no data or error.
		
		if ( rdLen == 0 ) break;
		if ( rdLen  < 0 )
		{
			ShowErrorDialog( NetReadErrorString, NULL );
			break;
		}

		for ( i = 0; i < rdLen; i++ )
		{
			// substitute ' ' for CR because it displays
			// better in the field.
			
			if ( rdBufP[ i ] == '\r' ) rdBufP[ i ] = ' ';
		}	// for
	 		

		// if we need more buffer space to contain the received data
		// then try to allocate it...
		
	 	if ( ( bufOffset + rdLen ) >= bufLen )
	 	{
	 		VoidHand		newBufH;
	 			
	 		MemHandleUnlock( bufH );
	 		bufP = 0;

	 		
	 		// force the result field to release it too
	 		 		  
	 		FldSetTextHandle( resFldP, NULL );


			// attempt to resize the buffer.
				 		
	 		newBufH = DmResizeRecord( gFingerDB, 0, bufLen + CHUNK_SIZE );
	 		if ( newBufH == NULL )
	 		{
	 			// the resize failed...let the field keep what we
	 			// have already received.
	 				
	 			FldSetTextHandle( resFldP, bufH ); 	
		 		bufP = MemHandleLock( bufH );
	 			break;
	 		}
	 		else
	 			bufH = newBufH;
	 			
	 		bufP    = MemHandleLock( bufH );
	 		bufLen += CHUNK_SIZE;
	 	}	

	 	
		// save the received data to our display buffer, adding a 
		// null termination at the end.
			 	 
	 	DmWrite( bufP, bufOffset, rdBufP, rdLen );
	 	bufOffset += rdLen;
	 	DmSet( bufP, bufOffset, 1, 0 );


		// a bit of funkyness to update the text in the result field.
		// result field is NOT editable by the user. make it editable
		// to update the text, then put it back to not editable.
		
		resFldP->attr.editable = true;
		FldSetTextHandle( resFldP, bufH );
	 	FldDrawField( resFldP );
	 	resFldP->attr.editable = false;

		FingerResultUpdate( false, bufOffset );

	 }	// while ( true )
	 


	// cleanup the mess...

_FingerExit:

	MemHandleUnlock( whoStrH );
	MemHandleUnlock( whereStrH );
	
	if ( rdBufH != NULL )
	{
		MemHandleUnlock( rdBufH );
		if ( rdBufP != NULL ) MemHandleFree( rdBufH );
	}			
	if ( bufH != NULL )
	{
		// don't free the handle here. bufH must be freed with a Data Manager
		// operation since it is a chunk in a DB. also, it is now 
		// associated with the result field text. we must make sure that
		// the Form Manager does not free it when the form closes.
		
		MemHandleUnlock( bufH );
	}			
	if ( fd >= 0 ) close( fd );


	// free any unused space in the field...
	
	FldCompactText( resFldP );


	// clean up the status.
	
	FingerResultUpdate( true, bufOffset );


}	// FingerIt

