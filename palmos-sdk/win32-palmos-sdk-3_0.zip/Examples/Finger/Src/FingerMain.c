/*=======================================================================
* FingerMain.c
*
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
*
* try fingering:
*
*	quake@gldfs.cr.usgs.gov
*	nasanews@space.mit.edu
*	copi@oddjob.uchicago.edu
*
* they can return ALOT of stuff...
*
* HISTORY
*		04/24/97		Gregory Toto, created. 
*
********************************************************************************/

#include <Pilot.h>


// Application headers
#include <FeatureMgr.h>			//	Needed to detect ROM versions


#include "FingerDemo.h"




//=======================================================================
//	globals

Word			gCurrentFrmID;
DmOpenRef	gFingerDB;	




//=======================================================================
// CreateFingerDatabase
//
// remove the finger database. the routine closes the database before
// removing it (if it is open).
//
// gFingerDB is initialized with the DmOpenRef of the database.
//=======================================================================

Boolean CreateFingerDatabase( void )
{
	gFingerDB = 0;
		

	// remove any existing database (should not exist, but just in case)
	
	ClobberFingerDatabase( false );	
	


	// create a database for the app to use.
		
	if ( DmCreateDatabase( 0, FingerDBNameStr, FingerCreator, FingerDBType, false ) == 0 )
	{
		gFingerDB = DmOpenDatabaseByTypeCreator( FingerDBType, FingerCreator,
															  ( dmModeReadWrite | dmModeExclusive ) );
	}
	


	// error alert if the DB was not created.
		
	if ( gFingerDB == 0 )
	{
		ShowErrorDialog( DBNotCreatedString, NULL );
		return false;				
	}
	else
		return true;

}	// CreateFingerDatabase




//=======================================================================
// ClobberFingerDatabase
//
// remove the finger database. the routine closes the database before
// removing it (if it is open).
//
// gFingerDB is assumed to contain the DmOpenRef of the database.
//=======================================================================

void ClobberFingerDatabase( Boolean showErrDialog )
{
	Err					err = 0;
	DmSearchStateType	searchState;
	UInt					cardNo;
	LocalID				dbLocalID;


	// if the database is still open, then close it.
	
	if ( gFingerDB != 0 ) 
	{
		DmCloseDatabase( gFingerDB );
		gFingerDB = 0;
	};


	// get the card and local ID of the database, and delete the database
	// so we start clean next time...
			
	if ( DmGetNextDatabaseByTypeCreator( true, &searchState,
													 FingerDBType, FingerCreator,
													 false, &cardNo, &dbLocalID ) != dmErrCantFind )
	{
		err = DmDeleteDatabase( cardNo, dbLocalID );
	
	}

	if ( ( err != 0 ) && showErrDialog ) ShowErrorDialog( DBNotFoundOrDelString, NULL );

}	// ClobberFingerDatabase








//=======================================================================
// GetObjectPtr
//
// return a pointer to an object with objectID in the form on formP. use
// the active form if formP is NULL.
//=======================================================================

static VoidPtr GetObjectPtr( FormPtr formP, Word objectID)
{
	FormPtr frmP;

	if ( formP != NULL )
		frmP = formP;
	else
		frmP = FrmGetActiveForm();
		
	return FrmGetObjectPtr( frmP, FrmGetObjectIndex( frmP, objectID ) );

}	// GetObjectPtr



//=======================================================================
// ShowControl
//
// given a formPtr and controlID, show or hide the control based on the
// value of showTheControl. the active form is used if formP is NULL.
// 
//=======================================================================

void ShowControl( FormPtr formP, Word controlID, Boolean showTheControl )
{
	VoidPtr	objP;
	

	// get the index of the control
	
	objP = GetObjectPtr( formP, controlID );


	// show it or hide it.
	
	if ( showTheControl )
		CtlShowControl( (ControlPtr) objP );
	else
		CtlHideControl( (ControlPtr) objP );
			
}	// ShowControl

	

//=======================================================================
// SetFieldTextFromStr
//
// given a formPtr and fieldID, set the text of the field from the string
// on strP (a copy is made). the active form is used if formP is NULL. works
// even if the field is not editable.
//
// return a pointer to the field.
// 
//=======================================================================

FieldPtr SetFieldTextFromStr( FormPtr formP, Word fieldID, CharPtr strP )
{
	Handle		oldTxtH;
	Handle		txtH;
	CharPtr		txtP;

	FieldPtr		fldP;
	Boolean		fieldWasEditable;
	

	// get some space in which to stash the string.
		
	txtH	= MemHandleNew(  StrLen( strP ) + 1 );
	txtP	= MemHandleLock( txtH );


	// copy the string.
		
	StrCopy( txtP, strP );


	// unlock the string handle.
		
	MemHandleUnlock( txtH );
	txtP = 0;


	// get the field and the field's current text handle.
	
	fldP		= GetObjectPtr( formP, fieldID );	
	oldTxtH	= FldGetTextHandle( fldP );
	
	
	// set the field's text to the new text.
	
	fieldWasEditable		= fldP->attr.editable;
	fldP->attr.editable	= true;
	
	FldSetTextHandle( fldP, txtH );
	FldDrawField( fldP );
	
	fldP->attr.editable	= fieldWasEditable;


	// free the handle AFTER we call FldSetTextHandle().
	
	if ( oldTxtH != NULL ) MemHandleFree( oldTxtH );
	
	return fldP;

}	// SetFieldTextFromStr



//=======================================================================
// SetFieldTextFromRes
//
// given a formPtr and fieldID, set the text of the field from the string
// resource strID. the active form is used if formP is NULL. works
// even if the field is not editable.
//
// return a pointer to the field.
// 
//=======================================================================

FieldPtr SetFieldTextFromRes( FormPtr formP, Word fieldID, Word strID )
{
	Handle		oldTxtH;
	
	Handle		strH;
	CharPtr		strP;
	UInt			strSize;

	Handle		txtH;
	CharPtr		txtP;

	FieldPtr		fldP;
	Boolean		fieldWasEditable;
	

	// get a ptr and length of the string.
	
	strH	= DmGetResource( strRsc, strID );
	strP	= MemHandleLock( strH );
	strSize	= StrLen( strP ) + 1;

	// get some space in which to stash the string.
		
	txtH	= MemHandleNew( strSize );
	txtP	= MemHandleLock( txtH );

	// copy the string.
		
	StrCopy( txtP, strP );


	// unlock the handles.
		
	MemHandleUnlock( strH );
	MemHandleUnlock( txtH );

	
	// release the resource.
	
	DmReleaseResource( strH );


	// get the field and the field's current text handle.
	
	fldP		= GetObjectPtr( formP, fieldID );	
	oldTxtH	= FldGetTextHandle( fldP );


	// set the field's text to the new text.
	
	fieldWasEditable		= fldP->attr.editable;
	fldP->attr.editable	= true;
	
	FldSetTextHandle( fldP, txtH );
	FldDrawField( fldP );
	
	fldP->attr.editable	= fieldWasEditable;


	// free the handle AFTER we call FldSetTextHandle().
	
	if ( oldTxtH != NULL ) MemHandleFree( oldTxtH );

	
	return fldP;

}	// SetFieldTextFromRes




//=======================================================================
// ClearFieldText
//
// given a formPtr and fieldID, set the text of the field from the string
// resource strID. the active form is used if formP is NULL.
// 
//=======================================================================

FieldPtr ClearFieldText( FormPtr formP, Word fldID )
{
	FieldPtr	fldP;
	Handle	txtH;


	// clear the text from the field specified by fldID in the form on fromPtr.

	fldP = GetObjectPtr( formP, fldID );	
	txtH = FldGetTextHandle( fldP );


	// if there is a text handle, free the text.
	
	if ( txtH != NULL )
	{
		FldSetTextHandle( fldP,NULL );

		// free the handle AFTER we call FldSetTextHandle().

		MemHandleFree( txtH );
	}

	return fldP;
	
}	// ClearFieldText



//=======================================================================
// ShowErrorDialog
// ShowErrorDialog2
//
// display an error dialog with text from the string resource stringID and
// string on aStrPtr, or from two string resources stringID1 and stringID2.
// 
//=======================================================================

#define PUNT_STRING	" "

void ShowErrorDialog( Word stringID, CharPtr aStrPtr )
{
	// get a pointer to the string with ID stringID.
	
	Handle	strH = DmGetResource( strRsc, stringID );
	CharPtr	strP = MemHandleLock( strH );

	
	// FrmCustomAlert() really doesn't like to be handed NULL or empty
	// strings, so use " ".
	
	FrmCustomAlert( ErrorNoticeAlert, strP,
									  ( aStrPtr == NULL ) ? PUNT_STRING : aStrPtr,
									  PUNT_STRING );

	// clean up.
	
	MemHandleUnlock( strH );
	DmReleaseResource( strH );

}	// ShowErrorDialog


void ShowErrorDialog2( Word stringID1,  Word stringID2 )
{
	// get a pointer to the string with ID stringID1.
	
	Handle	strH1 = DmGetResource( strRsc, stringID1 );
	CharPtr	strP1 = MemHandleLock( strH1 );

	Handle	strH2 = DmGetResource( strRsc, stringID2 );
	CharPtr	strP2 = MemHandleLock( strH2 );
	
	// FrmCustomAlert() really doesn't like to be handed NULL or empty
	// strings, so use " ".
	
	FrmCustomAlert( ErrorNoticeAlert, strP1, strP2, PUNT_STRING );


	// clean up.
	
	MemHandleUnlock( strH1 );
	MemHandleUnlock( strH2 );
	
	DmReleaseResource( strH1 );
	DmReleaseResource( strH2 );

}	// ShowErrorDialog2



//=======================================================================
// UpdateScrollBar
//
// update the scroll bar on barP associated with field fldP.
//=======================================================================

void UpdateScrollBar( FieldPtr fldP, ScrollBarPtr barP )
{
	Word	scrollPos;
	Word	textHeight;
	Word	fieldHeight;
	Short	maxValue;

	if ( fldP == NULL ) return;
	if ( barP == NULL ) return;
	
	FldGetScrollValues( fldP, &scrollPos, &textHeight,  &fieldHeight );

	if ( textHeight > fieldHeight )
		maxValue = textHeight - fieldHeight;
	else if ( scrollPos != 0 )
		maxValue = scrollPos;
	else
		maxValue = 0;

	SclSetScrollBar( barP, scrollPos, 0, maxValue, fieldHeight - 1 );

}	// UpdateScrollBar



//=======================================================================
// ScrollField
//
// scroll a field on fldP with scroll bar barP, linesToScroll lines.
//=======================================================================

void ScrollField( FieldPtr fldP, ScrollBarPtr barP, Short linesToScroll )
{

	if ( fldP == NULL ) return;
	if ( barP == NULL ) return;
	
	
	if ( linesToScroll < 0 )
	{
		Word	blankLines;
		Short	min;
		Short	max;
		Short	value;
		Short	pageSize;

		blankLines = FldGetNumberOfBlankLines( fldP );
		FldScrollField( fldP, -linesToScroll, up );
		
		// if there were blank lines visible at the end of the field
		// then we need to update the scroll bar.
		
		if ( blankLines != 0 )
		{
			// update the scroll bar.

			SclGetScrollBar( barP, &value, &min, &max, &pageSize );
			
			if ( blankLines > -linesToScroll )
				max += linesToScroll;
			else
				max -= blankLines;
				
			SclSetScrollBar( barP, value, min, max, pageSize );
		}
	}
	else if ( linesToScroll > 0 )
	{
		FldScrollField( fldP, linesToScroll, down );
	}

}	// ScrollField



//=======================================================================
// PageScroll
//
// update the result field scroll bar and any other indicators associated
// with the result field.
//=======================================================================

void PageScroll( FieldPtr fldP, ScrollBarPtr barP, DirectionType direction )
{
	if ( fldP == NULL ) return;
	if ( barP == NULL ) return;
	
	if ( FldScrollable( fldP, direction ) )
	{
		Word	linesToScroll;
		Short	value;
		Short	min;
		Short	max;
		Short	pageSize;

		linesToScroll = FldGetVisibleLines( fldP ) - 1;
		FldScrollField( fldP, linesToScroll, direction );

		// update the scroll bar.
		
		SclGetScrollBar( barP, &value, &min, &max, &pageSize );

		if ( direction == up )
			value -= linesToScroll;
		else
			value += linesToScroll;
		
		SclSetScrollBar( barP, value, min, max, pageSize );
	}

}	// PageScroll	



//=======================================================================
// DrawBitmap
//
// if drawIt is true, draw a bitmap with resource ID resID, at position x, y
// relative to the current window. otherwise, erase a rectangle enclosing
// the bitmap specified by resID.
//=======================================================================

static void DrawBitMap( Int resID, Short x, Short y, Boolean drawIt )
{
	Handle		resH = DmGetResource( bitmapRsc, resID );
	BitmapPtr	resP = MemHandleLock( resH );


	if ( drawIt )
	{
		// ok, draw it!
		
		WinDrawBitmap( resP, x, y );
	}
	else
	{
		// erase it!
		
		RectangleType	bounds;
		
		bounds.topLeft.x	= x;
		bounds.topLeft.y	= y;
		bounds.extent.x	= resP->width;
		bounds.extent.y	= resP->height;
		
		WinEraseRectangle( &bounds, 0 );
	}
	

	// clean up.
	
	MemPtrUnlock( resP );
	DmReleaseResource( resH );

}	// DrawBitMap




//=======================================================================
// FingerResultUpdate
//
// update the result field scroll bar and any other indicators associated
// with the result field.
//=======================================================================

void FingerResultUpdate( Boolean doInit, ULong bytesFetched )
{
	static	SWord	actIndX;
	static	SWord	actIndY;
	static	Int	updateState;					// drawing state
	const		Int	netActBitMaps[ ] =			// bitmaps to draw
	{
		NetActBitMap + 0,
		NetActBitMap + 1,
		NetActBitMap + 2,
		NetActBitMap + 3,
		NetActBitMap + 4,
		0
	};
	
	UpdateScrollBar( GetObjectPtr( NULL, FingerResultField ),
					 	  GetObjectPtr( NULL, FingerResultScrollBar ) );


	if ( doInit )
	{
		// get the location of the gadget placeholder for the net activity
		// icons.
		
		FormPtr 	frmP = FrmGetActiveForm();
		FrmGetObjectPosition( frmP, FrmGetObjectIndex( frmP, FingerNetActivityGadget ),
									 &actIndX, &actIndY );

		// erase the activity icon.
		
		DrawBitMap( netActBitMaps[ 0 ], actIndX, actIndY, false );

		updateState = 0;
		
	}
	else
	{
		Char			tmpStr[ 20 ];

		// display the number of bytes received.

		StrPrintF( tmpStr, "%ld Bytes", bytesFetched ); 
		SetFieldTextFromStr( NULL, FingerRetrievedField, tmpStr );		

		
		// draw the activity icon.
		
		DrawBitMap( netActBitMaps[ updateState++ ], actIndX, actIndY, true );


		// update the state.
				
		if ( netActBitMaps[ updateState ] == 0 ) updateState = 0;	
	
	}
	
}	// FingerResultUpdate




//=======================================================================
// AppFormHandleEvent
//
// generic handler for the app's static forms
//=======================================================================

static Boolean AppFormHandleEvent( EventPtr event )
{
	FormPtr 	frmP;
	Boolean 	handled = true;

	// Get the form pointer
	frmP = FrmGetActiveForm();


	//---------------------------------------------------------------
	// Key Events
	//---------------------------------------------------------------
	if (event->eType == keyDownEvent)
	{
		switch( event->data.keyDown.chr )
		{
			case pageUpChr:			// Scroll up key presed?
				PageScroll( GetObjectPtr( frmP, FingerResultField ), 
							GetObjectPtr( frmP, FingerResultScrollBar),
							up );
				handled = true;
				break;
				
			case pageDownChr:		// Scroll down key presed?						
				PageScroll( GetObjectPtr( frmP, FingerResultField), 
							GetObjectPtr( frmP, FingerResultScrollBar),
							down );
				handled = true;
				break;
				
			default:
				handled = false;
				break;
				
		}	// switch
	}

		
	//---------------------------------------------------------------
	// Controls
	//---------------------------------------------------------------
	else if (event->eType == ctlSelectEvent)
	{
		switch( event->data.ctlSelect.controlID )
		{
			case FingerFingerButton:
				{
					Handle		whoStrH   = NULL;
					Handle		whereStrH = NULL;
				

					// if we have a valid network address, do the finger. ValidNetAddress()
					// puts up an error dialog if it doesn't like the address string.
					
					if ( ValidNetAddress( frmP, FingerAddressField, &whoStrH, &whereStrH ) )
					{
						// valid network address, make sure the connection is open,
						// dialing if necessary.
						
						if ( OpenNetwork() )
						{
							// the connection is open! do the finger...
							
							FingerIt( whoStrH, whereStrH, GetObjectPtr( frmP, FingerResultField ) );

							
							// show the Disconnect button.
							
							ShowControl( frmP, FingerDisconnectButton, true );
						
						}	// if OpenNetwork( � )
						
						// done with the address, so free the space.
						
						if ( whoStrH   != NULL ) MemHandleFree( whoStrH );
						if ( whereStrH != NULL ) MemHandleFree( whereStrH );
						
					}	// if ValidNetAddress( � )
					
				}
				break;
			
			case FingerDisconnectButton:
			
				// Disconnect button. close the connection and hide the Disconnect
				// button.
				
				CloseNetwork( true );
				ShowControl( frmP, FingerDisconnectButton, false );
				break;
			
			case FingerDoneButton:
				{
					EventType	newEvent;

					// exit the application by inserting an appStopEvent
					// into the event queue.
					
			    	MemSet( &newEvent, sizeof( EventType ), 0 );
			   	newEvent.eType = appStopEvent;
			   	EvtAddEventToQueue( &newEvent );
			   }
				break;
		
			default:
				handled = false;
				break;

		}	// switch
	}



	//---------------------------------------------------------------
	// Menus
	//---------------------------------------------------------------
	else if ( event->eType == menuEvent )
	{
		handled = false;
	}

		
	//---------------------------------------------------------------
	// Pop up lists
	//---------------------------------------------------------------
	else if ( event->eType == popSelectEvent )
	{
		// stub for pop up lists...
		
		switch ( event->data.popSelect.listID )
		{
			default:
				handled = false;
				break;
		}	// switch
			
	}

		
	//---------------------------------------------------------------
	// Form Open
	//---------------------------------------------------------------
	else if ( event->eType == frmOpenEvent )
	{
		// set the current form ID global
			
		gCurrentFrmID = frmP->formId;

		// initialize the network globals.
		
		InitNetworkGlobals();
		
		// update the scroll bar and connection icon.
		
		FingerResultUpdate( true, 0 );	
		
		// put an initial address in the finger address field.
				
		SetFieldTextFromRes( frmP, FingerAddressField, TestAddr2String );

		// show the disconnect button if the network connection is live.
		
		ShowControl( frmP, FingerDisconnectButton, TestNetwork() );

		// clear the result field, freeing the text handle associated with
		// the field. it is important do do this before we do a Finger because
		// we will be putting a handle to a DB record in the field later. from
		// now on, we assume that any non-NULL handle in the result field is
		// to a DB record.
							 
		ClearFieldText( frmP, FingerResultField );

		// show the form and set the focus to the address field.
		
		FrmDrawForm( frmP );
		FrmSetFocus( frmP, FrmGetObjectIndex( frmP, FingerAddressField ) );


		// create the finger database. exit the app if we fail to create
		// the DB ( CreateFingerDatabase() will post the alert if we fail ).
		
		if ( ! CreateFingerDatabase() )
		{
			EventType	newEvent;

			// exit the application by inserting an appStopEvent
			// into the event queue.
			
	    	MemSet( &newEvent, sizeof( EventType ), 0 );
	   	newEvent.eType = appStopEvent;
	   	EvtAddEventToQueue( &newEvent );
		}
		
	}

	//---------------------------------------------------------------
	// Form Close
	//---------------------------------------------------------------
	else if ( event->eType == frmCloseEvent )
	{

		handled = false;
	}

	//---------------------------------------------------------------
	// Form Update
	//---------------------------------------------------------------
	else if ( event->eType == frmUpdateEvent )
	{
		handled = false;
	}

	//---------------------------------------------------------------
	// Scroll Bar Update
	//---------------------------------------------------------------

	else if (event->eType == sclRepeatEvent)
	{
		ScrollField( GetObjectPtr( frmP, FingerResultField ),
					 GetObjectPtr( frmP, FingerResultScrollBar ),
					 ( event->data.sclRepeat.newValue - 
					   event->data.sclRepeat.value ) );
		handled = false;
	}

	//---------------------------------------------------------------
	// Everything else...
	//---------------------------------------------------------------
	else
	{
		handled = false;
	}

	return handled;

}	// AppFormHandleEvent



//=======================================================================
// AppHandleEvent
//
// loads form resources and sets the event handler for the form loaded.
//
// returns true if the event was handled and should not be passed
// to a higher level handler.
//=======================================================================

static Boolean AppHandleEvent( EventPtr event )
{
	Boolean	eventHandled = true;

	if ( event->eType == frmLoadEvent )
	{
		// Load the form resource.
		
		Word	formID	= event->data.frmLoad.formID;
		FormPtr	frm		= FrmInitForm( formID );

		FrmSetActiveForm( frm );		


		// set the event handler for the form. the handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		//
		// for this app, all forms are handled by the same routine.
			
		switch( formID )
		{
			case FingerForm:
				FrmSetEventHandler( frm, AppFormHandleEvent );
				break;



			// if you add more forms to the app, put a case in for each new
			// form...
		
							
			default:
				eventHandled = false;
				break;
				
		}	// switch
	}
	else
	{
		eventHandled = false;
	}
	
	
	return eventHandled;

}	// AppHandleEvent





//=======================================================================
// AppEventLoop
//
// loop to process application events.
//=======================================================================

static void AppEventLoop(void)
{
	Word		 	error;
	EventType 	event;


	do
	{
		// get an event to process.

		EvtGetEvent( &event, evtWaitForever );


		// normal processing of events.
		
		if ( !SysHandleEvent ( &event ) )
		{
			if ( !MenuHandleEvent( NULL /* CurrentMenuP */, &event, &error ) )
			{
				if ( !AppHandleEvent( &event ) ) FrmDispatchEvent( &event );

			}	// Menu
			
		}	// Sys
			
	}
	while( event.eType != appStopEvent );

}	// AppEventLoop




//=======================================================================
// AppStart
//
//=======================================================================

static Word AppStart( void )
{

	return 0;
	
}	// AppStart



//=======================================================================
// AppStop
//
//=======================================================================

static void AppStop( void )
{
	// disassociate the text buffer (a DB chunk) from the result
	// form. if we do not, the form will try to free the space - we
	// would MUCH rather do this by explicitly removing the
	// record or (in our case), deleting the DB.
	
	FldSetTextHandle( GetObjectPtr( FrmGetActiveForm(), FingerResultField ), NULL );


	// close the network, but allow the connection to remain open
	// for other apps (on the device - close the connection under
	// the simulator).

#if EMULATION_LEVEL == EMULATION_NONE
	CloseNetwork( false );
#else
	CloseNetwork( true );
#endif
	
	// cleanup the DB.
	
	ClobberFingerDatabase( false );

}	// AppStop




/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version meets your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *                             
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/15/96	Initial Revision
 *
 ***********************************************************************/
 
static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;

	// See if we have at least the minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return (0);
}



//=======================================================================
// PilotMain
//
// application entry point.
//=======================================================================

#define version20			0x02000000

DWord	PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags )
{

	// If normal launch
	
	if ( cmd == sysAppLaunchCmdNormalLaunch )
	{
		Word error;


		// initialize globals.
		
		gCurrentFrmID = 0;
		gFingerDB	  = 0;	


		// check the ROM version - bail if it's not right...
		
		error = RomVersionCompatible( version20, launchFlags );
		if ( error ) return error;


		error = AppStart ();
		if ( error ) return error;


		// first form.
		
		FrmGotoForm( FingerForm );

		
		// run the event loop. returns to exit.
		
		AppEventLoop ();
		AppStop ();

	}

	return 0;

}	// PilotMain



