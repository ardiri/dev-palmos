/***************************************************************************
* FingerDemo.h
*
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.
 
 *****************************************************************************
*
* HISTORY
*		01/04/97		Gregory Toto, created. 
*
********************************************************************************/

#include "Finger.h"



// useful debugging tools on the device when the serial port is occupied
// and you can't use the nifty source code debugger...

#define	AlertPrintf1(a)					FrmCustomAlert(PrintfAlert,(a)," "," ")
#define	AlertPrintf2(a,b)					FrmCustomAlert(PrintfAlert,(a),(b)," ")
#define	AlertPrintf3(a,b,c)				FrmCustomAlert(PrintfAlert,(a),(b),(c))

#define AlertPrintf							AlertPrintf2



// resource ID of first network activity bitmap.
// define here because of Constructor b10 bug -
// #defines for bit maps are not generated...

#define NetActBitMap							1100



#define FingerDBNameStr						"FingerDB"
#define FingerCreator						'Fngr'
#define FingerDBType							'DATA'




//=======================================================================
// FingerMain.c

Boolean CreateFingerDatabase( void );
void ClobberFingerDatabase( Boolean showErrDialog );


void ShowControl( FormPtr formP, Word controlID, Boolean showTheControl );

FieldPtr SetFieldTextFromStr( FormPtr formP, Word fieldID, CharPtr strP );
FieldPtr SetFieldTextFromRes( FormPtr formP, Word fieldID, Word strID );

FieldPtr ClearFieldText( FormPtr formP, Word fldID );
void ShowErrorDialog( Word stringID, CharPtr aStrPtr );
void ShowErrorDialog2( Word stringID1,  Word stringID2 );
void UpdateScrollBar( FieldPtr fldP, ScrollBarPtr barP );
void ScrollField( FieldPtr fldP, ScrollBarPtr barP, Short linesToScroll );
void PageScroll( FieldPtr fldP, ScrollBarPtr barP, DirectionType direction );

void FingerResultUpdate( Boolean doInit, ULong bytesFetched );


// Network.c

void InitNetworkGlobals( void );
Boolean ValidNetAddress( FormPtr formP, Word addrFieldID, Handle * whoStrHP, Handle * whereStrHP );
Boolean FindNetworkLibrary( void );
Boolean OpenNetwork( void );
Boolean CloseNetwork( Boolean forceToClose );
Boolean RefreshNetwork( Boolean reconnectIfDown );
Boolean TestNetwork( void );
void FingerIt( Handle whoStrH, Handle whereStrH, FieldPtr resFldP );




//=======================================================================

extern Word			gCurrentFrmID;
extern DmOpenRef	gFingerDB;	

