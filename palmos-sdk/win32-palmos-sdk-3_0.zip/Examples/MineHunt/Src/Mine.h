/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Touchdown
 * FILE:     Mine.h
 * AUTHOR:	 Vitaly Kruglikov: October 8, 1995
 *
 * DECLARER: Mine
 *
 * DESCRIPTION:
 *		This is the MineHunt application's header file.
 *
 **********************************************************************/
#ifndef __MINE_H__
#define __MINE_H__

#include <Common.h>


/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define mineAppVersionNum		0x0101
#define mineAppCreator			'mhdk'

#define version20					0x02000000


#define maxRows				10
#define maxColumns			11


/***********************************************************************
 *
 *	Internal Structures
 *
 ***********************************************************************/
typedef struct PieceCoordType {
	Int		row;							// 0-based
	Int		col;							// 0-based
	} PieceCoordType;


// States of a game piece
enum {
	covered = 0,
	markedMine = 1,
	markedUnknown = 2,
	uncovered = 3
	};
	
typedef struct GamePieceType {
	unsigned mined : 1;				// if set, there is a mine at this position
	unsigned state : 2;				// covered, uncovered, markedMine, markedUnknown
	unsigned neighbours: 4;			// number of neighbours
	unsigned mark : 1;				// used for computing which pieces to uncover
											// automatically
	} GamePieceType;


// States of the game
typedef enum GameStateType {
	gameInProgress,
	gameWon,
	gameDead
	} GameStateType;

typedef struct GameType {
	Boolean			restored;		// if true, the game was restored from preferences
	PointType		origin;			// board origin (x,y)
	Byte				numRows;			// number of rows
	Byte				numCol;			// number of columns
	Byte				numMines;		// number of mines
	Int				minesLeft;		// number of mines left to uncover
	GameStateType	state;			// game state
	PieceCoordType	deadCoord;		// coordinate of piece which killed the game
	GamePieceType	piece[maxRows][maxColumns];	// game pieces
	} GameType;

typedef enum SquareGraphicType {
	coveredSquareGraphic = 0,
	markedUnknownSquareGraphic,
	markedMineSquareGraphic,
	mineSquareGraphic,
	notMineSquareGraphic,
	emptySquareGraphic,
	lastSquareGraphic
	} SquareGraphicType;

//
// App preferences structures
//

// Game difficulty
typedef enum DifficultyType {
	difficultyEasy = 0,				// must start at zero for mapping tables to work correctly
	difficultyIntermediate,
	difficultyMoreDifficult,
	difficultyImpossible
	} DifficultyType;

#define defaultDifficulty		difficultyIntermediate;
	
// Preferences resource type
typedef struct MinePrefType {
	DWord				signature;		// signature for preferences resource validation
	GameType			game;				// saved game info
	DifficultyType	difficulty;		// difficulty level
	} MinePrefType;
	
#define	minePrefSignature	'MiNe'

#endif	// __MINE_H__
