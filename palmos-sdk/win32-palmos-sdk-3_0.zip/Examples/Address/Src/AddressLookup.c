/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 **********************************************************************/

#include <Pilot.h>

#include "AddressDB.h"
#include "Address.h"
#include "AddressRsc.h"

#pragma mark ----------------
/***********************************************************************
 *
 * FUNCTION:    LookupDrawRecordFields
 *
 * DESCRIPTION: Draws the name and phone number (plus which phone)
 * within the screen bounds passed.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *              record - record to draw
 *              field - phone to draw
 *              bounds - bounds of the draw region
 *              phoneLabelLetters - the first letter of each phone label
 *              sortByCompany - true if the database is sorted by company
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         roger   6/21/95   Initial Revision
 *
 ***********************************************************************/
 
static void LookupDrawRecordFields (LookupVariablesPtr vars,
   AddrDBRecordPtr record, UInt field, RectanglePtr bounds, 
   CharPtr phoneLabelLetters)
{
   CharPtr name1;
   CharPtr name2;
   CharPtr field1;
   CharPtr field2;
   SWord x;
   SWord y;
   Int   field1Length;
   Int   field2Length;
   Int   field1Width;
   Int   field2Width;
   Int   horizontalSpace;
   UInt  phoneLabel;
   UInt  fieldSeparatorWidth;
   UInt  shortenedFieldWidth;
   UInt  field1Num;
   UInt  field2Num;
   Int  name1Length;
   Int  name2Length;
   Int  name1Width;
   Int  name2Width;
   Boolean ignored;
   Boolean everythingFits;
	Boolean name1HasPriority = true;
	Byte phoneLabelWidth;
	

   x = bounds->topLeft.x;
   y = bounds->topLeft.y;
   
   phoneLabelWidth = FntCharWidth('W') - 1;		// remove the blank trailing column


//   bounds->extent.x -= (phoneLabelWidth + 1);
   
   
   // Do we need to figure out the person's name?
   if (vars->params->field1 == addrLookupSortField ||
      vars->params->field2 == addrLookupSortField)
      {
      name1HasPriority = DetermineRecordName (record, &shortenedFieldWidth,
      	&fieldSeparatorWidth, vars->sortByCompany, &name1, &name1Length, &name1Width, 
         &name2, &name2Length, &name2Width, NULL, bounds->extent.x);
      }
   
   // Handle the first field to display
   field1Num = vars->params->field1;
   if (field1Num == addrLookupSortField)
      {
      field1Width = name1Width + (name2 ? fieldSeparatorWidth : 0) +
         name2Width;
      }
   else if (field1Num == addrLookupNoField)
      {
      field1Length = 0;
      field1Width = 0;
      }
   else
      {
      // Map from the lookup field requested to the Address's format
      if (IsPhoneLookupField(field1Num))
         {
         field1 = record->fields[field];
         }
      else if (field1Num == addrLookupListPhone)
         {
         field1 = record->fields[phone1 + record->options.phones.displayPhoneForList];
         }
      else
         {
         field1 = record->fields[vars->lookupFieldMap[field1Num]];
         }
      
      if (field1)
         {
         // Only show text from the first line in the field
         field1Width = bounds->extent.x;
         field1Length = field1Width;      // more characters than we can expect
         FntCharsInWidth (field1, &field1Width, &field1Length, &ignored);//lint !e64
         
         // Leave room for a letter to indicate which phone is being displayed.
         if (field1Num == addrLookupListPhone)
            field1Width += phoneLabelWidth + 1;
         }
      else
         {
         field1Length = 0;
         field1Width = 0;
         }
      }
      
      
   // Handle the second field to display
   field2Num = vars->params->field2;
   if (field2Num == addrLookupSortField)
      {
      // This is the width of the name before any truncation.
      field2Width = name1Width + (name2 ? fieldSeparatorWidth : 0) +
         name2Width;
      }
   else if (field2Num == addrLookupNoField)
      {
      field2Length = 0;
      field2Width = 0;
      }
   else
      {
      // Map from the lookup field requested to the Address's format
      if (IsPhoneLookupField(field2Num))
         {
         field2 = record->fields[field];
         }
      else if (field2Num == addrLookupListPhone)
         {
         field2 = record->fields[phone1 + record->options.phones.displayPhoneForList];
         }
      else
         {
         field2 = record->fields[vars->lookupFieldMap[field2Num]];
         }
      
      if (field2)
         {
         // Only show text from the first line in the field
         field2Width = bounds->extent.x;
         field2Length = field2Width;      // more characters than we can expect
         FntCharsInWidth (field2, &field2Width, &field2Length, &ignored);//lint !e64
         
         // Leave room for a letter to indicate which phone is being displayed.
         if (vars->params->field2 == addrLookupListPhone)
            field2Width += phoneLabelWidth + 1;
         }
      else
         {
         field2Length = 0;
         field2Width = 0;
         }
      }



   // Now check if everything can display without any truncation.   
   everythingFits = bounds->extent.x >= field1Width + 
      ((field1Width && field2Width) ? spaceBetweenNamesAndPhoneNumbers : 0) + 
      field2Width;
/*   if (bounds->extent.x   >= name1Width + (name2 ? fieldSeparatorWidth : 0) +
      name2Width + (phone ? spaceBetweenNamesAndPhoneNumbers : 0) + phoneWidth)
*/      {
      }
   
   // Find out how much room the left side can use
   if (everythingFits || field2Num == addrLookupNoField)
      horizontalSpace = bounds->extent.x;
   else
      {
      horizontalSpace = bounds->extent.x - spaceBetweenNamesAndPhoneNumbers;
      
      // This allows the left side to use space on the right side if the
      // right side is small enough.
      horizontalSpace -= min(horizontalSpace / 2, field2Width);
      }
   x = bounds->topLeft.x;
   
   
   // Now draw the left side.
   if (vars->params->field1 == addrLookupSortField)
      {
      DrawRecordName (name1, name1Length, name1Width, name2, name2Length, name2Width,
         horizontalSpace, &x, y, shortenedFieldWidth, fieldSeparatorWidth, false,
         name1HasPriority || !vars->sortByCompany);
      
      // Remember how much width was actually used for field1
      field1Width = x - bounds->topLeft.x;
      }
   else if (vars->params->field1 == addrLookupListPhone)
      {
      if (field1Width > horizontalSpace)
         {
         everythingFits = false;
         field1Width = horizontalSpace - phoneLabelWidth - 1 - shortenedFieldWidth;

         FntCharsInWidth(field1, &field1Width, &field1Length, &ignored);
         }
      else
         {
         everythingFits = true;
         field1Width -= phoneLabelWidth + 1;
         }
      
      x = bounds->topLeft.x;
      if (!everythingFits)
         x -= shortenedFieldWidth;
      WinDrawChars(field1, field1Length, x, y);
      x = bounds->topLeft.x + field1Width;
      
      if (!everythingFits)
         {
         WinDrawChars(shortenedFieldString, shortenedFieldLength, 
            x, y);
         x += shortenedFieldWidth;
         }

      // Draw the first letter of the phone field label
      phoneLabel = GetPhoneLabel(record, firstPhoneField + 
         record->options.phones.displayPhoneForList);
      WinDrawChars (&phoneLabelLetters[phoneLabel], 1,
         x + ((phoneLabelWidth - (FntCharWidth(phoneLabelLetters[phoneLabel]) - 1)) >> 1), //lint !e702
         y);
      
      // Remember how much width was actually used for field1
      field1Width = x + phoneLabelWidth - bounds->topLeft.x;
      }
   else if (vars->params->field1 != addrLookupNoField)
      {
      if (field1Width > horizontalSpace)
         {
         everythingFits = false;
         field1Width = horizontalSpace - shortenedFieldWidth;
         FntCharsInWidth(field1, &field1Width, &field1Length, &ignored);//lint !e64
         }
      else
         {
         everythingFits = true;
         }
         
      x = bounds->topLeft.x;
      WinDrawChars(field1, field1Length, x, y);
      x += field1Width;
         
      if (!everythingFits)
         {
         WinDrawChars(shortenedFieldString, shortenedFieldLength, x, y);
         x += shortenedFieldWidth;
         }
      
      // Remember how much width was actually used for field1
      field1Width = x - bounds->topLeft.x;
      }
   
   
   // Find out how much room the right side can use
   horizontalSpace = bounds->extent.x - field1Width - spaceBetweenNamesAndPhoneNumbers;
   x = bounds->topLeft.x + bounds->extent.x - field1Width;

   // Now draw the right side.
   if (vars->params->field2 == addrLookupSortField)
      {
      DrawRecordName (name1, name1Length, name1Width, name2, name2Length, name2Width,
         horizontalSpace, &x, y, shortenedFieldWidth, fieldSeparatorWidth, false,
         name1HasPriority || !vars->sortByCompany);
      }
   else if (vars->params->field2 == addrLookupListPhone)
      {
      if (field2Width > horizontalSpace)
         {
         everythingFits = false;
         field2Width = horizontalSpace - phoneLabelWidth - 1 - shortenedFieldWidth;

         FntCharsInWidth(field2, &field2Width, &field2Length, &ignored);//lint !e64
         }
      else
         {
         everythingFits = true;
         field2Width -= phoneLabelWidth + 1;
         }

      
      x = bounds->topLeft.x + (bounds->extent.x - 1) - field2Width - phoneLabelWidth - 1;
      if (!everythingFits)
         x -= shortenedFieldWidth;
      WinDrawChars(field2, field2Length, x, y);
         
      if (!everythingFits)
         {
         WinDrawChars(shortenedFieldString, shortenedFieldLength, 
            bounds->topLeft.x + (bounds->extent.x - 1) - shortenedFieldWidth - 
            phoneLabelWidth - 1, y);
         }

      // Draw the first letter of the phone field label
      phoneLabel = GetPhoneLabel(record, firstPhoneField + 
         record->options.phones.displayPhoneForList);
      WinDrawChars (&phoneLabelLetters[phoneLabel], 1,
         bounds->topLeft.x + (bounds->extent.x - 1) - phoneLabelWidth + 
         ((phoneLabelWidth - (FntCharWidth(phoneLabelLetters[phoneLabel]) - 1)) >> 1), //lint !e702
         y);
      }
   else if (vars->params->field2 != addrLookupNoField)
      {
      if (field2Width > horizontalSpace)
         {
         everythingFits = false;
         field2Width = horizontalSpace - shortenedFieldWidth;
         FntCharsInWidth(field2, &field2Width, &field2Length, &ignored);//lint !e64
         }
      else
         {
         everythingFits = true;
         }
         
      x = bounds->topLeft.x + bounds->extent.x - field2Width;
      if (!everythingFits)
         x -= shortenedFieldWidth;
      WinDrawChars(field2, field2Length, x, y);
         
      if (!everythingFits)
         {
         WinDrawChars(shortenedFieldString, shortenedFieldLength, 
            bounds->topLeft.x + bounds->extent.x - shortenedFieldWidth, y);
         }
      }
   
   
   
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewDrawRecord
 *
 * DESCRIPTION: This routine draws an address book record.  It is called as
 *              a callback routine by the table object.
 *
 * PARAMETERS:  table  - pointer to the address list table
 *              row    - row number, in the table, of the item to draw
 *              column - column number, in the table, of the item to draw
 *              bounds - bounds of the draw region
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
 
static void LookupViewDrawRecord (VoidPtr table, Word row, Word column, 
   RectanglePtr bounds)
{
   Word recordNum;
   Word fieldNum;
   Err error;
   AddrDBRecordType record;
   Handle recordH;
   LookupVariablesPtr vars;


   // Get the record number that corresponds to the table item to draw.
   // The record number is stored in the "intValue" field of the item.
   // 
   recordNum = TblGetRowID (table, row);
   vars = (LookupVariablesPtr) TblGetRowData(table, row);

   error = AddrGetRecord (vars->dbP, recordNum, &record, &recordH);
   ErrNonFatalDisplayIf ((error), "Record not found");
   if (error) return;

   fieldNum = TblGetItemInt(table, row, column);
   
	FntSetFont (stdFont);

   LookupDrawRecordFields (vars, &record, fieldNum, bounds, 
      vars->phoneLabelLetters);

   MemHandleUnlock(recordH);
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewUpdateScrollButtons
 *
 * DESCRIPTION: Show or hide the list view scroll buttons.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupViewUpdateScrollButtons (LookupVariablesPtr vars)
{
   SWord   row;
   Word upIndex;
   Word downIndex;
   Word recordNum;
   Word phoneNum;
   Boolean scrollableUp;
   Boolean scrollableDown;
   TablePtr table;


   // Update the buttons that scroll the list.
   //
   // If the first record displayed is not the fist record in the category,
   // enable the up scroller.
   recordNum = vars->topVisibleRecord;
   phoneNum = vars->topVisibleRecordPhone;
   scrollableUp = AddrLookupSeekRecord (vars->dbP, &recordNum, &phoneNum, 1, dmSeekBackward,
      vars->params->field1, vars->params->field2, vars->lookupFieldMap);


   // Find the record in the last row of the table
   table = GetObjectPtr (LookupTable);
   for (row = TblGetNumberOfRows (table) - 1; row >= 0; row--)
      {
      // Make the row usable.
      if (TblRowUsable (table, row))
         {
         recordNum = TblGetRowID (table, row);
         phoneNum = TblGetItemInt (table, row, 0);
         break;
         }
      }


   // If the last record displayed is not the last record in the category,
   // enable the down scroller.
   scrollableDown = AddrLookupSeekRecord (vars->dbP, &recordNum, &phoneNum, 1, dmSeekForward,
      vars->params->field1, vars->params->field2, vars->lookupFieldMap);


   // Update the scroll button.
   upIndex = FrmGetObjectIndex (vars->frm, LookupUpButton);
   downIndex = FrmGetObjectIndex (vars->frm, LookupDownButton);
   FrmUpdateScrollers (vars->frm, upIndex, downIndex, scrollableUp, scrollableDown);

}


/***********************************************************************
 *
 * FUNCTION:    LookupLoadTable
 *
 * DESCRIPTION: This routine loads address book database records into
 *              the lookup view form.  Note that the phone field may
 *                be set to the first or last field if it isn't field1 or
 *                field2 and the table is loaded either forward or backward.
 *                So ignore it if phone are not being displayed.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupLoadTable (LookupVariablesPtr vars)
{
   Word      row;
   Word      numRows;
   Word      recordNum;
   Word      phoneNum;
   TablePtr table;
   Boolean searchPhones;

   
   // For each row in the table, store the record number as the row id.
   table = GetObjectPtr (LookupTable);


   // Make sure we haven't scrolled too far down the list of records
   // leaving blank lines in the table.

   // Try going forward to the last record that should be visible
   numRows = TblGetNumberOfRows (table);
   recordNum = vars->topVisibleRecord;
   phoneNum = vars->topVisibleRecordPhone;
   if (!AddrLookupSeekRecord (vars->dbP, &recordNum, &phoneNum, numRows - 1, dmSeekForward,
      vars->params->field1, vars->params->field2, vars->lookupFieldMap))
      {
      // We have at least one line without a record.  Fix it.
      // Try going backwards one page from the last record
      vars->topVisibleRecord = dmMaxRecordIndex;
      vars->topVisibleRecordPhone = numPhoneFields - 1;
      if (!AddrLookupSeekRecord (vars->dbP, &vars->topVisibleRecord, &vars->topVisibleRecordPhone, 
         numRows - 1, dmSeekBackward, vars->params->field1, vars->params->field2, 
         vars->lookupFieldMap))
         {
         // Not enough records to fill one page.  Start with the first record
         vars->topVisibleRecord = 0;
         vars->topVisibleRecordPhone = 0;
         AddrLookupSeekRecord (vars->dbP, &vars->topVisibleRecord, &vars->topVisibleRecordPhone,
            0, dmSeekForward,   vars->params->field1, vars->params->field2, 
            vars->lookupFieldMap);
         }
      }



   numRows = TblGetNumberOfRows (table);
   recordNum = vars->topVisibleRecord;
   phoneNum = vars->topVisibleRecordPhone;
   searchPhones = IsPhoneLookupField(vars->params->field1) ||
      IsPhoneLookupField(vars->params->field2);

   for (row = 0; row < numRows; row++)
      {
      if ( ! AddrLookupSeekRecord (vars->dbP, &recordNum, &phoneNum, 0, dmSeekForward,
         vars->params->field1, vars->params->field2, vars->lookupFieldMap))
         break;

      // Make the row usable.
      TblSetRowUsable (table, row, true);

      // Mark the row invalid so that it will draw when we call the 
      // draw routine.
      TblMarkRowInvalid (table, row);

      // Store the record number as the row id.
      TblSetRowID (table, row, recordNum);
      
      // Store a pointer to vars for the callback.  Ideally the table would
      // have one copy of this information but it doesn't so we keep
      // a pointer to vars in every row.
      TblSetRowData(table, row, (ULong) vars);
      
      // Store the field used for a phone in the item int.
      // We need to do this because some records have multiple
      // occurances when they have multiple identical phone types
      // (i.e. two email address).  The type is AddressField.
      // Remember that we allow only one of the two fields to be
      // a phone field.
      TblSetItemInt (table, row, 0, firstPhoneField + phoneNum);

      if (searchPhones)
         {
         phoneNum++;
         if (phoneNum >= numPhoneFields)
            {
            phoneNum = 0;
            recordNum++;
            }
         }
      else
         recordNum++;
      }
   

   // Hide the item that don't have any data.
   while (row < numRows)
      {      
      TblSetRowUsable (table, row, false);
      row++;
      }

   TblUnhighlightSelection(table);

   LookupViewUpdateScrollButtons(vars);
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewScroll
 *
 * DESCRIPTION: This routine scrolls the list of names and phone numbers 
 *              in the direction specified.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *              direction - up or dowm
 *              oneLine   - if true the list is scroll by a single line,
 *                          if false the list is scroll by a full screen.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupViewScroll (LookupVariablesPtr vars, DirectionType direction, 
   Boolean oneLine)
{
   TablePtr table;
   Word rowsInTable;
   UInt newTopVisibleRecord;
   UInt newTopVisibleRecordPhone;

   
   table = GetObjectPtr (LookupTable);
   rowsInTable = TblGetNumberOfRows (table);
   newTopVisibleRecord = vars->topVisibleRecord;
   newTopVisibleRecordPhone = vars->topVisibleRecordPhone;
   

   // Scroll the table down.
   if (direction == down)
      {
      // Scroll down a single line.  If we can't scroll down a line
      // then the scroll down arrow would not have been displayed.
      if (oneLine)
         {
         AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
            1, dmSeekForward, vars->params->field1, vars->params->field2, vars->lookupFieldMap);
         ErrNonFatalDisplayIf (DmGetLastErr(), "Error scrolling");
         }

      // Scroll down a page (less one row).
      else
         {
         // Try going forward one page
         if (!AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
            rowsInTable - 1, dmSeekForward, vars->params->field1, vars->params->field2, 
            vars->lookupFieldMap))
            {
            // Try going backwards one page from the last record
            newTopVisibleRecord = dmMaxRecordIndex;
            newTopVisibleRecordPhone = numPhoneFields - 1;
            if (!AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
               rowsInTable - 1, dmSeekBackward, vars->params->field1, 
               vars->params->field2, vars->lookupFieldMap))
               {
               // Not enough records to fill one page.  Start with the first record
               newTopVisibleRecord = 0;
               newTopVisibleRecordPhone = 0;
               AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
                  0, dmSeekForward, vars->params->field1, vars->params->field2, 
                  vars->lookupFieldMap);
               }
            }
         }
      }



   // Scroll the table up.
   else
      {
      // Scroll up a single line
      if (oneLine)
         {
         AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 1, 
            dmSeekBackward, vars->params->field1, vars->params->field2, vars->lookupFieldMap);
         ErrNonFatalDisplayIf (DmGetLastErr(), "Error scrolling");
         }

      // Scroll up a page (less one row).
      else
         {
         if (!AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
            rowsInTable - 1, dmSeekBackward, vars->params->field1, vars->params->field2, 
            vars->lookupFieldMap))
            {
            // Not enough records to fill one page.  Start with the first record
            newTopVisibleRecord = 0;
            newTopVisibleRecordPhone = 0;
            AddrLookupSeekRecord (vars->dbP, &newTopVisibleRecord, &newTopVisibleRecordPhone, 
               0, dmSeekForward, vars->params->field1, vars->params->field2, 
               vars->lookupFieldMap);
            }
         }
      }


   // Avoid redraw if no change
   if (vars->topVisibleRecord != newTopVisibleRecord ||
      vars->topVisibleRecordPhone != newTopVisibleRecordPhone)
      {
      vars->topVisibleRecord = newTopVisibleRecord;
      vars->topVisibleRecordPhone = newTopVisibleRecordPhone;
      LookupLoadTable(vars);
      TblRedrawTable(table);
      }
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewSelectRecord
 *
 * DESCRIPTION: Selects (highlights) a record on the table, scrolling
 *              the record if neccessary.  Also sets the CurrentRecord.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *              recordNum - record to select
 *              phoneNum - phone in record to select
 *                      
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupViewSelectRecord (LookupVariablesPtr vars, 
   UInt recordNum, UInt phoneNum)
{
   UInt row, column;
   TablePtr tableP;
   UInt attr;
   Boolean recordFound;
   Boolean searchPhones;


   ErrFatalDisplayIf (recordNum >= DmNumRecords(vars->dbP), "Record outside AddrDB");
   ErrFatalDisplayIf (phoneNum >= numPhoneFields, "Phone outside legal range");


   tableP = GetObjectPtr (LookupTable);


   // Don't change anything if the same record is selected
   if (TblGetSelection(tableP, &row, &column) &&
      recordNum == TblGetRowID (tableP, row) &&
      phoneNum == TblGetItemInt (tableP, row, 0))
      {
      return;
      }
      

   searchPhones = IsPhoneLookupField(vars->params->field1) ||
      IsPhoneLookupField(vars->params->field2);

   // See if the record is displayed by one of the rows in the table
   // A while is used because if TblFindRowID fails we need to
   // call it again to find the row in the reloaded table.
   while (true)
      {
      recordFound = false;
      if (TblFindRowID(tableP, recordNum, &row))
         {
         if (searchPhones)
            {
            for (; row < TblGetNumberOfRows(tableP); row++)
               {
               if (TblRowUsable(tableP, row))
                  {
                  if (phoneNum == TblGetItemInt(tableP, row, 0) - firstPhoneField)
                     {
                     recordFound = true;
                     break; // match found
                     }
                  }            
               }
            }
         else
            {
            recordFound = true;
            break; // match found
            }
         }
      
      // If the record is found in the existing table stop
      // and go select it.  Otherwise position that table to
      // start with the record, reload the table, and look
      // for it again.
      if (recordFound)
         break;
         
      if (vars->hideSecretRecords)
         {
         // If the record is hidden stop trying to show it.
         DmRecordInfo(vars->dbP, recordNum, &attr, NULL, NULL);
         if (attr & dmRecAttrSecret)
            {
            return;
            }
         }
            
      // Scroll the view down placing the item
      // on the top row
      vars->topVisibleRecord = recordNum;
      vars->topVisibleRecordPhone = phoneNum;

      LookupLoadTable(vars);
      TblRedrawTable(tableP);
      }

   
   // Select the item
   TblSelectItem (tableP, row, 0);
   
   vars->currentRecord = recordNum;
   vars->currentPhone = phoneNum;
}   
   

/***********************************************************************
 *
 * FUNCTION:    LookupViewLookupString
 *
 * DESCRIPTION: Adds a character to LookupLookupField, looks up the 
 * string in the database and selects the item that matches.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *              event - EventPtr containing character to add to LookupLookupField
 *                        or NULL to use the text there
 *                      
 * RETURNED:    true if the field handled the event
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static Boolean LookupViewLookupString (LookupVariablesPtr vars, 
   EventPtr event)
{
   FormPtr frm;
   UInt fldIndex;
   FieldPtr fldP;
   CharPtr fldTextP;
   TablePtr tableP;
   UInt foundRecord;
   UInt foundRecordPhone;
   Boolean completeMatch;
   Boolean uniqueMatch;
   Int length;
   
            
   frm = FrmGetActiveForm();
   fldIndex = FrmGetObjectIndex(frm, LookupLookupField);
   FrmSetFocus(frm, fldIndex);
   fldP = FrmGetObjectPtr (frm, fldIndex);

   
   if (event == NULL ||
      FldHandleEvent (fldP, event))
      {
      fldTextP = FldGetTextPtr(fldP);
      tableP = FrmGetObjectPtr (frm, FrmGetObjectIndex(frm, LookupTable));

		foundRecordPhone = 0;
      if (!AddrLookupLookupString(vars->dbP, fldTextP, vars->sortByCompany, 
         vars->params->field1, vars->params->field2, &foundRecord, &foundRecordPhone, 
         vars->lookupFieldMap, &completeMatch, &uniqueMatch))  //foundRecordPhone
         {
         // If the user deleted the lookup text remove the
         // highlight.
         TblUnhighlightSelection(tableP);
         }
      else
         {
         LookupViewSelectRecord(vars, foundRecord, foundRecordPhone);
         }
      
      
      if (!completeMatch)
         {
         // Delete the last character added.
         length = FldGetTextLength(fldP);
         FldDelete(fldP, length - 1, length);
         
         SndPlaySystemSound (sndError);
         }
         
      return true;
      }

   // Event not handled
   return false;
   
}


/***********************************************************************
 *
 * FUNCTION:    LookupClearLookupString
 *
 * DESCRIPTION: Clears the LookupLookupField.  Does not unhighlight the item.
 *
 * PARAMETERS:  nothing
 *                      
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupClearLookupString ()
{
   FormPtr frm;
   UInt fldIndex;
   FieldPtr fldP;
   Int length;


   frm = FrmGetActiveForm();
//   FrmSetFocus(frm, noFocus);
   fldIndex = FrmGetObjectIndex(frm, LookupLookupField);
   fldP = FrmGetObjectPtr (frm, fldIndex);

   length = FldGetTextLength(fldP);
   if (length > 0)
      FldDelete(fldP, 0, length);
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewInit
 *
 * DESCRIPTION: This routine initializes the "Lookup View" of the 
 *              Address application.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static void LookupViewInit (LookupVariablesPtr vars)
{
   Word row;
   Word rowsInTable;
   TablePtr table;
   RectangleType bounds;
   
   
   // Initialize the address list table.
   table = FrmGetObjectPtr (vars->frm, FrmGetObjectIndex (vars->frm, LookupTable));
   rowsInTable = TblGetNumberOfRows (table);
   for (row = 0; row < rowsInTable; row++)
      {      
      TblSetItemStyle (table, row, field1Column, customTableItem);
      TblSetRowUsable (table, row, false);
      }

   TblSetColumnUsable (table, 0, true);


   // Set the callback routine that will draw the records.
   TblSetCustomDrawProcedure (table, field1Column, LookupViewDrawRecord);


   // Load records into the address list.
   LookupLoadTable (vars);


   // Turn on the cursor in the lookup field.
//   FrmSetFocus(vars->frm, FrmGetObjectIndex (vars->frm, LookupLookupField));

   // Set the bounds of the title, so that the title will draw across the 
   // entire display.
   bounds.topLeft.x = 0;
   bounds.topLeft.y = 0;
   WinGetWindowExtent (&bounds.extent.x, &bounds.extent.y);
   FrmSetObjectBounds (vars->frm, 0, &bounds);
   
   // Respond to an empty lookup field.
   vars->ignoreEmptyLookupField = false;
}


/***********************************************************************
 *
 * FUNCTION:    LookupViewUseSelection
 *
 * DESCRIPTION: Use the record currently selected.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *
 * RETURNED:    true if a record was selected and false if not.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   11/11/96   Initial Revision
 *
 ***********************************************************************/
static Boolean LookupViewUseSelection (LookupVariablesPtr vars)
{
   TablePtr table;
   UInt row;
   UInt column;
   
   
   // If a row is selected return the record number else
   // return noRecord.
   table = FrmGetObjectPtr (vars->frm, FrmGetObjectIndex (vars->frm, LookupTable));
   if (TblGetSelection (table, &row, &column))
      {
      vars->currentRecord = TblGetRowID(table, row);
      vars->currentPhone = TblGetItemInt(table, row, column);
      return true;
      }
   
   return false;
}


/****************************************************************************
 *
 * DESCRIPTION: This is the event handler for the "Lookup View"
 *              of the Address Book application.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *
 * RETURNED:    true if a record was selected and false if not.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/8/96   Initial Revision
 *
 ***********************************************************************/
static Boolean LookupViewHandleEvent (LookupVariablesPtr vars)
{
   EventType event;
   Boolean handled;


   while (true)
      {
      EvtGetEvent (&event, evtWaitForever);
      
      // Cancel if something is going to switch apps.
      if (event.eType == keyDownEvent && 
      	event.data.keyDown.chr == findChr)
      	{
			EvtAddEventToQueue(&event);
			return false;
      	}
      	
      if (SysHandleEvent (&event))
         continue;
      
      
      handled = false;
      
      // Clear the lookup string because the user is selecting an item.
		if (event.eType == tblSelectEvent)
      	{
         // Doing the next call sends a fldChangedEvent which remove's the 
         // table's selection.  Set a flag to not handle the event.
         LookupClearLookupString ();
         vars->ignoreEmptyLookupField = true;
         
         handled = true;
         }
		
		
		else if (event.eType == ctlSelectEvent)
      	{
      	if (event.data.ctlSelect.controlID == LookupPasteButton)
      		return LookupViewUseSelection(vars);
      	
      	else if (event.data.ctlSelect.controlID == LookupCancelButton)
				return false;
			}
		
		
		else if (event.eType == ctlRepeatEvent)
      	{
      	if (event.data.ctlRepeat.controlID == LookupUpButton)
      		{
				LookupViewScroll (vars, up, false);
				LookupClearLookupString ();
				// leave unhandled so the buttons can repeat
				}
			
			else if (event.data.ctlRepeat.controlID == LookupDownButton)
				{
				LookupViewScroll (vars, down, false);
				LookupClearLookupString ();
				// leave unhandled so the buttons can repeat
				}
			}
		
		
		else if (event.eType == keyDownEvent)
      	{
			if (ChrIsHardKey(event.data.keyDown.chr))
				{
				// SysHandleEvent saw these keys and is now switching apps. 
				// Leave the Lookup function.
				return false;
				}
			
         switch (event.data.keyDown.chr)
         	{
            case pageUpChr:
               LookupViewScroll (vars, up, false);
               LookupClearLookupString ();
               handled = true;
               break;
               
            case pageDownChr:
               LookupViewScroll (vars, down, false);
               LookupClearLookupString ();
               handled = true;
               break;

            case linefeedChr:
               return LookupViewUseSelection(vars);


            default:
               handled = LookupViewLookupString(vars, &event);
               
               // If the field becomes empty, handle it.
               vars->ignoreEmptyLookupField = false;
               break;
         	}
        }
		
		
		else if (event.eType == fldChangedEvent)
      	{
			if (!(vars->ignoreEmptyLookupField &&
			   FldGetTextLength(FrmGetObjectPtr (vars->frm, 
			      FrmGetObjectIndex(vars->frm, LookupLookupField))) == 0))
			   {
			   LookupViewLookupString(vars, NULL);
			   }

			vars->ignoreEmptyLookupField = false;
			handled = true;
			}
		
		
		else if (event.eType == appStopEvent)
      	{
			EvtAddEventToQueue(&event);
			return false;
			}
		
		
      // Check if the form can handle the event
      if (!handled)
         FrmHandleEvent (vars->frm, &event);
      
   	}
}


/***********************************************************************
 *
 * FUNCTION:    LookupFindPhoneField
 *
 * DESCRIPTION: Find a phone field from the record.  The first match
 * is used unless it's one of the fields displayed.  In that case the
 * field displayed is used.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *                recordP - the record to find the field in
 *                lookupField - the phone field to lookup
 *                phoneNum - the phone field in the record that matches
 *                           (used when field 1 or field2 is a phone field).
 *
 * RETURNED:    The field to use or lookupNoField if none found 
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/18/96   Initial Revision
 *
 ***********************************************************************/
static AddressFields LookupFindPhoneField (LookupVariablesPtr vars, 
   AddrDBRecordPtr recordP, AddressLookupFields lookupField, 
   UInt phoneNum)
{
   int index;
   int phoneType;
   
   
   if (vars->params->field1 == lookupField || vars->params->field2 == lookupField)
      return (AddressFields) phoneNum;
   else
      {
      phoneType = lookupField - addrLookupWork;
      
      // Scan through the phone fields looking for a phone of the right type
      // which also contains data.
      for (index = firstPhoneField; index <= lastPhoneField; index++)
         {
         if (GetPhoneLabel(recordP, index) == phoneType &&
            recordP->fields[index] != NULL)
            {
            return (AddressFields) (phone1 + index - firstPhoneField);
            }
         }
         
      }
   
   return (AddressFields) addrLookupNoField;
}


/***********************************************************************
 *
 * FUNCTION:    LookupResizeResultString
 *
 * DESCRIPTION: Resize the lookup a result string
 *
 * PARAMETERS:  resultStringP - result string
 *              newSize       - new size
 *
 * RETURNED:    pointer to the resized result of zero if the resize failed.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Art   12/11/96   Initial Revision
 *
 ***********************************************************************/
static CharPtr LookupResizeResultString (VoidHand resultStringH, Word newSize)
{
   Err err;
   
   MemHandleUnlock (resultStringH);
   
   err = MemHandleResize (resultStringH, newSize);
   if (err)
      return (0);
      
   return (MemHandleLock (resultStringH));
}

/***********************************************************************
 *
 * FUNCTION:    LookupCreateResultString
 *
 * DESCRIPTION: Create a result string which includes data from the record.
 *
 * PARAMETERS:  vars - variables used by the lookup code.
 *                recordNum - the record create a result string from
 *                phoneNum - the phone field in the record that matches
 *                           (used when field 1 or field2 is a phone field).
 *
 * RETURNED:    The handle to the string created or NULL.
 *                vars->params->resultStringH is also set
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/9/96   Initial Revision
 *
 ***********************************************************************/
static Handle LookupCreateResultString (LookupVariablesPtr vars, 
   UInt recordNum, UInt phoneNum)
{
   CharPtr formatStringP;
   Handle resultStringH;
   CharPtr resultStringP;
   Int resultSize = 0;
   Int nextChunkSize;
   CharPtr nextFieldP;
   Int field;
   AddrDBRecordType record;
   Handle recordH;
   CharPtr fieldP;
   Err error;
   UInt separatorLength;
   UInt phoneLabel;
   
   
   // Return the record's unique ID
   DmRecordInfo(vars->dbP, recordNum, NULL, &vars->params->uniqueID, NULL);

   // Check if a format string was specified
   formatStringP = vars->params->formatStringP;
   if (formatStringP == NULL)
      return 0;
   
   // Allocate the string on the dynamic heap
   resultStringH = MemHandleNew(32);      // Allocate extra so there's room to grow
   if (!resultStringH)
      return 0;            // not enough memory?
   
   error = AddrGetRecord (vars->dbP, recordNum, &record, &recordH);
   ErrFatalDisplayIf ((error), "Record not found");

   resultStringP = MemHandleLock(resultStringH);
   while (*formatStringP != '\0')
      {
      // Copy the next chunk (the string until a '^' or '\0'
      nextFieldP = StrChr(formatStringP, '^');
      if (nextFieldP)
         nextChunkSize = nextFieldP - formatStringP;
      else
         nextChunkSize = StrLen(formatStringP);

      if (nextChunkSize > 0)
         {
         resultStringP = LookupResizeResultString (resultStringH, 
            resultSize + nextChunkSize);
         if (! resultStringP) goto exit;
         
         MemMove(resultStringP + resultSize, formatStringP, nextChunkSize);
         
         resultSize += nextChunkSize;
         formatStringP += nextChunkSize;
         nextChunkSize = 0;
         }
      
      // determine which field to copy next
      if (*formatStringP == '^')
         {
         formatStringP++;
         field = (AddressFields) addrLookupNoField;
         
         // Decode which field to copy next.

         // Remember that the strings below can't be put into a table 
         // because the lookup function runs without global variables 
         // available with which we would store the table.
         if (StrNCompare(formatStringP, "name", 4) == 0)
            {
            field = name;
            formatStringP += 4;
            }
         else if (StrNCompare(formatStringP, "first", 5) == 0)
            {
            field = firstName;
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "company", 7) == 0)
            {
            field = company;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "address", 7) == 0)
            {
            field = address;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "city", 4) == 0)
            {
            field = city;
            formatStringP += 4;
            }
         else if (StrNCompare(formatStringP, "state", 5) == 0)
            {
            field = state;
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "zipcode", 7) == 0)
            {
            field = zipCode;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "country", 7) == 0)
            {
            field = country;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "title", 5) == 0)
            {
            field = title;
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "custom1", 7) == 0)
            {
            field = custom1;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "custom2", 7) == 0)
            {
            field = custom2;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "custom3", 7) == 0)
            {
            field = custom3;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "custom4", 7) == 0)
            {
            field = custom4;
            formatStringP += 7;
            }
         else if (StrNCompare(formatStringP, "work", 4) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupWork, phoneNum);
            formatStringP += 4;
            }
         else if (StrNCompare(formatStringP, "home", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupHome, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "fax", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupFax, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "other", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupOther, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "email", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupEmail, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "main", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupMain, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "pager", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupPager, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "mobile", 5) == 0)
            {
            field = LookupFindPhoneField(vars, &record, addrLookupMobile, phoneNum);
            formatStringP += 5;
            }
         else if (StrNCompare(formatStringP, "listname", 8) == 0)
            {
            formatStringP += 8;
            separatorLength = 0;
            
            // Add the company name 
            if (vars->sortByCompany)
               {
               fieldP = record.fields[company];
               if (fieldP)
                  {
                  nextChunkSize = StrLen(fieldP);

                  if (nextChunkSize > 0)
                     {
                     resultStringP = LookupResizeResultString (resultStringH,
                        resultSize + nextChunkSize);
                     if (! resultStringP) goto exit;

                     MemMove(resultStringP + resultSize, fieldP, nextChunkSize);
                     
                     resultSize += nextChunkSize;
                     nextChunkSize = 0;
                     separatorLength = 2;
                     }
                  }
               }
            
            // Add the name field
            fieldP = record.fields[name];
            if (fieldP)
               {
               nextChunkSize = StrLen(fieldP);

               if (nextChunkSize > 0)
                  {
                  resultStringP = LookupResizeResultString (resultStringH, resultSize + nextChunkSize + separatorLength);
                  if (! resultStringP) goto exit;
                  if (separatorLength > 0)
                     {
                     MemMove(resultStringP + resultSize, ", ", separatorLength);
                     resultSize += separatorLength;
                     }
                  MemMove(resultStringP + resultSize, fieldP, nextChunkSize);
                  
                  resultSize += nextChunkSize;
                  nextChunkSize = 0;
                  separatorLength = 2;
                  }
               }
            
            // Add the first name field
            if (!vars->sortByCompany ||
               record.fields[company] == NULL)
               {
               fieldP = record.fields[firstName];
               if (fieldP)
                  {
                  nextChunkSize = StrLen(fieldP);

                  if (nextChunkSize > 0)
                     {
                     resultStringP = LookupResizeResultString (resultStringH, resultSize + nextChunkSize + separatorLength);
                     if (! resultStringP) goto exit;
                     if (separatorLength > 0)
                        {
                        MemMove(resultStringP + resultSize, ", ", separatorLength);
                        resultSize += separatorLength;
                        }
                     MemMove(resultStringP + resultSize, fieldP, nextChunkSize);
                     
                     resultSize += nextChunkSize;
                     nextChunkSize = 0;
                     }
                  }
               }
            
            // We are done adding the data requested.  Continue to the next
            // chunk
            continue;
            }
         else if (StrNCompare(formatStringP, "listphone", 9) == 0)
            {
            formatStringP += 9;
            separatorLength = 0;
            
            // Add the list phone number with a letter after it 
            fieldP = record.fields[firstPhoneField + 
               record.options.phones.displayPhoneForList];
            if (fieldP)
               {
               nextChunkSize = StrLen(fieldP);
               if (nextChunkSize > 0)
                  {
                  resultStringP = LookupResizeResultString (resultStringH, resultSize + nextChunkSize + 2);
                  if (! resultStringP) goto exit;

                  MemMove(resultStringP + resultSize, fieldP, nextChunkSize);
                  
                  resultSize += nextChunkSize;
                  
                  resultStringP[resultSize] = ' ';
                  phoneLabel = GetPhoneLabel(&record, firstPhoneField + 
                     record.options.phones.displayPhoneForList);
                  resultStringP[resultSize + 1] = vars->phoneLabelLetters[phoneLabel];
                  resultSize += 2;
                  
                  nextChunkSize = 0;
                  separatorLength = 2;
                  }
               }
            }
            

         
         // Now copy in the correct field.  lookupNoField can result from
         // asking for a phone which isn't used.
         if (field != (AddressFields) addrLookupNoField)
            {
            fieldP = record.fields[field];
            if (fieldP)
               {
               nextChunkSize = StrLen(fieldP);

               if (nextChunkSize > 0)
                  {
                  resultStringP = LookupResizeResultString (resultStringH, resultSize + nextChunkSize);
                  if (! resultStringP) goto exit;
                  MemMove(resultStringP + resultSize, fieldP, nextChunkSize);
                  
                  resultSize += nextChunkSize;
                  nextChunkSize = 0;
                  }
               }
            }
         
         }

      }
   
   // Now null terminate the result string
   resultStringP = LookupResizeResultString (resultStringH, resultSize + 1);
   if (! resultStringP) goto exit;

   resultStringP[resultSize] = '\0';

   vars->params->resultStringH = resultStringH;
   MemHandleUnlock(recordH);
   MemHandleUnlock(resultStringH);
   
   return resultStringH;   

   
exit:
   // Error return
   MemHandleUnlock(recordH);
   MemHandleFree (resultStringH);
   vars->params->resultStringH = 0;
   return (0);
}

/***********************************************************************
 *
 * FUNCTION:    Lookup
 *
 * DESCRIPTION: Present a list of records for the user to select and return
 * a string formatted to include information from the selected record.
 *
 * PARAMETERS:    params - address lookup launch command parameters
 *
 * RETURNED:    nothing
 *                The params will contain a string for the matching record.
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         Roger   7/1/96   Initial Revision
 *
 ***********************************************************************/
extern void Lookup (AddrLookupParamsType * params)
{
   Err err;
   DmOpenRef dbP;
   AddrAppInfoPtr appInfoPtr;
   UInt      cardNo=0;
   LocalID   dbID;
   DmSearchStateType   searchState;
   FormPtr frm;
   FormPtr originalForm;
   LookupVariablesType vars;
   Boolean uniqueMatch;
   Boolean completeMatch;
   UInt mode;


   // Check the parameters
   ErrFatalDisplayIf(params->field1 > addrLookupListPhone &&
      params->field1 != addrLookupNoField, "Bad Lookup request - field1");
   ErrFatalDisplayIf(params->field2 > addrLookupListPhone &&
      params->field2 != addrLookupNoField, "Bad Lookup request - field2");
   
   
   // Find the application's data file.
   err = DmGetNextDatabaseByTypeCreator (true, &searchState, addrDBType,
               sysFileCAddress, true, &cardNo, &dbID);
   if (err)
      {
      params->resultStringH = 0;
      return;
      }
   
   // Obey the secret records setting.  Also, we only need to 
   // read from the database.
   if (PrefGetPreference(prefHidePrivateRecords))
      mode = dmModeReadOnly;
   else
      mode = dmModeReadOnly | dmModeShowSecret;
   
   // Open the address database.
   dbP = DmOpenDatabase(cardNo, dbID, mode);
   if (! dbP) 
      {
      params->resultStringH = 0;
      params->uniqueID = 0;
      return;
      }
   
   // Initialize some of the lookup variables (those needed)
   vars.params = params;
   vars.dbP = dbP;


   // Find how the database is sorted.
   appInfoPtr = (AddrAppInfoPtr) AddrAppInfoGetPtr(dbP);
   vars.sortByCompany = appInfoPtr->misc.sortByCompany;
   InitPhoneLabelLetters(appInfoPtr, vars.phoneLabelLetters);
   MemPtrUnlock(appInfoPtr);
   
   // Set the mappings from AddressLookupFields to AddressFields.  It is
   // necessary to initialize the mappings at runtime because static
   // global variables are not available to this launch code routine.
   vars.lookupFieldMap[addrLookupName] = name;
   vars.lookupFieldMap[addrLookupFirstName] = firstName;
   vars.lookupFieldMap[addrLookupCompany] = company;
   vars.lookupFieldMap[addrLookupAddress] = address;
   vars.lookupFieldMap[addrLookupCity] = city;
   vars.lookupFieldMap[addrLookupState] = state;
   vars.lookupFieldMap[addrLookupZipCode] = zipCode;
   vars.lookupFieldMap[addrLookupCountry] = country;
   vars.lookupFieldMap[addrLookupTitle] = title;
   vars.lookupFieldMap[addrLookupCustom1] = custom1;
   vars.lookupFieldMap[addrLookupCustom2] = custom2;
   vars.lookupFieldMap[addrLookupCustom3] = custom3;
   vars.lookupFieldMap[addrLookupCustom4] = custom4;
   vars.lookupFieldMap[addrLookupNote] = note;
   
   // Check to see if the lookup string is sufficient for a unique match.
   // If so we skip presenting the user a lookup dialog and just use the match.
   AddrLookupLookupString(vars.dbP, params->lookupString, vars.sortByCompany, 
      vars.params->field1, vars.params->field2, &vars.currentRecord, &vars.currentPhone, 
      vars.lookupFieldMap, &completeMatch, &uniqueMatch);
   if (completeMatch && uniqueMatch)
      {
      LookupCreateResultString(&vars, vars.currentRecord, vars.currentPhone + firstPhoneField);
      goto Exit;
      }
   
   // If the user isn't allowed to select a record then return without
   // a match.
   if (!params->userShouldInteract)
      {
      params->resultStringH = 0;
      params->uniqueID = 0;
      goto Exit;
      }   
   
   
   // Initialize more of the lookup variables
   vars.currentRecord = noRecord;
   vars.currentPhone = 0;
   vars.topVisibleRecord = 0;
   vars.topVisibleRecordPhone = 0;
   vars.hideSecretRecords = PrefGetPreference(prefHidePrivateRecords);


   // Remember the original form   
   originalForm =  FrmGetActiveForm();
   
   // Initialize the dialog.
   frm = FrmInitForm (LookupView);
   vars.frm = frm;
   
   // Set the title
   if (params->title)
      FrmSetTitle(frm, params->title);
   
   // Set the paste button
   if (params->pasteButtonText)
      CtlSetLabel (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, LookupPasteButton)), 
         params->pasteButtonText);
   
   FrmSetActiveForm (frm);


   LookupViewInit (&vars);
   
   // Enter the lookup string
   if (params->lookupString && *params->lookupString != '\0')
      {
      FldInsert (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, LookupLookupField)), 
         params->lookupString, StrLen(params->lookupString));
      LookupViewLookupString(&vars, NULL);
      }


   FrmDrawForm (frm);

   FrmSetFocus (frm, FrmGetObjectIndex (frm, LookupLookupField));

   // Handle events until the user picks a record or cancels
   if (LookupViewHandleEvent (&vars))
      {
      LookupCreateResultString(&vars, vars.currentRecord, vars.currentPhone);
      }
   else
      {
      params->resultStringH = 0;
      params->uniqueID = 0;
      }
   
   
   FrmSetFocus (frm, noFocus);
   FrmEraseForm (frm);
   FrmDeleteForm (frm);
   FrmSetActiveForm (originalForm);

   
Exit:
   DmCloseDatabase (dbP);   
}


