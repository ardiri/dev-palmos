/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot
 * FILE:     ShellCmdUser.c
 * AUTHOR:	 Roger Flores: Feb 26, 1996
 *
 * DESCRIPTION:
 *	  This file is where customized console shell comands are kept.
 * Currently this is a stub which the emulator calls when it doesn't
 * recognize a command.  The code here shows how to add a custom command.
 * The custom command is useless, but it does provide a template to add commands.
 * An application programmer can copy this file to their application 
 * folder and then customize it to handle as many commands as they wish.
 *
 **********************************************************************/

#include <Pilot.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "ShellCmd.h"

#include "MemoDB.h"
#include "MemoRsc.h"
#include "MemoMain.h"

typedef void ShellCmdFuncType (int argc, CharPtr argv[]);
typedef ShellCmdFuncType * ShellCmdFuncPtr;
typedef struct {
	CharPtr				longName;
	CharPtr				shortName;
	ShellCmdFuncPtr	func;
} ShellCmdInfoType;



/***********************************************************************
 *
 * FUNCTION:    DoAppCommand
 *
 * DESCRIPTION: Execute a user defined command for the appliation. 
 *					 (It currently adds one to a number as an example)
 *
 *					 Syntax: UserCommand num
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was a ui command.
 *
 ***********************************************************************/
static void DoAppCommand (int argc, CharPtr argv[])
{
	int i;
	char text[256];
	Short num = 0;
	Boolean usageErr = false;

	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	if (argc < 2) usageErr = true;
	for (i=1; i<argc; i++)
		{
		if (isxdigit(argv[i][0]))
			sscanf(argv[i], "%d", &num);
		else
			usageErr = true;
		}

	if (usageErr) {
		goto SyntaxOnly;
		}

	// Perform the command here
	sprintf(text, "\n%d + 1 = %d\n", num, num + 1);
	ShlInsertText(text);

	return;


	// Dislay help and or syntax.
Help:
	ShlInsertText("\nExecute a user defined command. (adds one to a number)\n"
		"You can customize this in the ShellCmdApp.cp file\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s [number]\n", argv[0]);
	ShlInsertText(text);
	return;
}


//----------------------------------------------------------------------
// find an open memo database
//
// Parameters: none
//----------------------------------------------------------------------
static DmOpenRef FindOpenedMemoDatabase (void)
{
	DmOpenRef	dbP=0;
	LocalID		dbID;
	UInt			mode;
	UInt			cardNo;
	ULong			dbType;
	ULong			dbCreator;
	
	do {
		dbP = DmNextOpenDatabase(dbP);
		if (!dbP) break;

		Err err = DmOpenDatabaseInfo(dbP, &dbID, NULL, &mode, &cardNo, NULL);
		if (err) 
			{
			ShlInsertText("\n#ERROR getting info");
			}
		else
			{
			DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				&dbType, &dbCreator);

			if ( (dbType == memoDBType) && (dbCreator == sysFileCMemo) )
				return (dbP);
			}
		} while (1);

	return (0);
}


//----------------------------------------------------------------------
// Function to read a char from a disk file for importing.
//----------------------------------------------------------------------
static Word GetChar(const void * stream)
{
	return fgetc((FILE *) stream);
}



//----------------------------------------------------------------------
// Import from a text file.
//
// DoMemoImportMIME <access ptr> <file in>
//----------------------------------------------------------------------
static void DoMemoImportMIME(int argc, CharPtr argv[])
{
	Boolean		usageErr = false;
	DmOpenRef	dbP=0;
	char			fileInName[64] = "\0";
	char			text[128];
	int			i;
	DWord 		firstRecordImported = 0;


	// Parse the arguments passed.
	if ( argc > 1 && !strcmp(argv[1], "?") )
		goto Help;

	for (i=1; i<argc; i++) {
		if (i == 1)
			sscanf(argv[i], "%lx", &dbP);
		else
		if (!*fileInName)
			sscanf(argv[i], "%s", fileInName);
		else
			usageErr = true;
	
		}

	dbP = FindOpenedMemoDatabase();
	if (!dbP)
		usageErr = true;

	if (usageErr)
		goto SyntaxOnly;


	FILE*	fileIn=0;
	fileIn = fopen(fileInName, "rb");
	if (!fileIn) {
		sprintf(text, "\nUnknown input file: %s\n", fileInName);
		ShlInsertText(text);
		return;
		}
	
	
	// Keep importing records until it can't
	// DOLATER... MemoImportMime currently doesn't use the GetChar function, so this is pointless.
	while (MemoImportMime(dbP, fileIn, GetChar, false, false))
		{};
	
	fclose(fileIn);
	
	return;
	
	
	// Dislay help and or syntax.
Help:
	ShlInsertText("\nImport a text file, handle MIME encoding\n");
SyntaxOnly:
	sprintf(text, "\nSyntax: %s <cardno> <file>\n", argv[0]);
	ShlInsertText(text);
	return;
}


/***********************************************************************
 *
 * FUNCTION:    ShlDoAppCmd
 *
 * DESCRIPTION: This routine check if a command is a user defined shell 
 *					 command for the application.  If so is the command is executed.
 *
 * PARAMETERS:  argc - number of arguments
 *              argv - argument list
 *
 * RETURNED:    false if the command was handled.
 *
 ***********************************************************************/
int ShlDoAppCmd (int argc, CharPtr argv[])
{
	int i;
	ShellCmdInfoType cmd [] ={ 
		// Each command should have a customized line below	
		"UserComand", 		"uc",  	DoAppCommand,
		"MemoImportMIME", "im",  	DoMemoImportMIME,
		};
			
	for (i = 0; i < sizeof (cmd) / sizeof (ShellCmdInfoType); i++)
		{
		if ( (!ShlStrCmpi(argv[0], cmd[i].longName)) ||
			  (!ShlStrCmpi(argv[0], cmd[i].shortName)))
			{
			cmd[i].func (argc, argv);
			return 0;
			}
		}
	return 1;

}

