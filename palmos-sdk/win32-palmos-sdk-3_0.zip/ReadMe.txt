IMPORTANT:  Read Before Using The Accompanying Software


= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
P a l m   O S   S o f t w a r e   D e v e l o p m e n t   K i t
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 

The Palm OS Software Development Kit (SDK) is used to create applications that run on the
Palm Computing Platform. This includes the PalmPilot, the PalmIII, the WorkPad, and other
Palm Computing Platform devices.


= = = = = = = = = = = = 
N e w  F e a t u r e s
= = = = = = = = = = = =
 - Support for Palm OS 3.0 (used on the PalmIII)
 - More Sample Applications
 - Palm OS Emulator
 

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
I m p o r t a n t   T h i n g s   Y o u   S h o u l d   K n o w
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
- Application jumps greater than 32K bytes:  Though the 64K limit on code size still
exists with the new tools, it is now possible to jump more than 32K bytes within
the application.  When you change the <target> Settings:Code Generation:68K 
Processor:Code Model setting to 'Smart' model, code will be generated which
allows long jumps between source code modules (.c files).

- In the Macintosh simulator, the function keys F9-F12 simulate the four
application buttons of the device.

- Breaks left in your application will cause a fatal exception upon the reset of the 
Palm Computing Platform device. It is recommended that all breakpoints are removed
prior to the reset of your device.

- The SystemPreferencesTypeV10 comments in the Preferences.h file state
incorrectly that the sysSoundLevel and alarmSoundLevel sound preferences
provide indication of four discrete volume levels (High, Med, Low, Off). In
version  3.0 of Palm OS, these preferences indicate actual amplitude levels
that can be passed to Sound Manager functions. In previous versions of Palm
OS, these preference values indicated only whether sound should be off or
on, and provided no intermediate values.

------------------
RESOURCE FILES
------------------
- The Windows representation of a resource file is actually two files.  The first
file contains the 'data' fork, which is empty.  This file will have the normal file
name, <file>.rsrc, and usually be located in the Src directory of your project.  There
will also be a directory called Resource.frk in the same directory.  Resource.frk
will contain another file, also called <file>.rsrc, which contains the 'resource'
fork.  Every resource file will have a companion resource fork 
file in Resource.frk.  When copying or moving resource files, both segments must
be copied or moved together and the subdirectory relationship must be maintained.

----------------------------
STARTING A NEW APPLICATION
----------------------------
- In the Examples folder, there is a project called Starter.  This provides 
a project file, skeleton source code, and a folder hierarchy that is a convenient
framework in which to build your application.  It is a simpler alternative to using 
Phase 21 of the tutorial.
- If you would like to start with a more functional application, you can
start with any of the tutorial phases from 3 thru 21, strip out the 
unwanted functionality, and add your own.  Each of these phases will
run correctly on the device.  DO NOT USE PHASES 1 OR 2 AS YOUR 
APPLICATION TEMPLATE - THEY ARE TOO PRIMITIVE!!!

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
W h e r e   T o   G o   F o r   T e c h n i c a l   S u p p o r t
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
  Tools (IDE, Constructor, Debugger, Compilers, Linkers):
    support@metrowerks.com
  Palm OS/HotSync/PalmPilot/PalmIII: devsupp@palm.com

= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
P a l m   O S  2 . 0   v s .   3 . 0   C o m p a t i b i l i t y
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
- If you recompile your application with the new SDK, you may find some 
  compile and link errors if you use any of the API functions or enums that have 
  been changed (see documentation for a complete list).  When you encounter these
  errors, you have two choices:  You can either append a 'V20' to the end of
  the changed functions/enums to access the original versions of these functions (via
  the same system trap locations), or you can change the parameters according
  to the new documentation.  If you choose the second route, your application
  will not be compatable with 1.0 devices, and you will need to include the 
  system version check demonstrated in Expense.c of the expense application
  in your application.


  In the long term, it is preferable that you upgrade to the new conventions
  for the changed calls, as the 'V10' versions may be eliminated in future versions
  of the OS.


Palm Computing, Inc., a subsidiary of 3Com Corporation
1565 Charleston Road
Mountain View, California 94043
(650) 237-6000
