/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include <windows.h>
#pragma hdrstop

#include "PilotCPU.h"

#include "CPU_REG.h"
#include "Platform.h"			// EnableSounds


HANDLE	gCPUBeginEvent;			// Signal this to start the CPU loop
HANDLE	gCPUStoppedEvent;		// Gets signaled when CPU loop exits.
HANDLE	gCPUDelayEvent;			// Gets signaled to wake up Platform::Delay.

uaecptr	skipaddr = 0;

char	gMemFileName[_MAX_PATH];
char	gROMFileName[_MAX_PATH];


// ---------------------------------------------------------------------------
//		� CPU
// ---------------------------------------------------------------------------
// Thread procedure for the CPU thread.  The CPU thread just executes
// emulated 68K instructions.  The only time it ever stopes if an exception
// occurs (or when it's requested).  If either of these occurs, the CPU
// loop exits back to here.  CPU() signals the event by signalling the
// event -- the gCPUStoppedEvent event, that is.  Anyone waiting for the
// CPU thread to pause can look for or wait on this condition.  CPU() then
// blocks itself on gCPUBeginEvent, waiting for some external source to start
// it up again.

DWORD WINAPI CPU (void*)
{
	while (1)
	{
		WaitForSingleObject (gCPUBeginEvent, INFINITE);	// Wait for someone to start us.

		Emulator::Execute ();							// Run the CPU loop.

		SetEvent (gCPUStoppedEvent);						// Signal that we've stopped.
	}

	return 0;
}


// ---------------------------------------------------------------------------
//		� CPU_init
// ---------------------------------------------------------------------------
// Starts up all CPU-related stuff.  Loads the RAM and ROM files, hands them
// off ot the memory-initialization routines, and then starts up the CPU
// emulation thread.

int CPU_init (DWORD ramsize, const char* romfn)
{
	// First, try opening the given ROM file.

	strcpy (gROMFileName, romfn);

	FILE*	memFile = NULL;
	FILE*	romFile = fopen (gROMFileName, "rb");

	// If we can't do that, look for anything ending with common prefixes/suffixes.

	if (!romFile)
	{
		const char*	patterns[] = {
			"*.ROM",
			"* ROM",
			"ROM.*"
		};

		for (int ii = 0; ii < 4 && !romFile; ++ii)
		{
			WIN32_FIND_DATA	found;
			HANDLE			findHandle = FindFirstFile (patterns[ii], &found);
			if (findHandle != INVALID_HANDLE_VALUE)
			{
				do {
					if ((found.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
					{
						strcpy (gROMFileName, found.cFileName);
						romFile = fopen (found.cFileName, "rb");
					}
				} while (!romFile && FindNextFile (findHandle, &found));

				FindClose (findHandle);
			}
		}
	}

	// If we can't do that, blow out of here.

	if (!romFile)
	{
		return kError_CantFindROMFile;
	}

	// Next, try opening a RAM file.

	// Generate the name we want.

	// If the ROM file name is only a partial path, generate a full path.
	// That way, gMemFileName will also be a full path.  If we don't use
	// a full path, the RAM file will get saved to whatever directory is
	// current at the time it's saved, and not necessarily the same path
	// as the ROM file.

	if (0)
	{
		char	drive[_MAX_DRIVE];
		char	dir[_MAX_DIR];
		char	name[_MAX_FNAME];
		char	ext[_MAX_EXT];

		_splitpath (gROMFileName, drive, dir, name, ext);

		if (strlen (dir) == 0)
		{
			char	curDir[_MAX_PATH];
			GetCurrentDirectory (_MAX_PATH, curDir);
			strcat (curDir, gROMFileName);
			strcpy (gROMFileName, curDir);
		}
	}
	else
	{
		char	fullPath[_MAX_PATH];
		_fullpath (fullPath, gROMFileName, _MAX_PATH);
		strcpy (gROMFileName, fullPath);
	}

	strcpy (gMemFileName, gROMFileName);
	strcat (gMemFileName, ".");
	sprintf (gMemFileName + strlen (gMemFileName), "%ld", ramsize);
	strcat (gMemFileName, ".RAM");

	// Open the RAM file (if it exists; it's OK if it doesn't).

	memFile = fopen (gMemFileName, "rb");

	// Try initializing the emulator with all this information.

	Emulator::Initialize (memFile, romFile, ramsize);

	if (memFile)
	{
		fclose (memFile);
		memFile = NULL;
	}

	if (romFile)
	{
		fclose (romFile);
		romFile = NULL;
	}

	// Create the event objects.
	//
	// gCPUBeginEvent is used to block the CPU loop until we're ready to
	// run.  It gets unblocked in CPU_run, which gets called (among other
	// places) in DoDisplayThread just before we enter the event handling
	// loop.
	//
	// gCPUStoppedEvent gets signaled whenever the CPU loop exits.  It's
	// a manual-reset event, which let's us poll at any time to see if the
	// CPU loop has stopped or not.

					// attributes, auto-reset, non-signaled, name
	gCPUBeginEvent = CreateEvent(NULL, FALSE, FALSE, NULL);

					// attributes, manual-reset, signaled, name
	gCPUStoppedEvent = CreateEvent(NULL, TRUE, TRUE, NULL);

					// attributes, manual-reset, non-signaled, name
	gCPUDelayEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	// Run the emulator

	DWORD tid;	// attributes, stack size, func, parm, flags, id
	CloseHandle (CreateThread (NULL, 0, CPU, NULL, 0, &tid));

	return 0;
}


// ---------------------------------------------------------------------------
//		� CPU_reset
// ---------------------------------------------------------------------------

void CPU_reset (void)
{
	CPU_stop ();

	Emulator::Reset ();

	CPU_run ();
}


// ---------------------------------------------------------------------------
//		� CPU_run
// ---------------------------------------------------------------------------
// Start up the CPU thread.  If the thread is already running, do nothing.
// Otherwise, unsignal the event that flags when the CPU stops, and unblock
// the thread by signalling gCPUBeginEvent.

void CPU_run (void)
{
	// If the CPU is stopped, restart it by signalling the gCPUBeginEvent object.

	if (WaitForSingleObject (gCPUStoppedEvent, 0) == WAIT_OBJECT_0)
	{
		ResetEvent (gCPUStoppedEvent);	// Unsignal this guy
		SetEvent (gCPUBeginEvent);		// Unblock CPU()
	}
}


// ---------------------------------------------------------------------------
//		� CPU_stop
// ---------------------------------------------------------------------------
// Stop the CPU thread, returning whether or not the thread was running when
// this function was called (TRUE == it was running, FALSE == it was already
// stopped).  If the thread is running, this function asks it to stop, and
// then waits FOREVER for it to stop.

bool CPU_stop (void)
{
	// See if the CPU is running. If not, return false (saying that it
	// wasn't running).

	if (WaitForSingleObject (gCPUStoppedEvent, 0) == WAIT_OBJECT_0)
		return false;

	// Ask the CPU loop to exit.

	Emulator::SetBreakReason (kBreak_StopRequest);

	// If it was dozing, give it a nudge.

	SetEvent (gCPUDelayEvent);

	// Wait for the CPU thread to stop.

	WaitForSingleObject (gCPUStoppedEvent, INFINITE);

	ResetEvent (gCPUDelayEvent);

	return true;	// Say that we stopped it.
}


// ---------------------------------------------------------------------------
//		� CPU_wait
// ---------------------------------------------------------------------------
// Merely wait for the CPU thread to stop.  Wait for the specified amount
// of time.  If the thread stops in time, return TRUE, else FALSE.

bool CPU_wait (DWORD timeout)
{
	// Wait for the specified amount of time for the CPU thread to stop.
	// Return whether or not the attempt succeeded.

	return WaitForSingleObject (gCPUStoppedEvent, timeout) == WAIT_OBJECT_0;
}


// ---------------------------------------------------------------------------
//		� CPU_step
// ---------------------------------------------------------------------------

void CPU_step (void)
{
	// Step the CPU state by one instruction.

	if (WaitForSingleObject (gCPUStoppedEvent, 0) == WAIT_OBJECT_0)
	{
		ResetEvent (gCPUStoppedEvent);
		regs.spcflags |= SPCFLAG_BRK;
		SetEvent (gCPUBeginEvent);		// Unblock CPU()
	}
}


// ---------------------------------------------------------------------------
//		� CPU_skip
// ---------------------------------------------------------------------------

void CPU_skip (uaecptr addr)
{
	// Step the CPU by one instruction. If the instruction is a JSR,
	// keep executing until we come back to the instruction just after
	// the JSR.

	if (WaitForSingleObject (gCPUStoppedEvent, 0) == WAIT_OBJECT_0)
	{
		ResetEvent (gCPUStoppedEvent);
		skipaddr = addr;
		SetEvent (gCPUBeginEvent);		// Unblock CPU()
	}
}


// ---------------------------------------------------------------------------
//		� CPU_executeuntilatrap
// ---------------------------------------------------------------------------

bool CPU_executeuntilatrap (void)
{
	// Tell the CPU emulator to exit on the next "ATrap"

	bool	old = Emulator::SetBreakOnException (kException_Trap15, true);

	// Wait for it to do so (one second).

	bool	ok = CPU_wait (1000);

	// Restore the old setting.

	(void) Emulator::SetBreakOnException (kException_Trap15, old);

	return ok;
}


// ---------------------------------------------------------------------------
//		� CPU_pen
// ---------------------------------------------------------------------------

void CPU_pen (bool down, int x, int y)
{
	// Don't do anything if the CPU is already stopped.
	// It might, for example, be in the debugger.

	if (CPU_stop ())
	{
		Hardware::PenEvent (down, x, y);
		CPU_run ();
	}
}


// ---------------------------------------------------------------------------
//		� CPU_key
// ---------------------------------------------------------------------------

void CPU_key (bool down, int key)
{
	// Don't do anything if the CPU is already stopped.
	// It might, for example, be in the debugger.

	if (CPU_stop ())
	{
		Hardware::ButtonEvent (down, key);
		CPU_run ();
	}
}


// ---------------------------------------------------------------------------
//		� CPU_hotsync
// ---------------------------------------------------------------------------

void CPU_hotsync (bool down)
{
	// Don't do anything if the CPU is already stopped.
	// It might, for example, be in the debugger.

	if (CPU_stop ())
	{
		Hardware::HotSyncEvent (down);
		CPU_run ();
	}
}


// ---------------------------------------------------------------------------
//		� CPU_putkey
// ---------------------------------------------------------------------------

void CPU_putkey (BYTE key)
{
	// Don't do anything if the CPU is already stopped.
	// It might, for example, be in the debugger.

	if (CPU_stop ())
	{
		Hardware::KeyboardEvent (key);
		CPU_run ();
	}
}


// ---------------------------------------------------------------------------
//		� CPU_setsounds
// ---------------------------------------------------------------------------

void CPU_setsounds(bool enablesounds)
{
	EnableSounds = enablesounds;
}


// ---------------------------------------------------------------------------
//		� CPUStopper::CPUStopper
// ---------------------------------------------------------------------------

CPUStopper::CPUStopper (HWND parent, const char* msg)
{
	ok = CPU_executeuntilatrap();	// Stop the CPU on an ATrap instruction.

	if (!ok)
	{
		char	buffer[200];
		sprintf (buffer, "The emulator is not ready to %s at this time.\n"
						"(Perhaps it is turned off?)", msg);
		MessageBox(parent, buffer, "Palm OS Emulator", MB_OK);
	}
}


// ---------------------------------------------------------------------------
//		� CPUStopper::~CPUStopper
// ---------------------------------------------------------------------------

CPUStopper::~CPUStopper ()
{
	if (ok)
	{
		CPU_run ();
	}
}

