/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include <windows.h>
#pragma hdrstop

#include <windowsx.h>			// ComboBox_SetCurSel, etc.
#include <CommCtrl.h>			// InitCommonControls, PBM_SETRANGE, etc.

#include <malloc.h>				// _alloca
#include "PilotCPU.h"
#include "CPU_REG.h"
#include "Gremlins.h"			// Gremlins_New, etc.
#include "StringData.h"			// kErrorStrings
#include "LoadApplication.h"	// LoadApplication
#include "MMFMessaging.h"		// MMFIsDebuggerMessage
#include "Palm.h"				// SysPktBodyType
#include "DebugMgr.h"			// Debug::HandlePacket
#include "Platform.h"			// kError_TransferError

#include "Settings.h"

#include "resource.h"


struct DownloadData
{
	long		OK;					// Which button exited the dialog?
	long		port;				// port to use (0 = COM1, etc.)
	long		speed;				// Baud rate (0 = 57,600, etc.)
	const char*	defaultName;		// Save ROM to this file (NULL = ask for name)

	long		romRead;			// Amount of ROM transferred
	long		romSize;			// Total ROM size
	BYTE*		romImage;			// ROM image buffer
	DWORD		result;				// Result of transfer operation

	int			state;				// State of transfer (reading header, data, etc.)
	DWORD		header;				// Header signature
	short		romChecksum;		// ROM checksum
	BYTE*		readBuffer;			// Data from ReadFile is placed here for processing
	long		readBufferOffset;	// Amount of data in "readBuffer"

	bool		reopenSerialPort;	// Need to re-open the serial port for
									// "serial port emulation" for the ROM.

	HANDLE		downloadThread;		// Handle to thread doing the downloading
	HANDLE		quitEvent;			// Event to tell thread to quit
};

extern HINSTANCE	gInstance;


const char*	kClassName			= "PalmOSEmulatorDisplay";
const char*	kWindowName			= "Palm OS Emulator";

const DWORD	CM_RESET			= 1001;
const DWORD	CM_HOTSYNC			= 1002;
const DWORD	CM_LOADAPP			= 1003;
const DWORD	CM_DOWNLOADROM		= 1004;
const DWORD	CM_SCREENSHOT		= 1005;
const DWORD	CM_EXIT				= 1006;
const DWORD	CM_ABOUT			= 1007;
const DWORD	CM_PROPERTIES		= 1008;

const DWORD	CM_GREMLINNEW		= 1100;
const DWORD	CM_GREMLINSTEP		= 1101;
const DWORD	CM_GREMLINRESUME	= 1102;
const DWORD	CM_GREMLINSTOP		= 1103;

const DWORD	CM_PROFILESTART		= 1200;
const DWORD	CM_PROFILESTOP		= 1201;
const DWORD	CM_PROFILEDUMP		= 1202;
const DWORD	CM_PROFILETEST		= 1203;

const DWORD	CM_LOADAPPMRU		= 2000;

const int kPlasticWidth			= 221;
const int kPlasticHeight		= 337;
const int kPlasticBaseX			= 34;
const int kPlasticBaseY			= 33;

const POINT points[] =
{
	{  3,   0},
	{217,   0},
	{220,   3},
	{220, 310},
	{218, 313},
	{210, 316},
	{210, 333},
	{207, 336},
	{ 13, 336},
	{ 10, 333},
	{ 10, 314},
	{  2, 311},
	{  0, 308},
	{  0,   3}
};
const int NPOINTS = sizeof(points)/sizeof(POINT);


// Array used to convert the 2-bit Palm device screen to a 4-bit Windows bitmap.

const unsigned char stretch[16] =
{
	/* 00 00 -> 0000 0000 */	0x00,
	/* 00 01 -> 0000 0101 */	0x05,
	/* 00 10 -> 0000 1010 */	0x0A,
	/* 00 11 -> 0000 1111 */	0x0F,
	/* 01 00 -> 0101 0000 */	0x50,
	/* 01 01 -> 0101 0101 */	0x55,
	/* 01 10 -> 0101 1010 */	0x5A,
	/* 01 11 -> 0101 1111 */	0x5F,
	/* 10 00 -> 1010 0000 */	0xA0,
	/* 10 01 -> 1010 0101 */	0xA5,
	/* 10 10 -> 1010 1010 */	0xAA,
	/* 10 11 -> 1010 1111 */	0xAF,
	/* 11 00 -> 1111 0000 */	0xF0,
	/* 11 01 -> 1111 0101 */	0xF5,
	/* 11 10 -> 1111 1010 */	0xFA,
	/* 11 11 -> 1111 1111 */	0xFF
};


TSettings		gTempSettings;

OSVERSIONINFO	gOSVersionInfo;
HWND			gEmulatorWindow;
BITMAPINFO*		gPlasticBMI;
void*			gPlasticBits;
HBITMAP			gSilkscreen, gSilkscreen2;
HPALETTE		gPalette;
BOOL			gMoveDrag = FALSE;
RECT			gDragOrigRect;
POINT			gDragBase;
BOOL			gPenTracking = FALSE;
BOOL			gKeyTracking = FALSE;
int				gCurrentKey;
DWORD			gHotSyncDownStart = 0;

static long		gGremlinNumber = 0;
static long		gGremlinSteps = -1;
static int		gGremlinLogEvents = BST_UNCHECKED;
static int		gGremlinLogTraps = BST_UNCHECKED;
static int		gGremlinDisplayElapsedTime = BST_UNCHECKED;
static long		gGremlinNumApps;
static AppInfo*	gGremlinAppList;
static long		gGremlinSelecteditem;


//
// A C++ class for subclassing a window without any other framework:
//

class SubclassedWindow
{
	public:
								SubclassedWindow(HWND hwnd);
		virtual					~SubclassedWindow();

	protected:
		const HWND				Hwnd;
		WNDPROC					OldWndProc;

		static LRESULT CALLBACK	StaticWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
		virtual LRESULT			WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam) = 0;
};

SubclassedWindow::SubclassedWindow(HWND hwnd) :
	Hwnd(hwnd)
{
	OldWndProc = (WNDPROC) GetWindowLong (Hwnd, GWL_WNDPROC);
	SetWindowLong (Hwnd, GWL_WNDPROC, (long) StaticWndProc);
	SetWindowLong (Hwnd, GWL_USERDATA, (long) this);
}

SubclassedWindow::~SubclassedWindow()
{
	SetWindowLong (Hwnd, GWL_WNDPROC, (long) OldWndProc);
}

LRESULT CALLBACK SubclassedWindow::StaticWndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	SubclassedWindow*	This = reinterpret_cast<SubclassedWindow*>(
									GetWindowLong (hwnd, GWL_USERDATA));
	LRESULT				r = This->WndProc (hwnd, msg, wparam, lparam);

	if (msg == WM_NCDESTROY)		// last message this window will get
	{
		SetWindowLong (This->Hwnd, GWL_WNDPROC, (long) This->OldWndProc);
		delete This;
	}

	return r;
}


// This class implements the hyperlink functionality.  The idea is
// quite simple: Draw the static text in the appropriate color.  When the
// user clicks in the control window, call ShellExecute with appropriate
// parameters to launch the URL.  Change the color after a successful
// browser launch.  This code grabs the URL right out of the window text.
// ShellExecute will understand both http: and mailto: URLs.

class StaticHyperlink: public SubclassedWindow
{
	public:
								StaticHyperlink(HWND hwnd);
		virtual					~StaticHyperlink();

		HBRUSH					OnCtlColorStatic(HWND parent, HDC dc, HWND control, int type);
		void					OnLButtonDown(HWND hwnd, BOOL doubleclick, int x, int y, UINT flags);
		UINT					OnNcHitTest(HWND hwnd, int x, int y);
		BOOL					OnSetCursor(HWND hwnd, HWND hwndCursor, UINT codeHitTest, UINT msg);

	private:
		HFONT					font;
		HCURSOR					finger;
		COLORREF				color;

		virtual LRESULT			WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
};

StaticHyperlink::StaticHyperlink(HWND hwnd) :
	SubclassedWindow(hwnd)
{
	font = NULL;
	finger = LoadCursor (gInstance, MAKEINTRESOURCE(IDC_FINGER));
	color = RGB(0, 0, 255);
}

StaticHyperlink::~StaticHyperlink()
{
	if (font)
	{
		DeleteObject(font);
	}
}

HBRUSH StaticHyperlink::OnCtlColorStatic(HWND /*parent*/, HDC dc, HWND /*control*/, int /*type*/)
{
	HBRUSH	hbr = NULL;

	if ((GetWindowLong (Hwnd, GWL_STYLE) & 0xFF) <= SS_RIGHT)
	{
		if (font == NULL)
		{
			LOGFONT lf;

			GetObject ((HFONT) SendMessage (Hwnd, WM_GETFONT, 0, 0), sizeof (lf), &lf);

			lf.lfUnderline = TRUE;
			font = CreateFontIndirect (&lf);
		}

		SelectObject (dc, font);
		SetTextColor (dc, color);
		SetBkMode (dc, TRANSPARENT);
		hbr = (HBRUSH) GetStockObject (HOLLOW_BRUSH);
	}

	return hbr;
}

void StaticHyperlink::OnLButtonDown(HWND hwnd, BOOL doubleclick, int x, int y, UINT flags)
{
	// Get the URL.

	char	buf[256];
	GetWindowText (Hwnd, buf, sizeof(buf));

	// Strip off the leading and trailing elbow-brackets.

	size_t	len = strlen (buf);
	memcpy (buf, &buf[1], len - 2);
	buf[len - 2] = 0;

	HCURSOR	cur = GetCursor ();
	SetCursor (LoadCursor (NULL, IDC_WAIT));

	HINSTANCE	r = ShellExecute (NULL, "open", buf, NULL, NULL, SW_SHOWNORMAL);

	SetCursor (cur);

	if ((UINT) r > 32)
	{
		color = RGB (128, 0, 128);
		InvalidateRect (Hwnd, NULL, FALSE);
	}
}

UINT StaticHyperlink::OnNcHitTest(HWND hwnd, int x, int y)
{
	return HTCLIENT;
}

BOOL StaticHyperlink::OnSetCursor(HWND hwnd, HWND hwndCursor, UINT codeHitTest, UINT msg)
{
	SetCursor (finger);
	return TRUE;
}

LRESULT StaticHyperlink::WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch (msg)
	{
		case WM_CTLCOLORSTATIC:
			return HANDLE_WM_CTLCOLORSTATIC(hwnd, wparam, lparam, OnCtlColorStatic);

		case WM_LBUTTONDOWN:
			return HANDLE_WM_LBUTTONDOWN(hwnd, wparam, lparam, OnLButtonDown);

		case WM_NCHITTEST:
			return HANDLE_WM_NCHITTEST(hwnd, wparam, lparam, OnNcHitTest);

		case WM_SETCURSOR:
			return HANDLE_WM_SETCURSOR(hwnd, wparam, lparam, OnSetCursor);

		default:
			return CallWindowProc(OldWndProc, hwnd, msg, wparam, lparam);
	}

	return 0;
}

// ---------------------------------------------------------------------------
//		� CenterWindow
// ---------------------------------------------------------------------------

void CenterWindow (HWND hwnd)
{
	RECT	workArea;
	SystemParametersInfo (SPI_GETWORKAREA, NULL, &workArea, NULL);

	RECT	dRect;
	GetWindowRect (hwnd, &dRect);

	int xLeft = (workArea.left + workArea.right) / 2 - (dRect.right - dRect.left) / 2;
	int yTop = (workArea.top + workArea.bottom) / 2 - (dRect.bottom - dRect.top) / 2;

	SetWindowPos (hwnd, NULL, xLeft, yTop, -1, -1, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
}


// ---------------------------------------------------------------------------
//		� DoLoadApp
// ---------------------------------------------------------------------------

BOOL DoLoadApp (const char* fn)
{
	BOOL	result = false;

	CPUStopper	stopper (gEmulatorWindow, "load an application");
	if (stopper.Stopped ())
	{
		FILE*	file = fopen (fn, "rb");
		if (file)
		{
			result = LoadApplication (file);

			if (result)
			{
				MessageBox (gEmulatorWindow, "Application loaded successfully!",
							"Palm OS Emulator", MB_OK);
				Settings.UpdateMru (fn);
			}

			fclose (file);
		}
	}

	return result;
}


// ---------------------------------------------------------------------------
//		� LoadApp
// ---------------------------------------------------------------------------

void LoadApp (void)
{
	char fn[MAX_PATH];
	fn[0] = 0;

	OPENFILENAME ofn;
	ZeroMemory (&ofn, sizeof (ofn));

	ofn.lStructSize		= sizeof (ofn);
	ofn.hwndOwner		= gEmulatorWindow;
	ofn.lpstrFilter		= "Palm OS Applications (*.prc, *.pdb)\0*.prc;*.pdb\0"
							"All Files (*.*)\0*.*\0";
	ofn.lpstrFile		= fn;
	ofn.nMaxFile		= sizeof (fn);
	ofn.lpstrInitialDir	= Settings.PrcPath;
	ofn.Flags			= OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
	ofn.lpstrDefExt		= "prc";

	if (GetOpenFileName (&ofn))
	{
		DoLoadApp (fn);

		fn[ofn.nFileOffset] = 0;
		strcpy (Settings.PrcPath, fn);
	}
}


// ---------------------------------------------------------------------------
//		� SetColorRamp
// ---------------------------------------------------------------------------

void SetColorRamp (RGBQUAD colors[], int numColors, COLORREF foreground, COLORREF background)
{
	// Set up the color palette to ramp from the background color to
	// the foreground color.

	int	br = ((int) GetRValue (background));
	int	bg = ((int) GetGValue (background));
	int	bb = ((int) GetBValue (background));

	int	dr = ((int) GetRValue (foreground)) - ((int) GetRValue (background));
	int	dg = ((int) GetGValue (foreground)) - ((int) GetGValue (background));
	int	db = ((int) GetBValue (foreground)) - ((int) GetBValue (background));

	for (int color = 0; color < numColors; ++color)
	{
		colors[color].rgbRed		= (BYTE) (br + dr * color / (numColors - 1));
		colors[color].rgbGreen		= (BYTE) (bg + dg * color / (numColors - 1));
		colors[color].rgbBlue		= (BYTE) (bb + db * color / (numColors - 1));
		colors[color].rgbReserved	= 0;
	}
}


// ---------------------------------------------------------------------------
//		� MungeBitsForWindows
// ---------------------------------------------------------------------------

void*	gScreenImage;	// Points to the image the caller uses.
long	gScreenImageSize;

void MungeBitsForWindows (void*& addr, int& width, int& height, int& depth)
{
	long	screenCopySize = width * height * depth / 8;
	long	screenImageSize = screenCopySize;

	// Under Windows, we expand the 2-bit screen to 4-bits, so
	// the size of gScreenImage has to be twice as large.

	if (depth == 2)
		screenImageSize *= 2;

	// If the LCD buffer size has changed since we last looked at it,
	// dump the old buffer because we'll need a new one.

	int	screenChanged = screenImageSize != gScreenImageSize;

	if (screenChanged)
	{
		free (gScreenImage);
		gScreenImage = NULL;
	}

	// If we no longer have a buffer (or if we never had one), allocate one.

	if (gScreenImage == NULL)
	{
		gScreenImage = malloc (screenImageSize);
		gScreenImageSize = screenImageSize;
	}

	//	- the words have to be un-swapped.
	//	- a 2-bit image has to be converted to a 4-bit image

	uae_u16*	pWords = (uae_u16*) addr;
	uae_u8*		pBytes = (uae_u8*) gScreenImage;
	int			rowWords = width * depth / 16;

	if (depth == 2)
	{
		// In 2-bit mode, byte-swap and stretch at the same time.

		for (int y = 0; y < height; ++y)
		{
			for (int x = 0; x < rowWords; ++x)
			{
				uae_u16	theWord = *pWords++;

				*pBytes++ = stretch[(theWord >> 12) & 0x0F];
				*pBytes++ = stretch[(theWord >> 8) & 0x0F];
				*pBytes++ = stretch[(theWord >> 4) & 0x0F];
				*pBytes++ = stretch[(theWord >> 0) & 0x0F];
			}
		}
	}
	else	// This should be OK for 1, 4, 8, etc...
	{
		// In all other modes, just byte-swap.

		for (int y = 0; y < height; ++y)
		{
			for (int x = 0; x < rowWords; ++x)
			{
				uae_u16	theWord = *pWords++;

				*pBytes++ = (theWord >> 8) & 0x0FF;
				*pBytes++ = (theWord >> 0) & 0x0FF;
			}
		}
	}

	if (depth == 2)
		depth *= 2;

	addr = gScreenImage;
}


// ---------------------------------------------------------------------------
//		� ScreenShot
// ---------------------------------------------------------------------------

void ScreenShot (void)
{
	BOOL	wasRunning = CPU_stop ();

	char fn[MAX_PATH];
	fn[0] = 0;

	OPENFILENAME	ofn;
	ZeroMemory (&ofn, sizeof (ofn));

	ofn.lStructSize		= sizeof (ofn);
	ofn.hwndOwner		= gEmulatorWindow;
	ofn.lpstrFilter		= "Bitmap (*.bmp)\0*.bmp\0";
	ofn.lpstrFile		= fn;
	ofn.nMaxFile		= sizeof (fn);
	ofn.lpstrInitialDir	= Settings.PrcPath;
	ofn.Flags			= OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;
	ofn.lpstrDefExt		= "bmp";

	if (GetSaveFileName (&ofn))
	{
		HANDLE	file = CreateFile (ofn.lpstrFile, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS,
									FILE_ATTRIBUTE_NORMAL, NULL);

		if (file != INVALID_HANDLE_VALUE)
		{
			void*	bitmap;
			int		width, height, depth;

			Screen::GetBits (&bitmap, &width, &height, &depth);
			MungeBitsForWindows (bitmap, width, height, depth);

			long	numColors = 1 << depth;

			DWORD	fileHeaderSize		= sizeof (BITMAPFILEHEADER);
			DWORD	bitmapHeaderSize	= sizeof (BITMAPINFOHEADER);
			DWORD	colorTableSize		= numColors * sizeof (RGBQUAD);
			DWORD	bitmapSize			= width * height * depth / 8;
			DWORD	fileSize			= fileHeaderSize + bitmapHeaderSize + colorTableSize + bitmapSize;
			DWORD	bitmapOffset		= fileHeaderSize + bitmapHeaderSize + colorTableSize;

			BITMAPFILEHEADER	fileHeader;

			fileHeader.bfType		= 'MB';
			fileHeader.bfSize		= fileSize;
			fileHeader.bfReserved1	= 0;
			fileHeader.bfReserved2	= 0;
			fileHeader.bfOffBits	= bitmapOffset;

			BITMAPINFOHEADER	bitmapHeader;

			bitmapHeader.biSize				= sizeof (BITMAPINFOHEADER);
			bitmapHeader.biWidth			= width;
			bitmapHeader.biHeight			= height;
			bitmapHeader.biPlanes			= 1;
			bitmapHeader.biBitCount			= depth;
			bitmapHeader.biCompression		= BI_RGB;
			bitmapHeader.biSizeImage		= 0;
			bitmapHeader.biXPelsPerMeter	= 0;
			bitmapHeader.biYPelsPerMeter	= 0;
			bitmapHeader.biClrUsed			= 0;
			bitmapHeader.biClrImportant		= 0;

			RGBQUAD*	colors = (RGBQUAD*) _alloca (colorTableSize);
			SetColorRamp (colors, numColors, RGB (0, 0, 0), RGB (255, 255, 255));

			DWORD	written;

			WriteFile (file, &fileHeader, fileHeaderSize, &written, NULL);
			WriteFile (file, &bitmapHeader, bitmapHeaderSize, &written, NULL);
			WriteFile (file, colors, colorTableSize, &written, NULL);

			// What the...?  When I tried writing the negative of height to
			// indicate a top-down DIB, neither Paintbrush nor VC++ could
			// open the file!  So let's do it the hard way...

//			WriteFile (file, bitmap, bitmapSize, &written, NULL);

			long	rowBytes = width * depth / 8;
			for (int yy = height - 1; yy >= 0; --yy)
			{
				void*	src = ((char*) bitmap) + yy * rowBytes;
				WriteFile (file, src, rowBytes, &written, NULL);
			}

			CloseHandle (file);
		}
	}

	if (wasRunning)
		CPU_run ();
}


// ---------------------------------------------------------------------------
//		� ResetWindow
// ---------------------------------------------------------------------------

void ResetWindow()
{
	RECT wr, cr;

	if (Settings.Realistic)
	{
		SetWindowLong (gEmulatorWindow, GWL_STYLE, GetWindowLong (gEmulatorWindow, GWL_STYLE) & ~WS_CAPTION);
		GetWindowRect (gEmulatorWindow, &wr);
		GetClientRect (gEmulatorWindow, &cr);
		MoveWindow (gEmulatorWindow,
					wr.left, wr.top,
					kPlasticWidth * Settings.Scale + (wr.right - wr.left) - (cr.right - cr.left),
					kPlasticHeight * Settings.Scale + (wr.bottom - wr.top) - (cr.bottom - cr.top),
					TRUE);

		POINT p[NPOINTS];
		for (int i = 0; i < NPOINTS; i++)
		{
			p[i].x = points[i].x * Settings.Scale;
			p[i].y = points[i].y * Settings.Scale;
		}

		HRGN region = CreatePolygonRgn (p, NPOINTS, ALTERNATE);
		SetWindowRgn (gEmulatorWindow, region, TRUE);
	}
	else
	{
		SetWindowRgn (gEmulatorWindow, NULL, TRUE);
		SetWindowLong (gEmulatorWindow, GWL_STYLE, GetWindowLong (gEmulatorWindow, GWL_STYLE) | WS_CAPTION);
		GetWindowRect (gEmulatorWindow, &wr);
		GetClientRect (gEmulatorWindow, &cr);
		MoveWindow (gEmulatorWindow, wr.left, wr.top,
					160 * Settings.Scale + (wr.right - wr.left) - (cr.right - cr.left),
					(160 + 60) * Settings.Scale + (wr.bottom - wr.top) - (cr.bottom - cr.top),
					TRUE);
		// (Why is this here twice?)
		GetWindowRect (gEmulatorWindow, &wr);
		GetClientRect (gEmulatorWindow, &cr);
		MoveWindow (gEmulatorWindow, wr.left, wr.top,
					160 * Settings.Scale + (wr.right - wr.left) - (cr.right - cr.left),
					(160 + 60) * Settings.Scale + (wr.bottom - wr.top) - (cr.bottom - cr.top),
					TRUE);
	}

	SetTimer (gEmulatorWindow, 1, 1000 / Settings.FPS, NULL);
	InvalidateRect (gEmulatorWindow, NULL, FALSE);
}


// ---------------------------------------------------------------------------
//		� SaveRAMImage
// ---------------------------------------------------------------------------

extern char	gMemFileName[];

void SaveRAMImage (void)
{
	FILE*	memFile = fopen (gMemFileName, "wb");

	// Memory::Save will report an error and throw an exception if it
	// couldn't save the file.  However, it's too late to do anything
	// about it now, so just swallow the exception.  !!! TBD, revisit
	// this later so that developer can free up some space before
	// quitting.

	try
	{
		Memory::Save (memFile);
	}
	catch (...)
	{
	}
}


// ---------------------------------------------------------------------------
//		� SaveROMImage
// ---------------------------------------------------------------------------

void SaveROMImage (HWND hDlg, const void* romImage, long romSize, const char* name)
{
	OPENFILENAME	reply;
	char			fileName[_MAX_PATH];

	// See if there's a given name we should use.

	if (name)
	{
		strcpy (fileName, name);
	}

	// If not, ask the user for one.

	else
	{
		memset (&reply, 0, sizeof (reply));
		memset (&fileName, 0, sizeof (fileName));

		reply.lStructSize	= sizeof (OPENFILENAME);
		reply.hwndOwner		= hDlg;
		reply.lpstrFilter	= "Palm OS ROM files (*.ROM)\0*.ROM\0";
		reply.nFilterIndex	= 1;
		reply.lpstrFile		= fileName;
		reply.nMaxFile		= _MAX_PATH;
		reply.lpstrTitle	= "Save ROM image to:";
		reply.Flags			= OFN_OVERWRITEPROMPT;

		if (!GetSaveFileName (&reply))
		{
			DWORD error = GetLastError ();
			return;
		}
	}

	// Open the file and write the ROM image to it.

	FILE*	f = fopen (fileName, "wb");
	if (f)
	{
		fwrite (romImage, 1, romSize, f);
		fclose (f);

		// Let's also save this as the next default name.

		strcpy (Settings.RomFile, fileName);
	}
}


// ---------------------------------------------------------------------------
//		� SetDownloadError
// ---------------------------------------------------------------------------

void SetDownloadError (DownloadData* data, DWORD error)
{
	data->result = error;
}


// ---------------------------------------------------------------------------
//		� HandleDownloadedData
// ---------------------------------------------------------------------------

const long kBufferSize = 64 * 1024L;
enum { kState_ReadingHeader, kState_ReadingData = 10 };

void HandleDownloadedData (DownloadData* data)
{
	switch (data->state)
	{
		case kState_ReadingHeader:
		{
			// Scan the first 100 bytes for our signature.  They don't seem
			// to be guaranteed to be at the beginning; sometimes there's
			// leading garbage.

			if (data->readBufferOffset >= 100)
			{
				int ii;
				for (ii = 0; ii < 90; ++ii)
				{
					// (Note: this byte shifting depends on the array being composed
					// of unsigned chars.)

					data->header =		(((unsigned long) data->readBuffer[ii + 0]) << 24) |
										(((unsigned long) data->readBuffer[ii + 1]) << 16) |
										(((unsigned long) data->readBuffer[ii + 2]) <<  8) |
										(((unsigned long) data->readBuffer[ii + 3]));
					data->romSize =		(((unsigned long) data->readBuffer[ii + 4]) << 24) |
										(((unsigned long) data->readBuffer[ii + 5]) << 16) |
										(((unsigned long) data->readBuffer[ii + 6]) <<  8) |
										(((unsigned long) data->readBuffer[ii + 7]));
					data->romChecksum =	(((unsigned long) data->readBuffer[ii + 8]) <<  8) |
										(((unsigned long) data->readBuffer[ii + 9]));

					if (data->header == 0xDEADC0DE)
						break;
				}

				// Couldn't find it?

				if (ii >= 90)
				{
					SetDownloadError (data, kError_CantDownloadROM_BadBaudRate | (1 << 29));
					return;
				}

				// Create a buffer to hold the ROM image.

				data->romImage = (BYTE*) calloc (data->romSize, 1);

				// Copy any bytes after the 10 byte header into the ROM image buffer.

				data->romRead = data->readBufferOffset - (ii + 10);
				data->readBufferOffset = 0;
				memcpy (data->romImage, data->readBuffer + (ii + 10), data->romRead);

				// Change our state.

				data->state = kState_ReadingData;
			}
			break;
		}

		case kState_ReadingData:
		{
			memcpy (data->romImage + data->romRead, data->readBuffer, data->readBufferOffset);
			data->romRead += data->readBufferOffset;
			data->readBufferOffset = 0;
			break;
		}
	}
}


// ---------------------------------------------------------------------------
//		� DownloadThread
// ---------------------------------------------------------------------------

DWORD CALLBACK DownloadThread(void* param)
{
	DownloadData*	data = (DownloadData*) param;

	data->romRead			= 0;
	data->romSize			= 0;
	data->romImage			= NULL;
	data->result			= 0;

	data->state				= kState_ReadingHeader;
	data->header			= 0;
	data->romChecksum		= 0;
	data->readBuffer		= (BYTE*) calloc (kBufferSize, 1);
	data->readBufferOffset	= 0;

	data->reopenSerialPort	= Platform::CloseSerialPort ();

	DWORD		error;

	char	deviceName[10];
	sprintf (deviceName, "COM%d", data->port + 1);

	HANDLE	port = CreateFile (	deviceName,						// name
								GENERIC_READ | GENERIC_WRITE,	// access
								0,								// share mode
								NULL,							// security attributes
								OPEN_EXISTING,					// create action
								FILE_ATTRIBUTE_NORMAL,			// flags & attributes
								NULL);							// template handle

	if (port == INVALID_HANDLE_VALUE)
	{
		port = NULL;
		SetDownloadError (data, GetLastError ());
		if (data->result == ERROR_ACCESS_DENIED)
			SetDownloadError (data, kError_CantDownloadROM_SerialPortBusy | (1 << 29));
		goto Exit;
	}

	if (!SetCommMask (port, EV_ERR))
	{
		SetDownloadError (data, GetLastError ());
		goto Exit;
	}

	if (!SetupComm (port, 4096, 4096))
	{
		SetDownloadError (data, GetLastError ());
		goto Exit;
	}

	DCB	dcb;
	dcb.DCBlength = sizeof (DCB);
	if (!GetCommState (port, &dcb))
	{
		SetDownloadError (data, GetLastError ());
		goto Exit;
	}

	switch (data->speed)
	{
		case 0:		dcb.BaudRate = CBR_57600;	break;
		case 1:		dcb.BaudRate = CBR_38400;	break;
		case 2:		dcb.BaudRate = CBR_19200;	break;
		case 3:		dcb.BaudRate = CBR_14400;	break;
		case 4:		dcb.BaudRate = CBR_9600;	break;
		case 5:		dcb.BaudRate = CBR_4800;	break;
		case 6:		dcb.BaudRate = CBR_2400;	break;
		case 7:		dcb.BaudRate = CBR_1200;	break;
	}

	dcb.fBinary			= TRUE;
	dcb.ByteSize		= 8;
	dcb.Parity			= NOPARITY;
	dcb.fParity			= FALSE; 
	dcb.StopBits		= ONESTOPBIT;
	dcb.fOutX			= 0;
	dcb.fInX			= 0;
	dcb.fOutxDsrFlow	= FALSE;	
	dcb.fDtrControl		= DTR_CONTROL_ENABLE;

	if (dcb.BaudRate >= CBR_19200)
	{
		dcb.fOutxCtsFlow = TRUE;              
		dcb.fRtsControl  = RTS_CONTROL_HANDSHAKE;
	}
	else
	{
		dcb.fOutxCtsFlow = FALSE;
		dcb.fRtsControl  = RTS_CONTROL_ENABLE; 
	}

	COMMTIMEOUTS	cto;

	if (dcb.BaudRate <= CBR_2400)
	{
		cto.ReadIntervalTimeout			= 2 * 1000;  
		cto.ReadTotalTimeoutMultiplier	= 15;  
		cto.ReadTotalTimeoutConstant	= 500; 
		cto.WriteTotalTimeoutMultiplier	= 15;  
		cto.WriteTotalTimeoutConstant	= 500; 
	}
	else
	{
		cto.ReadIntervalTimeout			= 3 * 1000;
		cto.ReadTotalTimeoutMultiplier	= 25;
		cto.ReadTotalTimeoutConstant	= 2000;
		cto.WriteTotalTimeoutMultiplier	= 25;
		cto.WriteTotalTimeoutConstant	= 2000;
	}

	if (!SetCommTimeouts (port, &cto))
	{
		SetDownloadError (data, GetLastError ());
		goto Exit;
	}

	if (!SetCommState (port, &dcb))
	{
		SetDownloadError (data, GetLastError ());
		goto Exit;
	}

	// Loop for as long as we're not told to quit.

	while (WaitForSingleObject (data->quitEvent, 0) != WAIT_OBJECT_0)
	{
		// Call ClearCommError to see if there's data in the serial buffer.

		DWORD	errors;
		COMSTAT	stat;
		if (!ClearCommError (port, &errors, &stat))
		{
			SetDownloadError (data, GetLastError ());
			goto Exit;
		}

		// If there's data in the serial buffer, get it.

		if (stat.cbInQue > 0)
		{
			// Get the data in the serial buffer.

			DWORD	bytesRead;
			if (!ReadFile (port, data->readBuffer + data->readBufferOffset,
							stat.cbInQue, &bytesRead, NULL))
			{
				SetDownloadError (data, GetLastError ());
				goto Exit;
			}

			// Hand off the data to the function that processes it.

			data->readBufferOffset += bytesRead;
			HandleDownloadedData (data);

			// If there was an error in HandleDownloadedData, return.

			if (data->result)
			{
				break;
			}

			// If we've read all the data, return.

			if (data->romSize && data->romRead == data->romSize)
			{
				break;
			}
		}

		// There was no data.  Sleep for a little bit before we check again.

		else
		{
			Sleep (10);
		}
	}


Exit:

	// If there was an error, get rid of any partially accumulated ROM image.

	if (data->result)
	{
		free (data->romImage);
		data->romImage = NULL;
		data->romSize = 0;
	}

	// Get rid of our temporary intermediate buffer.

	free (data->readBuffer);

	// Close the serial port.

	CloseHandle (port);

	// If we closed the serial port being used for serial port emulation
	// of the ROM, re-open it.

	if (data->reopenSerialPort)
	{
		Platform::OpenSerialPort ();
	}

	return 0;
}


// ---------------------------------------------------------------------------
//		� DownloadROMProc1
// ---------------------------------------------------------------------------

BOOL CALLBACK DownloadROMProc1 (HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			SetWindowLong (hDlg, DWL_MSGRESULT, 0);
			CenterWindow (GetParent (hDlg));
			return TRUE;
		}

		case WM_NOTIFY:
		{
			switch (((PSHNOTIFY*) lParam)->hdr.code) 
			{
				case PSN_SETACTIVE:
					PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_NEXT);
					return TRUE;
			}
			break;
		}
	}

	return FALSE; 
}


// ---------------------------------------------------------------------------
//		� DownloadROMProc2
// ---------------------------------------------------------------------------

BOOL CALLBACK DownloadROMProc2 (HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			PROPSHEETPAGE*	page = (PROPSHEETPAGE*) lParam;
			DownloadData*	data = (DownloadData*) page->lParam;
			SetWindowLong (hDlg, DWL_USER, (LONG) data);

			HWND	port = GetDlgItem (hDlg, IDC_PORT);
			ComboBox_AddString (port, "COM1");
			ComboBox_AddString (port, "COM2");
			ComboBox_AddString (port, "COM3");
			ComboBox_AddString (port, "COM4");

			HWND	speed = GetDlgItem (hDlg, IDC_SPEED);
			ComboBox_AddString (speed, "57,600 bps");
			ComboBox_AddString (speed, "38,400 bps");
		//	ComboBox_AddString (speed, "28,800 bps");
			ComboBox_AddString (speed, "19,200 bps");
			ComboBox_AddString (speed, "14,400 bps");
			ComboBox_AddString (speed, "9,600 bps");
			ComboBox_AddString (speed, "4,800 bps");
			ComboBox_AddString (speed, "2,400 bps");
			ComboBox_AddString (speed, "1,200 bps");

			return TRUE;
		}

		case WM_NOTIFY:
		{
			switch (((PSHNOTIFY*) lParam)->hdr.code) 
			{
				case PSN_SETACTIVE:
				{
					PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK | PSWIZB_NEXT);

					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

					ComboBox_SetCurSel (GetDlgItem (hDlg, IDC_PORT), data->port);
					ComboBox_SetCurSel (GetDlgItem (hDlg, IDC_SPEED), data->speed);

					return TRUE;
				}

				case PSN_KILLACTIVE:
				{
					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

					data->port = ComboBox_GetCurSel (GetDlgItem (hDlg, IDC_PORT));
					data->speed = ComboBox_GetCurSel (GetDlgItem (hDlg, IDC_SPEED));

					return TRUE;
				}
			}
			break;
		}
	}

	return FALSE; 
}


// ---------------------------------------------------------------------------
//		� DownloadROMProc3
// ---------------------------------------------------------------------------

BOOL CALLBACK DownloadROMProc3 (HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	switch (message)
	{
		case WM_NOTIFY:
			switch (((PSHNOTIFY*) lParam)->hdr.code) 
			{
				case PSN_SETACTIVE:
					PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK | PSWIZB_NEXT);
					return TRUE;
			}
			break;
	}

	return FALSE; 
}


// ---------------------------------------------------------------------------
//		� DownloadROMProc6
// ---------------------------------------------------------------------------

BOOL CALLBACK DownloadROMProc6 (HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			PROPSHEETPAGE*	page = (PROPSHEETPAGE*) lParam;
			DownloadData*	data = (DownloadData*) page->lParam;
			SetWindowLong (hDlg, DWL_USER, (LONG) data);

			return TRUE;
		}

		case WM_NOTIFY:
		{
			switch (((PSHNOTIFY*) lParam)->hdr.code) 
			{
				case PSN_SETACTIVE:
				{
					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

					PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK);

					DWORD	tid;
					data->quitEvent = CreateEvent (NULL, TRUE, FALSE, NULL);
					data->downloadThread = CreateThread (NULL, 0, DownloadThread, (LPVOID) data, 0, &tid);

					SetTimer (hDlg, (UINT) hDlg, 100, NULL);
					return TRUE;
				}

				case PSN_KILLACTIVE:
				{
					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

					KillTimer (hDlg, (UINT) hDlg);

					SetEvent (data->quitEvent);
					WaitForSingleObject (data->downloadThread, 5 * 1000L);

					CloseHandle (data->quitEvent);
					CloseHandle (data->downloadThread);

					return TRUE;
				}
			}
			break;
		}

		case WM_TIMER:
		{
			DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

			if (data->result)
			{
				KillTimer (hDlg, (UINT) hDlg);

				PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK | PSWIZB_NEXT);
				PropSheet_PressButton (GetParent (hDlg), PSBTN_NEXT);

				break;
			}

			if (WaitForSingleObject (data->downloadThread, 0) == WAIT_OBJECT_0)
			{
				// The thread is signalled, which means that it's exited.

				KillTimer (hDlg, (UINT) hDlg);

				SaveROMImage (hDlg, data->romImage, data->romSize, data->defaultName);

				PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK | PSWIZB_NEXT);
				PropSheet_PressButton (GetParent (hDlg), PSBTN_NEXT);

				break;
			}

			if (data->romSize > 0)
			{
				SendDlgItemMessage (hDlg, IDC_PROGRESS, PBM_SETRANGE, 0, MAKELPARAM (0, data->romSize / 256));
				SendDlgItemMessage (hDlg, IDC_PROGRESS, PBM_SETPOS, data->romRead / 256, 0);
			}
		}
	}

	return FALSE; 
}


// ---------------------------------------------------------------------------
//		� DownloadROMProc7
// ---------------------------------------------------------------------------

BOOL CALLBACK DownloadROMProc7 (HWND hDlg, UINT message, UINT wParam, LONG lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
		{
			PROPSHEETPAGE*	page = (PROPSHEETPAGE*) lParam;
			DownloadData*	data = (DownloadData*) page->lParam;
			SetWindowLong (hDlg, DWL_USER, (LONG) data);

			return TRUE;
		}

		case WM_NOTIFY:
			switch (((PSHNOTIFY*) lParam)->hdr.code) 
			{
				case PSN_SETACTIVE:
				{
					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);

					PropSheet_SetWizButtons (GetParent (hDlg), PSWIZB_BACK | PSWIZB_FINISH);

					if (data->result)
					{
						if ((data->result & (1 << 29)) != 0)
							SetDlgItemText (hDlg, IDC_MESSAGE, kErrorStrings[data->result & ~(1 << 29)]);
						else
							SetDlgItemText (hDlg, IDC_MESSAGE, kErrorStrings[kError_CantDownloadROM_Generic]);
					}
					else
					{
						SetDlgItemText (hDlg, IDC_MESSAGE, "Done! The ROM image has been saved to the "
							"file \"Palm ROM\". Click on \"Finish\" to launch the emulator.");
					}

					return TRUE;
				}

				case PSN_WIZFINISH:
				{
					DownloadData*	data = (DownloadData*) GetWindowLong (hDlg, DWL_USER);
					data->OK = TRUE;
					return TRUE;
				}
			}
			break;
	}

	return FALSE; 
}


// ---------------------------------------------------------------------------
//		� DownloadROM
// ---------------------------------------------------------------------------

BOOL DownloadROM (HWND parent, const char* defaultName)
{
	PROPSHEETHEADER	psh;
	PROPSHEETPAGE	psp[7];
	DLGPROC			funcs[7] = {
		DownloadROMProc1,
		DownloadROMProc2,
		DownloadROMProc3,
		DownloadROMProc3,
		DownloadROMProc3,
		DownloadROMProc6,
		DownloadROMProc7
	};

	DownloadData	dlData;
	dlData.OK			= FALSE;
	dlData.port			= 0;
	dlData.speed		= 0;
	dlData.defaultName	= defaultName;

	memset (psp, 0, sizeof (psp));

	for (int ii = 0; ii < 7; ++ii)
	{
		psp[ii].dwSize		= sizeof (PROPSHEETPAGE);
		psp[ii].dwFlags		= 0;
		psp[ii].hInstance	= gInstance;
		psp[ii].pszTemplate	= MAKEINTRESOURCE (IDD_DOWNLOAD_WIZ1 + ii);
		psp[ii].pfnDlgProc	= funcs[ii];
		psp[ii].lParam		= (LPARAM) &dlData;
	}

	psh.dwSize		= sizeof (PROPSHEETHEADER);
	psh.dwFlags		= PSH_PROPSHEETPAGE | PSH_WIZARD | PSH_NOAPPLYNOW;
	psh.hwndParent	= parent;
	psh.hInstance	= gInstance;
	psh.pszIcon		= NULL;
	psh.pszCaption	= "Download ROM";
	psh.nPages		= sizeof (psp) / sizeof (PROPSHEETPAGE);
	psh.nStartPage	= 0;
	psh.ppsp		= (LPCPROPSHEETPAGE) &psp;
	psh.pfnCallback	= NULL;

	// launch the wizard

	PropertySheet (&psh);

	// Return TRUE if the user clicked on Finish and there was no error.

	return dlData.OK && (dlData.result == 0);
}


// ---------------------------------------------------------------------------
//		� PropertyProc
// ---------------------------------------------------------------------------

BOOL CALLBACK PropertyProc(HWND hwnd,
						   UINT msg,
						   WPARAM wparam,
						   LPARAM lparam)
{
	switch (msg)
	{
		case WM_COMMAND:
			switch (HIWORD (wparam))
			{
				case BN_CLICKED:
					if (LOWORD (wparam) == IDC_BROWSE_ROMFILE)
					{
						char fn[MAX_PATH];

						if (!GetDlgItemText (hwnd, IDC_ROMFILE, fn, sizeof (fn)))
						{
							fn[0] = 0;
						}

						OPENFILENAME ofn;
						ZeroMemory (&ofn, sizeof (ofn));

						ofn.lStructSize	= sizeof (ofn);
						ofn.hwndOwner	= hwnd;
						ofn.lpstrFilter	= "Palm OS ROM files (*.ROM)\0*.ROM\0"
											"All Files (*.*)\0*.*\0";
						ofn.lpstrFile	= fn;
						ofn.nMaxFile	= sizeof (fn);
						ofn.Flags		= OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY | OFN_NOCHANGEDIR;
						ofn.lpstrDefExt	= "rom";

						if (GetOpenFileName (&ofn))
						{
							SetDlgItemText (hwnd, IDC_ROMFILE, fn);
						}
						break;
					}
					// FALL THROUGH //

				case CBN_SELCHANGE:

					PropSheet_Changed (GetParent (hwnd), hwnd);
					break;
			}
			break;

		case WM_INITDIALOG:
		{
			CenterWindow (hwnd);

			SendDlgItemMessage (hwnd, IDC_ZOOM2X, BM_SETCHECK, Settings.Scale == 2, 0);
			SendDlgItemMessage (hwnd, IDC_REALISTIC, BM_SETCHECK, Settings.Realistic, 0);


			SendDlgItemMessage (hwnd, IDC_SOUNDS, BM_SETCHECK, Settings.Sounds, 0);
			SetDlgItemInt (hwnd, IDC_FPS, Settings.FPS, FALSE);
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "128 KB");
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "512 KB");
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "1024 KB (1 MB)");
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "2048 KB (2 MB)");
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "4096 KB (4 MB)");
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_ADDSTRING, 0, (LPARAM) "8192 KB (8 MB)");

			char buf[20];
			wsprintf (buf, "%d", Settings.RamSize);
			SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_SELECTSTRING, (WPARAM) - 1, (LPARAM)buf);
			SetDlgItemText (hwnd, IDC_ROMFILE, Settings.RomFile);
			SendDlgItemMessage (hwnd, IDC_PORT, CB_ADDSTRING, 0, (LPARAM)"None");

			for (int i = 1; i <= 4; i++)
			{
				char buf[10];
				wsprintf (buf, "COM%d", i);
				SendDlgItemMessage (hwnd, IDC_PORT, CB_ADDSTRING, 0, (LPARAM)buf);
			}

			SendDlgItemMessage (hwnd, IDC_PORT, CB_SELECTSTRING, (WPARAM) -1, (LPARAM) Settings.CommPort);
			gTempSettings = Settings;
			break;
		}

		case WM_NOTIFY:
			switch (((NMHDR*) lparam)->code)
			{
				case PSN_APPLY:
				{
					if (SendDlgItemMessage (hwnd, IDC_ZOOM2X, BM_GETCHECK, 0, 0) == BST_CHECKED)
					{
						Settings.Scale = 2;
					}
					else
					{
						Settings.Scale = 1;
					}

					Settings.Realistic = SendDlgItemMessage (hwnd, IDC_REALISTIC, BM_GETCHECK, 0, 0) == BST_CHECKED;
					Settings.Sounds = SendDlgItemMessage (hwnd, IDC_SOUNDS, BM_GETCHECK, 0, 0) == BST_CHECKED;
					CPU_setsounds (Settings.Sounds != 0);

					BOOL ok;
					int fps = GetDlgItemInt (hwnd, IDC_FPS, &ok, FALSE);
					if (ok && fps > 0)
					{
						Settings.FPS = fps;
					}

					char buf[MAX_PATH];
					SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_GETLBTEXT, SendDlgItemMessage (hwnd, IDC_RAMSIZE, CB_GETCURSEL, 0, 0), (LPARAM)buf);
					Settings.RamSize = atoi (buf);
					if (Settings.RamSize != gTempSettings.RamSize)
					{
						MessageBox (hwnd, "Changes to the RAM size will not take effect until you shut down and restart the Palm OS Emulator.", "Palm OS Emulator", MB_OK);
					}

					if (GetDlgItemText (hwnd, IDC_ROMFILE, buf, sizeof (buf)) > 0 &&
						(stricmp (Settings.RomFile, buf) != 0))
					{
						if (GetFileAttributes (buf) != 0xFFFFFFFF ||
							MessageBox (hwnd, "The ROM file name you selected does not exist. Use it anyway?", "Palm OS Emulator", MB_YESNO) == IDYES)
						{
							strcpy (Settings.RomFile, buf);
						}
					}

					if (stricmp (Settings.RomFile, gTempSettings.RomFile) != 0)
					{
						MessageBox (hwnd, "Changes to the ROM file will not take effect until you shut down and restart the Palm OS Emulator.", "Palm OS Emulator", MB_OK);
					}

					SendDlgItemMessage (hwnd, IDC_PORT, CB_GETLBTEXT, SendDlgItemMessage (hwnd, IDC_PORT, CB_GETCURSEL, 0, 0), (LPARAM)Settings.CommPort);
					if (stricmp (Settings.CommPort, gTempSettings.CommPort) != 0)
					{
						MessageBox (hwnd, "Changes to the communications port will not take effect until you shut down and restart the Palm OS Emulator.", "Palm OS Emulator", MB_OK);
					}

					ResetWindow ();
					Settings.Save (gEmulatorWindow);
					PropSheet_UnChanged (GetParent (hwnd), hwnd);
					gTempSettings = Settings;
					break;
				}

				case PSN_RESET:
					Settings = gTempSettings;
					ResetWindow ();
					Settings.Save (gEmulatorWindow);
					break;
			}
			break;

		default:
			return FALSE;
	}

	return TRUE;
}


// ---------------------------------------------------------------------------
//		� Properties
// ---------------------------------------------------------------------------

void Properties(HWND hwnd)
{
	PROPSHEETPAGE	psp[1];
	ZeroMemory(&psp, sizeof(psp));

	psp[0].dwSize		= sizeof (PROPSHEETPAGE);
	psp[0].dwFlags		= PSP_DEFAULT;
	psp[0].hInstance	= GetModuleHandle (NULL);
	psp[0].pszTemplate	= MAKEINTRESOURCE (IDD_PROPERTIES);
	psp[0].pfnDlgProc	= PropertyProc;

	PROPSHEETHEADER psh;
	ZeroMemory (&psh, sizeof (psh));

	psh.dwSize			= sizeof (psh);
	psh.dwFlags			= PSH_PROPSHEETPAGE | PSH_PROPTITLE;
	psh.hwndParent		= hwnd;
	psh.hInstance		= GetModuleHandle (NULL);
	psh.pszCaption		= "Palm OS Emulator";
	psh.nPages			= 1;
	psh.ppsp			= &psp[0];

	PropertySheet (&psh);
}


// ---------------------------------------------------------------------------
//		� AboutDlgProc
// ---------------------------------------------------------------------------

BOOL CALLBACK AboutDlgProc(HWND hwnd,
						   UINT msg,
						   WPARAM wparam,
						   LPARAM lparam)
{
	switch (msg)
	{
		case WM_COMMAND:
			switch (LOWORD (wparam))
			{
				case IDOK:
				case IDCANCEL:
					EndDialog (hwnd, LOWORD (wparam));
					break;
			}
			break;

		case WM_INITDIALOG:
		{
			CenterWindow (hwnd);
		//	SetDlgItemText (hwnd, IDC_ABOUT_DATE, "(" __DATE__ ")");

			// Hide the Cancel button and move the OK button over.

			HWND	cancelButton	= GetDlgItem (GetParent (hwnd), IDCANCEL);
			HWND	okButton		= GetDlgItem (GetParent (hwnd), IDOK);

			ShowWindow (cancelButton, SW_HIDE);

			RECT	cancelRect, okRect;
			GetWindowRect (cancelButton, &cancelRect);
			GetWindowRect (okButton, &okRect);

			long	shift = cancelRect.right - okRect.right;

			ScreenToClient (GetParent (hwnd), (POINT*) &okRect.left);
			ScreenToClient (GetParent (hwnd), (POINT*) &okRect.right);

			MoveWindow (okButton, okRect.left + shift, okRect.top,
						okRect.right - okRect.left, okRect.bottom - okRect.top, true);

			// Subclass the URLs so that they act like hyperlinks.

			new StaticHyperlink (GetDlgItem (hwnd, IDC_HTTP));
			new StaticHyperlink (GetDlgItem (hwnd, IDC_MAILTO));

			break;
		}

		case WM_CTLCOLORSTATIC:
		{
			// Reflect this one back down to the child.

			LONG		wnd = GetWindowLong ((HWND) lparam, GWL_USERDATA);
			if (wnd)
				return (BOOL) ::SendMessage ((HWND) lparam, msg, wparam, lparam);

			break;
		}

		default:
			return FALSE;
	}

	return TRUE;
}


// ---------------------------------------------------------------------------
//		� About
// ---------------------------------------------------------------------------

void About (HWND hwnd)
{
	PROPSHEETPAGE	psp[4];
	ZeroMemory (psp, sizeof (psp));

	psp[0].dwSize		= sizeof (PROPSHEETPAGE);
	psp[0].dwFlags		= PSP_DEFAULT;
	psp[0].hInstance	= GetModuleHandle (NULL);
	psp[0].pszTemplate	= MAKEINTRESOURCE (IDD_ABOUT_PALM);
	psp[0].pfnDlgProc	= AboutDlgProc;

	psp[1].dwSize		= sizeof (PROPSHEETPAGE);
	psp[1].dwFlags		= PSP_DEFAULT;
	psp[1].hInstance	= GetModuleHandle (NULL);
	psp[1].pszTemplate	= MAKEINTRESOURCE (IDD_ABOUT_WINDOWS);
	psp[1].pfnDlgProc	= AboutDlgProc;

	psp[2].dwSize		= sizeof (PROPSHEETPAGE);
	psp[2].dwFlags		= PSP_DEFAULT;
	psp[2].hInstance	= GetModuleHandle (NULL);
	psp[2].pszTemplate	= MAKEINTRESOURCE (IDD_ABOUT_MAC);
	psp[2].pfnDlgProc	= AboutDlgProc;

	psp[3].dwSize		= sizeof (PROPSHEETPAGE);
	psp[3].dwFlags		= PSP_DEFAULT;
	psp[3].hInstance	= GetModuleHandle (NULL);
	psp[3].pszTemplate	= MAKEINTRESOURCE (IDD_ABOUT_UAE);
	psp[3].pfnDlgProc	= AboutDlgProc;

	PROPSHEETHEADER psh;
	ZeroMemory (&psh, sizeof (psh));

	psh.dwSize			= sizeof (psh);
	psh.dwFlags			= PSH_PROPSHEETPAGE | PSH_NOAPPLYNOW;
	psh.hwndParent		= hwnd;
	psh.hInstance		= GetModuleHandle (NULL);
	psh.pszCaption		= "About Palm OS Emulator";
	psh.nPages			= 4;
	psh.ppsp			= psp;

	PropertySheet (&psh);
}


// ---------------------------------------------------------------------------
//		� ValidateNumber
// ---------------------------------------------------------------------------

int ValidateNumber(const char* text, long low, long high, const char* label, long* result)
{
	const char *nptr = text;
	int c;

	while ( isspace((int)(unsigned char)*nptr) )
		++nptr;

	c = (int)(unsigned char) *nptr++;
	int	sign = c;
	if (c == '-' || c == '+')
	{
		c = (int)(unsigned char) *nptr++;
	}

	*result = 0;

	while (isdigit(c))
	{
		*result = 10 * *result + (c - '0');
		c = (int)(unsigned char) *nptr++;
	}

	if (sign == '-')
	{
		*result *= -1;
	}

	if (*result < low || *result > high)
	{
		char	buffer[200];
		sprintf (buffer, "The value entered for %s must be in the range %ld to %ld.",
			label, low, high);
		MessageBox (NULL, buffer, "Error", MB_OK);
		
		return false;
	}

	if (nptr <= text + strlen (text))
	{
		char	buffer[200];
		sprintf (buffer, "A non-numeric character was entered for %s.", label);
		MessageBox (NULL, buffer, "Error", MB_OK);

		return false;
	}

	return true;
}


// ---------------------------------------------------------------------------
//		� NewGremlinProc
// ---------------------------------------------------------------------------

BOOL CALLBACK NewGremlinProc(HWND hwnd,
						   UINT msg,
						   WPARAM wparam,
						   LPARAM lparam)
{
	switch (msg)
	{
		case WM_COMMAND:
			switch (LOWORD (wparam))
			{
				case IDOK:
				case IDCANCEL:
				{
					if (LOWORD (wparam) == IDOK)
					{
						char text[256];

						GetDlgItemText (hwnd, IDC_GREMLIN_NUMBER, text, sizeof (text));
						if (!ValidateNumber (text, 0, 999, "Gremlin Number", &gGremlinNumber))
							break;

						GetDlgItemText (hwnd, IDC_GREMLIN_STEPS, text, sizeof (text));
						if (!ValidateNumber (text, -1, 0x7FFFFFFF, "Number of Steps", &gGremlinSteps))
							break;

						HWND	checkbox;
						int		checkState;

						checkbox = GetDlgItem (hwnd, IDC_LOG_EVENTS);
						gGremlinLogEvents = SendMessage (checkbox, BM_GETCHECK, 0, 0);

						checkbox = GetDlgItem (hwnd, IDC_LOG_TRAPS);
						gGremlinLogTraps = SendMessage (checkbox, BM_GETCHECK, 0, 0);

						checkbox = GetDlgItem (hwnd, IDC_DISPLAY_ELAPSED_TIME);
						gGremlinDisplayElapsedTime = SendMessage (checkbox, BM_GETCHECK, 0, 0);

						HWND	list = GetDlgItem (hwnd, IDC_APPLICATION_LIST);
						gGremlinSelecteditem = SendMessage (list, LB_GETCURSEL, 0, 0);

						Gremlins_LogEvents (gGremlinLogEvents == BST_CHECKED ? true : false);
						Gremlins_LogTraps (gGremlinLogTraps == BST_CHECKED ? true : false);
						Gremlins_DisplayElapsed (gGremlinDisplayElapsedTime == BST_CHECKED ? true : false);

						if (gGremlinSelecteditem == 0)
							Gremlins_AppToRun (NULL);
						else
							Gremlins_AppToRun (&gGremlinAppList[gGremlinSelecteditem - 1]);

						Gremlins_New (gGremlinNumber, gGremlinSteps);
					}

					EndDialog (hwnd, LOWORD (wparam));
					break;
				}
			}
			break;

		case WM_INITDIALOG:
		{
			CenterWindow (hwnd);

			SetDlgItemInt (hwnd, IDC_GREMLIN_NUMBER, gGremlinNumber, true);
			SetDlgItemInt (hwnd, IDC_GREMLIN_STEPS, gGremlinSteps, true);

			HWND	checkbox;

			checkbox = GetDlgItem (hwnd, IDC_LOG_EVENTS);
			Button_SetCheck (checkbox, gGremlinLogEvents);

			checkbox = GetDlgItem (hwnd, IDC_LOG_TRAPS);
			Button_SetCheck (checkbox, gGremlinLogTraps);

			checkbox = GetDlgItem (hwnd, IDC_DISPLAY_ELAPSED_TIME);
			Button_SetCheck (checkbox, gGremlinDisplayElapsedTime);

			HWND	list = GetDlgItem (hwnd, IDC_APPLICATION_LIST);
			SendMessage (list, LB_ADDSTRING, 0, (LPARAM) "Entire Palm OS device");

			for (int ii = 0; ii < gGremlinNumApps; ++ii)
			{
				SendMessage (list, LB_ADDSTRING, 0, (LPARAM) gGremlinAppList[ii].name);
			}

			SendMessage (list, LB_SETCURSEL, 0, 0);

			break;
		}

		default:
			return FALSE;
	}

	return TRUE;
}


// ---------------------------------------------------------------------------
//		� NewGremlin
// ---------------------------------------------------------------------------

void NewGremlin (HWND hwnd)
{
	Gremlins_GetApplicationNames (&gGremlinAppList, &gGremlinNumApps);

	DialogBox (GetModuleHandle (NULL), MAKEINTRESOURCE (IDD_NEWGREMLIN), hwnd, NewGremlinProc);

	free (gGremlinAppList);
	gGremlinAppList = NULL;
}


// ---------------------------------------------------------------------------
//		� PaintScreen
// ---------------------------------------------------------------------------

void PaintScreen(HDC dc,
				 BOOL always)
{
	int			lcdOn = Screen::LCDIsOn ();
	int			backlightOn = Screen::BacklightIsOn ();
	COLORREF	background = RGB(255, 255, 255);	// white
	COLORREF	foreground = RGB(0, 0, 0);			// black
	void*		theBits;
	int			width, height, depth;

	// Get the right background color.

	if (Settings.Realistic)
	{
		if (lcdOn && Screen::BacklightIsOn ())
		{
			background = RGB (100, 240, 220);	// Light green
		}
		else
		{
			background = RGB (84, 108, 85);		// Green
		}
	}

	// If the screen is not on, just paint the background color.

	if (!lcdOn)
	{
		RECT r =
		{
			kPlasticBaseX * Settings.Realistic * Settings.Scale,
			kPlasticBaseY * Settings.Realistic * Settings.Scale
		};
		r.right = r.left + 160 * Settings.Scale;
		r.bottom = r.top + 160 * Settings.Scale;

		SetBkColor (dc, PALETTEINDEX (GetNearestPaletteIndex (gPalette, background)));
		ExtTextOut (dc, 0, 0, ETO_OPAQUE, &r, NULL, 0, NULL);
	}

	// Otherwise, if the screen is on, get the bits. Screen_GetChange will return TRUE
	// if something significant has changed since the last time we called it.

	else if (Screen::GetBits (&theBits, &width, &height, &depth) || always)
	{
		MungeBitsForWindows (theBits, width, height, depth);

		// In the future, we may want to cache the DIB we create here.
		// For now, we just create it all the time.

		int	numColors = 1 << depth;

		// Fill in a BITMAPINFO structure accordingly.

		BITMAPINFO*	bmi = (BITMAPINFO*) _alloca (sizeof (BITMAPINFOHEADER) +
												numColors * sizeof (RGBQUAD));
		ZeroMemory (bmi, sizeof (BITMAPINFOHEADER));
		bmi->bmiHeader.biSize		= sizeof (BITMAPINFOHEADER);
		bmi->bmiHeader.biWidth		= width;
		bmi->bmiHeader.biHeight		= -height;
		bmi->bmiHeader.biPlanes		= 1;
		bmi->bmiHeader.biBitCount	= depth;

		SetColorRamp (bmi->bmiColors, numColors, foreground, background);

		// Create the DIB section.  The last two parameters to CreateDIBSection
		// are hSection and dwOffset; by setting them to NULL/0, we tell Windows
		// to allocate the memory for us.

		VOID*	bits;
		HBITMAP	bmp = CreateDIBSection (dc, bmi, DIB_RGB_COLORS, &bits, NULL, 0);

		if (!bmp || !bits)
		{
			// If we couldn't get that, just return.  I'm not sure why CreateDIBSection
			// would fail, but I've seen it happen.  It usually happens when another
			// copy of the emulator contacts this one in order to download the ROM.
			// Perhaps the intense serial port activity is getting in the way.
			// Whatever.  But subsequent attempts to call CreateDIBSection appear to
			// work.  GetLastError is returning zero.

			DWORD	error = GetLastError ();

			return;
		}

		// Copy our bits into it. They should already be in the right format
		// from the Screen_GetBits call.

		memcpy (bits, theBits, width * height * depth / 8);

		// Create a DC for blitting purposes.

		HDC		mdc = CreateCompatibleDC (NULL);
		HBITMAP	ob = (HBITMAP) SelectObject (mdc, bmp);

		// Do the blitting. The code below assumes a 160 x 160 screen.

		if (Settings.Scale == 1)
		{
			// Blit the image to the screen.

			BitBlt (dc,
					kPlasticBaseX * Settings.Realistic,
					kPlasticBaseY * Settings.Realistic,
					160, 160, mdc, 0, 0, SRCCOPY);
		}
		else if (gOSVersionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT)	// (Bug in NT? Besides, with the bug in DoDisplayThread, we'll never get into this section of code!)
		{
			// Create a temporary DC

			HDC tdc = CreateCompatibleDC (NULL);
			HBITMAP ob = (HBITMAP) SelectObject (tdc, CreateBitmap (160 * Settings.Scale,
																	160 * Settings.Scale,
																	1, 1, NULL));

			// Stretch our screen image into the temporary.

			StretchBlt (tdc, 0, 0,
						160 * Settings.Scale,
						160 * Settings.Scale,
						mdc, 0, 0, 160, 160, SRCCOPY);
			BitBlt (dc, 0, 0,				// !!! What's this BitBlt for? Seems like an extra...
					160 * Settings.Scale,
					160 * Settings.Scale,
					tdc, 0, 0, SRCCOPY);

			// Set the fore- and background colors so that we get the needed
			// "colorization" when transferring to the screen.

			SetBkColor (dc, background);
			SetTextColor (dc, foreground);

			// Blit the image to the screen.

			BitBlt (dc,
					kPlasticBaseX * Settings.Realistic * Settings.Scale,
					kPlasticBaseY * Settings.Realistic * Settings.Scale,
					160 * Settings.Scale,
					160 * Settings.Scale,
					tdc, 0, 0, SRCCOPY);

			// Get rid of the temporary DC.

			DeleteObject (SelectObject (tdc, ob));
			DeleteDC (tdc);
		}
		else
		{
			// Blit the image to the screen.

			StretchBlt (dc,
						kPlasticBaseX * Settings.Realistic * Settings.Scale,
						kPlasticBaseY * Settings.Realistic * Settings.Scale,
						160 * Settings.Scale,
						160 * Settings.Scale,
						mdc, 0, 0, 160, 160, SRCCOPY);
		}

		SelectObject (mdc, ob);
		DeleteDC (mdc);
		DeleteObject (bmp);
	}
}


// ---------------------------------------------------------------------------
//		� PenEvent
// ---------------------------------------------------------------------------

void PenEvent(HWND hwnd,
			  LPARAM lparam,
			  bool down)
{
	if (gMoveDrag)
	{
		POINT p;
		p.x = (short) LOWORD (lparam);
		p.y = (short) HIWORD (lparam);
		ClientToScreen (hwnd, &p);
		p.x += gDragOrigRect.left - gDragBase.x;
		p.y += gDragOrigRect.top - gDragBase.y;
		SetWindowPos (hwnd, NULL, p.x, p.y, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
		gMoveDrag = down;

		if (!gMoveDrag)
		{
			ReleaseCapture ();
		}

		return;
	}

	int x = LOWORD (lparam) / Settings.Scale - kPlasticBaseX * Settings.Realistic;
	int y = HIWORD (lparam) / Settings.Scale - kPlasticBaseY * Settings.Realistic;

	if (gPenTracking)
	{
		if (x < 0)
			x = 0;
		if (x >= 160)
			x = 160 - 1;
		if (y < 0)
			y = 0;
		if (y >= 160 + 60)
			y = 160 + 60 - 1;

		CPU_pen (down, x, y);
		gPenTracking = down;

		if (!gPenTracking)
		{
			ReleaseCapture ();
		}
	}
	else if (gKeyTracking)
	{
		gKeyTracking = down;
		if (!gKeyTracking)
		{
			ReleaseCapture ();
			CPU_key (0, gCurrentKey);
		}
	}
	else if (down)
	{
		if (x >= 0 && x < 160 && y >= 0 && y <= 160 + 60)
		{
			SetCapture (hwnd);
			CPU_pen (true, x, y);
			gPenTracking = TRUE;
		}
		else if (kPlasticBaseY + y >= 276 && kPlasticBaseY + y < 318)
		{
			x += kPlasticBaseX;
			y += kPlasticBaseY;
			gCurrentKey = kButton_None;
			if (x >= 0 && x < 17)
			{
				gCurrentKey = kButton_Power;
			}
			else if (x >= 25 && x < 53)
			{
				gCurrentKey = kButton_DateBook;
			}
			else if (x >= 64 && x < 92)
			{
				gCurrentKey = kButton_Phone;
			}
			else if (x >= 100 & x < 125)
			{
				if (y >= 280 && y < 292)
				{
					gCurrentKey = kButton_UpArrow;
				}
				else if (y >= 302 && y < 314)
				{
					gCurrentKey = kButton_DownArrow;
				}
			}
			else if (x >= 135 && x < 162)
			{
				gCurrentKey = kButton_ToDo;
			}
			else if (x >= 174 && x < 200)
			{
				gCurrentKey = kButton_Memo;
			}

			if (gCurrentKey >= 0)
			{
				SetCapture (hwnd);
				CPU_key (true, gCurrentKey);
				gKeyTracking = TRUE;
			}
		}
		else if (Settings.Realistic)
		{
			SetCapture (hwnd);
			GetWindowRect (hwnd, &gDragOrigRect);
			gDragBase.x = LOWORD (lparam);
			gDragBase.y = HIWORD (lparam);
			ClientToScreen (hwnd, &gDragBase);
			gMoveDrag = TRUE;
		}
	}
}


// ---------------------------------------------------------------------------
//		� PopupMenu
// ---------------------------------------------------------------------------

void PopupMenu(HWND hwnd,
			   int x,
			   int y)
{
	HMENU	apps		= CreatePopupMenu ();
	HMENU	gremlins	= CreatePopupMenu ();
	HMENU	menu		= CreatePopupMenu ();
#if HAS_PROFILING
	HMENU	profiling	= CreatePopupMenu ();
#endif

	for (int i = 0; i < TSettings::MRU_COUNT; i++)
	{
		if (Settings.PrcMru[i][0] == 0)
		{
			break;
		}

		char buf[MAX_PATH];
		wsprintf (buf, "&%d %s", i + 1, Settings.PrcMru[i]);
		AppendMenu (apps, MF_STRING, CM_LOADAPPMRU + i, buf);
	}

	if (i == 0)
	{
		AppendMenu (apps,	MF_STRING | MF_GRAYED,	0,			"(Empty)");
	}

	// ABCDEFGHIJKLMNOPQRSTUVWXYZ
	// x xx  xx   x  xx x     x		// Main menu
	//              x x xx			// Gremlins menu

	AppendMenu (apps,		MF_SEPARATOR,	0,					NULL);
	AppendMenu (apps,		MF_STRING,		CM_LOADAPP,			"&Other...");

	AppendMenu (gremlins,	MF_STRING,		CM_GREMLINNEW,		"&New...");
	AppendMenu (gremlins,	MF_SEPARATOR,	0,					NULL);
	AppendMenu (gremlins,	MF_STRING,		CM_GREMLINSTEP,		"&Step");
	AppendMenu (gremlins,	MF_STRING,		CM_GREMLINRESUME,	"&Resume");
	AppendMenu (gremlins,	MF_SEPARATOR,	0,					NULL);
	AppendMenu (gremlins,	MF_STRING,		CM_GREMLINSTOP,		"Sto&p");

	EnableMenuItem (gremlins,	CM_GREMLINNEW,		Gremlins_CanNew () ? MF_ENABLED : MF_GRAYED);
	EnableMenuItem (gremlins,	CM_GREMLINSTEP,		Gremlins_CanStep () ? MF_ENABLED : MF_GRAYED);
	EnableMenuItem (gremlins,	CM_GREMLINRESUME,	Gremlins_CanResume () ? MF_ENABLED : MF_GRAYED);
	EnableMenuItem (gremlins,	CM_GREMLINSTOP,		Gremlins_CanStop () ? MF_ENABLED : MF_GRAYED);

#if HAS_PROFILING
	AppendMenu (profiling,	MF_STRING,		CM_PROFILESTART,	"&Start");
	AppendMenu (profiling,	MF_STRING,		CM_PROFILESTOP,		"Sto&p");
	AppendMenu (profiling,	MF_STRING,		CM_PROFILEDUMP,		"&Dump");
	AppendMenu (profiling,	MF_STRING,		CM_PROFILETEST,		"&Test");
#endif

	AppendMenu (menu,		MF_STRING,		CM_RESET,			"&Reset");
	AppendMenu (menu,		MF_STRING,		CM_HOTSYNC,			"&HotSync");
	AppendMenu (menu,		MF_POPUP,		(UINT) apps,		"&Load app");
	AppendMenu (menu,		MF_POPUP,		(UINT) gremlins,	"&Gremlins");
#if HAS_PROFILING
	AppendMenu (menu,		MF_POPUP,		(UINT) profiling,	"Pr&ofiling");
#endif
	AppendMenu (menu,		MF_STRING,		CM_DOWNLOADROM,		"&Download ROM");
	AppendMenu (menu,		MF_STRING,		CM_SCREENSHOT,		"Save S&creen");
	AppendMenu (menu,		MF_STRING,		CM_EXIT,			"E&xit");
	AppendMenu (menu,		MF_STRING,		CM_ABOUT,			"&About Palm OS Emulator");
	AppendMenu (menu,		MF_SEPARATOR,	0,					NULL);
	AppendMenu (menu,		MF_STRING,		CM_PROPERTIES,		"&Properties");

	POINT	p = { x,  y };
	ClientToScreen (hwnd, &p);
	TrackPopupMenu (menu, TPM_LEFTALIGN | TPM_RIGHTBUTTON, p.x, p.y, 0, hwnd, NULL);
	DestroyMenu (menu);
}


// ---------------------------------------------------------------------------
//		� HandlePacket
// ---------------------------------------------------------------------------
// Handle a debugger packet from an external debugger.  There are three
// scenarios under which we could receive a message:
//
//	(a) The CPU thread encountered an exception and sent off a state packet
//		to the debugger.  In that case, the CPU thread may or may not have
//		halted itself by now.  If it hasn't, we want to wait for it to stop
//		before handling the packet.  If it has, we can go ahead and handle
//		the packet.  In both cases, after the packet has been handled, we
//		need to leave the CPU thread halted.
//
//	(b) The packet may be part of a sequence of packets we're dealing with
//		while already being in debug mode.  In that case, the CPU thread
//		should already be halted, and we can process the packet.  If the
//		packet is anything other than a sysContinueCmd packet, we need to
//		leave the CPU thread halted.  Otherwise, we want to start it up
//		again.
//
//	(c) The packet could be sent to us from out of the blue.  For instance,
//		the user could be trying to set or clear a breakpoint.  In that case,
//		we want to halt the CPU thread, handle the packet, and restart the
//		thread.
//
// We can stop the CPU thread with either CPU_stop or CPU_wait.  We'd use
// CPU_wait only if we were expecting the thread to stop on its own, so
// we use CPU_stop, which will ask the thread to stop and then wait for it
// to do so. It's OK if the thread was already coming to a halt (as in
// scenario (a)).
//
// When deciding to restart the thread, we just look at the result of
// Debug::InDebugger().  In case (a), it should be true, so we leave the
// thread halted.  In case (b), it will be true unless we exited debug
// mode with a sysContinueCmd packet.  In case (c), it should always be
// false, as we never entered debug mode.

void HandlePacket (const void* data, long size, LPARAM userData)
{
	CPU_stop ();

	SlkPktHeaderType&	header = *(SlkPktHeaderType*) data;
	SysPktBodyType&		body = *(SysPktBodyType*) ((&header) + 1);

	Debug::HandleNewPacket (header, body);

	BOOL	inDebugger = Debug::InDebugger ();

	if (!inDebugger)
	{
		CPU_run ();
	}
}


// ---------------------------------------------------------------------------
//		� DisplayWndProc
// ---------------------------------------------------------------------------

LRESULT CALLBACK DisplayWndProc(HWND hwnd,
								UINT msg,
								WPARAM wparam,
								LPARAM lparam)
{
	switch (msg)
	{
		case WM_CHAR:
			if (wparam == 13)
			{
				wparam = 10;
			}

			CPU_putkey (wparam);
			break;

		case WM_COMMAND:
			switch (wparam)
			{
				case CM_RESET:
					CPU_reset ();
					break;

				case CM_HOTSYNC:
					CPU_hotsync (true);
					gHotSyncDownStart = GetTickCount ();
					break;

				case CM_LOADAPP:
					LoadApp ();
					break;

				case CM_GREMLINNEW:
				{
					CPUStopper	stopper (gEmulatorWindow, "run a gremlin");

					if (stopper.Stopped ())
						NewGremlin (hwnd);

					break;
				}

				case CM_GREMLINSTEP:
				{
					CPUStopper	stopper (gEmulatorWindow, "single-step a gremlin");

					if (stopper.Stopped ())
						Gremlins_Step ();

					break;
				}

				case CM_GREMLINRESUME:
				{
					CPUStopper	stopper (gEmulatorWindow, "resume a gremlin");

					if (stopper.Stopped ())
						Gremlins_Resume ();

					break;
				}

				case CM_GREMLINSTOP:
				{
					CPUStopper	stopper (gEmulatorWindow, "stop a gremlin");

					if (stopper.Stopped ())
						Gremlins_Stop ();

					break;
				}

#if HAS_PROFILING
				case CM_PROFILESTART:
					ProfileInit (MAXFNCALLS, MAXDEPTH);
#if !PROFILE_ONE_FN
					ProfileStart ();
#endif
					break;

				case CM_PROFILESTOP:
					ProfileStop ();
					break;

				case CM_PROFILEDUMP:
					ProfileDump ();
					ProfileCleanup ();
					break;

				case CM_PROFILETEST:
					ProfileTest ();
					break;
#endif

				case CM_DOWNLOADROM:
					DownloadROM (hwnd, NULL);
					break;

				case CM_SCREENSHOT:
					ScreenShot ();
					break;

				case CM_EXIT:
					DestroyWindow (hwnd);
					break;

				case CM_ABOUT:
					About (hwnd);
					break;

				case CM_PROPERTIES:
					Properties (hwnd);
					break;

				default:
					if (wparam >= CM_LOADAPPMRU && wparam < CM_LOADAPPMRU + TSettings::MRU_COUNT)
					{
						char fn[MAX_PATH];
						strcpy (fn, Settings.PrcMru[wparam - CM_LOADAPPMRU]);
						if (fn[0])
						{
							DoLoadApp (fn);
						}
					}
					break;
			}
			break;

		case WM_CREATE:
			MMFOpenFiles (NULL, HandlePacket, (LPARAM) hwnd,
					kFromEmulatorFileName, kToEmulatorFileName);
			gEmulatorWindow = hwnd;
			ResetWindow ();
			break;

		case WM_DESTROY:
			CPU_stop ();
			SaveRAMImage ();
			Settings.Save (gEmulatorWindow);
			KillTimer (hwnd, 1);
			PostQuitMessage (0);
			break;

		case WM_KEYDOWN:
			switch (wparam)
			{
				case VK_ESCAPE:
					CPU_key (true, kButton_Power);
					break;

				case VK_PRIOR:
					CPU_key (true, kButton_UpArrow);
					break;

				case VK_NEXT:
					CPU_key (true, kButton_DownArrow);
					break;

				case VK_F1:
					CPU_key (true, kButton_DateBook);
					break;

				case VK_F2:
					CPU_key (true, kButton_Phone);
					break;

				case VK_F3:
					CPU_key (true, kButton_ToDo);
					break;

				case VK_F4:
					CPU_key (true, kButton_Memo);
					break;

				case VK_LEFT:
					CPU_putkey (0x1c);
					break;

				case VK_RIGHT:
					CPU_putkey (0x1d);
					break;
			}
			break;

		case WM_KEYUP:
			switch (wparam)
			{
				case VK_ESCAPE:
					CPU_key (false, kButton_Power);
					break;

				case VK_PRIOR:
					CPU_key (false, kButton_UpArrow);
					break;

				case VK_NEXT:
					CPU_key (false, kButton_DownArrow);
					break;

				case VK_F1:
					CPU_key (false, kButton_DateBook);
					break;

				case VK_F2:
					CPU_key (false, kButton_Phone);
					break;

				case VK_F3:
					CPU_key (false, kButton_ToDo);
					break;

				case VK_F4:
					CPU_key (false, kButton_Memo);
					break;
			}
			break;

		case WM_LBUTTONDOWN:
			PenEvent (hwnd, lparam, true);
			break;

		case WM_LBUTTONUP:
			PenEvent (hwnd, lparam, false);
			break;

		case WM_MOUSEMOVE:
			if (GetCapture ())
			{
				PenEvent (hwnd, lparam, TRUE);
			}
			break;

		case WM_PAINT:
		{
			PAINTSTRUCT	ps;
			HDC			dc = BeginPaint (hwnd, &ps);
			HPALETTE	op;

			if (Settings.Realistic)
			{
				op = SelectPalette (dc, gPalette, FALSE);
				RealizePalette (dc);
			}

			HDC		mdc = CreateCompatibleDC (NULL);
			HBITMAP	ob;
			if (Settings.Realistic)
			{
				StretchDIBits (	dc, 0, 0,
								kPlasticWidth * Settings.Scale,
								kPlasticHeight * Settings.Scale,
								0, 0, kPlasticWidth, kPlasticHeight,
								gPlasticBits, gPlasticBMI, DIB_RGB_COLORS, SRCCOPY);
			}
			else
			{
				if (Settings.Scale == 1)
				{
					ob = (HBITMAP) SelectObject (mdc, gSilkscreen);
					BitBlt (dc, 0, 160, 160, 60, mdc, 0, 0, SRCCOPY);
				}
				else
				{
					ob = (HBITMAP) SelectObject (mdc, gSilkscreen2);
					StretchBlt (dc, 0,
								160 * Settings.Scale,
								160 * Settings.Scale,
								60 * Settings.Scale,
								mdc, 0, 0, 320, 120, SRCCOPY);
				}
			}

			SelectObject (mdc, ob);
			DeleteDC (mdc);
			PaintScreen (dc, TRUE);

			if (Settings.Realistic)
			{
				SelectPalette (dc, op, TRUE);
			}

			EndPaint (hwnd, &ps);
			break;
		}

		case WM_PALETTECHANGED:
			if (HWND(wparam) == hwnd)
			{
				break;
			}
			/***** FALL THROUGH *****/

		case WM_QUERYNEWPALETTE:
		{
			if (Settings.Realistic)
			{
				HDC			dc = GetDC (hwnd);
				HPALETTE	op = SelectPalette (dc, gPalette, FALSE);
				int			n = RealizePalette (dc);

				SelectPalette (dc, op, TRUE);
				ReleaseDC (hwnd, dc);

				if (n > 0)
				{
					InvalidateRect (hwnd, NULL, FALSE);
				}

				return n;
			}

			break;
		}

		case WM_RBUTTONDOWN:

			// When the user clicks with the right mouse button, popup our menu.

			PopupMenu (hwnd, LOWORD (lparam), HIWORD (lparam));
			break;

		case WM_SYSKEYDOWN:
			switch (wparam)
			{
				// When the user presses F10, popup our menu.

				case VK_F10:
					PopupMenu (hwnd, 0, 0);
					break;
			}
			break;

		case WM_TIMER:
		{
			// Perform periodic tasks.

			HDC			dc = GetDC (hwnd);
			HPALETTE	oldPalette;

			// If we're in realistic mode, install our palette preparatory
			// to drawing.

			if (Settings.Realistic)
			{
				oldPalette = SelectPalette (dc, gPalette, FALSE);
				RealizePalette (dc);
			}

			// Update the LCD screen.

			PaintScreen (dc, FALSE);

			// Restore the old palette.

			if (Settings.Realistic)
			{
				SelectPalette (dc, oldPalette, TRUE);
			}

			ReleaseDC (hwnd, dc);

			// If we're emulating the user pressing the hotsync button, emulate
			// releasing the button after 1 second.

			if (gHotSyncDownStart && GetTickCount () - gHotSyncDownStart > 1000)
			{
				CPU_hotsync (false);
				gHotSyncDownStart = 0;
			}

			// Bump this guy so that periodic tasks can be handled in
			// Hardware::Cycle.

			gPseudoTickcount++;

			break;
		}

		default:
			return DefWindowProc (hwnd, msg, wparam, lparam);
	}

	return 0;
}


// ---------------------------------------------------------------------------
//		� DoDisplayThread
// ---------------------------------------------------------------------------
// Thread proc for the UI thread.

DWORD CALLBACK DoDisplayThread(void*)
{
	// !!! How's this call supposed to ever work? You're supposed to
	// fill out the dwOSVersionInfoSize field first!
	GetVersionEx (&gOSVersionInfo);

	InitCommonControls ();

	// Load all the graphics resources we'll ever need for this application.

	gSilkscreen = LoadBitmap (GetModuleHandle (NULL), MAKEINTRESOURCE (IDB_SILKSCREEN));
	gSilkscreen2 = LoadBitmap (GetModuleHandle (NULL), MAKEINTRESOURCE (IDB_SILKSCREEN2));

	gPlasticBMI = (BITMAPINFO*) LockResource (LoadResource (NULL, FindResource (NULL, MAKEINTRESOURCE(IDB_CASE), RT_BITMAP)));
	gPlasticBits = ((BYTE*) gPlasticBMI) + sizeof (BITMAPINFO) + 255 * sizeof (RGBQUAD);

	// Create the color palette for the plastics image.

	LOGPALETTE*	lp = (LOGPALETTE*) malloc (sizeof(LOGPALETTE) + 256 * sizeof (PALETTEENTRY));
	lp->palVersion = 0x300;
	lp->palNumEntries = 256;

	for (int i = 0; i < 256; i++)
	{
		lp->palPalEntry[i].peRed	= gPlasticBMI->bmiColors[i].rgbRed;
		lp->palPalEntry[i].peGreen	= gPlasticBMI->bmiColors[i].rgbGreen;
		lp->palPalEntry[i].peBlue	= gPlasticBMI->bmiColors[i].rgbBlue;
		lp->palPalEntry[i].peFlags	= 0;
	}

	gPalette = CreatePalette (lp);
	free(lp);

	// Initialize the flag used for emulating sounds based on our preference settings.

	CPU_setsounds (Settings.Sounds != 0);

	// Create the window class for the emulator window.

	WNDCLASS	wc;
	ZeroMemory (&wc, sizeof (wc));

	wc.style			= CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc		= DisplayWndProc;
	wc.hIcon			= LoadIcon (GetModuleHandle (NULL), MAKEINTRESOURCE (IDI_EMULATOR));
	wc.hCursor			= LoadCursor (NULL, IDC_ARROW);
	wc.lpszClassName	= kClassName;

	RegisterClass (&wc);

	// Create the emulator window and show it.

	gEmulatorWindow = CreateWindow (	kClassName,
									kWindowName,
									WS_CAPTION | WS_MINIMIZEBOX | WS_OVERLAPPED,
									Settings.Window.x, Settings.Window.y,
									CW_USEDEFAULT, CW_USEDEFAULT,
									NULL, NULL, 0, NULL);
	ShowWindow (gEmulatorWindow, SW_SHOW);

	// Kickstart the CPU emulator (running in it's own thread).

	CPU_run ();

	// Our main event loop.  Retrieve and handle events until the application quits.

	MSG	msg;
	while (GetMessage (&msg, NULL, 0, 0))
	{
		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	// Release our resources before quitting.

	DeleteObject (gSilkscreen);
	DeleteObject (gSilkscreen2);
	DeleteObject (gPalette);

	// Exit the thread.

	return 0;
}


// ---------------------------------------------------------------------------
//		� StartLCD
// ---------------------------------------------------------------------------
// Return the handle to the UI thread, creating it if necessary.

HANDLE DisplayThread = NULL;

HANDLE StartLCD()
{
	if (!DisplayThread)
	{
		DWORD tid;
		DisplayThread = CreateThread (NULL, 0, DoDisplayThread, 0, 0, &tid);
	}

	return DisplayThread;
}

