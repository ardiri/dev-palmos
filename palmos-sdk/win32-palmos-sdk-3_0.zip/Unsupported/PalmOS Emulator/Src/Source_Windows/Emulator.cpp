/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include <windows.h>
#pragma hdrstop

#include "LCD.h"
#include "PilotCPU.h"
#include "Settings.h"
#include "Platform.h"

#include "resource.h"

HINSTANCE	gInstance;


extern void CenterWindow (HWND);
extern BOOL DownloadROM (HWND parent, const char* defaultName);

// ---------------------------------------------------------------------------
//		� BrowserForROM
// ---------------------------------------------------------------------------

BOOL BrowserForROM (char* fileName)
{
	OPENFILENAME	reply;

	static const char	filters[] =
	{
		"Palm OS ROM files (*.ROM)\0"	"*.ROM\0"
		"All files (*.*)\0"				"*.*\0"
		"\0"
	};

	memset(&reply, 0, sizeof(reply));

	reply.lStructSize       = sizeof(OPENFILENAME);
	reply.hwndOwner         = NULL;
	reply.lpstrFilter       = filters;
	reply.nFilterIndex      = 1;
	reply.lpstrFile         = fileName;
	reply.nMaxFile          = _MAX_PATH;

	fileName[0] = 0;

	return GetOpenFileName(&reply);
}


// ---------------------------------------------------------------------------
//		� QueryDlgProc
// ---------------------------------------------------------------------------

BOOL CALLBACK QueryDlgProc(HWND hwnd,
						   UINT msg,
						   WPARAM wparam,
						   LPARAM lparam)
{
	switch (msg)
	{
		case WM_INITDIALOG:
		{
			CenterWindow (hwnd);
			break;
		}

		case WM_COMMAND:
		{
			switch (LOWORD(wparam))
			{
				case IDC_DOWNLOAD:
				case IDC_BROWSE:
				case IDC_EXIT:
					EndDialog(hwnd, LOWORD(wparam));
					break;
			}
			break;
		}

		default:
			return FALSE;
	}

	return TRUE;
}


// ---------------------------------------------------------------------------
//		� WinMain
// ---------------------------------------------------------------------------

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int)
{
	try
	{
		gInstance = instance;

		// When run under the VC++ debugger, the default directory appears
		// to be set to S:\emulator\windows\source, instead of the expected
		// \Debug or \Release sub-directories. Jam the current directory
		// to the app directory so that we can find our files.

		{
			char	path[_MAX_PATH], drive[_MAX_DRIVE], dir[_MAX_DIR];

			GetModuleFileName (/* module = */ NULL, path, _MAX_PATH);
			_splitpath (path, drive, dir, NULL, NULL);
			_makepath (path, drive, dir, NULL, NULL);
			SetCurrentDirectory (path);
		}

		// Initialize the CPU emulator, giving it the comm handle for serial
		// communications, the amount of RAM to emulate, and the name of the
		// ROM file to use.  The result of this initialization will be a new
		// thread that just fetches opcodes and executes them.  The thread is
		// initially blocked; it becomes unblocked in DoDisplayThread.

		// If the Caps Lock key is down, force the display of the "What now?" dialog.

		int r;
		
		if (GetKeyState (VK_CAPITAL) != 0)
			r = kError_CantFindROMFile;
		else
			r = CPU_init (Settings.RamSize, Settings.RomFile);

		// If we couldn't find a ROM file, offer to get one.

		if (r == kError_CantFindROMFile)
		{
			// Ask what the user wants to do now.

			int	choice = DialogBox (instance, MAKEINTRESOURCE (IDD_QUERY_DOWNLOAD), NULL, QueryDlgProc);

			// He wants to download a ROM from a device.

			if (choice == IDC_DOWNLOAD)
			{
				if (!DownloadROM (NULL, "Palm.ROM"))
				{
					// There was an error when the user pressed Finish,
					// or the user pressed Cancel.

					return 0;
				}
			}

			// He wants to find one on the disk.

			else if (choice == IDC_BROWSE)
			{
				char	fileName [_MAX_PATH];
				if (!BrowserForROM (fileName))
				{
					return 0;
				}

				// Let's save this as the next default name.

				strcpy (Settings.RomFile, fileName);
			}

			// He wants to quit.

			else
			{
				return 0;
			}

			// Try again to load the ROM image.

			r = CPU_init (Settings.RamSize, Settings.RomFile);
		}

		// If there was an error, report it and quit.

		if (r != 0)
		{
			Platform::ReportError (r);
			return 0;
		}

		// Start up the UI thread. This thread responds to user events and
		// periodically updates the LCD display.  WaitForSingleObject will block
		// the current thread until the LCD thread object is signalled (which
		// occurs when the thread is terminated).

		WaitForSingleObject (StartLCD (), INFINITE);
	}

	catch (...)
	{
	}

	return 0;
}
