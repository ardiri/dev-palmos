/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include <Windows.h>
#pragma hdrstop

#include "MMFMessaging.h"

#include <assert.h>

/*
	This file implements two-way messaging between two applications.
	The two applications can send up to 4K of data to each other.

	The data interchange is accomplished by the means of two memory-
	mapped files. When this module is initialized by calling
	MMFOpenFiles, it first looks for the existance of already-created
	memory-mapped files.  If it doesn't find them, it creates them.

	MMFOpenFiles also opens a hidden window for the purpose of receiving
	messages, and creates a unique message ID that is sent as the "you've
	got data" message.

	Once the module is initialized, data can be sent to the other end
	by calling MMFSendData.  The given data is written to the "outgoing"
	memory-mapped file, and a message is sent to the other application.
	The hidden window of the other application gets the message, and
	respondes to it by calling a user-defined callback function. The
	callback function is given a pointer to the data, the length of the
	data, and a user-defined callback value.  The callback is then free
	to do whatever it wants with the data, including sending back a response.

	When the application is done sending all messages, it closes down its
	end of the session by calling MMFCloseFiles.  This can usually be done
	when the application quits.
*/

// Data structure overlaid on the memory-mapped files.
//
//		fDataSize: size of the data send to the receiving app.
//		fData: the buffer to hold the data being sent to the other app.

struct Buffer
{
	long	fDataSize;
	char	fData[1];
};

// A collection of information that's needed for a single direction
// of message flow.

struct FileBundle
{
	HANDLE	fFile;		// Handle of the memory-mapped file.
	Buffer*	fView;		// Pointer to the mapping of that file.
	HANDLE	fEvent;		// Event that gets signalled when there's new data.
};

// Size of the memory-mapped files we create. Way larger than we need,
// but the system will probably allocate in 4K chunks anyway, so what
// the heck. NOTE: we might want to parameterize this in the future.

const int				kBufferSize = 4 * 1024;

// Names of the memory-mapped files we create.

const char*				kToEmulatorFileName		= "Debugger to Emulator";
const char*				kFromEmulatorFileName	= "Emulator to Debugger";

// Class and window names of the window we create.  We create a hidden
// window for the purpose of sending and receiving messages.

static const char*		kMMFClassName			= "MMFMessaging";
static const char*		kMMFWindowName			= "MMFMessaging";

// Handles of the hidden windows.

static HWND				gOurWindow;
static HWND				gHisWindow;

// Function to call when we receive a message saying that there's data
// for us, and a 32-bit parameter the user wants us to pass to the callback.

static PacketHandler	gCallback;
static LPARAM			gCallbackData;

// Bundles for the two (send and receive) memory-mapped files we create.

static FileBundle		gSendBundle;
static FileBundle		gReceiveBundle;

// The message ID we use in PostMessage when telling the other guy that
// there's new data waiting for him.

static UINT				gMessageID;

// Private internal function declarations.

static DWORD			MMFOpenABundle		(const char* name, FileBundle& bundle);
static void				MMFCloseABundle		(FileBundle& bundle);
static UINT				MMFRegisterMessage	(void);

static LRESULT CALLBACK	MMFMessagingWndProc	(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
static BOOL CALLBACK	MMFWindowFinder		(HWND hwnd, LPARAM lParam);


// ---------------------------------------------------------------------------
//		� Diagnostics
// ---------------------------------------------------------------------------

#if LOG_MMF

extern void PRINTF (const char* msg, ...);

#else

inline void PRINTF (const char*) {}
template <class T1> inline void PRINTF (const char*, T1) {}
template <class T1, class T2> inline void PRINTF (const char*, T1, T2) {}
template <class T1, class T2, class T3> inline void PRINTF (const char*, T1, T2, T3) {}

#endif


// ---------------------------------------------------------------------------
//		� MMFOpenFiles
// ---------------------------------------------------------------------------

DWORD MMFOpenFiles (HINSTANCE hInstance, PacketHandler fn, LPARAM userData,
					const char* sendFileName, const char* receiveFileName)
{
	DWORD		result;

	WNDCLASS	wc;
	ZeroMemory (&wc, sizeof (wc));

	wc.lpfnWndProc		= MMFMessagingWndProc;
	wc.lpszClassName	= kMMFClassName;

	if (RegisterClass (&wc) == 0)
	{
		assert (!"Unable to register window class.");
		result = GetLastError ();
		goto Error;
	}

	// Create the emulator window and show it.

	gOurWindow = CreateWindow (	kMMFClassName,
								kMMFWindowName,	// (Might want to parameterize this)
								0,			// style
								0, 0,		// position
								0, 0,		// size
								NULL,		// parent
								NULL,		// menu
								hInstance,
								NULL);		// window creation data

	if (gOurWindow == NULL)
	{
		assert (!"Unable to create window.");
		result = GetLastError ();
		goto Error;
	}

	gCallback = fn;
	gCallbackData = userData;

	result = MMFOpenABundle (sendFileName, gSendBundle);
	if (result != 0)
		goto Error;

	result = MMFOpenABundle (receiveFileName, gReceiveBundle);
	if (result != 0)
		goto Error;

	gMessageID = MMFRegisterMessage ();
	if (gMessageID == 0)
		goto Error;

Error:
	if (result != 0)
	{
		MMFCloseFiles ();
	}

	return result;
}


// ---------------------------------------------------------------------------
//		� MMFSendData
// ---------------------------------------------------------------------------
// Attempt to send the data to the requested "partner" application. Copy the
// given data into the "outgoing" memory-mapped file, and send a message to
// the "partner" application that there's data waiting for it.  If we can't
// send that message, it's either because we've never looked up the other
// guy's window handle, or the window handle we have is stale (either the
// other application has quit or has quit and restarted).  In any case, try
// to (re)find the window handle and send the message again.  If we fail
// again, then just give up.

DWORD MMFSendData (const void* data, long size)
{
	DWORD	error = ERROR_SUCCESS;

	PRINTF ("Entered MMFSendData. Checking message semaphore.");

	// Make sure that there's not an unread message in the buffer.
	// In other words, make sure that the event is not signalled.

	if (WaitForSingleObject (gSendBundle.fEvent, 0) == WAIT_OBJECT_0)
	{
		// The object is signalled, so it's "in use".

		PRINTF ("Message semaphore busy; leaving.");

		assert (!"Oops...sending data while previous data still in the buffer.");

		return ERROR_BUSY;
	}

	PRINTF ("Copying user data to shared buffer.");

	// Copy the data to the file.

	memcpy (gSendBundle.fView->fData, data, size);
	gSendBundle.fView->fDataSize = size;

	// Signal that data is ready.

	PRINTF ("Signalling event.");

	SetEvent (gSendBundle.fEvent);

	// Send the message.

	PRINTF ("Posting message.");

	if (!gHisWindow || !PostMessage (gHisWindow, gMessageID, 0, 0))
	{
		// If we can't post the message, the reason could be because
		// either we haven't hooked up with the other window yet, or
		// the other window doesn't exist any more.  Try finding the
		// other window.

		gHisWindow = NULL;
		EnumWindows (MMFWindowFinder, (LPARAM) &gHisWindow);

		// If we found it, try posting the message again.

		if (gHisWindow)
		{
			if (!PostMessage (gHisWindow, gMessageID, 0, 0))
			{
				// Complete and utter failure...

				error = GetLastError ();

				if (error == ERROR_SUCCESS)
				{
					// Make sure error is non-zero.

					error = ERROR_INVALID_WINDOW_HANDLE;
				}
			}
		}

		// Set the error in case we can't find the window.

		else
		{
			error = ERROR_INVALID_WINDOW_HANDLE;
		}
	}

	// Reset the event; no one is listening... If we don't
	// reset it, it will stay signalled, and the next time
	// we call this function, we'll think that there's pending
	// data in the outgoing buffer.

	if (error != ERROR_SUCCESS)
	{
		ResetEvent (gSendBundle.fEvent);
	}

	PRINTF ("Leaving MMFSendData.");

	return error;
}


// ---------------------------------------------------------------------------
//		� MMFWaitForData
// ---------------------------------------------------------------------------
// Wait for the given amount of time (in milliseconds) for data to arrive.
// If the data shows up, we handle it immediately by calling the user's
// callback function.  If the data doesn't show up, we return the result
// of WaitForSingleEvent, which will probably be WAIT_TIMEOUT. Otherwise,
// we return ERROR_SUCCESS.

DWORD MMFWaitForData (DWORD timeout)
{
	// Wait for the event to be signalled.

	PRINTF ("Entered MMFWaitForData. Waiting for message semaphore.");

	DWORD	result = WaitForSingleObject (gReceiveBundle.fEvent, timeout);

	if (result == WAIT_OBJECT_0)
	{
		PRINTF ("Got it. Calling callback");

		result = ERROR_SUCCESS;

		// Call the callback.

		gCallback (	gReceiveBundle.fView->fData,
					gReceiveBundle.fView->fDataSize,
					gCallbackData);

		PRINTF ("Back from callback. Resetting event.");

		// Mark the event unsignalled, saying that there's no longer
		// any data to be read.

		ResetEvent (gReceiveBundle.fEvent);
	}

	PRINTF ("Leaving MMFWaitForData.");

	return result;
}


// ---------------------------------------------------------------------------
//		� MMFCloseFiles
// ---------------------------------------------------------------------------

void MMFCloseFiles (void)
{
	DestroyWindow (gOurWindow);
	gOurWindow = NULL;

	MMFCloseABundle (gSendBundle);
	MMFCloseABundle (gReceiveBundle);

	gCallback = NULL;
	gCallbackData = 0;
}


// ---------------------------------------------------------------------------
//		� MMFOpenABundle
// ---------------------------------------------------------------------------

DWORD MMFOpenABundle (const char* name, FileBundle& bundle)
{
	DWORD	error = 0;
	BOOL	newFile = FALSE;

	// Assume glorious failure.

	bundle.fFile = NULL;
	bundle.fView = NULL;
	bundle.fEvent = NULL;

	// Try to open the mmf it it's already there

	bundle.fFile = OpenFileMapping (FILE_MAP_READ | FILE_MAP_WRITE, FALSE, name);


	// If it's not there, create one.

	if (!bundle.fFile)
	{
		bundle.fFile = CreateFileMapping ((HANDLE) 0xFFFFFFFF,	// in-memory mmf
											NULL, PAGE_READWRITE, 0, kBufferSize, name);

		if (!bundle.fFile)
		{
			assert (!"Unable to create file mapping");
			error = GetLastError ();
			return error;
		}

		newFile = TRUE;
	}

	// Map the file into our address space.

	bundle.fView = (Buffer*) MapViewOfFile (bundle.fFile, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, 0);

	if (!bundle.fView)
	{
		assert (!"Unable to map view of file");
		error = GetLastError ();
		return error;
	}

	if (newFile)
	{
		memset (bundle.fView, 0, kBufferSize);
	}

	// Create a new name for the event. We can base it on the name used for the
	// memory-mapped file (to ensure its uniqueness), but Win32 rules say that
	// event names must be different from those for semaphores, mutexes, and
	// memory mapped files.

	char	buffer[_MAX_PATH];

	strcpy (buffer, name);
	strcat (buffer, " event");

	bundle.fEvent = CreateEvent(NULL,	// Security attributes
								FALSE,	// bManual reset = no
								FALSE,	// bInitialState = non-signalled
								buffer);

	if (!bundle.fEvent)
	{
		assert (!"Unable to create event object");
		error = GetLastError ();
		return error;
	}
 
	return error;
}


// ---------------------------------------------------------------------------
//		� MMFCloseABundle
// ---------------------------------------------------------------------------

void MMFCloseABundle (FileBundle& bundle)
{
	DWORD	error = 0;

	if (bundle.fEvent)
	{
		if (!CloseHandle (bundle.fEvent))
		{
			assert (!"Error closing event");
			error = GetLastError ();
		}

		bundle.fEvent = NULL;
	}

	if (bundle.fView)
	{
		if (!UnmapViewOfFile (bundle.fView))
		{
			assert (!"Error unmapping file");
			error = GetLastError ();
		}

		bundle.fView = NULL;
	}

	if (bundle.fFile)
	{
		if (!CloseHandle (bundle.fFile))
		{
			assert (!"Error closing file");
			error = GetLastError ();
		}

		bundle.fFile = NULL;
	}
}


// ---------------------------------------------------------------------------
//		� MMFRegisterMessage
// ---------------------------------------------------------------------------

UINT MMFRegisterMessage (void)
{
	DWORD	error = 0;
	UINT	msgID = RegisterWindowMessage ("Emulator/Debugger");

	if (msgID == 0)
	{
		assert (!"Unable to register message ID");

		error = GetLastError ();
		assert (error == 0);
	}

	return msgID;
}


// ---------------------------------------------------------------------------
//		� MMFMessagingWndProc
// ---------------------------------------------------------------------------

LRESULT CALLBACK MMFMessagingWndProc(HWND hWnd,
									 UINT msg,
									 WPARAM wParam,
									 LPARAM lParam)
{
	PRINTF ("MMFMessagingWndProc called.");

	if ((hWnd == gOurWindow) && (msg == gMessageID))
	{
		// Call MMFWaitForData with no timeout to process any incoming
		// data.  If the data's there, we handle it.  However, if the data
		// was already handled because the client waited for it by calling
		// MMFWaitForData himself, we don't want to try to handle it again.

		PRINTF ("Message was for us.");

		MMFWaitForData (0);

		PRINTF ("Handled message.");

		return TRUE;
	}

	PRINTF ("Message was not for us.");

	return DefWindowProc (hWnd, msg, wParam, lParam);
}


// ---------------------------------------------------------------------------
//		� MMFWindowFinder
// ---------------------------------------------------------------------------

BOOL CALLBACK MMFWindowFinder(HWND hwnd, LPARAM lParam)
{
	// If it's the right kind, and it's not ours, then we'll talk with it.

	char	className[300];
	GetClassName (hwnd, className, 300);

	if ((strcmp (className, kMMFClassName) == 0) && (hwnd != gOurWindow))
	{
		*(HWND*) lParam = hwnd;
		return FALSE;	// stop enumeration
	}

	return TRUE;
}
