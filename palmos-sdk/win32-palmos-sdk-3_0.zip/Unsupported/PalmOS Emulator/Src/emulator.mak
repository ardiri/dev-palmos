# Microsoft Developer Studio Generated NMAKE File, Based on Emulator.dsp
!IF "$(CFG)" == ""
CFG=Emulator - Win32 Debug
!MESSAGE No configuration specified. Defaulting to Emulator - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "Emulator - Win32 Release" && "$(CFG)" !=\
 "Emulator - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Emulator.mak" CFG="Emulator - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Emulator - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Emulator - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "Emulator - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\Emulator.exe"

!ELSE 

ALL : "$(OUTDIR)\Emulator.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ATraps.obj"
	-@erase "$(INTDIR)\Byteswapping.obj"
	-@erase "$(INTDIR)\CGremlins.obj"
	-@erase "$(INTDIR)\cpu0.obj"
	-@erase "$(INTDIR)\cpu1.obj"
	-@erase "$(INTDIR)\cpu2.obj"
	-@erase "$(INTDIR)\cpu3.obj"
	-@erase "$(INTDIR)\cpu4.obj"
	-@erase "$(INTDIR)\cpu5.obj"
	-@erase "$(INTDIR)\cpu6.obj"
	-@erase "$(INTDIR)\cpu7.obj"
	-@erase "$(INTDIR)\cpu8.obj"
	-@erase "$(INTDIR)\cpu9.obj"
	-@erase "$(INTDIR)\CPU_REG.obj"
	-@erase "$(INTDIR)\cpuA.obj"
	-@erase "$(INTDIR)\cpuB.obj"
	-@erase "$(INTDIR)\cpuC.obj"
	-@erase "$(INTDIR)\cpuD.obj"
	-@erase "$(INTDIR)\cpudefs.obj"
	-@erase "$(INTDIR)\cpuE.obj"
	-@erase "$(INTDIR)\cpuF.obj"
	-@erase "$(INTDIR)\Crc.obj"
	-@erase "$(INTDIR)\DebugMgr.obj"
	-@erase "$(INTDIR)\Emulator.obj"
	-@erase "$(INTDIR)\Emulator.res"
	-@erase "$(INTDIR)\Gremlins.obj"
	-@erase "$(INTDIR)\LCD.obj"
	-@erase "$(INTDIR)\LoadApplication.obj"
	-@erase "$(INTDIR)\Logging.obj"
	-@erase "$(INTDIR)\MMFMessaging.obj"
	-@erase "$(INTDIR)\PilotCPU.obj"
	-@erase "$(INTDIR)\Platform_Win.obj"
	-@erase "$(INTDIR)\RAM_ROM.obj"
	-@erase "$(INTDIR)\readcpu.obj"
	-@erase "$(INTDIR)\Registry.obj"
	-@erase "$(INTDIR)\ROMStubs.obj"
	-@erase "$(INTDIR)\Settings.obj"
	-@erase "$(INTDIR)\small_cputbl.obj"
	-@erase "$(INTDIR)\StringData.obj"
	-@erase "$(INTDIR)\TrapPatches.obj"
	-@erase "$(INTDIR)\UAE_Utils.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\Emulator.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MT /W3 /GX /O2 /I ".\Source_Shared\UAE" /I\
 ".\Source_Shared\UAE\Includes" /I ".\Source_Shared\UAE\Generated" /I\
 ".\Source_Shared\\" /I ".\Source_Shared\Includes\\" /I\
 ".\Source_Shared\Includes\Palm\\" /I ".\Source_Shared\Includes\Palm\Hardware\\"\
 /I ".\Source_Shared\Includes\Palm\System\\" /I\
 ".\Source_Shared\Includes\Palm\UI\\" /I ".\Source_Shared\Emulator\\" /D\
 "NDEBUG" /D __PALMOS_TRAPS__=0 /D EMULATION_LEVEL=EMULATION_WINDOWS /D "WIN32"\
 /D "_WINDOWS" /D HW_TARGET=HW_TARGET_TD1 /D HW_REV=1 /D "STRICT" /D\
 GRAPHICS_VERSION=GRAPHICS_VERSION_1 /Fp"$(INTDIR)\Emulator.pch" /YX\
 /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Emulator.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Emulator.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comctl32.lib\
 comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib\
 odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no\
 /pdb:"$(OUTDIR)\Emulator.pdb" /machine:I386 /out:"$(OUTDIR)\Emulator.exe" 
LINK32_OBJS= \
	"$(INTDIR)\ATraps.obj" \
	"$(INTDIR)\Byteswapping.obj" \
	"$(INTDIR)\CGremlins.obj" \
	"$(INTDIR)\cpu0.obj" \
	"$(INTDIR)\cpu1.obj" \
	"$(INTDIR)\cpu2.obj" \
	"$(INTDIR)\cpu3.obj" \
	"$(INTDIR)\cpu4.obj" \
	"$(INTDIR)\cpu5.obj" \
	"$(INTDIR)\cpu6.obj" \
	"$(INTDIR)\cpu7.obj" \
	"$(INTDIR)\cpu8.obj" \
	"$(INTDIR)\cpu9.obj" \
	"$(INTDIR)\CPU_REG.obj" \
	"$(INTDIR)\cpuA.obj" \
	"$(INTDIR)\cpuB.obj" \
	"$(INTDIR)\cpuC.obj" \
	"$(INTDIR)\cpuD.obj" \
	"$(INTDIR)\cpudefs.obj" \
	"$(INTDIR)\cpuE.obj" \
	"$(INTDIR)\cpuF.obj" \
	"$(INTDIR)\Crc.obj" \
	"$(INTDIR)\DebugMgr.obj" \
	"$(INTDIR)\Emulator.obj" \
	"$(INTDIR)\Emulator.res" \
	"$(INTDIR)\Gremlins.obj" \
	"$(INTDIR)\LCD.obj" \
	"$(INTDIR)\LoadApplication.obj" \
	"$(INTDIR)\Logging.obj" \
	"$(INTDIR)\MMFMessaging.obj" \
	"$(INTDIR)\PilotCPU.obj" \
	"$(INTDIR)\Platform_Win.obj" \
	"$(INTDIR)\RAM_ROM.obj" \
	"$(INTDIR)\readcpu.obj" \
	"$(INTDIR)\Registry.obj" \
	"$(INTDIR)\ROMStubs.obj" \
	"$(INTDIR)\Settings.obj" \
	"$(INTDIR)\small_cputbl.obj" \
	"$(INTDIR)\StringData.obj" \
	"$(INTDIR)\TrapPatches.obj" \
	"$(INTDIR)\UAE_Utils.obj"

"$(OUTDIR)\Emulator.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\Emulator.exe" "$(OUTDIR)\Emulator.bsc"

!ELSE 

ALL : "$(OUTDIR)\Emulator.exe" "$(OUTDIR)\Emulator.bsc"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ATraps.obj"
	-@erase "$(INTDIR)\ATraps.sbr"
	-@erase "$(INTDIR)\Byteswapping.obj"
	-@erase "$(INTDIR)\Byteswapping.sbr"
	-@erase "$(INTDIR)\CGremlins.obj"
	-@erase "$(INTDIR)\CGremlins.sbr"
	-@erase "$(INTDIR)\cpu0.obj"
	-@erase "$(INTDIR)\cpu0.sbr"
	-@erase "$(INTDIR)\cpu1.obj"
	-@erase "$(INTDIR)\cpu1.sbr"
	-@erase "$(INTDIR)\cpu2.obj"
	-@erase "$(INTDIR)\cpu2.sbr"
	-@erase "$(INTDIR)\cpu3.obj"
	-@erase "$(INTDIR)\cpu3.sbr"
	-@erase "$(INTDIR)\cpu4.obj"
	-@erase "$(INTDIR)\cpu4.sbr"
	-@erase "$(INTDIR)\cpu5.obj"
	-@erase "$(INTDIR)\cpu5.sbr"
	-@erase "$(INTDIR)\cpu6.obj"
	-@erase "$(INTDIR)\cpu6.sbr"
	-@erase "$(INTDIR)\cpu7.obj"
	-@erase "$(INTDIR)\cpu7.sbr"
	-@erase "$(INTDIR)\cpu8.obj"
	-@erase "$(INTDIR)\cpu8.sbr"
	-@erase "$(INTDIR)\cpu9.obj"
	-@erase "$(INTDIR)\cpu9.sbr"
	-@erase "$(INTDIR)\CPU_REG.obj"
	-@erase "$(INTDIR)\CPU_REG.sbr"
	-@erase "$(INTDIR)\cpuA.obj"
	-@erase "$(INTDIR)\cpuA.sbr"
	-@erase "$(INTDIR)\cpuB.obj"
	-@erase "$(INTDIR)\cpuB.sbr"
	-@erase "$(INTDIR)\cpuC.obj"
	-@erase "$(INTDIR)\cpuC.sbr"
	-@erase "$(INTDIR)\cpuD.obj"
	-@erase "$(INTDIR)\cpuD.sbr"
	-@erase "$(INTDIR)\cpudefs.obj"
	-@erase "$(INTDIR)\cpudefs.sbr"
	-@erase "$(INTDIR)\cpuE.obj"
	-@erase "$(INTDIR)\cpuE.sbr"
	-@erase "$(INTDIR)\cpuF.obj"
	-@erase "$(INTDIR)\cpuF.sbr"
	-@erase "$(INTDIR)\Crc.obj"
	-@erase "$(INTDIR)\Crc.sbr"
	-@erase "$(INTDIR)\DebugMgr.obj"
	-@erase "$(INTDIR)\DebugMgr.sbr"
	-@erase "$(INTDIR)\Emulator.obj"
	-@erase "$(INTDIR)\Emulator.res"
	-@erase "$(INTDIR)\Emulator.sbr"
	-@erase "$(INTDIR)\Gremlins.obj"
	-@erase "$(INTDIR)\Gremlins.sbr"
	-@erase "$(INTDIR)\LCD.obj"
	-@erase "$(INTDIR)\LCD.sbr"
	-@erase "$(INTDIR)\LoadApplication.obj"
	-@erase "$(INTDIR)\LoadApplication.sbr"
	-@erase "$(INTDIR)\Logging.obj"
	-@erase "$(INTDIR)\Logging.sbr"
	-@erase "$(INTDIR)\MMFMessaging.obj"
	-@erase "$(INTDIR)\MMFMessaging.sbr"
	-@erase "$(INTDIR)\PilotCPU.obj"
	-@erase "$(INTDIR)\PilotCPU.sbr"
	-@erase "$(INTDIR)\Platform_Win.obj"
	-@erase "$(INTDIR)\Platform_Win.sbr"
	-@erase "$(INTDIR)\RAM_ROM.obj"
	-@erase "$(INTDIR)\RAM_ROM.sbr"
	-@erase "$(INTDIR)\readcpu.obj"
	-@erase "$(INTDIR)\readcpu.sbr"
	-@erase "$(INTDIR)\Registry.obj"
	-@erase "$(INTDIR)\Registry.sbr"
	-@erase "$(INTDIR)\ROMStubs.obj"
	-@erase "$(INTDIR)\ROMStubs.sbr"
	-@erase "$(INTDIR)\Settings.obj"
	-@erase "$(INTDIR)\Settings.sbr"
	-@erase "$(INTDIR)\small_cputbl.obj"
	-@erase "$(INTDIR)\small_cputbl.sbr"
	-@erase "$(INTDIR)\StringData.obj"
	-@erase "$(INTDIR)\StringData.sbr"
	-@erase "$(INTDIR)\TrapPatches.obj"
	-@erase "$(INTDIR)\TrapPatches.sbr"
	-@erase "$(INTDIR)\UAE_Utils.obj"
	-@erase "$(INTDIR)\UAE_Utils.sbr"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\Emulator.bsc"
	-@erase "$(OUTDIR)\Emulator.exe"
	-@erase "$(OUTDIR)\Emulator.ilk"
	-@erase "$(OUTDIR)\Emulator.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MTd /W3 /Gm /GX /Zi /Od /I\
 ".\Source_Shared\Includes\Palm\UI\\" /I ".\Source_Shared\UAE" /I\
 ".\Source_Shared\UAE\Includes" /I ".\Source_Shared\UAE\Generated" /I\
 ".\Source_Shared\\" /I ".\Source_Shared\Includes\\" /I\
 ".\Source_Shared\Includes\Palm\\" /I ".\Source_Shared\Includes\Palm\Hardware\\"\
 /I ".\Source_Shared\Includes\Palm\System\\" /I ".\Source_Shared\Emulator\\" /D\
 "_DEBUG" /D __PALMOS_TRAPS__=0 /D EMULATION_LEVEL=EMULATION_WINDOWS /D "WIN32"\
 /D "_WINDOWS" /D HW_TARGET=HW_TARGET_TD1 /D HW_REV=1 /D "STRICT" /D\
 GRAPHICS_VERSION=GRAPHICS_VERSION_1 /FR"$(INTDIR)\\"\
 /Fp"$(INTDIR)\Emulator.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.\Debug/

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Emulator.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Emulator.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\ATraps.sbr" \
	"$(INTDIR)\Byteswapping.sbr" \
	"$(INTDIR)\CGremlins.sbr" \
	"$(INTDIR)\cpu0.sbr" \
	"$(INTDIR)\cpu1.sbr" \
	"$(INTDIR)\cpu2.sbr" \
	"$(INTDIR)\cpu3.sbr" \
	"$(INTDIR)\cpu4.sbr" \
	"$(INTDIR)\cpu5.sbr" \
	"$(INTDIR)\cpu6.sbr" \
	"$(INTDIR)\cpu7.sbr" \
	"$(INTDIR)\cpu8.sbr" \
	"$(INTDIR)\cpu9.sbr" \
	"$(INTDIR)\CPU_REG.sbr" \
	"$(INTDIR)\cpuA.sbr" \
	"$(INTDIR)\cpuB.sbr" \
	"$(INTDIR)\cpuC.sbr" \
	"$(INTDIR)\cpuD.sbr" \
	"$(INTDIR)\cpudefs.sbr" \
	"$(INTDIR)\cpuE.sbr" \
	"$(INTDIR)\cpuF.sbr" \
	"$(INTDIR)\Crc.sbr" \
	"$(INTDIR)\DebugMgr.sbr" \
	"$(INTDIR)\Emulator.sbr" \
	"$(INTDIR)\Gremlins.sbr" \
	"$(INTDIR)\LCD.sbr" \
	"$(INTDIR)\LoadApplication.sbr" \
	"$(INTDIR)\Logging.sbr" \
	"$(INTDIR)\MMFMessaging.sbr" \
	"$(INTDIR)\PilotCPU.sbr" \
	"$(INTDIR)\Platform_Win.sbr" \
	"$(INTDIR)\RAM_ROM.sbr" \
	"$(INTDIR)\readcpu.sbr" \
	"$(INTDIR)\Registry.sbr" \
	"$(INTDIR)\ROMStubs.sbr" \
	"$(INTDIR)\Settings.sbr" \
	"$(INTDIR)\small_cputbl.sbr" \
	"$(INTDIR)\StringData.sbr" \
	"$(INTDIR)\TrapPatches.sbr" \
	"$(INTDIR)\UAE_Utils.sbr"

"$(OUTDIR)\Emulator.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comctl32.lib\
 comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib\
 odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:yes\
 /pdb:"$(OUTDIR)\Emulator.pdb" /debug /machine:I386\
 /out:"$(OUTDIR)\Emulator.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\ATraps.obj" \
	"$(INTDIR)\Byteswapping.obj" \
	"$(INTDIR)\CGremlins.obj" \
	"$(INTDIR)\cpu0.obj" \
	"$(INTDIR)\cpu1.obj" \
	"$(INTDIR)\cpu2.obj" \
	"$(INTDIR)\cpu3.obj" \
	"$(INTDIR)\cpu4.obj" \
	"$(INTDIR)\cpu5.obj" \
	"$(INTDIR)\cpu6.obj" \
	"$(INTDIR)\cpu7.obj" \
	"$(INTDIR)\cpu8.obj" \
	"$(INTDIR)\cpu9.obj" \
	"$(INTDIR)\CPU_REG.obj" \
	"$(INTDIR)\cpuA.obj" \
	"$(INTDIR)\cpuB.obj" \
	"$(INTDIR)\cpuC.obj" \
	"$(INTDIR)\cpuD.obj" \
	"$(INTDIR)\cpudefs.obj" \
	"$(INTDIR)\cpuE.obj" \
	"$(INTDIR)\cpuF.obj" \
	"$(INTDIR)\Crc.obj" \
	"$(INTDIR)\DebugMgr.obj" \
	"$(INTDIR)\Emulator.obj" \
	"$(INTDIR)\Emulator.res" \
	"$(INTDIR)\Gremlins.obj" \
	"$(INTDIR)\LCD.obj" \
	"$(INTDIR)\LoadApplication.obj" \
	"$(INTDIR)\Logging.obj" \
	"$(INTDIR)\MMFMessaging.obj" \
	"$(INTDIR)\PilotCPU.obj" \
	"$(INTDIR)\Platform_Win.obj" \
	"$(INTDIR)\RAM_ROM.obj" \
	"$(INTDIR)\readcpu.obj" \
	"$(INTDIR)\Registry.obj" \
	"$(INTDIR)\ROMStubs.obj" \
	"$(INTDIR)\Settings.obj" \
	"$(INTDIR)\small_cputbl.obj" \
	"$(INTDIR)\StringData.obj" \
	"$(INTDIR)\TrapPatches.obj" \
	"$(INTDIR)\UAE_Utils.obj"

"$(OUTDIR)\Emulator.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(CFG)" == "Emulator - Win32 Release" || "$(CFG)" ==\
 "Emulator - Win32 Debug"
SOURCE=.\Source_Windows\Emulator.rc
DEP_RSC_EMULA=\
	".\Source_Windows\Connection.bmp"\
	".\Source_Windows\Emulator.ico"\
	".\Source_Windows\POSE.bmp"\
	".\Source_Windows\Silkscreen.bmp"\
	".\Source_Windows\Silkscreen2.bmp"\
	

!IF  "$(CFG)" == "Emulator - Win32 Release"


"$(INTDIR)\Emulator.res" : $(SOURCE) $(DEP_RSC_EMULA) "$(INTDIR)"
	$(RSC) /l 0x409 /fo"$(INTDIR)\Emulator.res" /i "Source_Windows" /d "NDEBUG"\
 $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"


"$(INTDIR)\Emulator.res" : $(SOURCE) $(DEP_RSC_EMULA) "$(INTDIR)"
	$(RSC) /l 0x409 /fo"$(INTDIR)\Emulator.res" /i "Source_Windows" /d "_DEBUG"\
 $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\Emulator.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_EMULAT=\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\LCD.h"\
	".\Source_Windows\PilotCPU.h"\
	".\Source_Windows\Settings.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_EMULAT=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\Emulator.obj" : $(SOURCE) $(DEP_CPP_EMULAT) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_EMULAT=\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\LCD.h"\
	".\Source_Windows\PilotCPU.h"\
	".\Source_Windows\Settings.h"\
	

"$(INTDIR)\Emulator.obj"	"$(INTDIR)\Emulator.sbr" : $(SOURCE) $(DEP_CPP_EMULAT)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\LCD.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_LCD_C=\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\LoadApplication.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\MMFMessaging.h"\
	".\Source_Windows\PilotCPU.h"\
	".\Source_Windows\Settings.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_LCD_C=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\LCD.obj" : $(SOURCE) $(DEP_CPP_LCD_C) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_LCD_C=\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\LoadApplication.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\MMFMessaging.h"\
	".\Source_Windows\PilotCPU.h"\
	".\Source_Windows\Settings.h"\
	

"$(INTDIR)\LCD.obj"	"$(INTDIR)\LCD.sbr" : $(SOURCE) $(DEP_CPP_LCD_C)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\MMFMessaging.cpp
DEP_CPP_MMFME=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Windows\MMFMessaging.h"\
	

!IF  "$(CFG)" == "Emulator - Win32 Release"


"$(INTDIR)\MMFMessaging.obj" : $(SOURCE) $(DEP_CPP_MMFME) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"


"$(INTDIR)\MMFMessaging.obj"	"$(INTDIR)\MMFMessaging.sbr" : $(SOURCE)\
 $(DEP_CPP_MMFME) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\PilotCPU.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_PILOT=\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\PilotCPU.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_PILOT=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\PilotCPU.obj" : $(SOURCE) $(DEP_CPP_PILOT) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_PILOT=\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\PilotCPU.h"\
	

"$(INTDIR)\PilotCPU.obj"	"$(INTDIR)\PilotCPU.sbr" : $(SOURCE) $(DEP_CPP_PILOT)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\Platform_Win.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_PLATF=\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\MMFMessaging.h"\
	".\Source_Windows\Settings.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_PLATF=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\Platform_Win.obj" : $(SOURCE) $(DEP_CPP_PLATF) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_PLATF=\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	".\Source_Windows\MMFMessaging.h"\
	".\Source_Windows\Settings.h"\
	

"$(INTDIR)\Platform_Win.obj"	"$(INTDIR)\Platform_Win.sbr" : $(SOURCE)\
 $(DEP_CPP_PLATF) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\Registry.cpp
DEP_CPP_REGIS=\
	".\Source_Windows\Registry.h"\
	

!IF  "$(CFG)" == "Emulator - Win32 Release"


"$(INTDIR)\Registry.obj" : $(SOURCE) $(DEP_CPP_REGIS) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"


"$(INTDIR)\Registry.obj"	"$(INTDIR)\Registry.sbr" : $(SOURCE) $(DEP_CPP_REGIS)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Windows\Settings.cpp
DEP_CPP_SETTI=\
	".\Source_Windows\Registry.h"\
	".\Source_Windows\Settings.h"\
	

!IF  "$(CFG)" == "Emulator - Win32 Release"


"$(INTDIR)\Settings.obj" : $(SOURCE) $(DEP_CPP_SETTI) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"


"$(INTDIR)\Settings.obj"	"$(INTDIR)\Settings.sbr" : $(SOURCE) $(DEP_CPP_SETTI)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\ATraps.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_ATRAP=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_ATRAP=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\ATraps.obj" : $(SOURCE) $(DEP_CPP_ATRAP) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_ATRAP=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\ATraps.obj"	"$(INTDIR)\ATraps.sbr" : $(SOURCE) $(DEP_CPP_ATRAP)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\Byteswapping.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_BYTES=\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_BYTES=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\Byteswapping.obj" : $(SOURCE) $(DEP_CPP_BYTES) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_BYTES=\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\Byteswapping.obj"	"$(INTDIR)\Byteswapping.sbr" : $(SOURCE)\
 $(DEP_CPP_BYTES) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\CGremlins.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CGREM=\
	".\Source_Shared\Emulator\CGremlins.h"\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SystemPrv.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Switches.h"\
	
NODEP_CPP_CGREM=\
	".\Source_Shared\Emulator\ShellCmd.h"\
	

"$(INTDIR)\CGremlins.obj" : $(SOURCE) $(DEP_CPP_CGREM) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CGREM=\
	".\Source_Shared\Emulator\CGremlins.h"\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Switches.h"\
	

"$(INTDIR)\CGremlins.obj"	"$(INTDIR)\CGremlins.sbr" : $(SOURCE)\
 $(DEP_CPP_CGREM) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\CPU_REG.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU_R=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\Profiling.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\EmuTraps.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU_R=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\CPU_REG.obj" : $(SOURCE) $(DEP_CPP_CPU_R) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU_R=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\EmuTraps.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\CPU_REG.obj"	"$(INTDIR)\CPU_REG.sbr" : $(SOURCE) $(DEP_CPP_CPU_R)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\Emulator\Crc.c

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CRC_C=\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\Crc.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	

"$(INTDIR)\Crc.obj" : $(SOURCE) $(DEP_CPP_CRC_C) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CRC_C=\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\Crc.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	

"$(INTDIR)\Crc.obj"	"$(INTDIR)\Crc.sbr" : $(SOURCE) $(DEP_CPP_CRC_C)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\DebugMgr.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_DEBUG=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_DEBUG=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\DebugMgr.obj" : $(SOURCE) $(DEP_CPP_DEBUG) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_DEBUG=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\DebugMgr.obj"	"$(INTDIR)\DebugMgr.sbr" : $(SOURCE) $(DEP_CPP_DEBUG)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\Gremlins.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_GREML=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CGremlins.h"\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_GREML=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\Gremlins.obj" : $(SOURCE) $(DEP_CPP_GREML) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_GREML=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CGremlins.h"\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\Gremlins.obj"	"$(INTDIR)\Gremlins.sbr" : $(SOURCE) $(DEP_CPP_GREML)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\LoadApplication.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_LOADA=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\LoadApplication.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_LOADA=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\LoadApplication.obj" : $(SOURCE) $(DEP_CPP_LOADA) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_LOADA=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\LoadApplication.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\LoadApplication.obj"	"$(INTDIR)\LoadApplication.sbr" : $(SOURCE)\
 $(DEP_CPP_LOADA) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\Emulator\Logging.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_LOGGI=\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_LOGGI=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\Logging.obj" : $(SOURCE) $(DEP_CPP_LOGGI) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_LOGGI=\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\Logging.obj"	"$(INTDIR)\Logging.sbr" : $(SOURCE) $(DEP_CPP_LOGGI)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\RAM_ROM.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_RAM_R=\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Profiling.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\Crc.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_RAM_R=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\RAM_ROM.obj" : $(SOURCE) $(DEP_CPP_RAM_R) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_RAM_R=\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\Crc.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\RAM_ROM.obj"	"$(INTDIR)\RAM_ROM.sbr" : $(SOURCE) $(DEP_CPP_RAM_R)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\ROMStubs.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_ROMST=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_ROMST=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\ROMStubs.obj" : $(SOURCE) $(DEP_CPP_ROMST) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_ROMST=\
	".\Source_Shared\Emulator\ATraps.h"\
	".\Source_Shared\Emulator\Byteswapping.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\DebugMgr.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\ROMStubs.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\ROMStubs.obj"	"$(INTDIR)\ROMStubs.sbr" : $(SOURCE) $(DEP_CPP_ROMST)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\StringData.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_STRIN=\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Switches.h"\
	

"$(INTDIR)\StringData.obj" : $(SOURCE) $(DEP_CPP_STRIN) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_STRIN=\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Switches.h"\
	

"$(INTDIR)\StringData.obj"	"$(INTDIR)\StringData.sbr" : $(SOURCE)\
 $(DEP_CPP_STRIN) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\TrapPatches.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_TRAPP=\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_TRAPP=\
	".\Source_Shared\Includes\CEmulatorApp.h"\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\TrapPatches.obj" : $(SOURCE) $(DEP_CPP_TRAPP) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_TRAPP=\
	".\Source_Shared\Emulator\CGremlinsStubs.h"\
	".\Source_Shared\Emulator\CPU_REG.h"\
	".\Source_Shared\Emulator\Gremlins.h"\
	".\Source_Shared\Emulator\RAM_ROM.h"\
	".\Source_Shared\Emulator\StringData.h"\
	".\Source_Shared\Emulator\TrapPatches.h"\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\DragonBall.h"\
	".\Source_Shared\Includes\Palm\AppBuildRules.h"\
	".\Source_Shared\Includes\Palm\BuildRules.h"\
	".\Source_Shared\Includes\Palm\Common.h"\
	".\Source_Shared\Includes\Palm\Hardware\Hardware.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h"\
	".\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h"\
	".\Source_Shared\Includes\Palm\Hardware\M68KHwr.h"\
	".\Source_Shared\Includes\Palm\Palm.h"\
	".\Source_Shared\Includes\Palm\SysBuildRules.h"\
	".\Source_Shared\Includes\Palm\System\DataMgr.h"\
	".\Source_Shared\Includes\Palm\System\DataPrv.h"\
	".\Source_Shared\Includes\Palm\System\DebugPrv.h"\
	".\Source_Shared\Includes\Palm\System\ErrorMgr.h"\
	".\Source_Shared\Includes\Palm\System\Globals.h"\
	".\Source_Shared\Includes\Palm\System\KeyMgr.h"\
	".\Source_Shared\Includes\Palm\System\KeyPrv.h"\
	".\Source_Shared\Includes\Palm\System\MemoryMgr.h"\
	".\Source_Shared\Includes\Palm\System\MemoryPrvNew.h"\
	".\Source_Shared\Includes\Palm\System\PenMgr.h"\
	".\Source_Shared\Includes\Palm\System\SerialLinkMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtMgr.h"\
	".\Source_Shared\Includes\Palm\System\SysEvtPrv.h"\
	".\Source_Shared\Includes\Palm\System\SystemMgr.h"\
	".\Source_Shared\Includes\Palm\System\SystemPkt.h"\
	".\Source_Shared\Includes\Palm\System\SysTraps.h"\
	".\Source_Shared\Includes\Palm\UI\Chars.h"\
	".\Source_Shared\Includes\Palm\UI\Control.h"\
	".\Source_Shared\Includes\Palm\UI\Event.H"\
	".\Source_Shared\Includes\Palm\UI\Field.h"\
	".\Source_Shared\Includes\Palm\UI\Font.h"\
	".\Source_Shared\Includes\Palm\UI\Form.h"\
	".\Source_Shared\Includes\Palm\UI\List.h"\
	".\Source_Shared\Includes\Palm\UI\Rect.h"\
	".\Source_Shared\Includes\Palm\UI\ScrollBar.h"\
	".\Source_Shared\Includes\Palm\UI\Table.h"\
	".\Source_Shared\Includes\Palm\UI\Window.h"\
	".\Source_Shared\Includes\Platform.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\TrapPatches.obj"	"$(INTDIR)\TrapPatches.sbr" : $(SOURCE)\
 $(DEP_CPP_TRAPP) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=".\Source_Shared\Emulator\UAE_Utils.cpp"

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_UAE_U=\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_UAE_U=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\UAE_Utils.obj" : $(SOURCE) $(DEP_CPP_UAE_U) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_UAE_U=\
	".\Source_Shared\Emulator\UAE_Utils.h"\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\Includes\UAE.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\UAE_Utils.obj"	"$(INTDIR)\UAE_Utils.sbr" : $(SOURCE)\
 $(DEP_CPP_UAE_U) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu0.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU0_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU0_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu0.obj" : $(SOURCE) $(DEP_CPP_CPU0_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU0_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu0.obj"	"$(INTDIR)\cpu0.sbr" : $(SOURCE) $(DEP_CPP_CPU0_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu1.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU1_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU1_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu1.obj" : $(SOURCE) $(DEP_CPP_CPU1_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU1_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu1.obj"	"$(INTDIR)\cpu1.sbr" : $(SOURCE) $(DEP_CPP_CPU1_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu2.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU2_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU2_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu2.obj" : $(SOURCE) $(DEP_CPP_CPU2_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU2_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu2.obj"	"$(INTDIR)\cpu2.sbr" : $(SOURCE) $(DEP_CPP_CPU2_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu3.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU3_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU3_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu3.obj" : $(SOURCE) $(DEP_CPP_CPU3_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU3_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu3.obj"	"$(INTDIR)\cpu3.sbr" : $(SOURCE) $(DEP_CPP_CPU3_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu4.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU4_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU4_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu4.obj" : $(SOURCE) $(DEP_CPP_CPU4_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU4_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu4.obj"	"$(INTDIR)\cpu4.sbr" : $(SOURCE) $(DEP_CPP_CPU4_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu5.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU5_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU5_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu5.obj" : $(SOURCE) $(DEP_CPP_CPU5_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU5_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu5.obj"	"$(INTDIR)\cpu5.sbr" : $(SOURCE) $(DEP_CPP_CPU5_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu6.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU6_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU6_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu6.obj" : $(SOURCE) $(DEP_CPP_CPU6_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU6_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu6.obj"	"$(INTDIR)\cpu6.sbr" : $(SOURCE) $(DEP_CPP_CPU6_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu7.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU7_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU7_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu7.obj" : $(SOURCE) $(DEP_CPP_CPU7_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU7_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu7.obj"	"$(INTDIR)\cpu7.sbr" : $(SOURCE) $(DEP_CPP_CPU7_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu8.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU8_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU8_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu8.obj" : $(SOURCE) $(DEP_CPP_CPU8_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU8_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu8.obj"	"$(INTDIR)\cpu8.sbr" : $(SOURCE) $(DEP_CPP_CPU8_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpu9.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPU9_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPU9_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpu9.obj" : $(SOURCE) $(DEP_CPP_CPU9_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPU9_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpu9.obj"	"$(INTDIR)\cpu9.sbr" : $(SOURCE) $(DEP_CPP_CPU9_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuA.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUA_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUA_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuA.obj" : $(SOURCE) $(DEP_CPP_CPUA_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUA_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuA.obj"	"$(INTDIR)\cpuA.sbr" : $(SOURCE) $(DEP_CPP_CPUA_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuB.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUB_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUB_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuB.obj" : $(SOURCE) $(DEP_CPP_CPUB_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUB_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuB.obj"	"$(INTDIR)\cpuB.sbr" : $(SOURCE) $(DEP_CPP_CPUB_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuC.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUC_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUC_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuC.obj" : $(SOURCE) $(DEP_CPP_CPUC_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUC_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuC.obj"	"$(INTDIR)\cpuC.sbr" : $(SOURCE) $(DEP_CPP_CPUC_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuD.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUD_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUD_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuD.obj" : $(SOURCE) $(DEP_CPP_CPUD_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUD_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuD.obj"	"$(INTDIR)\cpuD.sbr" : $(SOURCE) $(DEP_CPP_CPUD_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpudefs.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUDE=\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUDE=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpudefs.obj" : $(SOURCE) $(DEP_CPP_CPUDE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUDE=\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpudefs.obj"	"$(INTDIR)\cpudefs.sbr" : $(SOURCE) $(DEP_CPP_CPUDE)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuE.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUE_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUE_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuE.obj" : $(SOURCE) $(DEP_CPP_CPUE_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUE_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuE.obj"	"$(INTDIR)\cpuE.sbr" : $(SOURCE) $(DEP_CPP_CPUE_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\cpuF.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_CPUF_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_CPUF_=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\cpuF.obj" : $(SOURCE) $(DEP_CPP_CPUF_) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_CPUF_=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\cpuF.obj"	"$(INTDIR)\cpuF.sbr" : $(SOURCE) $(DEP_CPP_CPUF_)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\readcpu.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_READC=\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_READC=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\readcpu.obj" : $(SOURCE) $(DEP_CPP_READC) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_READC=\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\readcpu.obj"	"$(INTDIR)\readcpu.sbr" : $(SOURCE) $(DEP_CPP_READC)\
 "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Source_Shared\UAE\Generated\small_cputbl.cpp

!IF  "$(CFG)" == "Emulator - Win32 Release"

DEP_CPP_SMALL=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cpu0.h"\
	".\Source_Shared\UAE\Generated\cpu1.h"\
	".\Source_Shared\UAE\Generated\cpu2.h"\
	".\Source_Shared\UAE\Generated\cpu3.h"\
	".\Source_Shared\UAE\Generated\cpu4.h"\
	".\Source_Shared\UAE\Generated\cpu5.h"\
	".\Source_Shared\UAE\Generated\cpu6.h"\
	".\Source_Shared\UAE\Generated\cpu7.h"\
	".\Source_Shared\UAE\Generated\cpu8.h"\
	".\Source_Shared\UAE\Generated\cpu9.h"\
	".\Source_Shared\UAE\Generated\cpuA.h"\
	".\Source_Shared\UAE\Generated\cpuB.h"\
	".\Source_Shared\UAE\Generated\cpuC.h"\
	".\Source_Shared\UAE\Generated\cpuD.h"\
	".\Source_Shared\UAE\Generated\cpuE.h"\
	".\Source_Shared\UAE\Generated\cpuF.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	{$(INCLUDE)}"sys\stat.h"\
	{$(INCLUDE)}"sys\types.h"\
	
NODEP_CPP_SMALL=\
	".\Source_Shared\UAE\Includes\md-amiga\amiga-kludges.h"\
	

"$(INTDIR)\small_cputbl.obj" : $(SOURCE) $(DEP_CPP_SMALL) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

DEP_CPP_SMALL=\
	".\Source_Shared\Includes\Switches.h"\
	".\Source_Shared\UAE\Generated\cpu0.h"\
	".\Source_Shared\UAE\Generated\cpu1.h"\
	".\Source_Shared\UAE\Generated\cpu2.h"\
	".\Source_Shared\UAE\Generated\cpu3.h"\
	".\Source_Shared\UAE\Generated\cpu4.h"\
	".\Source_Shared\UAE\Generated\cpu5.h"\
	".\Source_Shared\UAE\Generated\cpu6.h"\
	".\Source_Shared\UAE\Generated\cpu7.h"\
	".\Source_Shared\UAE\Generated\cpu8.h"\
	".\Source_Shared\UAE\Generated\cpu9.h"\
	".\Source_Shared\UAE\Generated\cpuA.h"\
	".\Source_Shared\UAE\Generated\cpuB.h"\
	".\Source_Shared\UAE\Generated\cpuC.h"\
	".\Source_Shared\UAE\Generated\cpuD.h"\
	".\Source_Shared\UAE\Generated\cpuE.h"\
	".\Source_Shared\UAE\Generated\cpuF.h"\
	".\Source_Shared\UAE\Generated\cputbl.h"\
	".\Source_Shared\UAE\Includes\compiler.h"\
	".\Source_Shared\UAE\Includes\config.h"\
	".\Source_Shared\UAE\Includes\custom.h"\
	".\Source_Shared\UAE\Includes\machdep_m68k.h"\
	".\Source_Shared\UAE\Includes\machdep_memory.h"\
	".\Source_Shared\UAE\Includes\memory_cpu.h"\
	".\Source_Shared\UAE\Includes\newcpu.h"\
	".\Source_Shared\UAE\Includes\options.h"\
	".\Source_Shared\UAE\Includes\readcpu.h"\
	".\Source_Shared\UAE\Includes\sysconfig.h"\
	".\Source_Shared\UAE\Includes\sysdeps.h"\
	

"$(INTDIR)\small_cputbl.obj"	"$(INTDIR)\small_cputbl.sbr" : $(SOURCE)\
 $(DEP_CPP_SMALL) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 


!ENDIF 

