# Microsoft Developer Studio Project File - Name="Emulator" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=Emulator - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "Emulator.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Emulator.mak" CFG="Emulator - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Emulator - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Emulator - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Emulator - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MT /W3 /GX /O2 /I ".\Source_Shared\UAE" /I ".\Source_Shared\UAE\Includes" /I ".\Source_Shared\UAE\Generated" /I ".\Source_Shared\\" /I ".\Source_Shared\Includes\\" /I ".\Source_Shared\Includes\Palm\\" /I ".\Source_Shared\Includes\Palm\Hardware\\" /I ".\Source_Shared\Includes\Palm\System\\" /I ".\Source_Shared\Includes\Palm\UI\\" /I ".\Source_Shared\Emulator\\" /D "NDEBUG" /D __PALMOS_TRAPS__=0 /D EMULATION_LEVEL=EMULATION_WINDOWS /D "WIN32" /D "_WINDOWS" /D HW_TARGET=HW_TARGET_TD1 /D HW_REV=1 /D "STRICT" /D GRAPHICS_VERSION=GRAPHICS_VERSION_1 /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comctl32.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /machine:I386
# SUBTRACT LINK32 /debug

!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /I ".\Source_Shared\Includes\Palm\UI\\" /I ".\Source_Shared\UAE" /I ".\Source_Shared\UAE\Includes" /I ".\Source_Shared\UAE\Generated" /I ".\Source_Shared\\" /I ".\Source_Shared\Includes\\" /I ".\Source_Shared\Includes\Palm\\" /I ".\Source_Shared\Includes\Palm\Hardware\\" /I ".\Source_Shared\Includes\Palm\System\\" /I ".\Source_Shared\Emulator\\" /D "_DEBUG" /D __PALMOS_TRAPS__=0 /D EMULATION_LEVEL=EMULATION_WINDOWS /D "WIN32" /D "_WINDOWS" /D HW_TARGET=HW_TARGET_TD1 /D HW_REV=1 /D "STRICT" /D GRAPHICS_VERSION=GRAPHICS_VERSION_1 /FR /YX /FD /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comctl32.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "Emulator - Win32 Release"
# Name "Emulator - Win32 Debug"
# Begin Group "Emulator - Windows"

# PROP Default_Filter ""
# Begin Group "Resources"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Source_Windows\Case.bmp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Connection.bmp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Emulator.ico
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Emulator.rc

!IF  "$(CFG)" == "Emulator - Win32 Release"

!ELSEIF  "$(CFG)" == "Emulator - Win32 Debug"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Source_Windows\POSE.bmp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Silkscreen.bmp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Silkscreen2.bmp
# End Source File
# End Group
# Begin Source File

SOURCE=.\Source_Windows\Emulator.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\LCD.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\LCD.h
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\MMFMessaging.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\MMFMessaging.h
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\PilotCPU.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\PilotCPU.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Platform.h
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Platform_Win.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Registry.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Registry.h
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Settings.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Windows\Settings.h
# End Source File
# End Group
# Begin Group "Emulator - Shared"

# PROP Default_Filter ""
# Begin Group "Palm Includes"

# PROP Default_Filter ""
# Begin Group "Palm"

# PROP Default_Filter ""
# Begin Group "Hardware"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\Hardware.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\HardwarePrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\HardwareTD1.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\M68328Hwr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\M68681Hwr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Hardware\M68KHwr.h
# End Source File
# End Group
# Begin Group "System"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\Crc.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\DataMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\DataPrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\DebugPrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\ErrorMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\Globals.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\KeyMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\KeyPrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\MemoryMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\MemoryPrvNew.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\PenMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SerialLinkMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SysEvtMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SysEvtPrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SystemMgr.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SystemPkt.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SystemPrv.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\System\SysTraps.h
# End Source File
# End Group
# Begin Group "UI"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Chars.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Control.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Event.H
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Field.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Font.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Form.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\List.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Rect.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\ScrollBar.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Table.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\UIGlobals.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\UI\Window.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\AppBuildRules.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\BuildRules.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Common.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\Palm.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Palm\SysBuildRules.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Source_Shared\Includes\Byteswapping.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\DragonBall.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\EmuTraps.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\UAE.h
# End Source File
# End Group
# Begin Source File

SOURCE=".\Source_Shared\Emulator\ATraps.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\ATraps.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\Byteswapping.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\Byteswapping.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\CGremlins.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\CGremlins.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\CGremlinsStubs.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\CPU_REG.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\CPU_REG.h"
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Emulator\Crc.c
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\DebugMgr.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\DebugMgr.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\Gremlins.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\Gremlins.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\LoadApplication.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\LoadApplication.h"
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Emulator\Logging.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Emulator\Profiling.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Emulator\Profiling.h
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\RAM_ROM.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\RAM_ROM.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\ROMStubs.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\ROMStubs.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\StringData.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\StringData.h"
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\Includes\Switches.h
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\TrapPatches.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\TrapPatches.h"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\UAE_Utils.cpp"
# End Source File
# Begin Source File

SOURCE=".\Source_Shared\Emulator\UAE_Utils.h"
# End Source File
# End Group
# Begin Group "UAE"

# PROP Default_Filter ""
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\compiler.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\config.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu0.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu0.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu1.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu1.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu2.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu2.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu3.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu3.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu4.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu4.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu5.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu5.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu6.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu6.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu7.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu7.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu8.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu8.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu9.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpu9.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuA.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuA.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuB.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuB.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuC.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuC.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuD.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuD.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpudefs.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuE.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuE.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuF.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cpuF.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\cputbl.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\custom.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\machdep_m68k.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\machdep_memory.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\memory_cpu.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\newcpu.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\options.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\readcpu.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\readcpu.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Generated\small_cputbl.cpp
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\sysconfig.h
# End Source File
# Begin Source File

SOURCE=.\Source_Shared\UAE\Includes\sysdeps.h
# End Source File
# End Group
# Begin Source File

SOURCE=.\Source_Windows\Finger.cur
# End Source File
# Begin Source File

SOURCE=.\Notes.txt
# End Source File
# Begin Source File

SOURCE=.\NotesPrv.txt
# End Source File
# End Target
# End Project
