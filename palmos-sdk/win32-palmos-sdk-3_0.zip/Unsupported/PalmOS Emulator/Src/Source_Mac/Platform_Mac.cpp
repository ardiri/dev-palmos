/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma mark Includes

#include "Platform.h"

#include "DragonBall.h"		// hwr68328Base, HwrDBallType

#include "CPU_REG.h"		// gPen_IsDown, gPen_HorzLocation, Hardware::PenEvent, kBreak_CheckForEvents
#include "TrapPatches.h"	// gCurrentApplicationName
#include "StringData.h"		// kErrorStrings
#include "Gremlins.h"		// Gremlins_IsOn, Gremlins_GremlinNumber, Gremlins_EventNumber
#include "UAE_Utils.h"		// uae_strlen, uae_strcpy

#include <Timer.h>			// Microseconds
#include <FixMath.h>		// Long2Fix
#include "CEmulatorApp.h"	// gApplication
#include "CTouchScreen.h"	// CTouchScreen
#include "UDialogTools.h"	// StandardAlert
#include "USerialPort.h"	// Comm_Initialize, Comm_Dispose

#if USE_THREADS
#include <LThread.h>		// LThread::Yield
#endif

#include <string.h>			// memcpy


// TByteQueuePrivate Class.

#pragma mark TByteQueuePrivate Definition

// Queue used for keyboard and serial input/output.  This is the
// private, platform-dependent implementation used by TByteQueue.

const uae_s16 kQueueSize = 8;

class TByteQueuePrivate
{
	public:
					TByteQueuePrivate (void)
					{
						fFreeElements = kQueueSize;
						fUsedElements = fHead = fTail = 0;
					}

		void		Put (uae_u8 iElement)
					{
						fQueue[fHead] = iElement;
						fHead = (fHead + 1) % kQueueSize;
						fUsedElements++;
						fFreeElements--;
					}

		uae_u8		Get (void)
					{
						uae_u8 aElement = fQueue[fTail];
						fTail = (fTail + 1) % kQueueSize;
						fFreeElements++;
						fUsedElements--;
						return aElement;
					}

		uae_s16		GetUsed (void)	{ return fUsedElements; }
		uae_s16		GetFree (void)	{ return fFreeElements; }

	private:
		uae_s16		fUsedElements;
		uae_s16		fFreeElements;
		uae_u8		fQueue[kQueueSize];
		uae_s16		fHead;
		uae_s16		fTail;
};


// Constants.

#pragma mark Constants

const short kResource_SignalAlert		= 1000;
const short kResource_ErrorAlert		= 1001;
const short kResource_ErrorStrings		= 10000;

const short kErrorDialog_ContinueDebugReset	= 1011;

enum {
	kErrorDialog_Icon = 1,
	kErrorDialog_Text,
	kErrorDialog_Continue,
	kErrorDialog_Debug,
	kErrorDialog_Reset
};

// Non-constants.

#pragma mark Globals

unsigned long	gLastCycleTime;

TByteQueue		gCommReadQueue;
TByteQueue		gCommWriteQueue;


// ---------------------------------------------------------------------------
//		� Platform::Initialize
// ---------------------------------------------------------------------------
// Initializes platform-dependent stuff.

void Platform::Initialize (void)
{
	Platform::OpenSerialPort ();
}


// ---------------------------------------------------------------------------
//		� Platform::Reset
// ---------------------------------------------------------------------------
// Resets platform-dependent stuff.

void Platform::Reset (void)
{
}


// ---------------------------------------------------------------------------
//		� Platform::ReportString
// ---------------------------------------------------------------------------
// Displays a stop alert that contains the specified message.

void Platform::ReportString (const Str255 iMessageString)
{
	// Set the error text.

	ParamText (iMessageString, "\p", "\p", "\p");

	// Display the dialog.

	StandardAlert (kResource_SignalAlert);
}


// ---------------------------------------------------------------------------
//		� Platform::ReportString
// ---------------------------------------------------------------------------
// Displays a stop alert that contains the specified message.

void Platform::ReportString (const char* iMessageString)
{
	// Convert the string

	Str255	pString;
	pString[0] = strlen (iMessageString);
	memcpy (&pString[1], iMessageString, pString[0]);

	// Set the error text.

	ParamText (pString, "\p", "\p", "\p");

	// Display the dialog.

	StandardAlert (kResource_SignalAlert);
}


// ---------------------------------------------------------------------------
//		� Platform::ReportError
// ---------------------------------------------------------------------------
// Displays a stop alert that contains the specified message.

void Platform::ReportError (long iMessageID)
{
	// Get the error string.
	
	if (iMessageID >= kError_LastError)
		iMessageID = kError_DefaultError;

	// Display the dialog.

	Platform::ReportString (kErrorStrings[iMessageID]);
}


// ---------------------------------------------------------------------------
//		� Platform::ReportCriticalError
// ---------------------------------------------------------------------------
// Displays a stop alert that contains the specified error and the file name
// and line number where the error occurred.

void Platform::ReportCriticalError (long		iMessageID,
									long		iErrorID,
									const char*	iFileName,
									long		iLineNumber)
{
	// Get the error string.

	if (iMessageID >= kError_LastError)
		iMessageID = kError_DefaultError;

	Str255	aMessage;
	aMessage[0] = strlen (kErrorStrings[iMessageID]);
	memcpy (&aMessage[1], kErrorStrings[iMessageID], aMessage[0]);

	// Try to determine the error if no error code was provided.

	long aErrorID = iErrorID;
	if (aErrorID == kError_NoError)
		aErrorID = MemError ();
	if (aErrorID == kError_NoError)
		aErrorID = ResError ();

	// Convert the error code to a string.

	Str255 aError;
	NumToString (aErrorID, aError);

	// Convert the file name to a Pascal string.

	Str255 aFileName;
	aFileName[0] = 0;

	if (iFileName != NULL)
	{
		// Get the length of the file name.

		long aNameLength = 0;
		while (iFileName[aNameLength])
			aNameLength++;
		aNameLength = (aNameLength > 255) ? 255 : aNameLength;

		// Move the C string into a P string.

		BlockMove (iFileName, &aFileName[1], aNameLength);
		aFileName[0] = aNameLength;
	}

	// Convert the line number to a string.

	Str255 aLineNumber;
	NumToString (iLineNumber, aLineNumber);

	// Set the error text.

	ParamText (aMessage, aError, aFileName, aLineNumber);

	// Display the dialog.

	StandardAlert (kResource_ErrorAlert);
}


// ---------------------------------------------------------------------------
//		� Platform::ErrorDialog
// ---------------------------------------------------------------------------

static const char*	gMessage;

static pascal void I_wish_I_had_lamda_functions (	DialogRef 	iDialog,
													short		iItem)
{
	Rect	aRect;
	GetItemRect (iDialog, iItem, aRect);

	UTextDrawing::DrawWithJustification ((Ptr) gMessage, strlen (gMessage),
										aRect, teFlushDefault, false);
}

// Based on UTextDrawing::DrawWithJustification

static Int16 GetTextHeight(
	Ptr			inText,
	Int32		inLength,
	const Rect	&inRect,
	Int16		inJustification,
	Boolean		inFirstLeading)			// Add leading above first line?
{
	Fixed	fixedWidth = ::Long2Fix(inRect.right - inRect.left);

	FontInfo	fontInfo;
	::GetFontInfo(&fontInfo);
	Int16 lineHeight = fontInfo.ascent + fontInfo.descent + fontInfo.leading;
	Int16 lineBase = fontInfo.ascent;
	
	if (inFirstLeading) {
		lineBase += fontInfo.leading;
	}

	Fixed	wrapWidth;
	Int32	blackSpace, lineBytes;
	Int32	textLeft = inLength;
	Ptr		textEnd = inText + inLength;
	StyledLineBreakCode	lineBreak;
	
	Int16	justification = inJustification;
	if (justification == teFlushDefault) {
		justification = ::GetSysDirection();
	}
	
	while ((inText < textEnd)) {
		lineBytes = 1;
		wrapWidth = fixedWidth;
		
		Int32	textLen = textLeft;		// Note in IM:Text 5-80 states
		if (textLen > max_Int16) {		//   that length is limited to the
			textLen = max_Int16;		//   integer range
		}
		
		lineBreak = ::StyledLineBreak(inText, textLen, 0, textLen, 0,
										&wrapWidth, &lineBytes);

		lineBase += lineHeight;
		inText += lineBytes;
		textLeft -= lineBytes;
	}

	return lineBase + fontInfo.descent;
}


int Platform::ErrorDialog (const char* msg, int flags)
{
	gMessage = msg;

	// Display the dialog.

	// Remember the current port.

	GrafPtr aSavePort;
	GetPort (&aSavePort);

	// Load the dialog.

	DialogRef	aDialog = GetNewDialog (kErrorDialog_ContinueDebugReset, NULL, (WindowRef) -1);

	SetDialogFontToEspi (aDialog);

	// Enable/disable the buttons appropriately.

	SetItemEnable (aDialog, kErrorDialog_Continue, (flags & kMsgContinue) != 0);
	SetItemEnable (aDialog, kErrorDialog_Debug, (flags & kMsgDebug) != 0);
	SetItemEnable (aDialog, kErrorDialog_Reset, (flags & kMsgReset) != 0);

	// Resize the text box, move the buttons below it, and resize the window.

	Rect	aRect;
	GetItemRect (aDialog, kErrorDialog_Text, aRect);

	Int16	msgHeight = GetTextHeight ((Ptr) gMessage, strlen (gMessage),
										aRect, teFlushDefault, false);

		// For aesthetic reasons, make the message height at least 50 pixels.
	
	if (msgHeight < 50)
	{
		msgHeight = 50;
	}

		// Resize the message box.

	aRect.bottom = msgHeight;
	SetItemRect (aDialog, kErrorDialog_Text, aRect);

		// Move the buttons down.

	GetItemRect (aDialog, kErrorDialog_Continue, aRect);
	aRect.top += msgHeight;
	aRect.bottom += msgHeight;
	SetItemRect (aDialog, kErrorDialog_Continue, aRect);

	GetItemRect (aDialog, kErrorDialog_Debug, aRect);
	aRect.top += msgHeight;
	aRect.bottom += msgHeight;
	SetItemRect (aDialog, kErrorDialog_Debug, aRect);

	GetItemRect (aDialog, kErrorDialog_Reset, aRect);
	aRect.top += msgHeight;
	aRect.bottom += msgHeight;
	SetItemRect (aDialog, kErrorDialog_Reset, aRect);

		// Resize the window.

	aRect = aDialog->portRect;
	SizeWindow (aDialog, aRect.right - aRect.left,
				aRect.bottom - aRect.top + msgHeight, true);

	// Set up the default button.

//	SetDialogDefaultItem (aDialog, kErrorDialog_ButtonBase);

	// Set up the guy who will draw the text.

	UserItemUPP	aTextItemUPP = NewUserItemProc (I_wish_I_had_lamda_functions);
	SetUserItemProcedure (aDialog, kErrorDialog_Text, aTextItemUPP);

	// Event loop.

	ShowWindow (aDialog);
	SetPort (aDialog);

	short	button = 0;
	do
	{
		ModalDialog (NULL, &button);
	}
	while (button < kErrorDialog_Continue);

	// Clean up.

	DisposeDialog (aDialog);
	DisposeRoutineDescriptor (aTextItemUPP);

	SetPort (aSavePort);

	// Figure out which button was hit and return it.

	return	(button == kErrorDialog_Continue) ? kMsgContinue :
			(button == kErrorDialog_Debug) ? kMsgDebug :
			kMsgReset;
}


// ---------------------------------------------------------------------------
//		� Platform::GetString
// ---------------------------------------------------------------------------

char* Platform::GetString (int id)
{
	// On the Mac, our resource ID's are the same as the string ID's
	// plus 1000.

	const int	kStringResourceIDBase = 1000;

	id += kStringResourceIDBase;

	Handle	strHandle = GetResource ('TEXT', id);
	Size	strLength = GetHandleSize (strHandle);

	char*	result = (char*) malloc (strLength + 1);

	if (result)
	{
		memcpy (result, *strHandle, strLength);
		result [strLength] = 0;
	}

	return result;
}


// ---------------------------------------------------------------------------
//		� Platform::Delay
// ---------------------------------------------------------------------------
// Delay for a time period appropriate for a sleeping 68328.

void Platform::Delay (void)
{
	UnsignedWide	start, end;
	Microseconds (&start);
	do {
		Microseconds (&end);
	} while (end.lo < (start.lo + 8800));	// Delay 8.8 msecs. This value was
											// empirically determined by seeing
											// if the Palm device would go to
											// sleep after the right amount of
											// time.
}


// ---------------------------------------------------------------------------
//		� Platform::Cycle
// ---------------------------------------------------------------------------

void Platform::Cycle (void)
{
	gLastCycleTime = LMGetTicks ();

	CTouchScreen*	screen = gApplication->GetLCDScreen ();
	if (screen == NULL)
		return;

#if !USE_THREADS

	// Refresh the screen

	screen->RefreshScreen ();

#endif

	// Track the pen if it's down.

	if (gPen_IsDown)
	{
		Point aLocation = screen->GetMouse ();

		if (aLocation.h != gPen_HorzLocation || aLocation.v != gPen_VertLocation)
		{
			Hardware::PenEvent (true, aLocation.h, aLocation.v);
		}			
	}

#if USE_THREADS

	// Yield to the UI thread.

	LThread::Yield (LThread::GetMainThread ());

#else

	// Break from the CPU loop.

	Emulator::SetBreakReason (kBreak_CheckForEvents);

#endif
}


// ---------------------------------------------------------------------------
//		� Platform::GetMilliseconds
// ---------------------------------------------------------------------------

uae_u32 Platform::GetMilliseconds (void)
{
	UnsignedWide	now;
	Microseconds (&now);

	// The number of microseconds was stored in a 64-bit field.  We want to
	// return the number of _milliseconds_ in a _32-bit_ field.  To perform
	// the conversion, we extract bits 10 through 42 (giving us our 32 bits),
	// shifting them down by 10 (effectively dividing by 1024 to convert from
	// microseconds to milliseconds).


//	64-bit microseconds:
//
//	+----------- now.hi ------------+----------- now.lo ------------+
//
//  64		56		48		40		32		24		16		8		0
//	|		|		|		|		|		|		|		|		|
//	 ****************************************************************
//						  42							  10
//						  +-------------------------------+
//						  |								  |
//						  V								  V
//
//	32-bit milliseconds:
//						  32							  0
//						  |								  |
//						   ********************************
//

	return (now.hi << 22) | (now.lo >> 10);	// return milliseconds
}


// ---------------------------------------------------------------------------
//		� Platform::GetTime
// ---------------------------------------------------------------------------

void Platform::GetTime (long* hour, long* min, long* sec)
{
	DateTimeRec	dateTime;
	::GetTime (&dateTime);

	*hour	= dateTime.hour;		// 0...23
	*min	= dateTime.minute;		// 0...59
	*sec	= dateTime.second;		// 0...59
}


// ---------------------------------------------------------------------------
//		� Platform::GetDate
// ---------------------------------------------------------------------------

void Platform::GetDate (long* year, long* month, long* day)
{
	DateTimeRec	dateTime;
	::GetTime (&dateTime);

	*year	= dateTime.year;		// 1904...2040
	*month	= dateTime.month;		// 1...12
	*day	= dateTime.day;			// 1...31
}


// ---------------------------------------------------------------------------
//		� Platform::ConnectToDebugger
// ---------------------------------------------------------------------------

uae_u32 Platform::ConnectToDebugger (void)
{
	return gApplication->OpenPorts ();
}


// ---------------------------------------------------------------------------
//		� Platform::SendPacket
// ---------------------------------------------------------------------------

uae_u32 Platform::SendPacket (const void* pkt, long size)
{
	return gApplication->SendPacket(pkt, size);
}


// ---------------------------------------------------------------------------
//		� Platform::DisconnectFromDebugger
// ---------------------------------------------------------------------------

void Platform::DisconnectFromDebugger (void)
{
	(void) gApplication->ClosePorts ();
}


// ---------------------------------------------------------------------------
//		� Platform::ViewDrawLine
// ---------------------------------------------------------------------------

void Platform::ViewDrawLine (int xStart, int yStart, int xEnd, int yEnd)
{
#if 0
	if (gScreenPane != NULL)
	{
		gScreenPane->FocusDraw();
		
		::PenNormal();
		::MoveTo(xStart, yStart);
		::Line(xEnd - xStart, yEnd - yStart);
	}
#endif
}


// ---------------------------------------------------------------------------
//		� Platform::ViewDrawPixel
// ---------------------------------------------------------------------------

void Platform::ViewDrawPixel (int xPos, int yPos)
{
#if 0
	if (gScreenPane != NULL)
	{
		gScreenPane->FocusDraw();
		
		::PenNormal();
		::MoveTo(xPos, yPos);
		::Line(0, 0);
	}
#endif
}


// ---------------------------------------------------------------------------
//		� Platform::OpenSerialPort
// ---------------------------------------------------------------------------

void Platform::OpenSerialPort (void)
{
	Comm_Dispose ();
	Comm_Initialize (gApplication->GetHotSyncPort (), baud19200);
}


// ---------------------------------------------------------------------------
//		� Platform::CloseSerialPort
// ---------------------------------------------------------------------------

bool Platform::CloseSerialPort (void)
{
	bool	wasOpen = gCommEstablished != FALSE;
	Comm_Dispose ();
	return wasOpen;
}


// ---------------------------------------------------------------------------
//		� Platform::SetBaud
// ---------------------------------------------------------------------------

void Platform::SetBaud (uae_u16 newRate)
{
	bool	wasOpen = CloseSerialPort ();

	if (wasOpen)
	{
		// (This calculation really ought to be in RAM_ROM.cpp --
		//  a common file.)

		uae_u32	rate = 1036800 /
			(1 << ((newRate & hwr328UBaudDivider) >> hwr328UBaudDivideBitOffset)) /
			(65 - (newRate & hwr328UBaudPrescaler));

		short	newBaud;

		switch (rate)
		{
			case   150:	newBaud = baud150;		break;
			case   300:	newBaud = baud300;		break;
			case   600:	newBaud = baud600;		break;
			case  1200:	newBaud = baud1200;		break;
			case  1800:	newBaud = baud1800;		break;
			case  2400:	newBaud = baud2400;		break;
			case  3600:	newBaud = baud3600;		break;
			case  4800:	newBaud = baud4800;		break;
			case  7200:	newBaud = baud7200;		break;
			case  9600:	newBaud = baud9600;		break;
			case 14400:	newBaud = baud14400;	break;
			case 19200:	newBaud = baud19200;	break;
			case 28800:	newBaud = baud28800;	break;
			case 38400:	newBaud = baud38400;	break;
			case 57600:	newBaud = baud57600;	break;
			default:	newBaud = baud19200;	break;
		}

		Comm_Initialize (gApplication->GetHotSyncPort (), newBaud);
	}
}


// ---------------------------------------------------------------------------
//		� Platform::SetCTS
// ---------------------------------------------------------------------------

void Platform::SetCTS (uae_u16 uTransmit)
{
	// !!! TBD
}


// ---------------------------------------------------------------------------
//		� Platform::WriteSerialByte
// ---------------------------------------------------------------------------

void Platform::WriteSerialByte (uae_u8 outByte)
{
	assert (gCommWriteQueue.GetFree () > 0);

	// Write the byte to the serial output queue.  If the queue is full,
	// force the CPU loop to break so that CEmulatorApp::SpendTime can
	// empty it.

	gCommWriteQueue.Put (outByte);

	if (gCommWriteQueue.GetFree () == 0)
	{
		Emulator::SetBreakReason (kBreak_CheckForEvents);
	}
}


// ---------------------------------------------------------------------------
//		� Platform::ReadSerialByte
// ---------------------------------------------------------------------------

uae_u8 Platform::ReadSerialByte (void)
{
	assert (gCommReadQueue.GetUsed () > 0);

	// A call to this function indicates that there's serial activity going
	// on, so let's break out of the CPU loop so that CEmulatorApp::SpendTime
	// can buffer up any data.

	Emulator::SetBreakReason (kBreak_CheckForEvents);

	// Return the next byte in the queue.

	return gCommReadQueue.Get ();
}


// ---------------------------------------------------------------------------
//		� Platform::IncomingSerialBytes
// ---------------------------------------------------------------------------

uae_u32 Platform::IncomingSerialBytes (void)
{
	// Return the number of bytes we've queued up.

	return gCommReadQueue.GetUsed ();
}


// ---------------------------------------------------------------------------
//		� Platform::OutgoingSerialBytes
// ---------------------------------------------------------------------------

uae_u32 Platform::OutgoingSerialBytes (void)
{
	// Return the number of bytes we've queued up.

	return gCommWriteQueue.GetUsed ();
}


// ---------------------------------------------------------------------------
//		� TByteQueue::TByteQueue
// ---------------------------------------------------------------------------

TByteQueue::TByteQueue () :
	fImplementation (new TByteQueuePrivate)
{
}


// ---------------------------------------------------------------------------
//		� TByteQueue::~TByteQueue
// ---------------------------------------------------------------------------

TByteQueue::~TByteQueue ()
{
	delete fImplementation;
}


// ---------------------------------------------------------------------------
//		� TByteQueue::Put
// ---------------------------------------------------------------------------

void TByteQueue::Put (uae_u8 b)
{
	fImplementation->Put (b);
}


// ---------------------------------------------------------------------------
//		� TByteQueue::Get
// ---------------------------------------------------------------------------

uae_u8 TByteQueue::Get (void)
{
	return fImplementation->Get ();
}


// ---------------------------------------------------------------------------
//		� TByteQueue::GetUsed
// ---------------------------------------------------------------------------

int TByteQueue::GetUsed (void)
{
	return fImplementation->GetUsed ();
}


// ---------------------------------------------------------------------------
//		� TByteQueue::GetFree
// ---------------------------------------------------------------------------

int TByteQueue::GetFree (void)
{
	return fImplementation->GetFree ();
}


