/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "PPCMessaging.h"

#include <Script.h>			// smSystemScript

#include <stddef.h>			// offsetof
#include <string.h>			// memset


/*
	General flow:

		--- Starting up

		 1)	User opens things up by calling OpenPorts
		 2)	OpenPorts opens two ports via OpenAPort
		 3) If failure, return error
		 4)	If success, tries to connect to other side
		 5) If success, goto 9
		 6) if failure, start listening for connections
		 7) if failure, close down
		 8) when connection attempt completes...
		 9) have "receiving" port start listening for packets
		10) if failure, disconnect and go to 4

		--- For receiving data

		11) when packet arrives, set flag
		12) user reads data, and goes back to 9

		--- For sending data

		13) Sends data out of write port
		14) If successful, flag data sent
		15) If failure, flag error
		
		--- Shutting down

		16) End sessions
		17) Close ports
*/


#pragma mark --- Globals ---

// ---------------------------------------------------------------------------
//		� Globals
// ---------------------------------------------------------------------------

PortBundle					gSendPort;
PortBundle					gReceivePort;

const unsigned char*		kEmulatorPortName = "\pEmulator";
const unsigned char*		kDebuggerPortName = "\pDebugger";
const unsigned char*		kToEmulatorPortType = "\pDebugger to Emulator";
const unsigned char*		kFromEmulatorPortType = "\pEmulator to Debugger";

static ProcessSerialNumber	gPSN;

static PPCCompUPP			gInformCompletionProc;
static PPCCompUPP			gReadCompletionProc;
static PPCCompUPP			gWriteCompletionProc;
static PPCCompUPP			gEndCompletionProc;

static char					gDefaultReadBuffer[300];
static char					gDefaultWriteBuffer[300];


#pragma mark -
#pragma mark --- Diagnostics ---

// ---------------------------------------------------------------------------
//		� Diagnostics
// ---------------------------------------------------------------------------

#if LOG_PPC

extern void PRINTF (const char* msg, ...);

#else

inline void PRINTF (const char*) {}

#if defined (__cplusplus)
template <class T1> inline void PRINTF (const char*, T1) {}
template <class T1, class T2> inline void PRINTF (const char*, T1, T2) {}
template <class T1, class T2, class T3> inline void PRINTF (const char*, T1, T2, T3) {}
#endif

#endif


#pragma mark -
#pragma mark --- Main Functions ---

// ---------------------------------------------------------------------------
//		� PPCOpenPorts
// ---------------------------------------------------------------------------

OSErr PPCOpenPorts (const unsigned char* ourPortName,
					const unsigned char* hisPortName,
					const unsigned char* sendPortType,
					const unsigned char* receivePortType)
{
	OSErr	err;

	// If we haven't already done so, create our completion proc pointers.

	if (!gInformCompletionProc)
	{
		gInformCompletionProc	= NewPPCCompProc (PPCInformCompletionProc);
		gReadCompletionProc		= NewPPCCompProc (PPCReadCompletionProc);
		gWriteCompletionProc	= NewPPCCompProc (PPCWriteCompletionProc);
		gEndCompletionProc		= NewPPCCompProc (PPCEndCompletionProc);
	}

	// Get the current process number.

	GetCurrentProcess (&gPSN);

	// Intialize our ports.

	memset(&gSendPort, 0, sizeof (gSendPort));

	gSendPort.fBuffer					= gDefaultWriteBuffer;
	gSendPort.fBufferSize				= sizeof (gDefaultWriteBuffer);
	gSendPort.fState					= kPPC_Closed;
	gSendPort.fDataWaiting				= false;
	gSendPort.fForReading				= false;
	gSendPort.fPSN						= gPSN;
	gSendPort.fInformCompletionProc		= gInformCompletionProc;
	gSendPort.fReadCompletionProc		= gReadCompletionProc;
	gSendPort.fWriteCompletionProc		= gWriteCompletionProc;
	gSendPort.fEndCompletionProc		= gEndCompletionProc;

	memset(&gReceivePort, 0, sizeof (gReceivePort));

	gReceivePort.fBuffer				= gDefaultReadBuffer;
	gReceivePort.fBufferSize			= sizeof (gDefaultReadBuffer);
	gReceivePort.fState					= kPPC_Closed;
	gReceivePort.fDataWaiting			= false;
	gReceivePort.fForReading			= true;
	gReceivePort.fPSN					= gPSN;
	gReceivePort.fInformCompletionProc	= gInformCompletionProc;
	gReceivePort.fReadCompletionProc	= gReadCompletionProc;
	gReceivePort.fWriteCompletionProc	= gWriteCompletionProc;
	gReceivePort.fEndCompletionProc		= gEndCompletionProc;


	// Try to open the ports.  If we fail, close down and leave.

	err = PPCOpenAPort (&gSendPort, ourPortName, sendPortType);
	if (err)
		goto Exit;

	err = PPCOpenAPort (&gReceivePort, ourPortName, receivePortType);
	if (err)
		goto Exit;

	// Try to connect the ports.  If either of these fail, disconnect
	// and starting listening for connections.

	err = PPCConnectAPort (&gSendPort, hisPortName, sendPortType);

	if (!err)
	{
		err = PPCConnectAPort (&gReceivePort, hisPortName, receivePortType);
		if (err)
		{
			(void) PPCDisconnectAPort (&gSendPort);
		}
	}

	// The connect attempt failed, so try listening for a connection.

	if (err)
	{
		err = PPCListenForConnect (&gSendPort);

		if (!err)
			err = PPCListenForConnect (&gReceivePort);
	}

	// On any errors, close us down.

Exit:
	if (err)
		PPCClosePorts ();

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCOpenAPort
// ---------------------------------------------------------------------------

OSErr PPCOpenAPort (PortBundle* bndl,
					const unsigned char* ourPortName,
					const unsigned char* ourPortType)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only open a port if it's currently closed.

	if (PPCPortClosed (bndl))
	{
		PRINTF ("Opening a port.");

		// Fill in the PPCPortRec.

		bndl->fOurPortName.nameScript		= smSystemScript;
		bndl->fOurPortName.portKindSelector	= ppcByString;

		memcpy (bndl->fOurPortName.name,			ourPortName,	StrLength (ourPortName) + 1);
		memcpy (bndl->fOurPortName.u.portTypeStr,	ourPortType,	StrLength (ourPortType) + 1);

		// Fill in the PPCOpenPBRec.

		bndl->fPB.openParam.ioCompletion	= NULL;
		bndl->fPB.openParam.serviceType		= ppcServiceRealTime;
		bndl->fPB.openParam.resFlag			= 0;
		bndl->fPB.openParam.networkVisible	= false;
		bndl->fPB.openParam.portName		= &bndl->fOurPortName;
		bndl->fPB.openParam.locationName	= NULL;
		bndl->fPB.openParam.networkVisible	= false;

		// Open the port.

		err = PPCOpenSync (&bndl->fPB.openParam);

		// If we opened, update our state.

		if (!err)
		{
			PRINTF ("Opened a port.");

			bndl->fState = kPPC_Opened;
		}
		else
		{
			PRINTF ("Attempt to open a port failed.");
		}
	}
	else
	{
		PRINTF ("Not opening a port because it wasn't closed.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCConnectAPort
// ---------------------------------------------------------------------------

OSErr PPCConnectAPort (	PortBundle* bndl,
						const unsigned char* hisPortName,
						const unsigned char* hisPortType)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only connect a port if it's open.

	if (PPCPortOpened (bndl))
	{
		PRINTF ("Starting a session.");

		// Fill in the PPCPortRec.

		bndl->fHisPortName.nameScript		= smSystemScript;
		bndl->fHisPortName.portKindSelector	= ppcByString;

		memcpy (bndl->fHisPortName.name,			hisPortName,	StrLength (hisPortName) + 1);
		memcpy (bndl->fHisPortName.u.portTypeStr,	hisPortType,	StrLength (hisPortType) + 1);

		// Fill in the PPCStartPBRec.

		bndl->fPB.startParam.ioCompletion	= NULL;
		bndl->fPB.startParam.resFlag		= 0;
		bndl->fPB.startParam.portName		= &bndl->fHisPortName;
		bndl->fPB.startParam.locationName	= NULL;		// local machine
		bndl->fPB.startParam.userData		= 0;
		bndl->fPB.startParam.userRefNum		= 0;

		// Try to connect.

		err = PPCStartSync (&bndl->fPB.startParam);

		// If we connected, update our state.

		if (!err)
		{
			PRINTF ("Started a session.");

			bndl->fState = kPPC_Connected;

			// If this port is for reading, start listening on it

			if (bndl->fForReading)
			{
				err = PPCListenForData (bndl);
			}
		}
		else
		{
			PRINTF ("Attempt to start a session failed.");
		}
	}
	else
	{
		PRINTF ("Not connecting a port because it wasn't opened.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCListenForConnect
// ---------------------------------------------------------------------------

OSErr PPCListenForConnect (PortBundle* bndl)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only listen for a connection on a port if it's open.

	if (PPCPortOpened (bndl))
	{
		PRINTF ("Started listening for a connection.");

		// Fill in the PPCInformPBRec.

		bndl->fPB.informParam.ioCompletion	= gInformCompletionProc;
		bndl->fPB.informParam.autoAccept	= true;
		bndl->fPB.informParam.portName		= NULL;
		bndl->fPB.informParam.locationName	= NULL;
		bndl->fPB.informParam.userName		= NULL;

		// Set our new state.  When the Listen completes, the completion
		// proc will update our state.

		bndl->fState = kPPC_Connecting;

		// Start listening for a connection.

		err = PPCInformAsync (&bndl->fPB.informParam);
	}
	else
	{
		PRINTF ("Not listening for a connection because the port wasn't opened.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCSetReadBuffer
// ---------------------------------------------------------------------------

void PPCSetReadBuffer (void* buffer, long size)
{
	if (buffer)
	{
		gReceivePort.fBuffer = (Ptr) buffer;
		gReceivePort.fBufferSize = size;
	}
	else
	{
		gReceivePort.fBuffer = gDefaultReadBuffer;
		gReceivePort.fBufferSize = sizeof (gDefaultReadBuffer);
	}
}


// ---------------------------------------------------------------------------
//		� PPCSetWriteBuffer
// ---------------------------------------------------------------------------

void PPCSetWriteBuffer (void* buffer, long size)
{
	if (buffer)
	{
		gSendPort.fBuffer = (Ptr) buffer;
		gSendPort.fBufferSize = size;
	}
	else
	{
		gSendPort.fBuffer = gDefaultWriteBuffer;
		gSendPort.fBufferSize = sizeof (gDefaultWriteBuffer);
	}
}


// ---------------------------------------------------------------------------
//		� PPCListenForData
// ---------------------------------------------------------------------------

OSErr PPCListenForData (PortBundle* bndl)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only listen for data on a connected port.
	// Also require that the user indicate that they've read
	// any previously received data before letting them read again.

	if (PPCPortConnected (bndl) && !PPCPortReading (&gSendPort) && !bndl->fDataWaiting)
	{
		PRINTF ("Started listening for data.");

		// Fill in the PPCReadPBRec.

		bndl->fPB.readParam.ioCompletion	= bndl->fReadCompletionProc;
		bndl->fPB.readParam.bufferPtr		= bndl->fBuffer;
		bndl->fPB.readParam.bufferLength	= bndl->fBufferSize;

		// Set our new state.  If the Read fails, the completion
		// proc will update our state.

		bndl->fState = kPPC_Reading;

		// Start listening for a packet.

		err = PPCReadAsync (&bndl->fPB.readParam);
	}
	else
	{
		PRINTF ("Not listening for data because the port wasn't opened.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCSendData
// ---------------------------------------------------------------------------

OSErr PPCSendData (const void* data, long size)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only send data on a connected port.

	if (PPCPortConnected (&gSendPort) && !PPCPortWriting (&gSendPort))
	{
		PRINTF ("Started sending some data.");

		// We're doing an asynchronous write, so copy the user's data.

		memcpy (gSendPort.fBuffer, data, size);

		// Fill in the PPCWritePBRec.

		gSendPort.fPB.writeParam.ioCompletion	= gSendPort.fWriteCompletionProc;
		gSendPort.fPB.writeParam.bufferLength	= size;
		gSendPort.fPB.writeParam.bufferPtr		= gSendPort.fBuffer;
		gSendPort.fPB.writeParam.more			= false;
		gSendPort.fPB.writeParam.userData		= 0;
		gSendPort.fPB.writeParam.blockCreator	= 0;
		gSendPort.fPB.writeParam.blockType		= 0;

		// Set our new state.  When the Write completes, the completion
		// proc will update our state.

		gSendPort.fState = kPPC_Writing;

		// Start sending the data.

		err = PPCWriteAsync (&gSendPort.fPB.writeParam);
	}
	else
	{
		PRINTF ("Not sending data because the port wasn't connected.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCDataWaiting
// ---------------------------------------------------------------------------

int PPCDataWaiting (void)
{
	return gReceivePort.fDataWaiting;
}


// ---------------------------------------------------------------------------
//		� PPCReceiveData
// ---------------------------------------------------------------------------

long PPCReceiveData (void* data, long size)
{
	long	bytesReceived = gReceivePort.fPB.readParam.actualLength;

	if (bytesReceived > size)
		bytesReceived = size;

	memcpy(data, gReceivePort.fBuffer, bytesReceived);

	gReceivePort.fDataWaiting = false;

	return bytesReceived;
}


// ---------------------------------------------------------------------------
//		� PPCClosePorts
// ---------------------------------------------------------------------------

OSErr PPCClosePorts (void)
{
	PPCDisconnectAPort (&gSendPort);
	PPCDisconnectAPort (&gReceivePort);

	PPCCloseAPort (&gSendPort);
	PPCCloseAPort (&gReceivePort);

	return noErr;
}


// ---------------------------------------------------------------------------
//		� PPCDisconnectAPort
// ---------------------------------------------------------------------------

OSErr PPCDisconnectAPort (PortBundle* bndl)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only disconnect connected ports.

	if (PPCPortConnected (bndl))
	{
		PRINTF ("Disconnecting a port.");

#if 0
		// Fill in the PPCEndPBRec.

		bndl->fPB.endParam.ioCompletion	= NULL;

		// Disconnect the port.

		err = PPCEndSync (&bndl->fPB.endParam);
#else

		// Fill in the PPCEndPBRec.

		{
			PPCEndPBRec	pb;

			pb.ioCompletion	= NULL;
			pb.sessRefNum	= bndl->fPB.startParam.sessRefNum;

			// Disconnect the port.

			err = PPCEndSync (&pb);
		}
#endif

		if (err)
		{
			PRINTF ("Got error disconnecting a port.");
		}

		// Regardless of whether or not we succeeded, mark us
		// as disconnected.

		bndl->fState = kPPC_Opened;
	}
	else
	{
		PRINTF ("Not disconnecting a port because it wasn't connected.");
	}

	return err;
}


// ---------------------------------------------------------------------------
//		� PPCCloseAPort
// ---------------------------------------------------------------------------

OSErr PPCCloseAPort (PortBundle* bndl)
{
	OSErr	err = kPPC_ErrBadState;

	// We can only close opened ports.

	if (PPCPortOpened (bndl))
	{
		PRINTF ("Closing a port.");

#if 0

		// Fill in the PPCClosePBRec.

		bndl->fPB.closeParam.ioCompletion	= NULL;

		// Close the port.

		err = PPCCloseSync (&bndl->fPB.closeParam);

#else

		// Fill in the PPCClosePBRec.
		{
			PPCClosePBRec	pb;

			pb.ioCompletion	= NULL;
			pb.portRefNum	= bndl->fPB.openParam.portRefNum;

			// Close the port.

			err = PPCCloseSync (&pb);
		}
#endif

		if (err)
		{
			PRINTF ("Got error closing a port.");
		}

		// Regardless of whether or not we succeeded, mark us
		// as closed.

		bndl->fState = kPPC_Closed;
	}
	else
	{
		PRINTF ("Not closing a port because it wasn't open.");
	}

	return err;
}


#pragma mark -
#pragma mark --- Status Functions ---

// ---------------------------------------------------------------------------
//		� PPCPortClosed
// ---------------------------------------------------------------------------

int PPCPortClosed (PortBundle* bndl)
{
	return bndl->fState == kPPC_Closed;
}


// ---------------------------------------------------------------------------
//		� PPCPortOpened
// ---------------------------------------------------------------------------

int PPCPortOpened (PortBundle* bndl)
{
	return	bndl->fState == kPPC_Opened ||
			bndl->fState == kPPC_Connecting ||
			bndl->fState == kPPC_Connected ||
			bndl->fState == kPPC_Reading ||
			bndl->fState == kPPC_Writing;
}


// ---------------------------------------------------------------------------
//		� PPCPortConnecting
// ---------------------------------------------------------------------------

int PPCPortConnecting (PortBundle* bndl)
{
	return	bndl->fState == kPPC_Connecting;
}


// ---------------------------------------------------------------------------
//		� PPCPortConnected
// ---------------------------------------------------------------------------

int PPCPortConnected (PortBundle* bndl)
{
	return	bndl->fState == kPPC_Connected ||
			bndl->fState == kPPC_Reading ||
			bndl->fState == kPPC_Writing;
}


// ---------------------------------------------------------------------------
//		� PPCPortReading
// ---------------------------------------------------------------------------

int PPCPortReading (PortBundle* bndl)
{
	return	bndl->fState == kPPC_Reading;
}


// ---------------------------------------------------------------------------
//		� PPCPortWriting
// ---------------------------------------------------------------------------

int PPCPortWriting (PortBundle* bndl)
{
	return	bndl->fState == kPPC_Writing;
}



#pragma mark -
#pragma mark --- Completion Procedures ---

// turn off profiling in this module
#pragma profile off

// ---------------------------------------------------------------------------
//		� PPCInformCompletionProc
// ---------------------------------------------------------------------------

pascal void PPCInformCompletionProc (PPCParamBlockPtr pb)
{
	PortBundle*	bndl = (PortBundle*) (((char*) pb) - offsetof(PortBundle, fPB));

	// If we connected, update our state, and optionally start looking
	// for data packets.

	if (pb->readParam.ioResult == noErr)
	{
		PRINTF ("Finished connecting.");

		// Take us out of kPPC_Connecting mode.

		bndl->fState = kPPC_Connected;

		// If this port is for reading, start listening on it.

		if (bndl->fForReading)
		{
			PRINTF ("Starting listening for data.");

			// Fill in the PPCReadPBRec.

			bndl->fPB.readParam.ioCompletion	= bndl->fReadCompletionProc;
			bndl->fPB.readParam.bufferPtr		= bndl->fBuffer;
			bndl->fPB.readParam.bufferLength	= bndl->fBufferSize;

			// Set our new state.  If the Read fails, the completion
			// proc will update our state.

			bndl->fState = kPPC_Reading;

			// Start listening for a packet.

			(void) PPCReadAsync (&bndl->fPB.readParam);
		}
	}

	// If an error occured, just take us out of kPPC_Connecting mode.

	else
	{
		PRINTF ("Error connecting.");

		bndl->fState = kPPC_Opened;
	}
}


// ---------------------------------------------------------------------------
//		� PPCReadCompletionProc
// ---------------------------------------------------------------------------

pascal void PPCReadCompletionProc (PPCParamBlockPtr pb)
{
	PortBundle*	bndl = (PortBundle*) (((char*) pb) - offsetof(PortBundle, fPB));

	// Take us out of kPPC_Reading mode.

	bndl->fState = kPPC_Connected;

	// If the read went OK, say so.

	if (pb->readParam.ioResult == noErr)
	{
		PRINTF ("Finished reading data.");

		bndl->fDataWaiting = true;

		WakeUpProcess (&bndl->fPSN);
	}

	// If there was an error, disconnect us.  Since we're in the middle of
	// a completion proc, we have to make this call asynchronously.

	else
	{
		PRINTF ("Error reading data; closing session.");

		bndl->fPB.endParam.ioCompletion	= bndl->fEndCompletionProc;

		// Disconnect the port.

		(void) PPCEndAsync (&bndl->fPB.endParam);
	}
}


// ---------------------------------------------------------------------------
//		� PPCWriteCompletionProc
// ---------------------------------------------------------------------------

pascal void PPCWriteCompletionProc (PPCParamBlockPtr pb)
{
	PortBundle*	bndl = (PortBundle*) (((char*) pb) - offsetof(PortBundle, fPB));
	
	// Take us out of kPPC_Writing mode.

	bndl->fState = kPPC_Connected;

	// If the write went OK, nothing else to do.

	if (pb->writeParam.ioResult == noErr)
	{
		PRINTF ("Finished writing data.");
	}

	// If there was an error, disconnect us.  Since we're in the middle of
	// a completion proc, we have to make this call asynchronously.

	else
	{
		PRINTF ("Error writing data; closing session.");

		bndl->fPB.endParam.ioCompletion	= bndl->fEndCompletionProc;

		// Disconnect the port.

		(void) PPCEndAsync (&bndl->fPB.endParam);
	}
}


// ---------------------------------------------------------------------------
//		� PPCEndCompletionProc
// ---------------------------------------------------------------------------

pascal void PPCEndCompletionProc (PPCParamBlockPtr pb)
{
	PortBundle*	bndl = (PortBundle*) (((char*) pb) - offsetof(PortBundle, fPB));

	if (pb->endParam.ioResult == noErr)
	{
		PRINTF ("Finished closing a session.");
	}
	else
	{
		PRINTF ("Error closing a session.");
	}

	// Regardless of whether or not the PPCEnd was successful, put
	// us into disconnected state.

	bndl->fState = kPPC_Opened;

}

