/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once


#include "CProgressPane.h"


// Constants.

const ResIDT kResource_ProgressWindow	= 10021;
const SInt16 kTicksBetweenProgress		= 2;
const SInt16 kTicksToFirstTime			= 100;
const SInt16 kPaneID_StopButton			= 1;
const SInt16 kPaneID_Text				= 2;
const SInt16 kPaneID_Indicator			= 3;

// String constants.

const SInt16 kResource_Strings			= 10001;
const SInt16 kString_ProgressTitle		= 6;
const SInt16 kString_WaitingCaption		= 7;
const SInt16 kString_TransferCaption	= 8;

// Class declarations.

class CProgressWindow : public LListener
{
	public:

								CProgressWindow (void);
		virtual					~CProgressWindow (void);

		void					InitProgress (const SInt16 iTitle, const SInt16 iCaption);

		void					SetCaption (const SInt16 iCaption);
		void					SetCaption (Str255 iCaption);

		void					SetModal (const Boolean iIsModal);

		void					ShowProgress (const Boolean iResetCounter = false);
		void					HideProgress (void);

		Boolean					AdvanceProgress (void);
		Boolean					AdvanceProgress (const SInt32 iCurrent, const SInt32 iStart, const SInt32 iEnd);

		void					ListenToMessage (MessageT iMessage, void* ioParameter);

	private:

		LWindow*				mProgressWindow;
		CProgressPane*			mProgressPane;
		LCaption*				mCaptionPane;
		UInt32					mAdvanceTime;
		Boolean					mFirstTime;
		Boolean					mWasCanceled;
		Boolean					mIsModal;
};
