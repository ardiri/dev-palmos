/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"

#include <PPCToolbox.h>		// PPCParamBlockRec, PPCPortRec
#include <Processes.h>		// ProcessSerialNumber

#ifdef __cplusplus
extern "C" {
#endif

typedef enum PPCState
{
	// States that a PPC port can be in.

	kPPC_Closed,
	kPPC_Opened,
	kPPC_Connecting,
	kPPC_Connected,
	kPPC_Reading,
	kPPC_Writing
} PPCState;


typedef enum PPCError
{
	kPPC_ErrBadState = -23456
} PPCError;


typedef struct PortBundle
{
	PPCPortRec				fOurPortName;
	PPCPortRec				fHisPortName;

	PPCParamBlockRec		fPB;

	Ptr						fBuffer;
	long					fBufferSize;

	PPCState				fState;
	int						fDataWaiting;
	int						fForReading;

	ProcessSerialNumber		fPSN;

	PPCCompUPP				fInformCompletionProc;
	PPCCompUPP				fReadCompletionProc;
	PPCCompUPP				fWriteCompletionProc;
	PPCCompUPP				fEndCompletionProc;
} PortBundle;

extern PortBundle		gSendPort;
extern PortBundle		gReceivePort;

extern const unsigned char*	kEmulatorPortName;
extern const unsigned char*	kDebuggerPortName;
extern const unsigned char*	kToEmulatorPortType;
extern const unsigned char*	kFromEmulatorPortType;


OSErr		PPCOpenPorts		(const unsigned char* ourPortName,
								 const unsigned char* hisPortName,
								 const unsigned char* sendPortType,
								 const unsigned char* receivePortType);
OSErr		PPCOpenAPort		(PortBundle*,
								 const unsigned char* ourPortName,
								 const unsigned char* ourPortType);
OSErr		PPCConnectAPort		(PortBundle*,
								 const unsigned char* hisPortName,
								 const unsigned char* hisPortType);
OSErr		PPCListenForConnect	(PortBundle*);					// Asynchronous
void		PPCSetReadBuffer	(void* buffer, long size);
void		PPCSetWriteBuffer	(void* buffer, long size);
OSErr		PPCListenForData	(PortBundle*);					// Asynchronous
OSErr		PPCSendData			(const void* data, long size);	// Asynchronous
int			PPCDataWaiting		(void);
long		PPCReceiveData		(void* data, long size);	// Clears "data waiting" flag
OSErr		PPCClosePorts		(void);
OSErr		PPCDisconnectAPort	(PortBundle*);
OSErr		PPCCloseAPort		(PortBundle*);

int			PPCPortClosed		(PortBundle*);
int			PPCPortOpened		(PortBundle*);
int			PPCPortConnecting	(PortBundle*);
int			PPCPortConnected	(PortBundle*);
int			PPCPortReading		(PortBundle*);
int			PPCPortWriting		(PortBundle*);

static pascal void		PPCInformCompletionProc(PPCParamBlockPtr pb);
static pascal void		PPCReadCompletionProc(PPCParamBlockPtr pb);
static pascal void		PPCWriteCompletionProc(PPCParamBlockPtr pb);
static pascal void		PPCEndCompletionProc(PPCParamBlockPtr pb);

#ifdef __cplusplus
}
#endif
