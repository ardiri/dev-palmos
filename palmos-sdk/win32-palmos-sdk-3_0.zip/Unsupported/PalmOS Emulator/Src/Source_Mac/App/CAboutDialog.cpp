/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1997-1998
 * John C. Daub.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CAboutDialog.h"
#include "CURLPushButton.h"
#include <UModalDialogs.h>
#include <LPane.h>
#include <LWindow.h>
#include <PP_Messages.h>

#include "ICAPI.h"

const ResIDT	PPob_About	=	10030;

void
CAboutDialog::DoAboutBox(
	LCommander *inSuper )
{
	CAboutDialog	handler (PPob_About, inSuper);

	MessageT theMessage;

	do {
		theMessage = handler.DoDialog();
	} while (theMessage != msg_OK);
}

CAboutDialog::CAboutDialog(
	ResIDT		inDialogResID,
	LCommander	*inSuper )
		: StDialogHandler( inDialogResID, inSuper )
{
}


CAboutDialog::~CAboutDialog()
{
}


void
CAboutDialog::ListenToMessage( MessageT inMessage, void* ioParam )
{
#pragma unused (ioParam)

	mMessage = inMessage;  // store message for DoDialog to return

	if (mMessage >= 1000 && mMessage < 1040)
	{
		OSStatus	err;
		ICInstance	inst;
		
		err = ICStart (&inst, '�LOT');
		if (!err)
		{
			err = ICFindConfigFile (inst, 0, nil);
			if (!err)
			{
				Str255	theURL;

				dynamic_cast<CURLPushButton*>(GetDialog ()->FindPaneByID (mMessage))->GetURL (theURL);

				long	startSel = 0;
				long	endSel = theURL[0];

				err = ICLaunchURL (inst, "\p", (char*) &theURL[1], theURL[0], &startSel, &endSel);
			}

			ICStop (inst);
		}
	}
}
