/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"

#include <LDocApplication.h>
#include <LListener.h>
#include <LPeriodical.h>
#include <LCleanupTask.h>

#include <stdio.h>			// FILE
#include "PPCMessaging.h"	// gReceivePort


// Globals.

class LThread;
class CEmulatorApp;
class CTouchScreen;

extern CEmulatorApp*	gApplication;

// Command and message constants.

const CommandT		kCommand_OpenEmulator		= 10000;
const CommandT		kCommand_CloseEmulator		= 10001;
const CommandT		kCommand_OpenMemory			= 10002;
const CommandT		kCommand_SaveMemory			= 10003;
const CommandT		kCommand_SaveMemoryAs		= 10004;
const CommandT		kCommand_LoadApplication	= 10005;
const CommandT		kCommand_Preferences		= 10006;
const CommandT		kCommand_ResetEmulator		= 10007;
const CommandT		kCommand_Screenshot			= 10008;
const CommandT		kCommand_AboutEmulator		= 10009;
const CommandT		kCommand_DownloadROM		= 10010;
const CommandT		kCommand_HotSync			= 10011;

const CommandT		kCommand_GremlinNew			= 12000;
const CommandT		kCommand_GremlinStep		= 12001;
const CommandT		kCommand_GremlinResume		= 12002;
const CommandT		kCommand_GremlinStop		= 12003;

const CommandT		kCommand_ProfilingStart		= 13000;
const CommandT		kCommand_ProfilingStop		= 13001;
const CommandT		kCommand_ProfilingDump		= 13002;
const CommandT		kCommand_ProfilingTest		= 13003;

const MessageT		kMessage_Save				= 1;
const MessageT		kMessage_DontSave			= 2;
const MessageT		kMessage_OK					= 1;
const MessageT		kMessage_Cancel				= 2;

// Resource constants.

const ResIDT		kResource_SmallEmulator		= 10000;
const ResIDT		kResource_LargeEmulator		= 10001;
const ResIDT		kResource_AskWindow			= 10002;
const ResIDT		kResource_ChooseMemorySize	= 10004;
const ResIDT		kResource_NewGremlinWindow	= 10005;
const ResIDT		kResource_DownloadWindow	= 10020;

// Dialog item constants.

const PaneIDT		kItem_OKButton				= 1;
const PaneIDT		kItem_CancelButton			= 2;

// New Gremlin dialog item constants.

const PaneIDT		kItem_GremlinNumber			= 3;
const PaneIDT		kItem_NumberOfSteps			= 4;
const PaneIDT		kItem_LogEvents				= 5;
const PaneIDT		kItem_LogTraps				= 6;
const PaneIDT		kItem_DisplayElapsedTime	= 7;
const PaneIDT		kItem_ApplicationList		= 8;

// String constants.

const SInt16		kResource_AppStrings		= 10001;
const SInt16		kString_ROMFileName			= 1;
const SInt16		kString_ROMFileNameAlt		= 2;
const SInt16		kString_SavePrompt			= 3;
const SInt16		kString_DefaultMemoryName	= 4;
const SInt16		kString_EmulatorPreferences	= 5;
const SInt16		kString_SaveROMPrompt		= 9;

// Pane constants.

const SInt16		kPaneID_SpeedPopup			= 3;
const SInt16		kPaneID_PortPopup			= 4;

// Other constants.

const SInt16		kTicksUntilTimeout			= 5 * 60;
const SInt16		kTicksUntilProgress			= 25;
const SInt32		kMenuID_Apple				= 128;
const SInt32		kPopupMemorySizes[]			= { 0, -1, 0, 512, 1024, 2048, 4096 };

// Preference definitions.

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=mac68k
#endif

const int			kCurrentPreferenceVersion	= 3;

struct Preferences
{
	UInt16		fPrefVersion;
	SInt32		fDefaultMemorySize;
	Boolean		fAutoLoadOnStartup;
	Boolean		fAutoSaveOnClose;
	Boolean		fAutoSaveOnQuit;
	UInt8		fUnused[8];
	Boolean		fDoubleSize;		// Added in version 2.
	UInt8		fHotSyncPort;		// Added in version 3.
};

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=reset
#endif


// Class declarations.

class	CEmulatorApp :	public LDocApplication,
						public LListener,
						public LPeriodical,
						public LCleanupTask
{
	public:
								CEmulatorApp (void);
		virtual					~CEmulatorApp (void);

		virtual void			Initialize (void);
		virtual void			DoCleanup (void);

		virtual	void			SpendTime (const EventRecord& inMacEvent);
		bool					RunEmulatorAtIdle (bool doRun);

		virtual	Boolean			ObeyCommand (CommandT iCommand, void* iParameters);
		virtual	void			FindCommandStatus (CommandT iCommand, Boolean& oEnabled, Boolean& oUsesMark, Char16& oMark, Str255 oName);
		virtual	void			ListenToMessage (MessageT iMessage, void* ioParameter);
		virtual	Boolean			HandleKeyPress (const EventRecord& iKeyEvent);

		virtual	void			OpenDocument (FSSpec* iFileSpec);
		virtual	void			ChooseDocument (void);

		LWindow*				GetEmulatorWindow (void) { return fEmulatorWindow; }
		CTouchScreen*			GetLCDScreen (void)
								{
									if (!fLCDScreen)
										FindLCDScreen ();
									return fLCDScreen;
								}
		void					FindLCDScreen (void);
		bool					IsScreenDoubleSize ();

		Int8					GetHotSyncPort () const;

		OSErr					OpenPorts (void);
		void					ListenForPacket (void);
		bool					ReceivedPacket (void) { return gReceivePort.fDataWaiting; }
		void					HandlePacket (void);
		OSErr					SendPacket (const void* pkt, long size);
		OSErr					ClosePorts (void);

	protected:

		virtual void			StartUp (void);

		MessageT				AskToSave (void);

		void					About (void);

		void					NewGremlin (void);

		void					LoadPreferences (void);
		void					SavePreferences (void);
		void					EditPreferences (void);

		void					NewEmulator (const Boolean iLoadMemory, const Boolean iShowDialog);
		void					DisposeEmulator (const Boolean iSaveMemory, const Boolean iShowDialog, const Boolean iDisposeAlias = true);

		FILE*					OpenAsFILE(AliasHandle& ioFileAlias, Boolean iForLoading, Boolean iShowDialog);
		FILE*					OpenAsFILE(const FSSpec& iFileSpec, Boolean iForLoading);
		FILE* 					OpenROMFile();

		void					DownloadROM (void);

	private:

		LWindow*				fEmulatorWindow;
		CTouchScreen*			fLCDScreen;

#if USE_THREADS
		static LThread*			fCPUThread;
#endif
		Preferences				fPreferences;
		AliasHandle				fMemoryFileAlias;
		bool					fRunEmulatorAtIdle;

		bool					fHotSyncDown;
		UInt32					fHotSyncDownTime;
};
