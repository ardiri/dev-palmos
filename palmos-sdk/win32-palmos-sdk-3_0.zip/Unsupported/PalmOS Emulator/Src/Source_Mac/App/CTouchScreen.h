/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once


// Constants.

const PaneIDT	kTouchScreenID		= 'TScr';
const SInt16	kWidth_LCDScreen	= 160;	// !!! Should make these common
const SInt16	kHeight_LCDScreen	= 160;
const SInt16	kWidth_SilkScreen	= 160;
const SInt16	kHeight_SilkScreen	= 60;

// Class declarations.

class CTouchScreen : public LPane
{
	public:

		enum { class_ID = 'CLCD' };

								CTouchScreen (LStream* iStream) : LPane (iStream) {}
		virtual					~CTouchScreen (void) {}

		static CTouchScreen*	CreateTouchScreenStream (LStream* iStream) { return (new CTouchScreen (iStream)); }

		Point					GetMouse (void);
		void					GetScreenRect (Rect& oScreenRect);

		void					RefreshScreen (void);
		void					SaveScreen (const FSSpec&);

	private:

								CTouchScreen (void) {}
								CTouchScreen (const SPaneInfo& iPaneInfo) : LPane (iPaneInfo) {}

		void					DrawSelf (void);
		void					ClickSelf (const SMouseDownEvent &iMouseEvent);
		void					EventMouseUp (const EventRecord &iMouseEvent);
		void					AdjustCursorSelf (Point, const EventRecord&) {}

		void					InitPixMap(PixMap& pixMap, void* theBits,
									int width, int height, int depth,
									const RGBColor& foreground,
									const RGBColor& background);
};
