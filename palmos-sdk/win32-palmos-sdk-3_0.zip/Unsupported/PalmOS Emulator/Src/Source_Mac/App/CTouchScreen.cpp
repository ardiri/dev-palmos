/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CTouchScreen.h"
#include "CEmulatorApp.h"
#include "CPU_REG.h"
#include "Platform.h"

#include <stddef.h>		// offsetof

const RGBColor	kRGB_ScreenGreen	= { 0x7B7B, 0x8C8C, 0x5A5A };
//const RGBColor	kRGB_ScreenGreen		= { 0x5454, 0x6C6C, 0x5555 };	// Used in Windows version
const RGBColor	kRGB_ScreenLightGreen	= { 0x6464, 0xF0F0, 0xDCDC };
const RGBColor	kRGB_ScreenWhite		= { 0xFFFF, 0xFFFF, 0xFFFF };
const RGBColor	kRGB_ScreenBlack		= { 0x0000, 0x0000, 0x0000 };


// ---------------------------------------------------------------------------
//		� CTouchScreen::DrawSelf
// ---------------------------------------------------------------------------

void CTouchScreen::DrawSelf (void)
{
	// Mark some innocuous change.  Saying that the backlight has
	// changed will force a redraw, but won't cause all of the
	// buffer copying to go on.

	Screen::RecordChange (kScreen_BacklightChanged);

	this->RefreshScreen ();
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::ClickSelf
// ---------------------------------------------------------------------------
// Notifies the emulated CPU of the mouse down event.

void CTouchScreen::ClickSelf (const SMouseDownEvent &iMouseEvent)
{
	Point aLocation = iMouseEvent.whereLocal;

	// Convert the point to pane coordinates.

	aLocation.h -= mFrameLocation.h;
	aLocation.v -= mFrameLocation.v;

	// Scale the pen by half if the screen is double size.

	if (gApplication->IsScreenDoubleSize ())
	{
		aLocation.h /= 2;
		aLocation.v /= 2;
	}

	// Make sure the mouse location is in bounds.

	if (aLocation.h < 1)
		aLocation.h = 1;
	else if (aLocation.h > kWidth_LCDScreen)
		aLocation.h = kWidth_LCDScreen;

	if (aLocation.v < 1)
		aLocation.v = 1;
	else if (aLocation.v > kHeight_LCDScreen + kHeight_SilkScreen)
		aLocation.v = kHeight_LCDScreen + kHeight_SilkScreen;

	// Send the event to the emulated CPU.

	Hardware::PenEvent (true, aLocation.h, aLocation.v);
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::EventMouseUp
// ---------------------------------------------------------------------------
// Notifies the emulated CPU of the mouse up event.

void CTouchScreen::EventMouseUp (const EventRecord &iMouseEvent)
{
	LPane::EventMouseUp (iMouseEvent);

	Point aLocation = iMouseEvent.where;
	GlobalToPortPoint (aLocation);

	// Convert the point to pane coordinates.

	aLocation.h -= mFrameLocation.h;
	aLocation.v -= mFrameLocation.v;

	// Scale the pen by half if the screen is double size.

	if (gApplication->IsScreenDoubleSize ())
	{
		aLocation.h /= 2;
		aLocation.v /= 2;
	}

	// Make sure the mouse location is in bounds.

	if (aLocation.h < 1)
		aLocation.h = 1;
	else if (aLocation.h > kWidth_LCDScreen)
		aLocation.h = kWidth_LCDScreen;

	if (aLocation.v < 1)
		aLocation.v = 1;
	else if (aLocation.v > kHeight_LCDScreen + kHeight_SilkScreen)
		aLocation.v = kHeight_LCDScreen + kHeight_SilkScreen;

	// Send the event to the emulated CPU.

	Hardware::PenEvent (false, aLocation.h, aLocation.v);
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::GetMouse
// ---------------------------------------------------------------------------
// Returns the current mouse location in coordinates that are local to the
// touchscreen.

Point CTouchScreen::GetMouse (void)
{
	FocusDraw ();

	Point aLocation;
	::GetMouse (&aLocation);

	// Convert the point to pane coordinates.

	aLocation.h -= mFrameLocation.h;
	aLocation.v -= mFrameLocation.v;

	// Scale the pen by half if the screen is double size.

	if (gApplication->IsScreenDoubleSize ())
	{
		aLocation.h /= 2;
		aLocation.v /= 2;
	}

	// Make sure the mouse location is in bounds.

	if (aLocation.h < 1)
		aLocation.h = 1;
	else if (aLocation.h > kWidth_LCDScreen)
		aLocation.h = kWidth_LCDScreen;

	if (aLocation.v < 1)
		aLocation.v = 1;
	else if (aLocation.v > kHeight_LCDScreen + kHeight_SilkScreen)
		aLocation.v = kHeight_LCDScreen + kHeight_SilkScreen;

	return (aLocation);
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::GetScreenRect
// ---------------------------------------------------------------------------
// Returns the rectangle, in window coordinates, that encloses the LCD
// portion of the touch-screen.

void CTouchScreen::GetScreenRect (Rect& oScreenRect)
{
	FocusDraw ();
	::SetRect (&oScreenRect, 0, 0, 0, 0);
	CalcPortFrameRect (oScreenRect);
	oScreenRect.right = oScreenRect.left + kWidth_LCDScreen * (gApplication->IsScreenDoubleSize () ? 2 : 1);
	oScreenRect.bottom = oScreenRect.top + kHeight_LCDScreen * (gApplication->IsScreenDoubleSize () ? 2 : 1);
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::RefreshScreen
// ---------------------------------------------------------------------------

void CTouchScreen::RefreshScreen (void)
{
	bool		lcdOn		= Screen::LCDIsOn ();
	bool		backlightOn	= Screen::BacklightIsOn ();
	RGBColor	background	= kRGB_ScreenWhite;
	RGBColor	foreground	= kRGB_ScreenBlack;

	void*		theBits;
	int			width, height, depth;

	// Get the right background color.

	if (true /* Settings.Realistic */)
	{
		if (lcdOn && backlightOn)
		{
			background = kRGB_ScreenLightGreen;
		}
		else
		{
			background = kRGB_ScreenGreen;
		}
	}

	// If the screen is off, just paint the background color.

	if (!lcdOn)
	{
		this->FocusDraw ();
		RGBBackColor (&background);

		Rect	screenBounds;
		this->GetScreenRect (screenBounds);

		EraseRect (&screenBounds);
	}

	// Otherwise, if the screen is on, get the bits. Screen_GetBits will
	// return TRUE if something significant has changed since the last
	// time we called it.

	else if (Screen::GetBits (&theBits, &width, &height, &depth))
	{
		// Fill in a pixMap for blitting from.

		PixMap	pixMap;
		this->InitPixMap (pixMap, theBits, width, height, depth,
							foreground, background);

		// Get the destination bounds and port.

		Rect	screenBounds;
		this->GetScreenRect (screenBounds);
		GrafPtr	screenPort = this->GetMacPort ();

		// Prepare to draw into it.

		this->FocusDraw ();

		RGBBackColor (&kRGB_ScreenWhite);
		RGBForeColor (&kRGB_ScreenBlack);

		// And, finally, draw into it.

		CopyBits (	(BitMap*) &pixMap, &screenPort->portBits,
					&pixMap.bounds, &screenBounds,
					srcCopy, NULL);

		// And, finally finally, clean up

		DisposeHandle ((Handle) pixMap.pmTable);
	}
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::SaveScreen
// ---------------------------------------------------------------------------

void CTouchScreen::SaveScreen (const FSSpec& fileSpec)
{
	PicHandle	picHandle = NULL;
	short		refNum = 0;

	try
	{
		// Get information about the screen.

		void*		theBits;
		int			width, height, depth;

		Screen::GetBits (&theBits, &width, &height, &depth);

		// Create the PicHandle that will contain the picture.

		this->FocusDraw ();

		OpenCPicParams	picHeader =
		{
			0, 0, height, width,
			0x00480000, 0x00480000,
			-2, 0, 0
		};

		picHandle = OpenCPicture (&picHeader);
		ThrowNotify_IfNil (picHandle, kError_DefaultError, kDefaultException);

		// Fill in a pixMap for blitting from.

		PixMap	pixMap;
		this->InitPixMap (pixMap, theBits, width, height, depth,
							kRGB_ScreenBlack, kRGB_ScreenWhite);

		// Prepare to draw into it.

		GrafPtr	screenPort = this->GetMacPort ();

		RGBBackColor (&kRGB_ScreenWhite);
		RGBForeColor (&kRGB_ScreenBlack);

		// Draw into ourselves, just to get the bits recorded
		// into the picture.

		CopyBits (	(BitMap*) &pixMap, &screenPort->portBits,
					&pixMap.bounds, &pixMap.bounds,
					srcCopy, NULL);

		// Clean up the pixmap.

		DisposeHandle ((Handle) pixMap.pmTable);

		ClosePicture ();

		// Create the file we'll be writing to.  Create it as
		// a TeachText/SimpleText picture file. If the file already
		// exists, write over it.

		OSErr	err = FSpCreate (&fileSpec, 'ttxt', 'PICT', smSystemScript);
		if (err != dupFNErr)
			ThrowNotify_IfError (err, kError_DefaultError, err);

		// Open up the file.

		err = FSpOpenDF (&fileSpec, fsWrPerm, &refNum);
		ThrowNotify_IfError (err, kError_DefaultError, err);

		// Set the file to be at least 512 bytes long so that we
		// can set the write mark to that location.

		err = SetEOF (refNum, 512);
		ThrowNotify_IfError (err, kError_DefaultError, err);

		// Position ourselves to be 512 bytes into the file. PICT
		// files start with a 512 byte header (which can be anything;
		// but we don't use it here).

		err = SetFPos (refNum, fsFromStart, 512);
		ThrowNotify_IfError (err, kError_DefaultError, err);

		// Write out the PICT.

		long	size = GetHandleSize ((Handle) picHandle);
		err = FSWrite (refNum, &size, *picHandle);
		ThrowNotify_IfError (err, kError_DefaultError, err);
	}
	catch(...)
	{
	}
	
	// Close the file and dispose of the picture.

	if (refNum)
		FSClose (refNum);

	if (picHandle)
		KillPicture (picHandle);
}


// ---------------------------------------------------------------------------
//		� CTouchScreen::InitPixMap
// ---------------------------------------------------------------------------

void CTouchScreen::InitPixMap(PixMap& pixMap, void* theBits,
					int width, int height, int depth,
					const RGBColor& foreground, const RGBColor& background)
{
	// Clear everything out in case we fail.

	memset(&pixMap, 0, sizeof(PixMap));

	// Set up a color table to ramp from the background color to
	// the foreground color.

	long	numColors = 1 << depth;

	CTabHandle	cTable = (CTabHandle) NewHandle(
										offsetof(ColorTable, ctTable) +
										numColors * sizeof(ColorSpec));

	ThrowNotify_IfNil(cTable, kError_DefaultError, kDefaultException);

	(**cTable).ctSeed = GetCTSeed();
	(**cTable).ctFlags = 0;
	(**cTable).ctSize = numColors - 1;

	long	br = ((long) background.red);
	long	bg = ((long) background.green);
	long	bb = ((long) background.blue);

	long	dr = ((long) foreground.red) - ((long) background.red);
	long	dg = ((long) foreground.green) - ((long) background.green);
	long	db = ((long) foreground.blue) - ((long) background.blue);

	for (int color = 0; color < numColors; ++color)
	{
		(**cTable).ctTable[color].value		= color;
		(**cTable).ctTable[color].rgb.red	= (unsigned short) (br + dr * color / (numColors - 1));
		(**cTable).ctTable[color].rgb.green	= (unsigned short) (bg + dg * color / (numColors - 1));
		(**cTable).ctTable[color].rgb.blue	= (unsigned short) (bb + db * color / (numColors - 1));
	}

	// Now fill in all the PixMap fields.

	Rect	emulatorBounds;
	::SetRect(&emulatorBounds, 0, 0, width, height);

	pixMap.baseAddr = (Ptr) theBits;
	pixMap.rowBytes = (width * depth / 8) | 0x8000;
	pixMap.bounds = emulatorBounds;
	pixMap.pmVersion = 0;
	pixMap.packType = 0;
	pixMap.packSize = 0;
	pixMap.hRes = 0x00480000;
	pixMap.vRes = 0x00480000;
	pixMap.pixelType = 0;
	pixMap.pixelSize = depth;
	pixMap.cmpCount = 1;
	pixMap.cmpSize = depth;
	pixMap.planeBytes = 0;
	pixMap.pmTable = cTable;
	pixMap.pmReserved = 0;
}
