/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

/*===================================================================================*\

	Comments:	CCicnButton is a sub-class of LCicnButton that broadcasts
				kCmd_CicnButtonUp and kCmd_CicnButtonDown messages when the
				button changes states.  Note: Although CCicnButton is a subclass
				of LControl, it doesn't respond to mouse events in the way that
				other controls do.  CCicnButtons are always down while the mouse
				is down (i.e. they don't change state when the mouse enters or
				exits the control area).  Also, unlike the standard LCicnButton,
				other processes may continue to function while the button is
				being pressed.  These modifications make CCicnButtons function
				more like the hardware buttons on a Palm OS device.

\*===================================================================================*/


#include "CCicnButton.h"


// ---------------------------------------------------------------------------
//		� CCicnButton::ClickSelf
// ---------------------------------------------------------------------------
// Processes a click in the button by displaying the button down icon.  The
// kCmd_CicnButtonDown message is broadcast to any listeners.

void CCicnButton::ClickSelf (const SMouseDownEvent& iMouseEvent)
{
#pragma unused (iMouseEvent)

	if (FocusDraw ())
		HotSpotAction (0, true, false);

	SInt32 aValue = mValueMessage;
	BroadcastMessage (kCmd_CicnButtonDown, (void*) &aValue);
}


// ---------------------------------------------------------------------------
//		� CCicnButton::EventMouseUp
// ---------------------------------------------------------------------------
// Processes a mouse up in the button by displaying the button up icon.  The
// kCmd_CicnButtonUp message is broadcast to any listeners.

void CCicnButton::EventMouseUp (const EventRecord &iMouseEvent)
{
#pragma unused (iMouseEvent)

	if (FocusDraw ())
		HotSpotAction (0, false, true);

	SInt32 aValue = mValueMessage;
	BroadcastMessage (kCmd_CicnButtonUp, (void*) &aValue);
}
