/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "USerialPort.h"


// Globals.

SInt16		gInReference		= 0;
SInt16		gOutReference		= 0;
Boolean		gCommEstablished	= false;

char		gInBuffer[4096];
char		gOutBuffer[4096];

// ---------------------------------------------------------------------------
//		� Comm_Initialize
// ---------------------------------------------------------------------------
// Opens the communications port.

SInt16 Comm_Initialize (SInt16	iPort,
						SInt16	iBaud)
{
	// Exit if communications have already been established.

	OSErr	aError;
	SInt16	aSettings;
	SerShk	aHandshake;

	if (gCommEstablished)
		return kError_CommOpen;

	// Clear the globals.

	gCommEstablished	= false;

	aError			= 0;
	gInReference	= iPort;
	gOutReference	= iPort - 1;

	// Open the modem port.

	if (iPort == kPort_Modem)
	{
		aError = OpenDriver ("\p.AIn", &gInReference);
		if (aError != 0)
			return kError_CantOpenPort;

		aError = OpenDriver ("\p.AOut", &gOutReference);
		if (aError != 0)
		{
			CloseDriver (gInReference);
			return kError_CantOpenPort;
		}
	}

	// Open the printer port.

	else if (iPort == kPort_Printer)
	{
		aError = OpenDriver ("\p.BIn", &gInReference);
		if (aError != 0)
			return kError_CantOpenPort;

		aError = OpenDriver ("\p.BOut", &gOutReference);
		if (aError != 0)
		{
			CloseDriver (gInReference);
			return kError_CantOpenPort;
		}
	}

	// Invalid port.

	else
		return (kError_InvalidPort);

	// Make sure the port was opened.

	if (gInReference != iPort || gOutReference != iPort - 1)
	{
		CloseDriver (gInReference);
		CloseDriver (gOutReference);
		return kError_CantOpenPort;
	}

	// Initialize the handshake settings.

	aHandshake.fXOn = aHandshake.xOn	= aHandshake.xOff = 0;
	aHandshake.errs = aHandshake.evts	= aHandshake.fInX = 0;
	aHandshake.fCTS = aHandshake.fDTR = 1;

	aError = SerHShake (gInReference, &aHandshake);
	if (aError != 0)
	{
		CloseDriver (gInReference);
		CloseDriver (gOutReference);
		return kError_CantOpenPort;
	}

	aError = SerHShake (gOutReference, &aHandshake);
	if (aError != 0)
	{
		CloseDriver (gInReference);
		CloseDriver (gOutReference);
		return kError_CantOpenPort;
	}

	// Initialize the port settings.

	aSettings = iBaud + stop10 + noParity + data8;

	aError = SerReset (gInReference, aSettings);
	if (aError != 0)
	{
		CloseDriver (gInReference);
		CloseDriver (gOutReference);
		return kError_CantOpenPort;
	}

	aError = SerReset (gOutReference, aSettings);
	if (aError != 0)
	{
		CloseDriver (gInReference);
		CloseDriver (gOutReference);
		return kError_CantOpenPort;
	}

	// Give us some bigger buffers.  We have a hard time handling
	// > 256 byte packets with the defaults.

	aError = SerSetBuf (gInReference, gInBuffer, sizeof (gInBuffer));
	aError = SerSetBuf (gOutReference, gOutBuffer, sizeof (gOutBuffer));

	gCommEstablished = true;

	return 0;
}


// ---------------------------------------------------------------------------
//		� Comm_Dispose
// ---------------------------------------------------------------------------
// Closes the communications port.

void Comm_Dispose (void)
{
	// Exit if communications have not been established.

	if (!gCommEstablished)
		return;

	// Close the serial port.

	UInt32 aFakeBuffer;
	SerSetBuf (gInReference, (Ptr) &aFakeBuffer, 0);

	CloseDriver (gInReference);
	CloseDriver (gOutReference);

	gInReference = 0;
	gOutReference = 0;

	// Clear the globals.

	gCommEstablished	= false;
}
