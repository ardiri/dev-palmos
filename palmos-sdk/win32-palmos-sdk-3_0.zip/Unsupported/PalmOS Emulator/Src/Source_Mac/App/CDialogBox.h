// ===========================================================================
//	CDialogBox.h			   �1993-1996 Metrowerks Inc. All rights reserved.
// ===========================================================================

#ifndef _H_CDialogBox
#define _H_CDialogBox
#pragma once

#if defined(__CFM68K__) && !defined(__USING_STATIC_LIBS__)
	#pragma import on
#endif

#include <LWindow.h>
#include <LListener.h>

class	LStdButton;
class	LDefaultOutline;
class	LAction;

class	CDialogBox : public LWindow,
					 public LListener {
public:
	enum { class_ID = 'dlog' };
	static CDialogBox*	CreateDialogBoxStream(LStream *inStream);

					CDialogBox();
					CDialogBox(SWindowInfo &inWindowInfo);
					CDialogBox(ResIDT inWINDid, Uint32 inAttributes,
								LCommander *inSuperCommander);
					CDialogBox(LStream *inStream);
	virtual			~CDialogBox();
					
	virtual Boolean	HandleKeyPress(const EventRecord &inKeyEvent);
	virtual void	ListenToMessage(MessageT inMessage, void *ioParam);
	
	virtual void	SetDefaultButton(PaneIDT inButtonID);
	virtual void	SetCancelButton(PaneIDT inButtonID);

protected:
	PaneIDT			mDefaultButtonID;
	PaneIDT			mCancelButtonID;
	LDefaultOutline	*mDefaultOutline;
	
	virtual void	FinishCreateSelf();
};


struct SCDialogResponse {
	CDialogBox	*dialogBox;
	void		*messageParam;
};

#if defined(__CFM68K__) && !defined(__USING_STATIC_LIBS__)
	#pragma import reset
#endif

#endif