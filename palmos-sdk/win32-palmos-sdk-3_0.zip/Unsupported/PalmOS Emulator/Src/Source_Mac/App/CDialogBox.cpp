// ===========================================================================
//	CDialogBox.cp			   �1993-1996 Metrowerks Inc. All rights reserved.
// ===========================================================================
//
//	A DialogBox is a Window that has an optional Default and/or Cancel
//	Button. Return and Enter are keyboard equivalents for the Default
//	Button, which has a DefaultOutline drawn around it. Escape and
//	Command-Period are keyboard equivalents for the Cancel Button.
//
//	The DialogBox is a Listener to these buttons, which must derived from
//	LControl. However, the DialogBox does not attach any special meaning
//	to the buttons. The user must give meaning to these buttons by assigning
//	them an appropriate message (the one broadcasted when they are clicked).
//
//	A DialogBox handles negative message numbers by relaying them to its
//	SuperCommander as commands to ObeyCommand(). This allows any
//	Commander to create a DialogBox and then to receive as commands
//	the messages sent by the DialogBox's Broadcasters (which are usually
//	Controls such as buttons).

#ifdef PowerPlant_PCH
#include PowerPlant_PCH
#endif

#include "CDialogBox.h"
#include <LStdControl.h>
#include <LStream.h>
#include <UReanimator.h>

#include <UKeyFilters.h>
#include <PP_KeyCodes.h>
#include <PP_Messages.h>


// ---------------------------------------------------------------------------
//		� CreateDialogBoxStream [static]
// ---------------------------------------------------------------------------
//	Return a new DialogBox object initialized using data from a Stream

CDialogBox*
CDialogBox::CreateDialogBoxStream(
	LStream	*inStream)
{
	return (new CDialogBox(inStream));
}


// ---------------------------------------------------------------------------
//		� CDialogBox
// ---------------------------------------------------------------------------
//	Default Constructor

CDialogBox::CDialogBox()
{
	mDefaultButtonID = PaneIDT_Undefined;
	mCancelButtonID = PaneIDT_Undefined;
	mDefaultOutline = nil;
}


// ---------------------------------------------------------------------------
//		� CDialogBox(SWindowInfo&)
// ---------------------------------------------------------------------------
//	Construct DialogBox from the data in a struct

CDialogBox::CDialogBox(
	SWindowInfo	&inWindowInfo)
		: LWindow(inWindowInfo)
{
	mDefaultButtonID = PaneIDT_Undefined;
	mCancelButtonID = PaneIDT_Undefined;
	mDefaultOutline = nil;
}


// ---------------------------------------------------------------------------
//		� CDialogBox(ResIDT, Uint32, LCommander*)
// ---------------------------------------------------------------------------
//	Construct a DialogBox from a WIND Resource with the specified attributes
//	and SuperCommander
//
//	Side Effect: Created window becomes the current port

CDialogBox::CDialogBox(
	ResIDT		inWINDid,
	Uint32		inAttributes,
	LCommander	*inSuper)
		: LWindow(inWINDid, inAttributes, inSuper)
{
	mDefaultButtonID = PaneIDT_Undefined;
	mCancelButtonID = PaneIDT_Undefined;
	mDefaultOutline = nil;
}


// ---------------------------------------------------------------------------
//		� CDialogBox(LStream*)
// ---------------------------------------------------------------------------
//	Construct a DialogBox from the data in a Stream

CDialogBox::CDialogBox(
	LStream	*inStream)
		: LWindow(inStream)
{
	inStream->ReadData(&mDefaultButtonID, sizeof(PaneIDT));
	inStream->ReadData(&mCancelButtonID, sizeof(PaneIDT));
	mDefaultOutline = nil;
}


// ---------------------------------------------------------------------------
//		� ~CDialogBox
// ---------------------------------------------------------------------------
//	Destructor

CDialogBox::~CDialogBox()
{
}


// ---------------------------------------------------------------------------
//		� FinishCreateSelf
// ---------------------------------------------------------------------------
//	Finish creation by linking DialogBox as a Listener to its Default
//	and Cancel Buttons.

void
CDialogBox::FinishCreateSelf()
{
	SetDefaultButton(mDefaultButtonID);
	SetCancelButton(mCancelButtonID);
}


// ---------------------------------------------------------------------------
//		� HandleKeyPress
// ---------------------------------------------------------------------------
//	DialogBox handles keyboard equivalents for hitting the Default and
//	Cancel Buttons.
//
//		Default Button: Enter, Return
//		Cancel Button:  Escape, Command-Period

Boolean
CDialogBox::HandleKeyPress(
	const EventRecord	&inKeyEvent)
{
	Boolean		keyHandled = false;
	LControl	*keyButton = nil;
	
	switch (inKeyEvent.message & charCodeMask) {
	
		case char_Enter:
		case char_Return:
			keyButton = (LControl*) FindPaneByID(mDefaultButtonID);
			break;
			
		case char_Escape:
			if ((inKeyEvent.message & keyCodeMask) == vkey_Escape) {
				keyButton =  (LControl*) FindPaneByID(mCancelButtonID);
			}
			break;

		default:
			if (UKeyFilters::IsCmdPeriod(inKeyEvent)) {
				keyButton =  (LControl*) FindPaneByID(mCancelButtonID);
			} else {
				keyHandled = LWindow::HandleKeyPress(inKeyEvent);
			}
			break;
	}
			
	if (keyButton != nil) {
		keyButton->SimulateHotSpotClick(kControlButtonPart);
		keyHandled = true;
	}
	
	return keyHandled;
}


// ---------------------------------------------------------------------------
//		� ListenToMessage
// ---------------------------------------------------------------------------
//	Respond to messages from Broadcasters
//
//	DialogBox responds to the cmd_Close message by deleting itself.
//
//	Also, negative message numbers are relayed to the ProcessCommand().
//	This allows subclasses of DialogBox to handle messages as commands.
//	Or, if you don't want to subclass DialogBox, the SuperCommander
//	of the DialogBox will receive the messages as commands.

void
CDialogBox::ListenToMessage(
	MessageT	inMessage,
	void		*ioParam)
{
	if (inMessage == cmd_Close) {
		DoClose();
	
	} else if (inMessage < 0) {
									// Relay message to supercommander
		if (GetSuperCommander() != nil) {
			SCDialogResponse	theResponse;
			theResponse.dialogBox = this;
			theResponse.messageParam = ioParam;
			ProcessCommand(inMessage, &theResponse);
		}
	}
}


// ---------------------------------------------------------------------------
//		� SetDefaultButton
// ---------------------------------------------------------------------------
//	Specify the PaneID of the default button of a DialogBox. The default
//	button must be derived from LControl.
//
//	The default button has a default outline around it and certain
//	keyboard equivalents (Return and Enter) simulate a click inside it

void
CDialogBox::SetDefaultButton(
	PaneIDT	inButtonID)
{
	mDefaultButtonID = inButtonID;
	
	if (mDefaultOutline != nil) {	// Remove former default outline
		mDefaultOutline->Refresh();
		delete mDefaultOutline;
		mDefaultOutline = nil;
	}
	
	LControl	*theButton = (LControl*) FindPaneByID(inButtonID);
	if (theButton != nil) {
		theButton->AddListener(this);
		
		/*
									// Create new default outline
		mDefaultOutline = new LDefaultOutline(theButton);
		mDefaultOutline->Refresh();
		*/
	}
}


// ---------------------------------------------------------------------------
//		� SetCancelButton
// ---------------------------------------------------------------------------
//	Specify the PaneID of the cancel button of a DialogBox. The cancel
//	button must be derived from LControl.
//
//	Certain keyboard equivalents (Escape and Command-Period) simulate
//	a click inside the cancel button

void
CDialogBox::SetCancelButton(
	PaneIDT	inButtonID)
{
	mCancelButtonID = inButtonID;
	
	LControl	*theButton = (LControl*) FindPaneByID(inButtonID);
	if (theButton != nil) {
		theButton->AddListener(this);
	}
}