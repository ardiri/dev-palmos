/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once


// Constants.

const UInt16	kPatternBits[]		= { 0x01FE, 0x00FF, 0x807F, 0xC03F,
										0xE01F, 0xF00F, 0xF807, 0xFC03,
										0xFE01, 0xFF00, 0x7F80, 0x3FC0,
										0x1FE0, 0x0FF0, 0x07F8, 0x03FC };
const RGBColor	kProgressGray		= { 0x4444, 0x4444, 0x4444 };
const RGBColor	kProgressBlue		= { 0xCCCC, 0xCCCC, 0xFFFF };
const SInt16	kType_Unmeasured	= 1;
const SInt16	kType_Measured		= 2;

// Class declarations.

class CProgressPane : public LPane
{
	public:
								enum { class_ID = 'CPrP' };

								CProgressPane (LStream* iStream);
		virtual					~CProgressPane (void) {}

		virtual void			AdvanceProgress (void);
		virtual void			AdvanceProgress (const SInt32 iCurrent, const SInt32 iStart, const SInt32 iEnd);

	protected:
								CProgressPane (void);

		virtual void			DrawSelf (void);

	private:
		SInt16					mProgressType;
		SInt32					mCurrent;
		SInt32					mStart;
		SInt32					mEnd;
		SInt16					mOffset;
		BitMap					mPattern;
};
