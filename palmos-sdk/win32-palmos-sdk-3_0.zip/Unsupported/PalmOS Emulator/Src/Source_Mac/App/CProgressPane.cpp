/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CProgressPane.h"


// ---------------------------------------------------------------------------
//		� CProgressPane::CProgressPane
// ---------------------------------------------------------------------------

CProgressPane::CProgressPane (LStream* iStream) : LPane (iStream)
{
	mProgressType = kType_Unmeasured;
	mCurrent = 0;
	mStart = 0;
	mEnd = 0;
	mOffset = 0;

	mPattern.rowBytes = 2;
	mPattern.baseAddr = (Ptr) kPatternBits;
	::SetRect (&mPattern.bounds, 0, 0, 16, 16);
}


// ---------------------------------------------------------------------------
//		� CProgressPane::DrawSelf
// ---------------------------------------------------------------------------

void CProgressPane::DrawSelf (void)
{
	// Get the draw settings.

	Rect aFrame;
	CalcLocalFrameRect (aFrame);
	StColorPenState::Normalize ();
	GrafPtr aPort = GetMacPort ();

	// Frame the pane.

	::FrameRect (&aFrame);
	::InsetRect (&aFrame, 1, 1);

	if (aPort == NULL)
		return;

	StColorState aColorSave;
	StClipRgnState aClipSave (aFrame);

	// Set the progress colors.

	::RGBForeColor (&kProgressGray);
	::RGBBackColor (&kProgressBlue);

	if (mProgressType == kType_Measured)
	{
		if (mStart >= mEnd)
			::EraseRect (&aFrame);
		else
		{
			// Paint the "completed" rectangle.

			float aCurrentPixel = float (aFrame.right - aFrame.left) / float (mEnd - mStart);
			aCurrentPixel *= float (mCurrent - mStart);

			Rect aRect = aFrame;
			aRect.right = aRect.left + aCurrentPixel;
			::PaintRect (&aRect);

			// Paint the "remaining" rectangle.

			aRect.left = aRect.right;
			aRect.right = aFrame.right;
			::EraseRect (&aRect);
		}
	}

	else
	{
		// Tile the pattern bitmap starting from the upper left.

		Rect aOffsetRect = { aFrame.top, aFrame.left - 16 + mOffset, aFrame.top + 16, aFrame.left + mOffset };

		while (aOffsetRect.top < aFrame.bottom)
		{
			while (aOffsetRect.left < aFrame.right)
			{
				// Draw the pattern at the current location.

				::CopyBits (&mPattern, &aPort->portBits, &mPattern.bounds, &aOffsetRect, srcCopy, NULL);

				// Move the pattern to the next column.

				::OffsetRect (&aOffsetRect, 16, 0);
			}

			// Move the pattern to the next row.

			::SetRect (&aOffsetRect, aFrame.left - 16 + mOffset, aOffsetRect.top + 16, aFrame.left + mOffset, aOffsetRect.bottom + 16);
		}
	}
}


// ---------------------------------------------------------------------------
//		� CProgressPane::AdvanceProgress
// ---------------------------------------------------------------------------
// Increments the unmeasured progress indicator and redraws the pane.

void CProgressPane::AdvanceProgress (void)
{
	mProgressType = kType_Unmeasured;

	mOffset = (mOffset + 2) % 16;

	Draw (NULL);
}


// ---------------------------------------------------------------------------
//		� CProgressPane::AdvanceProgress
// ---------------------------------------------------------------------------
// Increments the measured progress indicator and redraws the pane.

void CProgressPane::AdvanceProgress (	const SInt32	iCurrent,
										const SInt32	iStart,
										const SInt32	iEnd)
{
	if ((mProgressType != kType_Measured) ||
			(mCurrent != iCurrent) ||
			(mStart != iStart) ||
			(mEnd != iEnd))
	{
		mProgressType = kType_Measured;

		mCurrent = iCurrent;
		mStart = iStart;
		mEnd = iEnd;

		Draw (NULL);
	}
}
