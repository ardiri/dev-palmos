/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "UDialogTools.h"


// ---------------------------------------------------------------------------
//		� UserItem_Frame
// ---------------------------------------------------------------------------
// Draws a one pixel frame around the bounds of a dialog item.  This is a
// user item proc.

pascal void UserItem_Frame (DialogRef 	iDialog,
							short		iItem)
{
	Rect aRect;
	GetItemRect (iDialog, iItem, aRect);
	FrameRect (&aRect);
}


// ---------------------------------------------------------------------------
//		� UserItem_GrayFrame
// ---------------------------------------------------------------------------
// Draws a gray one pixel frame around the bounds of a dialog item.  This is
// a user item proc.

pascal void UserItem_GrayFrame (DialogRef 	iDialog,
								short		iItem)
{
	Rect aRect;
	GetItemRect (iDialog, iItem, aRect);
	PenPat (&qd.gray);
	FrameRect (&aRect);
	PenPat (&qd.black);
}


// ---------------------------------------------------------------------------
//		� UserItem_DefaultFrame
// ---------------------------------------------------------------------------
// Draws a three pixel frame with rounded corners around the bounds of a
// dialog item.  This is a user item proc.

pascal void UserItem_DefaultFrame (	DialogRef 	iDialog,
									short		iItem)
{
	Rect aRect;
	GetItemRect (iDialog, iItem, aRect);

	if (PortIsColor (iDialog))
	{
		InsetRect (&aRect, 1, 1);
		aRect.right--; aRect.bottom--;

		RGBColor aForeColor;

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xDDDD;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.right - 4, aRect.top + 1);
		LineTo (aRect.left + 4, aRect.top + 1);
		Line (-1, 1);
		Line (-1, 0);
		Line (0, 1);
		Line (-1, 1);
		LineTo (aRect.left + 1, aRect.bottom - 4);

		MoveTo (aRect.left + 2, aRect.top);
		Line (-2, 2);
		MoveTo (aRect.right, aRect.bottom - 2);
		Line (-2, 2);
		MoveTo (aRect.left, aRect.bottom - 2);
		Line (2, 2);
		MoveTo (aRect.right - 2, aRect.top);
		Line (2, 2);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xCCCC;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.right - 3, aRect.top + 1);
		Line (1, 1);
		MoveTo (aRect.left + 1, aRect.bottom - 3);
		Line (1, 1);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x8888;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.right - 1, aRect.top + 3);
		Line (0, 0);
		MoveTo (aRect.left + 3, aRect.bottom - 1);
		Line (0, 0);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x7777;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.left + 4, aRect.top + 3);
		Line (-1, 1);
		MoveTo (aRect.right - 4, aRect.top + 3);
		Line (1, 1);
		MoveTo (aRect.left + 4, aRect.bottom - 3);
		Line (-1, -1);
		MoveTo (aRect.right - 4, aRect.bottom - 3);
		Line (1, -1);

		MoveTo (aRect.right - 1, aRect.top + 4);
		LineTo (aRect.right - 1, aRect.bottom - 3);
		Line (-1, 0);
		Line (0, 1);
		Line (-1, 0);
		Line (0, 1);
		LineTo (aRect.left + 4, aRect.bottom - 1);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x2222;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.left + 5, aRect.top + 3);
		Line (0, 0);
		Move (-2, 2);
		Line (0, 0);
		MoveTo (aRect.right - 5, aRect.top + 3);
		Line (0, 0);
		Move (2, 2);
		Line (0, 0);
		MoveTo (aRect.left + 5, aRect.bottom - 3);
		Line (0, 0);
		Move (-2, -2);
		Line (0, 0);
		MoveTo (aRect.right - 5, aRect.bottom - 3);
		Line (0, 0);
		Move (2, -2);
		Line (0, 0);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xAAAA;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.left + 3, aRect.top + 1);
		Line (-2, 0);
		Line (0, 2);
		MoveTo (aRect.right - 1, aRect.top + 1);
		Line (0, 0);
		MoveTo (aRect.right - 1, aRect.bottom - 1);
		Line (0, 0);
		MoveTo (aRect.left + 1, aRect.bottom - 1);
		Line (0, 0);

		MoveTo (aRect.left + 2, aRect.top + 4);
		Line (2, -2);
		LineTo (aRect.right - 3, aRect.top + 2);
		Line (0, 1);
		Line (1, 0);
		LineTo (aRect.right - 2, aRect.bottom - 4);
		Line (-2, 2);
		LineTo (aRect.left + 3, aRect.bottom - 2);
		Line (0, -1);
		Line (-1, 0);
		LineTo (aRect.left + 2, aRect.top + 4);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x0000;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.left + 3, aRect.top);
		LineTo (aRect.left, aRect.top + 3);
		LineTo (aRect.left, aRect.bottom - 3);
		LineTo (aRect.left + 3, aRect.bottom);
		LineTo (aRect.right - 3, aRect.bottom);
		LineTo (aRect.right, aRect.bottom - 3);
		LineTo (aRect.right, aRect.top + 3);
		LineTo (aRect.right - 3, aRect.top);
		LineTo (aRect.left + 3, aRect.top);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x4444;
		RGBForeColor (&aForeColor);

		MoveTo (aRect.left + 3, aRect.top);
		Line (0, 0);
		Move (-3, 3);
		Line (0, 0);
		MoveTo (aRect.right, aRect.bottom - 3);
		Line (0, 0);
		Move (-3, 3);
		Line (0, 0);
		MoveTo (aRect.left, aRect.bottom - 3);
		Line (0, 0);
		Move (3, 3);
		Line (0, 0);
		MoveTo (aRect.right - 3, aRect.top);
		Line (0, 0);
		Move (3, 3);
		Line (0, 0);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x0000;
		RGBForeColor (&aForeColor);
		aForeColor.red = aForeColor.green = aForeColor.blue = 0xFFFF;
		RGBBackColor (&aForeColor);
	}
	else
	{
		PenSize (3, 3);
		FrameRoundRect (&aRect, 16, 16);
		PenSize (1, 1);
	}
}


// ---------------------------------------------------------------------------
//		� SetUserItemProcedure
// ---------------------------------------------------------------------------
// Sets the drawing procedure for a user item in a dialog.

void SetUserItemProcedure (	DialogRef 		iDialog,
							short			iItem,
							UserItemUPP		iProcedure)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	SetDialogItem (iDialog, iItem, aType, (Handle) iProcedure, &aRect);
}


// ---------------------------------------------------------------------------
//		� GetItemType
// ---------------------------------------------------------------------------
// Returns the item type of the specified dialog item.

short GetItemType (	DialogRef 	iDialog,
					short		iItem)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	return aType;
}


// ---------------------------------------------------------------------------
//		� SetItemSelect
// ---------------------------------------------------------------------------
// Sets or clears a radio button or check box item based on the value of
// iSelect.  SetItemSelect can also be used to set the selection in a popup
// menu item if iSelect is an integer instead of a boolean.

void SetItemSelect (DialogRef 	iDialog,
					short		iItem,
					short		iSelect)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	if (iSelect != GetControlValue ((ControlRef) aProc))
		SetControlValue ((ControlRef) aProc, iSelect);
}


// ---------------------------------------------------------------------------
//		� GetItemSelect
// ---------------------------------------------------------------------------
// Returns true if the specified radio button or check box is set, false if
// it is clear.

Boolean GetItemSelect (	DialogRef 	iDialog,
						short		iItem)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	return GetControlValue ((ControlRef) aProc);
}


// ---------------------------------------------------------------------------
//		� GetItemValue
// ---------------------------------------------------------------------------
// Returns the value of the specified dialog control.

short GetItemValue (DialogRef 	iDialog,
					short		iItem)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	return GetControlValue ((ControlRef) aProc);
}


// ---------------------------------------------------------------------------
//		� SetItemEnable
// ---------------------------------------------------------------------------
// Enables or disables a radio button, check box, popup menu, or button based
// on the value of iEnable.

void SetItemEnable (DialogRef 	iDialog,
					short		iItem,
					Boolean		iEnable)
{
	short		aType;
	Rect		aRect;
	ControlRef	aControl;

	GetDialogItem (iDialog, iItem, &aType, &(Handle) aControl, &aRect);
	if ((*aControl)->contrlHilite != ((iEnable) ? 0 : 255))
		HiliteControl (aControl, (iEnable) ? 0 : 255);
}


// ---------------------------------------------------------------------------
//		� GetItemEnable
// ---------------------------------------------------------------------------
// Returns true if the specified dialog item is enabled.

Boolean GetItemEnable (	DialogRef 	iDialog,
						short		iItem)
{
	short		aType;
	Rect		aRect;
	ControlRef	aControl;

	GetDialogItem (iDialog, iItem, &aType, &(Handle) aControl, &aRect);
	if ((*aControl)->contrlHilite == 0)
		return true;
	else
		return false;
}


// ---------------------------------------------------------------------------
//		� GetItemRect
// ---------------------------------------------------------------------------
// Returns the bounding rectangle of a dialog item.

void GetItemRect (	DialogRef 	iDialog,
					short		iItem,
					Rect&		oRect)
{
	short	aType;
	Handle	aProc;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &oRect);
}


// ---------------------------------------------------------------------------
//		� SetItemRect
// ---------------------------------------------------------------------------
// Returns the bounding rectangle of a dialog item.

void SetItemRect (	DialogRef 	iDialog,
					short		iItem,
					const Rect&	iRect)
{
	short	aType;
	Handle	aProc;
	Rect	oRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &oRect);
	SetDialogItem (iDialog, iItem, aType, aProc, &iRect);

	// If the item is a control, we have to move the underlying control, too.

	if ((aType & kControlDialogItem) != 0)
	{
		ControlHandle	ctl = (ControlHandle) aProc;
		UInt8			oldVis = (**ctl).contrlVis;
		HideControl (ctl);
		MoveControl (ctl, iRect.left, iRect.top);
		SizeControl (ctl, iRect.right - iRect.left, iRect.bottom - iRect.top);
		if (oldVis /*== 255*/)	//��� I�m not sure if full check is OK.
			ShowControl (ctl);	//��� call ValidRect, too?
	}
}


// ---------------------------------------------------------------------------
//		� GetItemText
// ---------------------------------------------------------------------------
// Returns the text of the specified text field dialog item.

void GetItemText (DialogRef 	iDialog,
					short		iItem,
					Str255		oText)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	GetDialogItemText (aProc, oText);
}


// ---------------------------------------------------------------------------
//		� SetItemText
// ---------------------------------------------------------------------------
// Sets the text of the specified text field dialog item.

void SetItemText (DialogRef 	iDialog,
					short		iItem,
					Str255		iText)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	SetDialogItemText (aProc, iText);
}


// ---------------------------------------------------------------------------
//		� SetButtonText
// ---------------------------------------------------------------------------
// Sets the text of the specified button dialog item.

void SetButtonText (DialogRef 	iDialog,
					short		iItem,
					Str255		iText)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);
	SetControlTitle ((ControlRef) aProc, iText);
}


// ---------------------------------------------------------------------------
//		� PressButton
// ---------------------------------------------------------------------------
// Presses the specified button, as if the user clicked it.

void PressButton (DialogRef 	iDialog,
					short		iItem)
{
	short	aType;
	Handle	aProc;
	Rect	aRect;
	unsigned long	aTicks;

	GetDialogItem (iDialog, iItem, &aType, &aProc, &aRect);

	if (aType == kButtonDialogItem || aType == kResourceControlDialogItem)
	{
		HiliteControl ((ControlHandle) aProc, kControlButtonPart);
		Delay (8, &aTicks);
		HiliteControl ((ControlHandle) aProc, false);
	}
}


// ---------------------------------------------------------------------------
//		� PortIsColor
// ---------------------------------------------------------------------------
// Returns true if the specified port is deeper than two bits.

Boolean PortIsColor (GrafPtr iPort)
{
	return (iPort->portBits.rowBytes & 0xC000) && ((*((CGrafPtr) iPort)->portPixMap)->pixelSize > 2);
}


// ---------------------------------------------------------------------------
//		� GetWindowContentColor
// ---------------------------------------------------------------------------
// Returns the content color of the specified window.

void GetWindowContentColor (WindowRef	iWindow,
							RGBColor&	oContentColor)
{
	// Don't bother if this is a monochrome window.

	oContentColor.red = oContentColor.blue = oContentColor.green = 0xFFFF;
	if (!PortIsColor (iWindow))
		return;

	// Get the custom color table, if any.

	AuxWinHandle aAuxHandle = NULL;

	if (GetAuxWin (iWindow, &aAuxHandle) && (aAuxHandle != NULL))
		oContentColor = (**(**aAuxHandle).awCTable).ctTable[wContentColor].rgb;

	// No custom color, get the default.

	else
		GetBackColor (&oContentColor);
}


// ---------------------------------------------------------------------------
//		� SetDialogFontToEspi
// ---------------------------------------------------------------------------
// Sets the specified dialog's font to Espi Sans.

void SetDialogFontToEspi (DialogRef iDialog)
{
	// Set up the dialog font.  This is a nasty thing to do.

	short	fontNum = kFont_PandoraEspi;
	short	fontSize = 10;
	GetFNum ("\pGeneva", &fontNum);

	SetPort (iDialog);
	TextFont (fontNum);
	TextMode (srcOr);
	TextSize (fontSize);
	TextFace (0);

	FontInfo	fInfo;
	GetFontInfo (&fInfo);

	DialogPeek aDialogPeek = (DialogPeek) iDialog;

	(*aDialogPeek->textH)->txFont = fontNum;
	(*aDialogPeek->textH)->txSize = fontSize;
	(*aDialogPeek->textH)->lineHeight = fInfo.ascent + fInfo.descent + fInfo.leading;
	(*aDialogPeek->textH)->fontAscent = fInfo.ascent;
}


// ---------------------------------------------------------------------------
//		� StandardAlertFilter
// ---------------------------------------------------------------------------
// A dialog filter for StandardAlert.

pascal Boolean StandardAlertFilter (DialogRef		iDialog,
									EventRecord*	iEvent,
									short*			oItem)
{
	// The filter is only interested in key events.

	if (iEvent->what != keyDown)
		return false;

	switch (iEvent->message & charCodeMask)
	{
		// Hit the ok button.

		case kKey_Return:
		case kKey_Enter:

			if (GetItemEnable (iDialog, kAlertItem_OKButton) &&
					(GetItemType (iDialog, kAlertItem_OKButton) == kButtonDialogItem ||
					 GetItemType (iDialog, kAlertItem_OKButton) == kResourceControlDialogItem))
			{
				PressButton (iDialog, kAlertItem_OKButton);
				*oItem = kAlertItem_OKButton;
				return true;
			}
			return true;

		// Hit the cancel button.

		case kKey_Escape:

			if (GetItemEnable (iDialog, kAlertItem_CancelButton) &&
					(GetItemType (iDialog, kAlertItem_CancelButton) == kButtonDialogItem ||
					GetItemType (iDialog, kAlertItem_CancelButton) == kResourceControlDialogItem))
			{
				PressButton (iDialog, kAlertItem_CancelButton);
				*oItem = kAlertItem_CancelButton;
				return true;
			}
			else if (GetItemEnable (iDialog, kAlertItem_OKButton) &&
					(GetItemType (iDialog, kAlertItem_OKButton) == kButtonDialogItem ||
					GetItemType (iDialog, kAlertItem_OKButton) == kResourceControlDialogItem))
			{
				PressButton (iDialog, kAlertItem_OKButton);
				*oItem = kAlertItem_OKButton;
				return true;
			}

			return true;

		// Otherwise, do nothing.

		default:
			return false;
	}

	return false;
}


// ---------------------------------------------------------------------------
//		� StandardAlert
// ---------------------------------------------------------------------------
// Displays the specified dialog as an alert.  Item one in the dialog should
// be the "OK" button.  Item two should be the default frame user item.
// Item three should be a cancel button, if any.  Returns the index of the
// item that was clicked to close the dialog.

short StandardAlert (	short		iDialogID,
						Boolean		iBeep)
{
	// Remember the current port.

	GrafPtr aSavePort;
	GetPort (&aSavePort);

	// Alert sound.

	if (iBeep)
		SysBeep (0);

	// Load the dialog.

	DialogRef aDialog = GetNewDialog (iDialogID, NULL, (WindowRef) -1);
	if (aDialog == NULL)
		return 0;

	SetDialogFontToEspi (aDialog);

	// Set up the default frame.

	UserItemUPP aDefaultItemUPP = NewUserItemProc (UserItem_DefaultFrame);
	if ((aDefaultItemUPP != NULL) &&
			(GetItemType (aDialog, kAlertItem_DefaultFrame) == kUserDialogItem) ||
			(GetItemType (aDialog, kAlertItem_DefaultFrame) == kItemDisableBit))
		SetUserItemProcedure (aDialog, kAlertItem_DefaultFrame, aDefaultItemUPP);

	// Set up the filter.

	ModalFilterUPP aDialogFilterUPP = NewModalFilterProc (StandardAlertFilter);

	// Event loop.

	ShowWindow (aDialog);
	SetPort (aDialog);

	short aItem = 0;
	do
	{
		ModalDialog (aDialogFilterUPP, &aItem);
	}
	while ((aItem != kAlertItem_OKButton) && (aItem != kAlertItem_CancelButton));

	// Clean up.

	if (aDialog != NULL)
		DisposeDialog (aDialog);

	if (aDefaultItemUPP != NULL)
		DisposeRoutineDescriptor (aDefaultItemUPP);

	if (aDialogFilterUPP != NULL)
		DisposeRoutineDescriptor (aDialogFilterUPP);

	SetPort (aSavePort);

	return aItem;
}
