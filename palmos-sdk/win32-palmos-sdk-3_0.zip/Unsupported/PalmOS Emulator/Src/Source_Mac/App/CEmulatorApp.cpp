/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CEmulatorApp.h"

#include "CPU_REG.h"
#include "DebugMgr.h"			// Debug::InDebugger
#include "Gremlins.h"			// Gremlin_Foo
#include "LoadApplication.h"	// LoadApplication
#include "Palm.h"				// SlkPktHeaderType, etc.
#include "Platform.h"			// ThrowFoo
#include "PPCMessaging.h"
#include "RAM_ROM.h"
#include "Profiling.h"

#include <ctype.h>				// toupper
#include <string.h>				// strlen

#include "CAboutDialog.h"
#include "CBox.h"
#include "CCicnButton.h"
#include "CDialogBox.h"
#include "CDragPicture.h"
#include "CProgressPane.h"
#include "CProgressWindow.h"
#include "CTouchScreen.h"
#include "CURLPushButton.h"
#include "USerialPort.h"

#include <LActiveScroller.h>
#include <LCaption.h>
#include <LCheckbox.h>
#include <LCicnButton.h>
#include <LEditText.h>
#include <LGADialog.h>
#include <LListBox.h>
#include <LPlaceHolder.h>
#include <LPushButton.h>
#include <LRadioGroup.h>
#include <LStdControl.h>
#include <LStaticText.h>
#include <LTabGroup.h>
#include <LTextEditView.h>
#include <LTextGroupBox.h>
#include <LWindow.h>

#include <LGACheckboxImp.h>
#include <LGAEditTextImp.h>
#include <LGAPushButtonImp.h>
#include <LGAStaticTextImp.h>
#include <LGATextGroupBoxImp.h>

#include <LGrowZone.h>
#include <LMenuBar.h>
#include <PP_Messages.h>
#include <PP_Resources.h>
#include <UDrawingState.h>
#include <UMemoryMgr.h>
#include <UModalDialogs.h>
#include <URegistrar.h>

#if USE_THREADS
#include <LThread.h>			// UMainThread
#include <UThread.h>			// LYieldAttachment
#endif

#if __profile__
#include <Profiler.h>
#endif


// Resource constants.

const ResIDT		kResource_PrefWindow		= 10003;

// Preferences dialog item constants.

const PaneIDT		kItem_MemorySizePopup		= 3;
const PaneIDT		kItem_AutoLoadCheck			= 4;
const PaneIDT		kItem_AutoSaveCloseCheck	= 5;
const PaneIDT		kItem_AutoSaveQuitCheck		= 6;
const PaneIDT		kItem_DoubleSizeCheck		= 7;
const PaneIDT		kItem_HotSyncPort			= 8;

extern TByteQueue		gCommReadQueue;		// Platform_Mac.cpp
extern TByteQueue		gCommWriteQueue;

#pragma mark -
#pragma mark --- Diagnostics ---

// ---------------------------------------------------------------------------
//		� Diagnostics
// ---------------------------------------------------------------------------

#if LOG_PPC

extern void PRINTF (const char* msg, ...);

#else

inline void PRINTF (const char*) {}
template <class T1> inline void PRINTF (const char*, T1) {}
template <class T1, class T2> inline void PRINTF (const char*, T1, T2) {}
template <class T1, class T2, class T3> inline void PRINTF (const char*, T1, T2, T3) {}

#endif


// Initialize the globals and static data members.

CEmulatorApp*	gApplication;


#if USE_THREADS

LThread*		CEmulatorApp::fCPUThread;

class LCPUThread : public LThread
{
	public:
						LCPUThread();
		virtual			~LCPUThread();

	protected:
		virtual void*	Run();
};

LCPUThread::LCPUThread() :
	LThread(false, thread_DefaultStack, LThread::threadOption_Default)
{
}


LCPUThread::~LCPUThread()
{
}


void* LCPUThread::Run()
{
	long	breakState = kCPUState_Stopped;

//	while (1)
	{
		breakState = Emulator::Execute ();
	}

	Debugger ();

	while (1)
	{
		LThread::Yield ();
	}

	return NULL;
}
#endif


// ---------------------------------------------------------------------------
//		� main
// ---------------------------------------------------------------------------

void main (void)
{
	// Set the debugging options.

	SetDebugThrow_	(debugAction_Alert);
	SetDebugSignal_ (debugAction_Alert);

	// Memory initialization.

	InitializeHeap (3);

	// Toolbox initialization.

	UQDGlobals::InitializeToolbox (&qd);

	// Scope out the system.

	UEnvironment::InitEnvironment ();

#if USE_THREADS
	if (!UEnvironment::HasFeature (env_HasThreadsManager))
	{
		// !!! Thread Manager not available
	}

	new UMainThread;
#endif

	PPCInit ();

	// Install a GrowZone to catch low memory situations.

	new LGrowZone (20000);

#if __profile__

	// If we're profiling, initiliaze the system

	if (ProfilerInit(collectDetailed, bestTimeBase, 400, 20))
	{
		SysBreakStr("\pError initializing profiler");
		Throw_(-1);
	}

	ProfilerSetStatus (false);

#endif
	
	// Construct and run the application class.

	CEmulatorApp	theApp;
	gApplication = &theApp;
	theApp.Run ();
}


#ifndef NDEBUG

	#if __dest_os != __win32_os
	#include <strings.h>
	#endif

	void __assertion_failed(char * condition, char * filename, int lineno)
	{
		char buf[4096];
		
		#if __dest_os == __win32_os

			sprintf(buf,"Assertion (%s) failed in \"%s\" on line %d\n", condition, filename, lineno);
			MessageBox(NULL,buf,"Assertion Failure",MB_OK);

		#else

			sprintf(buf, "Assertion (%s) failed in \"%s\" on line %d\n", condition, filename, lineno);
			c2pstr(buf);
			DebugStr((unsigned char*) buf);

		#endif
	}

#endif


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::CEmulatorApp
// ---------------------------------------------------------------------------

CEmulatorApp::CEmulatorApp (void)
{
	// Register the core PowerPlant classes.

	RegisterClass_(LActiveScroller);					// �ascr�
	RegisterClass_(LCaption);							// �capt�
	RegisterClass_(LCheckBox);							// �chbx�
	RegisterClass_(LCicnButton);						// �cicn�
//	RegisterClass_(LDialogBox);							// �dlog�
	RegisterClass_(LEditText);							// �etxt�
	RegisterClass_(LGADialog);							// �gdlg�
	RegisterClass_(LListBox);							// �lbox�
	RegisterClass_(LPlaceHolder);						// �plac�
	RegisterClass_(LPushButton);						// �push�
	RegisterClass_(LRadioGroup);						// �radg�
	RegisterClass_(LStdButton);							// �pbut� ?
	RegisterClass_(LStdCheckBox);						// �cbox� ?
	RegisterClass_(LStdPopupMenu);						// �popm� ?
	RegisterClass_(LStdRadioButton);					// �rbut� ?
	RegisterClass_(LStaticText);						// �stxt�
	RegisterClass_(LTabGroup);							// �tabg�
	RegisterClass_(LTextEditView);						// �txtv�
	RegisterClass_(LTextGroupBox);						// �tgbx�
	RegisterClass_(LWindow);							// �wind�

	// 'text' is the class id of the old LTextEdit class. That class
	// is now replaced by LTextEditView.  So that our PPob resources
	// (which still refer to 'text') don't break, register LTextEditView
	// to be instantiated for 'text'.

	RegisterClassID_(LTextEditView, 'text');

	// Register the grayscale control implementation classes.

	RegisterClassID_(LGACheckboxImp,		LCheckBox::imp_class_ID);
	RegisterClassID_(LGAEditTextImp,		LEditText::imp_class_ID);
	RegisterClassID_(LGAPushButtonImp,		LPushButton::imp_class_ID);
	RegisterClassID_(LGAStaticTextImp,		LStaticText::imp_class_ID);
	RegisterClassID_(LGATextGroupBoxImp,	LTextGroupBox::imp_class_ID);

	// Register the application classes.

    RegisterClass_(CBox);								// �CBox�
	RegisterClass_(CDialogBox);							// �dlog�
    RegisterClass_(CDragPicture);						// �CDrg�
    RegisterClass_(CTouchScreen);						// �CLCD�
    RegisterClass_(CProgressPane);						// �CPrP�
    RegisterClass_(CCicnButton);						// �Cicn�
    RegisterClass_(CURLPushButton);						// �URpb�

	// Initialize the data members.

	fEmulatorWindow		= NULL;
	fLCDScreen			= NULL;

	fPreferences.fPrefVersion		= kCurrentPreferenceVersion;
	fPreferences.fDefaultMemorySize	= 512;
	fPreferences.fAutoLoadOnStartup	= true;
	fPreferences.fAutoSaveOnClose	= false;
	fPreferences.fAutoSaveOnQuit	= false;
	fPreferences.fDoubleSize		= false;

	fMemoryFileAlias	= NULL;
	fRunEmulatorAtIdle	= true;

	fHotSyncDown		= false;
	fHotSyncDownTime	= 0;

#if LOG_PPC
	gLog = fopen("Phantom:Log.Emulator", "w");
#endif

#if USE_THREADS
	this->AddAttachment (new LYieldAttachment (-1));
#endif
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::~CEmulatorApp
// ---------------------------------------------------------------------------

CEmulatorApp::~CEmulatorApp ()
{
	this->CleanUpAtExit();

	this->DisposeEmulator (false, false);

	::DisposeHandle ((Handle) fMemoryFileAlias);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::Initialize
// ---------------------------------------------------------------------------

void CEmulatorApp::Initialize (void)
{
	this->LoadPreferences ();
	
	this->StartIdling ();
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::DoCleanup
// ---------------------------------------------------------------------------

void CEmulatorApp::DoCleanup (void)
{
#if LOG_PPC

	if (gLog)
	{
		fclose(gLog);
		gLog = NULL;
	}

#endif

	Platform::CloseSerialPort ();

	this->ClosePorts ();

#if __profile__
	// If we were profiling, dump the collected information.

	ProfilerDump("\pEmulator.prof");
	ProfilerTerm();

#endif
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::SpendTime
// ---------------------------------------------------------------------------

#if 0	// Debugging code only, add it back in when we add a serial line monitor.
static int		oldDirection = 0;
static UInt32	lastTime = 0;
static FILE*	serialLog;

static void LogSerial (uae_u8 byte, int direction)
{
	if (!serialLog)
	{
		serialLog = fopen ("SerialLog", "w");
	}
	
	if (oldDirection != direction || lastTime != TickCount ())
	{
		UInt32	delta = TickCount () - lastTime;
		oldDirection = direction;
		lastTime = TickCount ();
		
		fprintf (serialLog, "\n%s (%08X) :", direction < 0 ? "OUT" : " IN", delta);
	}

	fprintf (serialLog, " %02X", (int) byte);
}
#endif

void CEmulatorApp::SpendTime (const EventRecord& inMacEvent)
{
	PRINTF ("Entering SpendTime.");

	// See if the ports are still in place.

	if (PPCPortOpened (&gReceivePort) &&
		!PPCPortConnecting (&gReceivePort) &&
		!PPCPortConnected (&gReceivePort))
	{
		PRINTF ("Found broken port. Called ClosePorts.");

		this->ClosePorts ();
		this->OpenPorts ();
	}

	// If still connected, see if there's data from the debugger.

	bool	handledAPacket = false;

	// We need to be careful about re-entrancy. HandlePacket could
	// try calling into the ROM (for instance, to call HwrMemReadable).
	// If it's time to handle events while calling that, the event
	// loop will try calling into here, which will cause us to try
	// to handle the same packet that we're already handling.  To
	// prevent this from happening, use a simple semaphore.

	static bool	handlingAPacket;

	if (gReceivePort.fDataWaiting && !handlingAPacket)
	{
		handlingAPacket = true;

		PRINTF ("Handling received packet.");
		this->HandlePacket ();
		PRINTF ("Handled received packet.");

		this->ListenForPacket ();
		
		handlingAPacket = false;
		handledAPacket = true;
	}


	// If there's any serial stuff going on, manage it.

	if (gCommEstablished)
	{
		// Write out any outgoing bytes.

		OSErr	err = noErr;
		char	buffer[8];
		long	byteCount = gCommWriteQueue.GetUsed ();

		if (byteCount > 0)
		{
			for (long ii = 0; ii < byteCount; ++ii)
			{
				buffer[ii] = gCommWriteQueue.Get ();
#if 0
				LogSerial (buffer[ii], -1);
#endif
			}

			err = ::FSWrite (gOutReference, &byteCount, &buffer);

#if 0
			fflush (serialLog);
#endif
		}

		// Buffer up any incoming bytes.  But only do it if
		// we need to refresh gCommReadQueue.

		if (gCommReadQueue.GetUsed () == 0)
		{
			err = ::SerGetBuf (gInReference, &byteCount);

			if (err == noErr)
			{
				if (byteCount > gCommReadQueue.GetFree ())
				{
					byteCount = gCommReadQueue.GetFree ();
				}

				if (byteCount > 0)
				{
					err = ::FSRead (gInReference, &byteCount, buffer);

					if (err == noErr)
					{
						for (long ii = 0; ii < byteCount; ++ii)
						{
#if 0
							LogSerial (buffer[ii], 1);
#endif
							gCommReadQueue.Put (buffer[ii]);
						}

#if 0
						fflush (serialLog);
#endif
					}
				}
			}
		}
	}

	// If we started a hot-sync event, and one second has passed, emulate
	// a button-up of the hotsync button.

	if (fHotSyncDown && TickCount () - fHotSyncDownTime > 60)
	{
		fHotSyncDown = false;
		fHotSyncDownTime = 0;
		Hardware::HotSyncEvent (false);
	}


#if USE_THREADS
	CTouchScreen*	screen = GetLCDScreen ();
	if (screen != NULL)
	{
		screen->Refresh ();
	}
#else
	// If the emulator window is open, and we're allowed to run at idle
	// time (we disable doing this under certain circumstances), and we're
	// not in the debugger, then run the emulator.  If the emulator exits
	// because of an exception, then enter the debugger.
	//
	// Additional refinement: if we just handled a packet, don't execute
	// the CPU loop.  This gives the guy we're talking to a faster response.

	if (GetEmulatorWindow () &&
		!handledAPacket &&
		fRunEmulatorAtIdle &&
		!Debug::InDebugger ())
	{
		PRINTF ("Calling Emulator::Execute.");
		uae_s16	breakReason = Emulator::Execute () & kBreak_Exception;
		PRINTF ("Returned from Emulator::Execute.");
	}
#endif

	// Adjust our sleep time depending on the state of the processor

	if (regs.stopped)
		mSleepTime = 2;
	else
		mSleepTime = 0;

	this->UpdateMenus();

	PRINTF ("Leaving SpendTime.");
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::RunEmulatorAtIdle
// ---------------------------------------------------------------------------

bool CEmulatorApp::RunEmulatorAtIdle (bool doRun)
{
	bool	oldRun = fRunEmulatorAtIdle;
	fRunEmulatorAtIdle = doRun;
	return oldRun;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::ObeyCommand
// ---------------------------------------------------------------------------

Boolean CEmulatorApp::ObeyCommand (	CommandT	iCommand,
									void*	iParameters)
{
	Boolean		aWasHandled	= true;
	MessageT	aSaveReply	= kMessage_Save;

	switch (iCommand)
	{
		case kCommand_AboutEmulator:

			About ();
			break;

		case kCommand_OpenEmulator:

			// Dispose of the alias so that (a) NewEmulator doesn't try to
			// open it, and (b) DisposeEmulator doesn't try to automatically
			// save to it.

			DisposeHandle ((Handle) fMemoryFileAlias);
			fMemoryFileAlias = NULL;

			NewEmulator (false, false);
			break;

		case kCommand_CloseEmulator:

			if (fPreferences.fAutoSaveOnClose)
				DisposeEmulator (true, false);
			else
				DisposeEmulator ((AskToSave () == msg_OK), false);
			break;

		case kCommand_ResetEmulator:

			if (GetEmulatorWindow () != NULL)
			{
				Emulator::Reset ();
			}
			break;

		case kCommand_HotSync:

			if (GetEmulatorWindow () != NULL)
			{
				Hardware::HotSyncEvent (true);
				fHotSyncDown = true;
				fHotSyncDownTime = TickCount ();
			}
			break;

		case kCommand_OpenMemory:

			if (fPreferences.fAutoSaveOnClose)
				DisposeEmulator (true, false);
			else
				DisposeEmulator ((AskToSave () == msg_OK), false);

			NewEmulator (true, true);
			break;

		case kCommand_SaveMemory:
		case kCommand_SaveMemoryAs:
		{
			FILE*	file = this->OpenAsFILE (fMemoryFileAlias, false, iCommand == kCommand_SaveMemoryAs);

			if (file)
			{
				Memory::Save (file);
				fclose (file);
			}
			break;
		}
		
		case kCommand_Screenshot:
		{
			CTouchScreen*	screenPane = GetLCDScreen ();
			if (screenPane)
			{
				StandardFileReply	reply;
				::StandardPutFile ("\pSave screen as:", "\p", &reply);

				if (reply.sfGood)
				{
					screenPane->SaveScreen (reply.sfFile);
				}
			}

			break;
		}

		case kCommand_LoadApplication:

			if (Screen::LCDIsOn ())
			{
				// Let the user select an application from a standard
				// file dialog.
				
				StandardFileReply	reply;
				StandardGetFile (NULL, -1, NULL, &reply);
								
				if (reply.sfGood)
				{
					FILE*	appFile = this->OpenAsFILE (reply.sfFile, true);
					if (appFile)
					{
						if ((Emulator::ExecuteUntilATrap () & kBreak_Exception) == kException_Trap15)
						{
							LoadApplication (appFile);
						}

						fclose (appFile);
					}
				}
			}
			break;

		case kCommand_DownloadROM:

			this->DownloadROM ();
			break;

		case kCommand_Preferences:

			this->EditPreferences ();
			break;

		case kCommand_GremlinNew:

			if ((Emulator::ExecuteUntilATrap () & kBreak_Exception) == kException_Trap15)
			{
				this->NewGremlin ();
			}
			break;

		case kCommand_GremlinStep:

			if ((Emulator::ExecuteUntilATrap () & kBreak_Exception) == kException_Trap15)
			{
				Gremlins_Step ();
			}
			break;

		case kCommand_GremlinResume:

			if ((Emulator::ExecuteUntilATrap () & kBreak_Exception) == kException_Trap15)
			{
				Gremlins_Resume ();
			}
			break;

		case kCommand_GremlinStop:

			if ((Emulator::ExecuteUntilATrap () & kBreak_Exception) == kException_Trap15)
			{
				Gremlins_Stop ();
			}
			break;

#if HAS_PROFILING
		case kCommand_ProfilingStart:

			ProfileInit(MAXFNCALLS, MAXDEPTH);
#if !PROFILE_ONE_FN
			ProfileStart();
#endif
			break;

		case kCommand_ProfilingStop:

			ProfileStop();
			break;

		case kCommand_ProfilingDump:

			ProfileDump();
			ProfileCleanup();
			break;

		case kCommand_ProfilingTest:

			ProfileTest();
			break;
#endif


		case cmd_Quit:

			this->DisposeEmulator (fPreferences.fAutoSaveOnQuit || (AskToSave () == msg_OK),
									false, false);

			this->SendAEQuit ();
			this->SavePreferences ();
			break;

		// Pass unhandled commands to the superclass.

		default:

			aWasHandled = LApplication::ObeyCommand (iCommand, iParameters);
			break;
	}

	return aWasHandled;
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::FindCommandStatus
// ---------------------------------------------------------------------------

void CEmulatorApp::FindCommandStatus (	CommandT	iCommand,
										Boolean&	oEnabled,
										Boolean&	oUsesMark,
										Char16&		oMark,
										Str255		oName)
{
	oEnabled = false;
	oUsesMark = false;

	if (UDesktop::FrontWindowIsModal ())
	{
		if ((iCommand != cmd_Quit) && (iCommand != kCommand_AboutEmulator))
			LApplication::FindCommandStatus (iCommand, oEnabled, oUsesMark, oMark, oName);
	}
	else
	{
		switch (iCommand)
		{
			case kCommand_OpenEmulator:

				oEnabled = (GetEmulatorWindow () == NULL);
				break;

			case kCommand_CloseEmulator:
			case kCommand_ResetEmulator:
			case kCommand_HotSync:
			case kCommand_SaveMemory:
			case kCommand_SaveMemoryAs:
			case kCommand_Screenshot:

				oEnabled = (GetEmulatorWindow () != NULL);
				break;

			case kCommand_LoadApplication:

				oEnabled = Screen::LCDIsOn () && (GetEmulatorWindow () != NULL);
				break;

			case kCommand_GremlinNew:

				oEnabled = (GetEmulatorWindow () != NULL) && Gremlins_CanNew ();
				break;

			case kCommand_GremlinStep:

				oEnabled = (GetEmulatorWindow () != NULL) && Gremlins_CanStep ();
				break;

			case kCommand_GremlinResume:

				oEnabled = (GetEmulatorWindow () != NULL) && Gremlins_CanResume ();
				break;

			case kCommand_GremlinStop:

				oEnabled = (GetEmulatorWindow () != NULL) && Gremlins_CanStop ();
				break;

#if HAS_PROFILING
			case kCommand_ProfilingStart:

				oEnabled = (!gProfilingEnabled);
				break;

			case kCommand_ProfilingStop:

				oEnabled = (gProfilingEnabled && gProfilingOn);
				break;

			case kCommand_ProfilingDump:

				oEnabled = (gProfilingEnabled && !gProfilingOn);
				break;
			
			case kCommand_ProfilingTest:
				oEnabled = true;
				break;
#endif

			case kCommand_AboutEmulator:
			case kCommand_OpenMemory:
			case kCommand_DownloadROM:
			case kCommand_Preferences:
			case cmd_Quit:

				oEnabled = true;
				break;

			default:

				LApplication::FindCommandStatus (iCommand, oEnabled, oUsesMark, oMark, oName);
				break;
		}
	}
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::ListenToMessage
// ---------------------------------------------------------------------------
// Notifies the emulated CPU when a Palm device button is pressed or released.

void CEmulatorApp::ListenToMessage (MessageT	iMessage,
									void*		ioParameter)
{
	switch (iMessage)
	{
		case kCmd_CicnButtonUp:
			Hardware::ButtonEvent (false, *((SInt32*) ioParameter) - 1);
			break;

		case kCmd_CicnButtonDown:
			Hardware::ButtonEvent (true, *((SInt32*) ioParameter) - 1);
			break;
	}
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::HandleKeyPress
// ---------------------------------------------------------------------------
// Notifies the emulated CPU when a key has been pressed on the desktop
// keyboard.

Boolean CEmulatorApp::HandleKeyPress (const EventRecord& iKeyEvent)
{
	// Ignore command keys.

	if (iKeyEvent.modifiers & cmdKey)
		return false;

	// Notify the emulated CPU that a key has been pressed.

	Hardware::KeyboardEvent (iKeyEvent.message & charCodeMask);

	return true;
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::HandleKeyPress
// ---------------------------------------------------------------------------
// Displays a dialog asking the user if they would like to save the memory
// before closing it.  Depending on the selection made by the user, one of
// two constants is returned; msg_OK or msg_Cancel.

MessageT CEmulatorApp::AskToSave (void)
{
	// Don't even ask if there's nothing to save.

	if (gRAM_Memory == NULL)
		return kMessage_DontSave;

	// Show the alert.

	StDialogHandler aAskDialog (kResource_AskWindow, this);

	MessageT reply = msg_Nothing;
	while (reply < msg_OK || reply > msg_Cancel)
		reply = aAskDialog.DoDialog ();

	return reply;
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::About
// ---------------------------------------------------------------------------
// Displays emulator's About box.

void CEmulatorApp::About (void)
{
	CAboutDialog::DoAboutBox (this);
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::NewGremlin
// ---------------------------------------------------------------------------

void CEmulatorApp::NewGremlin (void)
{
	static long		gGremlinNumber = 0;
	static long		gGremlinSteps = -1;
	static int		gGremlinLogEvents = Button_Off;
	static int		gGremlinLogTraps = Button_Off;
	static int		gGremlinDisplayElapsedTime = Button_Off;
	static long		gGremlinNumApps;
	static AppInfo*	gGremlinAppList;
	static long		gGremlinSelecteditem;

	// Create the dialog.

	StDialogHandler	newGremlinDlg (kResource_NewGremlinWindow, this);

	// Initialize the settings.

	Gremlins_GetApplicationNames (&gGremlinAppList, &gGremlinNumApps);

	LWindow*	dlg = newGremlinDlg.GetDialog ();
	
	LPane*		edit1 = dlg->FindPaneByID (kItem_GremlinNumber);
	LPane*		edit2 = dlg->FindPaneByID (kItem_NumberOfSteps);
	LPane*		check1 = dlg->FindPaneByID (kItem_LogEvents);
	LPane*		check2 = dlg->FindPaneByID (kItem_LogTraps);
	LPane*		check3 = dlg->FindPaneByID (kItem_DisplayElapsedTime);

	ThrowIfNULL_(edit1);
	ThrowIfNULL_(edit1);
	ThrowIfNULL_(check1);
	ThrowIfNULL_(check2);
	ThrowIfNULL_(check3);

	edit1->SetValue (gGremlinNumber);
	edit2->SetValue (gGremlinSteps);
	check1->SetValue (gGremlinLogEvents);
	check2->SetValue (gGremlinLogTraps);
	check3->SetValue (gGremlinDisplayElapsedTime);

	LListBox*	list = dynamic_cast<LListBox*>
							(dlg->FindPaneByID (kItem_ApplicationList));
	ThrowIfNULL_(list);

	ListHandle	listH = list->GetMacListH ();
	ThrowIfNULL_(listH);
	::LAddColumn (1, 0, listH);
	::LAddRow (gGremlinNumApps + 1, 0, listH);

	Cell			cell = {0, 0};
	const char*		msg = "Entire Palm OS device";
	::LSetCell (msg, strlen(msg), cell, listH);
	::LSetSelect (true, cell, listH);

	for (int ii = 0; ii < gGremlinNumApps; ++ii)
	{
		cell.v++;
		::LSetCell (gGremlinAppList[ii].name, strlen(gGremlinAppList[ii].name), cell, listH);
	}

	// Execute the dialog until the user clicks OK or Cancel.

	bool	oldRun = this->RunEmulatorAtIdle (false);

	MessageT	reply = msg_Nothing;
	while (reply != msg_OK && reply != msg_Cancel)
		reply = newGremlinDlg.DoDialog ();

	this->RunEmulatorAtIdle (oldRun);

	if (reply == msg_OK)
	{
		gGremlinNumber				= edit1->GetValue ();
		gGremlinSteps				= edit2->GetValue ();
		gGremlinLogEvents			= check1->GetValue ();
		gGremlinLogTraps			= check2->GetValue ();
		gGremlinDisplayElapsedTime	= check3->GetValue ();
		
		if (!list->GetLastSelectedCell (cell))
			cell.v = 0;

		gGremlinSelecteditem = cell.v;

		Gremlins_LogEvents (gGremlinLogEvents == Button_On ? true : false);
		Gremlins_LogTraps (gGremlinLogTraps == Button_On ? true : false);
		Gremlins_DisplayElapsed (gGremlinDisplayElapsedTime == Button_On ? true : false);

		if (gGremlinSelecteditem == 0)
			Gremlins_AppToRun (NULL);
		else
			Gremlins_AppToRun (&gGremlinAppList[gGremlinSelecteditem - 1]);

		Gremlins_New (gGremlinNumber, gGremlinSteps);
	}

	free (gGremlinAppList);
	gGremlinAppList = NULL;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::LoadPreferences
// ---------------------------------------------------------------------------
// Locates our preferences in Preferences folder and reads the settings from
// the file.  If no preferences file is found, the default settings are used.

void CEmulatorApp::LoadPreferences (void)
{
	// Initialize the default preferences.

	fPreferences.fPrefVersion		= kCurrentPreferenceVersion;
	fPreferences.fDefaultMemorySize	= 512;
	fPreferences.fAutoLoadOnStartup	= true;
	fPreferences.fAutoSaveOnClose	= false;
	fPreferences.fAutoSaveOnQuit	= false;
	fPreferences.fDoubleSize		= false;
	fPreferences.fHotSyncPort		= 1;

	fMemoryFileAlias				= NULL;

	SInt16			aSaveRef	= CurResFile ();
	SInt16			aFileRef	= -1;
	Preferences**	aPrefHandle	= NULL;

	try
	{
		// Find the preferences directory and create a file spec to it.

		long	aDirID;
		short	aVolRef;

		OSErr aError = ::FindFolder (kOnSystemDisk, kPreferencesFolderType, kCreateFolder, &aVolRef, &aDirID);
		Throw_IfError (aError, kDefaultException);

		FSSpec aFileSpec;

		aFileSpec.parID = aDirID;
		aFileSpec.vRefNum = aVolRef;
		::GetIndString (aFileSpec.name, kResource_AppStrings, kString_EmulatorPreferences);

		// Open the file.

		aFileRef = ::FSpOpenResFile (&aFileSpec, fsRdWrPerm);
		if (aFileRef == -1)
			throw (kDefaultException);

		// Load the preferences.

		::UseResFile (aFileRef);

		aPrefHandle = (Preferences**) ::Get1Resource ('PREF', 0);
		Throw_IfNil (aPrefHandle, kDefaultException);

		// Make sure the preferences are valid.

		if ((**aPrefHandle).fPrefVersion > kCurrentPreferenceVersion)
			throw (kDefaultException);

		// Copy the preferences.  The case statements are "upside down"
		// so that they can safely fall into each other.

		switch ((**aPrefHandle).fPrefVersion)
		{
			case 3:
				fPreferences.fHotSyncPort = (**aPrefHandle).fHotSyncPort;

			case 2:
				fPreferences.fDoubleSize = (**aPrefHandle).fDoubleSize;

			case 1:
				fPreferences.fDefaultMemorySize	= (**aPrefHandle).fDefaultMemorySize;
				fPreferences.fAutoLoadOnStartup	= (**aPrefHandle).fAutoLoadOnStartup;
				fPreferences.fAutoSaveOnClose	= (**aPrefHandle).fAutoSaveOnClose;
				fPreferences.fAutoSaveOnQuit	= (**aPrefHandle).fAutoSaveOnQuit;
		}

		// Load the RAM file alias handle.

		fMemoryFileAlias = (AliasHandle) ::Get1Resource ('ALIS', 0);
		if (fMemoryFileAlias != NULL)
			::DetachResource ((Handle) fMemoryFileAlias);
	}

	catch (...)
	{
	}

	// Clean up.

	if (aPrefHandle != NULL)
		::ReleaseResource ((Handle) aPrefHandle);

	if (aFileRef != -1)
		::CloseResFile (aFileRef);

	::UseResFile (aSaveRef);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::SavePreferences
// ---------------------------------------------------------------------------
// Locates our preferences in Preferences folder and writes the current
// settings to the file.  If no preferences file is found, a new one is
// created.

void CEmulatorApp::SavePreferences (void)
{
	SInt16			aSaveRef		= CurResFile ();
	SInt16			aFileRef		= -1;
	Preferences**	aPrefHandle		= NULL;
	AliasHandle		aAliasHandle	= NULL;

	try
	{
		// Find the preferences directory and create a file spec to it.

		long	aDirID;
		short	aVolRef;

		OSErr aError = ::FindFolder (kOnSystemDisk, kPreferencesFolderType, kCreateFolder, &aVolRef, &aDirID);
		Throw_IfError (aError, kDefaultException);

		FSSpec aFileSpec;

		aFileSpec.parID = aDirID;
		aFileSpec.vRefNum = aVolRef;
		::GetIndString (aFileSpec.name, kResource_AppStrings, kString_EmulatorPreferences);

		// Open the file.

		aFileRef = ::FSpOpenResFile (&aFileSpec, fsRdWrPerm);

		// If the file doesn't exist, create a new one and open it.

		if (aFileRef == -1)
		{
			aError = ::FSpCreate (&aFileSpec, '�LOT', '�PRF', smSystemScript);
			Throw_IfError (aError, kDefaultException);

			::FSpCreateResFile (&aFileSpec, '�LOT', '�PRF', smSystemScript);
			Throw_IfError (::ResError (), kDefaultException);

			aFileRef = ::FSpOpenResFile (&aFileSpec, fsRdWrPerm);
			if (aFileRef == -1) throw (kDefaultException);
		}

		// Create a new handle and copy the current settings.

		aPrefHandle	= (Preferences**) NewHandle (sizeof (Preferences));
		Throw_IfNil (aPrefHandle, kDefaultException);

		(**aPrefHandle) = fPreferences;

		// Delete the old preferences resource.

		::UseResFile (aFileRef);

		Handle aResource = ::Get1Resource ('PREF', 0);
		if (aResource != NULL)
		{
			::RemoveResource (aResource);
			::UpdateResFile (aFileRef);
			::DisposeHandle (aResource);
		}

		// Save the new preferences resource.

		::AddResource ((Handle) aPrefHandle, 'PREF', 0, "\p");
		::WriteResource ((Handle) aPrefHandle);
		::UpdateResFile (aFileRef);
		::DetachResource ((Handle) aPrefHandle);
		::DisposeHandle ((Handle) aPrefHandle);
		aPrefHandle = NULL;

		// Delete the old alias resource.

		aResource = ::Get1Resource ('ALIS', 0);
		if (aResource != NULL)
		{
			::RemoveResource (aResource);
			::UpdateResFile (aFileRef);
			::DisposeHandle (aResource);
		}

		// Save the new alias resource.

		aAliasHandle = fMemoryFileAlias;

		if (aAliasHandle != NULL)
		{
			// Copy the alias handle.

			aError = ::HandToHand ((Handle*) &aAliasHandle);
			if (aError != kError_NoError)
			{
				aAliasHandle = NULL;
				throw (kDefaultException);
			}

			::AddResource ((Handle) aAliasHandle, 'ALIS', 0, "\p");
			::WriteResource ((Handle) aAliasHandle);
			::UpdateResFile (aFileRef);
			::DetachResource ((Handle) aAliasHandle);
			::DisposeHandle ((Handle) aAliasHandle);
			aAliasHandle = NULL;
		}
	}

	catch (...)
	{
	}

	// Clean up.

	if (aPrefHandle != NULL)
	{
		::DetachResource ((Handle) aPrefHandle);
		::DisposeHandle ((Handle) aPrefHandle);
	}

	if (aAliasHandle != NULL)
	{
		::DetachResource ((Handle) aAliasHandle);
		::DisposeHandle ((Handle) aAliasHandle);
	}

	if (aFileRef != -1)
		::CloseResFile (aFileRef);

	::UseResFile (aSaveRef);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::EditPreferences
// ---------------------------------------------------------------------------
// Displays a dialog allowing the user to change the emulator preferences.
// The new settings are saved to the prefs file.

void CEmulatorApp::EditPreferences (void)
{
	// Create the dialog.

	StDialogHandler aPrefDialog (kResource_PrefWindow, this);

	// Initialize the settings.

	LWindow*	aPrefWindow	= aPrefDialog.GetDialog ();
	if (aPrefWindow == NULL)
		return;

	LPane*	aDoubleSizeCheck	= aPrefWindow->FindPaneByID (kItem_DoubleSizeCheck);
	LPane*	aMemorySizePopup	= aPrefWindow->FindPaneByID (kItem_MemorySizePopup);
	LPane*	aAutoLoadCheck		= aPrefWindow->FindPaneByID (kItem_AutoLoadCheck);
	LPane*	aAutoSaveCloseCheck	= aPrefWindow->FindPaneByID (kItem_AutoSaveCloseCheck);
	LPane*	aAutoSaveQuitCheck	= aPrefWindow->FindPaneByID (kItem_AutoSaveQuitCheck);
	LPane*	aHotSyncPortPopup	= aPrefWindow->FindPaneByID (kItem_HotSyncPort);

	if (aDoubleSizeCheck != NULL)
		aDoubleSizeCheck->SetValue (fPreferences.fDoubleSize ? 1 : 0);

	if (aMemorySizePopup != NULL)
	{
		for (SInt16 aIndex = 1; aIndex < 7; aIndex++)
		{
			if (fPreferences.fDefaultMemorySize == kPopupMemorySizes[aIndex])
			{
				aMemorySizePopup->SetValue (aIndex);
			}
		}
	}

	if (aAutoLoadCheck != NULL)
		aAutoLoadCheck->SetValue (fPreferences.fAutoLoadOnStartup ? 1 : 0);

	if (aAutoSaveCloseCheck != NULL)
		aAutoSaveCloseCheck->SetValue (fPreferences.fAutoSaveOnClose ? 1 : 0);

	if (aAutoSaveQuitCheck != NULL)
		aAutoSaveQuitCheck->SetValue (fPreferences.fAutoSaveOnQuit ? 1 : 0);

	if (aHotSyncPortPopup != NULL)
		aHotSyncPortPopup->SetValue (fPreferences.fHotSyncPort);

	// Execute the dialog until the user clicks OK or Cancel.

	aPrefWindow->Show ();

	MessageT reply = msg_Nothing;
	while (reply != msg_OK && reply != msg_Cancel)
	{
		reply = aPrefDialog.DoDialog ();
	}

	// Save the settings if the user clicked OK.

	if (reply == msg_OK)
	{
		Boolean aPreviousSize = fPreferences.fDoubleSize;

		if (aDoubleSizeCheck != NULL)
			fPreferences.fDoubleSize = aDoubleSizeCheck->GetValue ();

		// Resize the display if the double size preference changed and
		// the emulator window is open.

		if (aPreviousSize != fPreferences.fDoubleSize && GetEmulatorWindow () != NULL)
		{
			try
			{
				// Delete the current display.

				delete fEmulatorWindow;
				fEmulatorWindow = NULL;

				// Load the new display.

				fEmulatorWindow = LWindow::CreateWindow ((fPreferences.fDoubleSize ? kResource_LargeEmulator : kResource_SmallEmulator), LCommander::GetTopCommander ());
				ThrowAlert_IfNil (GetEmulatorWindow (), kError_CantResizeDisplay, kDefaultException);
				UReanimator::LinkListenerToControls (this, GetEmulatorWindow (), (fPreferences.fDoubleSize ? kResource_LargeEmulator : kResource_SmallEmulator));

				fLCDScreen = NULL;

				GetEmulatorWindow ()->Show ();

				// For some reason we have to select the window to activate the palette.

				WindowRef aWindow = GetEmulatorWindow ()->GetMacPort ();
				if (aWindow != NULL)
					::SelectWindow (aWindow);
			}

			catch (...)
			{
				DisposeEmulator (true, true);
			}
		}

		if (aMemorySizePopup != NULL)
			fPreferences.fDefaultMemorySize = kPopupMemorySizes[aMemorySizePopup->GetValue ()];

		if (aAutoLoadCheck != NULL)
			fPreferences.fAutoLoadOnStartup = aAutoLoadCheck->GetValue ();

		if (aAutoSaveCloseCheck != NULL)
			fPreferences.fAutoSaveOnClose = aAutoSaveCloseCheck->GetValue ();

		if (aAutoSaveQuitCheck != NULL)
			fPreferences.fAutoSaveOnQuit = aAutoSaveQuitCheck->GetValue ();

		if (aHotSyncPortPopup != NULL)
			fPreferences.fHotSyncPort = aHotSyncPortPopup->GetValue ();

		// Save the new settings to the preferences file.

		SavePreferences ();
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::StartUp
// ---------------------------------------------------------------------------
// StartUp is called if the application is launched without any documents.
// If auto-load is turned on, the previous memory file is reloaded.

void CEmulatorApp::StartUp (void)
{
	if (fPreferences.fAutoLoadOnStartup)
		NewEmulator (fMemoryFileAlias != NULL, false);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::OpenDocument
// ---------------------------------------------------------------------------
// Opens the specified RAM file.  This method is called in response to an
// Apple event.

void CEmulatorApp::OpenDocument (FSSpec* iFileSpec)
{
	// Close and save the current document, if any.

	if (GetEmulatorWindow () != NULL)
	{
		if (fPreferences.fAutoSaveOnClose)
			DisposeEmulator (true, false);
		else
			DisposeEmulator ((AskToSave () == msg_OK), false);
	}

	// Delete the old alias.

	::DisposeHandle ((Handle) fMemoryFileAlias);
	fMemoryFileAlias = NULL;

	// Create a new alias.

	OSErr aError = NewAlias (NULL, iFileSpec, &fMemoryFileAlias);
	if (aError != kError_NoError || fMemoryFileAlias == NULL)
		return;

	NewEmulator (true, false);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::ChooseDocument
// ---------------------------------------------------------------------------
// Chooses a RAM file from an open dialog.  This method is called in response
// to an Apple event.

void CEmulatorApp::ChooseDocument (void)
{
	// Close and save the current document, if any.

	if (GetEmulatorWindow () != NULL)
	{
		if (fPreferences.fAutoSaveOnClose)
			DisposeEmulator (true, false);
		else
			DisposeEmulator ((AskToSave () == msg_OK), false);
	}

	NewEmulator (true, true);
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::FindLCDScreen
// ---------------------------------------------------------------------------

void CEmulatorApp::FindLCDScreen (void)
{
	LWindow*	window = this->GetEmulatorWindow ();
	if (window != NULL)
		fLCDScreen = dynamic_cast<CTouchScreen*> (window->FindPaneByID (kTouchScreenID));
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::IsScreenDoubleSize
// ---------------------------------------------------------------------------

bool CEmulatorApp::IsScreenDoubleSize (void)
{
	return fPreferences.fDoubleSize != 0;
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::GetHotSyncPort
// ---------------------------------------------------------------------------

Int8 CEmulatorApp::GetHotSyncPort (void) const
{
	return fPreferences.fHotSyncPort == 1 ? kPort_Modem : kPort_Printer;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::NewEmulator
// ---------------------------------------------------------------------------
// Opens the emulator window and starts the emulation.

void CEmulatorApp::NewEmulator (const Boolean iLoadMemory,
								const Boolean iShowDialog)
{
	FILE*	memFile = NULL;
	FILE*	romFile = NULL;

	// If the emulator is already running, shut it down.

	DisposeEmulator (false, false);

	// Initialize the emulator.

	try
	{
		fEmulatorWindow = LWindow::CreateWindow ((fPreferences.fDoubleSize ? kResource_LargeEmulator : kResource_SmallEmulator), LCommander::GetTopCommander ());
		ThrowAlert_IfNil (GetEmulatorWindow (), kError_CantLoadWindow, kDefaultException);
		UReanimator::LinkListenerToControls (this, GetEmulatorWindow (), (fPreferences.fDoubleSize ? kResource_LargeEmulator : kResource_SmallEmulator));

		fLCDScreen = NULL;

		romFile = this->OpenROMFile ();

		if (iLoadMemory)
			memFile = this->OpenAsFILE (fMemoryFileAlias, true, iShowDialog);

		if (romFile == NULL || (iLoadMemory && memFile == NULL))
			throw (kDefaultException);

		Emulator::Initialize (memFile, romFile, fPreferences.fDefaultMemorySize);

		fclose (memFile);
		memFile = NULL;

		fclose (romFile);
		romFile = NULL;

#if USE_THREADS
		fCPUThread = new LCPUThread;
		fCPUThread->Resume ();
#endif

		GetEmulatorWindow ()->Show ();

		// For some reason we have to select the window to activate the palette.

		WindowRef aWindow = GetEmulatorWindow ()->GetMacPort ();
		if (aWindow != NULL)
			::SelectWindow (aWindow);
	}

	catch (...)
	{
		if (memFile)
		{
			fclose (memFile);
			memFile = NULL;
		}

		if (romFile)
		{
			fclose (romFile);
			romFile = NULL;
		}

		DisposeEmulator (false, false);
	}
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::DisposeEmulator
// ---------------------------------------------------------------------------
// Closes the emulator window and stops the emulation.

void CEmulatorApp::DisposeEmulator (const Boolean iSaveMemory,
									const Boolean iShowDialog,
									const Boolean iDisposeAlias)
{
	if (GetEmulatorWindow () == NULL)
		return;

	Gremlins_Stop();

#if USE_THREADS
	if (fCPUThread)
	{
		fCPUThread->DeleteThread (NULL);
		fCPUThread = NULL;
	}
#endif

	if (iSaveMemory)
	{
		FILE*	file = this->OpenAsFILE (fMemoryFileAlias, false, iShowDialog);
		if (file)
		{
			// Memory::Save will report an error and throw an exception if it
			// couldn't save the file.  However, it's too late to do anything
			// about it now, so just swallow the exception.  !!! TBD, revisit
			// this later so that developer can free up some space before
			// quitting.

			try
			{
				Memory::Save (file);
			}
			catch (...)
			{
			}

			fclose (file);
		}
	}

	Emulator::Dispose ();

	if (GetEmulatorWindow ())
	{
		GetEmulatorWindow ()->DoClose();
		fEmulatorWindow = NULL;
	}

	if (iDisposeAlias)
	{
		::DisposeHandle ((Handle) fMemoryFileAlias);
		fMemoryFileAlias = NULL;
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::OpenAsFILE
// ---------------------------------------------------------------------------
// Opens the file specified by the alias (assumed to be an alias to a RAM
// file).  If the alias can't be resolved or iShowDialog is TRUE, the user
// is prompted to find the file.

FILE* CEmulatorApp::OpenAsFILE (AliasHandle& ioFileAlias,
								Boolean iForLoading,
								Boolean iShowDialog)
{
	// Validate the alias.

	FSSpec	aTargetFile;
	Boolean	aWasChanged;

	OSErr	aError = ResolveAlias (NULL, ioFileAlias, &aTargetFile, &aWasChanged);

	// If requested, or if the alias is invalid, display the save dialog.

	if (iShowDialog || aError != kError_NoError)
	{
		StandardFileReply	reply;

		if (iForLoading)
		{
			// Show the dialog.

			OSType aRAMFileType = '�RAM';

			StandardGetFile (NULL, 1, &aRAMFileType, &reply);

			// Exit if the user canceled.

			if (!reply.sfGood)
				return NULL;
		}
		else
		{
			// Get the prompt.

			Str255 aPromptString;
			GetIndString (aPromptString, kResource_AppStrings, kString_SavePrompt);

			// Get the default file name.

			LStr255 aDefaultString;

			if (aError == kError_NoError)
				aDefaultString = aTargetFile.name;
			else
				GetIndString (aDefaultString, kResource_AppStrings, kString_DefaultMemoryName);

			// Show the dialog.

			StandardPutFile (aPromptString, aDefaultString, &reply);

			// Exit if the user canceled.

			if (!reply.sfGood)
				return NULL;
		}

		aTargetFile = reply.sfFile;
	}

	FILE*	result = this->OpenAsFILE (aTargetFile, iForLoading);

	// If we were able to open the file, do some housekeeping.

	if (result)
	{
		// Set the file type.

		FInfo	aFileInfo;
		aError = FSpGetFInfo (&aTargetFile, &aFileInfo);
		if (aError == noErr && (aFileInfo.fdType != '�RAM' || aFileInfo.fdCreator != '�LOT'))
		{
			aFileInfo.fdType	= '�RAM';
			aFileInfo.fdCreator	= '�LOT';
			(void) FSpSetFInfo (&aTargetFile, &aFileInfo);
		}

		// Delete the old alias.

		::DisposeHandle ((Handle) ioFileAlias);
		ioFileAlias = NULL;

		// Create a new alias.

		NewAlias (NULL, &aTargetFile, &ioFileAlias);
	}

	return result;
}


FILE* CEmulatorApp::OpenAsFILE(const FSSpec& iFileSpec, Boolean iForLoading)
{
	// Save the current directory and switch over to the desired directory.

	short	curVol;
	OSErr	aError = GetVol (NULL, &curVol);

	HSetVol (NULL, iFileSpec.vRefNum, iFileSpec.parID);

	// Convert the file name to a C-string so that we can call fopen with it.

	char	fileName[64];
	memcpy (fileName, &iFileSpec.name[1], StrLength(iFileSpec.name));
	fileName[StrLength (iFileSpec.name)] = 0;

	// Open the file.

	FILE*	file = fopen (fileName, iForLoading ? "rb" : "wb");

	// Reset the directory to what it was before we started.

	SetVol (NULL, curVol);

	// If there was an error, throw an exception.

	ThrowNotify_IfNil (file, kError_CantLoadRAMFile, kDefaultException);

	return file;
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::OpenROMFile
// ---------------------------------------------------------------------------
// Opens a ROM in the current directory.  The file is opened for read-only.

static int str_compare (StringPtr t1, const char* t2, int length)
{
	int index = 0;

	while (index < length)
	{
		unsigned char	c1 = t1[index];
		unsigned char	c2 = t2[index];

		c1 = toupper(c1);
		c2 = toupper(c2);

		if (c1 != c2)
			return false;

		++index;
	}

	return true;
}

static int MatchesPattern (StringPtr name, const char* pattern)
{
	if (name[0] < strlen (pattern))
	{
		return false;
	}

	if (pattern[0] == '*')
	{
		return str_compare (&name[1 + StrLength (name) - strlen (pattern) + 1],
						 &pattern[1], strlen (pattern) - 1);
	}

	return str_compare (&name[1], pattern, strlen (pattern) - 1);
}

static FILE* FindFirstFile (const char* pattern)
{
	FILE*		romFile = NULL;
	CInfoPBRec	pb;
	Str255		name;
	OSErr		err;
	short		index = 0;

	ProcessSerialNumber	psn;
	ProcessInfoRec		pInfo;
	FSSpec				us;
	
	err = GetCurrentProcess (&psn);

	pInfo.processInfoLength	= sizeof (pInfo);
	pInfo.processName		= NULL;
	pInfo.processAppSpec	= &us;

	err = GetProcessInformation (&psn, &pInfo);
	
	do {
		pb.hFileInfo.ioCompletion	= NULL;	
		pb.hFileInfo.ioNamePtr		= name;
		pb.hFileInfo.ioVRefNum		= us.vRefNum;
		pb.hFileInfo.ioFVersNum		= 0;
		pb.hFileInfo.ioFDirIndex	= ++index;
		pb.hFileInfo.ioDirID		= us.parID;

		err = PBGetCatInfoSync (&pb);
		if (err == noErr)
		{
			if (MatchesPattern (name, pattern))
			{
				p2cstr (name);
				romFile = fopen ((const char*) name, "rb");
				c2pstr ((char*) name);
			}
		}
	} while (!romFile && err == noErr);

	// Set the file type if it's incorrect.

	if (romFile)
	{
		if (pb.hFileInfo.ioFlFndrInfo.fdType != '�ROM' ||
			pb.hFileInfo.ioFlFndrInfo.fdCreator != '�LOT')
		{
			pb.hFileInfo.ioFDirIndex			= 0;
			pb.hFileInfo.ioDirID				= pb.hFileInfo.ioFlParID;
			pb.hFileInfo.ioFlFndrInfo.fdType	= '�ROM';
			pb.hFileInfo.ioFlFndrInfo.fdCreator	= '�LOT';
			err = PBSetCatInfoSync (&pb);
		}
	}

	return romFile;
}

FILE* CEmulatorApp::OpenROMFile (void)
{
	FILE*		romFile = NULL;
	
	if (!romFile)
		romFile = FindFirstFile ("*.ROM");

	if (!romFile)
		romFile = FindFirstFile ("* ROM");

	if (!romFile)
		romFile = FindFirstFile ("ROM.*");

//	if (!romFile)
//		romFile = FindFirstFile ("ROM *");
	
	ThrowNotify_IfNil (romFile, kError_CantFindROMFile, errno);

	return romFile;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::DownloadROM
// ---------------------------------------------------------------------------
// Downloads the Palm OS ROM via the serial connection.

void CEmulatorApp::DownloadROM (void)
{
	Ptr		aROMBuffer	= NULL;
	SInt16	aFileRef	= 0;
	bool	wasOpen		= false;

	try
	{
		// See if there's enough memory to hold the ROM.

		aROMBuffer = (char*) malloc (2 * 1024L * 1024L);
		ThrowNotify_IfNil (aROMBuffer, kError_CantDownloadROM_OutOfMemory, 0);

		// Create the dialog.

		MessageT	reply	= msg_Nothing;
		SInt16		aPort	= kPort_Modem;
		SInt16		aSpeed	= baud57600;

		{
			StDialogHandler	aROMDialog (kResource_DownloadWindow, this);

			LWindow* aROMWindow = aROMDialog.GetDialog ();
			if (aROMWindow == NULL)
				throw 0L;

			// Display the dialog.

			while (reply != msg_OK && reply != msg_Cancel)
				reply = aROMDialog.DoDialog ();

			// Get the selected settings.

			LPane*	aPopup = aROMWindow->FindPaneByID (kPaneID_PortPopup);
			if (aPopup != NULL)
				aPort = ((aPopup->GetValue () == 1) ? kPort_Modem : kPort_Printer);

			aPopup = aROMWindow->FindPaneByID (kPaneID_SpeedPopup);
			if (aPopup != NULL)
			{
				switch (aPopup->GetValue ())
				{
					case 1:		aSpeed = baud57600; break;
					case 2:		aSpeed = baud38400; break;
					case 3:		aSpeed = baud28800; break;
					case 4:		aSpeed = baud19200; break;
					case 5:		aSpeed = baud14400; break;
					case 6:		aSpeed =  baud9600; break;
					case 7:		aSpeed =  baud4800; break;
					case 8:		aSpeed =  baud2400; break;
					case 9:		aSpeed =  baud1200; break;
					default:	aSpeed = baud28800; break;
				}
			}
		}

		if (reply == msg_OK)
		{
			SInt32	aByteCount		= 0;
			SInt32	aPrevCount		= 0;
			UInt32	aHeaderLong		= 0;
			UInt32	aROMSize		= 0;
			UInt16	aROMChecksum	= 0;
			UInt32	aTimeOut		= 0;
			UInt32	aTimeToProgress	= 0;
			int		aState			= 0;
			UInt8	aByte			= 0;

			wasOpen = Platform::CloseSerialPort ();

			// Initialize the serial port.

			OSErr	aError = Comm_Initialize (aPort, aSpeed);
			ThrowNotify_IfError (aError, kError_CantDownloadROM_SerialPortBusy, 0);

			// Initialize the progress dialog.

			CProgressWindow	aProgressWindow;
			aProgressWindow.InitProgress (kString_ProgressTitle, kString_WaitingCaption);

			// Wait for acknowledgement from the Palm device.

			while (aState <= 4)
			{
				if (aProgressWindow.AdvanceProgress ())
					throw 0L;

				aError = ::SerGetBuf (gInReference, &aByteCount);
				ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);

				if (aByteCount > 0)
				{
					aByte		= 255;
					aByteCount	= 1;

					aError = ::FSRead (gInReference, &aByteCount, (Ptr) &aByte);
					ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);

					switch (aState)
					{
						case 0:		// Start of sequence, looking for 0xDE
							if (aByte == 0xDE)
								aState++;
							break;

						case 1:		// Read 0xDE, looking for 0xAD
							if (aByte == 0xAD)
								aState++;
							else
								aState = 0;
							break;

						case 2:		// Read 0xAD, looking for 0xC0
							if (aByte == 0xC0)
								aState++;
							else
								aState = 0;
							break;

						case 3:		// Read 0xC0, looking for 0xDE
							if (aByte == 0xDE)
								aState++;
							else
								aState = 0;
							break;

						case 4:		// Read 0xDE, looking for non-0xDE
							if (aByte != 0xDE)
								aState++;
							else
								aState = 0;
					}
				}
			}

			// We should be synched up. Read the rest of the size.

			aByteCount = 0;

			while (aByteCount < sizeof (aROMSize) - 1)
			{
				if (aProgressWindow.AdvanceProgress ())
					throw 0L;

				aError = ::SerGetBuf (gInReference, &aByteCount);
				ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);
			}

			UInt32	aThreeBytes;
			aByteCount = sizeof (aROMSize) - 1;
			aError = ::FSRead (gInReference, &aByteCount, (Ptr) &aThreeBytes);
			ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);

			aROMSize = (aByte << 24) | (aThreeBytes >> 8);

			// Read the checksum.

			aByteCount = 0;

			while (aByteCount < sizeof (aROMChecksum))
			{
				if (aProgressWindow.AdvanceProgress ())
					throw 0L;

				aError = ::SerGetBuf (gInReference, &aByteCount);
				ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);
			}

			aByteCount = sizeof (aROMChecksum);
			aError = ::FSRead (gInReference, &aByteCount, (Ptr) &aROMChecksum);
			ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);

			// Prepare to transfer the ROM.

			aProgressWindow.SetCaption (kString_TransferCaption);
			aProgressWindow.SetModal (true);

			SInt32 aOffset	= 0;

			// Repeat until the buffer is filled, the user cancels, or a timeout occurs.

			aByteCount			= 0;
			aPrevCount			= 0;
			aTimeToProgress		= 0;
			aTimeOut			= ::TickCount () + kTicksUntilTimeout;

			while (aOffset < aROMSize)
			{
				aError = ::SerGetBuf (gInReference, &aByteCount);
				ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);

				if (aByteCount > 0)
				{
					aPrevCount = aByteCount;
					aError = ::FSRead (gInReference, &aByteCount, (Ptr) (aROMBuffer + aOffset));
					ThrowNotify_IfError (aError, kError_CantDownloadROM_Generic, 0);
					aOffset += aPrevCount;
					aTimeOut = ::TickCount () + kTicksUntilTimeout;
				}

				UInt32 aTickCount = ::TickCount ();

				if (aTickCount > aTimeOut)
					ThrowNotify_Always (kError_CantDownloadROM_Generic, 0);

				if (aTickCount > aTimeToProgress)
				{
					if (aProgressWindow.AdvanceProgress (aOffset, 0, aROMSize - 1))
						throw 0L;

					aTimeToProgress = ::TickCount () + kTicksUntilProgress;
				}
			}

			// Verify the data.

			aProgressWindow.HideProgress ();

	//		SInt16 aChecksum = Comm_Checksum (aROMBuffer, aROMSize);

	//		if ((aChecksum != 5016) && (aChecksum != -6585))
	//			Platform::ReportError (kError_InvalidROMData);

			// Get the save dialog prompt.

			Str255 aPromptString;
			::GetIndString (aPromptString, kResource_AppStrings, kString_SaveROMPrompt);

			// Get the default file name.

			Str255 aDefaultString;
			::GetIndString (aDefaultString, kResource_AppStrings, kString_ROMFileName);

			// Show the dialog.

			StandardFileReply reply;
			::StandardPutFile (aPromptString, aDefaultString, &reply);

			// Exit if the user canceled.

			if (!reply.sfGood)
				throw 0L;

			FSSpec aTargetFile = reply.sfFile;

			if (reply.sfReplacing)
				::FSpDelete (&aTargetFile);

			aError = ::FSpCreate (&aTargetFile, '�LOT', '�ROM', smCurrentScript);
			aError = ::FSpOpenDF (&aTargetFile, fsWrPerm, &aFileRef);

			ThrowNotify_IfError (aError, kError_CantWriteROM, 0);

			// Set the size of the file.

			aError = ::SetEOF (aFileRef, aROMSize);

			ThrowNotify_IfError (aError, kError_CantWriteROM, 0);

			// Write the ROM data to the file.

			aError = ::FSWrite (aFileRef, (long*) &aROMSize, aROMBuffer);

			ThrowNotify_IfError (aError, kError_CantWriteROM, 0);
		}
	}

	catch (...)
	{
	}

	// Clean up.

	LCommander::SetUpdateCommandStatus (true);

	Comm_Dispose ();

	free (aROMBuffer);

	if (aFileRef != 0)
		::FSClose (aFileRef);

	if (wasOpen)
		Platform::OpenSerialPort ();

	return;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CEmulatorApp::OpenPorts
// ---------------------------------------------------------------------------

OSErr CEmulatorApp::OpenPorts (void)
{
	return PPCOpenPorts (kEmulatorPortName, kDebuggerPortName,
						kFromEmulatorPortType, kToEmulatorPortType);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::ListenForPacket
// ---------------------------------------------------------------------------

void CEmulatorApp::ListenForPacket (void)
{
	PPCListenForData (&gReceivePort);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::HandlePacket
// ---------------------------------------------------------------------------
// A packet has shown up from the debugger; do something with it.

void CEmulatorApp::HandlePacket (void)
{
#if __profile__

//	short	oldStatus = ProfilerGetStatus ();
//	ProfilerSetStatus (true);

#endif

	char	buffer[	sizeof (SlkPktHeaderType) +
					sizeof (SysPktBodyType) +
					sizeof (SlkPktFooterType)];
	PPCReceiveData (&buffer, sizeof (buffer));
	Debug::HandleNewPacket (*(SlkPktHeaderType*) buffer,
							*(SysPktBodyType*) &buffer[sizeof(SlkPktHeaderType)]);

	gReceivePort.fDataWaiting = false;

#if __profile__

//	ProfilerSetStatus (oldStatus);
//	ProfilerDump("\pEmulator.prof");

#endif
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::SendPacket
// ---------------------------------------------------------------------------

OSErr CEmulatorApp::SendPacket (const void* pkt, long size)
{
	return PPCSendData (pkt, size);
}


// ---------------------------------------------------------------------------
//		� CEmulatorApp::ClosePorts
// ---------------------------------------------------------------------------

OSErr CEmulatorApp::ClosePorts (void)
{
	return PPCClosePorts ();
}



#if 0

// We might want this code if we want a free-running timer for the RTC.

Listing 4. Extended Time Manager definitions 

#include <Types.h>
#include <Timer.h>
#include <OSUtils.h>
#include <GestaltEqu.h>
#include <Processes.h>

/* Define an extended task record. */
struct ExtendedTimerRec
{
	TMTask               tmTask;
	ProcessSerialNumber  taskPSN;
#if GENERATINGPOWERPC
	/* Nothing needed for PowerPC */
#else
	long                  applicationA5;
#endif
};
typedef struct ExtendedTimerRec ExtendedTimerRec, *ExtendedTimerPtr;

	/* Define the interface for a completion function. */
#if GENERATINGPOWERPC
	pascal void TimerCallbackProc(TMTaskPtr tmTaskPtr);
#else      /* 680x0 */
	pascal void TimerCallbackProc(void);
	/*
	* This inline function returns the extended Time Manager task 
	* pointer, which is passed to the completion routine in register A1.
	*/
	pascal TMTaskPtr GetTMTaskPtr(void) = 0x2E89;
#endif



Before you can use your extended task record, you need to be sure the extended
Time Manager and Process Manager are present on the system. Listing 5 shows code
that checks for their presence. If they're present, the code initializes the extended
task record (gExtendedTimerRec), installs the task in the extended Time Manager's event
queue, and starts the timer.



Listing 5. Starting the timer 

	long         gestaltResponse;

	if (Gestalt(gestaltTimeMgrVersion, &gestaltResponse) != noErr
		|| (gestaltResponse < gestaltExtendedTimeMgr))
		goto failure;   /* The extended Time Manager is not present. */
	if (Gestalt(gestaltOSAttr, &gestaltResponse) != noErr
		|| (gestaltResponse & (1L << gestaltLaunchControl)) == 0)
		goto failure;   /* The Process Manager is not present. */
	/*
	* Configure the global structure that stores the timing information.
	*/
	gExtendedTimerRec.tmTask.qLink = NULL;
	gExtendedTimerRec.tmTask.qType = 0;
	gExtendedTimerRec.tmTask.tmAddr = NewTimerProc(TimerCallbackProc);
	gExtendedTimerRec.tmTask.tmCount = 0;
	gExtendedTimerRec.tmTask.tmWakeup = 0;
	gExtendedTimerRec.tmTask.tmReserved = 0;
#if GENERATINGPOWERPC
	/* Nothing needed for PowerPC. */
#else
	gExtendedTimerRec.applicationA5 = SetCurrentA5();
#endif
	GetCurrentProcess(&gExtendedTimerRec.taskPSN);
	InsXTime((QElemPtr) &gExtendedTimerRec.tmTask);
	/*
	* Start the timer -- 30-second stall.
	*/
	PrimeTime((QElemPtr) &gExtendedTimerRec.tmTask, 30000L);



You also need to define the extended Time Manager completion routine that's called
when the timer expires (see Listing 6).



Listing 6. Extended Time Manager completion routine 

/*  * Define an extended Time Manager completion routine that awakens the 
 * specified application.
 */
#if GENERATINGPOWERPC
pascal void TimerCallbackProc(TMTaskPtr tmTaskPtr)
{
#else
pascal void TimerCallbackProc(void)
{
	TMTaskPtr      tmTaskPtr;
	long           oldA5;

	tmTaskPtr = GetTMTaskPtr();
	oldA5 = SetA5(((ExtendedTimerPtr) tmTaskPtr)->applicationA5);
#endif
	gTimerFired = TRUE;
	WakeUpProcess(&((ExtendedTimerPtr) tmTaskPtr)->taskPSN);
#if GENERATINGPOWERPC
	/* Nothing needed at completion routine exit. */
#else
	SetA5(oldA5);
#endif
}



The completion routine is a one-shot timer that awakens the process and exits.
You can easily extend this to perform a periodic wake-up action. Again, note
the use of A5 (use A4 for nonapplication code written in THINK or CodeWarrior).
#endif
