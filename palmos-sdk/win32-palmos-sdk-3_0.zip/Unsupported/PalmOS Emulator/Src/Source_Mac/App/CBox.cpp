/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CBox.h"
#include <UDrawingState.h>
#include <UDrawingUtils.h>


// ---------------------------------------------------------------------------
//		� CBox::CBox
// ---------------------------------------------------------------------------

CBox::CBox (void)
{
	mBoxType = kBoxType_BlackFrame;
}


// ---------------------------------------------------------------------------
//		� CBox::CBox
// ---------------------------------------------------------------------------

CBox::CBox (const CBox& iOriginalBox) : LPane (iOriginalBox)
{
	mBoxType = iOriginalBox.mBoxType;
}


// ---------------------------------------------------------------------------
//		� CBox::CBox
// ---------------------------------------------------------------------------

CBox::CBox (const SPaneInfo&	iPaneInfo,
			const BoxType		iBoxType) : LPane (iPaneInfo)
{
	mBoxType = iBoxType;
}


// ---------------------------------------------------------------------------
//		� CBox::CBox
// ---------------------------------------------------------------------------

CBox::CBox (LStream* iStream) : LPane (iStream)
{
	short aType = (short) kBoxType_BlackFrame;

	iStream->ReadData (&aType, sizeof (short));
	iStream->ReadData (&mEraseContents, sizeof (Boolean));

	mBoxType = (BoxType) aType;
}


// ---------------------------------------------------------------------------
//		� CBox::~CBox
// ---------------------------------------------------------------------------

CBox::~CBox (void)
{
}


// ---------------------------------------------------------------------------
//		� CBox::CreateBoxStream
// ---------------------------------------------------------------------------

CBox* CBox::CreateBoxStream (LStream* iStream)
{
	return new CBox (iStream);
}


// ---------------------------------------------------------------------------
//		� CBox::DrawSelf
// ---------------------------------------------------------------------------

void CBox::DrawSelf (void)
{
	// Get the bounds of the pane.

	Rect aFrame;
	CalcLocalFrameRect (aFrame);

	// Create a device loop.

	::PenNormal ();
	StDeviceLoop devices (aFrame);

	// Draw the frame on each device in the appropriate depth.

	Int16 aDepth;
	while (devices.NextDepth (aDepth))
	{
		// Save the pen state.

		StColorPenState aSavePen;

		// Set the standard fore and back colors.

		RGBColor aRGBWhite = { 0xFFFF, 0xFFFF, 0xFFFF };
		RGBColor aRGBBlack = { 0x0000, 0x0000, 0x0000 };

		if (aDepth > 2)
		{
			::RGBForeColor (&aRGBBlack);
			::RGBBackColor (&aRGBWhite);
		}
		else
		{
			::ForeColor (blackColor);
			::BackColor (whiteColor);
		}

		// Erase the contents of the frame, if requested.

		if (mEraseContents)
		{
			::InsetRect (&aFrame, 1, 1);
			::EraseRect (&aFrame);
			::InsetRect (&aFrame, -1, -1);
		}

		// Draw the right kind of frame.

		switch (mBoxType)
		{
			case kBoxType_BlackFrame:
				::FrameRect (&aFrame);
				break;

			case kBoxType_3DFrame:
				Draw_3DFrame (aFrame, aDepth);
				break;

			case kBoxType_3DDefaultButtonFrame:
				Draw_3DDefaultButtonFrame (aFrame, aDepth);
				break;

			case kBoxType_3DRecessedFrame:
				Draw_3DRecessedFrame (aFrame, aDepth);
				break;
		}
	}
}


// ---------------------------------------------------------------------------
//		� CBox::Draw_3DFrame
// ---------------------------------------------------------------------------
// Draws a 3D inset border around the specified frame.  If the target screen
// is monochrome, the border is drawn as a one pixel black frame.

void CBox::Draw_3DFrame (	const Rect&		iFrame,
							const short		iDepth)
{
	Rect aFrame = iFrame;

	// Draw a 3D inset frame if color is available.

	if (iDepth > 2)
	{
		RGBColor aRGBWhite = { 0xFFFF, 0xFFFF, 0xFFFF };
		RGBColor aRGBGray  = { 0x7777, 0x7777, 0x7777 };

		// Draw the white highlight.

		aFrame.left++; aFrame.top++;
		::RGBForeColor (&aRGBWhite);

		// Draw a line if the frame is less than five pixels in height.

		if (aFrame.bottom - aFrame.top < 5)
		{
			::MoveTo (aFrame.left - 1, aFrame.top);
			::LineTo (aFrame.right, aFrame.top);
		}

		// Otherwise, draw a rectangle.

		else
			::FrameRect (&aFrame);

		// Draw the dark frame.

		::RGBForeColor (&aRGBGray);

		::MoveTo (aFrame.right, aFrame.top - 1);
		::LineTo (aFrame.left - 1, aFrame.top - 1);

		// Don't draw the rest if the frame is less than five pixels in height.

		if (aFrame.bottom - aFrame.top >= 5)
		{
			::LineTo (aFrame.left - 1, aFrame.bottom);
			::MoveTo (aFrame.left + 1, aFrame.bottom - 2);
			::LineTo (aFrame.right - 2, aFrame.bottom - 2);
			::LineTo (aFrame.right - 2, aFrame.top + 1);
		}
	}

	// Otherwise, draw a standard one pixel black frame.

	else
	{
		// The bottom right sides must be inset so that they
		// match the location of the black part of the frame
		// when it is drawn in color.  Otherwise, the frame
		// looks slightly larger in b/w than it does in color.

		aFrame.right--; aFrame.bottom--;

		::ForeColor (blackColor);

		// Draw a divider line if the frame is less than five pixels in height.

		if (aFrame.bottom - aFrame.top < 5)
		{
			::MoveTo (aFrame.left, aFrame.top);
			::LineTo (aFrame.right, aFrame.top);
		}

		// Otherwise, draw a rectangle.

		else
			::FrameRect (&aFrame);
	}
}


// ---------------------------------------------------------------------------
//		� CBox::Draw_3DDefaultButtonFrame
// ---------------------------------------------------------------------------
// Draws a 3D round rectangle frame for the border of a default button.  If
// the target screen is monochrome, a standard three pixel black frame is
// drawn.

void CBox::Draw_3DDefaultButtonFrame (const Rect&		iFrame,
										const short		iDepth)
{
	Rect aFrame = iFrame;

	// Draw a 3D frame if the target screen has enough color depth.

	if (iDepth >= 4)
	{
		RGBColor aForeColor;

		::InsetRect (&aFrame, 1, 1);
		aFrame.right--;
		aFrame.bottom--;

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xDDDD;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.right - 4, aFrame.top + 1);
		::LineTo (aFrame.left + 4, aFrame.top + 1);
		::Line (-1, 1);
		::Line (-1, 0);
		::Line (0, 1);
		::Line (-1, 1);
		::LineTo (aFrame.left + 1, aFrame.bottom - 4);

		::MoveTo (aFrame.left + 2, aFrame.top);
		::Line (-2, 2);
		::MoveTo (aFrame.right, aFrame.bottom - 2);
		::Line (-2, 2);
		::MoveTo (aFrame.left, aFrame.bottom - 2);
		::Line (2, 2);
		::MoveTo (aFrame.right - 2, aFrame.top);
		::Line (2, 2);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xCCCC;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.right - 3, aFrame.top + 1);
		::Line (1, 1);
		::MoveTo (aFrame.left + 1, aFrame.bottom - 3);
		::Line (1, 1);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x8888;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.right - 1, aFrame.top + 3);
		::Line (0, 0);
		::MoveTo (aFrame.left + 3, aFrame.bottom - 1);
		::Line (0, 0);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x7777;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.right - 1, aFrame.top + 4);
		::LineTo (aFrame.right - 1, aFrame.bottom - 3);
		::Line (-1, 0);
		::Line (0, 1);
		::Line (-1, 0);
		::Line (0, 1);
		::LineTo (aFrame.left + 4, aFrame.bottom - 1);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0xAAAA;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.left + 3, aFrame.top + 1);
		::Line (-2, 0);
		::Line (0, 2);
		::MoveTo (aFrame.right - 1, aFrame.top + 1);
		::Line (0, 0);
		::MoveTo (aFrame.right - 1, aFrame.bottom - 1);
		::Line (0, 0);
		::MoveTo (aFrame.left + 1, aFrame.bottom - 1);
		::Line (0, 0);

		::MoveTo (aFrame.left + 2, aFrame.top + 4);
		::Line (2, -2);
		::LineTo (aFrame.right - 3, aFrame.top + 2);
		::Line (0, 1);
		::Line (1, 0);
		::LineTo (aFrame.right - 2, aFrame.bottom - 4);
		::Line (-2, 2);
		::LineTo (aFrame.left + 3, aFrame.bottom - 2);
		::Line (0, -1);
		::Line (-1, 0);
		::LineTo (aFrame.left + 2, aFrame.top + 4);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x0000;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.left + 3, aFrame.top);
		::LineTo (aFrame.left, aFrame.top + 3);
		::LineTo (aFrame.left, aFrame.bottom - 3);
		::LineTo (aFrame.left + 3, aFrame.bottom);
		::LineTo (aFrame.right - 3, aFrame.bottom);
		::LineTo (aFrame.right, aFrame.bottom - 3);
		::LineTo (aFrame.right, aFrame.top + 3);
		::LineTo (aFrame.right - 3, aFrame.top);
		::LineTo (aFrame.left + 3, aFrame.top);

		aForeColor.red = aForeColor.green = aForeColor.blue = 0x4444;
		::RGBForeColor (&aForeColor);

		::MoveTo (aFrame.left + 3, aFrame.top);
		::Line (0, 0);
		::Move (-3, 3);
		::Line (0, 0);
		::MoveTo (aFrame.right, aFrame.bottom - 3);
		::Line (0, 0);
		::Move (-3, 3);
		::Line (0, 0);
		::MoveTo (aFrame.left, aFrame.bottom - 3);
		::Line (0, 0);
		::Move (3, 3);
		::Line (0, 0);
		::MoveTo (aFrame.right - 3, aFrame.top);
		::Line (0, 0);
		::Move (3, 3);
		::Line (0, 0);
	}

	// The screen is not deep enough.  Draw the standard three pixel border.

	else
	{
		::PenSize (3, 3);
		::FrameRoundRect (&aFrame, 16, 16);
	}
}


// ---------------------------------------------------------------------------
//		� CBox::Draw_3DRecessedFrame
// ---------------------------------------------------------------------------
// Draws a recessed 3D border around the specified frame.  This type of frame
// is used for text fields and lists to give them a recessed look.  Recessed
// frames do not draw in monochrome.

void CBox::Draw_3DRecessedFrame (	const Rect&		iFrame,
									const short		iDepth)
{
	Rect aFrame = iFrame;

	// Draw a 3D recessed frame if color is available.

	if (iDepth > 2)
	{
		RGBColor aRGBWhite = { 0xFFFF, 0xFFFF, 0xFFFF };
		RGBColor aRGBGray  = { 0x8888, 0x8888, 0x8888 };

		// Draw the dark frame.

		::RGBForeColor (&aRGBGray);
		::MoveTo (aFrame.right - 1, aFrame.top);
		::LineTo (aFrame.left, aFrame.top);
		::LineTo (aFrame.left, aFrame.bottom - 1);

		// Draw the white highlight.

		::RGBForeColor (&aRGBWhite);
		::MoveTo (aFrame.right - 1, aFrame.top + 1);
		::LineTo (aFrame.right - 1, aFrame.bottom - 1);
		::LineTo (aFrame.left + 1, aFrame.bottom - 1);
	}
}
