/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once


// Alert constants.

const short kAlertItem_OKButton			= 1;
const short kAlertItem_DefaultFrame		= 2;
const short kAlertItem_CancelButton		= 3;
const short kFont_PandoraEspi			= 9841;

// Key constants.

const char	kKey_Return					= 13;
const char	kKey_Enter					= 3;
const char	kKey_Escape					= 27;
const char	kKey_Tab					= 9;
const char	kKey_ArrowLeft				= 28;
const char	kKey_ArrowRight				= 29;
const char	kKey_ArrowUp				= 30;
const char	kKey_ArrowDown				= 31;
const char	kKey_Delete					= 8;
const char	kKey_PageUp					= 11;
const char	kKey_PageDown				= 12;
const char	kKey_Home					= 1;
const char	kKey_End					= 4;

// Function prototypes.

pascal void		UserItem_Frame (DialogRef iDialog, short iItem);
pascal void		UserItem_GrayFrame (DialogRef iDialog, short iItem);
pascal void		UserItem_DefaultFrame (DialogRef iDialog, short iItem);

void			SetUserItemProcedure (DialogRef iDialog, short iItem, UserItemUPP iProcedure);

short			GetItemType (DialogRef iDialog, short iItem);

void			SetItemSelect (DialogRef iDialog, short iItem, short iSelect);
Boolean			GetItemSelect (DialogRef iDialog, short iItem);

short			GetItemValue (DialogRef iDialog, short iItem);

void			SetItemEnable (DialogRef iDialog, short iItem, Boolean iEnable);
Boolean			GetItemEnable (DialogRef iDialog, short iItem);

void			GetItemRect (DialogRef iDialog, short iItem, Rect& oRect);
void			SetItemRect (DialogRef iDialog, short iItem, const Rect& iRect);

void			GetItemText (DialogRef iDialog, short iItem, Str255 oText);
void			SetItemText (DialogRef iDialog, short iItem, Str255 iText);

void			SetButtonText (DialogRef iDialog, short iItem, Str255 iText);

void			PressButton (DialogRef iDialog, short iItem);

Boolean			PortIsColor (GrafPtr iPort);

void			GetWindowContentColor (WindowRef iWindow, RGBColor& oContentColor);

void			SetDialogFontToEspi (DialogRef iDialog);

pascal Boolean	StandardAlertFilter (DialogRef iDialog, EventRecord* iEvent, short* oItem);
short			StandardAlert (short iDialogID, Boolean iBeep = true);
