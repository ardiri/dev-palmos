/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "CProgressWindow.h"

#include "CEmulatorApp.h"


// ---------------------------------------------------------------------------
//		� CProgressWindow::CProgressWindow
// ---------------------------------------------------------------------------
// Constructs an uninitialized progress window.

CProgressWindow::CProgressWindow (void)
{
	mProgressWindow		= NULL;
	mProgressPane		= NULL;
	mCaptionPane		= NULL;
	mAdvanceTime		= 0;
	mFirstTime			= true;
	mWasCanceled		= false;
	mIsModal			= false;
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::~CProgressWindow
// ---------------------------------------------------------------------------

CProgressWindow::~CProgressWindow (void)
{
	delete mProgressWindow;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CProgressWindow::InitProgress
// ---------------------------------------------------------------------------
// Prepares the progress dialog.

void CProgressWindow::InitProgress (const SInt16 iTitle,
									const SInt16 iCaption)
{
	if (mProgressWindow == NULL)
		mProgressWindow = LWindow::CreateWindow (kResource_ProgressWindow, LCommander::GetDefaultCommander ());

	if (mProgressWindow != NULL)
	{
		UReanimator::LinkListenerToControls (this, mProgressWindow, kResource_ProgressWindow);
		mProgressPane = (CProgressPane*) mProgressWindow->FindPaneByID (kPaneID_Indicator);

		LStr255 aTitleString;
		aTitleString.Assign (kResource_Strings, iTitle);
		mProgressWindow->SetDescriptor (aTitleString);

		mCaptionPane = (LCaption*) mProgressWindow->FindPaneByID (kPaneID_Text);
		SetCaption (iCaption);
	}

	mAdvanceTime = LMGetTicks ();
	mWasCanceled = false;
	mFirstTime = true;
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::SetCaption
// ---------------------------------------------------------------------------

void CProgressWindow::SetCaption (const SInt16 iCaption)
{
	if (mCaptionPane != NULL)
	{
		LStr255 aCaptionString;
		aCaptionString.Assign (kResource_Strings, iCaption);
		mCaptionPane->SetDescriptor (aCaptionString);
	}

	if (mProgressWindow != NULL)
		mProgressWindow->Draw (NULL);
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::SetCaption
// ---------------------------------------------------------------------------

void CProgressWindow::SetCaption (Str255 iCaption)
{
	if (mCaptionPane != NULL)
		mCaptionPane->SetDescriptor (iCaption);

	if (mProgressWindow != NULL)
		mProgressWindow->Draw (NULL);
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::SetModal
// ---------------------------------------------------------------------------
// Changes the modality of the progress window by enabling or disabling the
// stop button and by allow or disallowing event processing.

void CProgressWindow::SetModal (const Boolean iIsModal)
{
	mIsModal = iIsModal;

	if (mProgressWindow != NULL)
	{
		LStdButton* aStopButton = (LStdButton*) mProgressWindow->FindPaneByID (kPaneID_StopButton);
		if (aStopButton != NULL)
		{
			if (iIsModal)
				aStopButton->Disable ();
			else
				aStopButton->Enable ();
		}
	}
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::ShowProgress
// ---------------------------------------------------------------------------

void CProgressWindow::ShowProgress (const Boolean iResetCounter)
{
	if (iResetCounter)
	{
		mAdvanceTime = LMGetTicks ();
		mWasCanceled = false;
		mFirstTime = true;
	}
	else if (mProgressWindow != NULL)
	{
		mProgressWindow->Show ();
		mProgressWindow->Activate ();
		mProgressWindow->Draw (NULL);

		// Update all of the windows.

		SInt16 aWindowIndex = 0;
		LWindow* aWindow = NULL;

		while ((aWindow = LWindow::FetchWindowObject (UWindows::FindNthWindow (++aWindowIndex))) != NULL)
			aWindow->UpdatePort ();

		mAdvanceTime = 0;
		mWasCanceled = false;
		mFirstTime = false;

		LCommander::SetUpdateCommandStatus (false);
	}
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::HideProgress
// ---------------------------------------------------------------------------

void CProgressWindow::HideProgress (void)
{
	if (mProgressWindow != NULL)
		mProgressWindow->Hide ();
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� CProgressWindow::AdvanceProgress
// ---------------------------------------------------------------------------
// Increments the unmeasured progress indicator.

Boolean CProgressWindow::AdvanceProgress (void)
{
	if (mProgressPane != NULL)
	{
		if (LMGetTicks () > mAdvanceTime)
		{
			mProgressPane->AdvanceProgress ();

			if (mFirstTime)
				ShowProgress ();

			if (!mIsModal)
				gApplication->ProcessNextEvent ();

			mAdvanceTime = LMGetTicks () + kTicksBetweenProgress;
		}
	}

	return mWasCanceled;
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::AdvanceProgress
// ---------------------------------------------------------------------------
// Increments the measured progress indicator.

Boolean CProgressWindow::AdvanceProgress (const SInt32		iCurrent,
											const SInt32	iStart,
											const SInt32	iEnd)
{
	static SInt32 aCurrent = -1;
	static SInt32 aStart = -1;
	static SInt32 aEnd = -1;

	if (LMGetTicks () > mAdvanceTime)
	{
		if (mProgressPane != NULL)
			if ((aCurrent != iCurrent) || (aStart != iStart) || (aEnd != iEnd))
			{
				aCurrent = iCurrent;
				aStart = iStart;
				aEnd = iEnd;

				mProgressPane->AdvanceProgress (iCurrent, iStart, iEnd);
			}

		if (mFirstTime)
			ShowProgress ();

		if (!mIsModal)
			gApplication->ProcessNextEvent ();

		mAdvanceTime = LMGetTicks () + kTicksBetweenProgress;
	}

	return mWasCanceled;
}


// ---------------------------------------------------------------------------
//		� CProgressWindow::ListenToMessage
// ---------------------------------------------------------------------------
// Responds to the stop button.

void CProgressWindow::ListenToMessage (	MessageT	iMessage,
										void*		ioParameter)
{
#pragma unused (ioParameter)

	if (iMessage == kPaneID_StopButton)
		mWasCanceled = true;
}
