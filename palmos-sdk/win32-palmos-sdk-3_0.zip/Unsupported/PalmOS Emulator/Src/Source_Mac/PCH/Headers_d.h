// ===========================================================================
//	Headers_d.h				   �1996-1997 Metrowerks Inc. All rights reserved.
// ===========================================================================

#if __MWERKS__ == 0x2000

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2000_d_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2000_d_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2000_d_68K"
	#endif

#elif __MWERKS__ == 0x2010

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2010_d_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2010_d_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2010_d_68K"
	#endif

#elif __MWERKS__ == 0x2100

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2100_d_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2100_d_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2100_d_68K"
	#endif

#else

	#error "Unsupported compiler version"

#endif
