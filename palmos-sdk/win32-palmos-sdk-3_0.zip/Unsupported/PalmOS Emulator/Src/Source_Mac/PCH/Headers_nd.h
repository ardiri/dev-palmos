// ===========================================================================
//	Headers_nd.h			   �1996-1997 Metrowerks Inc. All rights reserved.
// ===========================================================================

#if __MWERKS__ == 0x2000

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2000_nd_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2000_nd_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2000_nd_68K"
	#endif

#elif __MWERKS__ == 0x2010

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2010_nd_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2010_nd_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2010_nd_68K"
	#endif

#elif __MWERKS__ == 0x2100

	#if __POWERPC__
		#include ":Source_Mac:PCH:Headers_0x2100_nd_PPC"
	#elif __CFM68K__
		#include ":Source_Mac:PCH:Headers_0x2100_nd_CFM68K"
	#else
		#include ":Source_Mac:PCH:Headers_0x2100_nd_68K"
	#endif

#else

	#error "Unsupported compiler version"

#endif
