/*===================================================================================*\

		� 1997 Illume Software, Inc.  All rights reserved.  
			
		This work is subject to U.S. and international copyright laws and treaties.  
		No part of this work may be used, practiced, performed, copied, distributed, 
		revised, modified, translated, abridged, condensed, expanded, collected,
		compiled, linked, recast, transformed, or adapted without the prior written 
		consent of Illume Software, Inc.  Any use or exploitation of this work 
		without authorization could subject the perpetrator to criminal liability.  
			
/*===================================================================================*\

		File:			Copilot WDEF.cp
		Author:		C. B. Schofield
		History:	02/15/97 - Created.
	
		Comments:	The Copilot WDEF is a definition for a simple window style that is
							shaped like the Copilot case picture.

\*===================================================================================*/


#include <A4Stuff.h>
#include "Copilot WDEF.h"


pascal SInt32 main (SInt16			iVariation, 
										WindowPtr		iWindow, 
										SInt16			iMessage, 
										SInt32			iParameter)

{
	#pragma unused (iVariation)
	#pragma unused (iParameter)
	
	EnterCodeResource ();
	
	// Initialize the return value.
	
	SInt32 aReturnValue = 0;
	
	// Get a pointer to the internals of the window.
	
	WindowPeek aWindowPeek = (WindowPeek) iWindow;
	
	// Handle the message.
	
	switch (iMessage)
	{
		// Calculate the content and structure regions of the window.
		
		case wCalcRgns:
			
			// Set up the port.
			
			GrafPtr aSavePort;
			GetPort (&aSavePort);
			SetPort (iWindow);
			
			// Get the bounds of the window in global coordinates.
			
			Rect aWindowRect = iWindow->portRect;
			LocalToGlobal ((Point*) &aWindowRect.top);
			LocalToGlobal ((Point*) &aWindowRect.bottom);
			
			GrafPtr aWindowPort;
			::GetWMgrPort (&aWindowPort);
			::SetPort (aWindowPort);
			
			// Normalize the pen.
		
			PenState aSavePen;
			::GetPenState (&aSavePen);
			::PenNormal ();
			
			// Clear out the old content region and prepare to redefine it.
			
			::SetEmptyRgn (aWindowPeek->contRgn);
			::OpenRgn ();

			// Plot the points that frame the shape of the Copilot case.
			
			Point aSmallPoints[16] = {	{   2,   0 }, {   0,   2 }, {   0, 216 }, {   2, 219 }, { 308, 219 }, 
																	{ 309, 218 }, { 312, 212 }, { 313, 211 }, { 330, 211 }, { 333, 209 }, 
																	{ 333,  10 }, { 331,   8 }, { 307,   8 }, { 307,   2 }, { 305,   0 }, 
																	{   2,   0 } };
			
			Point aLargePoints[61] = {	{   7,   0 }, {   7,   1 }, {   5,   1 }, {   1,   5 }, {   1,   7 }, 
																	{   0,   7 }, {   0, 429 }, {   1, 429 }, {   1, 430 }, {   5, 434 }, 
																	{   7, 435 }, {   7, 436 }, { 614, 436 }, { 614, 435 }, { 615, 435 }, 
																	{ 618, 432 }, { 618, 431 }, { 619, 431 }, { 619, 429 }, { 620, 429 }, 
																	{ 620, 426 }, { 621, 426 }, { 621, 423 }, { 622, 423 }, { 622, 420 }, 
																	{ 657, 420 }, { 657, 419 }, { 658, 419 }, { 663, 414 }, { 663, 413 }, 
																	{ 664, 413 }, { 664,  23 }, { 604,  23 }, { 664,  23 }, { 663,  23 }, 
																	{ 663,  21 }, { 662,  21 }, { 662,  20 }, { 661,  20 }, { 661,  19 }, 
																	{ 660,  19 }, { 660,  18 }, { 658,  18 }, { 658,  17 }, { 656,  17 }, 
																	{ 656,  16 }, { 612,  16 }, { 612,   8 }, { 611,   8 }, { 611,   6 }, 
																	{ 610,   6 }, { 610,   4 }, { 609,   4 }, { 609,   3 }, { 608,   3 }, 
																	{ 608,   2 }, { 607,   2 }, { 607,   1 }, { 605,   1 }, { 605,   0 }, 
																	{   7,   0 } };																	
			
			SInt32	aPointCount = 16;
			Point*	aRegionPoints = aSmallPoints;
			
			// Choose the larger size if requested.
			
			if (iVariation == 1)
			{
				aPointCount = 61;
				aRegionPoints = aLargePoints;
			}
				
			::MoveTo (aRegionPoints[0].h + aWindowRect.left, aRegionPoints[0].v + aWindowRect.top);
			
			for (SInt16 aPointIndex = 1; aPointIndex < aPointCount; aPointIndex++)
				::LineTo (aRegionPoints[aPointIndex].h + aWindowRect.left, aRegionPoints[aPointIndex].v + aWindowRect.top);

			// Close the content region.

			::CloseRgn (aWindowPeek->contRgn);

			// The structure region is an exact copy of the content region.
			
			::CopyRgn (aWindowPeek->contRgn, aWindowPeek->strucRgn);
			
			// Clean up.
			
			::SetPenState (&aSavePen);
			::SetPort (aSavePort);
			
			break;
			
		// Return the part of the window that is currently under the mouse.
			
		case wHit:
		
			if (aWindowPeek->visible)
				aReturnValue = wInContent;
				
			break;
	}
	
	ExitCodeResource ();

	return (aReturnValue);
}