/*===================================================================================*\

		� 1997 Illume Software, Inc.  All rights reserved.  
			
		This work is subject to U.S. and international copyright laws and treaties.  
		No part of this work may be used, practiced, performed, copied, distributed, 
		revised, modified, translated, abridged, condensed, expanded, collected,
		compiled, linked, recast, transformed, or adapted without the prior written 
		consent of Illume Software, Inc.  Any use or exploitation of this work 
		without authorization could subject the perpetrator to criminal liability.  
			
/*===================================================================================*\

		File:			Copilot WDEF.h
		Author:		C. B. Schofield
		History:	02/15/97 - Created.
	
		Comments:	The Copilot WDEF is a definition for a simple window style that is
							shaped like the Copilot case picture.

\*===================================================================================*/


#pragma once

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=mac68k
#endif

#ifdef __cplusplus
extern "C" {
#endif


pascal SInt32 main (SInt16 iVariation, WindowPtr iWindow, SInt16 iMessage, SInt32 iParameter);


#ifdef __cplusplus
}
#endif

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=reset
#endif
