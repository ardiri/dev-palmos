/* The number of bytes in a char.  */
#define SIZEOF_CHAR 1

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* The number of bytes in a int.  */
#define SIZEOF_INT 0	// Goofy, but it gets us what we want: shorts
						// for 2-byte types and longs for 4-byte types

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

#ifdef __GNUC__
/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8
#define SIZEOF___INT64 0
#else
#define SIZEOF_LONG_LONG 0
#define SIZEOF___INT64 8
#endif

#define REGPARAM
#define DONT_HAVE_REAL_POSIX
#define EXEC_TYPES_H

#include <stdio.h>
#include <string.h>
#include <fcntl.h>

#ifdef __MWERKS__
	#include <unix.h>		// open()
#endif

#ifdef _MSC_VER
	#include <io.h>			// open()

	#pragma warning( disable : 4065 )	// warning C4065: switch statement contains 'default' but no 'case' labels
	#pragma warning( disable : 4068 )	// warning C4068: unknown pragma
	#pragma warning( disable : 4101 )	// warning C4101: 'exitWinPtr' : unreferenced local variable
	#pragma warning( disable : 4102 )	// warning C4102: 'l8' : unreferenced label
	#pragma warning( disable : 4244 )	// warning C4244: 'initializing' : conversion from 'unsigned long' to 'unsigned short', possible loss of data
#endif

#define __inline__ inline
