#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_4000)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4000) - NEGX

void REGPARAM2 CPU_OP_NAME(_4010)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4010 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4010) - NEGX

void REGPARAM2 CPU_OP_NAME(_4018)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4018 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4018) - NEGX

void REGPARAM2 CPU_OP_NAME(_4020)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4020 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4020) - NEGX

void REGPARAM2 CPU_OP_NAME(_4028)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4028 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4028) - NEGX

void REGPARAM2 CPU_OP_NAME(_4030)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4030 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4030) - NEGX

void REGPARAM2 CPU_OP_NAME(_4038)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4038 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4038) - NEGX

void REGPARAM2 CPU_OP_NAME(_4039)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4039 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4039) - NEGX

void REGPARAM2 CPU_OP_NAME(_4040)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4040) - NEGX

void REGPARAM2 CPU_OP_NAME(_4050)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4050 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4050) - NEGX

void REGPARAM2 CPU_OP_NAME(_4058)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4058 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4058) - NEGX

void REGPARAM2 CPU_OP_NAME(_4060)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4060 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4060) - NEGX

void REGPARAM2 CPU_OP_NAME(_4068)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4068 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4068) - NEGX

void REGPARAM2 CPU_OP_NAME(_4070)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4070 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4070) - NEGX

void REGPARAM2 CPU_OP_NAME(_4078)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4078 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4078) - NEGX

void REGPARAM2 CPU_OP_NAME(_4079)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEGX.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4079 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4079) - NEGX

void REGPARAM2 CPU_OP_NAME(_4080)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, srcreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf NEGX.L Rn 6(1/0)
}}}}}
// PERFDATA_4080 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_4080) - NEGX

void REGPARAM2 CPU_OP_NAME(_4090)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}
// PERFDATA_4090 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4090) - NEGX

void REGPARAM2 CPU_OP_NAME(_4098)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}}
// PERFDATA_4098 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4098) - NEGX

void REGPARAM2 CPU_OP_NAME(_40a0)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}}
// PERFDATA_40a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_40a0) - NEGX

void REGPARAM2 CPU_OP_NAME(_40a8)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}
// PERFDATA_40a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_40a8) - NEGX

void REGPARAM2 CPU_OP_NAME(_40b0)(uae_u32 opcode) /* NEGX */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}}
// PERFDATA_40b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_40b0) - NEGX

void REGPARAM2 CPU_OP_NAME(_40b8)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}
// PERFDATA_40b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_40b8) - NEGX

void REGPARAM2 CPU_OP_NAME(_40b9)(uae_u32 opcode) /* NEGX */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_u32 newv = 0 - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEGX.L M 12(1/2)+
}}}}}
// PERFDATA_40b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_40b9) - NEGX

void REGPARAM2 CPU_OP_NAME(_40c0)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	MakeSR();
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((regs.sr) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE SR, Rn 6(1/0)
}}}
// PERFDATA_40c0 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_40c0) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40d0)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}
// PERFDATA_40d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_40d0) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40d8)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += 2;
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}}
// PERFDATA_40d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_40d8) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40e0)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}}
// PERFDATA_40e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_40e0) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40e8)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}
// PERFDATA_40e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_40e8) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40f0)(uae_u32 opcode) /* MVSR2 */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}
// PERFDATA_40f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_40f0) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40f8)(uae_u32 opcode) /* MVSR2 */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}
// PERFDATA_40f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_40f8) - MVSR2

void REGPARAM2 CPU_OP_NAME(_40f9)(uae_u32 opcode) /* MVSR2 */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	MakeSR();
	put_word(srca,regs.sr);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE SR, M 8(1/1)+
}}}
// PERFDATA_40f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_40f9) - MVSR2

void REGPARAM2 CPU_OP_NAME(_4100)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4100 {0x06, 0x01, 0x00}	// 10(1/0)   CPU_OP_NAME(_4100) - CHK

void REGPARAM2 CPU_OP_NAME(_4110)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4110 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_4110) - CHK

void REGPARAM2 CPU_OP_NAME(_4118)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_4118 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_4118) - CHK

void REGPARAM2 CPU_OP_NAME(_4120)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_4120 {0x08, 0x03, 0x00}	// 20(3/0)   CPU_OP_NAME(_4120) - CHK

void REGPARAM2 CPU_OP_NAME(_4128)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4128 {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_4128) - CHK

void REGPARAM2 CPU_OP_NAME(_4130)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_4130 {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_4130) - CHK

void REGPARAM2 CPU_OP_NAME(_4138)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4138 {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_4138) - CHK

void REGPARAM2 CPU_OP_NAME(_4139)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4139 {0x06, 0x05, 0x00}	// 26(5/0)   CPU_OP_NAME(_4139) - CHK

void REGPARAM2 CPU_OP_NAME(_413a)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_413a {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_413a) - CHK

void REGPARAM2 CPU_OP_NAME(_413b)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_413b {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_413b) - CHK

void REGPARAM2 CPU_OP_NAME(_413c)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_413c {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_413c) - CHK

void REGPARAM2 CPU_OP_NAME(_4180)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4180 {0x06, 0x01, 0x00}	// 10(1/0)   CPU_OP_NAME(_4180) - CHK

void REGPARAM2 CPU_OP_NAME(_4190)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_4190 {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_4190) - CHK

void REGPARAM2 CPU_OP_NAME(_4198)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_4198 {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_4198) - CHK

void REGPARAM2 CPU_OP_NAME(_41a0)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_41a0 {0x08, 0x02, 0x00}	// 16(2/0)   CPU_OP_NAME(_41a0) - CHK

void REGPARAM2 CPU_OP_NAME(_41a8)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_41a8 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_41a8) - CHK

void REGPARAM2 CPU_OP_NAME(_41b0)(uae_u32 opcode) /* CHK */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_41b0 {0x08, 0x03, 0x00}	// 20(3/0)   CPU_OP_NAME(_41b0) - CHK

void REGPARAM2 CPU_OP_NAME(_41b8)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_41b8 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_41b8) - CHK

void REGPARAM2 CPU_OP_NAME(_41b9)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_41b9 {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_41b9) - CHK

void REGPARAM2 CPU_OP_NAME(_41ba)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_41ba {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_41ba) - CHK

void REGPARAM2 CPU_OP_NAME(_41bb)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}}
// PERFDATA_41bb {0x08, 0x03, 0x00}	// 20(3/0)   CPU_OP_NAME(_41bb) - CHK

void REGPARAM2 CPU_OP_NAME(_41bc)(uae_u32 opcode) /* CHK */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if ((uae_s32)dst < 0) { NFLG=1; Exception(6,oldpc-2); }
	else if (dst > src) { NFLG=0; Exception(6,oldpc-2); }
	// perf CHK 10(1/0)+ if no trap, 40(4/3)+ if trap
}}}}
// PERFDATA_41bc {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_41bc) - CHK

void REGPARAM2 CPU_OP_NAME(_41d0)(uae_u32 opcode) /* LEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA (An) 4(1/0)  {(d16,An), (xxx).W, (d16,PC)} 8(2/0)  (xxx).L 12(3/0)
}}}}
// PERFDATA_41d0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_41d0) - LEA

void REGPARAM2 CPU_OP_NAME(_41e8)(uae_u32 opcode) /* LEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA (An) 4(1/0)  {(d16,An), (xxx).W, (d16,PC)} 8(2/0)  (xxx).L 12(3/0)
}}}}
// PERFDATA_41e8 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_41e8) - LEA

void REGPARAM2 CPU_OP_NAME(_41f0)(uae_u32 opcode) /* LEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA {(d8,An,Xn)+,(d8,PC,Xn)} 12(2/0) 
}}}}
// PERFDATA_41f0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_41f0) - LEA

void REGPARAM2 CPU_OP_NAME(_41f8)(uae_u32 opcode) /* LEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA (An) 4(1/0)  {(d16,An), (xxx).W, (d16,PC)} 8(2/0)  (xxx).L 12(3/0)
}}}}
// PERFDATA_41f8 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_41f8) - LEA

void REGPARAM2 CPU_OP_NAME(_41f9)(uae_u32 opcode) /* LEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA (An) 4(1/0)  {(d16,An), (xxx).W, (d16,PC)} 8(2/0)  (xxx).L 12(3/0)
}}}}
// PERFDATA_41f9 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_41f9) - LEA

void REGPARAM2 CPU_OP_NAME(_41fa)(uae_u32 opcode) /* LEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA (An) 4(1/0)  {(d16,An), (xxx).W, (d16,PC)} 8(2/0)  (xxx).L 12(3/0)
}}}}
// PERFDATA_41fa {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_41fa) - LEA

void REGPARAM2 CPU_OP_NAME(_41fb)(uae_u32 opcode) /* LEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	m68k_areg(regs, dstreg) = (srca);
	// perf write: An 0(0/0)
	// perf LEA {(d8,An,Xn)+,(d8,PC,Xn)} 12(2/0) 
}}}}
// PERFDATA_41fb {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_41fb) - LEA

void REGPARAM2 CPU_OP_NAME(_4200)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((0) & 0xff);
	// perf write: Dn 0(0/0)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4200 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4200) - CLR

void REGPARAM2 CPU_OP_NAME(_4210)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4210 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4210) - CLR

void REGPARAM2 CPU_OP_NAME(_4218)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4218 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4218) - CLR

void REGPARAM2 CPU_OP_NAME(_4220)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4220 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4220) - CLR

void REGPARAM2 CPU_OP_NAME(_4228)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4228 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4228) - CLR

void REGPARAM2 CPU_OP_NAME(_4230)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4230 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4230) - CLR

void REGPARAM2 CPU_OP_NAME(_4238)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4238 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4238) - CLR

void REGPARAM2 CPU_OP_NAME(_4239)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(0)) == 0;
	NFLG = ((uae_s8)(0)) < 0;
	put_byte(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4239 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4239) - CLR

void REGPARAM2 CPU_OP_NAME(_4240)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((0) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4240 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4240) - CLR

void REGPARAM2 CPU_OP_NAME(_4250)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4250 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4250) - CLR

void REGPARAM2 CPU_OP_NAME(_4258)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4258 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4258) - CLR

void REGPARAM2 CPU_OP_NAME(_4260)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4260 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_4260) - CLR

void REGPARAM2 CPU_OP_NAME(_4268)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4268 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4268) - CLR

void REGPARAM2 CPU_OP_NAME(_4270)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4270 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4270) - CLR

void REGPARAM2 CPU_OP_NAME(_4278)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4278 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4278) - CLR

void REGPARAM2 CPU_OP_NAME(_4279)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(0)) == 0;
	NFLG = ((uae_s16)(0)) < 0;
	put_word(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf CLR.B/W Rn 4(1/0)  M 8(1/1)+
}}}
// PERFDATA_4279 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4279) - CLR

void REGPARAM2 CPU_OP_NAME(_4280)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	m68k_dreg(regs, srcreg) = (0);
	// perf write: Dn 0(0/0)
	// perf CLR.L Rn 6(1/0)
}}}
// PERFDATA_4280 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_4280) - CLR

void REGPARAM2 CPU_OP_NAME(_4290)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}
// PERFDATA_4290 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_4290) - CLR

void REGPARAM2 CPU_OP_NAME(_4298)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}}
// PERFDATA_4298 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_4298) - CLR

void REGPARAM2 CPU_OP_NAME(_42a0)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}}
// PERFDATA_42a0 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_42a0) - CLR

void REGPARAM2 CPU_OP_NAME(_42a8)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}
// PERFDATA_42a8 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_42a8) - CLR

void REGPARAM2 CPU_OP_NAME(_42b0)(uae_u32 opcode) /* CLR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}
// PERFDATA_42b0 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_42b0) - CLR

void REGPARAM2 CPU_OP_NAME(_42b8)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}
// PERFDATA_42b8 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_42b8) - CLR

void REGPARAM2 CPU_OP_NAME(_42b9)(uae_u32 opcode) /* CLR */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(0)) == 0;
	NFLG = ((uae_s32)(0)) < 0;
	put_long(srca,0);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf CLR.L M 12(1/2)+
}}}
// PERFDATA_42b9 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_42b9) - CLR

void REGPARAM2 CPU_OP_NAME(_4400)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((dst) & 0xff);
	// perf write: Dn 0(0/0)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4400 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4400) - NEG

void REGPARAM2 CPU_OP_NAME(_4410)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4410 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4410) - NEG

void REGPARAM2 CPU_OP_NAME(_4418)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4418 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4418) - NEG

void REGPARAM2 CPU_OP_NAME(_4420)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4420 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4420) - NEG

void REGPARAM2 CPU_OP_NAME(_4428)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4428 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4428) - NEG

void REGPARAM2 CPU_OP_NAME(_4430)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4430 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4430) - NEG

void REGPARAM2 CPU_OP_NAME(_4438)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4438 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4438) - NEG

void REGPARAM2 CPU_OP_NAME(_4439)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 dst = ((uae_s8)(0)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(0)) < 0;
	int flgn = ((uae_s8)(dst)) < 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(0));
	NFLG = flgn != 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4439 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4439) - NEG

void REGPARAM2 CPU_OP_NAME(_4440)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((dst) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4440 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4440) - NEG

void REGPARAM2 CPU_OP_NAME(_4450)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4450 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4450) - NEG

void REGPARAM2 CPU_OP_NAME(_4458)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4458 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4458) - NEG

void REGPARAM2 CPU_OP_NAME(_4460)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4460 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4460) - NEG

void REGPARAM2 CPU_OP_NAME(_4468)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4468 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4468) - NEG

void REGPARAM2 CPU_OP_NAME(_4470)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}}
// PERFDATA_4470 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4470) - NEG

void REGPARAM2 CPU_OP_NAME(_4478)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4478 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4478) - NEG

void REGPARAM2 CPU_OP_NAME(_4479)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 dst = ((uae_s16)(0)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(0)) < 0;
	int flgn = ((uae_s16)(dst)) < 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(0));
	NFLG = flgn != 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NEG.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}}
// PERFDATA_4479 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4479) - NEG

void REGPARAM2 CPU_OP_NAME(_4480)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf NEG.L Rn 6(1/0)
}}}}}}
// PERFDATA_4480 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_4480) - NEG

void REGPARAM2 CPU_OP_NAME(_4490)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}
// PERFDATA_4490 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4490) - NEG

void REGPARAM2 CPU_OP_NAME(_4498)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}}
// PERFDATA_4498 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4498) - NEG

void REGPARAM2 CPU_OP_NAME(_44a0)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}}
// PERFDATA_44a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_44a0) - NEG

void REGPARAM2 CPU_OP_NAME(_44a8)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}
// PERFDATA_44a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_44a8) - NEG

void REGPARAM2 CPU_OP_NAME(_44b0)(uae_u32 opcode) /* NEG */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}}
// PERFDATA_44b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_44b0) - NEG

void REGPARAM2 CPU_OP_NAME(_44b8)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}
// PERFDATA_44b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_44b8) - NEG

void REGPARAM2 CPU_OP_NAME(_44b9)(uae_u32 opcode) /* NEG */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 dst = ((uae_s32)(0)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(0)) < 0;
	int flgn = ((uae_s32)(dst)) < 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(0));
	NFLG = flgn != 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NEG.B/W M 12(1/2)+
}}}}}}
// PERFDATA_44b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_44b9) - NEG

void REGPARAM2 CPU_OP_NAME(_44c0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44c0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_44c0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44d0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44d0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_44d0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44d8)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_44d8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_44d8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44e0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_44e0 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_44e0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44e8)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44e8 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_44e8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44f0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_44f0 {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_44f0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44f8)(uae_u32 opcode) /* MV2SR */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44f8 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_44f8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44f9)(uae_u32 opcode) /* MV2SR */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44f9 {0x04, 0x05, 0x00}	// 24(5/0)   CPU_OP_NAME(_44f9) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44fa)(uae_u32 opcode) /* MV2SR */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_44fa {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_44fa) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44fb)(uae_u32 opcode) /* MV2SR */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_44fb {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_44fb) - MV2SR

void REGPARAM2 CPU_OP_NAME(_44fc)(uae_u32 opcode) /* MV2SR */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
	MakeSR();
	regs.sr &= 0xFF00;
	regs.sr |= src & 0xFF;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}
// PERFDATA_44fc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_44fc) - MV2SR

void REGPARAM2 CPU_OP_NAME(_4600)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((dst) & 0xff);
	// perf write: Dn 0(0/0)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4600 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4600) - NOT

void REGPARAM2 CPU_OP_NAME(_4610)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4610 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4610) - NOT

void REGPARAM2 CPU_OP_NAME(_4618)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4618 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4618) - NOT

void REGPARAM2 CPU_OP_NAME(_4620)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4620 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4620) - NOT

void REGPARAM2 CPU_OP_NAME(_4628)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4628 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4628) - NOT

void REGPARAM2 CPU_OP_NAME(_4630)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4630 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4630) - NOT

void REGPARAM2 CPU_OP_NAME(_4638)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4638 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4638) - NOT

void REGPARAM2 CPU_OP_NAME(_4639)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(dst)) == 0;
	NFLG = ((uae_s8)(dst)) < 0;
	put_byte(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4639 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4639) - NOT

void REGPARAM2 CPU_OP_NAME(_4640)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((dst) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4640 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4640) - NOT

void REGPARAM2 CPU_OP_NAME(_4650)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4650 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4650) - NOT

void REGPARAM2 CPU_OP_NAME(_4658)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4658 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4658) - NOT

void REGPARAM2 CPU_OP_NAME(_4660)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4660 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4660) - NOT

void REGPARAM2 CPU_OP_NAME(_4668)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4668 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4668) - NOT

void REGPARAM2 CPU_OP_NAME(_4670)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}}
// PERFDATA_4670 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4670) - NOT

void REGPARAM2 CPU_OP_NAME(_4678)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4678 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4678) - NOT

void REGPARAM2 CPU_OP_NAME(_4679)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	put_word(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf NOT.B/W Rn 4(1/0)  M 8(1/1)+
}}}}
// PERFDATA_4679 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4679) - NOT

void REGPARAM2 CPU_OP_NAME(_4680)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf NOT.L Rn 6(1/0)
}}}}
// PERFDATA_4680 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_4680) - NOT

void REGPARAM2 CPU_OP_NAME(_4690)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}
// PERFDATA_4690 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4690) - NOT

void REGPARAM2 CPU_OP_NAME(_4698)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}}
// PERFDATA_4698 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4698) - NOT

void REGPARAM2 CPU_OP_NAME(_46a0)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}}
// PERFDATA_46a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_46a0) - NOT

void REGPARAM2 CPU_OP_NAME(_46a8)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}
// PERFDATA_46a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_46a8) - NOT

void REGPARAM2 CPU_OP_NAME(_46b0)(uae_u32 opcode) /* NOT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}}
// PERFDATA_46b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_46b0) - NOT

void REGPARAM2 CPU_OP_NAME(_46b8)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}
// PERFDATA_46b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_46b8) - NOT

void REGPARAM2 CPU_OP_NAME(_46b9)(uae_u32 opcode) /* NOT */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_u32 dst = ~src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	put_long(srca,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf NOT.L M 12(1/2)+
}}}}
// PERFDATA_46b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_46b9) - NOT

void REGPARAM2 CPU_OP_NAME(_46c0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46c0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_46c0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46d0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46d0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_46d0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46d8)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}}
// PERFDATA_46d8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_46d8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46e0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}}
// PERFDATA_46e0 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_46e0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46e8)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46e8 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_46e8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46f0)(uae_u32 opcode) /* MV2SR */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}}
// PERFDATA_46f0 {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_46f0) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46f8)(uae_u32 opcode) /* MV2SR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46f8 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_46f8) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46f9)(uae_u32 opcode) /* MV2SR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46f9 {0x04, 0x05, 0x00}	// 24(5/0)   CPU_OP_NAME(_46f9) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46fa)(uae_u32 opcode) /* MV2SR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}}
// PERFDATA_46fa {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_46fa) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46fb)(uae_u32 opcode) /* MV2SR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}}
// PERFDATA_46fb {0x06, 0x04, 0x00}	// 22(4/0)   CPU_OP_NAME(_46fb) - MV2SR

void REGPARAM2 CPU_OP_NAME(_46fc)(uae_u32 opcode) /* MV2SR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
	regs.sr = src;
	MakeFromSR();
	// perf MOVE <ea>, SR 12(2/0)+
}}}}
// PERFDATA_46fc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_46fc) - MV2SR

void REGPARAM2 CPU_OP_NAME(_4800)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf NBCD.B Rn 6(1/0)
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}
// PERFDATA_4800 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_4800) - NBCD

void REGPARAM2 CPU_OP_NAME(_4810)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}
// PERFDATA_4810 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4810) - NBCD

void REGPARAM2 CPU_OP_NAME(_4818)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}}
// PERFDATA_4818 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_4818) - NBCD

void REGPARAM2 CPU_OP_NAME(_4820)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}}
// PERFDATA_4820 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4820) - NBCD

void REGPARAM2 CPU_OP_NAME(_4828)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}
// PERFDATA_4828 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4828) - NBCD

void REGPARAM2 CPU_OP_NAME(_4830)(uae_u32 opcode) /* NBCD */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}}
// PERFDATA_4830 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4830) - NBCD

void REGPARAM2 CPU_OP_NAME(_4838)(uae_u32 opcode) /* NBCD */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}
// PERFDATA_4838 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_4838) - NBCD

void REGPARAM2 CPU_OP_NAME(_4839)(uae_u32 opcode) /* NBCD */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_u16 newv_lo = - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	put_byte(srca,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf NBCD.B <M> 8(1/1)+
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
}}}}
// PERFDATA_4839 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_4839) - NBCD

void REGPARAM2 CPU_OP_NAME(_4840)(uae_u32 opcode) /* SWAP */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = ((src >> 16)&0xFFFF) | ((src&0xFFFF)<<16);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf SWAP 4(1/0)
}}}}
// PERFDATA_4840 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4840) - SWAP

void REGPARAM2 CPU_OP_NAME(_4850)(uae_u32 opcode) /* PEA */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA (An) 12(1/2)  {(d16,An), (xxx).W, (d16,PC)} 16(2/2)  (xxx).L 20(3/2)
}}}}}
// PERFDATA_4850 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_4850) - PEA

void REGPARAM2 CPU_OP_NAME(_4868)(uae_u32 opcode) /* PEA */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA (An) 12(1/2)  {(d16,An), (xxx).W, (d16,PC)} 16(2/2)  (xxx).L 20(3/2)
}}}}}
// PERFDATA_4868 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_4868) - PEA

void REGPARAM2 CPU_OP_NAME(_4870)(uae_u32 opcode) /* PEA */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA(d8,An,Xn)+, (d8,PC,Xn) 20(2/2)
}}}}}
// PERFDATA_4870 {0x03, 0x02, 0x02}	// 19(2/2)   CPU_OP_NAME(_4870) - PEA

void REGPARAM2 CPU_OP_NAME(_4878)(uae_u32 opcode) /* PEA */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA (An) 12(1/2)  {(d16,An), (xxx).W, (d16,PC)} 16(2/2)  (xxx).L 20(3/2)
}}}}}
// PERFDATA_4878 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_4878) - PEA

void REGPARAM2 CPU_OP_NAME(_4879)(uae_u32 opcode) /* PEA */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA (An) 12(1/2)  {(d16,An), (xxx).W, (d16,PC)} 16(2/2)  (xxx).L 20(3/2)
}}}}}
// PERFDATA_4879 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4879) - PEA

void REGPARAM2 CPU_OP_NAME(_487a)(uae_u32 opcode) /* PEA */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA (An) 12(1/2)  {(d16,An), (xxx).W, (d16,PC)} 16(2/2)  (xxx).L 20(3/2)
}}}}}
// PERFDATA_487a {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_487a) - PEA

void REGPARAM2 CPU_OP_NAME(_487b)(uae_u32 opcode) /* PEA */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	m68k_areg(regs, 7) -= 4;
{	uaecptr dsta = m68k_areg(regs, 7);
	put_long(dsta,srca);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf PEA(d8,An,Xn)+, (d8,PC,Xn) 20(2/2)
}}}}}
// PERFDATA_487b {0x03, 0x02, 0x02}	// 19(2/2)   CPU_OP_NAME(_487b) - PEA

void REGPARAM2 CPU_OP_NAME(_4880)(uae_u32 opcode) /* EXT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u16 dst = (uae_s16)(uae_s8)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(dst)) == 0;
	NFLG = ((uae_s16)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((dst) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf EXT 4(1/0)
}}}}
// PERFDATA_4880 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4880) - EXT

void REGPARAM2 CPU_OP_NAME(_4890)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = m68k_areg(regs, dstreg);
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_word(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { put_word(srca, m68k_areg(regs, movem_index1[amask])); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_4890 {0x00, 0x02, 0xff}	// 1028(2/255)   CPU_OP_NAME(_4890) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48a0)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{{	uaecptr srca = m68k_areg(regs, dstreg);
{	uae_u16 amask = mask & 0xff, dmask = (mask >> 8) & 0xff;
	while (amask) { srca -= 2; put_word(srca, m68k_areg(regs, movem_index2[amask])); amask = movem_next[amask]; }
	while (dmask) { srca -= 2; put_word(srca, m68k_dreg(regs, movem_index2[dmask])); dmask = movem_next[dmask]; }
	m68k_areg(regs, dstreg) = srca;
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}}
// PERFDATA_48a0 {0x00, 0x02, 0xff}	// 1028(2/255)   CPU_OP_NAME(_48a0) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48a8)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_word(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { put_word(srca, m68k_areg(regs, movem_index1[amask])); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48a8 {0x00, 0x03, 0xff}	// 1032(3/255)   CPU_OP_NAME(_48a8) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48b0)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_word(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { put_word(srca, m68k_areg(regs, movem_index1[amask])); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48b0 {0x02, 0x03, 0xff}	// 1034(3/255)   CPU_OP_NAME(_48b0) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48b8)(uae_u32 opcode) /* MVMLE */
{
{	uae_u16 mask = nextiword();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_word(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { put_word(srca, m68k_areg(regs, movem_index1[amask])); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48b8 {0x00, 0x03, 0xff}	// 1032(3/255)   CPU_OP_NAME(_48b8) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48b9)(uae_u32 opcode) /* MVMLE */
{
{	uae_u16 mask = nextiword();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_word(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { put_word(srca, m68k_areg(regs, movem_index1[amask])); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48b9 {0x00, 0x04, 0xff}	// 1036(4/255)   CPU_OP_NAME(_48b9) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48c0)(uae_u32 opcode) /* EXT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf EXT 4(1/0)
}}}}
// PERFDATA_48c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_48c0) - EXT

void REGPARAM2 CPU_OP_NAME(_48d0)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = m68k_areg(regs, dstreg);
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_long(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { put_long(srca, m68k_areg(regs, movem_index1[amask])); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48d0 {0x00, 0x02, 0xff}	// 1028(2/255)   CPU_OP_NAME(_48d0) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48e0)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{{	uaecptr srca = m68k_areg(regs, dstreg);
{	uae_u16 amask = mask & 0xff, dmask = (mask >> 8) & 0xff;
	while (amask) { srca -= 4; put_long(srca, m68k_areg(regs, movem_index2[amask])); amask = movem_next[amask]; }
	while (dmask) { srca -= 4; put_long(srca, m68k_dreg(regs, movem_index2[dmask])); dmask = movem_next[dmask]; }
	m68k_areg(regs, dstreg) = srca;
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}}
// PERFDATA_48e0 {0x00, 0x02, 0xff}	// 1028(2/255)   CPU_OP_NAME(_48e0) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48e8)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_long(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { put_long(srca, m68k_areg(regs, movem_index1[amask])); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48e8 {0x00, 0x03, 0xff}	// 1032(3/255)   CPU_OP_NAME(_48e8) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48f0)(uae_u32 opcode) /* MVMLE */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_long(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { put_long(srca, m68k_areg(regs, movem_index1[amask])); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48f0 {0x02, 0x03, 0xff}	// 1034(3/255)   CPU_OP_NAME(_48f0) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48f8)(uae_u32 opcode) /* MVMLE */
{
{	uae_u16 mask = nextiword();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_long(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { put_long(srca, m68k_areg(regs, movem_index1[amask])); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48f8 {0x00, 0x03, 0xff}	// 1032(3/255)   CPU_OP_NAME(_48f8) - MVMLE

void REGPARAM2 CPU_OP_NAME(_48f9)(uae_u32 opcode) /* MVMLE */
{
{	uae_u16 mask = nextiword();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	uae_u16 dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
	while (dmask) { put_long(srca, m68k_dreg(regs, movem_index1[dmask])); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { put_long(srca, m68k_areg(regs, movem_index1[amask])); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM R, M 8+4n(2/n) + eff addr
}}}}
// PERFDATA_48f9 {0x00, 0x04, 0xff}	// 1036(4/255)   CPU_OP_NAME(_48f9) - MVMLE

void REGPARAM2 CPU_OP_NAME(_49c0)(uae_u32 opcode) /* EXT */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 dst = (uae_s32)(uae_s8)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(dst)) == 0;
	NFLG = ((uae_s32)(dst)) < 0;
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf EXT 4(1/0)
}}}}
// PERFDATA_49c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_49c0) - EXT

void REGPARAM2 CPU_OP_NAME(_4a00)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a00 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4a00) - TST

void REGPARAM2 CPU_OP_NAME(_4a10)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a10 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a10) - TST

void REGPARAM2 CPU_OP_NAME(_4a18)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a18 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a18) - TST

void REGPARAM2 CPU_OP_NAME(_4a20)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a20 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_4a20) - TST

void REGPARAM2 CPU_OP_NAME(_4a28)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a28 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a28) - TST

void REGPARAM2 CPU_OP_NAME(_4a30)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a30 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4a30) - TST

void REGPARAM2 CPU_OP_NAME(_4a38)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a38 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a38) - TST

void REGPARAM2 CPU_OP_NAME(_4a39)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a39 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4a39) - TST

void REGPARAM2 CPU_OP_NAME(_4a3a)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a3a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a3a) - TST

void REGPARAM2 CPU_OP_NAME(_4a3b)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a3b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4a3b) - TST

void REGPARAM2 CPU_OP_NAME(_4a3c)(uae_u32 opcode) /* TST */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a3c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a3c) - TST

void REGPARAM2 CPU_OP_NAME(_4a40)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a40 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4a40) - TST

void REGPARAM2 CPU_OP_NAME(_4a48)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a48 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4a48) - TST

void REGPARAM2 CPU_OP_NAME(_4a50)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a50 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a50) - TST

void REGPARAM2 CPU_OP_NAME(_4a58)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a58 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a58) - TST

void REGPARAM2 CPU_OP_NAME(_4a60)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a60 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_4a60) - TST

void REGPARAM2 CPU_OP_NAME(_4a68)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a68 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a68) - TST

void REGPARAM2 CPU_OP_NAME(_4a70)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a70 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4a70) - TST

void REGPARAM2 CPU_OP_NAME(_4a78)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a78 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a78) - TST

void REGPARAM2 CPU_OP_NAME(_4a79)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a79 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4a79) - TST

void REGPARAM2 CPU_OP_NAME(_4a7a)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a7a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a7a) - TST

void REGPARAM2 CPU_OP_NAME(_4a7b)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a7b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4a7b) - TST

void REGPARAM2 CPU_OP_NAME(_4a7c)(uae_u32 opcode) /* TST */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a7c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4a7c) - TST

void REGPARAM2 CPU_OP_NAME(_4a80)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a80 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4a80) - TST

void REGPARAM2 CPU_OP_NAME(_4a88)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a88 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4a88) - TST

void REGPARAM2 CPU_OP_NAME(_4a90)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4a90 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a90) - TST

void REGPARAM2 CPU_OP_NAME(_4a98)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4a98 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4a98) - TST

void REGPARAM2 CPU_OP_NAME(_4aa0)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4aa0 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4aa0) - TST

void REGPARAM2 CPU_OP_NAME(_4aa8)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4aa8 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4aa8) - TST

void REGPARAM2 CPU_OP_NAME(_4ab0)(uae_u32 opcode) /* TST */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4ab0 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_4ab0) - TST

void REGPARAM2 CPU_OP_NAME(_4ab8)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4ab8 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4ab8) - TST

void REGPARAM2 CPU_OP_NAME(_4ab9)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4ab9 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_4ab9) - TST

void REGPARAM2 CPU_OP_NAME(_4aba)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4aba {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4aba) - TST

void REGPARAM2 CPU_OP_NAME(_4abb)(uae_u32 opcode) /* TST */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}}
// PERFDATA_4abb {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_4abb) - TST

void REGPARAM2 CPU_OP_NAME(_4abc)(uae_u32 opcode) /* TST */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	// perf TST Rn 4(1/0)  M 4(1/0)+
}}}
// PERFDATA_4abc {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4abc) - TST

void REGPARAM2 CPU_OP_NAME(_4ac0)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf TAS R 4(1/0)
}}}
// PERFDATA_4ac0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4ac0) - TAS

void REGPARAM2 CPU_OP_NAME(_4ad0)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}
// PERFDATA_4ad0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4ad0) - TAS

void REGPARAM2 CPU_OP_NAME(_4ad8)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}}
// PERFDATA_4ad8 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_4ad8) - TAS

void REGPARAM2 CPU_OP_NAME(_4ae0)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}}
// PERFDATA_4ae0 {0x04, 0x02, 0x01}	// 16(2/1)   CPU_OP_NAME(_4ae0) - TAS

void REGPARAM2 CPU_OP_NAME(_4ae8)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}
// PERFDATA_4ae8 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4ae8) - TAS

void REGPARAM2 CPU_OP_NAME(_4af0)(uae_u32 opcode) /* TAS */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}}
// PERFDATA_4af0 {0x04, 0x03, 0x01}	// 20(3/1)   CPU_OP_NAME(_4af0) - TAS

void REGPARAM2 CPU_OP_NAME(_4af8)(uae_u32 opcode) /* TAS */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}
// PERFDATA_4af8 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_4af8) - TAS

void REGPARAM2 CPU_OP_NAME(_4af9)(uae_u32 opcode) /* TAS */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	src |= 0x80;
	put_byte(srca,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf TAS M 14(2/1)+
}}}
// PERFDATA_4af9 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_4af9) - TAS

void REGPARAM2 CPU_OP_NAME(_4c90)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg);
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4c90 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4c90) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4c98)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg);
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	m68k_areg(regs, dstreg) = srca;
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4c98 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4c98) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4ca8)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4ca8 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4ca8) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cb0)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cb0 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_4cb0) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cb8)(uae_u32 opcode) /* MVMEL */
{
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cb8 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cb8) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cb9)(uae_u32 opcode) /* MVMEL */
{
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cb9 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cb9) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cba)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = 2;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cba {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cba) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cbb)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = 3;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = (uae_s32)(uae_s16)get_word(srca); srca += 2; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cbb {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_4cbb) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cd0)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg);
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cd0 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cd0) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cd8)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg);
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	m68k_areg(regs, dstreg) = srca;
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cd8 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cd8) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4ce8)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4ce8 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4ce8) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cf0)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = opcode & 7;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cf0 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_4cf0) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cf8)(uae_u32 opcode) /* MVMEL */
{
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cf8 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cf8) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cf9)(uae_u32 opcode) /* MVMEL */
{
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cf9 {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cf9) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cfa)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = 2;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cfa {0x00, 0xff, 0x00}	// 1020(255/0)   CPU_OP_NAME(_4cfa) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4cfb)(uae_u32 opcode) /* MVMEL */
{
	uae_u32 dstreg = 3;
{	uae_u16 mask = nextiword(), dmask = mask & 0xff, amask = (mask >> 8) & 0xff;
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	while (dmask) { m68k_dreg(regs, movem_index1[dmask]) = get_long(srca); srca += 4; dmask = movem_next[dmask]; }
	while (amask) { m68k_areg(regs, movem_index1[amask]) = get_long(srca); srca += 4; amask = movem_next[amask]; }
	// perf MOVEM M, R 12+4n(3+n/0) + eff addr
}}}}
// PERFDATA_4cfb {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_4cfb) - MVMEL

void REGPARAM2 CPU_OP_NAME(_4e40)(uae_u32 opcode) /* TRAP */
{
	uae_u32 srcreg = (opcode & 15);
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	Exception(src+32,0);
	// perf TRAP 34(4/3)
}}}
// PERFDATA_4e40 {0x06, 0xff, 0xff}	// 2046(255/255)   CPU_OP_NAME(_4e40) - TRAP

void REGPARAM2 CPU_OP_NAME(_4e50)(uae_u32 opcode) /* LINK */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, 7) -= 4;
{	uaecptr olda = m68k_areg(regs, 7);
{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
	put_long(olda,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	m68k_areg(regs, srcreg) = (m68k_areg(regs, 7));
	// perf write: An 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	m68k_areg(regs, 7) += offs;
	// perf LINK 16(2/2)
}}}}}}
// PERFDATA_4e50 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_4e50) - LINK

void REGPARAM2 CPU_OP_NAME(_4e58)(uae_u32 opcode) /* UNLK */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
	m68k_areg(regs, 7) = src;
{	uaecptr olda = m68k_areg(regs, 7);
	uae_s32 old = get_long(olda);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, 7) += 4;
	m68k_areg(regs, srcreg) = (old);
	// perf write: An 0(0/0)
	// perf UNLK 12(3/0)
}}}}}
// PERFDATA_4e58 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4e58) - UNLK

void REGPARAM2 CPU_OP_NAME(_4e60)(uae_u32 opcode) /* MVR2USP */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
	regs.usp = src;
	// perf MOVE to USP 4(1/0)
}}}}
// PERFDATA_4e60 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4e60) - MVR2USP

void REGPARAM2 CPU_OP_NAME(_4e68)(uae_u32 opcode) /* MVUSP2R */
{
	uae_u32 srcreg = (opcode & 7);
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	m68k_areg(regs, srcreg) = (regs.usp);
	// perf write: An 0(0/0)
	// perf MOVE from USP 4(1/0)
}}}}
// PERFDATA_4e68 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4e68) - MVUSP2R

void REGPARAM2 CPU_OP_NAME(_4e70)(uae_u32 opcode) /* RESET */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{	customreset();
	// perf RESET 132(1/0)
}}}
// PERFDATA_4e70 {0x80, 0x01, 0x00}	// 132(1/0)   CPU_OP_NAME(_4e70) - RESET

void REGPARAM2 CPU_OP_NAME(_4e71)(uae_u32 opcode) /* NOP */
{
{	// perf NOP 4(1/0)
}}
// PERFDATA_4e71 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_4e71) - NOP

void REGPARAM2 CPU_OP_NAME(_4e72)(uae_u32 opcode) /* STOP */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	regs.sr = src;
	MakeFromSR();
	m68k_setstopped(1);
	// perf STOP 4(0/0)
}}}}
// PERFDATA_4e72 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_4e72) - STOP

void REGPARAM2 CPU_OP_NAME(_4e73)(uae_u32 opcode) /* RTE */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{{	uaecptr sra = m68k_areg(regs, 7);
	uae_s16 sr = get_word(sra);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, 7) += 2;
{	uaecptr pca = m68k_areg(regs, 7);
	uae_s32 pc = get_long(pca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, 7) += 4;
	regs.sr = sr; m68k_do_rte(pc);
	MakeFromSR();
	// perf RTE 20(5/0)
}}}}}}}
// PERFDATA_4e73 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_4e73) - RTE

void REGPARAM2 CPU_OP_NAME(_4e74)(uae_u32 opcode) /* RTD */
{
{	compiler_flush_jsr_stack();
{	uaecptr pca = m68k_areg(regs, 7);
	uae_s32 pc = get_long(pca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, 7) += 4;
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	m68k_areg(regs, 7) += offs;
	m68k_setpc_rte(pc);
	// perf RTD ?(?/?)
}}}}}
// PERFDATA_4e74 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4e74) - RTD

void REGPARAM2 CPU_OP_NAME(_4e75)(uae_u32 opcode) /* RTS */
{
{	m68k_do_rts();
	// perf RTS 16(4/0)
}}
// PERFDATA_4e75 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_4e75) - RTS

void REGPARAM2 CPU_OP_NAME(_4e76)(uae_u32 opcode) /* TRAPV */
{
{	if(VFLG) Exception(7,m68k_getpc()-2);
	// perf TRAPV 4(1/0) OR 34(5/3)
}}
// PERFDATA_4e76 {0x00, 0xff, 0xff}	// 2040(255/255)   CPU_OP_NAME(_4e76) - TRAPV

void REGPARAM2 CPU_OP_NAME(_4e77)(uae_u32 opcode) /* RTR */
{
{	compiler_flush_jsr_stack();
	MakeSR();
{	uaecptr sra = m68k_areg(regs, 7);
	uae_s16 sr = get_word(sra);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, 7) += 2;
{	uaecptr pca = m68k_areg(regs, 7);
	uae_s32 pc = get_long(pca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, 7) += 4;
	regs.sr &= 0xFF00; sr &= 0xFF;
	regs.sr |= sr; m68k_setpc(pc);
	MakeFromSR();
	// perf RTR 20(2/0)
}}}}}}
// PERFDATA_4e77 {0x0c, 0x02, 0x00}	// 20(2/0)   CPU_OP_NAME(_4e77) - RTR

void REGPARAM2 CPU_OP_NAME(_4e90)(uae_u32 opcode) /* JSR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	m68k_do_jsr(srca);
	// perf JSR (An)  16(2/2)
}}}
// PERFDATA_4e90 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_4e90) - JSR

void REGPARAM2 CPU_OP_NAME(_4ea8)(uae_u32 opcode) /* JSR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	m68k_do_jsr(srca);
	// perf JSR {(d16, An), (xxx).W, (d16 PC)}  18(2/2)
}}}
// PERFDATA_4ea8 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_4ea8) - JSR

void REGPARAM2 CPU_OP_NAME(_4eb0)(uae_u32 opcode) /* JSR */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	m68k_do_jsr(srca);
	// perf JSR {(d8,An,Xn)+, (d8,PC,Xn)}  22(2/2)
}}}
// PERFDATA_4eb0 {0x06, 0x02, 0x02}	// 22(2/2)   CPU_OP_NAME(_4eb0) - JSR

void REGPARAM2 CPU_OP_NAME(_4eb8)(uae_u32 opcode) /* JSR */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	m68k_do_jsr(srca);
	// perf JSR {(d16, An), (xxx).W, (d16 PC)}  18(2/2)
}}}
// PERFDATA_4eb8 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_4eb8) - JSR

void REGPARAM2 CPU_OP_NAME(_4eb9)(uae_u32 opcode) /* JSR */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	m68k_do_jsr(srca);
	// perf JSR (xxx).L  20(3/2)
}}}
// PERFDATA_4eb9 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_4eb9) - JSR

void REGPARAM2 CPU_OP_NAME(_4eba)(uae_u32 opcode) /* JSR */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
	m68k_do_jsr(srca);
	// perf JSR {(d16, An), (xxx).W, (d16 PC)}  18(2/2)
}}}
// PERFDATA_4eba {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_4eba) - JSR

void REGPARAM2 CPU_OP_NAME(_4ebb)(uae_u32 opcode) /* JSR */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
	m68k_do_jsr(srca);
	// perf JSR {(d8,An,Xn)+, (d8,PC,Xn)}  22(2/2)
}}}
// PERFDATA_4ebb {0x06, 0x02, 0x02}	// 22(2/2)   CPU_OP_NAME(_4ebb) - JSR

void REGPARAM2 CPU_OP_NAME(_4ed0)(uae_u32 opcode) /* JMP */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	m68k_setpc(srca);
	// perf JMP (An) 8(2/0)  (d8,An,Xn) 14(3/0), (d8,PC,Xn) 14(3/0)
}}}
// PERFDATA_4ed0 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_4ed0) - JMP

void REGPARAM2 CPU_OP_NAME(_4ee8)(uae_u32 opcode) /* JMP */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	m68k_setpc(srca);
	// perf JMP {(d16, An), (xxx).W, (d16 PC)}  10(2/0)
}}}
// PERFDATA_4ee8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_4ee8) - JMP

void REGPARAM2 CPU_OP_NAME(_4ef0)(uae_u32 opcode) /* JMP */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	m68k_setpc(srca);
	// perf JMP (An) 8(2/0)  (d8,An,Xn) 14(3/0), (d8,PC,Xn) 14(3/0)
}}}
// PERFDATA_4ef0 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4ef0) - JMP

void REGPARAM2 CPU_OP_NAME(_4ef8)(uae_u32 opcode) /* JMP */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	m68k_setpc(srca);
	// perf JMP {(d16, An), (xxx).W, (d16 PC)}  10(2/0)
}}}
// PERFDATA_4ef8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_4ef8) - JMP

void REGPARAM2 CPU_OP_NAME(_4ef9)(uae_u32 opcode) /* JMP */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	m68k_setpc(srca);
	// perf JMP (xxx).L 12(3/0)
}}}
// PERFDATA_4ef9 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_4ef9) - JMP

void REGPARAM2 CPU_OP_NAME(_4efa)(uae_u32 opcode) /* JMP */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
	m68k_setpc(srca);
	// perf JMP {(d16, An), (xxx).W, (d16 PC)}  10(2/0)
}}}
// PERFDATA_4efa {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_4efa) - JMP

void REGPARAM2 CPU_OP_NAME(_4efb)(uae_u32 opcode) /* JMP */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
	m68k_setpc(srca);
	// perf JMP (An) 8(2/0)  (d8,An,Xn) 14(3/0), (d8,PC,Xn) 14(3/0)
}}}
// PERFDATA_4efb {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_4efb) - JMP

#endif
