#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_c000)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_c000) - AND

void REGPARAM2 CPU_OP_NAME(_c010)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c010) - AND

void REGPARAM2 CPU_OP_NAME(_c018)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c018) - AND

void REGPARAM2 CPU_OP_NAME(_c020)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_c020) - AND

void REGPARAM2 CPU_OP_NAME(_c028)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c028) - AND

void REGPARAM2 CPU_OP_NAME(_c030)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c030) - AND

void REGPARAM2 CPU_OP_NAME(_c038)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c038) - AND

void REGPARAM2 CPU_OP_NAME(_c039)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c039) - AND

void REGPARAM2 CPU_OP_NAME(_c03a)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c03a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c03a) - AND

void REGPARAM2 CPU_OP_NAME(_c03b)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c03b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c03b) - AND

void REGPARAM2 CPU_OP_NAME(_c03c)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c03c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c03c) - AND

void REGPARAM2 CPU_OP_NAME(_c040)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_c040) - AND

void REGPARAM2 CPU_OP_NAME(_c050)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c050) - AND

void REGPARAM2 CPU_OP_NAME(_c058)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c058) - AND

void REGPARAM2 CPU_OP_NAME(_c060)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_c060) - AND

void REGPARAM2 CPU_OP_NAME(_c068)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c068) - AND

void REGPARAM2 CPU_OP_NAME(_c070)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c070) - AND

void REGPARAM2 CPU_OP_NAME(_c078)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c078) - AND

void REGPARAM2 CPU_OP_NAME(_c079)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c079) - AND

void REGPARAM2 CPU_OP_NAME(_c07a)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c07a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c07a) - AND

void REGPARAM2 CPU_OP_NAME(_c07b)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c07b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c07b) - AND

void REGPARAM2 CPU_OP_NAME(_c07c)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c07c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c07c) - AND

void REGPARAM2 CPU_OP_NAME(_c080)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c080 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_c080) - AND

void REGPARAM2 CPU_OP_NAME(_c090)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c090 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c090) - AND

void REGPARAM2 CPU_OP_NAME(_c098)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_c098 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c098) - AND

void REGPARAM2 CPU_OP_NAME(_c0a0)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_c0a0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_c0a0) - AND

void REGPARAM2 CPU_OP_NAME(_c0a8)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c0a8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c0a8) - AND

void REGPARAM2 CPU_OP_NAME(_c0b0)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_c0b0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_c0b0) - AND

void REGPARAM2 CPU_OP_NAME(_c0b8)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c0b8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c0b8) - AND

void REGPARAM2 CPU_OP_NAME(_c0b9)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c0b9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_c0b9) - AND

void REGPARAM2 CPU_OP_NAME(_c0ba)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_c0ba {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c0ba) - AND

void REGPARAM2 CPU_OP_NAME(_c0bb)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_c0bb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_c0bb) - AND

void REGPARAM2 CPU_OP_NAME(_c0bc)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_c0bc {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c0bc) - AND

void REGPARAM2 CPU_OP_NAME(_c0c0)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0c0 {0x42, 0x01, 0x00}	// 70(1/0)   CPU_OP_NAME(_c0c0) - MULU

void REGPARAM2 CPU_OP_NAME(_c0d0)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0d0 {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c0d0) - MULU

void REGPARAM2 CPU_OP_NAME(_c0d8)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}}
// PERFDATA_c0d8 {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c0d8) - MULU

void REGPARAM2 CPU_OP_NAME(_c0e0)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}}
// PERFDATA_c0e0 {0x44, 0x02, 0x00}	// 76(2/0)   CPU_OP_NAME(_c0e0) - MULU

void REGPARAM2 CPU_OP_NAME(_c0e8)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0e8 {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c0e8) - MULU

void REGPARAM2 CPU_OP_NAME(_c0f0)(uae_u32 opcode) /* MULU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}}
// PERFDATA_c0f0 {0x44, 0x03, 0x00}	// 80(3/0)   CPU_OP_NAME(_c0f0) - MULU

void REGPARAM2 CPU_OP_NAME(_c0f8)(uae_u32 opcode) /* MULU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0f8 {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c0f8) - MULU

void REGPARAM2 CPU_OP_NAME(_c0f9)(uae_u32 opcode) /* MULU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0f9 {0x42, 0x04, 0x00}	// 82(4/0)   CPU_OP_NAME(_c0f9) - MULU

void REGPARAM2 CPU_OP_NAME(_c0fa)(uae_u32 opcode) /* MULU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}}
// PERFDATA_c0fa {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c0fa) - MULU

void REGPARAM2 CPU_OP_NAME(_c0fb)(uae_u32 opcode) /* MULU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}}
// PERFDATA_c0fb {0x44, 0x03, 0x00}	// 80(3/0)   CPU_OP_NAME(_c0fb) - MULU

void REGPARAM2 CPU_OP_NAME(_c0fc)(uae_u32 opcode) /* MULU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_u32)(uae_u16)dst * (uae_u32)(uae_u16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULU 70(1/0)+*
}}}}}
// PERFDATA_c0fc {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c0fc) - MULU

void REGPARAM2 CPU_OP_NAME(_c100)(uae_u32 opcode) /* ABCD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u16 newv_lo = (src & 0xF) + (dst & 0xF) + (XFLG ? 1 : 0);
	uae_u16 newv_hi = (src & 0xF0) + (dst & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo +=6; }
	newv = newv_hi + newv_lo;	CFLG = XFLG = (newv & 0x1F0) > 0x90;
	if (CFLG) newv += 0x60;
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ABCD.B Dn, Dn 6(1/0)
}}}}}}
// PERFDATA_c100 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_c100) - ABCD

void REGPARAM2 CPU_OP_NAME(_c108)(uae_u32 opcode) /* ABCD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{	uae_u16 newv_lo = (src & 0xF) + (dst & 0xF) + (XFLG ? 1 : 0);
	uae_u16 newv_hi = (src & 0xF0) + (dst & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo +=6; }
	newv = newv_hi + newv_lo;	CFLG = XFLG = (newv & 0x1F0) > 0x90;
	if (CFLG) newv += 0x60;
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ABCD.B -(Ax), -(Ay) 18(3/1)
}}}}}}}}
// PERFDATA_c108 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_c108) - ABCD

void REGPARAM2 CPU_OP_NAME(_c110)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_c110) - AND

void REGPARAM2 CPU_OP_NAME(_c118)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_c118) - AND

void REGPARAM2 CPU_OP_NAME(_c120)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_c120) - AND

void REGPARAM2 CPU_OP_NAME(_c128)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_c128) - AND

void REGPARAM2 CPU_OP_NAME(_c130)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_c130) - AND

void REGPARAM2 CPU_OP_NAME(_c138)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_c138) - AND

void REGPARAM2 CPU_OP_NAME(_c139)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_c139) - AND

void REGPARAM2 CPU_OP_NAME(_c140)(uae_u32 opcode) /* EXG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf EXG 6(1/0)
}}}}
// PERFDATA_c140 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_c140) - EXG

void REGPARAM2 CPU_OP_NAME(_c148)(uae_u32 opcode) /* EXG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
	m68k_areg(regs, srcreg) = (dst);
	// perf write: An 0(0/0)
	m68k_areg(regs, dstreg) = (src);
	// perf write: An 0(0/0)
	// perf EXG 6(1/0)
}}}}
// PERFDATA_c148 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_c148) - EXG

void REGPARAM2 CPU_OP_NAME(_c150)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_c150) - AND

void REGPARAM2 CPU_OP_NAME(_c158)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_c158) - AND

void REGPARAM2 CPU_OP_NAME(_c160)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_c160) - AND

void REGPARAM2 CPU_OP_NAME(_c168)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_c168) - AND

void REGPARAM2 CPU_OP_NAME(_c170)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_c170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_c170) - AND

void REGPARAM2 CPU_OP_NAME(_c178)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_c178) - AND

void REGPARAM2 CPU_OP_NAME(_c179)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_c179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_c179) - AND

void REGPARAM2 CPU_OP_NAME(_c188)(uae_u32 opcode) /* EXG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
	m68k_dreg(regs, srcreg) = (dst);
	// perf write: Dn 0(0/0)
	m68k_areg(regs, dstreg) = (src);
	// perf write: An 0(0/0)
	// perf EXG 6(1/0)
}}}}
// PERFDATA_c188 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_c188) - EXG

void REGPARAM2 CPU_OP_NAME(_c190)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_c190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_c190) - AND

void REGPARAM2 CPU_OP_NAME(_c198)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_c198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_c198) - AND

void REGPARAM2 CPU_OP_NAME(_c1a0)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_c1a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_c1a0) - AND

void REGPARAM2 CPU_OP_NAME(_c1a8)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_c1a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_c1a8) - AND

void REGPARAM2 CPU_OP_NAME(_c1b0)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_c1b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_c1b0) - AND

void REGPARAM2 CPU_OP_NAME(_c1b8)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_c1b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_c1b8) - AND

void REGPARAM2 CPU_OP_NAME(_c1b9)(uae_u32 opcode) /* AND */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_c1b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_c1b9) - AND

void REGPARAM2 CPU_OP_NAME(_c1c0)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1c0 {0x42, 0x01, 0x00}	// 70(1/0)   CPU_OP_NAME(_c1c0) - MULS

void REGPARAM2 CPU_OP_NAME(_c1d0)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1d0 {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c1d0) - MULS

void REGPARAM2 CPU_OP_NAME(_c1d8)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}}
// PERFDATA_c1d8 {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c1d8) - MULS

void REGPARAM2 CPU_OP_NAME(_c1e0)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}}
// PERFDATA_c1e0 {0x44, 0x02, 0x00}	// 76(2/0)   CPU_OP_NAME(_c1e0) - MULS

void REGPARAM2 CPU_OP_NAME(_c1e8)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1e8 {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c1e8) - MULS

void REGPARAM2 CPU_OP_NAME(_c1f0)(uae_u32 opcode) /* MULS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}}
// PERFDATA_c1f0 {0x44, 0x03, 0x00}	// 80(3/0)   CPU_OP_NAME(_c1f0) - MULS

void REGPARAM2 CPU_OP_NAME(_c1f8)(uae_u32 opcode) /* MULS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1f8 {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c1f8) - MULS

void REGPARAM2 CPU_OP_NAME(_c1f9)(uae_u32 opcode) /* MULS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1f9 {0x42, 0x04, 0x00}	// 82(4/0)   CPU_OP_NAME(_c1f9) - MULS

void REGPARAM2 CPU_OP_NAME(_c1fa)(uae_u32 opcode) /* MULS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}}
// PERFDATA_c1fa {0x42, 0x03, 0x00}	// 78(3/0)   CPU_OP_NAME(_c1fa) - MULS

void REGPARAM2 CPU_OP_NAME(_c1fb)(uae_u32 opcode) /* MULS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}}
// PERFDATA_c1fb {0x44, 0x03, 0x00}	// 80(3/0)   CPU_OP_NAME(_c1fb) - MULS

void REGPARAM2 CPU_OP_NAME(_c1fc)(uae_u32 opcode) /* MULS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = (uae_s32)(uae_s16)dst * (uae_s32)(uae_s16)src;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf MULS 70(1/0)+*
}}}}}
// PERFDATA_c1fc {0x42, 0x02, 0x00}	// 74(2/0)   CPU_OP_NAME(_c1fc) - MULS

#endif
