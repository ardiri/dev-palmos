#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_1000)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_1000) - MOVE

void REGPARAM2 CPU_OP_NAME(_1010)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_1010) - MOVE

void REGPARAM2 CPU_OP_NAME(_1018)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_1018) - MOVE

void REGPARAM2 CPU_OP_NAME(_1020)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_1020) - MOVE

void REGPARAM2 CPU_OP_NAME(_1028)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_1028) - MOVE

void REGPARAM2 CPU_OP_NAME(_1030)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_1030) - MOVE

void REGPARAM2 CPU_OP_NAME(_1038)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_1038) - MOVE

void REGPARAM2 CPU_OP_NAME(_1039)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_1039) - MOVE

void REGPARAM2 CPU_OP_NAME(_103a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_103a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_103a) - MOVE

void REGPARAM2 CPU_OP_NAME(_103b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_103b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_103b) - MOVE

void REGPARAM2 CPU_OP_NAME(_103c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_103c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_103c) - MOVE

void REGPARAM2 CPU_OP_NAME(_1080)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1080 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_1080) - MOVE

void REGPARAM2 CPU_OP_NAME(_1090)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1090 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1090) - MOVE

void REGPARAM2 CPU_OP_NAME(_1098)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1098 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1098) - MOVE

void REGPARAM2 CPU_OP_NAME(_10a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10a0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_10a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_10a8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_10b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10b0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_10b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_10b8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_10b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_10b9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_10b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_10ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10ba {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_10bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10bb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_10bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_10bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_10bc {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_10bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_10c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10c0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_10c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10d0 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_10d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_10d8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_10d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_10e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_10e0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_10e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10e8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_10f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_10f0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_10f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_10f8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10f8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_10f9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10f9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_10f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_10fa)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_10fa {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_10fb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_10fb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_10fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_10fc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_10fc {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_10fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_1100)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1100 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_1100) - MOVE

void REGPARAM2 CPU_OP_NAME(_1110)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1110) - MOVE

void REGPARAM2 CPU_OP_NAME(_1118)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_1118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1118) - MOVE

void REGPARAM2 CPU_OP_NAME(_1120)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_1120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_1120) - MOVE

void REGPARAM2 CPU_OP_NAME(_1128)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1128) - MOVE

void REGPARAM2 CPU_OP_NAME(_1130)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_1130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1130) - MOVE

void REGPARAM2 CPU_OP_NAME(_1138)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1138) - MOVE

void REGPARAM2 CPU_OP_NAME(_1139)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_1139) - MOVE

void REGPARAM2 CPU_OP_NAME(_113a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_113a {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_113a) - MOVE

void REGPARAM2 CPU_OP_NAME(_113b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_113b {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_113b) - MOVE

void REGPARAM2 CPU_OP_NAME(_113c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_113c {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_113c) - MOVE

void REGPARAM2 CPU_OP_NAME(_1140)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1140 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1140) - MOVE

void REGPARAM2 CPU_OP_NAME(_1150)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1150 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1150) - MOVE

void REGPARAM2 CPU_OP_NAME(_1158)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1158 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1158) - MOVE

void REGPARAM2 CPU_OP_NAME(_1160)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1160 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1160) - MOVE

void REGPARAM2 CPU_OP_NAME(_1168)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1168 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_1168) - MOVE

void REGPARAM2 CPU_OP_NAME(_1170)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1170 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_1170) - MOVE

void REGPARAM2 CPU_OP_NAME(_1178)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1178 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_1178) - MOVE

void REGPARAM2 CPU_OP_NAME(_1179)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1179 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_1179) - MOVE

void REGPARAM2 CPU_OP_NAME(_117a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_117a {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_117a) - MOVE

void REGPARAM2 CPU_OP_NAME(_117b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_117b {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_117b) - MOVE

void REGPARAM2 CPU_OP_NAME(_117c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_117c {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_117c) - MOVE

void REGPARAM2 CPU_OP_NAME(_1180)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1180 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_1180) - MOVE

void REGPARAM2 CPU_OP_NAME(_1190)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_1190 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1190) - MOVE

void REGPARAM2 CPU_OP_NAME(_1198)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_1198 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1198) - MOVE

void REGPARAM2 CPU_OP_NAME(_11a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11a0 {0x04, 0x03, 0x01}	// 20(3/1)   CPU_OP_NAME(_11a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11a8 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_11a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_11b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11b0 {0x04, 0x04, 0x01}	// 24(4/1)   CPU_OP_NAME(_11b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11b8 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_11b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_11b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11b9 {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_11b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_11ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11ba {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_11ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_11bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11bb {0x04, 0x04, 0x01}	// 24(4/1)   CPU_OP_NAME(_11bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_11bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11bc {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_11bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_11c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11c0 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_11c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11d0 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_11d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11d8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_11d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_11e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11e0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_11e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11e8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_11e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_11f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11f0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_11f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_11f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11f8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_11f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_11f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11f9 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_11f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_11fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11fa {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_11fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_11fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_11fb {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_11fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_11fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_11fc {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_11fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_13c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13c0 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_13c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_13d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13d0 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_13d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_13d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_13d8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_13d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_13e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_13e0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_13e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_13e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13e8 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_13e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_13f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_13f0 {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_13f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_13f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13f8 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_13f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_13f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13f9 {0x00, 0x06, 0x01}	// 28(6/1)   CPU_OP_NAME(_13f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_13fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_13fa {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_13fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_13fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_13fb {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_13fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_13fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_13fc {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_13fc) - MOVE

#endif
