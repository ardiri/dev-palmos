#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_6000)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(0)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6000 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6000) - Bcc

void REGPARAM2 CPU_OP_NAME(_6001)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(0)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6001 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6001) - Bcc

void REGPARAM2 CPU_OP_NAME(_60ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(0)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_60ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_60ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6100)(uae_u32 opcode) /* BSR */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	uae_s32 s = (uae_s32)src - (((char *)regs.pc_p) - oldpcp);
	m68k_do_bsr(s);
	fill_prefetch();
	// perf�BSR 18(2/2)
}}}
// PERFDATA_6100 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_6100) - BSR

void REGPARAM2 CPU_OP_NAME(_6101)(uae_u32 opcode) /* BSR */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	uae_s32 s = (uae_s32)src - (((char *)regs.pc_p) - oldpcp);
	m68k_do_bsr(s);
	fill_prefetch();
	// perf�BSR 18(2/2)
}}}
// PERFDATA_6101 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_6101) - BSR

void REGPARAM2 CPU_OP_NAME(_61ff)(uae_u32 opcode) /* BSR */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	uae_s32 s = (uae_s32)src - (((char *)regs.pc_p) - oldpcp);
	m68k_do_bsr(s);
	fill_prefetch();
	// perf�BSR 18(2/2)
}}}
// PERFDATA_61ff {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_61ff) - BSR

void REGPARAM2 CPU_OP_NAME(_6200)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(2)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6200 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6200) - Bcc

void REGPARAM2 CPU_OP_NAME(_6201)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(2)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6201 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6201) - Bcc

void REGPARAM2 CPU_OP_NAME(_62ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(2)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_62ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_62ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6300)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(3)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6300 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6300) - Bcc

void REGPARAM2 CPU_OP_NAME(_6301)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(3)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6301 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6301) - Bcc

void REGPARAM2 CPU_OP_NAME(_63ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(3)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_63ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_63ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6400)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(4)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6400 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6400) - Bcc

void REGPARAM2 CPU_OP_NAME(_6401)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(4)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6401 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6401) - Bcc

void REGPARAM2 CPU_OP_NAME(_64ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(4)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_64ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_64ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6500)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(5)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6500 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6500) - Bcc

void REGPARAM2 CPU_OP_NAME(_6501)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(5)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6501 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6501) - Bcc

void REGPARAM2 CPU_OP_NAME(_65ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(5)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_65ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_65ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6600)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(6)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6600 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6600) - Bcc

void REGPARAM2 CPU_OP_NAME(_6601)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(6)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6601 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6601) - Bcc

void REGPARAM2 CPU_OP_NAME(_66ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(6)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_66ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_66ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6700)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(7)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6700 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6700) - Bcc

void REGPARAM2 CPU_OP_NAME(_6701)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(7)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6701 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6701) - Bcc

void REGPARAM2 CPU_OP_NAME(_67ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(7)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_67ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_67ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6800)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(8)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6800 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6800) - Bcc

void REGPARAM2 CPU_OP_NAME(_6801)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(8)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6801 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6801) - Bcc

void REGPARAM2 CPU_OP_NAME(_68ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(8)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_68ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_68ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6900)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(9)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6900 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6900) - Bcc

void REGPARAM2 CPU_OP_NAME(_6901)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(9)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6901 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6901) - Bcc

void REGPARAM2 CPU_OP_NAME(_69ff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(9)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_69ff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_69ff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6a00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(10)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6a00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6a00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6a01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(10)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6a01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6a01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6aff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(10)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6aff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6aff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6b00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(11)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6b00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6b00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6b01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(11)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6b01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6b01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6bff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(11)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6bff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6bff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6c00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(12)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6c00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6c00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6c01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(12)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6c01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6c01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6cff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(12)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6cff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6cff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6d00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(13)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6d00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6d00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6d01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(13)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6d01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6d01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6dff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(13)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6dff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6dff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6e00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(14)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6e00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6e00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6e01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(14)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6e01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6e01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6eff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(14)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6eff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6eff) - Bcc

void REGPARAM2 CPU_OP_NAME(_6f00)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (cctrue(15)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6f00 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6f00) - Bcc

void REGPARAM2 CPU_OP_NAME(_6f01)(uae_u32 opcode) /* Bcc */
{
	uae_u32 srcreg = (uae_s32)(uae_s8)(opcode & 255);
{	char *oldpcp = (char *)regs.pc_p;
{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
	if (cctrue(15)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.B 10(2/0) if taken, 8(1/0) if not
}}}
// PERFDATA_6f01 {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6f01) - Bcc

void REGPARAM2 CPU_OP_NAME(_6fff)(uae_u32 opcode) /* Bcc */
{
{	char *oldpcp = (char *)regs.pc_p;
{	uae_s32 src = nextilong();
	// perf read: imm2 #<data> L 8(2/0)
	if (cctrue(15)) {
	regs.pc_p = (uae_u8 *)(oldpcp + (uae_s32)src);
	fill_prefetch();
	}
	// perf Bcc.W 10(2/0) if taken, 12(2/0) if not
}}}
// PERFDATA_6fff {0x02, 0xff, 0x00}	// 1022(255/0)   CPU_OP_NAME(_6fff) - Bcc

#endif
