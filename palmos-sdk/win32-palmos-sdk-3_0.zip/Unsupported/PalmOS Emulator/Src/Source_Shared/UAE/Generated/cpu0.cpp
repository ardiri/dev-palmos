#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_0)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_0 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_0) - OR

void REGPARAM2 CPU_OP_NAME(_10)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_10 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_10) - OR

void REGPARAM2 CPU_OP_NAME(_18)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_18 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_18) - OR

void REGPARAM2 CPU_OP_NAME(_20)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_20 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_20) - OR

void REGPARAM2 CPU_OP_NAME(_28)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_28 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_28) - OR

void REGPARAM2 CPU_OP_NAME(_30)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_30 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_30) - OR

void REGPARAM2 CPU_OP_NAME(_38)(uae_u32 opcode) /* OR */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_38 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_38) - OR

void REGPARAM2 CPU_OP_NAME(_39)(uae_u32 opcode) /* OR */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_39 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_39) - OR

void REGPARAM2 CPU_OP_NAME(_3c)(uae_u32 opcode) /* ORSR */
{
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	src &= 0xFF;
	regs.sr |= src;
	MakeFromSR();
	// perf ORSR.B/W 20(3/0)
}}}
// PERFDATA_3c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_3c) - ORSR

void REGPARAM2 CPU_OP_NAME(_40)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_40 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_40) - OR

void REGPARAM2 CPU_OP_NAME(_50)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_50 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_50) - OR

void REGPARAM2 CPU_OP_NAME(_58)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_58 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_58) - OR

void REGPARAM2 CPU_OP_NAME(_60)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_60 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_60) - OR

void REGPARAM2 CPU_OP_NAME(_68)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_68 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_68) - OR

void REGPARAM2 CPU_OP_NAME(_70)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_70 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_70) - OR

void REGPARAM2 CPU_OP_NAME(_78)(uae_u32 opcode) /* OR */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_78 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_78) - OR

void REGPARAM2 CPU_OP_NAME(_79)(uae_u32 opcode) /* OR */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_79 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_79) - OR

void REGPARAM2 CPU_OP_NAME(_7c)(uae_u32 opcode) /* ORSR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	regs.sr |= src;
	MakeFromSR();
	// perf ORSR.B/W 20(3/0)
}}}}
// PERFDATA_7c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_7c) - ORSR

void REGPARAM2 CPU_OP_NAME(_80)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_80 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_80) - OR

void REGPARAM2 CPU_OP_NAME(_90)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_90 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_90) - OR

void REGPARAM2 CPU_OP_NAME(_98)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_98 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_98) - OR

void REGPARAM2 CPU_OP_NAME(_a0)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_a0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_a0) - OR

void REGPARAM2 CPU_OP_NAME(_a8)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_a8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_a8) - OR

void REGPARAM2 CPU_OP_NAME(_b0)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_b0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_b0) - OR

void REGPARAM2 CPU_OP_NAME(_b8)(uae_u32 opcode) /* OR */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_b8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_b8) - OR

void REGPARAM2 CPU_OP_NAME(_b9)(uae_u32 opcode) /* OR */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_b9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_b9) - OR

void REGPARAM2 CPU_OP_NAME(_100)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	// perf BTST.L Dn Dyn 6(1/0) Stat 10(2/0)
}}}}
// PERFDATA_100 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_100) - BTST

void REGPARAM2 CPU_OP_NAME(_108)(uae_u32 opcode) /* MVPMR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr memp = m68k_areg(regs, srcreg) + nextiword();
	// perf read: (d16, Ay)  4(1/0)
{	uae_u16 val = (get_byte(memp) << 8) + get_byte(memp + 2);
	// perf reads: 8(2/0)
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((val) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVEP M, Rn  W 16(4/0) L 24(6/0)
}}}
// PERFDATA_108 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_108) - MVPMR

void REGPARAM2 CPU_OP_NAME(_110)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_110 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_110) - BTST

void REGPARAM2 CPU_OP_NAME(_118)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_118 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_118) - BTST

void REGPARAM2 CPU_OP_NAME(_120)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_120 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_120) - BTST

void REGPARAM2 CPU_OP_NAME(_128)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_128 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_128) - BTST

void REGPARAM2 CPU_OP_NAME(_130)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_130 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_130) - BTST

void REGPARAM2 CPU_OP_NAME(_138)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_138 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_138) - BTST

void REGPARAM2 CPU_OP_NAME(_139)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_139 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_139) - BTST

void REGPARAM2 CPU_OP_NAME(_13a)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 2;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_13a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_13a) - BTST

void REGPARAM2 CPU_OP_NAME(_13b)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 3;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_13b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_13b) - BTST

void REGPARAM2 CPU_OP_NAME(_13c)(uae_u32 opcode) /* BTST */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = nextibyte();
	// perf read: #<data> B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_13c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_13c) - BTST

void REGPARAM2 CPU_OP_NAME(_140)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BCHG.L Dn Dyn 8(1/0)* Stat 12(2/0)*
}}}}
// PERFDATA_140 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_140) - BCHG

void REGPARAM2 CPU_OP_NAME(_148)(uae_u32 opcode) /* MVPMR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr memp = m68k_areg(regs, srcreg) + nextiword();
	// perf read: (d16, Ay)  4(1/0)
{	uae_u32 val = (get_byte(memp) << 24) + (get_byte(memp + 2) << 16)
			  + (get_byte(memp + 4) << 8) + get_byte(memp + 6);
	// perf reads: 16(4/0)
	m68k_dreg(regs, dstreg) = (val);
	// perf write: Dn 0(0/0)
	// perf MOVEP M, Rn  W 16(4/0) L 24(6/0)
}}}
// PERFDATA_148 {0x00, 0x06, 0x00}	// 24(6/0)   CPU_OP_NAME(_148) - MVPMR

void REGPARAM2 CPU_OP_NAME(_150)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_150) - BCHG

void REGPARAM2 CPU_OP_NAME(_158)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_158) - BCHG

void REGPARAM2 CPU_OP_NAME(_160)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_160) - BCHG

void REGPARAM2 CPU_OP_NAME(_168)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_168) - BCHG

void REGPARAM2 CPU_OP_NAME(_170)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_170) - BCHG

void REGPARAM2 CPU_OP_NAME(_178)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_178) - BCHG

void REGPARAM2 CPU_OP_NAME(_179)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_179) - BCHG

void REGPARAM2 CPU_OP_NAME(_17a)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 2;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_17a {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_17a) - BCHG

void REGPARAM2 CPU_OP_NAME(_17b)(uae_u32 opcode) /* BCHG */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 3;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_17b {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_17b) - BCHG

void REGPARAM2 CPU_OP_NAME(_180)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BCLR.L Dn Dyn 10(1/0)* Stat 14(2/0)*
}}}}
// PERFDATA_180 {0x06, 0x01, 0x00}	// 10(1/0)   CPU_OP_NAME(_180) - BCLR

void REGPARAM2 CPU_OP_NAME(_188)(uae_u32 opcode) /* MVPRM */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	uaecptr memp = m68k_areg(regs, dstreg) + nextiword();
	// perf read: (d16, Ay)  4(1/0)
	put_byte(memp, src >> 8); put_byte(memp + 2, src);
	// perf writes: 8(0/2)
	// perf MOVEP Rn, M  W 16(2/2) L 24(2/4)
}}}
// PERFDATA_188 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_188) - MVPRM

void REGPARAM2 CPU_OP_NAME(_190)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_190 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_190) - BCLR

void REGPARAM2 CPU_OP_NAME(_198)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_198 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_198) - BCLR

void REGPARAM2 CPU_OP_NAME(_1a0)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1a0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_1a0) - BCLR

void REGPARAM2 CPU_OP_NAME(_1a8)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1a8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1a8) - BCLR

void REGPARAM2 CPU_OP_NAME(_1b0)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1b0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1b0) - BCLR

void REGPARAM2 CPU_OP_NAME(_1b8)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1b8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1b8) - BCLR

void REGPARAM2 CPU_OP_NAME(_1b9)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1b9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_1b9) - BCLR

void REGPARAM2 CPU_OP_NAME(_1ba)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 2;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1ba {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1ba) - BCLR

void REGPARAM2 CPU_OP_NAME(_1bb)(uae_u32 opcode) /* BCLR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 3;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1bb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1bb) - BCLR

void REGPARAM2 CPU_OP_NAME(_1c0)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BSET.L Dn Dyn 8(1/0)* Stat 12(2/0)*
}}}}
// PERFDATA_1c0 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_1c0) - BSET

void REGPARAM2 CPU_OP_NAME(_1c8)(uae_u32 opcode) /* MVPRM */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
	uaecptr memp = m68k_areg(regs, dstreg) + nextiword();
	// perf read: (d16, Ay)  4(1/0)
	put_byte(memp, src >> 24); put_byte(memp + 2, src >> 16);
	put_byte(memp + 4, src >> 8); put_byte(memp + 6, src);
	// perf writes: 16(0/4)
	// perf MOVEP Rn, M  W 16(2/2) L 24(2/4)
}}}
// PERFDATA_1c8 {0x00, 0x02, 0x04}	// 24(2/4)   CPU_OP_NAME(_1c8) - MVPRM

void REGPARAM2 CPU_OP_NAME(_1d0)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1d0 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1d0) - BSET

void REGPARAM2 CPU_OP_NAME(_1d8)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1d8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_1d8) - BSET

void REGPARAM2 CPU_OP_NAME(_1e0)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1e0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_1e0) - BSET

void REGPARAM2 CPU_OP_NAME(_1e8)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1e8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1e8) - BSET

void REGPARAM2 CPU_OP_NAME(_1f0)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1f0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1f0) - BSET

void REGPARAM2 CPU_OP_NAME(_1f8)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1f8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1f8) - BSET

void REGPARAM2 CPU_OP_NAME(_1f9)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_1f9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_1f9) - BSET

void REGPARAM2 CPU_OP_NAME(_1fa)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 2;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1fa {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_1fa) - BSET

void REGPARAM2 CPU_OP_NAME(_1fb)(uae_u32 opcode) /* BSET */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = 3;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_1fb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_1fb) - BSET

void REGPARAM2 CPU_OP_NAME(_200)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_200 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_200) - AND

void REGPARAM2 CPU_OP_NAME(_210)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_210 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_210) - AND

void REGPARAM2 CPU_OP_NAME(_218)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_218 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_218) - AND

void REGPARAM2 CPU_OP_NAME(_220)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_220 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_220) - AND

void REGPARAM2 CPU_OP_NAME(_228)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_228 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_228) - AND

void REGPARAM2 CPU_OP_NAME(_230)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_230 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_230) - AND

void REGPARAM2 CPU_OP_NAME(_238)(uae_u32 opcode) /* AND */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_238 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_238) - AND

void REGPARAM2 CPU_OP_NAME(_239)(uae_u32 opcode) /* AND */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_239 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_239) - AND

void REGPARAM2 CPU_OP_NAME(_23c)(uae_u32 opcode) /* ANDSR */
{
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	src |= 0xFF00;
	regs.sr &= src;
	MakeFromSR();
	// perf ANDSR.B/W 20(3/0)
}}}
// PERFDATA_23c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_23c) - ANDSR

void REGPARAM2 CPU_OP_NAME(_240)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_240 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_240) - AND

void REGPARAM2 CPU_OP_NAME(_250)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_250 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_250) - AND

void REGPARAM2 CPU_OP_NAME(_258)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_258 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_258) - AND

void REGPARAM2 CPU_OP_NAME(_260)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_260 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_260) - AND

void REGPARAM2 CPU_OP_NAME(_268)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_268 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_268) - AND

void REGPARAM2 CPU_OP_NAME(_270)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}}
// PERFDATA_270 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_270) - AND

void REGPARAM2 CPU_OP_NAME(_278)(uae_u32 opcode) /* AND */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_278 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_278) - AND

void REGPARAM2 CPU_OP_NAME(_279)(uae_u32 opcode) /* AND */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf AND.B/W M, Dn 4(1/0)+  Dn, M 8(1/1)+
}}}}
// PERFDATA_279 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_279) - AND

void REGPARAM2 CPU_OP_NAME(_27c)(uae_u32 opcode) /* ANDSR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	regs.sr &= src;
	MakeFromSR();
	// perf ANDSR.B/W 20(3/0)
}}}}
// PERFDATA_27c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_27c) - ANDSR

void REGPARAM2 CPU_OP_NAME(_280)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf AND.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_280 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_280) - AND

void REGPARAM2 CPU_OP_NAME(_290)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_290 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_290) - AND

void REGPARAM2 CPU_OP_NAME(_298)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_298 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_298) - AND

void REGPARAM2 CPU_OP_NAME(_2a0)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_2a0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_2a0) - AND

void REGPARAM2 CPU_OP_NAME(_2a8)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_2a8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_2a8) - AND

void REGPARAM2 CPU_OP_NAME(_2b0)(uae_u32 opcode) /* AND */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_2b0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_2b0) - AND

void REGPARAM2 CPU_OP_NAME(_2b8)(uae_u32 opcode) /* AND */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_2b8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_2b8) - AND

void REGPARAM2 CPU_OP_NAME(_2b9)(uae_u32 opcode) /* AND */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src &= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf AND.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_2b9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_2b9) - AND

void REGPARAM2 CPU_OP_NAME(_400)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_400 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_400) - SUB

void REGPARAM2 CPU_OP_NAME(_410)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_410 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_410) - SUB

void REGPARAM2 CPU_OP_NAME(_418)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_418 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_418) - SUB

void REGPARAM2 CPU_OP_NAME(_420)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_420 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_420) - SUB

void REGPARAM2 CPU_OP_NAME(_428)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_428 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_428) - SUB

void REGPARAM2 CPU_OP_NAME(_430)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_430 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_430) - SUB

void REGPARAM2 CPU_OP_NAME(_438)(uae_u32 opcode) /* SUB */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_438 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_438) - SUB

void REGPARAM2 CPU_OP_NAME(_439)(uae_u32 opcode) /* SUB */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_439 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_439) - SUB

void REGPARAM2 CPU_OP_NAME(_440)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_440 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_440) - SUB

void REGPARAM2 CPU_OP_NAME(_450)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_450 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_450) - SUB

void REGPARAM2 CPU_OP_NAME(_458)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_458 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_458) - SUB

void REGPARAM2 CPU_OP_NAME(_460)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_460 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_460) - SUB

void REGPARAM2 CPU_OP_NAME(_468)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_468 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_468) - SUB

void REGPARAM2 CPU_OP_NAME(_470)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_470 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_470) - SUB

void REGPARAM2 CPU_OP_NAME(_478)(uae_u32 opcode) /* SUB */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_478 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_478) - SUB

void REGPARAM2 CPU_OP_NAME(_479)(uae_u32 opcode) /* SUB */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_479 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_479) - SUB

void REGPARAM2 CPU_OP_NAME(_480)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}}}
// PERFDATA_480 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_480) - SUB

void REGPARAM2 CPU_OP_NAME(_490)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_490 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_490) - SUB

void REGPARAM2 CPU_OP_NAME(_498)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_498 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_498) - SUB

void REGPARAM2 CPU_OP_NAME(_4a0)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_4a0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_4a0) - SUB

void REGPARAM2 CPU_OP_NAME(_4a8)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_4a8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_4a8) - SUB

void REGPARAM2 CPU_OP_NAME(_4b0)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_4b0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_4b0) - SUB

void REGPARAM2 CPU_OP_NAME(_4b8)(uae_u32 opcode) /* SUB */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_4b8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_4b8) - SUB

void REGPARAM2 CPU_OP_NAME(_4b9)(uae_u32 opcode) /* SUB */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_4b9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_4b9) - SUB

void REGPARAM2 CPU_OP_NAME(_600)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_600 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_600) - ADD

void REGPARAM2 CPU_OP_NAME(_610)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_610 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_610) - ADD

void REGPARAM2 CPU_OP_NAME(_618)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_618 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_618) - ADD

void REGPARAM2 CPU_OP_NAME(_620)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_620 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_620) - ADD

void REGPARAM2 CPU_OP_NAME(_628)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_628 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_628) - ADD

void REGPARAM2 CPU_OP_NAME(_630)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_630 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_630) - ADD

void REGPARAM2 CPU_OP_NAME(_638)(uae_u32 opcode) /* ADD */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_638 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_638) - ADD

void REGPARAM2 CPU_OP_NAME(_639)(uae_u32 opcode) /* ADD */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_639 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_639) - ADD

void REGPARAM2 CPU_OP_NAME(_640)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_640 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_640) - ADD

void REGPARAM2 CPU_OP_NAME(_650)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_650 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_650) - ADD

void REGPARAM2 CPU_OP_NAME(_658)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_658 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_658) - ADD

void REGPARAM2 CPU_OP_NAME(_660)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_660 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_660) - ADD

void REGPARAM2 CPU_OP_NAME(_668)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_668 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_668) - ADD

void REGPARAM2 CPU_OP_NAME(_670)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_670 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_670) - ADD

void REGPARAM2 CPU_OP_NAME(_678)(uae_u32 opcode) /* ADD */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_678 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_678) - ADD

void REGPARAM2 CPU_OP_NAME(_679)(uae_u32 opcode) /* ADD */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_679 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_679) - ADD

void REGPARAM2 CPU_OP_NAME(_680)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}}}
// PERFDATA_680 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_680) - ADD

void REGPARAM2 CPU_OP_NAME(_690)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_690 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_690) - ADD

void REGPARAM2 CPU_OP_NAME(_698)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_698 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_698) - ADD

void REGPARAM2 CPU_OP_NAME(_6a0)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_6a0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_6a0) - ADD

void REGPARAM2 CPU_OP_NAME(_6a8)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_6a8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_6a8) - ADD

void REGPARAM2 CPU_OP_NAME(_6b0)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_6b0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_6b0) - ADD

void REGPARAM2 CPU_OP_NAME(_6b8)(uae_u32 opcode) /* ADD */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_6b8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_6b8) - ADD

void REGPARAM2 CPU_OP_NAME(_6b9)(uae_u32 opcode) /* ADD */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_6b9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_6b9) - ADD

void REGPARAM2 CPU_OP_NAME(_800)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	// perf BTST.L Dn Dyn 6(1/0) Stat 10(2/0)
}}}}
// PERFDATA_800 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_800) - BTST

void REGPARAM2 CPU_OP_NAME(_810)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_810 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_810) - BTST

void REGPARAM2 CPU_OP_NAME(_818)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_818 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_818) - BTST

void REGPARAM2 CPU_OP_NAME(_820)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_820 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_820) - BTST

void REGPARAM2 CPU_OP_NAME(_828)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_828 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_828) - BTST

void REGPARAM2 CPU_OP_NAME(_830)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_830 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_830) - BTST

void REGPARAM2 CPU_OP_NAME(_838)(uae_u32 opcode) /* BTST */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_838 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_838) - BTST

void REGPARAM2 CPU_OP_NAME(_839)(uae_u32 opcode) /* BTST */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_839 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_839) - BTST

void REGPARAM2 CPU_OP_NAME(_83a)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = 2;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_83a {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_83a) - BTST

void REGPARAM2 CPU_OP_NAME(_83b)(uae_u32 opcode) /* BTST */
{
	uae_u32 dstreg = 3;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}}
// PERFDATA_83b {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_83b) - BTST

void REGPARAM2 CPU_OP_NAME(_83c)(uae_u32 opcode) /* BTST */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uae_s8 dst = nextibyte();
	// perf read: #<data> B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	// perf BTST.B M Dyn 4(1/0)+ Stat 8(2/0)+
}}}}
// PERFDATA_83c {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_83c) - BTST

void REGPARAM2 CPU_OP_NAME(_840)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BCHG.L Dn Dyn 8(1/0)* Stat 12(2/0)*
}}}}
// PERFDATA_840 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_840) - BCHG

void REGPARAM2 CPU_OP_NAME(_850)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_850 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_850) - BCHG

void REGPARAM2 CPU_OP_NAME(_858)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_858 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_858) - BCHG

void REGPARAM2 CPU_OP_NAME(_860)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_860 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_860) - BCHG

void REGPARAM2 CPU_OP_NAME(_868)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_868 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_868) - BCHG

void REGPARAM2 CPU_OP_NAME(_870)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_870 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_870) - BCHG

void REGPARAM2 CPU_OP_NAME(_878)(uae_u32 opcode) /* BCHG */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_878 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_878) - BCHG

void REGPARAM2 CPU_OP_NAME(_879)(uae_u32 opcode) /* BCHG */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_879 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_879) - BCHG

void REGPARAM2 CPU_OP_NAME(_87a)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = 2;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_87a {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_87a) - BCHG

void REGPARAM2 CPU_OP_NAME(_87b)(uae_u32 opcode) /* BCHG */
{
	uae_u32 dstreg = 3;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst ^= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCHG.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_87b {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_87b) - BCHG

void REGPARAM2 CPU_OP_NAME(_880)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BCLR.L Dn Dyn 10(1/0)* Stat 14(2/0)*
}}}}
// PERFDATA_880 {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_880) - BCLR

void REGPARAM2 CPU_OP_NAME(_890)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_890 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_890) - BCLR

void REGPARAM2 CPU_OP_NAME(_898)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_898 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_898) - BCLR

void REGPARAM2 CPU_OP_NAME(_8a0)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8a0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_8a0) - BCLR

void REGPARAM2 CPU_OP_NAME(_8a8)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8a8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8a8) - BCLR

void REGPARAM2 CPU_OP_NAME(_8b0)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8b0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_8b0) - BCLR

void REGPARAM2 CPU_OP_NAME(_8b8)(uae_u32 opcode) /* BCLR */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8b8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8b8) - BCLR

void REGPARAM2 CPU_OP_NAME(_8b9)(uae_u32 opcode) /* BCLR */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8b9 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_8b9) - BCLR

void REGPARAM2 CPU_OP_NAME(_8ba)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = 2;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8ba {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8ba) - BCLR

void REGPARAM2 CPU_OP_NAME(_8bb)(uae_u32 opcode) /* BCLR */
{
	uae_u32 dstreg = 3;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst &= ~(1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BCLR.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8bb {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_8bb) - BCLR

void REGPARAM2 CPU_OP_NAME(_8c0)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src &= 31;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	m68k_dreg(regs, dstreg) = (dst);
	// perf write: Dn 0(0/0)
	// perf BSET.L Dn Dyn 8(1/0)* Stat 12(2/0)*
}}}}
// PERFDATA_8c0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_8c0) - BSET

void REGPARAM2 CPU_OP_NAME(_8d0)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8d0 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8d0) - BSET

void REGPARAM2 CPU_OP_NAME(_8d8)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8d8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8d8) - BSET

void REGPARAM2 CPU_OP_NAME(_8e0)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8e0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_8e0) - BSET

void REGPARAM2 CPU_OP_NAME(_8e8)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8e8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8e8) - BSET

void REGPARAM2 CPU_OP_NAME(_8f0)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8f0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_8f0) - BSET

void REGPARAM2 CPU_OP_NAME(_8f8)(uae_u32 opcode) /* BSET */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8f8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8f8) - BSET

void REGPARAM2 CPU_OP_NAME(_8f9)(uae_u32 opcode) /* BSET */
{
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}
// PERFDATA_8f9 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_8f9) - BSET

void REGPARAM2 CPU_OP_NAME(_8fa)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = 2;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8fa {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8fa) - BSET

void REGPARAM2 CPU_OP_NAME(_8fb)(uae_u32 opcode) /* BSET */
{
	uae_u32 dstreg = 3;
{{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
	src &= 7;
	ZFLG = !(dst & (1 << src));
	dst |= (1 << src);
	put_byte(dsta,dst);
	// perf write: (d16, PC), (d8, PC, Xn) B 4(0/1)
	// perf BSET.B M Dyn 8(1/1)+ Stat 12(2/1)+
}}}}}
// PERFDATA_8fb {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_8fb) - BSET

void REGPARAM2 CPU_OP_NAME(_a00)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a00 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_a00) - EOR

void REGPARAM2 CPU_OP_NAME(_a10)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a10 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_a10) - EOR

void REGPARAM2 CPU_OP_NAME(_a18)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a18 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_a18) - EOR

void REGPARAM2 CPU_OP_NAME(_a20)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a20 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_a20) - EOR

void REGPARAM2 CPU_OP_NAME(_a28)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a28 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_a28) - EOR

void REGPARAM2 CPU_OP_NAME(_a30)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a30 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_a30) - EOR

void REGPARAM2 CPU_OP_NAME(_a38)(uae_u32 opcode) /* EOR */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a38 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_a38) - EOR

void REGPARAM2 CPU_OP_NAME(_a39)(uae_u32 opcode) /* EOR */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a39 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_a39) - EOR

void REGPARAM2 CPU_OP_NAME(_a3c)(uae_u32 opcode) /* EORSR */
{
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	src &= 0xFF;
	regs.sr ^= src;
	MakeFromSR();
	// perf EORSR.B/W 20(3/0)
}}}
// PERFDATA_a3c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_a3c) - EORSR

void REGPARAM2 CPU_OP_NAME(_a40)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a40 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_a40) - EOR

void REGPARAM2 CPU_OP_NAME(_a50)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a50 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_a50) - EOR

void REGPARAM2 CPU_OP_NAME(_a58)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a58 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_a58) - EOR

void REGPARAM2 CPU_OP_NAME(_a60)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a60 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_a60) - EOR

void REGPARAM2 CPU_OP_NAME(_a68)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a68 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_a68) - EOR

void REGPARAM2 CPU_OP_NAME(_a70)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_a70 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_a70) - EOR

void REGPARAM2 CPU_OP_NAME(_a78)(uae_u32 opcode) /* EOR */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a78 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_a78) - EOR

void REGPARAM2 CPU_OP_NAME(_a79)(uae_u32 opcode) /* EOR */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_a79 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_a79) - EOR

void REGPARAM2 CPU_OP_NAME(_a7c)(uae_u32 opcode) /* EORSR */
{
{if (!regs.s) { regs.pc_p -= 2; Exception(8,0); } else
{	MakeSR();
{	uae_s16 src = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	regs.sr ^= src;
	MakeFromSR();
	// perf EORSR.B/W 20(3/0)
}}}}
// PERFDATA_a7c {0x08, 0x04, 0x00}	// 24(4/0)   CPU_OP_NAME(_a7c) - EORSR

void REGPARAM2 CPU_OP_NAME(_a80)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf EOR.L M, Dn 8(1/0)+
}}}}
// PERFDATA_a80 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_a80) - EOR

void REGPARAM2 CPU_OP_NAME(_a90)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_a90 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_a90) - EOR

void REGPARAM2 CPU_OP_NAME(_a98)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_a98 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_a98) - EOR

void REGPARAM2 CPU_OP_NAME(_aa0)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_aa0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_aa0) - EOR

void REGPARAM2 CPU_OP_NAME(_aa8)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_aa8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_aa8) - EOR

void REGPARAM2 CPU_OP_NAME(_ab0)(uae_u32 opcode) /* EOR */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_ab0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_ab0) - EOR

void REGPARAM2 CPU_OP_NAME(_ab8)(uae_u32 opcode) /* EOR */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_ab8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_ab8) - EOR

void REGPARAM2 CPU_OP_NAME(_ab9)(uae_u32 opcode) /* EOR */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_ab9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_ab9) - EOR

void REGPARAM2 CPU_OP_NAME(_c00)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_c00 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c00) - CMP

void REGPARAM2 CPU_OP_NAME(_c10)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c10 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c10) - CMP

void REGPARAM2 CPU_OP_NAME(_c18)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c18 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c18) - CMP

void REGPARAM2 CPU_OP_NAME(_c20)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c20 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c20) - CMP

void REGPARAM2 CPU_OP_NAME(_c28)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c28 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c28) - CMP

void REGPARAM2 CPU_OP_NAME(_c30)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c30 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c30) - CMP

void REGPARAM2 CPU_OP_NAME(_c38)(uae_u32 opcode) /* CMP */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c38 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c38) - CMP

void REGPARAM2 CPU_OP_NAME(_c39)(uae_u32 opcode) /* CMP */
{
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c39 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_c39) - CMP

void REGPARAM2 CPU_OP_NAME(_c3a)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 2;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, PC) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c3a {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c3a) - CMP

void REGPARAM2 CPU_OP_NAME(_c3b)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 3;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, PC, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c3b {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c3b) - CMP

void REGPARAM2 CPU_OP_NAME(_c40)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_c40 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_c40) - CMP

void REGPARAM2 CPU_OP_NAME(_c50)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c50 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c50) - CMP

void REGPARAM2 CPU_OP_NAME(_c58)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c58 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_c58) - CMP

void REGPARAM2 CPU_OP_NAME(_c60)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c60 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c60) - CMP

void REGPARAM2 CPU_OP_NAME(_c68)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c68 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c68) - CMP

void REGPARAM2 CPU_OP_NAME(_c70)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c70 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c70) - CMP

void REGPARAM2 CPU_OP_NAME(_c78)(uae_u32 opcode) /* CMP */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c78 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c78) - CMP

void REGPARAM2 CPU_OP_NAME(_c79)(uae_u32 opcode) /* CMP */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c79 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_c79) - CMP

void REGPARAM2 CPU_OP_NAME(_c7a)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 2;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d16, PC) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c7a {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_c7a) - CMP

void REGPARAM2 CPU_OP_NAME(_c7b)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 3;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, PC, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c7b {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_c7b) - CMP

void REGPARAM2 CPU_OP_NAME(_c80)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_c80 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_c80) - CMP

void REGPARAM2 CPU_OP_NAME(_c90)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_c90 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_c90) - CMP

void REGPARAM2 CPU_OP_NAME(_c98)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_c98 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_c98) - CMP

void REGPARAM2 CPU_OP_NAME(_ca0)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_ca0 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_ca0) - CMP

void REGPARAM2 CPU_OP_NAME(_ca8)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_ca8 {0x00, 0x06, 0x00}	// 24(6/0)   CPU_OP_NAME(_ca8) - CMP

void REGPARAM2 CPU_OP_NAME(_cb0)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_cb0 {0x02, 0x06, 0x00}	// 26(6/0)   CPU_OP_NAME(_cb0) - CMP

void REGPARAM2 CPU_OP_NAME(_cb8)(uae_u32 opcode) /* CMP */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_cb8 {0x00, 0x06, 0x00}	// 24(6/0)   CPU_OP_NAME(_cb8) - CMP

void REGPARAM2 CPU_OP_NAME(_cb9)(uae_u32 opcode) /* CMP */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}
// PERFDATA_cb9 {0x00, 0x07, 0x00}	// 28(7/0)   CPU_OP_NAME(_cb9) - CMP

void REGPARAM2 CPU_OP_NAME(_cba)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 2;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_getpc();
	dsta += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d16, PC) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_cba {0x00, 0x06, 0x00}	// 24(6/0)   CPU_OP_NAME(_cba) - CMP

void REGPARAM2 CPU_OP_NAME(_cbb)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = 3;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, PC, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPI #, M B/W 8(2/0)+, L 12(3/0)+
}}}}}}}}
// PERFDATA_cbb {0x02, 0x06, 0x00}	// 26(6/0)   CPU_OP_NAME(_cbb) - CMP

#endif
