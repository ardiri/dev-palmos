#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_5000)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5000) - ADD

void REGPARAM2 CPU_OP_NAME(_5010)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5010 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5010) - ADD

void REGPARAM2 CPU_OP_NAME(_5018)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5018 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5018) - ADD

void REGPARAM2 CPU_OP_NAME(_5020)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5020 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5020) - ADD

void REGPARAM2 CPU_OP_NAME(_5028)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5028 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5028) - ADD

void REGPARAM2 CPU_OP_NAME(_5030)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5030 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_5030) - ADD

void REGPARAM2 CPU_OP_NAME(_5038)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5038 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5038) - ADD

void REGPARAM2 CPU_OP_NAME(_5039)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5039 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_5039) - ADD

void REGPARAM2 CPU_OP_NAME(_5040)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5040) - ADD

void REGPARAM2 CPU_OP_NAME(_5048)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_5048 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5048) - ADDA

void REGPARAM2 CPU_OP_NAME(_5050)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5050 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5050) - ADD

void REGPARAM2 CPU_OP_NAME(_5058)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5058 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5058) - ADD

void REGPARAM2 CPU_OP_NAME(_5060)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5060 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5060) - ADD

void REGPARAM2 CPU_OP_NAME(_5068)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5068 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5068) - ADD

void REGPARAM2 CPU_OP_NAME(_5070)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_5070 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_5070) - ADD

void REGPARAM2 CPU_OP_NAME(_5078)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5078 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5078) - ADD

void REGPARAM2 CPU_OP_NAME(_5079)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_5079 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_5079) - ADD

void REGPARAM2 CPU_OP_NAME(_5080)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}}}
// PERFDATA_5080 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5080) - ADD

void REGPARAM2 CPU_OP_NAME(_5088)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}
// PERFDATA_5088 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5088) - ADDA

void REGPARAM2 CPU_OP_NAME(_5090)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_5090 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_5090) - ADD

void REGPARAM2 CPU_OP_NAME(_5098)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_5098 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_5098) - ADD

void REGPARAM2 CPU_OP_NAME(_50a0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_50a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_50a0) - ADD

void REGPARAM2 CPU_OP_NAME(_50a8)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_50a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_50a8) - ADD

void REGPARAM2 CPU_OP_NAME(_50b0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_50b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_50b0) - ADD

void REGPARAM2 CPU_OP_NAME(_50b8)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_50b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_50b8) - ADD

void REGPARAM2 CPU_OP_NAME(_50b9)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_50b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_50b9) - ADD

void REGPARAM2 CPU_OP_NAME(_50c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(0) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_50c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_50c0) - Scc

void REGPARAM2 CPU_OP_NAME(_50c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(0)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_50c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_50c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_50d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_50d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_50d0) - Scc

void REGPARAM2 CPU_OP_NAME(_50d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_50d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_50d8) - Scc

void REGPARAM2 CPU_OP_NAME(_50e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_50e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_50e0) - Scc

void REGPARAM2 CPU_OP_NAME(_50e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_50e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_50e8) - Scc

void REGPARAM2 CPU_OP_NAME(_50f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_50f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_50f0) - Scc

void REGPARAM2 CPU_OP_NAME(_50f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_50f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_50f8) - Scc

void REGPARAM2 CPU_OP_NAME(_50f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(0) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_50f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_50f9) - Scc

void REGPARAM2 CPU_OP_NAME(_5100)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5100 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5100) - SUB

void REGPARAM2 CPU_OP_NAME(_5110)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5110) - SUB

void REGPARAM2 CPU_OP_NAME(_5118)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5118) - SUB

void REGPARAM2 CPU_OP_NAME(_5120)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5120) - SUB

void REGPARAM2 CPU_OP_NAME(_5128)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5128) - SUB

void REGPARAM2 CPU_OP_NAME(_5130)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_5130) - SUB

void REGPARAM2 CPU_OP_NAME(_5138)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5138) - SUB

void REGPARAM2 CPU_OP_NAME(_5139)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_5139) - SUB

void REGPARAM2 CPU_OP_NAME(_5140)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5140 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5140) - SUB

void REGPARAM2 CPU_OP_NAME(_5148)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_5148 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5148) - SUBA

void REGPARAM2 CPU_OP_NAME(_5150)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5150) - SUB

void REGPARAM2 CPU_OP_NAME(_5158)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5158) - SUB

void REGPARAM2 CPU_OP_NAME(_5160)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5160) - SUB

void REGPARAM2 CPU_OP_NAME(_5168)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5168) - SUB

void REGPARAM2 CPU_OP_NAME(_5170)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_5170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_5170) - SUB

void REGPARAM2 CPU_OP_NAME(_5178)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5178) - SUB

void REGPARAM2 CPU_OP_NAME(_5179)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_5179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_5179) - SUB

void REGPARAM2 CPU_OP_NAME(_5180)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}}}
// PERFDATA_5180 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5180) - SUB

void REGPARAM2 CPU_OP_NAME(_5188)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}
// PERFDATA_5188 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_5188) - SUBA

void REGPARAM2 CPU_OP_NAME(_5190)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_5190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_5190) - SUB

void REGPARAM2 CPU_OP_NAME(_5198)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_5198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_5198) - SUB

void REGPARAM2 CPU_OP_NAME(_51a0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_51a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_51a0) - SUB

void REGPARAM2 CPU_OP_NAME(_51a8)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_51a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_51a8) - SUB

void REGPARAM2 CPU_OP_NAME(_51b0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
	uae_u32 dstreg = opcode & 7;
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_51b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_51b0) - SUB

void REGPARAM2 CPU_OP_NAME(_51b8)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_51b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_51b8) - SUB

void REGPARAM2 CPU_OP_NAME(_51b9)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = imm8_table[((opcode >> 9) & 7)];
{{	uae_u32 src = srcreg;
	// perf read: immi #<data> L 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_51b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_51b9) - SUB

void REGPARAM2 CPU_OP_NAME(_51c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(1) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_51c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_51c0) - Scc

void REGPARAM2 CPU_OP_NAME(_51c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(1)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_51c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_51c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_51d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_51d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_51d0) - Scc

void REGPARAM2 CPU_OP_NAME(_51d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_51d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_51d8) - Scc

void REGPARAM2 CPU_OP_NAME(_51e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_51e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_51e0) - Scc

void REGPARAM2 CPU_OP_NAME(_51e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_51e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_51e8) - Scc

void REGPARAM2 CPU_OP_NAME(_51f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_51f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_51f0) - Scc

void REGPARAM2 CPU_OP_NAME(_51f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_51f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_51f8) - Scc

void REGPARAM2 CPU_OP_NAME(_51f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(1) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_51f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_51f9) - Scc

void REGPARAM2 CPU_OP_NAME(_52c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(2) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_52c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_52c0) - Scc

void REGPARAM2 CPU_OP_NAME(_52c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(2)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_52c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_52c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_52d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_52d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_52d0) - Scc

void REGPARAM2 CPU_OP_NAME(_52d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_52d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_52d8) - Scc

void REGPARAM2 CPU_OP_NAME(_52e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_52e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_52e0) - Scc

void REGPARAM2 CPU_OP_NAME(_52e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_52e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_52e8) - Scc

void REGPARAM2 CPU_OP_NAME(_52f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_52f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_52f0) - Scc

void REGPARAM2 CPU_OP_NAME(_52f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_52f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_52f8) - Scc

void REGPARAM2 CPU_OP_NAME(_52f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(2) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_52f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_52f9) - Scc

void REGPARAM2 CPU_OP_NAME(_53c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(3) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_53c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_53c0) - Scc

void REGPARAM2 CPU_OP_NAME(_53c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(3)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_53c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_53c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_53d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_53d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_53d0) - Scc

void REGPARAM2 CPU_OP_NAME(_53d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_53d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_53d8) - Scc

void REGPARAM2 CPU_OP_NAME(_53e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_53e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_53e0) - Scc

void REGPARAM2 CPU_OP_NAME(_53e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_53e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_53e8) - Scc

void REGPARAM2 CPU_OP_NAME(_53f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_53f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_53f0) - Scc

void REGPARAM2 CPU_OP_NAME(_53f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_53f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_53f8) - Scc

void REGPARAM2 CPU_OP_NAME(_53f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(3) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_53f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_53f9) - Scc

void REGPARAM2 CPU_OP_NAME(_54c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(4) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_54c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_54c0) - Scc

void REGPARAM2 CPU_OP_NAME(_54c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(4)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_54c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_54c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_54d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_54d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_54d0) - Scc

void REGPARAM2 CPU_OP_NAME(_54d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_54d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_54d8) - Scc

void REGPARAM2 CPU_OP_NAME(_54e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_54e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_54e0) - Scc

void REGPARAM2 CPU_OP_NAME(_54e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_54e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_54e8) - Scc

void REGPARAM2 CPU_OP_NAME(_54f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_54f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_54f0) - Scc

void REGPARAM2 CPU_OP_NAME(_54f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_54f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_54f8) - Scc

void REGPARAM2 CPU_OP_NAME(_54f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(4) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_54f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_54f9) - Scc

void REGPARAM2 CPU_OP_NAME(_55c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(5) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_55c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_55c0) - Scc

void REGPARAM2 CPU_OP_NAME(_55c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(5)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_55c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_55c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_55d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_55d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_55d0) - Scc

void REGPARAM2 CPU_OP_NAME(_55d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_55d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_55d8) - Scc

void REGPARAM2 CPU_OP_NAME(_55e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_55e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_55e0) - Scc

void REGPARAM2 CPU_OP_NAME(_55e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_55e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_55e8) - Scc

void REGPARAM2 CPU_OP_NAME(_55f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_55f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_55f0) - Scc

void REGPARAM2 CPU_OP_NAME(_55f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_55f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_55f8) - Scc

void REGPARAM2 CPU_OP_NAME(_55f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(5) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_55f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_55f9) - Scc

void REGPARAM2 CPU_OP_NAME(_56c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(6) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_56c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_56c0) - Scc

void REGPARAM2 CPU_OP_NAME(_56c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(6)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_56c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_56c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_56d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_56d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_56d0) - Scc

void REGPARAM2 CPU_OP_NAME(_56d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_56d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_56d8) - Scc

void REGPARAM2 CPU_OP_NAME(_56e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_56e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_56e0) - Scc

void REGPARAM2 CPU_OP_NAME(_56e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_56e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_56e8) - Scc

void REGPARAM2 CPU_OP_NAME(_56f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_56f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_56f0) - Scc

void REGPARAM2 CPU_OP_NAME(_56f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_56f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_56f8) - Scc

void REGPARAM2 CPU_OP_NAME(_56f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(6) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_56f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_56f9) - Scc

void REGPARAM2 CPU_OP_NAME(_57c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(7) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_57c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_57c0) - Scc

void REGPARAM2 CPU_OP_NAME(_57c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(7)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_57c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_57c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_57d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_57d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_57d0) - Scc

void REGPARAM2 CPU_OP_NAME(_57d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_57d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_57d8) - Scc

void REGPARAM2 CPU_OP_NAME(_57e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_57e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_57e0) - Scc

void REGPARAM2 CPU_OP_NAME(_57e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_57e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_57e8) - Scc

void REGPARAM2 CPU_OP_NAME(_57f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_57f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_57f0) - Scc

void REGPARAM2 CPU_OP_NAME(_57f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_57f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_57f8) - Scc

void REGPARAM2 CPU_OP_NAME(_57f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(7) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_57f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_57f9) - Scc

void REGPARAM2 CPU_OP_NAME(_58c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(8) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_58c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_58c0) - Scc

void REGPARAM2 CPU_OP_NAME(_58c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(8)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_58c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_58c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_58d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_58d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_58d0) - Scc

void REGPARAM2 CPU_OP_NAME(_58d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_58d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_58d8) - Scc

void REGPARAM2 CPU_OP_NAME(_58e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_58e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_58e0) - Scc

void REGPARAM2 CPU_OP_NAME(_58e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_58e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_58e8) - Scc

void REGPARAM2 CPU_OP_NAME(_58f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_58f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_58f0) - Scc

void REGPARAM2 CPU_OP_NAME(_58f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_58f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_58f8) - Scc

void REGPARAM2 CPU_OP_NAME(_58f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(8) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_58f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_58f9) - Scc

void REGPARAM2 CPU_OP_NAME(_59c0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(9) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_59c0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_59c0) - Scc

void REGPARAM2 CPU_OP_NAME(_59c8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(9)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_59c8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_59c8) - DBcc

void REGPARAM2 CPU_OP_NAME(_59d0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_59d0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_59d0) - Scc

void REGPARAM2 CPU_OP_NAME(_59d8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_59d8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_59d8) - Scc

void REGPARAM2 CPU_OP_NAME(_59e0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_59e0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_59e0) - Scc

void REGPARAM2 CPU_OP_NAME(_59e8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_59e8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_59e8) - Scc

void REGPARAM2 CPU_OP_NAME(_59f0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_59f0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_59f0) - Scc

void REGPARAM2 CPU_OP_NAME(_59f8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_59f8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_59f8) - Scc

void REGPARAM2 CPU_OP_NAME(_59f9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(9) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_59f9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_59f9) - Scc

void REGPARAM2 CPU_OP_NAME(_5ac0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(10) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5ac0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5ac0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ac8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(10)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5ac8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5ac8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5ad0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ad0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ad0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ad8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5ad8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ad8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ae0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5ae0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ae0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ae8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ae8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5ae8) - Scc

void REGPARAM2 CPU_OP_NAME(_5af0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5af0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5af0) - Scc

void REGPARAM2 CPU_OP_NAME(_5af8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5af8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5af8) - Scc

void REGPARAM2 CPU_OP_NAME(_5af9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(10) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5af9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5af9) - Scc

void REGPARAM2 CPU_OP_NAME(_5bc0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(11) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5bc0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5bc0) - Scc

void REGPARAM2 CPU_OP_NAME(_5bc8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(11)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5bc8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5bc8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5bd0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5bd0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5bd0) - Scc

void REGPARAM2 CPU_OP_NAME(_5bd8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5bd8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5bd8) - Scc

void REGPARAM2 CPU_OP_NAME(_5be0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5be0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5be0) - Scc

void REGPARAM2 CPU_OP_NAME(_5be8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5be8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5be8) - Scc

void REGPARAM2 CPU_OP_NAME(_5bf0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5bf0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5bf0) - Scc

void REGPARAM2 CPU_OP_NAME(_5bf8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5bf8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5bf8) - Scc

void REGPARAM2 CPU_OP_NAME(_5bf9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(11) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5bf9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5bf9) - Scc

void REGPARAM2 CPU_OP_NAME(_5cc0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(12) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5cc0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5cc0) - Scc

void REGPARAM2 CPU_OP_NAME(_5cc8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(12)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5cc8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5cc8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5cd0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5cd0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5cd0) - Scc

void REGPARAM2 CPU_OP_NAME(_5cd8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5cd8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5cd8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ce0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5ce0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ce0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ce8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ce8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5ce8) - Scc

void REGPARAM2 CPU_OP_NAME(_5cf0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5cf0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5cf0) - Scc

void REGPARAM2 CPU_OP_NAME(_5cf8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5cf8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5cf8) - Scc

void REGPARAM2 CPU_OP_NAME(_5cf9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(12) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5cf9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5cf9) - Scc

void REGPARAM2 CPU_OP_NAME(_5dc0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(13) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5dc0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5dc0) - Scc

void REGPARAM2 CPU_OP_NAME(_5dc8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(13)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5dc8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5dc8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5dd0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5dd0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5dd0) - Scc

void REGPARAM2 CPU_OP_NAME(_5dd8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5dd8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5dd8) - Scc

void REGPARAM2 CPU_OP_NAME(_5de0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5de0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5de0) - Scc

void REGPARAM2 CPU_OP_NAME(_5de8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5de8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5de8) - Scc

void REGPARAM2 CPU_OP_NAME(_5df0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5df0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5df0) - Scc

void REGPARAM2 CPU_OP_NAME(_5df8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5df8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5df8) - Scc

void REGPARAM2 CPU_OP_NAME(_5df9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(13) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5df9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5df9) - Scc

void REGPARAM2 CPU_OP_NAME(_5ec0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(14) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5ec0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5ec0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ec8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(14)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5ec8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5ec8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5ed0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ed0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ed0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ed8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5ed8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ed8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ee0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5ee0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5ee0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ee8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ee8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5ee8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ef0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ef0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5ef0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ef8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ef8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5ef8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ef9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(14) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ef9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5ef9) - Scc

void REGPARAM2 CPU_OP_NAME(_5fc0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{{	int val = cctrue(15) ? 0xff : 0;
#if HAS_PROFILING
	if (gProfilingEnabled && val)
		ProfileIncrementClock(2); // perf extra cycles if byte, register, true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xff) | ((val) & 0xff);
	// perf write: Dn 0(0/0)
	// perf Scc Rn 4(1/0) if false, 6(1/0) if true
}}}}
// PERFDATA_5fc0 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_5fc0) - Scc

void REGPARAM2 CPU_OP_NAME(_5fc8)(uae_u32 opcode) /* DBcc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 offs = nextiword();
	// perf read: imm1 #<data> W 4(1/0)
	if (!cctrue(15)) {
		if (src-- & 0xFFFF) {
			regs.pc_p = (uae_u8 *)((char *)regs.pc_p + (uae_s32)offs - 2);
			fill_prefetch();
		}
#if HAS_PROFILING
	else if (gProfilingEnabled)
		ProfileIncrementClock(2); // perf +2 clocks if cc true
#endif
	m68k_dreg(regs, srcreg) = (m68k_dreg(regs, srcreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	}
	// perf DBcc 12(2/0) if cc, 10(2/0) if not -1, 14(3/0) if -1
}}}}
// PERFDATA_5fc8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_5fc8) - DBcc

void REGPARAM2 CPU_OP_NAME(_5fd0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5fd0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5fd0) - Scc

void REGPARAM2 CPU_OP_NAME(_5fd8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5fd8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5fd8) - Scc

void REGPARAM2 CPU_OP_NAME(_5fe0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}}
// PERFDATA_5fe0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_5fe0) - Scc

void REGPARAM2 CPU_OP_NAME(_5fe8)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5fe8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5fe8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ff0)(uae_u32 opcode) /* Scc */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ff0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_5ff0) - Scc

void REGPARAM2 CPU_OP_NAME(_5ff8)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ff8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_5ff8) - Scc

void REGPARAM2 CPU_OP_NAME(_5ff9)(uae_u32 opcode) /* Scc */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
{	int val = cctrue(15) ? 0xff : 0;
	put_byte(srca,val);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf Scc <M> 8(1/1)+
}}}}
// PERFDATA_5ff9 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_5ff9) - Scc

#endif
