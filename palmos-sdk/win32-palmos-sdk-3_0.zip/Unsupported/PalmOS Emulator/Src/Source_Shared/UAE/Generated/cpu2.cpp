#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_2000)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_2000) - MOVE

void REGPARAM2 CPU_OP_NAME(_2008)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2008 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_2008) - MOVE

void REGPARAM2 CPU_OP_NAME(_2010)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2010 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_2010) - MOVE

void REGPARAM2 CPU_OP_NAME(_2018)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2018 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_2018) - MOVE

void REGPARAM2 CPU_OP_NAME(_2020)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2020 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_2020) - MOVE

void REGPARAM2 CPU_OP_NAME(_2028)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2028 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_2028) - MOVE

void REGPARAM2 CPU_OP_NAME(_2030)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2030 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_2030) - MOVE

void REGPARAM2 CPU_OP_NAME(_2038)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2038 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_2038) - MOVE

void REGPARAM2 CPU_OP_NAME(_2039)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2039 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_2039) - MOVE

void REGPARAM2 CPU_OP_NAME(_203a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_203a {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_203a) - MOVE

void REGPARAM2 CPU_OP_NAME(_203b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_203b {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_203b) - MOVE

void REGPARAM2 CPU_OP_NAME(_203c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_203c {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_203c) - MOVE

void REGPARAM2 CPU_OP_NAME(_2040)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_2040) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2048)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2048 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_2048) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2050)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2050 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_2050) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2058)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_2058 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_2058) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2060)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_2060 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_2060) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2068)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2068 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_2068) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2070)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_2070 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_2070) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2078)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2078 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_2078) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2079)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_2079 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_2079) - MOVEA

void REGPARAM2 CPU_OP_NAME(_207a)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_207a {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_207a) - MOVEA

void REGPARAM2 CPU_OP_NAME(_207b)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_207b {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_207b) - MOVEA

void REGPARAM2 CPU_OP_NAME(_207c)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_u32 val = src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_207c {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_207c) - MOVEA

void REGPARAM2 CPU_OP_NAME(_2080)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2080 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_2080) - MOVE

void REGPARAM2 CPU_OP_NAME(_2088)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2088 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_2088) - MOVE

void REGPARAM2 CPU_OP_NAME(_2090)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2090 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_2090) - MOVE

void REGPARAM2 CPU_OP_NAME(_2098)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2098 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_2098) - MOVE

void REGPARAM2 CPU_OP_NAME(_20a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_20a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_20a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_20b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_20b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_20b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_20b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_20ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20ba {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_20bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20bb {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_20bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_20bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_20bc {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_20bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_20c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20c0 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_20c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20c8 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_20c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20d0 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_20d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_20d8 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_20d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_20e0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_20e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20e8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_20f0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_20f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_20f8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20f8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_20f9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20f9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_20f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_20fa)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_20fa {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_20fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_20fb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_20fb {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_20fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_20fc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 4;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_20fc {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_20fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_2100)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2100 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_2100) - MOVE

void REGPARAM2 CPU_OP_NAME(_2108)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2108 {0x00, 0x01, 0x02}	// 12(1/2)   CPU_OP_NAME(_2108) - MOVE

void REGPARAM2 CPU_OP_NAME(_2110)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2110 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_2110) - MOVE

void REGPARAM2 CPU_OP_NAME(_2118)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_2118 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_2118) - MOVE

void REGPARAM2 CPU_OP_NAME(_2120)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_2120 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_2120) - MOVE

void REGPARAM2 CPU_OP_NAME(_2128)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2128 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_2128) - MOVE

void REGPARAM2 CPU_OP_NAME(_2130)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_2130 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_2130) - MOVE

void REGPARAM2 CPU_OP_NAME(_2138)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2138 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_2138) - MOVE

void REGPARAM2 CPU_OP_NAME(_2139)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2139 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_2139) - MOVE

void REGPARAM2 CPU_OP_NAME(_213a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_213a {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_213a) - MOVE

void REGPARAM2 CPU_OP_NAME(_213b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_213b {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_213b) - MOVE

void REGPARAM2 CPU_OP_NAME(_213c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_213c {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_213c) - MOVE

void REGPARAM2 CPU_OP_NAME(_2140)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2140 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_2140) - MOVE

void REGPARAM2 CPU_OP_NAME(_2148)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2148 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_2148) - MOVE

void REGPARAM2 CPU_OP_NAME(_2150)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2150 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_2150) - MOVE

void REGPARAM2 CPU_OP_NAME(_2158)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2158 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_2158) - MOVE

void REGPARAM2 CPU_OP_NAME(_2160)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2160 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_2160) - MOVE

void REGPARAM2 CPU_OP_NAME(_2168)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2168 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_2168) - MOVE

void REGPARAM2 CPU_OP_NAME(_2170)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2170 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_2170) - MOVE

void REGPARAM2 CPU_OP_NAME(_2178)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2178 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_2178) - MOVE

void REGPARAM2 CPU_OP_NAME(_2179)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2179 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_2179) - MOVE

void REGPARAM2 CPU_OP_NAME(_217a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_217a {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_217a) - MOVE

void REGPARAM2 CPU_OP_NAME(_217b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_217b {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_217b) - MOVE

void REGPARAM2 CPU_OP_NAME(_217c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_217c {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_217c) - MOVE

void REGPARAM2 CPU_OP_NAME(_2180)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2180 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_2180) - MOVE

void REGPARAM2 CPU_OP_NAME(_2188)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2188 {0x02, 0x02, 0x02}	// 18(2/2)   CPU_OP_NAME(_2188) - MOVE

void REGPARAM2 CPU_OP_NAME(_2190)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_2190 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_2190) - MOVE

void REGPARAM2 CPU_OP_NAME(_2198)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_2198 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_2198) - MOVE

void REGPARAM2 CPU_OP_NAME(_21a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21a0 {0x04, 0x04, 0x02}	// 28(4/2)   CPU_OP_NAME(_21a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21a8 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_21a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21b0 {0x04, 0x05, 0x02}	// 32(5/2)   CPU_OP_NAME(_21b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21b8 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_21b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21b9 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_21b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_21ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21ba {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_21ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_21bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21bb {0x04, 0x05, 0x02}	// 32(5/2)   CPU_OP_NAME(_21bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_21bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21bc {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_21bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_21c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21c0 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_21c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21c8 {0x00, 0x02, 0x02}	// 16(2/2)   CPU_OP_NAME(_21c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21d0 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_21d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21d8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_21d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21e0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_21e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21e8 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_21e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21f0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_21f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_21f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21f8 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_21f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_21f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21f9 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_21f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_21fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21fa {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_21fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_21fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_21fb {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_21fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_21fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_21fc {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_21fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_23c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23c0 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_23c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_23c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23c8 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_23c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_23d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23d0 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_23d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_23d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_23d8 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_23d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_23e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_23e0 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_23e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_23e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23e8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_23e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_23f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_23f0 {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_23f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_23f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23f8 {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_23f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_23f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23f9 {0x00, 0x07, 0x02}	// 36(7/2)   CPU_OP_NAME(_23f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_23fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_23fa {0x00, 0x06, 0x02}	// 32(6/2)   CPU_OP_NAME(_23fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_23fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_23fb {0x02, 0x06, 0x02}	// 34(6/2)   CPU_OP_NAME(_23fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_23fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_23fc {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_23fc) - MOVE

#endif
