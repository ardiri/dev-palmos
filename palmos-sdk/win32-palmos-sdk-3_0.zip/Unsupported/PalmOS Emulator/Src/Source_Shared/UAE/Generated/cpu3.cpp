#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_3000)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_3000) - MOVE

void REGPARAM2 CPU_OP_NAME(_3008)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3008 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_3008) - MOVE

void REGPARAM2 CPU_OP_NAME(_3010)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_3010) - MOVE

void REGPARAM2 CPU_OP_NAME(_3018)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_3018) - MOVE

void REGPARAM2 CPU_OP_NAME(_3020)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_3020) - MOVE

void REGPARAM2 CPU_OP_NAME(_3028)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_3028) - MOVE

void REGPARAM2 CPU_OP_NAME(_3030)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_3030) - MOVE

void REGPARAM2 CPU_OP_NAME(_3038)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_3038) - MOVE

void REGPARAM2 CPU_OP_NAME(_3039)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_3039) - MOVE

void REGPARAM2 CPU_OP_NAME(_303a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_303a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_303a) - MOVE

void REGPARAM2 CPU_OP_NAME(_303b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_303b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_303b) - MOVE

void REGPARAM2 CPU_OP_NAME(_303c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_303c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_303c) - MOVE

void REGPARAM2 CPU_OP_NAME(_3040)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_3040) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3048)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3048 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_3048) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3050)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_3050) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3058)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_3058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_3058) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3060)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_3060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_3060) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3068)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_3068) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3070)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_3070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_3070) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3078)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_3078) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3079)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_3079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_3079) - MOVEA

void REGPARAM2 CPU_OP_NAME(_307a)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_307a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_307a) - MOVEA

void REGPARAM2 CPU_OP_NAME(_307b)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}}
// PERFDATA_307b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_307b) - MOVEA

void REGPARAM2 CPU_OP_NAME(_307c)(uae_u32 opcode) /* MOVEA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_u32 val = (uae_s32)(uae_s16)src;
	m68k_areg(regs, dstreg) = (val);
	// perf write: An 0(0/0)
	// perf MOVEA 4(1/0)+
}}}}
// PERFDATA_307c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_307c) - MOVEA

void REGPARAM2 CPU_OP_NAME(_3080)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3080 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_3080) - MOVE

void REGPARAM2 CPU_OP_NAME(_3088)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3088 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_3088) - MOVE

void REGPARAM2 CPU_OP_NAME(_3090)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3090 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3090) - MOVE

void REGPARAM2 CPU_OP_NAME(_3098)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3098 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3098) - MOVE

void REGPARAM2 CPU_OP_NAME(_30a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30a0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_30a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_30a8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30b0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_30b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_30b8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_30b9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_30b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_30ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30ba {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_30bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30bb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_30bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_30bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_30bc {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_30bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_30c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30c0 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_30c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30c8 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_30c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30d0 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_30d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_30d8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_30d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_30e0 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_30e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30e8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_30f0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_30f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_30f8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30f8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_30f9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30f9 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_30f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_30fa)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_30fa {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_30fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_30fb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_30fb {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_30fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_30fc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
{	m68k_areg(regs, dstreg) += 2;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_30fc {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_30fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_3100)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3100 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_3100) - MOVE

void REGPARAM2 CPU_OP_NAME(_3108)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3108 {0x00, 0x01, 0x01}	// 8(1/1)   CPU_OP_NAME(_3108) - MOVE

void REGPARAM2 CPU_OP_NAME(_3110)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3110) - MOVE

void REGPARAM2 CPU_OP_NAME(_3118)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_3118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3118) - MOVE

void REGPARAM2 CPU_OP_NAME(_3120)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_3120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_3120) - MOVE

void REGPARAM2 CPU_OP_NAME(_3128)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_3128) - MOVE

void REGPARAM2 CPU_OP_NAME(_3130)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_3130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_3130) - MOVE

void REGPARAM2 CPU_OP_NAME(_3138)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_3138) - MOVE

void REGPARAM2 CPU_OP_NAME(_3139)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_3139) - MOVE

void REGPARAM2 CPU_OP_NAME(_313a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_313a {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_313a) - MOVE

void REGPARAM2 CPU_OP_NAME(_313b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}}
// PERFDATA_313b {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_313b) - MOVE

void REGPARAM2 CPU_OP_NAME(_313c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_313c {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_313c) - MOVE

void REGPARAM2 CPU_OP_NAME(_3140)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3140 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3140) - MOVE

void REGPARAM2 CPU_OP_NAME(_3148)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3148 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_3148) - MOVE

void REGPARAM2 CPU_OP_NAME(_3150)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3150 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_3150) - MOVE

void REGPARAM2 CPU_OP_NAME(_3158)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3158 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_3158) - MOVE

void REGPARAM2 CPU_OP_NAME(_3160)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3160 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_3160) - MOVE

void REGPARAM2 CPU_OP_NAME(_3168)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3168 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_3168) - MOVE

void REGPARAM2 CPU_OP_NAME(_3170)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3170 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_3170) - MOVE

void REGPARAM2 CPU_OP_NAME(_3178)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3178 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_3178) - MOVE

void REGPARAM2 CPU_OP_NAME(_3179)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3179 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_3179) - MOVE

void REGPARAM2 CPU_OP_NAME(_317a)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_317a {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_317a) - MOVE

void REGPARAM2 CPU_OP_NAME(_317b)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_317b {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_317b) - MOVE

void REGPARAM2 CPU_OP_NAME(_317c)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_317c {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_317c) - MOVE

void REGPARAM2 CPU_OP_NAME(_3180)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3180 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_3180) - MOVE

void REGPARAM2 CPU_OP_NAME(_3188)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3188 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_3188) - MOVE

void REGPARAM2 CPU_OP_NAME(_3190)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_3190 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_3190) - MOVE

void REGPARAM2 CPU_OP_NAME(_3198)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_3198 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_3198) - MOVE

void REGPARAM2 CPU_OP_NAME(_31a0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31a0 {0x04, 0x03, 0x01}	// 20(3/1)   CPU_OP_NAME(_31a0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31a8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31a8 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_31a8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31b0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31b0 {0x04, 0x04, 0x01}	// 24(4/1)   CPU_OP_NAME(_31b0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31b8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31b8 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_31b8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31b9)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31b9 {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_31b9) - MOVE

void REGPARAM2 CPU_OP_NAME(_31ba)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31ba {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_31ba) - MOVE

void REGPARAM2 CPU_OP_NAME(_31bb)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31bb {0x04, 0x04, 0x01}	// 24(4/1)   CPU_OP_NAME(_31bb) - MOVE

void REGPARAM2 CPU_OP_NAME(_31bc)(uae_u32 opcode) /* MOVE */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31bc {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_31bc) - MOVE

void REGPARAM2 CPU_OP_NAME(_31c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31c0 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_31c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31c8 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_31c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31d0 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_31d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31d8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_31d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31e0 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_31e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31e8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_31e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31f0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_31f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_31f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31f8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_31f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_31f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31f9 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_31f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_31fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31fa {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_31fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_31fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_31fb {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_31fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_31fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_31fc {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_31fc) - MOVE

void REGPARAM2 CPU_OP_NAME(_33c0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33c0 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_33c0) - MOVE

void REGPARAM2 CPU_OP_NAME(_33c8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33c8 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_33c8) - MOVE

void REGPARAM2 CPU_OP_NAME(_33d0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33d0 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_33d0) - MOVE

void REGPARAM2 CPU_OP_NAME(_33d8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_33d8 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_33d8) - MOVE

void REGPARAM2 CPU_OP_NAME(_33e0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_33e0 {0x02, 0x04, 0x01}	// 22(4/1)   CPU_OP_NAME(_33e0) - MOVE

void REGPARAM2 CPU_OP_NAME(_33e8)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33e8 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_33e8) - MOVE

void REGPARAM2 CPU_OP_NAME(_33f0)(uae_u32 opcode) /* MOVE */
{
	uae_u32 srcreg = (opcode & 7);
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_33f0 {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_33f0) - MOVE

void REGPARAM2 CPU_OP_NAME(_33f8)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33f8 {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_33f8) - MOVE

void REGPARAM2 CPU_OP_NAME(_33f9)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33f9 {0x00, 0x06, 0x01}	// 28(6/1)   CPU_OP_NAME(_33f9) - MOVE

void REGPARAM2 CPU_OP_NAME(_33fa)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_33fa {0x00, 0x05, 0x01}	// 24(5/1)   CPU_OP_NAME(_33fa) - MOVE

void REGPARAM2 CPU_OP_NAME(_33fb)(uae_u32 opcode) /* MOVE */
{
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}}
// PERFDATA_33fb {0x02, 0x05, 0x01}	// 26(5/1)   CPU_OP_NAME(_33fb) - MOVE

void REGPARAM2 CPU_OP_NAME(_33fc)(uae_u32 opcode) /* MOVE */
{
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf MOVE 4(1/0)+
}}}}
// PERFDATA_33fc {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_33fc) - MOVE

#endif
