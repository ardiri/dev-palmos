#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_9000)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_9000) - SUB

void REGPARAM2 CPU_OP_NAME(_9010)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_9010) - SUB

void REGPARAM2 CPU_OP_NAME(_9018)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_9018) - SUB

void REGPARAM2 CPU_OP_NAME(_9020)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_9020) - SUB

void REGPARAM2 CPU_OP_NAME(_9028)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_9028) - SUB

void REGPARAM2 CPU_OP_NAME(_9030)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_9030) - SUB

void REGPARAM2 CPU_OP_NAME(_9038)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_9038) - SUB

void REGPARAM2 CPU_OP_NAME(_9039)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_9039) - SUB

void REGPARAM2 CPU_OP_NAME(_903a)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_903a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_903a) - SUB

void REGPARAM2 CPU_OP_NAME(_903b)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_903b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_903b) - SUB

void REGPARAM2 CPU_OP_NAME(_903c)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_903c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_903c) - SUB

void REGPARAM2 CPU_OP_NAME(_9040)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_9040) - SUB

void REGPARAM2 CPU_OP_NAME(_9048)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9048 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_9048) - SUB

void REGPARAM2 CPU_OP_NAME(_9050)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_9050) - SUB

void REGPARAM2 CPU_OP_NAME(_9058)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_9058) - SUB

void REGPARAM2 CPU_OP_NAME(_9060)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_9060) - SUB

void REGPARAM2 CPU_OP_NAME(_9068)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_9068) - SUB

void REGPARAM2 CPU_OP_NAME(_9070)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_9070) - SUB

void REGPARAM2 CPU_OP_NAME(_9078)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_9078) - SUB

void REGPARAM2 CPU_OP_NAME(_9079)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_9079) - SUB

void REGPARAM2 CPU_OP_NAME(_907a)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_907a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_907a) - SUB

void REGPARAM2 CPU_OP_NAME(_907b)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_907b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_907b) - SUB

void REGPARAM2 CPU_OP_NAME(_907c)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_907c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_907c) - SUB

void REGPARAM2 CPU_OP_NAME(_9080)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}}}
// PERFDATA_9080 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_9080) - SUB

void REGPARAM2 CPU_OP_NAME(_9088)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}}}
// PERFDATA_9088 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_9088) - SUB

void REGPARAM2 CPU_OP_NAME(_9090)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}
// PERFDATA_9090 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_9090) - SUB

void REGPARAM2 CPU_OP_NAME(_9098)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}}
// PERFDATA_9098 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_9098) - SUB

void REGPARAM2 CPU_OP_NAME(_90a0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}}
// PERFDATA_90a0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_90a0) - SUB

void REGPARAM2 CPU_OP_NAME(_90a8)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}
// PERFDATA_90a8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_90a8) - SUB

void REGPARAM2 CPU_OP_NAME(_90b0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}}
// PERFDATA_90b0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_90b0) - SUB

void REGPARAM2 CPU_OP_NAME(_90b8)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}
// PERFDATA_90b8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_90b8) - SUB

void REGPARAM2 CPU_OP_NAME(_90b9)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}
// PERFDATA_90b9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_90b9) - SUB

void REGPARAM2 CPU_OP_NAME(_90ba)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}}
// PERFDATA_90ba {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_90ba) - SUB

void REGPARAM2 CPU_OP_NAME(_90bb)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L <M>, {An, Dn}  6(1/0)+
}}}}}}}}
// PERFDATA_90bb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_90bb) - SUB

void REGPARAM2 CPU_OP_NAME(_90bc)(uae_u32 opcode) /* SUB */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUB.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}}}
// PERFDATA_90bc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_90bc) - SUB

void REGPARAM2 CPU_OP_NAME(_90c0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90c0 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_90c0) - SUBA

void REGPARAM2 CPU_OP_NAME(_90c8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90c8 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_90c8) - SUBA

void REGPARAM2 CPU_OP_NAME(_90d0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90d0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_90d0) - SUBA

void REGPARAM2 CPU_OP_NAME(_90d8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}}
// PERFDATA_90d8 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_90d8) - SUBA

void REGPARAM2 CPU_OP_NAME(_90e0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}}
// PERFDATA_90e0 {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_90e0) - SUBA

void REGPARAM2 CPU_OP_NAME(_90e8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90e8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_90e8) - SUBA

void REGPARAM2 CPU_OP_NAME(_90f0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}}
// PERFDATA_90f0 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_90f0) - SUBA

void REGPARAM2 CPU_OP_NAME(_90f8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90f8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_90f8) - SUBA

void REGPARAM2 CPU_OP_NAME(_90f9)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90f9 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_90f9) - SUBA

void REGPARAM2 CPU_OP_NAME(_90fa)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}}
// PERFDATA_90fa {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_90fa) - SUBA

void REGPARAM2 CPU_OP_NAME(_90fb)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}}
// PERFDATA_90fb {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_90fb) - SUBA

void REGPARAM2 CPU_OP_NAME(_90fc)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.W, An 8(1/0)
}}}}}
// PERFDATA_90fc {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_90fc) - SUBA

void REGPARAM2 CPU_OP_NAME(_9100)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SUBX.B/W Dn, Dn 4(1/0)
}}}}}}
// PERFDATA_9100 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_9100) - SUBX

void REGPARAM2 CPU_OP_NAME(_9108)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUBX.B/W -(Ax), -(Ay) 18(3/1)
}}}}}}}}
// PERFDATA_9108 {0x06, 0x03, 0x01}	// 22(3/1)   CPU_OP_NAME(_9108) - SUBX

void REGPARAM2 CPU_OP_NAME(_9110)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_9110) - SUB

void REGPARAM2 CPU_OP_NAME(_9118)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_9118) - SUB

void REGPARAM2 CPU_OP_NAME(_9120)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_9120) - SUB

void REGPARAM2 CPU_OP_NAME(_9128)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_9128) - SUB

void REGPARAM2 CPU_OP_NAME(_9130)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_9130) - SUB

void REGPARAM2 CPU_OP_NAME(_9138)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_9138) - SUB

void REGPARAM2 CPU_OP_NAME(_9139)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_9139) - SUB

void REGPARAM2 CPU_OP_NAME(_9140)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf SUBX.B/W Dn, Dn 4(1/0)
}}}}}}
// PERFDATA_9140 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_9140) - SUBX

void REGPARAM2 CPU_OP_NAME(_9148)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUBX.B/W -(Ax), -(Ay) 18(3/1)
}}}}}}}}
// PERFDATA_9148 {0x06, 0x03, 0x01}	// 22(3/1)   CPU_OP_NAME(_9148) - SUBX

void REGPARAM2 CPU_OP_NAME(_9150)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_9150) - SUB

void REGPARAM2 CPU_OP_NAME(_9158)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_9158) - SUB

void REGPARAM2 CPU_OP_NAME(_9160)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_9160) - SUB

void REGPARAM2 CPU_OP_NAME(_9168)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_9168) - SUB

void REGPARAM2 CPU_OP_NAME(_9170)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}}
// PERFDATA_9170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_9170) - SUB

void REGPARAM2 CPU_OP_NAME(_9178)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_9178) - SUB

void REGPARAM2 CPU_OP_NAME(_9179)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf SUB.B/W 4(1/0) Dn, 8(1/1)<M>
}}}}}}}
// PERFDATA_9179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_9179) - SUB

void REGPARAM2 CPU_OP_NAME(_9180)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf SUBX.L Dn, Dn 8(1/0)
}}}}}}
// PERFDATA_9180 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_9180) - SUBX

void REGPARAM2 CPU_OP_NAME(_9188)(uae_u32 opcode) /* SUBX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{	uae_u32 newv = dst - src - (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (!flgs && flgo && !flgn) || (flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && !flgo) || (flgn && (!flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUBX.L -(Ax), -(Ay) 30(5/2)
}}}}}}}}
// PERFDATA_9188 {0x06, 0x05, 0x02}	// 34(5/2)   CPU_OP_NAME(_9188) - SUBX

void REGPARAM2 CPU_OP_NAME(_9190)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_9190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_9190) - SUB

void REGPARAM2 CPU_OP_NAME(_9198)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_9198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_9198) - SUB

void REGPARAM2 CPU_OP_NAME(_91a0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_91a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_91a0) - SUB

void REGPARAM2 CPU_OP_NAME(_91a8)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_91a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_91a8) - SUB

void REGPARAM2 CPU_OP_NAME(_91b0)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}}
// PERFDATA_91b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_91b0) - SUB

void REGPARAM2 CPU_OP_NAME(_91b8)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_91b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_91b8) - SUB

void REGPARAM2 CPU_OP_NAME(_91b9)(uae_u32 opcode) /* SUB */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf SUB.L Dn, <M>  12(1/2)+
}}}}}}}
// PERFDATA_91b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_91b9) - SUB

void REGPARAM2 CPU_OP_NAME(_91c0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}
// PERFDATA_91c0 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_91c0) - SUBA

void REGPARAM2 CPU_OP_NAME(_91c8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}
// PERFDATA_91c8 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_91c8) - SUBA

void REGPARAM2 CPU_OP_NAME(_91d0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}
// PERFDATA_91d0 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_91d0) - SUBA

void REGPARAM2 CPU_OP_NAME(_91d8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}}
// PERFDATA_91d8 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_91d8) - SUBA

void REGPARAM2 CPU_OP_NAME(_91e0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}}
// PERFDATA_91e0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_91e0) - SUBA

void REGPARAM2 CPU_OP_NAME(_91e8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}
// PERFDATA_91e8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_91e8) - SUBA

void REGPARAM2 CPU_OP_NAME(_91f0)(uae_u32 opcode) /* SUBA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}}
// PERFDATA_91f0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_91f0) - SUBA

void REGPARAM2 CPU_OP_NAME(_91f8)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}
// PERFDATA_91f8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_91f8) - SUBA

void REGPARAM2 CPU_OP_NAME(_91f9)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}
// PERFDATA_91f9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_91f9) - SUBA

void REGPARAM2 CPU_OP_NAME(_91fa)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}}
// PERFDATA_91fa {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_91fa) - SUBA

void REGPARAM2 CPU_OP_NAME(_91fb)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L <M>, {An, Dn}  6(1/0)+
}}}}}}
// PERFDATA_91fb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_91fb) - SUBA

void REGPARAM2 CPU_OP_NAME(_91fc)(uae_u32 opcode) /* SUBA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst - src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf SUBA.L {An, Dn, imm}, {An, Dn} 8(1/0)+
}}}}}
// PERFDATA_91fc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_91fc) - SUBA

#endif
