#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_8000)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_8000) - OR

void REGPARAM2 CPU_OP_NAME(_8010)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_8010) - OR

void REGPARAM2 CPU_OP_NAME(_8018)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_8018) - OR

void REGPARAM2 CPU_OP_NAME(_8020)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_8020) - OR

void REGPARAM2 CPU_OP_NAME(_8028)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_8028) - OR

void REGPARAM2 CPU_OP_NAME(_8030)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_8030) - OR

void REGPARAM2 CPU_OP_NAME(_8038)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_8038) - OR

void REGPARAM2 CPU_OP_NAME(_8039)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_8039) - OR

void REGPARAM2 CPU_OP_NAME(_803a)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_803a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_803a) - OR

void REGPARAM2 CPU_OP_NAME(_803b)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_803b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_803b) - OR

void REGPARAM2 CPU_OP_NAME(_803c)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_803c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_803c) - OR

void REGPARAM2 CPU_OP_NAME(_8040)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_8040) - OR

void REGPARAM2 CPU_OP_NAME(_8050)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_8050) - OR

void REGPARAM2 CPU_OP_NAME(_8058)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_8058) - OR

void REGPARAM2 CPU_OP_NAME(_8060)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_8060) - OR

void REGPARAM2 CPU_OP_NAME(_8068)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_8068) - OR

void REGPARAM2 CPU_OP_NAME(_8070)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_8070) - OR

void REGPARAM2 CPU_OP_NAME(_8078)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_8078) - OR

void REGPARAM2 CPU_OP_NAME(_8079)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_8079) - OR

void REGPARAM2 CPU_OP_NAME(_807a)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_807a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_807a) - OR

void REGPARAM2 CPU_OP_NAME(_807b)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_807b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_807b) - OR

void REGPARAM2 CPU_OP_NAME(_807c)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_807c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_807c) - OR

void REGPARAM2 CPU_OP_NAME(_8080)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_8080 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_8080) - OR

void REGPARAM2 CPU_OP_NAME(_8090)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_8090 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_8090) - OR

void REGPARAM2 CPU_OP_NAME(_8098)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_8098 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_8098) - OR

void REGPARAM2 CPU_OP_NAME(_80a0)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_80a0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_80a0) - OR

void REGPARAM2 CPU_OP_NAME(_80a8)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_80a8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_80a8) - OR

void REGPARAM2 CPU_OP_NAME(_80b0)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_80b0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_80b0) - OR

void REGPARAM2 CPU_OP_NAME(_80b8)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_80b8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_80b8) - OR

void REGPARAM2 CPU_OP_NAME(_80b9)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_80b9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_80b9) - OR

void REGPARAM2 CPU_OP_NAME(_80ba)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_80ba {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_80ba) - OR

void REGPARAM2 CPU_OP_NAME(_80bb)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}}
// PERFDATA_80bb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_80bb) - OR

void REGPARAM2 CPU_OP_NAME(_80bc)(uae_u32 opcode) /* OR */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf OR.L <ea>, Dn  6(1/0)+**
}}}}
// PERFDATA_80bc {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_80bc) - OR

void REGPARAM2 CPU_OP_NAME(_80c0)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80c0 {0x88, 0x01, 0x00}	// 140(1/0)   CPU_OP_NAME(_80c0) - DIVU

void REGPARAM2 CPU_OP_NAME(_80d0)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80d0 {0x88, 0x02, 0x00}	// 144(2/0)   CPU_OP_NAME(_80d0) - DIVU

void REGPARAM2 CPU_OP_NAME(_80d8)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}}
// PERFDATA_80d8 {0x88, 0x02, 0x00}	// 144(2/0)   CPU_OP_NAME(_80d8) - DIVU

void REGPARAM2 CPU_OP_NAME(_80e0)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}}
// PERFDATA_80e0 {0x8a, 0x02, 0x00}	// 146(2/0)   CPU_OP_NAME(_80e0) - DIVU

void REGPARAM2 CPU_OP_NAME(_80e8)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80e8 {0x88, 0x03, 0x00}	// 148(3/0)   CPU_OP_NAME(_80e8) - DIVU

void REGPARAM2 CPU_OP_NAME(_80f0)(uae_u32 opcode) /* DIVU */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}}
// PERFDATA_80f0 {0x8a, 0x03, 0x00}	// 150(3/0)   CPU_OP_NAME(_80f0) - DIVU

void REGPARAM2 CPU_OP_NAME(_80f8)(uae_u32 opcode) /* DIVU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80f8 {0x88, 0x03, 0x00}	// 148(3/0)   CPU_OP_NAME(_80f8) - DIVU

void REGPARAM2 CPU_OP_NAME(_80f9)(uae_u32 opcode) /* DIVU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80f9 {0x88, 0x04, 0x00}	// 152(4/0)   CPU_OP_NAME(_80f9) - DIVU

void REGPARAM2 CPU_OP_NAME(_80fa)(uae_u32 opcode) /* DIVU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}}
// PERFDATA_80fa {0x88, 0x03, 0x00}	// 148(3/0)   CPU_OP_NAME(_80fa) - DIVU

void REGPARAM2 CPU_OP_NAME(_80fb)(uae_u32 opcode) /* DIVU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}}
// PERFDATA_80fb {0x8a, 0x03, 0x00}	// 150(3/0)   CPU_OP_NAME(_80fb) - DIVU

void REGPARAM2 CPU_OP_NAME(_80fc)(uae_u32 opcode) /* DIVU */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_u32 newv = (uae_u32)dst / (uae_u32)(uae_u16)src;
	uae_u32 rem = (uae_u32)dst % (uae_u32)(uae_u16)src;
	if (newv > 0xffff) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVU 140(1/0)+*
}}}}
// PERFDATA_80fc {0x88, 0x02, 0x00}	// 144(2/0)   CPU_OP_NAME(_80fc) - DIVU

void REGPARAM2 CPU_OP_NAME(_8100)(uae_u32 opcode) /* SBCD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u16 newv_lo = (dst & 0xF) - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = (dst & 0xF0) - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf SBCD.B Dn, Dn 6(1/0)  M, M 18(3,1)
}}}}}}
// PERFDATA_8100 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_8100) - SBCD

void REGPARAM2 CPU_OP_NAME(_8108)(uae_u32 opcode) /* SBCD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{	uae_u16 newv_lo = (dst & 0xF) - (src & 0xF) - (XFLG ? 1 : 0);
	uae_u16 newv_hi = (dst & 0xF0) - (src & 0xF0);
	uae_u16 newv;
	if (newv_lo > 9) { newv_lo-=6; newv_hi-=0x10; }
	newv = newv_hi + (newv_lo & 0xF);	CFLG = XFLG = (newv_hi & 0x1F0) > 0x90;
	if (CFLG) newv -= 0x60;
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf SBCD.B Dn, Dn 6(1/0)  M, M 18(3,1)
}}}}}}}}
// PERFDATA_8108 {0x06, 0x03, 0x01}	// 22(3/1)   CPU_OP_NAME(_8108) - SBCD

void REGPARAM2 CPU_OP_NAME(_8110)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_8110) - OR

void REGPARAM2 CPU_OP_NAME(_8118)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_8118) - OR

void REGPARAM2 CPU_OP_NAME(_8120)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_8120) - OR

void REGPARAM2 CPU_OP_NAME(_8128)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8128) - OR

void REGPARAM2 CPU_OP_NAME(_8130)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_8130) - OR

void REGPARAM2 CPU_OP_NAME(_8138)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8138) - OR

void REGPARAM2 CPU_OP_NAME(_8139)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8139) - OR

void REGPARAM2 CPU_OP_NAME(_8150)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_8150) - OR

void REGPARAM2 CPU_OP_NAME(_8158)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_8158) - OR

void REGPARAM2 CPU_OP_NAME(_8160)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_8160) - OR

void REGPARAM2 CPU_OP_NAME(_8168)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8168) - OR

void REGPARAM2 CPU_OP_NAME(_8170)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}}
// PERFDATA_8170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_8170) - OR

void REGPARAM2 CPU_OP_NAME(_8178)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_8178) - OR

void REGPARAM2 CPU_OP_NAME(_8179)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf OR.B/W M, Dn 4(1/0)+ Dn, M 8(1/1)+
}}}}
// PERFDATA_8179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_8179) - OR

void REGPARAM2 CPU_OP_NAME(_8190)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_8190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_8190) - OR

void REGPARAM2 CPU_OP_NAME(_8198)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_8198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_8198) - OR

void REGPARAM2 CPU_OP_NAME(_81a0)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_81a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_81a0) - OR

void REGPARAM2 CPU_OP_NAME(_81a8)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_81a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_81a8) - OR

void REGPARAM2 CPU_OP_NAME(_81b0)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}}
// PERFDATA_81b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_81b0) - OR

void REGPARAM2 CPU_OP_NAME(_81b8)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_81b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_81b8) - OR

void REGPARAM2 CPU_OP_NAME(_81b9)(uae_u32 opcode) /* OR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src |= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf OR.L Dn, M  12(1/2)+**
}}}}
// PERFDATA_81b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_81b9) - OR

void REGPARAM2 CPU_OP_NAME(_81c0)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81c0 {0x9a, 0x01, 0x00}	// 158(1/0)   CPU_OP_NAME(_81c0) - DIVS

void REGPARAM2 CPU_OP_NAME(_81d0)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81d0 {0x9a, 0x02, 0x00}	// 162(2/0)   CPU_OP_NAME(_81d0) - DIVS

void REGPARAM2 CPU_OP_NAME(_81d8)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}}
// PERFDATA_81d8 {0x9a, 0x02, 0x00}	// 162(2/0)   CPU_OP_NAME(_81d8) - DIVS

void REGPARAM2 CPU_OP_NAME(_81e0)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}}
// PERFDATA_81e0 {0x9c, 0x02, 0x00}	// 164(2/0)   CPU_OP_NAME(_81e0) - DIVS

void REGPARAM2 CPU_OP_NAME(_81e8)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81e8 {0x9a, 0x03, 0x00}	// 166(3/0)   CPU_OP_NAME(_81e8) - DIVS

void REGPARAM2 CPU_OP_NAME(_81f0)(uae_u32 opcode) /* DIVS */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}}
// PERFDATA_81f0 {0x9c, 0x03, 0x00}	// 168(3/0)   CPU_OP_NAME(_81f0) - DIVS

void REGPARAM2 CPU_OP_NAME(_81f8)(uae_u32 opcode) /* DIVS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81f8 {0x9a, 0x03, 0x00}	// 166(3/0)   CPU_OP_NAME(_81f8) - DIVS

void REGPARAM2 CPU_OP_NAME(_81f9)(uae_u32 opcode) /* DIVS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81f9 {0x9a, 0x04, 0x00}	// 170(4/0)   CPU_OP_NAME(_81f9) - DIVS

void REGPARAM2 CPU_OP_NAME(_81fa)(uae_u32 opcode) /* DIVS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}}
// PERFDATA_81fa {0x9a, 0x03, 0x00}	// 166(3/0)   CPU_OP_NAME(_81fa) - DIVS

void REGPARAM2 CPU_OP_NAME(_81fb)(uae_u32 opcode) /* DIVS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}}
// PERFDATA_81fb {0x9c, 0x03, 0x00}	// 168(3/0)   CPU_OP_NAME(_81fb) - DIVS

void REGPARAM2 CPU_OP_NAME(_81fc)(uae_u32 opcode) /* DIVS */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{	uaecptr oldpc = m68k_getpc();
{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	if(src == 0) Exception(5,oldpc-2); else {
	uae_s32 newv = (uae_s32)dst / (uae_s32)(uae_s16)src;
	uae_u16 rem = (uae_s32)dst % (uae_s32)(uae_s16)src;
	if ((newv & 0xffff8000) != 0 && (newv & 0xffff8000) != 0xffff8000) { VFLG = NFLG = 1; CFLG = 0; } else
	{
	if (((uae_s16)rem < 0) != ((uae_s32)dst < 0)) rem = -rem;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	NFLG = ((uae_s16)(newv)) < 0;
	newv = (newv & 0xffff) | ((uae_u32)rem << 16);
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	}
	}
	// perf DIVS 158(1/0)+*
}}}}
// PERFDATA_81fc {0x9a, 0x02, 0x00}	// 162(2/0)   CPU_OP_NAME(_81fc) - DIVS

#endif
