#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_b000)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_b000) - CMP

void REGPARAM2 CPU_OP_NAME(_b010)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b010) - CMP

void REGPARAM2 CPU_OP_NAME(_b018)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b018) - CMP

void REGPARAM2 CPU_OP_NAME(_b020)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_b020) - CMP

void REGPARAM2 CPU_OP_NAME(_b028)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b028) - CMP

void REGPARAM2 CPU_OP_NAME(_b030)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b030) - CMP

void REGPARAM2 CPU_OP_NAME(_b038)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b038) - CMP

void REGPARAM2 CPU_OP_NAME(_b039)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_b039) - CMP

void REGPARAM2 CPU_OP_NAME(_b03a)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b03a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b03a) - CMP

void REGPARAM2 CPU_OP_NAME(_b03b)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b03b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b03b) - CMP

void REGPARAM2 CPU_OP_NAME(_b03c)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b03c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b03c) - CMP

void REGPARAM2 CPU_OP_NAME(_b040)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_b040) - CMP

void REGPARAM2 CPU_OP_NAME(_b048)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b048 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_b048) - CMP

void REGPARAM2 CPU_OP_NAME(_b050)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b050) - CMP

void REGPARAM2 CPU_OP_NAME(_b058)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b058) - CMP

void REGPARAM2 CPU_OP_NAME(_b060)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_b060) - CMP

void REGPARAM2 CPU_OP_NAME(_b068)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b068) - CMP

void REGPARAM2 CPU_OP_NAME(_b070)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b070) - CMP

void REGPARAM2 CPU_OP_NAME(_b078)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b078) - CMP

void REGPARAM2 CPU_OP_NAME(_b079)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_b079) - CMP

void REGPARAM2 CPU_OP_NAME(_b07a)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b07a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b07a) - CMP

void REGPARAM2 CPU_OP_NAME(_b07b)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}}
// PERFDATA_b07b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b07b) - CMP

void REGPARAM2 CPU_OP_NAME(_b07c)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMP.B/W <ea>, Dn 4(1/0)+
}}}}}}}
// PERFDATA_b07c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_b07c) - CMP

void REGPARAM2 CPU_OP_NAME(_b080)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b080 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b080) - CMP

void REGPARAM2 CPU_OP_NAME(_b088)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b088 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b088) - CMP

void REGPARAM2 CPU_OP_NAME(_b090)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b090 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b090) - CMP

void REGPARAM2 CPU_OP_NAME(_b098)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}}
// PERFDATA_b098 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b098) - CMP

void REGPARAM2 CPU_OP_NAME(_b0a0)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}}
// PERFDATA_b0a0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_b0a0) - CMP

void REGPARAM2 CPU_OP_NAME(_b0a8)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b0a8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b0a8) - CMP

void REGPARAM2 CPU_OP_NAME(_b0b0)(uae_u32 opcode) /* CMP */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}}
// PERFDATA_b0b0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_b0b0) - CMP

void REGPARAM2 CPU_OP_NAME(_b0b8)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b0b8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b0b8) - CMP

void REGPARAM2 CPU_OP_NAME(_b0b9)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b0b9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_b0b9) - CMP

void REGPARAM2 CPU_OP_NAME(_b0ba)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}}
// PERFDATA_b0ba {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b0ba) - CMP

void REGPARAM2 CPU_OP_NAME(_b0bb)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}}
// PERFDATA_b0bb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_b0bb) - CMP

void REGPARAM2 CPU_OP_NAME(_b0bc)(uae_u32 opcode) /* CMP */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMP.L <ea>, Dn 6(1/0)+
}}}}}}}
// PERFDATA_b0bc {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b0bc) - CMP

void REGPARAM2 CPU_OP_NAME(_b0c0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0c0 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b0c0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0c8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0c8 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b0c8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0d0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0d0 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_b0d0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0d8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b0d8 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_b0d8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0e0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b0e0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_b0e0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0e8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0e8 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b0e8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0f0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b0f0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_b0f0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0f8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0f8 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b0f8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0f9)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0f9 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b0f9) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0fa)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b0fa {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b0fa) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0fb)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b0fb {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_b0fb) - CMPA

void REGPARAM2 CPU_OP_NAME(_b0fc)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b0fc {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_b0fc) - CMPA

void REGPARAM2 CPU_OP_NAME(_b100)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((src) & 0xff);
	// perf write: Dn 0(0/0)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b100 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_b100) - EOR

void REGPARAM2 CPU_OP_NAME(_b108)(uae_u32 opcode) /* CMPM */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) - ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u8)(src)) > ((uae_u8)(dst));
	NFLG = flgn != 0;
	// perf CMPM M, M B/W 12(3/0), L 20(5/0)
}}}}}}}}}
// PERFDATA_b108 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b108) - CMPM

void REGPARAM2 CPU_OP_NAME(_b110)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_b110) - EOR

void REGPARAM2 CPU_OP_NAME(_b118)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_b118) - EOR

void REGPARAM2 CPU_OP_NAME(_b120)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_b120) - EOR

void REGPARAM2 CPU_OP_NAME(_b128)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_b128) - EOR

void REGPARAM2 CPU_OP_NAME(_b130)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_b130) - EOR

void REGPARAM2 CPU_OP_NAME(_b138)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_b138) - EOR

void REGPARAM2 CPU_OP_NAME(_b139)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s8)(src)) == 0;
	NFLG = ((uae_s8)(src)) < 0;
	put_byte(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_b139) - EOR

void REGPARAM2 CPU_OP_NAME(_b140)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((src) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b140 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_b140) - EOR

void REGPARAM2 CPU_OP_NAME(_b148)(uae_u32 opcode) /* CMPM */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) - ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u16)(src)) > ((uae_u16)(dst));
	NFLG = flgn != 0;
	// perf CMPM M, M B/W 12(3/0), L 20(5/0)
}}}}}}}}}
// PERFDATA_b148 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_b148) - CMPM

void REGPARAM2 CPU_OP_NAME(_b150)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_b150) - EOR

void REGPARAM2 CPU_OP_NAME(_b158)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_b158) - EOR

void REGPARAM2 CPU_OP_NAME(_b160)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_b160) - EOR

void REGPARAM2 CPU_OP_NAME(_b168)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_b168) - EOR

void REGPARAM2 CPU_OP_NAME(_b170)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}}
// PERFDATA_b170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_b170) - EOR

void REGPARAM2 CPU_OP_NAME(_b178)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_b178) - EOR

void REGPARAM2 CPU_OP_NAME(_b179)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s16)(src)) == 0;
	NFLG = ((uae_s16)(src)) < 0;
	put_word(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf EOR.B/W M, Dn 4(1/0)+,  Dn, M 8(1/1)+
}}}}
// PERFDATA_b179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_b179) - EOR

void REGPARAM2 CPU_OP_NAME(_b180)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	m68k_dreg(regs, dstreg) = (src);
	// perf write: Dn 0(0/0)
	// perf EOR.L M, Dn 8(1/0)+
}}}}
// PERFDATA_b180 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_b180) - EOR

void REGPARAM2 CPU_OP_NAME(_b188)(uae_u32 opcode) /* CMPM */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPM M, M B/W 12(3/0), L 20(5/0)
}}}}}}}}}
// PERFDATA_b188 {0x00, 0x05, 0x00}	// 20(5/0)   CPU_OP_NAME(_b188) - CMPM

void REGPARAM2 CPU_OP_NAME(_b190)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_b190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_b190) - EOR

void REGPARAM2 CPU_OP_NAME(_b198)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_b198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_b198) - EOR

void REGPARAM2 CPU_OP_NAME(_b1a0)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_b1a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_b1a0) - EOR

void REGPARAM2 CPU_OP_NAME(_b1a8)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_b1a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_b1a8) - EOR

void REGPARAM2 CPU_OP_NAME(_b1b0)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}}
// PERFDATA_b1b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_b1b0) - EOR

void REGPARAM2 CPU_OP_NAME(_b1b8)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_b1b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_b1b8) - EOR

void REGPARAM2 CPU_OP_NAME(_b1b9)(uae_u32 opcode) /* EOR */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
	src ^= dst;
	VFLG = CFLG = 0;
	ZFLG = ((uae_s32)(src)) == 0;
	NFLG = ((uae_s32)(src)) < 0;
	put_long(dsta,src);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf EOR.L Dn, M 12(1/2)+
}}}}
// PERFDATA_b1b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_b1b9) - EOR

void REGPARAM2 CPU_OP_NAME(_b1c0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1c0 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b1c0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1c8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1c8 {0x02, 0x01, 0x00}	// 6(1/0)   CPU_OP_NAME(_b1c8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1d0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1d0 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b1d0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1d8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b1d8 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b1d8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1e0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b1e0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_b1e0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1e8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1e8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b1e8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1f0)(uae_u32 opcode) /* CMPA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b1f0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_b1f0) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1f8)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1f8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b1f8) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1f9)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1f9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_b1f9) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1fa)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b1fa {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_b1fa) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1fb)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}}
// PERFDATA_b1fb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_b1fb) - CMPA

void REGPARAM2 CPU_OP_NAME(_b1fc)(uae_u32 opcode) /* CMPA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) - ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs != flgo) && (flgn != flgo);
	CFLG = ((uae_u32)(src)) > ((uae_u32)(dst));
	NFLG = flgn != 0;
	// perf CMPA <ea>, An 6(1/0)+
}}}}}}}
// PERFDATA_b1fc {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_b1fc) - CMPA

#endif
