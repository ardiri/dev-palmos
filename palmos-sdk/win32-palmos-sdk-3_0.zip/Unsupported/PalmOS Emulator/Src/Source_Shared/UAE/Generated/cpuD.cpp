#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"
#include "options.h"
#include "machdep_m68k.h"
#include "memory_cpu.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "compiler.h"
#include "cputbl.h"
#if !defined (MEMFUNCS_DIRECT_REQUESTED) || defined (DIRECT_MEMFUNCS_SUCCESSFUL)
void REGPARAM2 CPU_OP_NAME(_d000)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d000 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_d000) - ADD

void REGPARAM2 CPU_OP_NAME(_d010)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An) B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d010 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d010) - ADD

void REGPARAM2 CPU_OP_NAME(_d018)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, srcreg) += areg_byteinc[srcreg];
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d018 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d018) - ADD

void REGPARAM2 CPU_OP_NAME(_d020)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d020 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_d020) - ADD

void REGPARAM2 CPU_OP_NAME(_d028)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (d16, An) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d028 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d028) - ADD

void REGPARAM2 CPU_OP_NAME(_d030)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, An, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d030 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d030) - ADD

void REGPARAM2 CPU_OP_NAME(_d038)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).W B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d038 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d038) - ADD

void REGPARAM2 CPU_OP_NAME(_d039)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 src = get_byte(srca);
	// perf read: (xxx).L B 12(3/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d039 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_d039) - ADD

void REGPARAM2 CPU_OP_NAME(_d03a)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d16, PC) B 8(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d03a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d03a) - ADD

void REGPARAM2 CPU_OP_NAME(_d03b)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s8 src = get_byte(srca);
	// perf read: (d8, PC, Xn) B 10(2/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d03b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d03b) - ADD

void REGPARAM2 CPU_OP_NAME(_d03c)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = nextibyte();
	// perf read: #<data> B 4(1/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d03c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d03c) - ADD

void REGPARAM2 CPU_OP_NAME(_d040)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d040 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_d040) - ADD

void REGPARAM2 CPU_OP_NAME(_d048)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d048 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_d048) - ADD

void REGPARAM2 CPU_OP_NAME(_d050)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d050 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d050) - ADD

void REGPARAM2 CPU_OP_NAME(_d058)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d058 {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d058) - ADD

void REGPARAM2 CPU_OP_NAME(_d060)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d060 {0x02, 0x02, 0x00}	// 10(2/0)   CPU_OP_NAME(_d060) - ADD

void REGPARAM2 CPU_OP_NAME(_d068)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d068 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d068) - ADD

void REGPARAM2 CPU_OP_NAME(_d070)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d070 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d070) - ADD

void REGPARAM2 CPU_OP_NAME(_d078)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d078 {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d078) - ADD

void REGPARAM2 CPU_OP_NAME(_d079)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d079 {0x00, 0x04, 0x00}	// 16(4/0)   CPU_OP_NAME(_d079) - ADD

void REGPARAM2 CPU_OP_NAME(_d07a)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d07a {0x00, 0x03, 0x00}	// 12(3/0)   CPU_OP_NAME(_d07a) - ADD

void REGPARAM2 CPU_OP_NAME(_d07b)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d07b {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d07b) - ADD

void REGPARAM2 CPU_OP_NAME(_d07c)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d07c {0x00, 0x02, 0x00}	// 8(2/0)   CPU_OP_NAME(_d07c) - ADD

void REGPARAM2 CPU_OP_NAME(_d080)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}}}
// PERFDATA_d080 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d080) - ADD

void REGPARAM2 CPU_OP_NAME(_d088)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}}}
// PERFDATA_d088 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d088) - ADD

void REGPARAM2 CPU_OP_NAME(_d090)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}
// PERFDATA_d090 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d090) - ADD

void REGPARAM2 CPU_OP_NAME(_d098)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}}
// PERFDATA_d098 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d098) - ADD

void REGPARAM2 CPU_OP_NAME(_d0a0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}}
// PERFDATA_d0a0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d0a0) - ADD

void REGPARAM2 CPU_OP_NAME(_d0a8)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}
// PERFDATA_d0a8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d0a8) - ADD

void REGPARAM2 CPU_OP_NAME(_d0b0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}}
// PERFDATA_d0b0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_d0b0) - ADD

void REGPARAM2 CPU_OP_NAME(_d0b8)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}
// PERFDATA_d0b8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d0b8) - ADD

void REGPARAM2 CPU_OP_NAME(_d0b9)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}
// PERFDATA_d0b9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_d0b9) - ADD

void REGPARAM2 CPU_OP_NAME(_d0ba)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}}
// PERFDATA_d0ba {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d0ba) - ADD

void REGPARAM2 CPU_OP_NAME(_d0bb)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}}}
// PERFDATA_d0bb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_d0bb) - ADD

void REGPARAM2 CPU_OP_NAME(_d0bc)(uae_u32 opcode) /* ADD */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}}}
// PERFDATA_d0bc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d0bc) - ADD

void REGPARAM2 CPU_OP_NAME(_d0c0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0c0 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d0c0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0c8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0c8 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d0c8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0d0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An) W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0d0 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_d0d0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0d8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, srcreg) += 2;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}}
// PERFDATA_d0d8 {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_d0d8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0e0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}}
// PERFDATA_d0e0 {0x06, 0x02, 0x00}	// 14(2/0)   CPU_OP_NAME(_d0e0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0e8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (d16, An) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0e8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d0e8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0f0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, An, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}}
// PERFDATA_d0f0 {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_d0f0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0f8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).W W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0f8 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d0f8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0f9)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 src = get_word(srca);
	// perf read: (xxx).L W 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0f9 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_d0f9) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0fa)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d16, PC) W 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}}
// PERFDATA_d0fa {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d0fa) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0fb)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s16 src = get_word(srca);
	// perf read: (d8, PC, Xn) W 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}}
// PERFDATA_d0fb {0x06, 0x03, 0x00}	// 18(3/0)   CPU_OP_NAME(_d0fb) - ADDA

void REGPARAM2 CPU_OP_NAME(_d0fc)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = nextiword();
	// perf read: #<data> W 4(1/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.W 4(1/0)+
}}}}}
// PERFDATA_d0fc {0x04, 0x02, 0x00}	// 12(2/0)   CPU_OP_NAME(_d0fc) - ADDA

void REGPARAM2 CPU_OP_NAME(_d100)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s8 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xff) | ((newv) & 0xff);
	// perf write: Dn 0(0/0)
	// perf ADDX.B/W Dn, Dn 4(1/0)
}}}}}}
// PERFDATA_d100 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_d100) - ADDX

void REGPARAM2 CPU_OP_NAME(_d108)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= areg_byteinc[srcreg];
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s8 src = get_byte(srca);
	// perf read: -(An) B 6(1/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s8)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s8)(newv)) < 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADDX.B/W -(Ax), -(Ay) 18(3/1)
}}}}}}}}
// PERFDATA_d108 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_d108) - ADDX

void REGPARAM2 CPU_OP_NAME(_d110)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An) B 4(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d110 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_d110) - ADD

void REGPARAM2 CPU_OP_NAME(_d118)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: (An)+ B 4(1/0)
{	m68k_areg(regs, dstreg) += areg_byteinc[dstreg];
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d118 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_d118) - ADD

void REGPARAM2 CPU_OP_NAME(_d120)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= areg_byteinc[dstreg];
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s8 dst = get_byte(dsta);
	// perf read: -(An) B 6(1/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d120 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_d120) - ADD

void REGPARAM2 CPU_OP_NAME(_d128)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (d16, An) B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d128 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_d128) - ADD

void REGPARAM2 CPU_OP_NAME(_d130)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s8 dst = get_byte(dsta);
	// perf read: (d8, An, Xn) B 10(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d130 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_d130) - ADD

void REGPARAM2 CPU_OP_NAME(_d138)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).W B 8(2/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d138 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_d138) - ADD

void REGPARAM2 CPU_OP_NAME(_d139)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s8 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s8 dst = get_byte(dsta);
	// perf read: (xxx).L B 12(3/0)
{{uae_u32 newv = ((uae_s8)(dst)) + ((uae_s8)(src));
{	int flgs = ((uae_s8)(src)) < 0;
	int flgo = ((uae_s8)(dst)) < 0;
	int flgn = ((uae_s8)(newv)) < 0;
	ZFLG = ((uae_s8)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u8)(~dst)) < ((uae_u8)(src));
	NFLG = flgn != 0;
	put_byte(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L B 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d139 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_d139) - ADD

void REGPARAM2 CPU_OP_NAME(_d140)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s16 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (m68k_dreg(regs, dstreg) & ~0xffff) | ((newv) & 0xffff);
	// perf write: Dn 0(0/0)
	// perf ADDX.B/W Dn, Dn 4(1/0)
}}}}}}
// PERFDATA_d140 {0x00, 0x01, 0x00}	// 4(1/0)   CPU_OP_NAME(_d140) - ADDX

void REGPARAM2 CPU_OP_NAME(_d148)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 2;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s16 src = get_word(srca);
	// perf read: -(An) W 6(1/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s16)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s16)(newv)) < 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADDX.B/W -(Ax), -(Ay) 18(3/1)
}}}}}}}}
// PERFDATA_d148 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_d148) - ADDX

void REGPARAM2 CPU_OP_NAME(_d150)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An) W 4(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d150 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_d150) - ADD

void REGPARAM2 CPU_OP_NAME(_d158)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: (An)+ W 4(1/0)
{	m68k_areg(regs, dstreg) += 2;
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d158 {0x00, 0x02, 0x01}	// 12(2/1)   CPU_OP_NAME(_d158) - ADD

void REGPARAM2 CPU_OP_NAME(_d160)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 2;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s16 dst = get_word(dsta);
	// perf read: -(An) W 6(1/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d160 {0x02, 0x02, 0x01}	// 14(2/1)   CPU_OP_NAME(_d160) - ADD

void REGPARAM2 CPU_OP_NAME(_d168)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (d16, An) W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d168 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_d168) - ADD

void REGPARAM2 CPU_OP_NAME(_d170)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s16 dst = get_word(dsta);
	// perf read: (d8, An, Xn) W 10(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}}
// PERFDATA_d170 {0x02, 0x03, 0x01}	// 18(3/1)   CPU_OP_NAME(_d170) - ADD

void REGPARAM2 CPU_OP_NAME(_d178)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).W W 8(2/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d178 {0x00, 0x03, 0x01}	// 16(3/1)   CPU_OP_NAME(_d178) - ADD

void REGPARAM2 CPU_OP_NAME(_d179)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s16 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s16 dst = get_word(dsta);
	// perf read: (xxx).L W 12(3/0)
{{uae_u32 newv = ((uae_s16)(dst)) + ((uae_s16)(src));
{	int flgs = ((uae_s16)(src)) < 0;
	int flgo = ((uae_s16)(dst)) < 0;
	int flgn = ((uae_s16)(newv)) < 0;
	ZFLG = ((uae_s16)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u16)(~dst)) < ((uae_u16)(src));
	NFLG = flgn != 0;
	put_word(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L W 4(0/1)
	// perf ADD.B/W <ea>, Dn 4(1/0)+  Dn, <M> 8(1/1)+
}}}}}}}
// PERFDATA_d179 {0x00, 0x04, 0x01}	// 20(4/1)   CPU_OP_NAME(_d179) - ADD

void REGPARAM2 CPU_OP_NAME(_d180)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_dreg(regs, dstreg);
	// perf read: Dn 0(0/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	m68k_dreg(regs, dstreg) = (newv);
	// perf write: Dn 0(0/0)
	// perf ADDX.L Dn, Dn 8(1/0)
}}}}}}
// PERFDATA_d180 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d180) - ADDX

void REGPARAM2 CPU_OP_NAME(_d188)(uae_u32 opcode) /* ADDX */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{	uae_u32 newv = dst + src + (XFLG ? 1 : 0);
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	VFLG = (flgs && flgo && !flgn) || (!flgs && !flgo && flgn);
	XFLG = CFLG = (flgs && flgo) || (!flgn && (flgo || flgs));
	if (((uae_s32)(newv)) != 0) ZFLG = 0;
	NFLG = ((uae_s32)(newv)) < 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADDX.L -(Ax), -(Ay) 30(5/2)
}}}}}}}}
// PERFDATA_d188 {0x02, 0x05, 0x02}	// 30(5/2)   CPU_OP_NAME(_d188) - ADDX

void REGPARAM2 CPU_OP_NAME(_d190)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An) L 8(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_d190 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_d190) - ADD

void REGPARAM2 CPU_OP_NAME(_d198)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, dstreg) += 4;
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_d198 {0x00, 0x03, 0x02}	// 20(3/2)   CPU_OP_NAME(_d198) - ADD

void REGPARAM2 CPU_OP_NAME(_d1a0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	m68k_areg(regs, dstreg) -= 4;
{	uaecptr dsta = m68k_areg(regs, dstreg);
	uae_s32 dst = get_long(dsta);
	// perf read: -(An) L 10(2/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_d1a0 {0x02, 0x03, 0x02}	// 22(3/2)   CPU_OP_NAME(_d1a0) - ADD

void REGPARAM2 CPU_OP_NAME(_d1a8)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = m68k_areg(regs, dstreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (d16, An) L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_d1a8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_d1a8) - ADD

void REGPARAM2 CPU_OP_NAME(_d1b0)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
	uae_u32 dstreg = opcode & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = get_disp_ea(m68k_areg(regs, dstreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 dst = get_long(dsta);
	// perf read: (d8, An, Xn) L 14(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}}
// PERFDATA_d1b0 {0x02, 0x04, 0x02}	// 26(4/2)   CPU_OP_NAME(_d1b0) - ADD

void REGPARAM2 CPU_OP_NAME(_d1b8)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).W L 12(3/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_d1b8 {0x00, 0x04, 0x02}	// 24(4/2)   CPU_OP_NAME(_d1b8) - ADD

void REGPARAM2 CPU_OP_NAME(_d1b9)(uae_u32 opcode) /* ADD */
{
	uae_u32 srcreg = ((opcode >> 9) & 7);
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uaecptr dsta = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 dst = get_long(dsta);
	// perf read: (xxx).L L 16(4/0)
{{uae_u32 newv = ((uae_s32)(dst)) + ((uae_s32)(src));
{	int flgs = ((uae_s32)(src)) < 0;
	int flgo = ((uae_s32)(dst)) < 0;
	int flgn = ((uae_s32)(newv)) < 0;
	ZFLG = ((uae_s32)(newv)) == 0;
	VFLG = (flgs == flgo) && (flgn != flgo);
	CFLG = XFLG = ((uae_u32)(~dst)) < ((uae_u32)(src));
	NFLG = flgn != 0;
	put_long(dsta,newv);
	// perf write: (An), (An)+, -(An), (d16, An), (d8, An, Xn), (xxx).W, (xxx).L L 8(0/2)
	// perf ADD.L  Dn, <M> 12(1/2)+
}}}}}}}
// PERFDATA_d1b9 {0x00, 0x05, 0x02}	// 28(5/2)   CPU_OP_NAME(_d1b9) - ADD

void REGPARAM2 CPU_OP_NAME(_d1c0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_dreg(regs, srcreg);
	// perf read: Dn 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}
// PERFDATA_d1c0 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d1c0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1c8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = m68k_areg(regs, srcreg);
	// perf read: An 0(0/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}
// PERFDATA_d1c8 {0x04, 0x01, 0x00}	// 8(1/0)   CPU_OP_NAME(_d1c8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1d0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An) L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}
// PERFDATA_d1d0 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d1d0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1d8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: (An)+ L 8(2/0)
{	m68k_areg(regs, srcreg) += 4;
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}
// PERFDATA_d1d8 {0x02, 0x03, 0x00}	// 14(3/0)   CPU_OP_NAME(_d1d8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1e0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	m68k_areg(regs, srcreg) -= 4;
{	uaecptr srca = m68k_areg(regs, srcreg);
	uae_s32 src = get_long(srca);
	// perf read: -(An) L 10(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}
// PERFDATA_d1e0 {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d1e0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1e8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_areg(regs, srcreg) + (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, An)  4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (d16, An) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}
// PERFDATA_d1e8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d1e8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1f0)(uae_u32 opcode) /* ADDA */
{
	uae_u32 srcreg = (opcode & 7);
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_areg(regs, srcreg));
	// perf eff addr: (d8, An, Xn) 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, An, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}
// PERFDATA_d1f0 {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_d1f0) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1f8)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = (uae_s32)(uae_s16)nextiword();
	// perf  eff addr: (xxx).W 4(1/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).W L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}
// PERFDATA_d1f8 {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d1f8) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1f9)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = nextilong();
	// perf  eff addr: (xxx).L 8(2/0)
	uae_s32 src = get_long(srca);
	// perf read: (xxx).L L 16(4/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}
// PERFDATA_d1f9 {0x02, 0x05, 0x00}	// 22(5/0)   CPU_OP_NAME(_d1f9) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1fa)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = m68k_getpc();
	srca += (uae_s32)(uae_s16)nextiword();
	// perf eff addr: (d16, PC) 4(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d16, PC) L 12(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}
// PERFDATA_d1fa {0x02, 0x04, 0x00}	// 18(4/0)   CPU_OP_NAME(_d1fa) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1fb)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uaecptr srca = get_disp_ea(m68k_getpc());
	// perf eff addr: (d8, PC, Xn) B 6(1/0)
{	uae_s32 src = get_long(srca);
	// perf read: (d8, PC, Xn) L 14(3/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  <M>, Rn 6(1/0)+
}}}}}}
// PERFDATA_d1fb {0x04, 0x04, 0x00}	// 20(4/0)   CPU_OP_NAME(_d1fb) - ADDA

void REGPARAM2 CPU_OP_NAME(_d1fc)(uae_u32 opcode) /* ADDA */
{
	uae_u32 dstreg = (opcode >> 9) & 7;
{{	uae_s32 src = nextilong();
	// perf read: #<data> L 8(2/0)
{	uae_s32 dst = m68k_areg(regs, dstreg);
	// perf read: An 0(0/0)
{	uae_u32 newv = dst + src;
	m68k_areg(regs, dstreg) = (newv);
	// perf write: An 0(0/0)
	// perf ADD.L  {Rn, imm}, Rn 8(1/0)+
}}}}}
// PERFDATA_d1fc {0x04, 0x03, 0x00}	// 16(3/0)   CPU_OP_NAME(_d1fc) - ADDA

#endif
