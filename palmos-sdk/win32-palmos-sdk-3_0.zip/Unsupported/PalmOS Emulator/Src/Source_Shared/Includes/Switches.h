/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

// Use convention: for the preprocessor symbols in this file used to
// turn features on and off, we follow the "if 0 or not 0" convention,
// not the "if defined or not defined" convention.  Thus, to turn
// off a feature, set the symbol to 0.  To turn on a feature, set the
// symbol to 1.

#if defined (_WINDOWS)

	// BYTESWAP is use by Byteswapping.h/.cpp to determine if
	// byteswapping should actually occur.  If not, it's a NOP.

	#define BYTESWAP			1

#endif


// Define a utility symbol that is guaranteed to be one in debug mode
// and zero in non-debug mode (I don't know what _DEBUG is actually
// defined to, so I'm not going to make any assumptions...)

#if defined (_DEBUG)

	#define ON_IN_DEBUG_MODE	1

#else

	#define ON_IN_DEBUG_MODE	0

#endif


// Define PROFILE_MEMORY to 1 to turn on profiling of memory access.
// Profiling means collecting how often various sections of memory
// are accessed and how they are accessed (read vs. write, byte vs.
// word vs. long.)

#define PROFILE_MEMORY			ON_IN_DEBUG_MODE


// Define REGISTER_HISTORY to 1 to keep a history of the last 512
// register states.

#define REGISTER_HISTORY		ON_IN_DEBUG_MODE


// Define EXCEPTION_HISTORY to 1 to keep a history of the last 512
// exceptions encountered.

#define EXCEPTION_HISTORY		ON_IN_DEBUG_MODE


// Define COUNT_INSTRUCTIONS to 1 to increment a counter each time through
// the CPU loop.

#define COUNT_INSTRUCTIONS		ON_IN_DEBUG_MODE


// Define COUNT_TRAPS to 1 to keep track of the number of ATraps called.

#define COUNT_TRAPS				ON_IN_DEBUG_MODE


// Define TIME_STARTUP to 1 to display the time it takes from when we
// execute the first opcode to the time we get to the digitizer screen.

#define TIME_STARTUP			0


// The number of ticks between calls to WaitNextEvent (Mac only).

#define EVENT_THRESHHOLD		6


// Define this to 1 to turn on PPC message logging (Mac only).

#define LOG_PPC					0


// Define this to 1 to turn on MMF message logging (Windows only).

#define LOG_MMF					0


// Define this to 1 to turn on logging of debugger messages.

#define LOG_DEBUGGER			0


// Define this to 1 to turn on logging of trap patches.

#define LOG_PATCHES				0


// Define this to 1 to turn on some (nascent) thread support (Mac only).

#define USE_THREADS				0


// Define this to 1 to turn on profiling stuff

#define HAS_PROFILING			0


// The emulator can optionally check all access to memory to flag questionable
// or illegal accesses.  There are two ways this checking can be controlled.
//
// At the first level, there are runtime variables that turn on and off
// this checking.  The variables control a fine-grain level of checking:
// there are read and write flags for DRAM, SRAM, ROM, and "unmapped
// memory" (for 8 flags in all).  Additionally, we have flags for checking
// for accesses to Dragonballs registers and low-memory, for 12 flags in
// all.
//
// These flags can be turned on and off at runtime.  However, there is
// still the penalty of constantly checking these flags at runtime, even
// if they are turned off.  Therefore, we can opt to compile those checks
// out for maximum performance.  For each runtime flag, there is a
// corresponding compile time flag that controls whether or not the
// runtime check is made.  If the compile time flag is true, the check
// is made based on the value of the runtime flag.  If the compile time
// flag is false, then the code for the runtime check is removed.
//
// With the compile and runtime flags turned on, startup time on
// my Mac is about 1622 msecs.  With the compile-time flags turned
// off, startup time is about 1407 msecs.  With the compile-time flags
// turned on, but the runtime flags turned off, startup time is
// about 1508 msecs.

#define MASTER_COMPILETIME_VALIDATE_SWITCH	1
#define VALIDATE_DUMMY_GET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_DUMMY_SET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_REGISTER_GET				(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_REGISTER_SET				(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_DRAM_GET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_DRAM_SET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_SRAM_GET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_SRAM_SET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_ROM_GET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)
#define VALIDATE_ROM_SET					(1 && MASTER_COMPILETIME_VALIDATE_SWITCH)

#define MASTER_COMPILETIME_PREVENT_SWITCH	1
#define PREVENT_USER_LOWMEM_GET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_LOWMEM_SET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_GLOBAL_GET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_GLOBAL_SET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_SCREEN_GET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_SCREEN_SET				(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_SRAM_GET				0	// Never make this check.
#define PREVENT_USER_SRAM_SET				1	// Always make this check.
#define PREVENT_USER_REGISTER_GET			(1 && MASTER_COMPILETIME_PREVENT_SWITCH)
#define PREVENT_USER_REGISTER_SET			(1 && MASTER_COMPILETIME_PREVENT_SWITCH)

#define PREVENT_SYSTEM_LOWMEM_SET			1

#define MASTER_RUNTIME_VALIDATE_SWITCH		1
#define MASTER_RUNTIME_PREVENT_SWITCH		1
