/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"
#include "UAE.h"		// uae_s16, uae_s32

#if defined (_WINDOWS)
extern bool	EnableSounds;	// accessed by CPU_setsounds
#endif

const long	kDefaultException	= 0;

enum
{
	kError_NoError = 0,
	kError_DefaultError = 1,

	// ROM-related errors

	kError_NotEnoughMemoryForROM,
	kError_CantFindROMFile,
	kError_CantLoadROMFile,
	kError_InvalidROMData,
	kError_ROMNotSupported,
	kError_CantWriteROM,

	// RAM-related errors

	kError_InvalidRAMSize,
	kError_NotEnoughMemoryForRAM,
	kError_CantLoadRAMFile,
	kError_CantWriteRAM,

	// Other mem errors

	kError_NotEnoughMemoryForCPUTables,
	kError_NotEnoughMemoryForBanks,

	// Palm OS app-related errors
	kError_CantOpenAppFile,
	kError_NotEnoughMemoryForAppFile,
	kError_CantLoadAppFile,
	kError_AppFileIsTooLarge,
	kError_AppFileDatabaseError,
	kError_AppFileDatabaseOpen,

	// Download errors

	kError_CantDownloadROM_OutOfMemory,
	kError_CantDownloadROM_SerialPortBusy,
	kError_CantDownloadROM_BadBaudRate,
	kError_CantDownloadROM_Generic,

	// Misc errors

	kError_CantLoadMenuBar,
	kError_CantLoadWindow,
	kError_CantLoadPicture,
	kError_AppInitFailed,
	kError_UnhandledException,
	kError_CantResizeDisplay,

	kError_LastError				// dummy last enum
};


// Values that can be passed in for the "kind" parameter of PreventedAccess.
// These are powers of two so that we can use them to access a bitfield
// of flags.

enum {
	kLowMem		= 1,
	kGlobal		= 2,
	kScreen		= 4,
	kRegister	= 8
};


// Values that can be passed in for the "flags" parameter of ErrorDialog.
// These are powers of two so that we can use them to specify a set of options.

enum {
	kMsgContinue	= 1,
	kMsgDebug		= 2,
	kMsgReset		= 4
};


// Values that can be passed to Platform::GetString.  Start at 1 to
// help accomodate Windows string resources.

enum {
	kStringScreenMemory = 1,
	kStringGlobalMemory,
	kStringLowMemory,
	kStringRegisterMemory,
	kStringRead,
	kStringFrom,
	kStringWritten,
	kStringTo,
	kStringCurrentApplication,
	kStringUnknownVersion,
	kStringErrDisplayWithGremlins,
	kStringErrDisplay,
	kStringErrException,

	kStringExceptionBase = 32,

	kStringDummyForLameANSIStandard
};


// Public interface to our byte queue.  This queue is used to collect bytes
// going in an out of the serial ports, as well as characters to be passed
// from the keyboard to the emulated ROM.
//
// Most of the implementation of this class is provided by a platform-
// dependent, private class.  The reason for splitting the class up into
// two parts is because the multi-threaded Windows version of the emulator
// needs some synchronization when bytes are added and removed.

class TByteQueuePrivate;

class TByteQueue
{
	public:
								TByteQueue	();
								~TByteQueue	();

		void					Put			(uae_u8 b);
		uae_u8					Get			(void);
		int						GetUsed		(void);
		int						GetFree		(void);
		bool					WaitForDataAvailable (int timeoutms);

	private:
		TByteQueuePrivate*		fImplementation;
};


// The Throw macros throw an exception if a condition is met.

#define Throw_Always(thrw_parm)				{ throw((thrw_parm)); }
#define Throw_IfError(tst_num,thrw_parm)	{ if ((tst_num) != 0) throw((thrw_parm)); }
#define Throw_IfMemError(thrw_parm)			{ if (MemError() != 0) throw((thrw_parm)); }
#define Throw_IfResError(thrw_parm)			{ if (ResError() != 0) throw((thrw_parm)); }
#define Throw_IfNil(tst_ptr,thrw_parm)		{ if ((tst_ptr) == NULL) throw((thrw_parm)); }

// The ThrowNotify macros display an error dialog and throw an exception.

#define ThrowNotify_Always(msg_id,thrw_parm)			{ Platform::ReportError((msg_id)); throw((thrw_parm)); }
#define ThrowNotify_IfError(tst_num,msg_id,thrw_parm)	{ if ((tst_num) != 0) { Platform::ReportError((msg_id)); throw((thrw_parm)); } }
#define ThrowNotify_IfMemError(msg_id,thrw_parm)		{ if (MemError() != 0) { Platform::ReportError((msg_id)); throw((thrw_parm)); } }
#define ThrowNotify_IfResError(msg_id,thrw_parm)		{ if (ResError() != 0) { Platform::ReportError((msg_id)); throw((thrw_parm)); } }
#define ThrowNotify_IfNil(tst_ptr,msg_id,thrw_parm)		{ if ((tst_ptr) == NULL) { Platform::ReportError((msg_id)); throw((thrw_parm)); } }

// The ThrowAlert macros display a critical error dialog and throw an exception.

#define ThrowAlert_Always(msg_id,thrw_parm)				{ Platform::ReportCriticalError((msg_id),0,__FILE__,__LINE__); throw((thrw_parm)); }
#define ThrowAlert_IfError(tst_num,msg_id,thrw_parm)	{ if ((tst_num) != 0) { Platform::ReportCriticalError((msg_id),tst_num,__FILE__,__LINE__); throw((thrw_parm)); } }
#define ThrowAlert_IfMemError(msg_id,thrw_parm)			{ if (MemError() != 0) { Platform::ReportCriticalError((msg_id),MemError(),__FILE__,__LINE__); throw((thrw_parm)); } }
#define ThrowAlert_IfResError(msg_id,thrw_parm)			{ if (ResError() != 0) { Platform::ReportCriticalError((msg_id),ResError(),__FILE__,__LINE__); throw((thrw_parm)); } }
#define ThrowAlert_IfNil(tst_ptr,msg_id,thrw_parm)		{ if ((tst_ptr) == NULL) { Platform::ReportCriticalError((msg_id),0,__FILE__,__LINE__); throw((thrw_parm)); } }


// Globals

extern unsigned long	gPseudoTickcount;

// Function prototypes.

class Platform
{
	public:
		static void		Initialize				(void);
		static void		Reset					(void);

		static void		ReportString			(const unsigned char* iMessageString);
		static void		ReportString			(const char* iMessageString);
		static void		ReportError				(long iMessageID);
		static void		ReportCriticalError		(long iMessageID,
												 long iErrorID,
												 const char* iFileName,
												 long iLineNumber);

		static int		ErrorDialog				(const char*, int flags);

		static char*	GetString				(int id);

		static void		Delay					(void);
		static bool		TimeForCycle			(bool sleeping);
		static void		Cycle					(void);

		static void		Debugger				(void);

		static uae_u32	GetMilliseconds			(void);
		static void		GetTime					(long* hour, long* min, long* sec);
		static void		GetDate					(long* year, long* month, long* day);

		static uae_u32	ConnectToDebugger		(void);
		static uae_u32	SendPacket				(const void* pkt, long size);
		static void		DisconnectFromDebugger	(void);

		static void		ViewDrawLine			(int xStart, int yStart, int xEnd, int yEnd);
		static void		ViewDrawPixel			(int xPos, int yPos);

		static void		OpenSerialPort			(void);
		static bool		CloseSerialPort			(void);
		static void		SetBaud					(uae_u16 newRate);
		static void		SetCTS					(uae_u16 newCTS);
		static void		WriteSerialByte			(uae_u8 outByte);
		static uae_u8	ReadSerialByte			(void);
		static uae_u32	IncomingSerialBytes		(void);
		static uae_u32	OutgoingSerialBytes		(void);
};

#if defined (__MACOS__)

extern unsigned long	gLastCycleTime;
#include "CEmulatorApp.h"	// gApplication

inline bool Platform::TimeForCycle (bool sleeping)
{
	// Respond to debugger packets immediately.

	if (gApplication->ReceivedPacket ())
		return true;

	// Calling LMGetTicks every time through the CPU loop is excessive.
	// On a 266MHz PowerMac, we can execute about 30K opcodes/tick, so
	// let's check in with gApplication and LMGetTicks only that often.
	// Checking in every 32768 opcodes, we get about a 9% performance
	// increase (1850 msecs vs. 1690 msecs in the tests I ran).

	static instructionCount;
	instructionCount++;
	if (!sleeping && (instructionCount & 0x7FFF) != 0)
		return false;

	return ((LMGetTicks () - gLastCycleTime) >= EVENT_THRESHHOLD);
}

inline void Platform::Debugger (void)
{
	::Debugger ();
}

#endif

#if defined (_WINDOWS)

inline bool Platform::TimeForCycle (bool)
{
	static unsigned long	lastPseudoTickcount;

	if (lastPseudoTickcount != gPseudoTickcount)
	{
		lastPseudoTickcount = gPseudoTickcount;
		return true;
	}

	return false;
}

inline void Platform::Debugger (void)
{
	__asm int 3;
}

#endif

