/*******************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 * FileName:
 *		HardwareTD1.h
 *
 * Description:
 *		Hardware Equates for the TD1 platform. This header file
 *  contains equates specific to Hardware platform TD1.
 *  It is included only in the modules "ROMHardwareTD1.c" and
 *  "AMXHardwareTD1.c".
 *
 * History:
 *   6/13/95  RM - Created by Ron Marianetti
 *
 *******************************************************************/  

#ifdef	NON_PORTABLE									// So app's don't mistakenly include this

#ifndef __HARDWARETD1_H__
#define __HARDWARETD1_H__



/************************************************************************
 * Port D Bit settings
 ************************************************************************/
#define	hwrTD1PortDNoExtPower		0x80			// (L) External DC input

/************************************************************************
 * Port E Bit settings
 ************************************************************************/
#define	hwrTD1PortENoBacklight		0x80			// (H) high if no backlight present

/************************************************************************
 * Port F Bit settings
 ************************************************************************/
#define	hwrTD1PortFPanelYPOff		0x01			// (L) Vcc to Y Panel
#define	hwrTD1PortFPanelYMOn			0x02			// (H) Gnd to Y Panel
#define	hwrTD1PortFPanelXPOff		0x04			// (L) Vcc to X Panel
#define	hwrTD1PortFPanelXMOn			0x08			// (H) Gnd to X Panel
#define	hwrTD1PortFLCDEnableOn		0x10			// (H) LCD Display on	
#define	hwrTD1PortFLCDVccOff			0x20			// (L) LCD Vcc		
#define	hwrTD1PortFLCDVeeOn			0x40			// (H) LCD Vee
#define	hwrTD1PortFADCSOff			0x80			// (L) A/D Chip Select


// Configurations of the panel control bits
#define	hwrTD1PortFPanelMask			0x0F			// Panel control bits

// Configure for lowest power
#define	hwrTD1PortFPanelCfgOff			(hwrTD1PortFPanelYPOff | 		\
												 	 hwrTD1PortFPanelXPOff)

// Configure to generate pen interrupt
#define	hwrTD1PortFPanelCfgPenIRQ		(hwrTD1PortFPanelXMOn | 		\
								 				 	 hwrTD1PortFPanelYPOff | 		\
												 	 hwrTD1PortFPanelXPOff)

// Configure to Measure Y Position
#define	hwrTD1PortFPanelCfgYMeas		(hwrTD1PortFPanelXMOn | 		\
								 				 	 hwrTD1PortFPanelYPOff)

// Configure to Measure X Position
#define	hwrTD1PortFPanelCfgXMeas		(hwrTD1PortFPanelXPOff | 		\
								 				 	 hwrTD1PortFPanelYMOn)


/************************************************************************
 * Port G Bit Assignments
 ************************************************************************/
#define	hwrTD1PortGSerialOn			0x08			// (H) Serial Driver Enable
#define	hwrTD1PortGBattOff			0x10			// (L) Battery Voltage Measure
#define	hwrTD1PortGRefreshOut		0x20			// (L) Timer 1 output to signal refresh
#define	hwrTD1PortGSelfRefOff		0x40			// (L) PSRAM Self Refresh mode
#define	hwrTD1PortGSelfRefOffBit	6				//  Bit # for above
#define	hwrTD1PortGBacklightOn		0x80			// (H) Turn on backlight

/************************************************************************
 * Port J Bit Assignments
 ************************************************************************/
#define	hwrTD1PortJIrOn				0x10			// (L) IrDA Driver Enable
#define	hwrTD1PortJLedOn				0x20			// (H) LED On

/************************************************************************
 * Port M Bit Assignments
 ************************************************************************/
#define	hwrTD1PortMVccFail			0x04			// (L) Input indicates 3.3v is too low
#define	hwrTD1PortMCardIRQ			0x08			// (L) IRQ3 input from card
#define	hwrTD1PortMUnused4			0x10			// Unused (IRQ2)
#define	hwrTD1PortMDockButton		0x20			// (L) Sync button from Serial Doc
#define	hwrTD1PortMPenIO				0x40			// Pen input/output
#define	hwrTD1PortMDockIn				0x80			// (L) Gen. Purpose input from Serial Doc



/************************************************************************
 * SPIM Base Configuration
 ************************************************************************/
#define	hwrTD1SPIMBaseControl		(hwr328SPIMControlRateDiv16 |		\
												 hwr328SPIMControlIntEnable |		\
												 hwr328SPIMControlInvPolarity |	\
												 hwr328SPIMControlOppPhase  |  	\
												 16-1)


/************************************************************************
 * Macros for turning write-protection on/off
 * These are used in-line for MemSemaphoreReserve and MemSemaphoreRelease
 *  for performance reasons.
 ************************************************************************/
#define	hwrWriteProtectOff()														\
	{																						\
	HwrDBallPtr baseP = (HwrDBallPtr)hwr68328Base;							\
	/* Word			mask; */															\
																							\
	/* DOLATER.. take this out....	*/											\
	/* mask = baseP->csAGroupMask;	*/											\
																							\
	/* Clr read-only bit in chip select register for storage area */	\
	baseP->csASelect1 &= ~(0x0008);												\
	baseP->csASelect3 &= ~(0x0008);												\
																							\
	/* DOLATER.. take this out... */												\
	/*baseP->csAGroupMask = mask;	*/												\
	}

#ifndef	BUILD_OPTION_WP_OFF
#define	hwrWriteProtectOn()														\
	{																						\
	HwrDBallPtr baseP = (HwrDBallPtr)hwr68328Base;							\
	/* Word			mask; */															\
																							\
	/* DOLATER.. take this out....	*/											\
	/* mask = baseP->csAGroupMask;	*/											\
																							\
	/* Set read-only bit in chip select register for storage area */	\
	baseP->csASelect1 |= (0x0008);												\
	baseP->csASelect3 |= (0x0008);												\
																							\
	/* DOLATER.. take this out... */												\
	/*baseP->csAGroupMask = mask;	*/												\
	}
#else
#define	hwrWriteProtectOn()	
#endif


/************************************************************************
 *Initial values for the PLL. We set the system clock to be VCO/2 so
 *  the system clock speed becomes:
 *
 *  32768 * ((hwrTD1FreqSelP + 1) * 14 + hwrTD1FreqSelQ + 1)
 *   --------------------------------------------------------
 *                            2
 ************************************************************************/
// NEW ASIC versions run at 16.580608 Mhz
#define	hwrTD1PLLControl			(hwr328PLLControlClkEn | 			\
											 hwr328PLLControlSysVCODiv1 | 	\
											 hwr328PLLControlPixVCODiv1)
#define	hwrTD1FreqSelQ				0x01
#define	hwrTD1FreqSelP				0x23
#define	hwrTD1Frequency			(32768*((hwrTD1FreqSelP+1)*14+hwrTD1FreqSelQ+1)/1)


 
#endif 	//__HARDWARETD1_H__

#endif 	// NON_PORTABLE
