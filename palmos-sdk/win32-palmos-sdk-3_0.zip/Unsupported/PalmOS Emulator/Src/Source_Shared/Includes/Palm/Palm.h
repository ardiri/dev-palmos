/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=mac68k
#endif

#if defined (_MSC_VER) 
#pragma pack (push, 2)
#endif

#define ControlPtr	Palm_ControlPtr
#define ListPtr		Palm_ListPtr

// From Pilot.h

	// From SysAll.h

		#include <Common.h>
		#include <SysTraps.h>
		#include <SystemMgr.h>
		//#include <DebugMgr.h>
		#include <ErrorMgr.h>
		//#include <StringMgr.h>
		//#include <SysUtils.h>
		#include <MemoryMgr.h>
		#include <DataMgr.h>
		//#include <FeatureMgr.h>

		//#include <Preferences.h>	// All we need from this file:
									// !!! TBD: use real Preferences.h
			typedef enum 
				{
				prefVersion,
				prefCountry,
				prefDateFormat,
				prefLongDateFormat,
				prefWeekStartDay,
				prefTimeFormat,
				prefNumberFormat,
				prefAutoOffDuration
			} SystemPreferencesChoice;

#ifdef __cplusplus
extern "C" {
#endif
			extern DmOpenRef PrefOpenPreferenceDBV10 (void)
					SYS_TRAP(sysTrapPrefOpenPreferenceDBV10);
			extern DmOpenRef PrefOpenPreferenceDB (Boolean saved)
					SYS_TRAP(sysTrapPrefOpenPreferenceDB);
			extern void PrefSetPreference(SystemPreferencesChoice choice, DWord value)
					SYS_TRAP(sysTrapPrefSetPreference);
#ifdef __cplusplus 
}
#endif

		//#include <Localize.h>
		//#include <TimeMgr.h>
		//#include <AlarmMgr.h>
		//#include <SoundMgr.h>
		//#include <Keyboard.h>
		//#include <GraffitiReference.h>
		//#include <AppLaunchCmd.h>


	// From UIAll.h

		//#include <UICommon.h>	// !!! TBD: Use real UICommon.h

			#define strRsc 					'tSTR'
			#define ainRsc 					'tAIN'
			#define iconType				'tAIB'
			#define bitmapRsc 				'Tbmp'
			#define alertRscType   			'Talt'
			#define kbdRscType				'tkbd'
			#define MenuRscType				'MBAR'
			#define fontRscType				'NFNT'
			#define verRsc					'tver'
			#define appInfoStringsRsc		'tAIS'
			#define appVersionID			1		// our apps use tver 1 resource
			#define appVersionAlternateID	1000	// CW Constructor uses tver 1000 resource
													// so we'll look for ours first, then try theirs
			#define ainID					1000

		//#include <Init.h>
		#include <Rect.h>
		#include <Font.h>
		//#include <FontSelect.h>
		#include <Window.h>
		#include <Chars.h>
		//#include <InsPoint.h>
		//#include <GraffitiShift.h>
		#include <Event.h>
		//#include <ClipBoard.h>
		#include <Control.h>
		#include <Field.h>
		#include <List.h>
		#include <ScrollBar.h>
		#include <Table.h>
		#include <Form.h>
		//#include <Menu.h>
		//#include <Category.h>
		//#include <Find.h>
		//#include <SelDay.h>
		//#include <SelTime.h>
		//#include <AboutBox.h>
		//#include <PhoneLookup.h>

	#define	NON_PORTABLE
	#include <Globals.h>
	//#include <UIGlobals.h>
	#undef NON_PORTABLE


// Additional bits we need

#include "KeyMgr.h"			// keyBitHard1
#include "PenMgr.h"			// PenScreenToRaw
#include "SysEvtMgr.h"		// EvtEnqueuePenPoint, EvtEnqueueKey
#include "SystemPkt.h"		// SysPktBodyType, etc.
							// (Be sure to include _before_ DebugPrv.h so that
							//  _sysPktBodyCommon is defined.)
#include "SerialLinkMgr.h"	// SlkPktHeaderType, slkSocketDebugger, etc.

#include "M68681Hwr.h"		// HwrDuartType

#define NON_PORTABLE
#include "DebugPrv.h"		// BreakpointType
#include "KeyPrv.h"			// KeyHandleInterrupt
#include "DataPrv.h"		// DatabaseHdrPtr, etc.
#include "SysEvtPrv.h"		// SysEvtMgrGlobalsPtr
#include "Hardware.h"		// hwrDisplayWidth, hwrSystemTop, hwrSystemHeight
#include "MemoryPrvNew.h"	// MemNVParams
#undef NON_PORTABLE


#if defined(_WINDOWS)		// Needed for Gremlins
struct Point
{
	short	h;
	short	v;
};
typedef Point*	PointPtr;
#endif



#if defined (_MSC_VER) 
#pragma pack (pop)
#endif

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=reset
#endif

#undef ControlPtr
#undef ListPtr

