 /**********************************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------*/
#ifndef __SYSTEMMGR_H__
#define __SYSTEMMGR_H__

#include "Common.h"
#include "SysTraps.h"

#define	sysAppLaunchCmdNormalLaunch			0	// Normal Launch

/************************************************************
 * Error Classes for each manager
 *************************************************************/
#define	memErrorClass				0x0100	// Memory Manager
#define	dmErrorClass				0x0200	// Data Manager
#define	serErrorClass				0x0300	// Serial Manager
#define	slkErrorClass				0x0400	// Serial Link Manager
#define	sysErrorClass				0x0500	// System Manager
#define	fplErrorClass				0x0600	// Floating Point Library
#define	flpErrorClass				0x0680	// New Floating Point Library
#define	evtErrorClass				0x0700  	// System Event Manager
#define	sndErrorClass				0x0800  	// Sound Manager
#define	almErrorClass				0x0900  	// Alarm Manager
#define	timErrorClass				0x0A00  	// Time Manager
#define	penErrorClass				0x0B00  	// Pen Manager
#define	ftrErrorClass				0x0C00  	// Feature Manager
#define	cmpErrorClass				0x0D00  	// Connection Manager
#define	dlkErrorClass				0x0E00	// Desktop Link Manager
#define	padErrorClass				0x0F00	// PAD Manager
#define	grfErrorClass				0x1000	// Graffiti Manager
#define	mdmErrorClass				0x1100	// Modem Manager
#define	netErrorClass				0x1200	// Net Library
#define	htalErrorClass				0x1300	// HTAL Library
#define	inetErrorClass				0x1400	// INet Library
#define	exgErrorClass				0x1500	// Exg Manager
#define	fileErrorClass				0x1600	// File Stream Manager
#define	rfutErrorClass				0x1700	// RFUT Library
#define	webErrorClass				0x1800	// Web Library
#define	encrErrorClass				0x1900	// Encrypt Library

#define	appErrorClass				0x8000	// Application-defined errors

/************************************************************
 * System Errors
 *************************************************************/
#define	sysErrTimeout				(sysErrorClass | 1)
#define	sysErrParamErr				(sysErrorClass | 2)
#define	sysErrNoFreeResource		(sysErrorClass | 3)
#define	sysErrNoFreeRAM			(sysErrorClass | 4)
#define	sysErrNotAllowed			(sysErrorClass | 5)
#define	sysErrSemInUse				(sysErrorClass | 6)
#define	sysErrInvalidID			(sysErrorClass | 7)
#define	sysErrOutOfOwnerIDs		(sysErrorClass | 8)
#define	sysErrNoFreeLibSlots		(sysErrorClass | 9)
#define	sysErrLibNotFound			(sysErrorClass | 10)
#define	sysErrDelayWakened		(sysErrorClass | 11)		// SysTaskDelay wakened by SysTaskWake before delay completed.
#define	sysErrRomIncompatible	(sysErrorClass | 12)
#define	sysErrBufTooSmall			(sysErrorClass | 13)
#define	sysErrPrefNotFound		(sysErrorClass | 14)



UInt 		SysSetAutoOffTime(UInt	seconds)
							SYS_TRAP(sysTrapSysSetAutoOffTime);

Err 		SysUIAppSwitch(UInt cardNo, LocalID dbID, Word cmd, Ptr cmdPBP)
					SYS_TRAP(sysTrapSysUIAppSwitch);

Err 		SysCurAppDatabase(UIntPtr cardNoP, LocalID* dbIDP)
					SYS_TRAP(sysTrapSysCurAppDatabase);

#endif  //__SYSTEMMGR_H__