 /************************************************************************************
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------*/
#ifndef __MEMORYPRVNEW__
#define __MEMORYPRVNEW__

#pragma once

// Bits and pieces of the real SystemPrv.h

/************************************************************
 * This structure defines a section within the RAM storage header
 *  on Card#0 used to hold non-volatile System information. We store
 *  System information that can not be conveniently stored or accessed
 *  from a Database in this area because:
 *	1.) it can be accessed earlier during the boot-up process and 
 * 2.) It can be accessed from an interrupt routine.
 *************************************************************/ 
typedef struct SysNVParamsType {
	DWord		rtcHours;									// Real-Time clock hours - add to value
																// in DragonBall RTC register to get
																// actual date & time.
	DWord		rtcHourMinSecCopy;						// Copy of latest value in rtcHourMinSec reg of 
																// DBall. Used as default RTC value on Reset.
	} SysNVParamsType;
typedef SysNVParamsType*	SysNVParamsPtr;


// Bits and pieces of the real MemoryPrvNew.h

/************************************************************
 * Structure of a Card Header.
 * There is 1 card header for in every card that has ROM. The
 *  card header is stored at sysCardHeaderOffset into the card.
 *
 * RAM only cards will not have a card header
 *************************************************************/
#define	memMaxNameLen				32		// size of name and manuf fields including null
typedef struct CardHeaderType {
	DWord			initStack;					// initial stack pointer
	DWord			resetVector;				// reset vector
	DWord			signature;					// must be sysCardSignature
	Word			hdrVersion;					// header version
	Word			flags;						// card flags;
	Byte			name[memMaxNameLen];		// card name
	Byte			manuf[memMaxNameLen];	// card manufacturer's name
	Word			version;						// card version
	DWord			creationDate;				// card creation date
	Word			numRAMBlocks;				// number of RAM blocks on card
	DWord			blockListOffset;			// offset to RAM block list
	DWord			readWriteParmsOffset;	// v2: offset to read/write system data if any (in ROM)
	DWord			readWriteParmsSize;		// v2: size of read/write system data if any (in ROM)
	DWord			readOnlyParmsOffset;		// v2: offset to read-only system data (in ROM)
	DWord			bigROMOffset;				// v2: in SmallROM header: where SmallROM expects bigROM to live
													//			in BigROM header: where BigROM expects itself to live
	DWord			checksumBytes;				// v2: size of card image in bytes (for checksum)
	Word			checksumValue;				// v2: checksum of card image (from Crc16CalcBlock)
	Byte			reserved[142];				// to bring us to 0x100 alignment
	} CardHeaderType;
typedef CardHeaderType*		CardHeaderPtr;

#define	memCardHeaderFlagRAMOnly	0x0001	// RAM only card


/********************************************************************
 * CardInfo structure
 * The Pilot globals has a pointer to an array of CardInfo structures.
 *
 * This array is initialized by the Boot code before the Memory Manager
 *  starts up. Among other things, it tells the Memory Manager where 
 *  every card is and the size of each card.
 ********************************************************************/
typedef struct {

	// These fields are filled in by the boot code BEFORE
	//  MemInit() is called.
	BytePtr		baseP;						// base address of card
	DWord			size;							// address range of card
	DWord			firstRAMBlockSize;		// size of RAM block at offset 0
	DWord			targetROMShift;			// used only under Emulation mode, must be
													//  added to emulated ROM pointers when calculating
													//  a LocalID for use in the device ROM.

	
	DWord			cardHeaderOffset;			// offset to card header (usually in ROM)
													//  = 0 if RAM only card
												
	DWord			rsvSpace;					// reserve space in RAM before first heap
	DWord			dynHeapSpace;				// how much space to reserve for dynamic heap(s)
	void*		ramStoreP;		// pointer to RAM store header 
													// This location depends on how much space
													//  was reserved on the card for the dynamic
													//  heap.
												
	// These fields are copies of information in the card and storage headers
	//  they are cached here for quicker access by the Memory Manager. They
	//  are filled in by the Memory Manager during MemInit.
	Word			numRAMHeaps;				// Number of RAM heaps - for quick access
	DWordPtr		ramHeapOffsetsP;			// Table of RAM heap offsets - for quick access
	Word			numROMHeaps;				// Number of RAM heaps - for quick access
	DWordPtr		romHeapOffsetsP;			// Table of RAM heap offsets - for quick access

	} CardInfoType;
typedef CardInfoType*	CardInfoPtr;


#ifdef __cplusplus
extern "C" {
#endif

Err				MemNVParams(Boolean set, SysNVParamsPtr paramsP)
							SYS_TRAP(sysTrapMemNVParams);

#ifdef __cplusplus 
}
#endif

#endif	// __MEMORYPRVNEW__
