/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *-------------------------------------------------------------------
 *
 * PROJECT:  Pilot
 * FILE:     font.h
 * AUTHOR:	 Art Lamb: September 13, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file defines font structures and routines.
 *
 ***********************************************************************/
 
#ifndef __FONT_H__
#define __FONT_H__


typedef struct {
	SByte		offset;
	SByte		width;
} FontCharInfoType;

typedef struct {
	SWord fontType; 			// font type
	SWord firstChar; 			// ASCII code of first character
	SWord lastChar; 			// ASCII code of last character
	SWord maxWidth; 			// maximum character width
	SWord kernMax; 			// negative of maximum character kern
	SWord nDescent; 			// negative of descent
	SWord fRectWidth; 		// width of font rectangle
	SWord fRectHeight; 		// height of font rectangle
	SWord owTLoc; 				// offset to offset/width table
	SWord ascent; 				// ascent
	SWord descent; 			// descent
	SWord leading; 			// leading
	SWord rowWords; 			// row width of bit image / 2
} FontType;

typedef FontType * FontPtr;

typedef FontPtr * FontTablePtr;

enum fontID { 
	stdFont = 0x00,					// Small font used for the user's writing.  Shows a good amount
	boldFont, 							// Small font.  Bold for easier reading.  Used often for ui.
	largeFont,							// Larger font for easier reading.  Shows a lot less.
	symbolFont,							// Various ui images like check boxes and arrows
	symbol11Font, 						// Larger various ui images
	symbol7Font,						// Smaller various ui images
	ledFont,								// Calculator specific font
//	narrowFont,							// An extra narrow font for space purposes
//	narrowBoldFont,					// A bold compliment
	largeBoldFont,						// A thicker version of the large font.  More readable.
	fntAppFontCustomBase = 0x80	// First available application-defined font ID
};

typedef enum fontID FontID;

#define checkboxFont symbol11Font

#define FntIsAppDefined(fnt) (fnt >= fntAppFontCustomBase)



//--------------------------------------------------------------------
//
// Font Function
//
//--------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

extern FontID FntGetFont (void)
							SYS_TRAP(sysTrapFntGetFont);

extern FontID FntSetFont (const FontID font)
							SYS_TRAP(sysTrapFntSetFont);

extern FontPtr FntGetFontPtr (void)
							SYS_TRAP(sysTrapFntGetFontPtr);

extern SWord FntBaseLine (void)
							SYS_TRAP(sysTrapFntBaseLine);

extern SWord FntCharHeight (void)
							SYS_TRAP(sysTrapFntCharHeight);

extern SWord FntLineHeight (void)
							SYS_TRAP(sysTrapFntLineHeight);

extern SWord FntAverageCharWidth (void)
							SYS_TRAP(sysTrapFntAverageCharWidth);

extern SWord FntCharWidth (const Char ch)
							SYS_TRAP(sysTrapFntCharWidth);

extern SWord FntCharsWidth (const Char * chars, Word len)
							SYS_TRAP(sysTrapFntCharsWidth);

extern void	FntCharsInWidth(const Char * string, 
	SWord *stringWidthP, SWord *stringLengthP, 
	Boolean *fitWithinWidth)
							SYS_TRAP(sysTrapFntCharsInWidth);

extern SWord FntDescenderHeight (void)
							SYS_TRAP(sysTrapFntDescenderHeight);

extern SWord FntLineWidth (const Char * pChars, Word length)
							SYS_TRAP(sysTrapFntLineWidth);

Word FntWordWrap (const Char * const chars, const Word maxWidth)
							SYS_TRAP(sysTrapFntWordWrap);

void FntWordWrapReverseNLines (const Char * const chars, 
	const Word maxWidth, const WordPtr linesToScrollP, 
	const WordPtr scrollPosP)
							SYS_TRAP(sysTrapFntWordWrapReverseNLines);

void FntGetScrollValues (const Char * const chars, const Word width, 
	const Word scrollPos, const WordPtr linesP, 
	const WordPtr topLine)
							SYS_TRAP(sysTrapFntGetScrollValues);

extern Err FntDefineFont (FontID font, FontPtr fontP)
							SYS_TRAP(sysTrapFntDefineFont);

#ifdef __cplusplus
}
#endif


#endif // __FONT_H__



