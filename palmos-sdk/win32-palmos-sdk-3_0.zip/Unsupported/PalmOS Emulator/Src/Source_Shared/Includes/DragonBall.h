#pragma once

#define NON_PORTABLE
#include "M68328Hwr.h"		// HwrDBallType, masks
#include "HardwareTD1.h"	// hwrTD1PortFPanelMask, etc.
#include "HardwarePrv.h"	// hwr68328Base
#undef NON_PORTABLE

