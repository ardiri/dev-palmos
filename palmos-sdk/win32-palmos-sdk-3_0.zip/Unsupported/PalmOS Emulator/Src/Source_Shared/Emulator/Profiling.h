/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/
#pragma once

#if defined(__MWERKS__)
#include <Math64.h>
#endif

#if defined(_MSC_VER)
typedef unsigned __int64 UInt64;

#define U64Max() ((UInt64) ~0)
#define U64Add(x, y) ((x) + (y))
#define U64Subtract(x, y) ((x) - (y))
#define U64Multiply(x, y) ((x) * (y))
#define U64Div(x, y) ((x) / (y))
#define U64Mod(x, y) ((x) % (y))
#define U64Set(x) ((UInt64) (x))
#define U64SetU(x) ((UInt64) (x))
//#define U32SetU(x) ((UInt32) (x))
#define U64Compare(x, y) ((int)((x) - (y)))
#define U64And(x, y) (((x) && (y)))
#define U64Or(x, y) (((x) || (y)))
#define U64Eor(x, y) (((x) ^ (y)))
#define U64Not(x) ((!(x)))
#define U64BitwiseAnd(x, y) ((x) & (y))
#define U64BitwiseOr(x, y) ((x) | (y))
#define U64BitwiseEor(x, y) (((x) & (~(y))) | ((~(x)) & (y)))
#define U64BitwiseNot(x) (~(x))
#define U64ShiftRight(x, y) ((x) >> (y))
#define U64ShiftLeft(x, y) ((x) << (y))
//#define UInt64ToLongDouble(x) ((long double)(x))
//#define LongDoubleToUInt64(x) ((UInt64)(x))
//#define UInt64ToSInt64(x) ((SInt64)(x))
//#define SInt64ToUInt64(x) ((UInt64)(x))
#endif

// #include "UAE.h"
#include "sysconfig.h"		// (should really be included by sysdeps.h ...)
#include "sysdeps.h"
#include "memory_cpu.h"

#define HAS_PROFILING_DEBUG		0	// turn on code to help debug profiler

#define WAITSTATES_ROM			2
#define WAITSTATES_SRAM			4	// according to Wayne Harrington
#define WAITSTATES_DRAM			4	// according to Wayne Harrington
#define WAITSTATES_REGISTERS	2
#define WAITSTATES_DUMMYBANK	2

// ��� normally passed in to ProfileInit, but here for CEmulatorApp.cpp
#define MAXFNCALLS	20000
#define MAXUNIQUEFNS 2500
#define MAXDEPTH 	200

#define PROFILE_ONE_FN			0	// set to 1 to profile on a particular fn enter/exit
#define FNTOPROFILE (0x0000a078)

// 	0x0000a078  sysTrapDmGetNextDatabaseByTypeCreator
//	PrvCompressedInnerBitBlt           $10c47ac4
//	0x0000a045  sysTrapDmFindDatabase
//	0x0000a171	sysTrapFrmDrawForm
// 	0x0000a08e  sysTrapSysAppLaunch
// 	0x0000a08f  sysTrapSysAppStartup


#define kCyclesPerSecond 16580608	// 16Mhz, more or less
#define kCyclesPerMilliSecond 16580

extern UInt64 gClockCycles;
extern UInt64 gReadCycles;
extern UInt64 gWriteCycles;

extern bool gProfilingEnabled;
extern bool gProfilingOn;
extern bool gProfilingCounted;

static __inline__ void ProfileIncrementClock(unsigned long by)
{
	gClockCycles = U64Add(gClockCycles, U64SetU(by));
}

static __inline__ void ProfileIncrementRead(int reads, int waitstates)
{
	gClockCycles = U64Add(gClockCycles, U64Set(reads * (4+waitstates)));
	gReadCycles = U64Add(gReadCycles, U64Set(reads));
}

static __inline__ void ProfileIncrementWrite(int writes, int waitstates)
{
	gClockCycles = U64Add(gClockCycles, U64Set(writes * (4+waitstates)));
	gWriteCycles = U64Add(gWriteCycles, U64Set(writes));
}


extern void ProfileInit(int maxCalls, int maxDepth);
extern void ProfileStart();
extern void ProfileStop();
extern void ProfileDump();
extern void ProfilePrint();
extern void ProfileCleanup();

extern void ProfileFnEnter(uaecptr address, uaecptr returnAddress);
extern void ProfileFnExit(uaecptr returnAddress);

extern void ProfileInterruptEnter(uae_s32 iException, uaecptr returnAddress);
extern void ProfileInterruptExit(uaecptr returnAddress);



// debugging stuff

extern long gReadMismatch;
extern long gWriteMismatch;

extern void ProfileTest();