/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "RAM_ROM.h"
#include "CPU_REG.h"
#include "ATraps.h"
#include "ROMStubs.h"
#include "StringData.h"
#include "TrapPatches.h"
#include "DebugMgr.h"			// Debug::Initialize
#include "Byteswapping.h"		// ByteswapWords
#include "EmuTraps.h"
#include "UAE_Utils.h"			// uae_strlen, uae_strcpy

#if HAS_PROFILING
#include "Profiling.h"
#endif

#include "Gremlins.h"			// Gremlins_Initialize, Gremlins_IsOn

#include "Platform.h"

#include "Palm.h"

#include <stddef.h>				// offsetof

#if __profile__
#include <Profiler.h>
#endif


// Types

#pragma mark Types


// Definitions of the stack frames used in Software::ProcessException.

/*
	Exception stack frame:

			15                       0
	sp ->	+------------------------+ <-+						 Higher Address
			| Function Code          |   |								|
			+------------------------+   |								|
			| Access Address (High)  |   | Only for Address and			|
			+------------------------+   | Bus errors.					|
			| Access Address (Low)   |   |								|
			+------------------------+   |								|
			| Instruction Register   |   |								|
			+------------------------+ <-+								|
			| Status Register        |									|
			+------------------------+									|
			| Program Counter (High) |									|
			+------------------------+									|
			| Program Counter (Low)  |									|
			+------------------------+									v

	Function code:
		Bits		Function
		0-2			Function Code
		3			I/N = Instruction = 0, Not = 1
		4			R/W = Write = 0, Read = 1
*/

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=mac68k
#endif

#if defined (_MSC_VER) 
#pragma pack (push, 2)
#endif

struct ExceptionStackFrame1
{
	uae_u16	statusRegister;
	uae_u32	programCounter;
};

struct ExceptionStackFrame2
{
	uae_u16	functionCode;
	uae_u32	accessAddress;
	uae_u16	instructionRegister;
	uae_u16	statusRegister;
	uae_u32	programCounter;
};

#if defined (_MSC_VER) 
#pragma pack (pop)
#endif

#if PRAGMA_ALIGN_SUPPORTED
#pragma options align=reset
#endif


// Globals.

#pragma mark Globals

uae_u32			gBreakReason;
uae_u32			gBreakReasonMask;
long			gCPULevel;

uae_u8*			gCurrentInstructionStart;
bool			gBreakOnException[kException_LastException];

bool			gPen_IsDown;
uae_s32			gPen_HorzLocation;
uae_s32			gPen_VertLocation;
bool			Hardware::fgHotSyncButtonDown;

void*			gScreenCopy;	// Points to a copy of the Palm device's LCD buffer.
uae_u32			gScreenChange;

ExceptionHandlerProc	gExceptionHandlers[kException_LastException];

TByteQueue		gKeyQueue;

uae_u16			gSysDispatchTableSize;

uae_u16			gNextOpcode;
bool			gNextOpcodeValid;

int areg_byteinc[] = { 1,1,1,1,1,1,1,2 };	// (normally in newcpu.c)
int imm8_table[] = { 8,1,2,3,4,5,6,7 };		// (normally in newcpu.c)

int movem_index1[256];						// (normally in newcpu.c)
int movem_index2[256];						// (normally in newcpu.c)
int movem_next[256];						// (normally in newcpu.c)

int fpp_movem_index1[256];					// (normally in newcpu.c)
int fpp_movem_index2[256];					// (normally in newcpu.c)
int fpp_movem_next[256];					// (normally in newcpu.c)

cpuop_func *cpufunctbl[65536];				// (normally in newcpu.c)

#if HAS_PROFILING
perfRec perftbl[65536];
#endif
											// (normally in newcpu.c)
uae_u16 last_op_for_exception_3;			/* Opcode of faulting instruction */
uaecptr last_addr_for_exception_3;			/* PC at fault time */
uaecptr last_fault_for_exception_3;			/* Address that generated the exception */

struct regstruct regs;						// (normally in newcpu.c)
struct flag_struct regflags;				// (normally in support.c)


#if REGISTER_HISTORY

	#define reg_history_size	512
	long	reg_history_index;
	struct regstruct	reg_history[reg_history_size];

#endif

#if EXCEPTION_HISTORY

	struct exception_history_rec
	{
		const char*		name;
		uae_u32			pc;
		uae_u32			sp;
	};
	
	#define exception_history_size	512
	long	exception_history_index;
	exception_history_rec	exception_history[exception_history_size];

#endif


#if TIME_STARTUP
	uae_u32	gStart;
#endif


#if COUNT_INSTRUCTIONS
	long	gInstructionCount;
	long	gSpecial;
#endif


#if COUNT_TRAPS
	long*	gTrapCounts;
	long	gTotalTrapCount;
#endif


// Values used to initialize the DragonBall registers.

const HwrDBallType	kInitial68328RegisterValues =
{
	0x0C,		//	Byte		scr;						// $000: System Control Register
	{ 0 },		//	Byte										___filler1[0xFF];

	0x0000,		//	Word		csAGroupBase;				// $100: Chip Select Group A Base Register
	0x0000,		//	Word		csBGroupBase;				// $102: Chip Select Group B Base Register
	0x0000,		//	Word		csCGroupBase;				// $104: Chip Select Group C Base Register
	0x0000,		//	Word		csDGroupBase;				// $106: Chip Select Group D Base Register

	0x0000,		//	Word		csAGroupMask;				// $108: Chip Select Group A Mask Register
	0x0000,		//	Word		csBGroupMask;				// $10A: Chip Select Group B Mask Register
	0x0000,		//	Word		csCGroupMask;				// $10C: Chip Select Group C Mask Register
	0x0000,		//	Word		csDGroupMask;				// $10E: Chip Select Group D Mask Register

	0x00010006,	//	DWord		csASelect0;					// $110: Group A Chip Select 0 Register
	0x00010006,	//	DWord		csASelect1;					// $114: Group A Chip Select 1 Register
	0x00010006,	//	DWord		csASelect2;					// $118: Group A Chip Select 2 Register
	0x00010006,	//	DWord		csASelect3;					// $11C: Group A Chip Select 3 Register

	0x00000000,	//	DWord		csBSelect0;					// $120: Group B Chip Select 0 Register
	0x00000000,	//	DWord		csBSelect1;					// $124: Group B Chip Select 1 Register
	0x00000000,	//	DWord		csBSelect2;					// $128: Group B Chip Select 2 Register
	0x00000000,	//	DWord		csBSelect3;					// $12C: Group B Chip Select 3 Register

	0x00010006,	//	DWord		csCSelect0;					// $130: Group C Chip Select 0 Register
	0x00010006,	//	DWord		csCSelect1;					// $134: Group C Chip Select 1 Register
	0x00010006,	//	DWord		csCSelect2;					// $138: Group C Chip Select 2 Register
	0x00010006,	//	DWord		csCSelect3;					// $13C: Group C Chip Select 3 Register

	0x00000000,	//	DWord		csDSelect0;					// $140: Group D Chip Select 0 Register
	0x00000000,	//	DWord		csDSelect1;					// $144: Group D Chip Select 1 Register
	0x00000000,	//	DWord		csDSelect2;					// $148: Group D Chip Select 2 Register
	0x00000000,	//	DWord		csDSelect3;					// $14C: Group D Chip Select 3 Register

	0x0000,		//	Word		csDebug;					// $150: Chip Select debug register
	{ 0 },		//	Byte										___filler2[0x200-0x152];

	0x2400,		//	Word		pllControl;					// $200: PLL Control Register
	0x0123,		//	Word		pllFreqSel;					// $202: PLL Frequency Select Register
	0x0000,		//	Word		pllTest;					// $204: PLL Test Register
	{ 0 },		//	Byte										__filler44;
	0x1F,		//	Byte		pwrControl;					// $207: Power Control Register

	{ 0 },		//	Byte										___filler3[0x300-0x208];

	0x00,		//	Byte		intVector;					// $300: Interrupt Vector Register
	{ 0 },		//	Byte										___filler4;
	0x0000,		//	Word		intControl;					// $302: Interrupt Control Register
	0x00FF,		//	Word		intMaskHi;					// $304: Interrupt Mask Register/HIGH word
	0xFFFF,		//	Word		intMaskLo;					// $306: Interrupt Mask Register/LOW word
	0x00FF,		//	Word		intWakeupEnHi;				// $308: Interrupt Wakeup Enable Register
	0xFFFF,		//	Word		intWakeupEnLo;				// $30A: Interrupt Wakeup Enable Register
	0x0000,		//	Word		intStatusHi;				// $30C: Interrupt Status Register/HIGH word
	0x0000,		//	Word		intStatusLo;				// $30E: Interrupt Status Register/LOW word
	0x0000,		//	Word		intPendingHi;				// $310: Interrupt Pending Register
	0x0000,		//	Word		intPendingLo;				// $312: Interrupt Pending Register

	{ 0 },		//	Byte 										___filler4a[0x400-0x314];

	0x00,		//	Byte		portADir;					// $400: Port A Direction Register
	0x00,		//	Byte		portAData;					// $401: Port A Data Register
	{ 0 },		//	Byte										___filler5;
	0x00,		//	Byte		portASelect;				// $403: Port A Select Register

	{ 0 },		//	Byte										___filler6[4];

	0x00,		//	Byte		portBDir;					// $408: Port B Direction Register
	0x00,		//	Byte		portBData;					// $409: Port B Data Register
	{ 0 },		//	Byte										___filler7;
	0x00,		//	Byte		portBSelect;				// $40B: Port B Select Register

	{ 0 },		//	Byte										___filler8[4];

	0x00,		//	Byte		portCDir;					// $410: Port C Direction Register
	0x00,		//	Byte		portCData;					// $411: Port C Data Register
	{ 0 },		//	Byte										___filler9;
	0x00,		//	Byte		portCSelect;				// $413: Port C Select Register

	{ 0 },		//	Byte										___filler10[4];

	0x00,		//	Byte		portDDir;					// $418: Port D Direction Register
	0x00,		//	Byte		portDData;					// $419: Port D Data Register
	0xFF,		//	Byte		portDPullupEn;				// $41A: Port D Pull-up Enable
	{ 0 },		//	Byte										___filler11;
	0x00,		//	Byte		portDPolarity;				// $41C: Port D Polarity Register
	0x00,		//	Byte		portDIntReqEn;				// $41D: Port D Interrupt Request Enable
	{ 0 },		//	Byte										___filler12;
	0x00,		//	Byte		portDIntEdge;				// $41F: Port D IRQ Edge Register

	0x00,		//	Byte		portEDir;					// $420: Port E Direction Register
	0x00,		//	Byte		portEData;					// $421: Port E Data Register
	0x80,		//	Byte		portEPullupEn;				// $422: Port E Pull-up Enable
	0x80,		//	Byte		portESelect;				// $423: Port E Select Register

	{ 0 },		//	Byte										___filler14[4];

	0x00,		//	Byte		portFDir;					// $428: Port F Direction Register
	0x00,		//	Byte		portFData;					// $429: Port F Data Register
	0xFF,		//	Byte		portFPullupEn;				// $42A: Port F Pull-up Enable
	0xFF,		//	Byte		portFSelect;				// $42B: Port F Select Register

	{ 0 },		//	Byte										___filler16[4];

	0x00,		//	Byte		portGDir;					// $430: Port G Direction Register
	0x00,		//	Byte		portGData;					// $431: Port G Data Register
	0xFF,		//	Byte		portGPullupEn;				// $432: Port G Pull-up Enable
	0xFF,		//	Byte		portGSelect;				// $433: Port G Select Register

	{ 0 },		//	Byte										___filler18[4];

	0x00,		//	Byte		portJDir;					// $438: Port J Direction Register
	0x00,		//	Byte		portJData;					// $439: Port J Data Register
	{ 0 },		//	Byte										___filler19;
	0x00,		//	Byte		portJSelect;				// $43B: Port J Select Register

	{ 0 },		//	Byte										___filler19a[4];

	0x00,		//	Byte		portKDir;					// $440: Port K Direction Register
	0x00,		//	Byte		portKData;					// $441: Port K Data Register
	0xFF,		//	Byte		portKPullupEn;				// $442: Port K Pull-up Enable
	0xFF,		//	Byte		portKSelect;				// $443: Port K Select Register

	{ 0 },		//	Byte										___filler21[4];

	0x00,		//	Byte		portMDir;					// $448: Port M Direction Register
	0x00,		//	Byte		portMData;					// $449: Port M Data Register
	0xFF,		//	Byte		portMPullupEn;				// $44A: Port M Pull-up Enable Register
	0xFF,		//	Byte		portMSelect;				// $44B: Port M Select Register

	{ 0 },		//	Byte										___filler22[4];

	{ 0 },		//	Byte										___filler23[0x500-0x450];

	0x0000,		//	Word		pwmControl;					// $500: PWM Control Register
	0x0000,		//	Word		pwmPeriod;					// $502: PWM Period Register
	0x0000,		//	Word		pwmWidth;					// $504: PWM Width Register
	0x0000,		//	Word		pwmCounter;					// $506: PWM Counter

	{ 0 },		//	Byte										___filler24[0x600-0x508];

	0x0000,		//	Word		tmr1Control;				// $600: Timer 1 Control Register
	0x0000,		//	Word		tmr1Prescaler;				// $602: Timer 1 Prescaler Register
	0xFFFF,		//	Word		tmr1Compare;				// $604: Timer 1 Compare Register
	0x0000,		//	Word		tmr1Capture;				// $606: Timer 1 Capture Register
	0x0000,		//	Word		tmr1Counter;				// $608: Timer 1 Counter Register
	0x0000,		//	Word		tmr1Status;					// $60A: Timer 1 Status Register

	0x0000,		//	Word		tmr2Control;				// $60C: Timer 2 Control Register
	0x0000,		//	Word		tmr2Prescaler;				// $60E: Timer 2 Prescaler Register
	0xFFFF,		//	Word		tmr2Compare;				// $610: Timer 2 Compare Register
	0x0000,		//	Word		tmr2Capture;				// $612: Timer 2 Capture Register
	0x0000,		//	Word		tmr2Counter;				// $614: Timer 2 Counter Register
	0x0000,		//	Word		tmr2Status;					// $616: Timer 2 Status Register

	0x0000,		//	Word		wdControl;					// $618: Watchdog Control Register
	0x0000,		//	Word		wdReference;				// $61A: Watchdog Reference Register
	0x0000,		//	Word		wdCounter;					// $61C: Watchdog Counter

	{ 0 },		//	Byte										___filler25[0x700-0x61E];

	0x0000,		//	Word		spiSlave;					// $700: SPI Slave Register

	{ 0 },		//	Byte										___filler26[0x800-0x702];

	0x0000,		//	Word		spiMasterData;				// $800: SPI Master Data Register
	0x0000,		//	Word		spiMasterControl;			// $802: SPI Master Control Register

	{ 0 },		//	Byte										___filler27[0x900-0x804];

	0x0000,		//	Word		uControl;					// $900: Uart Control Register
	0x003F,		//	Word		uBaud;						// $902: Uart Baud Control Register
	0x0000,		//	Word		uReceive;					// $904: Uart Receive Register
	0x0000,		//	Word		uTransmit;					// $906: Uart Transmit Register
	0x0000,		//	Word		uMisc;						// $908: Uart Miscellaneous Register

	{ 0 },		//	Byte										___filler28[0xA00-0x90A];

	0x00000000,	//	DWord		lcdStartAddr;				// $A00: Screen Starting Address Register
	{ 0 },		//	Byte										___filler29;
	0xFF,		//	Byte		lcdPageWidth;				// $A05: Virtual Page Width Register
	{ 0 },		//	Byte										___filler30[2];
	0x03FF,		//	Word		lcdScreenWidth;				// $A08: Screen Width Register
	0x01FF,		//	Word		lcdScreenHeight;			// $A0A: Screen Height Register
	{ 0 },		//	Byte										___filler31[0xA18-0xA0C];
	0x0000,		//	Word		lcdCursorXPos;				// $A18: Cursor X Position
	0x0000,		//	Word		lcdCursorYPos;				// $A1A:	Cursor Y Position
	0x0101,		//	Word		lcdCursorWidthHeight;		// $A1C: Cursor Width and Height
	{ 0 },		//	Byte										___filler32;
	0x7F,		//	Byte		lcdBlinkControl;			// $A1F: Blink Control Register
	0x00,		//	Byte		lcdPanelControl;			// $A20: Panel Interface Control Register
	0x00,		//	Byte		lcdPolarity;				// $A21: Polarity Config Register
	0x00,		//	Byte										___filler33;
	0x00,		//	Byte		lcdACDRate;					// $A23: ACD (M) Rate Control Register
	0x00,		//	Byte										___filler34;
	0x00,		//	Byte		lcdPixelClock;				// $A25: Pixel Clock Divider Register
	0x00,		//	Byte										___filler35;
	0x40,		//	Byte		lcdClockControl;			// $A27: Clocking Control Register
	0x00,		//	Byte										___filler36;
	0x3E,		//	Byte		lcdLastBufferAddr;			// $A29: Last Buffer Address Register
	0x00,		//	Byte										___filler37;
	0x3F,		//	Byte		lcdOctetTermCount;			// $A2B: Octet Terminal Count Register
	0x00,		//	Byte										___filler38;
	0x00,		//	Byte		lcdPanningOffset;			// $A2D: Panning Offset Register
	{ 0 },		//	Byte										___filler39[3];
	0xB9,		//	Byte		lcdFrameRate;				// $A31: Frame Rate Control Modulation Register
	0x1073,		//	Word		lcdGrayPalette;				// $A32: Gray Palette Mapping Register
	0x00,		//	Byte		lcdReserved;				// $A34: Reserved

	{ 0 },		//	Byte										___filler40[0xB00-0xA35];

	0x00000000,	//	DWord		rtcHourMinSec;				// $B00: RTC Hours, Minutes, Seconds Register
	0x00000000,	//	DWord		rtcAlarm;					// $B04: RTC Alarm Register
	0x00000000,	//	DWord		rtcReserved;				// $B08: RTC Reserved
	0x0000,		//	Word		rtcControl;					// $B0C: RTC Control Register
	0x0000,		//	Word		rtcIntStatus;				// $B0E: RTC Interrupt Status Register
	0x0000,		//	Word		rtcIntEnable;				// $B10: RTC Interrupt Enable Register
	0x0000		//	Word		stopWatch;					// $B12: Stopwatch Minutes
};


#pragma mark -


// ---------------------------------------------------------------------------
//		� Emulator::Initialize
// ---------------------------------------------------------------------------
// Initializes the emulator hardware, software, and memory.  You must call
// Emulator::Initialize before calling Emulator::Execute.

void Emulator::Initialize (	FILE*	iMemoryFile,
							FILE*	iROMFile,
							uae_s32	iRAMSize)
{
	Memory::Initialize (iMemoryFile, iROMFile, iRAMSize);
	Hardware::Initialize ();
	Gremlins_Initialize ();
	Patches::Initialize ();
	Platform::Initialize ();
	Debug::Initialize ();

	Software::InstallExceptionHandler (kException_Trap0 + kATrapTailpatchTrapNum,
										Software::ProcessTrap13);
	Software::InstallExceptionHandler (kException_Trap0 + emuTrapNum,
										Software::ProcessTrap14);
	Software::InstallExceptionHandler (kException_Trap0 + sysDispatchTrapNum,
										Software::ProcessTrap15);

	Emulator::Reset ();
}


// ---------------------------------------------------------------------------
//		� Emulator::Reset
// ---------------------------------------------------------------------------
// Reset the emulator.  This effects a "warm restart" of the ROM.

void Emulator::Reset (void)
{
	gSysDispatchTableSize = 0;
	gNextOpcodeValid = false;

	Memory::Reset ();
	Hardware::Reset ();
	Gremlins_Reset ();
	Patches::Reset ();
	Platform::Reset ();
	Debug::Reset ();

	gCPULevel = 0;
	Emulator::ClearBreakReason (kBreak_All);
	Emulator::SetBreakReasonMask (kBreak_All);
}


// ---------------------------------------------------------------------------
//		� Emulator::Dispose
// ---------------------------------------------------------------------------
// Shuts down the emulator and cleans up.

void Emulator::Dispose (void)
{
	Platform::DisconnectFromDebugger ();
	Memory::Dispose ();
}


// ---------------------------------------------------------------------------
//		� Emulator::Execute
// ---------------------------------------------------------------------------
// Processes instructions until an event occurs.

/*
		Comments on interrupt handling:

		- SPCFLAG_INT is set at the end of MakeFromSR.  MakeFromSR is
		  called at the end of any opcode that changes it.

		- SPCFLAG_INT is also set at the end of Registers::UpdateInterrupts,
		  which is called when we want to emulate an interrupt occuring.

		- SPCFLAG_INT is set at the end of Software::ProcessInterrupt.
		  Software::ProcessInterrupt is called from the main CPU loop if
		  the requested interrupt is greater than the interrupt level.

		- In the main CPU loop, if SPCFLAG_INT or SPCFLAG_DOINT are set
		  clear them.  If the interrupt is greater than the interrupt
		  level, call Software::ProcessInterrupt, set regs.stopped to zero,
		  and clear the SPCFLAG_STOP flag.

		- Later in the main CPU loop if SPCFLAG_DOINT is set, clear it.
		  If the interrupt is greater than the interrupt level, call
		  Software::ProcessInterrupt and set regs.stopped to zero. Note
		  that SPCFLAG_STOP is NOT cleared (I don't know why).

		- After that, if SPCFLAG_INT is set, clear it and set SPCFLAG_DOINT.


		Comments on trace handling:

		- In MakeFromSR, if t0 or t1 are set, the SPCFLAG_TRACE is
		  set. Otherwise, SPCFLAG_TRACE and SPCFLAG_DOTRACE are cleared.
		  MakeFromSR is called at the end of any opcode that changes it.

		- In main CPU loop after an opcode has been executed, if
		  SPCFLAG_DOTRACE is set, call Software::ProcessException (kException_Trace)

		- At the end of Software::ProcessException(), SPCFLAG_TRACE and
		  SPCFLAG_DOTRACE are cleared.

		- Near end of main CPU loop, if SPCFLAG_TRACE is set, SPCFLAG_TRACE
		  is cleared and SPCFLAG_DOTRACE is set.
*/

long Emulator::Execute (void)
{
	// Make sure that we're entering this function with a clean slate.
	// Still allow kBreak_StopRequest, as it's possible that someone
	// started up the CPU thread and then immediately asked it to stop.

	assert ((gBreakReason & (gBreakReasonMask & ~kBreak_StopRequest)) == 0);

	// Declare this here (instead of where it's actually used), so that VC++ doesn't
	// give us any lip about jumping over it with our goto statement.

	uae_u32 opcode;

	gCPULevel++;

#if TIME_STARTUP
	static calledOnce;

	if (!calledOnce)
	{
		calledOnce = true;

		gStart = Platform::GetMilliseconds();

#if __profile__
		ProfilerSetStatus (true);
#endif
	}
#endif

	// Check for the stopped flag before entering the "execute an opcode"
	// section.  It could be that we last exited the loop while still in
	// stop mode, and we need to wind our way back down to that spot.

	if ((regs.spcflags & SPCFLAG_STOP) != 0)
		goto StoppedLoop;

	while ((gBreakReason & gBreakReasonMask) == 0)
	{
#if HAS_PROFILING_DEBUG
			// debugging
			UInt64 readCyclesSaved = 0;
			UInt64 writeCyclesSaved = 0;
			UInt64 clockCyclesSaved = 0;
#endif

#if REGISTER_HISTORY

		// Save the registers for the post-mortem

		++reg_history_index;
		reg_history[reg_history_index & (reg_history_size - 1)] = regs;
#endif

		// Save our position in case we have to restore it in
		// Software::HandleException.

#ifdef USE_POINTER
		gCurrentInstructionStart = regs.pc_p;
#else
		gCurrentInstructionStart = (uae_u8*)regs.pc;
#endif

		// Get the next instruction.  Sometimes the next opcode comes
		// from gNextOpcode (which holds the opcode in case its normal
		// location in memory is occupied by some breakpoint opcode),
		// but normally we'll fetch it with Registers::GetNextShortInstruction.

#if HAS_PROFILING
#if HAS_PROFILING_DEBUG
		// debugging
		if (gProfilingEnabled)
		{
			readCyclesSaved = gReadCycles;
			writeCyclesSaved = gWriteCycles;
			clockCyclesSaved = gClockCycles;
		}
#endif
		// turn it on here so the nextiword() fetch is counted!
		gProfilingCounted = true;
#endif

		opcode = nextiword ();

		if (gNextOpcodeValid)
		{
			opcode = gNextOpcode;
			gNextOpcodeValid = false;
		}

#if COUNT_INSTRUCTIONS
		gInstructionCount++;
#endif

		// Execute the instruction.  Catch any exceptions thrown
		// because of address/bus errors.  In CodeWarrior, the overhead
		// of this try/catch block is minimal: the SP is saved, and there's
		// a branch around the catch block.  I don't know about VC++.

		try
		{
			(*cpufunctbl[opcode]) (opcode);

#if HAS_PROFILING
			if (gProfilingEnabled)
			{
#if HAS_PROFILING_DEBUG
				Boolean tryagain = false;
				
				// mode debugging, validity check on RAM_ROM stuff
				if (perftbl[opcode].readCycles != 0xFF && gReadCycles - readCyclesSaved != perftbl[opcode].readCycles)
					gReadMismatch += gReadCycles - readCyclesSaved - perftbl[opcode].readCycles;
				if (perftbl[opcode].writeCycles != 0xFF && gWriteCycles - writeCyclesSaved != perftbl[opcode].writeCycles)
					gWriteMismatch += gWriteCycles - writeCyclesSaved - perftbl[opcode].writeCycles;

				if (tryagain)
					(*cpufunctbl[opcode]) (opcode);
#endif
				// add in the extra time taken to execute the instruction
				ProfileIncrementClock(perftbl[opcode].extraCycles);
			}
#endif

		}
		catch (...)
		{
			// By the time we reach here, the break code that caused the
			// exception to be thrown should be recorded in gBreakReason.
		}

		// Perform periodic tasks.

		Hardware::Cycle (false);

StoppedLoop:

		// Handle special conditions.  NB: the code reached by calling
		// Emulator::ExecuteSpecial used to be inline in this function.  Moving it
		// out (thus simplifying both Emulator::Execute and Emulator::ExecuteSpecial)
		// sped up the CPU loop by 9%!

		if (regs.spcflags)
		{
			Emulator::ExecuteSpecial ();
		}

#if HAS_PROFILING
		gProfilingCounted = false;
#endif
	}	// while (...)

	gCPULevel--;

	// Return the reason for our breaking, and return that reason to the caller.

	uae_u32	breakReason = gBreakReason;

	gBreakReason &= ~gBreakReasonMask;

	return breakReason & gBreakReasonMask;
}


// ---------------------------------------------------------------------------
//		� Emulator::ExecuteSpecial
// ---------------------------------------------------------------------------

void Emulator::ExecuteSpecial (void)
{
#if COUNT_INSTRUCTIONS
	gSpecial++;
#endif

	// If we're tracing, execute the trace vector.

	if ((regs.spcflags & SPCFLAG_DOTRACE) && !(regs.spcflags & SPCFLAG_STOP))
	{
		Software::ProcessException (kException_Trace);
	}

	if (regs.spcflags & SPCFLAG_STOP)
	{
		Emulator::ExecuteStoppedLoop ();

		// If we're still stopped, exit now; we have to handle events.

		if (regs.spcflags & SPCFLAG_STOP)
			return;
	}

	// Do trace-mode stuff (do_trace from newcpu.c does more,
	// but it's only needed for CPU_LEVEL > 0)

	if (regs.spcflags & SPCFLAG_TRACE)
	{
		regs.spcflags &= ~SPCFLAG_TRACE;
		regs.spcflags |= SPCFLAG_DOTRACE;
	}

	if (regs.spcflags & SPCFLAG_DOINT)
	{
		uae_s32 interruptLevel = Registers::GetInterruptLevel ();
		regs.spcflags &= ~SPCFLAG_DOINT;	// was ~(SPCFLAG_INT | SPCFLAG_DOINT) in Greg and Craig, but the latest UAE has this
		if ((interruptLevel != -1) && (interruptLevel > regs.intmask))
		{
			Software::ProcessInterrupt (interruptLevel);
			regs.stopped = 0;
		}
	}

	if (regs.spcflags & SPCFLAG_INT)
	{
		regs.spcflags &= ~SPCFLAG_INT;
		regs.spcflags |= SPCFLAG_DOINT;
	}

	if (regs.spcflags & SPCFLAG_BRK)
	{
		regs.spcflags &= ~SPCFLAG_BRK;
		Emulator::SetBreakReason (kException_Trace);
	}
}


// ---------------------------------------------------------------------------
//		� Emulator::ExecuteStoppedLoop
// ---------------------------------------------------------------------------

void Emulator::ExecuteStoppedLoop (void)
{
	// While the CPU is stopped (because a STOP instruction was
	// executed) do some idle tasks.

	do {
		// Slow down processing so that the TIMER2 used
		// to increment the tickcount doesn't run too quickly.

		Platform::Delay ();

		// Perform periodic tasks.

		Hardware::Cycle (true);

		// Process an interrupt (see if it's time to wake up).

		if (regs.spcflags & (SPCFLAG_INT | SPCFLAG_DOINT))
		{
			uae_s32	interruptLevel = Registers::GetInterruptLevel ();

			regs.spcflags &= ~(SPCFLAG_INT | SPCFLAG_DOINT);

			if ((interruptLevel != -1) && (interruptLevel > regs.intmask))
			{
				Software::ProcessInterrupt (interruptLevel);
				regs.stopped = 0;
				regs.spcflags &= ~SPCFLAG_STOP;
			}
		}
	} while ((regs.spcflags & SPCFLAG_STOP) && ((gBreakReason & gBreakReasonMask) == 0));
}


// ---------------------------------------------------------------------------
//		� Emulator::ExecuteUntilATrap
// ---------------------------------------------------------------------------

long Emulator::ExecuteUntilATrap (void)
{
	// Tell the CPU emulator to exit on the next "ATrap".

	bool	old = SetBreakOnException (kException_Trap15, true);

	// Run the processor until we break.

	uae_u32	oldBreakMask = Emulator::ClearBreakReasonMask (kBreak_StopRequest | kBreak_CheckForEvents);
	long	reason = Emulator::Execute ();
	Emulator::SetBreakReasonMask (oldBreakMask);

	// If a request to handle updates came in while we were running, ignore
	// it by clearing it.  We can handle it when we get back to the main
	// CPU loop.  We _don't_ want this break reason to remain registered,
	// as we're not in a position to handle it right now (we're probably
	// setting up to make a ROM subroutine call) and leaving it registered
	// will just cause the CPU loop to exit again.

	Emulator::ClearBreakReason (kBreak_CheckForEvents);

	// Restore the old setting.

	(void) SetBreakOnException (kException_Trap15, old);

	return reason;
}


// ---------------------------------------------------------------------------
//		� Emulator::ExecuteUntilBreak
// ---------------------------------------------------------------------------
// Processes instructions until a break occurs.

long Emulator::ExecuteUntilBreak (void)
{
	// ExecuteUntilBreak is called when we're calling ROM functions as
	// subroutines.  In that context, we DON'T want to break if another
	// thread wants to break in by telling us to break on an "ATrap".

	bool	oldBreakOn15 = SetBreakOnException (kException_Trap15, false);

	// Similarly, we don't want to break to handle events or because another
	// thread asks us to.  Our call into the ROM at this point should be
	// pretty much atomic (modulo real exceptions like bus errors).

	uae_u32	oldBreakMask = Emulator::ClearBreakReasonMask (kBreak_StopRequest | kBreak_CheckForEvents);

	// Run the processor until we break.

	long	reason;

	do {
		reason = Emulator::Execute ();

		// See if we broke on an ATrap anyway.  If we did, then it's because
		// another thread called SetBreakOnException (kException_Trap15, true)
		// after we set it to false.  Remember the fact that the other thread
		// wants to break on the next ATrap (by setting oldBreakOn15 to true),
		// and set that break flag back to false.

		if ((reason & kBreak_Exception) == kException_Trap15)
		{
			reason &= ~kBreak_Exception;
			oldBreakOn15 = true;
			SetBreakOnException (kException_Trap15, false);
		}
	}
	while (reason == 0);

	// Restore the old settings.

	Emulator::SetBreakReasonMask (oldBreakMask);
	(void) SetBreakOnException (kException_Trap15, oldBreakOn15);

	// If a request to handle updates came in while we were running, ignore
	// it by clearing it.  We can handle it when we get back to the main
	// CPU loop.  We _don't_ want this break reason to remain registered,
	// as we're not in a position to handle it right now (we're probably
	// setting up to make a ROM subroutine call) and leaving it registered
	// will just cause the CPU loop to exit again.

	Emulator::ClearBreakReason (kBreak_CheckForEvents);

	return reason;
}


// ---------------------------------------------------------------------------
//		� Emulator::SetNextOpcode
// ---------------------------------------------------------------------------

void Emulator::SetNextOpcode (uae_u16 opcode)
{
	assert (gNextOpcodeValid == false);

	gNextOpcode = opcode;
	gNextOpcodeValid = true;
}


// ---------------------------------------------------------------------------
//		� Emulator::SetBreakReason
// ---------------------------------------------------------------------------

uae_u32 Emulator::SetBreakReason (uae_u32 setBits)
{
	uae_u32	oldReason = gBreakReason;

	gBreakReason |= setBits;

	return oldReason;
}


// ---------------------------------------------------------------------------
//		� Emulator::SetBreakReasonMask
// ---------------------------------------------------------------------------

uae_u32 Emulator::SetBreakReasonMask (uae_u32 setBits)
{
	uae_u32	oldReasonMask = gBreakReasonMask;

	gBreakReasonMask |= setBits;

	return oldReasonMask;
}


// ---------------------------------------------------------------------------
//		� Emulator::ClearBreakReason
// ---------------------------------------------------------------------------

uae_u32 Emulator::ClearBreakReason (uae_u32 clearBits)
{
	uae_u32	oldReason = gBreakReason;

	gBreakReason &= ~clearBits;

	return oldReason;
}


// ---------------------------------------------------------------------------
//		� Emulator::ClearBreakReasonMask
// ---------------------------------------------------------------------------

uae_u32 Emulator::ClearBreakReasonMask (uae_u32 clearBits)
{
	uae_u32	oldReasonMask = gBreakReasonMask;

	gBreakReasonMask &= ~clearBits;

	return oldReasonMask;
}


// ---------------------------------------------------------------------------
//		� Emulator::SetBreakOnException
// ---------------------------------------------------------------------------
// Specify whether or not the CPU loop should exit when the given exception
// is encountered.  If so, then the CPU loop exits with the PC pointing to
// the instruction that caused the loop to exit (and not 2, 4, or 6 bytes
// beyond it).

bool Emulator::SetBreakOnException (uae_s32 exceptionNumber, bool doBreak)
{
	bool	oldBreak = gBreakOnException[exceptionNumber];
	gBreakOnException[exceptionNumber] = doBreak;
	return oldBreak;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Hardware::Initialize
// ---------------------------------------------------------------------------
// One-time initialization of emulator. Called from Emulator::Initialize.

void Hardware::Initialize (void)
{
	// Initialize some CPU-related tables

	// (This initialization code is taken from init_m68k in newcpu.c)

	long	opcode;
	int		i, j;

	for (i = 0 ; i < 256 ; i++)
	{
		for (j = 0 ; j < 8 ; j++)
		{
			if (i & (1 << j))
			{
				break;
			}
		}

		movem_index1[i] = j;
		movem_index2[i] = 7-j;
		movem_next[i] = i & (~(1 << j));
	}

	for (i = 0 ; i < 256 ; i++)
	{
		for (j = 7 ; j >= 0 ; j--)
		{
			if (i & (1 << j))
			{
				break;
			}
		}

		fpp_movem_index1[i] = j;
		fpp_movem_index2[i] = 7-j;
		fpp_movem_next[i] = i & (~(1 << j));
	}

	// read_table68k is going to try to allocate a bunch of memory.
	// But it assumes that that attempt will succeed, and try using
	// that memory without checking for NULL.  This can crash you horribly
	// on a Mac, so preflight that allocation here.

    table68k = (struct instr *)malloc (65536 * sizeof (struct instr));
	if (table68k == NULL)
	{
		ThrowNotify_Always (kError_NotEnoughMemoryForCPUTables, errno);
	}
	else
	{
		free (table68k);
		table68k = NULL;
	}

	read_table68k ();
	do_merges ();
	for (opcode = 0; opcode < 65536; opcode++)
	{
		cpufunctbl[opcode] = op_illg;
	}

	for (i = 0; op_smalltbl[i].handler != NULL; i++)
	{
		if (!op_smalltbl[i].specific)
		{
			cpufunctbl[op_smalltbl[i].opcode] = op_smalltbl[i].handler;
#if HAS_PROFILING
			perftbl[op_smalltbl[i].opcode] = op_smalltbl[i].perf;
#endif
		}
	}

	for (opcode = 0; opcode < 65536; opcode++)
	{
		cpuop_func*	f;

		if (table68k[opcode].mnemo == i_ILLG)
		{
			continue;
		}

		if (table68k[opcode].handler != -1)
		{
			f = cpufunctbl[table68k[opcode].handler];
			if (f == op_illg)
			{
				abort ();
			}

			cpufunctbl[opcode] = f;
#if HAS_PROFILING
			perftbl[opcode] = perftbl[table68k[opcode].handler];
#endif

		}
	}	

	for (i = 0; op_smalltbl[i].handler != NULL; i++)
	{
		if (op_smalltbl[i].specific)
		{
			cpufunctbl[op_smalltbl[i].opcode] = op_smalltbl[i].handler;
#if HAS_PROFILING
			perftbl[op_smalltbl[i].opcode] = op_smalltbl[i].perf;
#endif
		}
	}

	// (hey readcpu doesn't free this guy!)

	free (table68k);
	table68k = NULL;
}


// ---------------------------------------------------------------------------
//		� Hardware::Reset
// ---------------------------------------------------------------------------
// Sets the registers to default values.  This occurs when the emulator boots
// for the first time or is reset. Also called directly from the RESET opcode
// handler (which would seem to bypass m68k_reset in UAE, but is not skipped
// here, since we merged m68K_reset and customreset into Hardware::Reset).

void Hardware::Reset (void)
{
	// (taken from m68k_reset in newcpu.c)

	m68k_areg (regs, 7) = Memory_GetLong (kROMBank_Start);
	m68k_setpc (Memory_GetLong (kROMBank_Start + 4));

	// Note, on the 68K, the t0 and m flags must always be zero.

	regs.kick_mask	= 0xF80000;			// (not a 68K register)
	regs.s			= 1;				// supervisor/user state
	regs.m			= 0;				// master/interrupt state
	regs.stopped	= 0;				// (not a 68K register)
	regs.t1			= 0;				// Trace enable: 00 = no trace, 10 = trace on any instruction
	regs.t0			= 0;				//		01 = gtrace on change of flow, 11 = undefined
	ZFLG = CFLG = NFLG = VFLG = 0;
	regs.spcflags	= 0;				// (not a 68K register)
	regs.intmask	= 7;				// enable all interrupts
	regs.vbr = regs.sfc = regs.dfc = 0;
	regs.fpcr = regs.fpsr = regs.fpiar = 0;

	// UAE doesn't do this next step, but it seems like a good idea.

	Registers::UpdateSRFromRegisters ();

	// Initialize the registers.
	// (Based on customreset in original Windows Copilot)

	g68328Regs = kInitial68328RegisterValues;

	// Byteswap all the words in the Dragonball registers (if necessary). Most
	// accesses are 16-bit accesses, so we optimize for that case.

	ByteswapWords (&g68328Regs, sizeof(g68328Regs));

	gLastTmr1Status = 0;
	gLastTmr2Status = 0;
	gPortDEdge = 0;
}


// ---------------------------------------------------------------------------
//		� Hardware::Cycle
// ---------------------------------------------------------------------------
// Handles periodic events that need to occur when the processor cycles (like
// updating timer registers).  This function is called in two places from
// Emulator::Execute.  Interestingly, the loop runs 3% FASTER if this function
// is in its own separate function instead of being inline.

void Hardware::Cycle (bool sleeping)
{
	// Determine whether timer 2 is enabled.

	if ((READ_REGISTER (tmr2Control) & hwr328TmrControlEnable) != 0)
	{
		// If so, increment the timer.

		WRITE_REGISTER (tmr2Counter, READ_REGISTER (tmr2Counter) + 1);

		// Determine whether the timer has reached the specified count.

		if (sleeping || READ_REGISTER (tmr2Counter) > READ_REGISTER (tmr2Compare))
		{
			// Flag the occurrence of the successful comparison.

			WRITE_REGISTER (tmr2Status, READ_REGISTER (tmr2Status) | hwr328TmrStatusCompare);

			// If the Free Run/Restart flag is not set, clear the counter.

			if ((READ_REGISTER (tmr2Control) & hwr328TmrControlFreeRun) == 0)
			{
				WRITE_REGISTER (tmr2Counter, 0);
			}

			// If the timer interrupt is enabled, post an interrupt.

			if ((READ_REGISTER (tmr2Control) & hwr328TmrControlEnInterrupt) != 0)
			{
				WRITE_REGISTER (intPendingLo, READ_REGISTER (intPendingLo) | hwr328IntLoTimer2);
				Registers::UpdateInterrupts ();
			}
		}
	}

	// Check if communications are enabled, pending read data
	// has been cleared, and new read data is available.

	if (((READ_REGISTER (uControl) & hwr328UControlUARTEnable) != 0) &&
		((READ_REGISTER (uReceive) & hwr328UReceiveDataRdy) == 0) &&
		(Platform::IncomingSerialBytes () > 0))
	{
		// Get the next byte of incoming data.

		uae_u16	uReceive = READ_REGISTER (uReceive);

		uReceive &= ~hwr328UReceiveData;
		uReceive |= (uae_u8) Platform::ReadSerialByte ();
		uReceive |= hwr328UReceiveDataRdy;

		WRITE_REGISTER (uReceive, uReceive);

		// If enabled, set an interrupt.

		if ((READ_REGISTER (uControl) & hwr328UControlRxRdyEn) != 0)
		{
			WRITE_REGISTER (intPendingLo, READ_REGISTER (intPendingLo) | hwr328IntLoUART);
			Registers::UpdateInterrupts ();
		}
	}

	// Note, the way we do this is very critical!  Previously, I'd updated
	// the screen and checked for events separately by calling two different
	// functions.  Each of these functions would check to see if an
	// appropropriate amount of time had elapsed, and perform their function
	// if it had.
	//
	// Making 4 function calls (one to the "update screen" function, one to
	// the "handle events" function, and two to LMGetTicks()) was extremely
	// expensive.  Changing this to a single call to LMTicks (in the inline
	// Platform_TimeForCycle function) speeds up the main CPU loop by 20%!

	if (Platform::TimeForCycle (sleeping))
	{
		// Check to see if the RTC alarm is ready to go off.  First see
		// if the RTC is enabled, and that the alarm event isn't already
		// registered (the latter check is just an optimization).

		if ((READ_REGISTER (rtcIntEnable) & hwr328RTCIntEnableAlarm) != 0 &&
			(READ_REGISTER (rtcIntStatus) & hwr328RTCIntStatusAlarm) == 0)
		{
			uae_u32	rtcAlarm = READ_REGISTER (rtcAlarm);

			long	almHour	 = (rtcAlarm & hwr328RTCAlarmHoursMask) >> hwr328RTCAlarmHoursOffset;
			long	almMin	 = (rtcAlarm & hwr328RTCAlarmMinutesMask) >> hwr328RTCAlarmMinutesOffset;
			long	almSec	 = (rtcAlarm & hwr328RTCAlarmSecondsMask) >> hwr328RTCAlarmSecondsOffset;
			long	almInSeconds = (almHour * 60 * 60) + (almMin * 60) + almSec;

			long	nowHour;
			long	nowMin;
			long	nowSec;
			Platform::GetTime (&nowHour, &nowMin, &nowSec);
			long	nowInSeconds = (nowHour * 60 * 60) + (nowMin * 60) + nowSec;

			if (almInSeconds <= nowInSeconds)
			{
				WRITE_REGISTER (rtcIntStatus, READ_REGISTER (rtcIntStatus) | hwr328RTCIntStatusAlarm);
				Registers::UpdateRTCInterrupts ();
			}
		}

		// Do some platform-specific stuff.

		Platform::Cycle ();
	}
}


// ---------------------------------------------------------------------------
//		� Hardware::PenEvent
// ---------------------------------------------------------------------------
// Handles a touch-screen pen event by updating the appropriate registers.

void Hardware::PenEvent (bool	iPen_IsDown,
						uae_s32	iPen_HorzLocation,
						uae_s32	iPen_VertLocation)
{

	// Might want to skip the whole HwrIRQ5Handler thing and just use
	// something along the lines of the following:
	//
	//
	/*
			// Enqueue the first point if we got one.
			if (!err)
				EvtEnqueuePenPoint(&pen);
				
			// If the pen is down, force our timer task to run on the next tick
			if (GHwrPenDown) 
				SysTimerWrite(GSysTimerID, 1);
	*/

	// If Gremlins is running, do nothing. If we tried to post anything
	// now, we might be interrupting a call to EvtEnqueuePenPoint.

	if (Gremlins_IsOn ())
		return;

	// If the pen changes state, set or clear the pen interrupt.

	if (gPen_IsDown != iPen_IsDown)
	{
		uae_u16	intPendingHi = READ_REGISTER (intPendingHi);

		if (iPen_IsDown)
		{
			intPendingHi |= hwr328IntHiPen;
		}
		else
		{
			intPendingHi &= ~hwr328IntHiPen;
		}

		WRITE_REGISTER (intPendingHi, intPendingHi);

		Registers::UpdateInterrupts ();

		gPen_IsDown = iPen_IsDown;
	}

	// Remember the pen location.

	gPen_HorzLocation = iPen_HorzLocation;
	gPen_VertLocation = iPen_VertLocation;
}


// ---------------------------------------------------------------------------
//		� Hardware::ButtonEvent
// ---------------------------------------------------------------------------
// Handles a Palm device button event by updating the appropriate registers.

void Hardware::ButtonEvent (	bool	iButton_IsDown,
							uae_s32	iButton)
{
	// If Gremlins is running, do nothing. If we tried to post anything
	// now, we might be interrupting a call to KeyHandleInterrupt.

	if (Gremlins_IsOn ())
		return;

	uae_u8	previousPortDData = READ_REGISTER (portDData);
	uae_u8	portDData = previousPortDData;

	if (iButton_IsDown)
	{
		portDData |= (1 << iButton);
	}
	else
	{
		portDData &= ~(1 << iButton);
	}

	WRITE_REGISTER (portDData, portDData);

	// Set the interrupt bits for the bits that went from off to on.

	gPortDEdge |= portDData & ~previousPortDData;

	// Set the new interrupt state.

	Registers::UpdatePortDInterrupts ();
}


// ---------------------------------------------------------------------------
//		� Hardware::HotSyncEvent
// ---------------------------------------------------------------------------
// Handles a HotSync button event by updating the appropriate registers.

void Hardware::HotSyncEvent (bool iButton_IsDown)
{
	// If Gremlins is running, do nothing. If we tried to post anything
	// now, we might be interrupting a call to KeyHandleInterrupt.

	if (Gremlins_IsOn ())
		return;

	// If the button changes state, set or clear the HotSync interrupt.

	uae_u16	intPendingHi = READ_REGISTER (intPendingHi);

	if (iButton_IsDown)
	{
		intPendingHi |= hwr328IntHiIRQ1;
		fgHotSyncButtonDown = true;
	}
	else
	{
		intPendingHi &= ~hwr328IntHiIRQ1;
		fgHotSyncButtonDown = false;
	}

	WRITE_REGISTER (intPendingHi, intPendingHi);

	Registers::UpdateInterrupts ();
}


// ---------------------------------------------------------------------------
//		� Hardware::KeyboardEvent
// ---------------------------------------------------------------------------
// Handles a key down event on the desktop keyboard by adding the key to the
// key queue.

void Hardware::KeyboardEvent (uae_u8 iKey)
{
	// Add the key to the queue if it isn't full.

	if (gKeyQueue.GetFree () > 0)
	{
		gKeyQueue.Put (iKey);
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Screen::GetDepth
// ---------------------------------------------------------------------------

int Screen::GetDepth()
{
	bool	grayscale = (READ_REGISTER (lcdPanelControl) & hwr328LcdPanelControlGrayScale) != 0;

	return grayscale ? 2 : 1;
}


// ---------------------------------------------------------------------------
//		� Screen::GetWidth
// ---------------------------------------------------------------------------

int Screen::GetWidth()
{
	int width = READ_REGISTER (lcdScreenWidth) + 1;

	return width;
}


// ---------------------------------------------------------------------------
//		� Screen::GetHeight
// ---------------------------------------------------------------------------

int Screen::GetHeight()
{
	int height = READ_REGISTER (lcdScreenHeight) + 1;

	return height;
}


// ---------------------------------------------------------------------------
//		� Screen::GetBaseAddress
// ---------------------------------------------------------------------------

void* Screen::GetBaseAddress()
{
	void*	addr = (void*) get_real_address (READ_REGISTER (lcdStartAddr));

	return addr;
}


// ---------------------------------------------------------------------------
//		� Screen::LCDIsOn
// ---------------------------------------------------------------------------

bool Screen::LCDIsOn()
{
	bool	on = (READ_REGISTER (portFData) & hwrTD1PortFLCDEnableOn) != 0;

	return on;
}


// ---------------------------------------------------------------------------
//		� Screen::BacklightIsOn
// ---------------------------------------------------------------------------

bool Screen::BacklightIsOn()
{
	bool	on = (READ_REGISTER (portGData) & hwrTD1PortGBacklightOn) != 0;

	return on;
}


// ---------------------------------------------------------------------------
//		� Screen::GetBits
// ---------------------------------------------------------------------------
// Provides the screen information in a format suitable for blitting to the
// screen.
//
//	Parameters:		pAddr receives a pointer to a buffer of pixels.
//					pWidth receives the width of the screen in pixels.
//					pHeight receives the height of the screen in pixels/lines.
//					pDepth receives the number of bits per pixel.
//
//	Return Value:	TRUE if some significant change has occured since the last time
//					this function was called, including:
//
//						- screen dimension
//						- screen depth
//						- screen contents
//						- backlighting
//						- lcd on/off
//
//					Otherwise it returns false.
//
//	NOTE ON IMPLEMENTATION:
//	
//	The original version of Copilot determined if something had changed
//	on the screen by keeping a copy of the screen, and comparing the
//	current screen to that copy.  Another approach is to set a bit from
//	DRAM_SetFoo if the memory affected is in the screen range.  The
//	question is: which is the better approach?
//
//	One way to determine this is to count instructions:
//
//	METHOD A: compare screens:
//
//		The workhorse of this method is the MemCmpy function. Assuming
//		the typical case that the screen hasn't change and thus a full
//		compare must be performed, MemCmpy's main loop of 12 PPC
//		instructions will be executed 800 times (the compare is performed
//		via longs, and there are 800 longs in a 1-bit 160x160 screen
//		buffer).  That's 9600 instructions per check. Assuming we check
//		10 times per second, that comes to 240,000 instructions during
//		the 2.5 second boot period on a PowerMac.
//
//	Method B: notice the change in DRAM_SetFoo:
//
//		Again, let's take the typical case where the screen is not
//		changing.  A DRAM_SetFoo function that doesn't make the check
//		is 5 instructions long.  A DRAM_SetFoo function with the check
//		is 23 instructions long, of which 21 are executed when nothing
//		changes (actually, check for whether or not to dirty the screen
//		is made only when the screen has not already been dirtied, which
//		leads to slightly more efficient code).  When booting the ROM,
//		those functions are called 543,451 times, for a total of
//		8,695,216 additional instructions.
//
//	So it looks like Method A is about 40 times faster!
//
//	!!! These numbers should be revisited now that MemSet and MemMove are
//	implemented as native functions.

bool Screen::GetBits(void** pAddr, int* pWidth, int* pHeight, int* pDepth)
{
	// Read the change bits and then clear them out.

	uae_u32	screenChange = gScreenChange;
	gScreenChange = 0;

	// Get the screen's current width, height, depth, and buffer size.

	int	width	= Screen::GetWidth ();
	int	height	= Screen::GetHeight ();
	int	depth	= Screen::GetDepth ();

	long	screenSize = width * height * depth / 8;

	// If the LCD depth, width or height changed since we last looked at it,
	// gScreenChange will have been set by the DBReg functions.
	// Dump the old buffer because we'll need a new one.

	if (screenChange & (kScreen_WidthChanged | kScreen_HeightChanged | kScreen_DepthChanged))
	{
		free (gScreenCopy);
		gScreenCopy = NULL;
	}

	// If we no longer have a buffer (or if we never had one), allocate one.

	if (gScreenCopy == NULL)
	{
		gScreenCopy = malloc (screenSize);
	}

	// If we know the screen has changed, copy the LCD buffer to gScreenCopy.
	// Otherwise, use MemCmpy to see if there's been a change.  If there has,
	// set the kScreen_ContentsChanged bit.
	//
	// Note: on the Mac, memcpy calls BlockMoveData, and on the PC, the copy
	// is performed a byte at a time. We may just want to call MemCmpy instead,
	// as it's pretty well optimized for transferring data a long at a time.
	//
	// OK...I tried it. On my PowerMac, doing memcpy 10,000 times takes 53
	// milliseconds, while doing MemCmpy 10,000 times takes 228 milliseconds.
	// Which means that a single memcpy takes 5.3 microseconds, and a single
	// MemCmpy takes 22.8 microseconds.  Neither of these amounts to a hill
	// of beans when executed 10 to 20 times per second that we check to
	// refresh the screen.

	if (screenChange & kScreen_ContentsChanged)
	{
		memcpy (gScreenCopy, Screen::GetBaseAddress (), screenSize);
	}
	else
	{
		if (Utility::MemCmpy (gScreenCopy, Screen::GetBaseAddress (), screenSize))
			screenChange |= kScreen_ContentsChanged;
	}

	if (pWidth)
		*pWidth = width;

	if (pHeight)
		*pHeight = height;

	if (pDepth)
		*pDepth = depth;

	if (pAddr)
		*pAddr = gScreenCopy;

	return screenChange != 0;
}


// ---------------------------------------------------------------------------
//		� Screen::RecordChange
// ---------------------------------------------------------------------------

void Screen::RecordChange (uae_u32 theChange)
{
	gScreenChange |= theChange;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Software::BusError
// ---------------------------------------------------------------------------
// Called by the FooBank_XXX routines when an illegal reference to memory
// is made.

void	Software::BusError(void)
{
	Software::ProcessException (kException_BusErr);

	// If a break reason was registered, get outta here fast.  We want to
	// do this for things like bus errors so that we don't try to
	// execute the rest of the instruction.
	//
	// Only check for kBreak_Exception reasons.  Other break reasons like
	// kBreak_StopRequest and kBreak_CheckForEvents are less imperative.

//	if ((Emulator::SetBreakReason (0) & kBreak_Exception) != 0)
	{
		throw (long) 0;
	}
}


// ---------------------------------------------------------------------------
//		� Software::ProcessException
// ---------------------------------------------------------------------------
// Handles an exception by updating the registers and the processor state.

void Software::ProcessException (uae_s32 iException)
{
#if EXCEPTION_HISTORY

	// Save the exception for the post-mortem

	exception_history_index++;

	long	index = exception_history_index & (exception_history_size - 1);
	if (iException == kException_Trap15)	// A-Trap
	{
		long	sysCmd = get_word (m68k_getpc ());
		exception_history[index].name = kTrapNames[ TrapIndex (sysCmd) ];
	}
	else
	{
		exception_history[index].name = kExceptionNames[iException];
	}

	exception_history[index].pc = m68k_getpc ();
	exception_history[index].sp = m68k_areg (regs, 7);

#endif

	// See if we've been asked to break on this exception.

	if (gBreakOnException[iException])
	{
		// Back up the PC to point to where this whole mess started.

#ifdef USE_POINTER
		regs.pc_p = gCurrentInstructionStart;
#else
		regs.pc = (uae_u32)gCurrentInstructionStart;
#endif

		Emulator::SetBreakReason (iException);
		return;
	}

#if HAS_PROFILING
	// don't count cycles spent in exception handlers against functions
	if (gProfilingEnabled)
	{
/*		if (iException == 0x2F)
		{
			// we know the trap handler is going to muck with the return address
			// so that the RTE will call the trap, so insert a function call here
			// to keep things balanced
			gProfilingCounted = false;
			uaecptr pc = m68k_getpc();
			ProfileFnEnter(get_word(pc), pc+2);
			gProfilingCounted = true;
		}
*/
		ProfileInterruptEnter(iException, m68k_getpc());
	}
#endif

	// Let any custom exception handler have a go at it.  If it returns
	// true, it handled it completely, and we don't have anything else to do.

	if (gExceptionHandlers[iException] && gExceptionHandlers[iException] (iException))
	{
#if HAS_PROFILING
	if (gProfilingEnabled)
		ProfileInterruptExit(m68k_getpc());
#endif
		return;
	}

	// The following is vaguely modelled after Exception() from newcpu.c

	// Make sure the Status Register is up-to-date.

	Registers::UpdateSRFromRegisters ();

	// If not in supervisor mode, set the usp, restore A7 from the isp,
	// and transfer to supervisor mode.

	if (!regs.s)
	{
		regs.usp = m68k_areg (regs, 7);
		m68k_areg (regs, 7) = regs.isp;
		regs.s = 1;
	}

	// Set up the stack frame.

	if (iException == kException_BusErr || iException == kException_AddressErr)
	{
		// For something bad like address and bus errors, tell the user.
		// !!! Do we really want to do this?

//		char	buffer[200];
//		
//		sprintf (buffer, "Address Error at 0x%X.", regs.pc);
//		Platform::ReportString (buffer);
//
//#if defined (_DEBUG)
//		Platform::Debugger ();
//#endif

		assert (sizeof (ExceptionStackFrame2) == 14);
		m68k_areg (regs, 7) -= sizeof (ExceptionStackFrame2);

		uaecptr	frame = m68k_areg (regs, 7);

		put_word (frame + offsetof (ExceptionStackFrame2, functionCode), 0);	// Eh...Palm OS doesn't use these 3 anyway...
		put_long (frame + offsetof (ExceptionStackFrame2, accessAddress), 0);
		put_word (frame + offsetof (ExceptionStackFrame2, instructionRegister), 0);

		put_word (frame + offsetof (ExceptionStackFrame2, statusRegister), regs.sr);
		put_long (frame + offsetof (ExceptionStackFrame2, programCounter), m68k_getpc ());
	}
	else
	{
		assert (sizeof (ExceptionStackFrame1) == 6);
		m68k_areg (regs, 7) -= sizeof (ExceptionStackFrame1);

		uaecptr	frame = m68k_areg (regs, 7);

		put_word (frame + offsetof (ExceptionStackFrame1, statusRegister), regs.sr);
		put_long (frame + offsetof (ExceptionStackFrame1, programCounter), m68k_getpc ());
	}

	{
		CEnableFullAccess	munge;	// Remove blocks on memory access.

		// Get the exception handler address and jam it in the PC.
		m68k_setpc (get_long (regs.vbr + 4 * iException));

	}

	// Turn tracing off.

	regs.t1 = regs.t0 = regs.m = 0;
	regs.spcflags &= ~(SPCFLAG_TRACE | SPCFLAG_DOTRACE);
}


// ---------------------------------------------------------------------------
//		� Software::ProcessInterrupt
// ---------------------------------------------------------------------------
// Handles an interrupt by updating the registers and the processor state.

void Software::ProcessInterrupt (uae_s32 iInterrupt)
{
	Software::ProcessException (iInterrupt + Registers::GetInterruptBase ());
	regs.intmask = iInterrupt;
	regs.spcflags |= SPCFLAG_INT;

	Registers::UpdateSRFromRegisters ();	// This isn't in UAE, but it seems like
										// a good idea to do after changing intmask.
}


// ---------------------------------------------------------------------------
//		� Software::ProcessIllegalInstruction
// ---------------------------------------------------------------------------
// Handles an illegal opcode by updating the registers and the processor state.

void Software::ProcessIllegalInstruction (uae_u32 iOpcode)
{
	// This function is loosely based on op_illg in newcpu.c

	m68k_setpc (m68k_getpc () - 2);

	// Process an FTrap.

	if ((iOpcode & 0xF000) == 0xF000)
	{
		Software::ProcessException (kException_FTrap);
		return;
	}

	// Process an ATrap.

	if ((iOpcode & 0xF000) == 0xA000)
	{
		Software::ProcessException (kException_ATrap);
		return;
	}

	Software::ProcessException (kException_IllegalInstr);
}


// ---------------------------------------------------------------------------
//		� Software::InstallExceptionHandler
// ---------------------------------------------------------------------------
// Specified a function to be called when the given exception occurs.  When
// it occurs, the function will be called with the PC somewhere beyond the
// start of the instruction that caused the problem, but
// gCurrentInstructionStart can be used to get the start of the
// instruction.

void Software::InstallExceptionHandler (uae_s32 exceptionNumber,
										ExceptionHandlerProc fn)
{
	gExceptionHandlers[exceptionNumber] = fn;
}


// ---------------------------------------------------------------------------
//		� Software::RemoveExceptionHandler
// ---------------------------------------------------------------------------

void Software::RemoveExceptionHandler (uae_s32 exceptionNumber)
{
	gExceptionHandlers[exceptionNumber] = NULL;
}


// ---------------------------------------------------------------------------
//		� Software::ProcessJSR
// ---------------------------------------------------------------------------
bool Software::ProcessJSR (uaecptr dest)
{
#if HAS_PROFILING
	if (gProfilingEnabled)
	{
		gProfilingCounted = false;
		ProfileFnEnter(dest, m68k_getpc());
		gProfilingCounted = true;
	}
#endif
	return false;
}


// ---------------------------------------------------------------------------
//		� Software::ProcessRTS
// ---------------------------------------------------------------------------

bool Software::ProcessRTS (void)
{
#if HAS_PROFILING
	if (gProfilingEnabled)
	{
		gProfilingCounted = false;
		ProfileFnExit(get_long(m68k_areg(regs, 7)));
		gProfilingCounted = true;
	}
#endif
	return false;	// We didn't completely handle it; do default handling.
}


// ---------------------------------------------------------------------------
//		� Software::ProcessRTE
// ---------------------------------------------------------------------------
bool Software::ProcessRTE (uae_s32 newpc)
{
#if HAS_PROFILING
	if (gProfilingEnabled)
		ProfileInterruptExit(newpc);
#endif

	return false;	// We didn't completely handle it; do default handling.
}


// ---------------------------------------------------------------------------
//		� Software::ProcessTrap13	
// ---------------------------------------------------------------------------
// Handle a tail patch. Traps that we want to tail patch have a TRAP D stored
// right after the 4-byte trap sequence used to invoke them.
// Patches::HandleTrap13 will restore the opcode removed when we put the
// TRAP D there, back up the PC so that we can re-execute that opcode, and
// call the tail patch handler.

bool Software::ProcessTrap13 (uae_s32 exceptionNumber)
{
	Patches::HandleTrap13 ();
	return true;
}


// ---------------------------------------------------------------------------
//		� Software::ProcessTrap14	
// ---------------------------------------------------------------------------
// Handle the emulator special-cased traps.

bool Software::ProcessTrap14 (uae_s32 exceptionNumber)
{
	bool	handledIt = true;
	uae_u16	trapWord = get_word (m68k_getpc ());

	switch(trapWord)
	{
#if HAS_PROFILING
		case emuTrapProfileInit:
		{
			int	maxCalls = (int) get_word (m68k_areg (regs, 7) + 0);
			int maxDepth = (int) get_word (m68k_areg (regs, 7) + 2);
			ProfileInit (maxCalls, maxDepth);
			break;
		}

		case emuTrapProfileStart:
			ProfileStart ();
			break;

		case emuTrapProfileStop:
			ProfileStop ();
			break;

		case emuTrapProfileDump:
			ProfileDump ();
			break;

		case emuTrapProfileCleanup:
			ProfileCleanup ();
			break;
#endif

		default:
			handledIt = false;
			break;
	}

	if (handledIt)
	{
		m68k_setpc (m68k_getpc () + 2);		// skip trapword
	}

	return handledIt;
}


// ---------------------------------------------------------------------------
//		� Software::ProcessTrap15
// ---------------------------------------------------------------------------
// Handle a trap. Traps are of the format TRAP $F / $Axxx.

bool Software::ProcessTrap15 (uae_s32 exceptionNumber)
{
	// If we haven't already, get the number of traps in this system.

	if (gSysDispatchTableSize == 0)
	{
		CEnableFullAccess	munge;	// Remove blocks on memory access.

		gSysDispatchTableSize = LowMem_GetGlobal (sysDispatchTableSize);
	}

	// Get the trap word (the $Axxx value) and turn it into a zero-based index.

	uae_u16	trapWord = get_word (m68k_getpc ());
	uae_u16	trapIndex = TrapIndex (trapWord);

#if COUNT_TRAPS

	// Record this trap call, allocating the table used to hold that
	// information if necessary.

	if (trapIndex < gSysDispatchTableSize)
	{
		if (gTrapCounts == NULL)
		{
			gTrapCounts = new long[gSysDispatchTableSize];
			memset (gTrapCounts, 0, sizeof(long) * gSysDispatchTableSize);
		}

		gTrapCounts[trapIndex]++;
		gTotalTrapCount++;
	}

#endif

	// Record what trap we're executing.

	Gremlins_RecordTrapCall (trapWord);

	// Let the debugger have a crack at it.  It may want to do a "break
	// on ATrap" thingy.  If so, it will return true.  Otherwise,
	// if no action is necessary, it will return false.

	if (Debug::HandleTrap15 ())
	{
		return true;
	}

	// ��� perf pretend there's a function entry here!
	
	// If this trap is patched, let the patch handler handle the patch.

#if HAS_PROFILING
	// this fnenter will show the function call within the trap handler exception,
	// which gives us a nice breakdown of which traps are being called and frequency
	if (gProfilingEnabled)
	{
		gProfilingCounted = false;
		ProfileFnEnter(trapWord, m68k_getpc()+2); 	// Skip the $Axxx dispatch number.
		gProfilingCounted = true;
	}
#endif

	if (Patches::HandleTrap15 ())
	{
		nextiword ();	// Skip the $Axxx dispatch number.

#if HAS_PROFILING
		if (gProfilingEnabled)
		{
			gProfilingCounted = false;
			ProfileFnExit(m68k_getpc());
			gProfilingCounted = true;
		}
#endif

		return true;
	}

#if HAS_PROFILING
	// don't do native dispatching if the profiler is on!
	if (gProfilingEnabled)
		// Return false to do default exception handler processing.
		return false;
#endif

	// Otherwise, let's run the trap dispatcher native.  This gives
	// us about a 10-12% speed-up.  But let's not try dealing with
	// library trap functions.  Apparently, each library table entry
	// can be either 8 or 16 bytes, depending on the OS version.
	// Let's sidestep that issue for now and avoid being dependent on
	// OS versions.

	if (trapWord < sysTrapLastTrapNumber)
	{
		uaecptr	address = LowMem::GetTrapAddress (trapWord);

		if (address)
		{
			// Push the return address onto the stack. Subtract 4
			// from the stack, and then store the current PC + 2
			// (we add 2 to skip past the trap selector that follows
			// the TRAP F).

			m68k_areg (regs, 7) -= 4;
			put_long (m68k_areg (regs, 7), m68k_getpc () + 2);

			// Change to the new PC.

			m68k_setpc (address);
			return true;
		}
	}

	// Return false to do default exception handler processing.

	return false;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� LowMem::GetEvtMgrIdle
// ---------------------------------------------------------------------------

uae_u8 LowMem::GetEvtMgrIdle (void)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	// First, get sysEvtMgrGlobalsP, which is a pointer in low-memory.

	uae_u32	sysEvtMgrGlobalsP	= LowMem_GetGlobal (sysEvtMgrGlobalsP);

	/*
	**	Next look at the "idle" boolean in the SysEvtMgrGlobalsPtr
	**	contained in sysEvtMgrGlobalsP:
	**
	**	struct SysEvtMgrGlobalsType
	**	{
	**		...
	**		Boolean			idle;
	**		...
	**	};
	*/

	size_t	idleOffset	= offsetof (SysEvtMgrGlobalsType, idle);
	uae_u8	idle		= get_byte (sysEvtMgrGlobalsP + idleOffset);

	return idle;
}


// ---------------------------------------------------------------------------
//		� LowMem::TrapExists
// ---------------------------------------------------------------------------

bool LowMem::TrapExists (uae_u16 iATrap)
{
	return (iATrap >= sysTrapBase) &&
			(iATrap < (gSysDispatchTableSize + sysTrapBase));
}


// ---------------------------------------------------------------------------
//		� LowMem::GetTrapAddress
// ---------------------------------------------------------------------------

uaecptr LowMem::GetTrapAddress (uae_u16 iATrap)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	// If the trap number is not in range, just return NULL to signal
	// that normal process of the TRAP $F should occur.

	if (!TrapExists (iATrap))
		return NULL;

	// Get sysDispatchTableP, which is a pointer in low-memory.

	uae_u32	sysDispatchTableP	= LowMem_GetGlobal (sysDispatchTableP);

	// If it's NULL, return NULL.

	if (sysDispatchTableP == NULL)
		return NULL;

	// Next, get the right guy from its contents.

	uaecptr	address = get_long (sysDispatchTableP + TrapIndex (iATrap) * 4);

	return address;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Registers::GetRegisters
// ---------------------------------------------------------------------------

void Registers::GetRegisters (regstruct& oRegisters)
{
	oRegisters = regs;
	oRegisters.pc = m68k_getpc ();
}


// ---------------------------------------------------------------------------
//		� Registers::SetRegisters
// ---------------------------------------------------------------------------

void Registers::SetRegisters (regstruct& iRegisters)
{
	regs = iRegisters;
	Registers::UpdateRegistersFromSR ();
	m68k_setpc (iRegisters.pc);
}


// ---------------------------------------------------------------------------
//		� Registers::GetInterruptLevel
// ---------------------------------------------------------------------------

uae_s32 Registers::GetInterruptLevel (void)
{
	uae_u16	intStatusHi = READ_REGISTER (intStatusHi);
	uae_u16	intStatusLo = READ_REGISTER (intStatusLo);

	// Level 7 = IRQ7.

	if ((intStatusHi & hwr328IntHiNMI) != 0)
		return 7;

	// Level 6 = SPIS, TMR1, IRQ6.

	if ((intStatusHi & (hwr328IntHiTimer1 | hwr328IntHiSPIS | hwr328IntHiIRQ6)) != 0)
		return 6;

	// Level 5 = PEN.

	if ((intStatusHi & hwr328IntHiPen) != 0)
		return 5;

	// Level 4 = SPIM, TMR2, UART, WDT, RTC, KB, PWM, INT0 - INT7.

	if ((intStatusLo & (	hwr328IntLoAllKeys |
							hwr328IntLoPWM |
							hwr328IntLoKbd |
						//	hwr328IntLoLCDC |
							hwr328IntLoRTC |
							hwr328IntLoWDT |
							hwr328IntLoTimer2 |
							hwr328IntLoSPIM)) != 0)
		return 4;

	// Level 3 = IRQ3.

	if ((intStatusHi & hwr328IntHiIRQ3) != 0)
		return 3;

	// Level 2 = IRQ2.

	if ((intStatusHi & hwr328IntHiIRQ2) != 0)
		return 2;

	// Level 1 = IRQ1.

	if ((intStatusHi & hwr328IntHiIRQ1) != 0)
		return 1;

	// Level 0.

	return -1;
}


// ---------------------------------------------------------------------------
//		� Registers::GetInterruptBase
// ---------------------------------------------------------------------------

uae_s32 Registers::GetInterruptBase(void)
{
	return READ_REGISTER (intVector) & 0xF8;
}


// ---------------------------------------------------------------------------
//		� Registers::UpdateInterrupts
// ---------------------------------------------------------------------------
// Determines whether an interrupt has occurred by copying the Interrupt
// Pending Register to the Interrupt Status Register.

void Registers::UpdateInterrupts (void)
{
	// Copy the Interrupt Pending Register to the Interrupt Status
	// Register, but ignore interrupts that are being masked.

	// Note: this function is not sensitive to the byte ordering of the registers,
	// so their contents don't need to be accessed via READ_REGISTER or WRITE_REGISTER.

	g68328Regs.intStatusHi = g68328Regs.intPendingHi & ~g68328Regs.intMaskHi;
	g68328Regs.intStatusLo = g68328Regs.intPendingLo & ~g68328Regs.intMaskLo;

	// If the Interrupt Status Register isn't clear, flag an interrupt.

	if (g68328Regs.intStatusHi || g68328Regs.intStatusLo)
	{
		regs.spcflags |= SPCFLAG_INT;
	}
}


// ---------------------------------------------------------------------------
//		� Registers::UpdatePortDInterrupts
// ---------------------------------------------------------------------------
// Determine what interrupts need to be generated based on the current
// settings in portDData and gPortDEdge.

void Registers::UpdatePortDInterrupts (void)
{
	// Update INT0-INT7 of the Interrupt-Pending register (bits 8-15 of the low word).

	// First, get those bits and clear them out.

	uae_u32	intPendingLo	= READ_REGISTER (intPendingLo) & 0x00FF;

	// Determine the new interrupt settings. An interrupt is signalled if:
	//
	//	- its gPortDEdge bit is set along with its corresponding portDIntEdge bit, or
	//	- its portDData bit is set but its corresponding portDIntEdge bit is not, and
	//	- that interrupt is enabled in portDIntReqen
	//
	// (Technically, it seems to me that we should also be looking at portDPolarity when
	//  examining edge interrupts to signal falling or rising edges.  However, those bits
	//  are always set by the current Palm OS ROMs (making them active low or falling edge),
	//  so we can work assuming that for now.  It also seems to me that we should be
	//  looking at portDDir so that we signal interrupts only on input bits, and not
	//  output bits (as happens with the up/down keys when we go to sleep).)

	uae_u8	portDIntEdge	= READ_REGISTER (portDIntEdge);
	uae_u8	portDData		= READ_REGISTER (portDData);
	uae_u8	portDIntReqEn	= READ_REGISTER (portDIntReqEn);
	uae_u8	newBits			= (gPortDEdge & portDIntEdge | portDData & ~portDIntEdge) & portDIntReqEn;

	// Merge in the new values and write out the result.

	intPendingLo |=	newBits << 8;
	WRITE_REGISTER (intPendingLo, intPendingLo);

	// Respond to the new interrupt state.

	Registers::UpdateInterrupts ();
}


// ---------------------------------------------------------------------------
//		� Registers::UpdateRTCInterrupts
// ---------------------------------------------------------------------------
// Determine whether to set or clear the RTC bit in the interrupt pending
// register based on the current RTC register values.

void Registers::UpdateRTCInterrupts (void)
{
	// See if the RTC is enabled.

	bool	rtcEnabled = (READ_REGISTER (rtcControl) & hwr328RTCControlRTCEnable) != 0;

	// See if there are any RTC events that need to trigger an interrupt.

#define BITS_TO_CHECK				( \
	hwr328RTCIntEnableSec			| \
	hwr328RTCIntEnable24Hr			| \
	hwr328RTCIntEnableAlarm			| \
	hwr328RTCIntEnableMinute		| \
	hwr328RTCIntEnableStopWatch		)

	uae_u16	rtcIntStatus = READ_REGISTER (rtcIntStatus);
	uae_u16	rtcIntEnable = READ_REGISTER (rtcIntEnable);
	uae_u16	rtcIntPending = rtcIntStatus & rtcIntEnable & BITS_TO_CHECK;

	bool	havePendingEvents = rtcIntPending != 0;

	// If the RTC is enabled and there are pending events, set the interrupt.
	// Otherwise, clear the interrupt.

	uae_u16	intPendingLo = READ_REGISTER (intPendingLo);

	if (rtcEnabled && havePendingEvents)
	{
		intPendingLo |= hwr328IntLoRTC;		// have events, so set interrupt
	}
	else
	{	intPendingLo &= ~hwr328IntLoRTC;	// no events, so clear interrupt
	}

	// Update the interrupt pending register.

	WRITE_REGISTER (intPendingLo, intPendingLo);

	// Respond to the new interrupt state.

	Registers::UpdateInterrupts ();
}


// ---------------------------------------------------------------------------
//		� Registers::UpdateSRFromRegisters
// ---------------------------------------------------------------------------
// Updates the status register to reflect the state of the other registers.

void Registers::UpdateSRFromRegisters (void)
{
	// (taken from MakeSR in newcpu.c)

	regs.sr = ((regs.t1 << 15) | (regs.t0 << 14)
			| (regs.s << 13) | (regs.m << 12) | (regs.intmask << 8)
			| (XFLG << 4) | (NFLG << 3) | (ZFLG << 2) | (VFLG << 1) 
			|  CFLG);
}


// ---------------------------------------------------------------------------
//		� Registers::UpdateRegistersFromSR
// ---------------------------------------------------------------------------
// Updates the registers to reflect the state of the status register.

void Registers::UpdateRegistersFromSR (void)
{
	// (taken from MakeFromSR in newcpu.c)
	
	int oldm = regs.m;
	int olds = regs.s;
	
	regs.t1 = (regs.sr >> 15) & 1;
	regs.t0 = (regs.sr >> 14) & 1;
	regs.s = (regs.sr >> 13) & 1;
	regs.m = (regs.sr >> 12) & 1;
	regs.intmask = (regs.sr >> 8) & 7;

	XFLG = (regs.sr >> 4) & 1;
	NFLG = (regs.sr >> 3) & 1;
	ZFLG = (regs.sr >> 2) & 1;
	VFLG = (regs.sr >> 1) & 1;
	CFLG = regs.sr & 1;

	if (olds != regs.s)
	{
		if (olds)
		{
			regs.isp = m68k_areg(regs, 7);
			m68k_areg(regs, 7) = regs.usp;
		}
		else
		{
			regs.usp = m68k_areg(regs, 7);
			m68k_areg(regs, 7) = regs.isp;
		}
	}
	
	regs.spcflags |= SPCFLAG_INT;

	if (regs.t1 || regs.t0)
	{
		regs.spcflags |= SPCFLAG_TRACE;
	}
	else
	{
		regs.spcflags &= ~(SPCFLAG_TRACE | SPCFLAG_DOTRACE);
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Utility::GetFileSize
// ---------------------------------------------------------------------------

long Utility::GetFileSize (FILE* iFile)
{
	// Remember where we started.

	long	originalPosition = ftell (iFile);

	// Scoot to the end.

	if (fseek (iFile, 0, SEEK_END))
	{
		return -1;
	}

	// Get current position, which is the file's size.
	
	long	fileSize = ftell (iFile);

	// Restore our original position.

	if (fseek (iFile, originalPosition, SEEK_SET))
	{
		return -1;
	}

	return fileSize;
}


// ---------------------------------------------------------------------------
//		� Utility::NextPowerOf2
// ---------------------------------------------------------------------------

uae_u32 Utility::NextPowerOf2(uae_u32 x)
{
	// Figure out the next power-of-2 higher than or equal to 'x'. We do
	// this by continually shifting x to the left until we get a '1' in
	// the upper bit. At the same time, we shift 0x80000000 to the left.
	// When we find that '1' in the upper bit, the shifted 0x80000000
	// pattern should hold our power-of-two.
	//
	// That approach is good for finding the next power-of-2 higher than
	// a given value, so in order to deal with the 'or equal to' part
	// of the task, we decrement x by 1 before embarking on this adventure.
	//
	// This function'll fail for x == 0 or x == 1, as well x > 0x80000000,
	// so handle those cases up front:

	if (x > 0x80000000)
		return -1;

	if (x == 0 || x == 1)
		return x;

	--x;

	unsigned long	result = 0x80000000;
	while (((x <<= 1) & 0x80000000) == 0)	// check for the highest set bit.
		result >>= 1;

	return result;
}


// ---------------------------------------------------------------------------
//		� Utility::MemCmpy
// ---------------------------------------------------------------------------
// Copies src to dest, returning whether or not there were any differences
// between the two before the copy was made.
//
// The general approach here is to do a "memcmp" up to the point where a
// difference is noted.  At that point, we change over to doing a "memcpy".
//
// This routine assumes that both src and dest are long-aligned.  It could
// also probably be made simpler by assuming that "len" is a multiple of
// four, since we'll always be using it that way.

bool Utility::MemCmpy(void* dest, const void* src, int len)
{
	// Start comparing 4 bytes at a time. If a difference is
	// found, go to diff4.

	long	len4 = len / 4;			// number of longs
	long	len1 = len - len4 * 4;	// number of leftover bytes

	long*		dest4 = (long*) dest;
	const long*	src4 = (const long*) src;
	char*		dest1;
	const char*	src1;

	while (len4--)
	{
		if(*dest4++ != *src4++)
		{
			// Copy the offending bytes, then jump down to copy the rest.

			dest4[-1] = src4[-1];
			goto diff4;
		}
	}

	// Compare any remaining bytes (less than 4). If a difference
	// is found, go to diff1.

	dest1 = (char*) dest4;
	src1 = (const char*) src4;

	while (len1--)
	{
		if (*dest1++ != *src1++)
		{
			// Copy the offending bytes, then jump down to copy the rest.

			dest1[-1] = src1[-1];
			goto diff1;
		}
	}

	// Return that no differences were found.

	return false;

diff4:
	// A difference has been found. At this point, start doing a memcpy.

	while (len4--)
	{
		*dest4++ = *src4++;
	}

	dest1 = (char*) dest4;
	src1 = (const char*) src4;

diff1:
	// Finish copying the last few bytes (less than 4).

	while (len1--)
	{
		*dest1++ = *src1++;
	}

	// Return that a difference was found.

	return true;
}


// ---------------------------------------------------------------------------
//		� Utility::DateToDays
// ---------------------------------------------------------------------------

static const int	month2days[] =
{
	  0,	 31,	 59,	 90,	120,	151,
	181,	212,	243,	273,	304,	334
};


uae_u32 Utility::DateToDays (uae_u32 year, uae_u32 month, uae_u32 day)
{
	// Normalize the values.

	year -= 1904;
	month -= 1;
	day -= 1;

	// Not counting any possible leap-day in the current year, figure out
	// the number of days between now and 1/1/1904.

	const uae_u32	kNumDaysInLeapCycle = 4 * 365 + 1;

	uae_u32	days =	day + month2days[month] +
					(year * kNumDaysInLeapCycle + 3) / 4;

	// Now add in this year's leap-day, if there is one.

	if ((month >= 2) && ((year & 3) == 0))
		days++;

	return days;
}


// ---------------------------------------------------------------------------
//		� Utility::ReplaceParameter
// ---------------------------------------------------------------------------
// In the string "msg", replace all occurances of "parameter" with
// "replacement".  The origianl "msg" will be deleted with free(), and
// the resulting string will be returned as the function result.  The
// new string will have to be deleted by the caller.

char* Utility::ReplaceParameter (char* msg, const char* parameter, const char* replacement)
{
	while (1)
	{
		// Look for the parameter to replace. If we can't find it, leave.

		char* parameterLocation = strstr (msg, parameter);
		if (parameterLocation == NULL)
			break;

		// Figure out some sizes and lengths.

		size_t	msgSize				= strlen (msg);
		size_t	parameterSize		= strlen (parameter);
		size_t	replacementSize		= strlen (replacement);

		size_t	beforeParameterSize	= parameterLocation - msg;
		size_t	afterParameterSize	= msgSize - parameterSize - beforeParameterSize;

		long	deltaSize = replacementSize - parameterSize;	// amt to _grow_

		// Create the buffer for the new message.  If we can't get
		// it, return with the message thus far built.

		char*	newMsg = (char*) malloc (msgSize + deltaSize + 1);	// Add one for the NULL

		if (newMsg == NULL)
			break;

		// Copy over the part before the parameter.

		memcpy (newMsg, msg, beforeParameterSize);

		// Copy over the replacement string.

		strcpy (newMsg + beforeParameterSize, replacement);

		// Copy over the remaining parts.

		strcat (newMsg, msg + beforeParameterSize + parameterSize);

		// Replace the old string with the new.

		free (msg);
		msg = newMsg;
	}

	return msg;
}


// ---------------------------------------------------------------------------
//		� Utility::ReplaceParameter
// ---------------------------------------------------------------------------
// In the string "msg", replace all occurances of "parameter" with
// "replacement".  The origianl "msg" will be deleted with free(), and
// the resulting string will be returned as the function result.  The
// new string will have to be deleted by the caller.

char* Utility::ReplaceParameter (char* msg, const char* parameter, long replacement)
{
	char	buffer[12];		// max size = strlen("-x,xxx,xxx,xxx"),
							// i.e., 0x80000000 in decimal, plus the last
							// NULL, and with no commas.

	sprintf (buffer, "%ld", replacement);

	return Utility::ReplaceParameter (msg, parameter, buffer);
}


// ---------------------------------------------------------------------------
//		� Utility::GetAppName
// ---------------------------------------------------------------------------
// Get a pointer to the current application's name.  If the name is not
// known, return "Unknown application".  In either case, the returned
// string needs to be deleted by the caller with free().

char* Utility::GetAppName (void)
{
	char*	appName;

	if (strlen (gCurrentApplicationName) > 0)
	{
		size_t	len = strlen (gCurrentApplicationName);
		appName = (char*) malloc (len + 1);	// Add one for the NULL.

		if (appName != NULL)
		{
			strcpy (appName, gCurrentApplicationName);
		}
	}
	else
	{
		appName	= Platform::GetString (kStringCurrentApplication);
	}

	return appName;
}


// ---------------------------------------------------------------------------
//		� Utility::GetAppVersion
// ---------------------------------------------------------------------------
// Get a pointer to the current application's version.  If the version
// cannot be determined, return "(unknown version)".  In either case, the
// returned string needs to be deleted by the caller with free().

char* Utility::GetAppVersion (void)
{
	char*	appVersion;

	if (strlen (gCurrentApplicationVersion) > 0)
	{
		size_t	len = strlen (gCurrentApplicationVersion);
		appVersion = (char*) malloc (len + 1);	// Add one for the NULL.

		if (appVersion != NULL)
		{
			strcpy (appVersion, gCurrentApplicationVersion);
		}
	}
	else
	{
		appVersion	= Platform::GetString (kStringUnknownVersion);
	}

	return appVersion;
}


#pragma mark -

// ---------------------------------------------------------------------------
// Glue function to bridge from UAE-generated code to the implemenations
// we define.
// ---------------------------------------------------------------------------

uaecptr m68k_currentpc(void)				// (normally in newcpu.c)
{
	return m68k_getpc();
}


void customreset (void)
{
	Emulator::Reset ();
}


void Exception(int nr, uaecptr oldpc)
{
#pragma unused (oldpc)	// only needed for pc's better than 68000

	Software::ProcessException (nr);
}


void op_illg (uae_u32 iOpcode)
{
	Software::ProcessIllegalInstruction (iOpcode);
}


bool Software_ProcessRTS ()
{
	return Software::ProcessRTS ();
}

bool Software_ProcessRTE (uae_s32 newpc)
{
	return Software::ProcessRTE (newpc);
}


bool Software_ProcessJSR (uaecptr dest)
{
	return Software::ProcessJSR (dest);
}


void MakeSR (void)
{
	Registers::UpdateSRFromRegisters ();
}


void MakeFromSR (void)
{
	Registers::UpdateRegistersFromSR ();
}

