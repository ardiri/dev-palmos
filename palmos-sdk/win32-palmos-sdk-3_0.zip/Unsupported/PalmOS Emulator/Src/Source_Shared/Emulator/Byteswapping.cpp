/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "Byteswapping.h"


#pragma mark -

#if BYTESWAP

#if defined (_MSC_VER) 

unsigned long	flipBits[] =
{
	/* 0000 -> 0000 */	0x00,
	/* 0001 -> 1000 */	0x08,
	/* 0010 -> 0100 */	0x04,
	/* 0011 -> 1100 */	0x0C,
	/* 0100 -> 0010 */	0x02,
	/* 0101 -> 1010 */	0x0A,
	/* 0110 -> 0110 */	0x06,
	/* 0111 -> 1110 */	0x0E,
	/* 1000 -> 0001 */	0x01,
	/* 1001 -> 1001 */	0x09,
	/* 1010 -> 0101 */	0x05,
	/* 1011 -> 1101 */	0x0D,
	/* 1100 -> 0011 */	0x03,
	/* 1101 -> 1011 */	0x0B,
	/* 1110 -> 0111 */	0x07,
	/* 1111 -> 1111 */	0x0F
};

#endif


void Canonical (BreakpointType& bp)
{
	Canonical (bp.addr);

	Canonical (bp.enabled);
	Canonical (bp.installed);
}


void Canonical (CardHeaderType& cardHdr)
{
	Canonical (cardHdr.initStack);
	Canonical (cardHdr.resetVector);
	Canonical (cardHdr.signature);
	Canonical (cardHdr.hdrVersion);
	Canonical (cardHdr.flags);
	Canonical (cardHdr.version);
	Canonical (cardHdr.creationDate);
	Canonical (cardHdr.numRAMBlocks);
	Canonical (cardHdr.blockListOffset);
	Canonical (cardHdr.readWriteParmsOffset);
	Canonical (cardHdr.readWriteParmsSize);
	Canonical (cardHdr.readOnlyParmsOffset);
	Canonical (cardHdr.bigROMOffset);
	Canonical (cardHdr.checksumBytes);
	Canonical (cardHdr.checksumValue);
	Canonical (cardHdr.version);
}


void Canonical (DatabaseHdrType& db)
{
	Canonical (db.attributes);
	Canonical (db.version);
	Canonical (db.creationDate);
	Canonical (db.modificationDate);
	Canonical (db.lastBackupDate);
	Canonical (db.modificationNumber);
	Canonical (db.appInfoID);
	Canonical (db.sortInfoID);
	Canonical (db.type);
	Canonical (db.creator);
	Canonical (db.uniqueIDSeed);
	Canonical (db.recordList.nextRecordListID);
	Canonical (db.recordList.numRecords);
}


void Canonical (EventType& event)
{
	assert(offsetof(EventType, eType) == 0);
	assert(offsetof(EventType, penDown) == 2);
	assert(offsetof(EventType, screenX) == 4);
	assert(offsetof(EventType, screenY) == 6);
	assert(offsetof(EventType, data) == 8);

	Canonical (event.eType);
	Canonical (event.penDown);
	Canonical (event.screenX);
	Canonical (event.screenY);

	switch(event.eType)
	{
		case nilEvent:
			break;

		case penDownEvent:
			Canonical (event.data.penUp.start);
			Canonical (event.data.penUp.end);
			break;

		case penUpEvent:
			Canonical (event.data.penUp.start);
			Canonical (event.data.penUp.end);
			break;

		case penMoveEvent:
			Canonical (event.data.penUp.start);
			Canonical (event.data.penUp.end);
			break;

		case keyDownEvent:
			Canonical (event.data.keyDown.chr);
			Canonical (event.data.keyDown.keyCode);
			Canonical (event.data.keyDown.modifiers);
			break;

		case winEnterEvent:
			Canonical (event.data.winEnter.enterWindow);
			Canonical (event.data.winEnter.exitWindow);
			break;

		case winExitEvent:
			Canonical (event.data.winExit.enterWindow);
			Canonical (event.data.winExit.exitWindow);
			break;

		case ctlEnterEvent:
			Canonical (event.data.ctlEnter.controlID);
			Canonical (event.data.ctlEnter.pControl);
			break;

		case ctlExitEvent:
			break;

		case ctlSelectEvent:
			Canonical (event.data.ctlSelect.controlID);
			Canonical (event.data.ctlSelect.pControl);
			Canonical (event.data.ctlSelect.on);
			break;

		case ctlRepeatEvent:
			Canonical (event.data.ctlRepeat.controlID);
			Canonical (event.data.ctlRepeat.pControl);
			Canonical (event.data.ctlRepeat.time);
			break;

		case lstEnterEvent:
			Canonical (event.data.lstEnter.listID);
			Canonical (event.data.lstEnter.pList);
			Canonical (event.data.lstEnter.selection);
			break;

		case lstSelectEvent:
			Canonical (event.data.lstSelect.listID);
			Canonical (event.data.lstSelect.pList);
			Canonical (event.data.lstSelect.selection);
			break;

		case lstExitEvent:
			Canonical (event.data.lstExit.listID);
			Canonical (event.data.lstExit.pList);
			break;

		case popSelectEvent:
			Canonical (event.data.popSelect.controlID);
			Canonical (event.data.popSelect.controlP);
			Canonical (event.data.popSelect.listID);
			Canonical (event.data.popSelect.listP);
			Canonical (event.data.popSelect.selection);
			Canonical (event.data.popSelect.priorSelection);
			break;

		case fldEnterEvent:
			Canonical (event.data.fldEnter.fieldID);
			Canonical (event.data.fldEnter.pField);
			break;

		case fldHeightChangedEvent:
			Canonical (event.data.fldHeightChanged.fieldID);
			Canonical (event.data.fldHeightChanged.pField);
			Canonical (event.data.fldHeightChanged.newHeight);
			Canonical (event.data.fldHeightChanged.currentPos);
			break;

		case fldChangedEvent:
			Canonical (event.data.fldChanged.fieldID);
			Canonical (event.data.fldChanged.pField);
			break;

		case tblEnterEvent:
			Canonical (event.data.tblEnter.tableID);
			Canonical (event.data.tblEnter.pTable);
			Canonical (event.data.tblEnter.row);
			Canonical (event.data.tblEnter.column);
			break;

		case tblSelectEvent:
			Canonical (event.data.tblEnter.tableID);
			Canonical (event.data.tblEnter.pTable);
			Canonical (event.data.tblEnter.row);
			Canonical (event.data.tblEnter.column);
			break;

		case daySelectEvent:
			Canonical (event.data.daySelect.pSelector);
			Canonical (event.data.daySelect.selection);
			Canonical (event.data.daySelect.useThisDate);
			break;

		case menuEvent:
			Canonical (event.data.menu.itemID);
			break;

		case appStopEvent:
			break;

		case frmLoadEvent:
			Canonical (event.data.frmLoad.formID);
			break;

		case frmOpenEvent:
			Canonical (event.data.frmOpen.formID);
			break;

		case frmGotoEvent:
			Canonical (event.data.frmGoto.formID);
			Canonical (event.data.frmGoto.recordNum);
			Canonical (event.data.frmGoto.matchPos);
			Canonical (event.data.frmGoto.matchLen);
			Canonical (event.data.frmGoto.matchFieldNum);
			Canonical (event.data.frmGoto.matchCustom);
			break;

		case frmUpdateEvent:
			Canonical (event.data.frmUpdate.formID);
			Canonical (event.data.frmUpdate.updateCode);
			break;

		case frmSaveEvent:
			break;

		case frmCloseEvent:
			Canonical (event.data.frmClose.formID);
			break;

		case frmTitleEnterEvent:
			Canonical (event.data.frmTitleEnter.formID);
			break;

		case frmTitleSelectEvent:
			Canonical (event.data.frmTitleSelect.formID);
			break;

		case tblExitEvent:
			Canonical (event.data.tblExit.tableID);
			Canonical (event.data.tblExit.pTable);
			Canonical (event.data.tblExit.row);
			Canonical (event.data.tblExit.column);
			break;

		case sclEnterEvent:
			Canonical (event.data.sclEnter.scrollBarID);
			Canonical (event.data.sclEnter.pScrollBar);
			break;

		case sclExitEvent:
			Canonical (event.data.sclExit.scrollBarID);
			Canonical (event.data.sclExit.pScrollBar);
			Canonical (event.data.sclExit.value);
			Canonical (event.data.sclExit.newValue);
			break;

		case sclRepeatEvent:
			Canonical (event.data.sclRepeat.scrollBarID);
			Canonical (event.data.sclRepeat.pScrollBar);
			Canonical (event.data.sclRepeat.value);
			Canonical (event.data.sclRepeat.newValue);
			Canonical (event.data.sclRepeat.time);
			break;
	}
}


void Canonical (FieldAttrType& attr)
{
	Canonical (*(unsigned short*) &attr);

	#if defined (_MSC_VER) 
		unsigned short	v = *(unsigned short*) &attr;

		/*
			======== BITFIELD LAYOUT CHEAT-SHEET ========

			typedef struct {
				Word usable			:1;
				Word visible		:1;
				Word editable		:1;
				Word singleLine		:1;
				Word hasFocus       :1;
				Word dynamicSize	:1;
				Word insPtVisible	:1;
				Word dirty			:1;
				Word underlined		:2;
				Word justification	:2;
				Word autoShift		:1;
				Word hasScrollBar	:1;
				Word numeric		:1;
			} FieldAttrType;

			// On the Mac:

			|---------- high byte ----------|---------- low byte -----------|

			 15  14  13  12  11  10   9   8   7   6   5   4   3   2   1   0  
			  7   6   5   4   3   2   1   0   7   6   5   4   3   2   1   0
			+---+---+---+---+---+---+---+---+-------+-------+---+---+---+---+
			| u | v | e | s | h | d | i | d |   u   |   j   | a | h | n | * |
			+---+---+---+---+---+---+---+---+-------+-------+---+---+---+---+


			// On Windows (in-register representation):

			|---------- high byte ----------|---------- low byte -----------|

			 15  14  13  12  11  10   9   8   7   6   5   4   3   2   1   0  
			  7   6   5   4   3   2   1   0   7   6   5   4   3   2   1   0
			+---+---+---+---+-------+-------+---+---+---+---+---+---+---+---+
			| * | n | h | a |   j   |   u   | d | i | d | h | s | e | v | u |
			+---+---+---+---+-------+-------+---+---+---+---+---+---+---+---+
		*/

		v = (flipBits[ (v >>  0) & 0x0F ] << 12) |
			(flipBits[ (v >>  4) & 0x0F ] <<  8) |
			(flipBits[ (v >>  8) & 0x0F ] <<  4) |
			(flipBits[ (v >> 12) & 0x0F ] <<  0);

		*(unsigned short*) &attr = v;
	#endif
}


void Canonical (M68KRegsType& debuggerRegs)
{
	Canonical (debuggerRegs.d[0]);
	Canonical (debuggerRegs.d[1]);
	Canonical (debuggerRegs.d[2]);
	Canonical (debuggerRegs.d[3]);
	Canonical (debuggerRegs.d[4]);
	Canonical (debuggerRegs.d[5]);
	Canonical (debuggerRegs.d[6]);
	Canonical (debuggerRegs.d[7]);

	Canonical (debuggerRegs.a[0]);
	Canonical (debuggerRegs.a[1]);
	Canonical (debuggerRegs.a[2]);
	Canonical (debuggerRegs.a[3]);
	Canonical (debuggerRegs.a[4]);
	Canonical (debuggerRegs.a[5]);
	Canonical (debuggerRegs.a[6]);
//	Canonical (debuggerRegs.a[7]);

	Canonical (debuggerRegs.usp);
	Canonical (debuggerRegs.ssp);
	Canonical (debuggerRegs.sr);
	Canonical (debuggerRegs.pc);
}


void Canonical (Point& p)
{
	Canonical (p.h);
	Canonical (p.v);
}


void Canonical (PointType& p)
{
	Canonical (p.x);
	Canonical (p.y);
}


void Canonical (RecordEntryType& entry)
{
	Canonical (entry.localChunkID);
	Canonical (entry.attributes);
//	Canonical (entry.uniqueID);	// array of 3 bytes
}


void Canonical (RectangleType& r)
{
	Canonical (r.topLeft);
	Canonical (r.extent);
}


void Canonical (RsrcEntryType& entry)
{
	Canonical (entry.type);
	Canonical (entry.id);
	Canonical (entry.localChunkID);
}


void Canonical (SlkPktHeaderType& hdr)
{
	Canonical (hdr.signature1);
	Canonical (hdr.signature2);
	Canonical (hdr.dest);
	Canonical (hdr.src);
	Canonical (hdr.type);
	Canonical (hdr.bodySize);
	Canonical (hdr.transId);
	Canonical (hdr.checksum);
}


void Canonical (SysNVParamsType& params)
{
	Canonical (params.rtcHours);
	Canonical (params.rtcHourMinSecCopy);
}


void Canonical (SysPktBodyType& packet)
{
	Canonical (packet.command);

	switch (packet.command)
	{
		case sysPktStateCmd:
			Canonical ((SysPktStateCmdType&) packet);
			break;

		case sysPktStateRsp:
			Canonical ((SysPktStateRspType&) packet);
			break;

		case sysPktReadMemCmd:
			Canonical ((SysPktReadMemCmdType&) packet);
			break;

		case sysPktWriteMemCmd:
			Canonical ((SysPktWriteMemCmdType&) packet);
			break;

		case sysPktSingleStepCmd:
			// I don't think there's anything to do here.  I think that
			// single-stepping is performed by the debugger setting the
			// trace bit in the SR and sending a sysPktContinueCmd.
			break;

		case sysPktGetRtnNameCmd:
			Canonical ((SysPktRtnNameCmdType&) packet);
			break;

		case sysPktReadRegsCmd:
			Canonical ((SysPktReadRegsCmdType&) packet);
			break;

		case sysPktWriteRegsCmd:
			Canonical ((SysPktWriteRegsCmdType&) packet);
			break;

		case sysPktContinueCmd:
			Canonical ((SysPktContinueCmdType&) packet);
			break;

		case sysPktRPCCmd:
			Canonical ((SysPktRPCType&) packet);
			break;

		case sysPktGetBreakpointsCmd:
			Canonical ((SysPktGetBreakpointsCmdType&) packet);
			break;

		case sysPktSetBreakpointsCmd:
			Canonical ((SysPktSetBreakpointsCmdType2&) packet);
			break;

//		case sysPktRemoteUIUpdCmd:
//			// Sent TO debugger; never received FROM debugger.
//			break;

//		case sysPktRemoteEvtCmd:
//			// Sent TO debugger; never received FROM debugger.
//			break;

		case sysPktDbgBreakToggleCmd:
			Canonical ((SysPktDbgBreakToggleCmdType&) packet);
			break;

		case sysPktFlashCmd:
			// Not supported in this release.
			break;

		case sysPktCommCmd:
			// Not supported in this release.
			break;

		case sysPktGetTrapBreaksCmd:
			Canonical ((SysPktGetTrapBreaksCmdType&) packet);
			break;

		case sysPktSetTrapBreaksCmd:
			Canonical ((SysPktSetTrapBreaksCmdType2&) packet);
			break;

		case sysPktGremlinsCmd:
			// !!! TBD.
			break;

		case sysPktFindCmd:
			Canonical ((SysPktFindCmdType&) packet);
			break;

		case sysPktGetTrapConditionsCmd:
			Canonical ((SysPktGetTrapConditionsCmdType&) packet);
			break;

		case sysPktSetTrapConditionsCmd:
			Canonical ((SysPktSetTrapConditionsCmdType2&) packet);
			break;

		case sysPktChecksumCmd:
			// Not supported in this release.
			break;

		case sysPktExecFlashCmd:
			// Not supported in this release.
			break;

		case sysPktRemoteMsgCmd:
			// Nothing for us to do.  With a serial link,
			// these are sent to clear the input port.
			break;

		default:
			break;
	}
}


void Canonical (SysPktContinueCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.regs);
	Canonical (packet.stepSpy);
	Canonical (packet.ssAddr);
	Canonical (packet.ssCount);
	Canonical (packet.ssCheckSum);
}


void Canonical (SysPktDbgBreakToggleCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktFindCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.firstAddr);
	Canonical (packet.lastAddr);
	Canonical (packet.numBytes);
	Canonical (packet.caseInsensitive);
}


void Canonical (SysPktFindRspType& packet)
{
	Canonical (packet.command);

	Canonical (packet.addr);
	Canonical (packet.found);
}


void Canonical (SysPktGetBreakpointsCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktGetBreakpointsRspType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalBreakpoints; ++ii)
		Canonical (packet.bp[ii]);
}


void Canonical (SysPktGetTrapBreaksCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktGetTrapBreaksRspType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
		Canonical (packet.trapBP[ii]);
}


void Canonical (SysPktGetTrapConditionsCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktGetTrapConditionsRspType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
		Canonical (packet.trapParam[ii]);
}


void Canonical (SysPktReadMemCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.address);
	Canonical (packet.numBytes);
}


void Canonical (SysPktReadRegsCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktReadRegsRspType2& packet)
{
	Canonical (packet.command);

	Canonical (packet.reg);
}


void Canonical (SysPktRPCType& packet)
{
	Canonical (packet.command);

	Canonical (packet.trapWord);
	Canonical (packet.resultD0);
	Canonical (packet.resultA0);
	Canonical (packet.numParams);

	// Nothing really to do with the "param" field.  "byRef" and "size"
	// are bytes, so nothing to swap there, and the "data" field is
	// of indeterminate size, so we can't bytewap it either.  That means
	// that we must take care to always treat it as a big-endian value.	
}


void Canonical (SysPktRtnNameCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.address);
}


void Canonical (SysPktRtnNameRspType& packet)
{
	Canonical (packet.command);

	Canonical (packet.address);
	Canonical (packet.startAddr);
	Canonical (packet.endAddr);
}


void Canonical (SysPktSetBreakpointsCmdType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalBreakpoints; ++ii)
		Canonical (packet.bp[ii]);
}


void Canonical (SysPktSetTrapBreaksCmdType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
		Canonical (packet.trapBP[ii]);
}


void Canonical (SysPktSetTrapConditionsCmdType2& packet)
{
	Canonical (packet.command);

	for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
		Canonical (packet.trapParam[ii]);
}


void Canonical (SysPktStateCmdType& packet)
{
	Canonical (packet.command);
}


void Canonical (SysPktStateRspType& packet)
{
	Canonical (packet.command);

	Canonical (packet.resetted);
	Canonical (packet.exceptionId);
	Canonical (packet.reg);

	int ii;
	for (ii = 0; ii < dbgTotalBreakpoints; ++ii)
		Canonical (packet.bp[ii]);

	for (ii = 0; ii < sysPktStateRspInstWords; ++ii)
		Canonical (packet.inst[ii]);

	Canonical (packet.startAddr);
	Canonical (packet.endAddr);
	Canonical (packet.trapTableRev);	
}


void Canonical (SysPktWriteRegsCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.reg);
}


void Canonical (SysPktWriteMemCmdType& packet)
{
	Canonical (packet.command);

	Canonical (packet.address);
	Canonical (packet.numBytes);
}

#endif	// BYTESWAP
