/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "LoadApplication.h"
#include "ROMStubs.h"
#include "Byteswapping.h"

#include "Platform.h"			// ThrowNotify_Always, kError_CantOpenAppFile, etc


/************************************************************
 *
 *  FUNCTION: DmCreateDatabaseFromImage
 *
 *  DESCRIPTION: Can be called to create an entire database
 *			from a single resource that contains in image of the database. 
 *			Usually, this would be called from an app's reset action code during
 *			boot.
 *
 *  PARAMETERS: 
 *			bufferP - pointer to locked resource containing image of the database
 *
 *  RETURNS: void
 *
 *  CREATED: 3/13/95
 *
 *  BY: Ron Marianetti
 *
 *		vmk	12/29/97	Fixed to return non-zero error code in case of failure
 *
 *************************************************************/

static Err	My_DmCreateDatabaseFromImage(Ptr bufferP, UInt32 size)
{
	LocalID			dbID=0;
	DmOpenRef		dbP=0;
	Err				err = 0;
	BytePtr			srcP;
	BytePtr			dstP;
	DatabaseHdrPtr	hdrP = (DatabaseHdrPtr)bufferP;
	UInt				i;
	DWord				uniqueIDSeed;

	DmAccessPtr		dbP2;
	DmOpenInfoPtr	openP2;
	DatabaseHdrPtr	hdrP2;

	Canonical(*hdrP);	// Now in little-endian format

	// Get the size and create it
	err = DmCreateDatabase(0, (CharPtr)hdrP->name, hdrP->creator, hdrP->type, 
						hdrP->attributes & dmHdrAttrResDB);
	if (err)
		goto Exit;

	// Set Database info
	dbID = DmFindDatabase(0, (CharPtr)hdrP->name);
	if (!dbID) {
		err = dmErrCantFind;
		goto Exit;
		}

	err = DmSetDatabaseInfo(0, dbID, 0,
				&hdrP->attributes, &hdrP->version, &hdrP->creationDate,
				&hdrP->modificationDate, &hdrP->lastBackupDate,
				&hdrP->modificationNumber, 0,
				0, &hdrP->type,
				&hdrP->creator);

	if (err)
		goto Exit;
	
	
	
	// Open the new database
	dbP = DmOpenDatabase(0, dbID, dmModeReadWrite);
	if (!dbP) {
		err = dmErrCantOpen;
		goto Exit;
		}

	// The new database has been created with a random number in it.
	// We don't want the records copied into the new database to have
	// different unique id's between each hard reset or else the records
	// with the same contents but with different unique id's will appear
	// distinct to HotSync and so will accumulate with hard resets and syncs.
	// To stop this behavior we always set the seed to a constant number,
	// copy the records into the new database, and then we restore the
	// random seed.
	MemSemaphoreReserve(true);
//	uniqueIDSeed = ((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed;
//	((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed = dmDefaultRecordsID << 12;
	dbP2	= (DmAccessPtr) get_real_address((uaecptr) dbP);
	openP2	= (DmOpenInfoPtr) get_real_address(do_get_mem_long(&dbP2->openP));
	hdrP2	= (DatabaseHdrPtr) get_real_address(do_get_mem_long(&openP2->hdrP));
	uniqueIDSeed = hdrP2->uniqueIDSeed;
	do_put_mem_long(&hdrP2->uniqueIDSeed, dmDefaultRecordsID << 12);
	MemSemaphoreRelease(true);

	//------------------------------------------------------------
	// If it's a resource database, Add the Resources
	//------------------------------------------------------------
	if (hdrP->attributes & dmHdrAttrResDB) {
		RsrcEntryPtr	rsrcP;
		ULong				resSize;
		Handle			newResH;

		// Byteswap the resource entry headers

		rsrcP  = (RsrcEntryPtr)(&hdrP->recordList.firstEntry);
		for (i=0; i<hdrP->recordList.numRecords; i++)
		{
			Canonical(*rsrcP);
			rsrcP++;
		}

		// Pointer to first resource
		rsrcP  = (RsrcEntryPtr)(&hdrP->recordList.firstEntry);
		for (i=0; i<hdrP->recordList.numRecords; i++) {
		
			// Calculate the size of the resource
			if (i < hdrP->recordList.numRecords - 1) {
				resSize = (ULong)rsrcP[1].localChunkID;
				resSize -= (ULong)rsrcP[0].localChunkID;
				}
			else
				resSize = size - (ULong)rsrcP[0].localChunkID;
			

			// Allocate the new resource
			newResH = (Handle) DmNewResource(dbP, rsrcP->type, rsrcP->id, resSize);
			if (!newResH) {
				err = dmErrMemError;
				goto Exit;
				}
	
			// Copy the data in
			srcP = (BytePtr)bufferP + (ULong)rsrcP->localChunkID;
			dstP = (BytePtr)MemHandleLock((VoidHand) newResH);
			DmWrite(dstP, 0, srcP, resSize);
			MemHandleUnlock((VoidHand) newResH);

			// Done with it
			DmReleaseResource((VoidHand) newResH);

			// next one
			rsrcP++;
			}
		}



	//------------------------------------------------------------
	// If it's a Record database, Add the Records
	//------------------------------------------------------------
	else {
		Handle			newRecH;
		RecordEntryPtr	recordP;
		ULong				recSize;
		LocalID			appInfoID;

		// Byteswap the record entry headers

		recordP  = (RecordEntryPtr)(&hdrP->recordList.firstEntry);
		for (i=0; i<hdrP->recordList.numRecords; i++)
		{
			Canonical (*recordP);
			recordP++;
		}

		// Pointer to first record
		recordP  = (RecordEntryPtr)(&hdrP->recordList.firstEntry);
		

		// If there's an appInfo, add that
		if (hdrP->appInfoID) {
			if (hdrP->sortInfoID) recSize = (ULong)hdrP->sortInfoID - (ULong)hdrP->appInfoID;
			else recSize = (ULong)recordP[0].localChunkID - (ULong)hdrP->appInfoID;

			// Allocate the chunk
			newRecH = (Handle)DmNewHandle(dbP, recSize);
			if (!newRecH) {
				err = dmErrMemError;
				goto Exit;
				}

			// Copy the data in
			srcP = (BytePtr)bufferP + (ULong)hdrP->appInfoID;
			dstP = (BytePtr)MemHandleLock((VoidHand) newRecH);
			DmWrite(dstP, 0, srcP, recSize);
			MemHandleUnlock((VoidHand) newRecH);

			// Store it in the header
			appInfoID = MemHandleToLocalID((VoidHand) newRecH);
			DmSetDatabaseInfo(0, dbID, 0,
				0, 0, 0,
				0, 0,
				0, &appInfoID,
				0, 0, 
				0);
			}



		// Add Each of the records.
		for (i=0; i<hdrP->recordList.numRecords; i++) {
			UInt		index;
			UInt		attr;
			ULong		id;

			// Calculate the size of the record
			if (i < hdrP->recordList.numRecords - 1) {
				recSize = (ULong)recordP[1].localChunkID;
				recSize -= (ULong)recordP[0].localChunkID;
				}
			else
				recSize = size - (ULong)recordP[0].localChunkID;


			// Only add non-nil records. When the default databases are created
			//  they sometimes have nil records if the user had to delete a
			//  record they didn't want.
			if (recSize) {
				// Allocate the new record
				index = 0xFFFF;
				newRecH = (Handle)DmNewRecord(dbP, &index, recSize);
				if (!newRecH) {
				err = dmErrMemError;
				goto Exit;
				}

				// Copy the data in
				srcP = (BytePtr)bufferP + (ULong)recordP->localChunkID;
				dstP = (BytePtr)MemHandleLock((VoidHand) newRecH);
				DmWrite(dstP, 0, srcP, recSize);
				MemHandleUnlock((VoidHand) newRecH);

				// Set the attributes
				attr = recordP->attributes;
				id = recordP->uniqueID[0];
				id = (id << 8) | recordP->uniqueID[1];
				id = (id << 8) | recordP->uniqueID[2];
				DmSetRecordInfo(dbP, index, &attr, &id);

				// Done with it
				DmReleaseRecord(dbP, index, true);
				}

			// next one
			recordP++;
			}
		}


		// Fixup the modification # to match what was in the image.
	DmSetDatabaseInfo(0, dbID, 0,
				0, 0,0,
				0, 0,
				&hdrP->modificationNumber, 0,
				0, 0,
				0);


	// Restore the database's uniqueIDSeed to it's random value.
	MemSemaphoreReserve(true);
//	((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed = uniqueIDSeed;
	// (Refresh the pointers; they may have changed since we initialized them.)
	dbP2	= (DmAccessPtr) get_real_address((uaecptr) dbP);
	openP2	= (DmOpenInfoPtr) get_real_address(do_get_mem_long(&dbP2->openP));
	hdrP2	= (DatabaseHdrPtr) get_real_address(do_get_mem_long(&openP2->hdrP));
	hdrP2->uniqueIDSeed = uniqueIDSeed;
	MemSemaphoreRelease(true);

	// If we got to here, no error 
	DmCloseDatabase(dbP);
	dbP = 0;


Exit:
	if (dbP) {
		DmCloseDatabase(dbP);
		if (dbID)
			DmDeleteDatabase(0, dbID);
		}
		
	return err;
}


// ---------------------------------------------------------------------------
//		� LoadApplication
// ---------------------------------------------------------------------------
// Loads a Palm OS program or database file into the emulator.

bool LoadApplication (FILE* iApplicationFile)
{
	bool	result = false;
	Ptr		aFileBuffer = NULL;

	try
	{
		// Get the size of the file.

		uae_s32	aFileSize = Utility::GetFileSize (iApplicationFile);
		if (aFileSize == -1)
		{
			ThrowNotify_Always (kError_CantOpenAppFile, errno);
		}

		// Create a buffer to hold the file data.

		aFileBuffer = (Ptr) malloc (aFileSize);
		ThrowNotify_IfNil (aFileBuffer, kError_NotEnoughMemoryForAppFile, kDefaultException);

		// Load the file into memory.

		if ( fread(aFileBuffer, aFileSize, 1, iApplicationFile) != 1 )
		{
			ThrowNotify_Always (kError_CantLoadAppFile, errno);
		}

		// Let the emulated ROM access the memory in the file buffer.

		Memory::MapPhysicalMemory((uae_u8*) aFileBuffer, aFileSize);

		// See if there's already a database with this name.

		uae_u32 aDatabaseID = DmFindDatabase(0, aFileBuffer);

		// If the database already exists, delete it.

		if (aDatabaseID != 0)
		{
			Err	err = DmDeleteDatabase(0, aDatabaseID);

			if (err == dmErrDatabaseOpen)
			{
				ThrowNotify_Always (kError_AppFileDatabaseOpen, kDefaultException);
			}

			else if (err == dmErrROMBased)
			{
				// This one's OK
			}

			else if (err == memErrNotEnoughSpace)
			{
				ThrowNotify_Always (kError_AppFileIsTooLarge, kDefaultException);
			}

			else
			{
				ThrowNotify_IfError (err, kError_AppFileDatabaseError, err);
			}
		}

		// Create the new database.

		Err	aError = My_DmCreateDatabaseFromImage(aFileBuffer, aFileSize);
		ThrowNotify_IfError (aError, kError_AppFileDatabaseError, aError);

		result = true;	// successfully loaded!
	}
	catch (...)
	{
	}

	Memory::UnmapPhysicalMemory((uae_u8*) aFileBuffer);

	free (aFileBuffer);

	return result;
}


