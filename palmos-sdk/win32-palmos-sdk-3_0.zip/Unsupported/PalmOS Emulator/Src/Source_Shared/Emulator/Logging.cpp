#include "Switches.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#include "Platform.h"		// GetMilliseconds

extern void PRINTF (const char* msg, ...);


#if defined (__MACOS__)

// We have a separate set of routines for the Mac instead of just using
// vanilla stdio calls so that we can write to the file during "times of
// inopportunity", like in async callback functions.

#include <Errors.h>
#include <Files.h>
#include <Timer.h>

static short	gLogFileRefNum;

static void EnsureLogFileOpened (void)
{
	if (!gLogFileRefNum)
	{
		OSErr	err;
		FSSpec	spec;

		err = FSMakeFSSpec (0, 0, "\pLog File", &spec);

		err = FSpCreate (&spec, 'CWIE', 'TEXT', smSystemScript);

		if (!err || err == dupFNErr)
		{
			err = FSpOpenDF (&spec, fsRdWrPerm, &gLogFileRefNum);
			
			if (!err)
				err = SetEOF (gLogFileRefNum, 0);
		}
	}
}



static void DoPrintf (const char* msg)
{
	EnsureLogFileOpened ();

	if (gLogFileRefNum)
	{
		char			buffer[200];
		char*			p;
		int				neg;
		long			count;

		UnsignedWide	now;
		Microseconds (&now);

		p = &buffer[200];
		*--p = '\0';

		neg = now.lo < 0;
		if (neg)
			now.lo = -now.lo;
		
		while (now.lo)
		{
			int	dig = now.lo % 10;
			*--p = dig + '0';
			now.lo /= 10;
		}

		if (p == &buffer[199])
			*--p = '0';

		if (neg)
			*--p = '-';

		strcpy (buffer, p);
		strcat (buffer, ": ");
		strcat (buffer, msg);
		strcat (buffer, "\x0D");

		count = strlen (buffer);
		FSWrite (gLogFileRefNum, &count, buffer);

		FlushVol (0, 0);
	}
}

#endif

#if defined (_WINDOWS)

static FILE*	gLogFile;

static void EnsureLogFileOpened (void)
{
	if (gLogFile == NULL)
	{
		gLogFile = fopen ("Log File", "w");
	}
}



static void DoPrintf (const char* msg)
{
	EnsureLogFileOpened ();

	if (gLogFile)
	{
		uae_u32		now = Platform::GetMilliseconds ();

		fprintf (gLogFile, "%ld: %s\n", now, msg);
		fflush (gLogFile);
	}
}

#endif

void PRINTF (const char* format, ...)
{
	va_list	arg;
	char	buffer[200];

	va_start (arg, format);

	vsprintf (buffer, format, arg);

	// debug check, watch for buffer overflows here
	if (strlen(buffer) >= 200)
		Platform::Debugger();

	DoPrintf (buffer);

	va_end (arg);
}
