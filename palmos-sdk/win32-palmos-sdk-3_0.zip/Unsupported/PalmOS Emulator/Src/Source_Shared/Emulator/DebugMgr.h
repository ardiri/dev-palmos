/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"
#include "UAE.h"			// uae_s32, etc.
#include "Palm.h"			// BreakpointType, SlkPktHeaderType, SysPktBodyType
#include "CPU_Reg.h"		// kException_Trace

// Types

#pragma mark Types

struct DebugGlobalsType
{
	// Mode settings

	bool			inDebugger;						// true if in debug mode
	bool			ignoreDbgBreaks;				// if true, ignore DbgBreak's
	bool			reEntered;						// true if we re-entered
	bool			firstEntrance;					// true first time we enter debugger
	bool			stepSpy;						// true if step spying.
	bool			breakingOnATrap;				// true if there are A-Traps to check
	bool			continuing;						// if true, restarting the CPU
													// after some sort of break, so
													// don't do A-Trap or BP stuff.

	// Breakpoints and saved opcodes behind each one

	BreakpointType	bp[dbgTotalBreakpoints];
	uae_u16			bpOpcode[dbgTotalBreakpoints];

	// Current trap breaks

	Word			trapBreak[dbgTotalTrapBreaks];
	Word			trapParam[dbgTotalTrapBreaks];

	// Step spy support

	uaecptr			ssAddr;							// address to step spy on 
	DWord			ssValue;						// saved value

	// Exception type

	uae_s32			excType;						// why we entered debugger
};


// For reasons of "convenience", the official type declarations for these
// packets omits their bodies.  For the emulator, we'd really like to have
// the bodies, so we declare these parallel types.

struct SysPktReadRegsRspType2
{
	_sysPktBodyCommon;								// Common Body header
	M68KRegsType	reg;							// <- return registers
};

struct SysPktGetBreakpointsRspType2
{
	_sysPktBodyCommon;								// Common Body header
	BreakpointType	bp[dbgTotalBreakpoints];
};

struct SysPktSetBreakpointsCmdType2
{
	_sysPktBodyCommon;								// Common Body header
	BreakpointType	bp[dbgTotalBreakpoints];
};

struct SysPktGetTrapBreaksRspType2
{
	_sysPktBodyCommon;								// Common Body header
	Word		trapBP[dbgTotalTrapBreaks];
};

struct SysPktSetTrapBreaksCmdType2
{
	_sysPktBodyCommon;								// Common Body header
	Word		trapBP[dbgTotalTrapBreaks];
};

struct SysPktGetTrapConditionsRspType2
{
	_sysPktBodyCommon;								// Common Body header
	Word		trapParam[dbgTotalTrapBreaks];
};

struct SysPktSetTrapConditionsCmdType2
{
	_sysPktBodyCommon;								// Common Body header
	Word		trapParam[dbgTotalTrapBreaks];
};

// Globals

#pragma mark Globals

extern DebugGlobalsType	gDebuggerGlobals;


// class Debug

#pragma mark class Debug

class Debug
{
	public:
		static void		Initialize			(void);
		static void		Reset				(void);
		static uae_u32	HandleNewPacket		(const SlkPktHeaderType& header,
											 const SysPktBodyType& pkt);
		static uae_u32	SendPacket			(const void* pkt, long size);
		static uae_u32	SendResponse		(int rsp);
		static bool		BreakIfConnected	(uae_s32 exceptionNumber);
		static bool		HandleTrap8			(uae_s32 exceptionNumber);
		static bool		HandleTrap15		(void);
		static uae_u32	EnterDebugger		(uae_s32 reason);
		static uae_u32	ExitDebugger		(void);
		static bool		InDebugger			(void);
		static void		CheckStepSpy		(void);

		static void		InstallBreakpoints	(void);
		static void		RemoveBreakpoints	(void);

	private:
		static uae_u32	SendState			(void);
		static uae_u32	ReadMem				(SysPktReadMemCmdType&);
		static uae_u32	WriteMem			(SysPktWriteMemCmdType&);
		static uae_u32	SendRoutineName		(SysPktRtnNameCmdType&);
		static uae_u32	ReadRegs			(SysPktReadRegsCmdType&);
		static uae_u32	WriteRegs			(SysPktWriteRegsCmdType&);
		static uae_u32	Continue			(SysPktContinueCmdType&);
		static uae_u32	RPC					(SysPktRPCType&);
		static uae_u32	GetBreakpoints		(SysPktGetBreakpointsCmdType&);
		static uae_u32	SetBreakpoints		(SysPktSetBreakpointsCmdType2&);
		static uae_u32	ToggleBreak			(SysPktDbgBreakToggleCmdType&);
		static uae_u32	GetTrapBreaks		(SysPktGetTrapBreaksCmdType&);
		static uae_u32	SetTrapBreaks		(SysPktSetTrapBreaksCmdType2&);
		static uae_u32	Find				(SysPktFindCmdType&);
		static uae_u32	GetTrapConditions	(SysPktGetTrapConditionsCmdType&);
		static uae_u32	SetTrapConditions	(SysPktSetTrapConditionsCmdType2&);

		static Err		GetRoutineName		(uaecptr addr,
											 char* nameP, 
											 uaecptr* startAddrP,
											 uaecptr* endAddrP);
		static void		GetRegs				(M68KRegsType&);
		static void		SetRegs				(const M68KRegsType&);
};


// This function is called from the RAM setter functions. Make it inline so
// that the common case where stepSpy == FALSE executes quickly.  Yes, this
// _does_ make a difference.

inline void Debug::CheckStepSpy (void)
{
	if (gDebuggerGlobals.stepSpy)
	{
		if (get_long (gDebuggerGlobals.ssAddr) != gDebuggerGlobals.ssValue)
		{
			Emulator::SetBreakReason (kException_Trace);
		}
	}
}

