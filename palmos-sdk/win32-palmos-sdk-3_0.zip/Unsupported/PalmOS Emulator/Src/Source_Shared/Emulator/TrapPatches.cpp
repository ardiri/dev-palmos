/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "TrapPatches.h"

#include "UAE.h"
#include "Palm.h"
#include "CPU_REG.h"		// LowMem_GetEvtMgrIdle, LowMem_TrapExists, gKeyQueue, Utility_DateToDays
#include "Platform.h"		// Platform::GetDate
#include "UAE_Utils.h"		// uae_memmove, uae_memset
#include "StringData.h"		// kTrapNames

#include "Gremlins.h"
#include "CGremlinsStubs.h"	// StubAppEnqueueKey

#include <stddef.h>			// offsetof

#if __profile__
#include <Profiler.h>
#endif


// Types

#pragma mark Types

// Structure used to hold tail-patch information.

struct TailpatchType
{
	uaecptr		fPC;
	uae_u16		fOldOpcode;
	uae_s32		fCount;
};


// Snippet we need from SysUtils.h

typedef enum
	{
	GremlinIsOn				// return non zero if gremlins is currently running
	} GremlinFunctionType;
	


const uae_u16	kOpcode_Tailpatch	= m68kTrapInstr + kATrapTailpatchTrapNum;


// Globals

#pragma mark Globals

HeadpatchProc	gHeadpatches[sysNumTraps];
TailpatchProc	gTailpatches[sysNumTraps];

uae_u16			gLastEvtTrap;
AbsRectType		gScreen_UpdateRect;

const int		kMaxInstalledTailpatches = 10;
TailpatchType	gInstalledTailpatches[kMaxInstalledTailpatches];

bool			gUIInitialized;
bool			gSysDozing;
bool			gSysSleeping;

char			gCurrentApplicationName[dmDBNameLength];
char			gCurrentApplicationVersion[256];	// <gulp> I hope this is big enough...


// Private Functions

#pragma mark Private Functions

static int ErrDisplayAndSysFatalAlertCommon (const char* msg);


class Headpatch
{
	public:
		static bool		RecordTrapNumber		(void);

		static bool		ErrDisplayFileLineMsg	(void);
		static bool		KeyCurrentState			(void);
		static bool		MemMove					(void);
		static bool		MemSet					(void);
		static bool		PenGetRawPen			(void);
		static bool		PenOpen					(void);
		static bool		RctPtInRectangle		(void);
		static bool		ScrDrawNotify			(void);
		static bool		SysEvGroupWait			(void);
		static bool		SysDoze					(void);
		static bool		SysFatalAlert			(void);
		static bool		SysGremlins				(void);
		static bool		SysLaunchConsole		(void);
		static bool		SysSleep				(void);
		static bool		SysUIAppSwitch			(void);
		static bool		SysUIBusy				(void);
		static bool		TimInit					(void);
};


class Tailpatch
{
	public:
		static void		EvtGetEvent				(void);
		static void		EvtGetPen				(void);
		static void		ScrInit					(void);
		static void		SysDoze					(void);
		static void		SysSleep				(void);
		static void		UIInitialize			(void);
		static void		TimInit					(void);
};

typedef bool	(*WalkerProc)(VoidPtr chunkP, int ver, void* userData);

bool	FindAllAppChunks (VoidPtr chunkP, int ver, void* userData);
void	WalkHeap (WalkerProc fn, void* userData);


#pragma mark -
#pragma mark --- Diagnostics ---

// ---------------------------------------------------------------------------
//		� Diagnostics
// ---------------------------------------------------------------------------

#if LOG_PATCHES

extern void PRINTF (const char* msg, ...);

#else

inline void PRINTF (const char*) {}
template <class T1> inline void PRINTF (const char*, T1) {}
template <class T1, class T2> inline void PRINTF (const char*, T1, T2) {}
template <class T1, class T2, class T3> inline void PRINTF (const char*, T1, T2, T3) {}

#endif


#pragma mark -

// ---------------------------------------------------------------------------
//		� Patches::Initialize
// ---------------------------------------------------------------------------

void Patches::Initialize (void)
{
	InstallHeadpatch (sysTrapEvtGetEvent,			Headpatch::RecordTrapNumber);
	InstallHeadpatch (sysTrapEvtGetPen,				Headpatch::RecordTrapNumber);
	InstallHeadpatch (sysTrapErrDisplayFileLineMsg,	Headpatch::ErrDisplayFileLineMsg);
	InstallHeadpatch (sysTrapKeyCurrentState,		Headpatch::KeyCurrentState);
#if !HAS_PROFILING
	InstallHeadpatch (sysTrapMemMove,				Headpatch::MemMove);
	InstallHeadpatch (sysTrapMemSet,				Headpatch::MemSet);
#endif
	InstallHeadpatch (sysTrapPenGetRawPen,			Headpatch::PenGetRawPen);
#if !TIME_STARTUP
	InstallHeadpatch (sysTrapPenOpen,				Headpatch::PenOpen);
#endif
#if !HAS_PROFILING
	InstallHeadpatch (sysTrapRctPtInRectangle,		Headpatch::RctPtInRectangle);
	InstallHeadpatch (sysTrapScrDrawNotify,			Headpatch::ScrDrawNotify);
#endif
	InstallHeadpatch (sysTrapSysEvGroupWait,		Headpatch::SysEvGroupWait);
	InstallHeadpatch (sysTrapSysDoze,				Headpatch::SysDoze);
	InstallHeadpatch (sysTrapSysFatalAlert,			Headpatch::SysFatalAlert);
	InstallHeadpatch (sysTrapSysGremlins,			Headpatch::SysGremlins);
	InstallHeadpatch (sysTrapSysLaunchConsole,		Headpatch::SysLaunchConsole);
	InstallHeadpatch (sysTrapSysSleep,				Headpatch::SysSleep);
	InstallHeadpatch (sysTrapSysUIAppSwitch,		Headpatch::SysUIAppSwitch);
#if TIME_STARTUP
	InstallHeadpatch (sysTrapSysUIBusy,				Headpatch::SysUIBusy);
#endif
	InstallHeadpatch (sysTrapTimInit,				Headpatch::TimInit);

	InstallTailpatch (sysTrapEvtGetEvent,			Tailpatch::EvtGetEvent);
	InstallTailpatch (sysTrapEvtGetPen,				Tailpatch::EvtGetPen);
//	InstallTailpatch (sysTrapScrInit,				Tailpatch::ScrInit);
	InstallTailpatch (sysTrapSysDoze,				Tailpatch::SysDoze);
	InstallTailpatch (sysTrapSysSleep,				Tailpatch::SysSleep);
	InstallTailpatch (sysTrapUIInitialize,			Tailpatch::UIInitialize);
	InstallTailpatch (sysTrapTimInit,				Tailpatch::TimInit);
}


// ---------------------------------------------------------------------------
//		� Patches::Reset
// ---------------------------------------------------------------------------

void Patches::Reset (void)
{
	Patches::RemoveAllTailpatches ();

	for (int ii = 0; ii < kMaxInstalledTailpatches; ++ii)
	{
		gInstalledTailpatches[ii].fPC = NULL;
		gInstalledTailpatches[ii].fCount = 0;
	}

	gUIInitialized = false;
	gSysDozing = false;
	gSysSleeping = false;
}


// ---------------------------------------------------------------------------
//		� Patches::InstallHeadpatch
// ---------------------------------------------------------------------------

void Patches::InstallHeadpatch (uae_u16 trapNum, HeadpatchProc fn)
{
	gHeadpatches[ TrapIndex (trapNum) ] = fn;
}


// ---------------------------------------------------------------------------
//		� Patches::InstallTailpatch
// ---------------------------------------------------------------------------

void Patches::InstallTailpatch (uae_u16 trapNum, TailpatchProc fn)
{
	gTailpatches[ TrapIndex (trapNum) ] = fn;
}


// ---------------------------------------------------------------------------
//		� Patches::HandleTrap15
// ---------------------------------------------------------------------------
// If this is a trap we could possibly have head- or tail-patched,
// handle those cases.

bool Patches::HandleTrap15 (void)
{
	bool	result = false;

	// Get the trap word (the $Axxx value) and turn it into a zero-based index.

	uae_u16	trapWord = get_word (m68k_getpc ());
	uae_u16	trapIndex = TrapIndex (trapWord);

	// Note that we check against the hard-coded value "sysNumTraps" instead of
	// the more dynamic "gSysDispatchTableSize" as our tables of patch function
	// pointers are statically sized based on "sysNumTraps".

	if (trapIndex < sysNumTraps)
	{
		// First, see if we have a Headpatch for this function. If so, call
		// it. If it returns true, then that means that the head patch
		// completely handled the function.

		if (CallHeadpatch (trapWord))
		{
			// We handled it, so return TRUE.

			result = true;
		}

		// Next, see if there's a Tailpatch function for this trap. If
		// so, install the TRAP $E that will cause us to regain control
		// after the trap function has executed.

		if (gTailpatches[trapIndex])
		{
			SetupForTailpatch ();
		}
	}

	return result;
}


// ---------------------------------------------------------------------------
//		� Patches::HandleTrap13
// ---------------------------------------------------------------------------
// Handle a tail patch.  Traps that we want to tail patch will have their
// RTS address "subverted".  Instead of putting the real return address onto
// the stack, we put a pointer to a TRAP $E instruction.  When that TRAP $E
// is encountered, we handle it by patching up the PC with the real return
// address (which we've saved) and by executing some post-processing code.

void Patches::HandleTrap13 (void)
{
	// Restore the PC with what it should be (the saved return address)

	RecoverFromTailpatch ();

	// We want to call the tailpatch handler for the trap that just returned.
	// The PC should now be pointing to just after the TRAP $F / $Axxx codes
	// that invoked the trap, so look up the $Axxx word.

	uae_u16	trapWord = get_word (m68k_getpc () - 2);

	// Call the Tailpatch and return, letting the CPU opcode loop
	// restart from the PC we just restored.

	CallTailpatch (trapWord);
}


// ---------------------------------------------------------------------------
//		� Patches::SetupForTailpatch
// ---------------------------------------------------------------------------
// Set up the pending TRAP $F call to be tailpatched.  A system function is
// tailpatched by storing a TRAP $E after the TRAP $F / $Axxx sequence. If
// there is already a TRAP $E there, we increment a use-count.  When the
// TRAP $E is encountered, we decrement the use-count and restore the old
// opcode when it reaches zero.

void Patches::SetupForTailpatch (void)
{
	// Get the current PC and save it along with the SP into our tailpatch table.
	// Bump the PC by two to skip it past the $Axxx dispatch word.

	uaecptr	pc = m68k_getpc () + 2;
	uae_u16	oldOpcode = get_word (pc);

	// See if this function is already tailpatched.  If so, merely increment
	// the use-count field.

	if (oldOpcode == kOpcode_Tailpatch)
	{
		// It is.  Find the corresponding entry.

		for (int ii = 0; ii < kMaxInstalledTailpatches; ++ii)
		{
			if (gInstalledTailpatches[ii].fPC == pc)
			{
				++gInstalledTailpatches[ii].fCount;

				PRINTF ("Incremented tailpatch for %s at PC = 0x%08X.",
							kTrapNames[ get_word (pc - 2) & 0x0FFF ],
							gInstalledTailpatches[ii].fPC);
			}
		}
	}

	// This function is not already tailpatched, so look for an empty spot
	// for the the PC/opcode we want to save.

	else
	{
		int	ii;
		for (ii = 0; ii < kMaxInstalledTailpatches; ++ii)
		{
			if (gInstalledTailpatches[ii].fCount == 0)
			{
				gInstalledTailpatches[ii].fPC = pc;
				gInstalledTailpatches[ii].fOldOpcode = oldOpcode;
				gInstalledTailpatches[ii].fCount = 1;

				CEnableFullAccess	munge;	// Remove blocks on memory access.

				put_word (pc, kOpcode_Tailpatch);

				PRINTF ("Installed tailpatch for %s at PC = 0x%08X.",
							kTrapNames[ get_word (pc - 2) & 0x0FFF ],
							gInstalledTailpatches[ii].fPC);

				break;
			}
		}

		// Make sure our table hasn't overflowed.

		if (ii == kMaxInstalledTailpatches)
		{
			assert (!"Too many tail patches");
			abort ();
		}
	}
}


// ---------------------------------------------------------------------------
//		� Patches::RecoverFromTailpatch
// ---------------------------------------------------------------------------
// A TRAP $E has just been executed.  Update our tailpatch table by either
// restoring the replace opcode, or by decrementing the use-count field and
// providing the opcode to the CPU opcode-fetcher as the next opcode to
// execute.

void Patches::RecoverFromTailpatch (void)
{
	// Get the current PC so that we can find the record for this tailpatch.
	// Account for the 2 bytes by which the PC was incremented when it
	// executed the TRAP $E.

	uaecptr	pc = m68k_getpc () - 2;

	// Find the PC.

	for (int ii = 0; ii < kMaxInstalledTailpatches; ++ii)
	{
		if (gInstalledTailpatches[ii].fCount > 0 &&
			gInstalledTailpatches[ii].fPC == pc)
		{
			// Decrement the use-count.  If it reaches zero, remove the
			// TRAP $E.  Otherwise, leave the TRAP $E there, but give the
			// real opcode the the CPU opcode-fetcher.

			if (--gInstalledTailpatches[ii].fCount == 0)
			{
				CEnableFullAccess	munge;	// Remove blocks on memory access.

				put_word (pc, gInstalledTailpatches[ii].fOldOpcode);

				PRINTF ("Restored tailpatch %s at PC = 0x%08X.",
						kTrapNames[ get_word (pc - 2) & 0x0FFF ], pc);
			}
			else
			{
				Emulator::SetNextOpcode (gInstalledTailpatches[ii].fOldOpcode);

				PRINTF ("Decremented tailpatch %s at PC = 0x%08X.",
						kTrapNames[ get_word (pc - 2) & 0x0FFF ], pc);
			}

			// Backup the PC so that we can re-execute the opcode at this
			// location.

			m68k_setpc (pc);

			return;
		}
	}

	PRINTF ("Could not find tailpatch entry for PC = 0x%08X.", pc);

	assert (!"Not enough tail patches");
	abort ();
}


// ---------------------------------------------------------------------------
//		� Patches::RemoveAllTailpatches
// ---------------------------------------------------------------------------

void Patches::RemoveAllTailpatches (void)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	for (int ii = 0; ii < kMaxInstalledTailpatches; ++ii)
	{
		if (gInstalledTailpatches[ii].fCount > 0)
		{
			put_word (gInstalledTailpatches[ii].fPC,
						gInstalledTailpatches[ii].fOldOpcode);
		}
	}
}


// ---------------------------------------------------------------------------
//		� Patches::InstallAllTailpatches
// ---------------------------------------------------------------------------

void Patches::InstallAllTailpatches (void)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	for (int ii = 0; ii < kMaxInstalledTailpatches; ++ii)
	{
		if (gInstalledTailpatches[ii].fCount > 0)
		{
			put_word (gInstalledTailpatches[ii].fPC,
						kOpcode_Tailpatch);
		}
	}
}


// ---------------------------------------------------------------------------
//		� Patches::CallHeadpatch
// ---------------------------------------------------------------------------

bool Patches::CallHeadpatch (uae_u16 trapWord)
{
	uae_u16	trapIndex = TrapIndex (trapWord);

	if (gHeadpatches[trapIndex] && gHeadpatches[trapIndex] ())
	{
		return true;
	}

	return false;
}


// ---------------------------------------------------------------------------
//		� Patches::CallTailpatch
// ---------------------------------------------------------------------------

void Patches::CallTailpatch (uae_u16 trapWord)
{
	uae_u16	trapIndex = TrapIndex (trapWord);

	if (gTailpatches[trapIndex])
	{
		gTailpatches[trapIndex] ();
	}
}




#pragma mark -


// ---------------------------------------------------------------------------
//		� Headpatch::RecordTrapNumber
// ---------------------------------------------------------------------------
// Record the trap we just executed for our patch to SysEvGroupWait later.

bool Headpatch::RecordTrapNumber (void)
{
	// Record the trap we just executed for our patch to SysEvGroupWait later.

	gLastEvtTrap = get_word (m68k_getpc ());

	return false;
}


// ---------------------------------------------------------------------------
//		� Headpatch::ErrDisplayFileLineMsg
// ---------------------------------------------------------------------------

bool Headpatch::ErrDisplayFileLineMsg (void)
{
	// void ErrDisplayFileLineMsg(CharPtr filename, UInt lineno, CharPtr msg)

	uaecptr	filename	= get_long (m68k_areg (regs, 7) + 0);
	uae_u16	lineno		= get_word (m68k_areg (regs, 7) + 4);
	uaecptr	msg			= get_long (m68k_areg (regs, 7) + 6);

	// Get the text of the messages, sorting out any problems with the
	// byte ordering on Windows.

	char	filename2[256];
	char	msg2[256];

	uae_strcpy (filename2, filename);
	uae_strcpy (msg2, msg);

	char	buffer[200];
	sprintf (buffer, "%s, Line: %d, %s", filename2, lineno, msg2);

	ErrDisplayAndSysFatalAlertCommon (buffer);
	
	// Turn off Gremlins.  Do this _after_ calling DebugOrReset so that
	// that function can pick up any active Gremlin information.

	Gremlins_Stop ();

	return true;	// Don't execute the ROM version.
}


// ---------------------------------------------------------------------------
//		� Headpatch::KeyCurrentState
// ---------------------------------------------------------------------------
// From Roger:
//
//	I was thinking a bit more about Gremlins and games yesterday.  Games which
//	use the buttons as input have been a special case for Gremlins because
//	Gremlins only faked events and pen points.  Normally games have to fake
//	their own button mask, and they get better results if have some buttons
//	held down more often than others.
//
//	Now I'm thinking different.  With Poser, the KeyCurrentState call should
//	be stolen when Gremlins is running.  All of the keys possible should have
//	their button bits on half the time.  This will allow users to test games.
//	By not tuning how often buttons should be held down, the testing process
//	will take longer to excerise all app functionality, but it's better than
//	now.  App developers can override the default Gremlin values with their
//	own for better results.
//
//	To successfully test this, A game like SubHunt should play on it's own for
//	a least a while.  HardBall is an example of a game which would really
//	benefit from recognizing Gremlins is running and tune itself to make the
//	testing more effective.  It should grant infinite balls until after the
//	last level is finished.
//
//	I actually think this is important enough to be for Acorn because it
//	enables users to test a large class of apps which otherwise can't.  I
//	think it's easy to implement.  Basically just have KeyCurrentState return
//	the int from the random number generator.  Each bit should be on about
//	half the time.
//
// Follow-up commentary: it turns out that this patch is not having the
// effect we hoped.  SubHunt was so overwhelmed with events from Gremlins
// that it rarely had the chance to call KeyCurrentState.  We're thinking
// of Gremlins backing off on posting events if the SysGetEvent sleep time
// is small (i.e., not "forever"), but we'll have to think about the impact
// on other apps first.

bool Headpatch::KeyCurrentState (void)
{
	// DWord KeyCurrentState(void)

	if (Gremlins_IsOn ())
	{
		// Let's try setting each bit 1/4 of the time.

		uae_u32	bits = rand () & rand ();

		m68k_dreg (regs, 0) = bits;

		return true;	// Don't execute the ROM version.
	}

	return false;	// Execute the ROM version.
}


// ---------------------------------------------------------------------------
//		� Headpatch::MemMove
// ---------------------------------------------------------------------------

bool Headpatch::MemMove (void)
{
	// Err MemMove(const VoidPtr dstP, const void * const sP, ULong numBytes)

	uaecptr	dP			= get_long (m68k_areg (regs, 7) + 0);
	uaecptr	sP			= get_long (m68k_areg (regs, 7) + 4);
	uae_u32	numBytes	= get_long (m68k_areg (regs, 7) + 8);

//	ErrFatalDisplayIf(dP == NULL, "MemMove to NULL");
//	ErrNonFatalDisplayIf(sP == NULL, "MemMove from NULL");

	if (numBytes != 0 && dP != sP)
	{
		uae_memmove (dP, sP, numBytes);
	}

	m68k_dreg (regs, 0) = 0;

	return true;	// We handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::MemSet
// ---------------------------------------------------------------------------

bool Headpatch::MemSet (void)
{
	// Err MemSet(const VoidPtr dstP, ULong numBytes, Byte value)

	uaecptr	dstP		= get_long (m68k_areg (regs, 7) + 0);
	ULong	numBytes	= (ULong) get_long (m68k_areg (regs, 7) + 4);
	Byte	value		= (Byte) get_byte (m68k_areg (regs, 7) + 8);

//	ErrFatalDisplayIf (dstP == NULL, "MemSet to NULL");

	uae_memset (dstP, value, numBytes);

	m68k_dreg (regs, 0) = 0;

	return true;	// We handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::PenGetRawPen
// ---------------------------------------------------------------------------
// Complete replacement for PenGetRawPen in an attempt to speed it up. The
// ROM version does a lot of pen sampling, which is just not needed since we
// don't have a flaky LCD screen to emulate. Theoretically, all we need is a
// version of PenGetRawPen that returns the mouse point which we know (assume)
// is accurate.


/************************************************************
 *
 *  FUNCTION: PenGetRawPen
 *
 *  DESCRIPTION: If called on the first pen down (GHwrPenDown = false), 
 *		This routine verifies that pen is down, sets the GHwrPenDown global
 *		accordingly, disables furthen pen down interrupts, and returns immediately
 *		with a result of non-zero (i.e. *penP is invalid). The pen position is not 
 *		obtained in this case because we are called from an interrupt routine 
 *		and we don't want to spend a lot of time getting the pen position because
 *		we might lose characters coming in on the serial port. On return, the
 *		pen down interrupt routine will then prime the System timer procedure 
 *		to poll the pen if GHwrPenDown is true.
 *
 *		If called when GHwrPenDown is already true, it will get the current pen position
 *		and state and return with a result of 0 if it was able to get a valid
 *		reading. If it detects that the pen has come up unambiguously, it will
 *		re-enable pen down interrupts, clear the GHwrPenDown global, and return
 *		a pen-up coordinate (-1,-1).
 *
 *		If the pen state or position is ambiguous (due to pen bouncing, noise, etc.)
 *		this routine will return an error code and leave the GHwrPenDown
 *		global true.
 *
 *		 
 *  PARAMETERS: 
 *		*penP		- returned pen location, or (-1,-1) if pen is not down.
 *
 *	 CALLED BY:
 *		Pen down interrupt routine on first pen down.
 *		System timer procedure while pen is still down.
 *
 *  RETURNS: 
 *		0 		- *penP contains the current pen position/state
 *		!=0 	- *penP is invalid.
 *
 *************************************************************/

bool Headpatch::PenGetRawPen (void)
{
	// Temporarily disabled in 1.0 ROMs since the below function has compatibility
	// problems with them. The first mouse down is registered, mouse interrupts are
	// turned off, but PenGetRawPen is never called again, so mouse tracking
	// doesn't occur, and the mouse up is never noticed so mouse interrupts are
	// never turned back on again.

	if (LowMem_GetGlobal (sysDispatchTableSize) == (uae_u32) TrapIndex (sysTrapLstSetTopItem) + 1)
		return false;	// Don't replace this function in 1.0 ROMs.

	// Err PenGetRawPen (PointType* penP)
	
	uaecptr	pen = get_long (m68k_areg (regs, 7) + 0);
	
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	bool	isDown = (READ_REGISTER (intPendingHi) & hwr328IntHiPen) != 0;
	bool	wasDown = LowMem_GetGlobal (hwrPenDown) != 0;

	// Set return value assuming success.

	m68k_dreg (regs, 0) = 0;

	// Set hwrPenDown.

	// If the pen just went down, set hwrPenDown to the sample rate,
	// and return non-zero to avoid processing the point.

	if (!wasDown && isDown)
	{
		LowMem_SetGlobal (hwrPenDown, 2);

		// Disable pen interrupts while the pen is down.

		uae_u16	intWakeupEnHi = READ_REGISTER (intWakeupEnHi);
		WRITE_REGISTER (intWakeupEnHi, intWakeupEnHi & ~hwr328IntHiPen);

		uae_u16	intMaskHi = READ_REGISTER (intMaskHi);
		WRITE_REGISTER (intMaskHi, intMaskHi | hwr328IntHiPen);

		// Respond to the new interrupt state.

		Registers::UpdateInterrupts ();

		// Return non-zero to ignore the point.

		m68k_dreg (regs, 0) = -1;
	}

	// If we got a pen-up, and the pen was already up, just return an error.

	else if (!wasDown && !isDown)
	{
		// Return non-zero to ignore the point.

		m68k_dreg (regs, 0) = -10;
	}

	// If we got a pen-up, and the pen was previously down, clear hwrPenDown.

	else if (wasDown && !isDown)
	{
		LowMem_SetGlobal (hwrPenDown, 0);

		// Re-enable pen interrupts.

		uae_u16	intWakeupEnHi = READ_REGISTER (intWakeupEnHi);
		WRITE_REGISTER (intWakeupEnHi, intWakeupEnHi | hwr328IntHiPen);

		uae_u16	intMaskHi = READ_REGISTER (intMaskHi);
		WRITE_REGISTER (intMaskHi, intMaskHi & ~hwr328IntHiPen);

		// Respond to the new interrupt state.

		Registers::UpdateInterrupts ();

		// Fill in the pen point.

		put_word (pen + offsetof (PointType, x), -1);
		put_word (pen + offsetof (PointType, y), -1);

		// Return zero (success).

		m68k_dreg (regs, 0) = 0;
	}

	// If the pen is down, and it was down before, just return success.

	else if (wasDown && isDown)
	{
		// Fill in the pen point.

		put_word (pen + offsetof (PointType, x), 255 - gPen_HorzLocation);
		put_word (pen + offsetof (PointType, y), 255 - gPen_VertLocation);

		// Return zero (success).

		m68k_dreg (regs, 0) = 0;
	}

	return true;	// We handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::PenOpen
// ---------------------------------------------------------------------------
// This is where the pen calibration information is read.  Preflight this call
// to add the calibration information to the preferences database if it
// doesn't exist.  That way, we don't have to continually calibrate the screen
// when we boot up.

#if !TIME_STARTUP

bool Headpatch::PenOpen (void)
{
	#define	sysFileCSystem					'psys'	// Creator type for System files
	#define	sysResTSysPref					sysFileCSystem
	#define	sysResIDSysPrefCalibration		3		// Digitizer calibration.

	// Open the preferences database.  If the new version of PrefOpenPreferenceDB
	// exists, then call it.  Otherwise, call the old version.  We can't just
	// unconditionally call the old version, as that has a bug in the newer
	// ROMs that causes it to create the database incorrectly if it doesn't
	// already exist.

	DmOpenRef	dbP;
	if (LowMem::TrapExists (sysTrapPrefOpenPreferenceDB))
		dbP = PrefOpenPreferenceDB (false);
	else
		dbP = PrefOpenPreferenceDBV10 ();

	if (dbP)
	{
		// Get the calibration information.

		VoidHand	resourceH = DmGetResource (sysResTSysPref, sysResIDSysPrefCalibration);

		// If that information doesn't exist, go about creating it.

		if (!resourceH)
		{
			resourceH = DmNewResource (dbP, sysResTSysPref, sysResIDSysPrefCalibration,
						4 * sizeof(UInt));

			if (resourceH)
			{
				// Write in the calibration information.  The information has the
				// following format and values:
				//
				//		scaleX	: 256
				//		scaleY	: 256
				//		offsetX	:   0
				//		offsetY	:   0
				//
				// We encode that data here as a string of bytes to avoid endian problems.

				UIntPtr	resP = (UIntPtr) MemHandleLock (resourceH);

				unsigned char data[] = { 1, 0, 1, 0, 0, 0, 0, 0 };

				DmWrite (resP, 0, data, 4 * sizeof (UInt));

				MemHandleUnlock (resourceH);
				DmReleaseResource (resourceH);
			}
		}

		DmCloseDatabase (dbP);
	}

	return false;
}

#endif


// ---------------------------------------------------------------------------
//		� Headpatch::RctPtInRectangle
// ---------------------------------------------------------------------------

bool Headpatch::RctPtInRectangle (void)
{
	// Boolean RctPtInRectangle (const SWord x, const SWord y, const RectanglePtr r)

	SWord	x	= (SWord) get_word (m68k_areg (regs, 7) + 0);
	SWord	y	= (SWord) get_word (m68k_areg (regs, 7) + 2);
	uaecptr	rP	= get_long (m68k_areg (regs, 7) + 4);

	RectangleType	r;
	r.topLeft.x = get_word (rP + offsetof (RectangleType, topLeft) + offsetof (PointType, x));
	r.topLeft.y = get_word (rP + offsetof (RectangleType, topLeft) + offsetof (PointType, y));
	r.extent.x = get_word (rP + offsetof (RectangleType, extent) + offsetof (PointType, x));
	r.extent.y = get_word (rP + offsetof (RectangleType, extent) + offsetof (PointType, y));

	Boolean result = (x >= r.topLeft.x &&
			  y >= r.topLeft.y &&
			  x < r.topLeft.x + r.extent.x &&
			  y < r.topLeft.y + r.extent.y);

	m68k_dreg (regs, 0) = result;

	return true;	// We handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::ScrDrawNotify
// ---------------------------------------------------------------------------
// This function get's called at the end of every drawing operation with the
// bounds of the affected screen area.  We patch this function to set our
// "screen dirty" bit, causing our application to redraw the screen from the
// LCD buffer contents.  We also keep track of the dirty bounds so that we
// can do a minimal redraw.

bool Headpatch::ScrDrawNotify (void)
{
	//	void ScrDrawNotify(SWord updLeft, SWord updTop,  SWord updWidth, SWord updHeight)

	SWord	updLeft		= (SWord) get_word (m68k_areg (regs, 7) + 0);
	SWord	updTop		= (SWord) get_word (m68k_areg (regs, 7) + 2);
	SWord	updWidth	= (SWord) get_word (m68k_areg (regs, 7) + 4);
	SWord	updHeight	= (SWord) get_word (m68k_areg (regs, 7) + 6);

	// Accumulate the update area.

	if (updLeft < gScreen_UpdateRect.left) 
		gScreen_UpdateRect.left = updLeft;

	else if ((updLeft + updWidth) > gScreen_UpdateRect.right)
		gScreen_UpdateRect.right = (updLeft + updWidth);

	if (updTop < gScreen_UpdateRect.top) 
		gScreen_UpdateRect.top = updTop;

	else if ((updTop + updHeight) > gScreen_UpdateRect.bottom)
		gScreen_UpdateRect.bottom = (updTop + updHeight);

	Screen::RecordChange (kScreen_ContentsChanged);

	return true;	// We handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysEvGroupWait
// ---------------------------------------------------------------------------
// We patch SysEvGroupWait as the mechanism for feeding the Palm OS new events.
// When the Palm OS needs an event, it calls EvtGetEvent.  EvtGetEvent looks in
// all the usual places for events to return. If it doesn't find any, it puts
// the system to sleep by calling SysEvGroupWait.  SysEvGroupWait will wake up
// and return when an event is posted via something like EvtEnqueuePenPoint,
// EvtEnqueueKey, or KeyHandleInterrupt.
//
// To puppet-string Palm OS, we therefore patch SysEvGroupWait and post events,
// preventing SysEvGroupWait from actually going to sleep.

bool Headpatch::SysEvGroupWait (void)
{
	// Set the return value (Err) to zero in case we return
	// "true" (saying that we handled the trap).

	m68k_dreg (regs, 0) = 0;

	// If the low-memory global "idle" is true, then we're being
	// called from EvtGetEvent or EvtGetPen, in which case we
	// need to check if we need to post some events.

	if (LowMem::GetEvtMgrIdle ())
	{
		if (Gremlins_IsOn ())
		{
			if (gLastEvtTrap == sysTrapEvtGetEvent)
			{
				if (!Gremlins_PostFakeEvent ())
				{
					// No event was posted.  What we'd like right now
					// is to force EvtGetEvent to return a nil event.
					// We can do that by returning a non-zero result
					// code from SysEvGroupWait.  EvtGetEvent doesn't
					// look too closely at the result, but let's try
					// to be as close to reality as possible.
					// SysEvGroupWait currently returns "4" (CJ_WRTMOUT)
					// to indicate a timeout condition.  It should
					// probably get turned into sysErrTimeout
					// somewhere along the way, but that translation
					// doesn't seem to occur.

					m68k_dreg(regs, 0) = 4;

					return true;	// We did it all
				}
			}
			else if (gLastEvtTrap == sysTrapEvtGetPen)
			{
				Gremlins_PostFakePenEvent ();
			}
		}

		// Gremlins aren't on; let's see if the user has typed some
		// keys that we need to pass on to the Palm device.

		else if (gKeyQueue.GetUsed () > 0)
		{
			StubAppEnqueueKey (gKeyQueue.Get (), 0, 0);
		}
	}

	return false;
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysDoze
// ---------------------------------------------------------------------------

bool Headpatch::SysDoze (void)
{
	gSysDozing = true;

	return false;
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysFatalAlert
// ---------------------------------------------------------------------------

bool Headpatch::SysFatalAlert (void)
{
	// UInt SysFatalAlert (CharPtr msg)

	uaecptr	msg	= get_long (m68k_areg (regs, 7) + 0);

	char	msg2[256];

	if (msg)
		uae_strcpy (msg2, msg);
	else
		strcpy (msg2, "Unknown fatal error occured!");

	ErrDisplayAndSysFatalAlertCommon (msg2);

	// Turn off Gremlins.  Do this _after_ calling DebugOrReset so that
	// that function can pick up any active Gremlin information.

	Gremlins_Stop ();

	return true;	// Don't execute the ROM version.
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysGremlins
// ---------------------------------------------------------------------------

bool Headpatch::SysGremlins (void)
{
	// DWord SysGremlins(GremlinFunctionType selector, GremlinParamsType *params)

	uae_s8	msg	= get_byte (m68k_areg (regs, 7) + 0);
	uaecptr	params = get_long (m68k_areg (regs, 7) + 2);

	switch (msg)
	{
		case GremlinIsOn:
			m68k_dreg (regs, 0) = 1;		// Gremlins is running.
			break;

		default:
			m68k_dreg (regs, 0) = 0;		// default result.
			break;
	}

	return true;	// we handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysLaunchConsole
// ---------------------------------------------------------------------------
// Stub this function out so that it doesn't do anything.  We completely
// handle the console in DebugMgr, so there's no need to get the ROM all
// heated up.  Also, there are problems with actually letting the ROM try
// to launch its console task, at least on the Mac.  It will try to open
// a serial port socket and do stuff with it.  That attempt will fail, as
// much of the serial port processing on the Mac is handled at idle time,
// and idle time processing is inhibited when handling debugger packets
// (SysLaunchConsole is usually called by a debugger via the RPC packet).
// Since serial port processing doesn't occur, SysLaunchConsole hangs.

bool Headpatch::SysLaunchConsole (void)
{
	// Err SysLaunchConsole(void)

	m68k_dreg (regs, 0) = 0;		// no error

	return true;	// we handled it all
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysSleep
// ---------------------------------------------------------------------------

bool Headpatch::SysSleep (void)
{
	gSysSleeping = true;

	return false;
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysUIAppSwitch
// ---------------------------------------------------------------------------
// SysUIAppSwitch is called from the following locations for the given
// reasons.  When running Gremlins, we want to prevent SysUIAppSwitch from
// doing its job, which is to record information about the application to
// switch to and to then post an appStopEvent to the current application.
//
// There are a couple of places where SysUIAppSwitch is called to quit and
// re-run the current application.  Therefore, we want to stub out
// SysUIAppSwitch only when the application being switched to is not the
// currently running application.
//
//	Places where this is called:
//
//	- LauncherMain.c (AppsViewSwitchApp) to launch new app.
//	- PrefApp (PilotMain) to launch a panel.
//	- SyncApp (prvLaunchExternalModule) to launch a "service owner"
//	- AppLaunchCmd.h (AppLaunchWithCommand) ???
//	- ModemPanel.h (ModemPanelLaunch) ???
//	- callApp.h (LaunchApp) ???
//	- ExgMgr.c (ExgNotifyReceive) to send a sysAppLaunchCmdGoTo message.
//	- GraffitiGlue.c (PrvLaunchGraffitiDemo) to launch Graffiti demo.
//	- Keyboard.c (PrvLaunchGraffitiDemo) to launch Graffiti demo.
//	- Launcher.c (LauncherFormHandleEvent) handles taps on launcher icons.
//	- SystemMgr.c (SysHandleEvent) to send sysAppLaunchCmdSystemLock
//	  in response to seeing a lockChr keyboard message.
//	- SystemMgr.c (SysHandleEvent) to switch apps in response to hard#Chr
//	  keyboard messages.
//	- Find.c (Find) to send sysAppLaunchCmdGoTo message.
//
//	- ButtonsPanel.c (ButtonsFormHandleEvent) switch to another panel.
//	- FormatsPanel.c (FormatsFormHandleEvent) switch to another panel.
//	- GeneralPanel.c (GeneralFormHandleEvent) switch to another panel.
//	- ModemPanel.c (ModemFormHandleEvent) switch to another panel.
//	- NetworkPanel.h (NetworkFormHandleEvent) switch to another panel.
//	- OwnerPanel.c (OwnerViewHandleEvent) switch to another panel.
//	- ShortCutsPanel.c (ShortCutFormHandleEvent) switch to another panel.

bool Headpatch::SysUIAppSwitch (void)
{
	// Err SysUIAppSwitch(UInt cardNo, LocalID dbID, Word cmd, Ptr cmdPBP)

	UInt	cardNo	= (UInt) get_word (m68k_areg (regs, 7) + 0);
	LocalID	dbID	= (LocalID) get_long (m68k_areg (regs, 7) + 2);
	Word	cmd		= (Word) get_word (m68k_areg (regs, 7) + 6);

	// Get the current application card and db.  If we are attempting to switch
	// to the same app, allow it.

	UInt	currentCardNo;
	LocalID	currentDbID;
	Err		err = SysCurAppDatabase (&currentCardNo, &currentDbID);

	// Got an error? Give up and let default handling occur.

	if (err != 0)
		return false;

	// Switching to current app; let default handling occur.

	if ((cardNo == currentCardNo) && (dbID == currentDbID))
		return false;

	// OK, we're switching to a different application.  If Gremlins is running
	// and running in "single app" mode, then stub out SysUIAppSwitch to do nothing.

	if (Gremlins_IsOn () && Gremlins_InSingleAppMode ())
	{
		m68k_dreg (regs, 0) = 0;
		return true;
	}

	// Remember the current application name and version information.  We use
	// this information when telling users that something has gone haywire.
	//
	// If the database has a 'tAIN' resource, get the name from there.
	// Otherwise, use the database name.
	//
	// (Write the name into a temporary local variable.  The local variable is
	// on the stack, which will get "mapped" into the emulated address space so
	// that the emulated DmDatabaseInfo can get to it.)

	char	appName[dmDBNameLength] = {0};
	char	appVersion[256] = {0};	// <gulp> I hope this is big enough...

	DmOpenRef	dbP = DmOpenDatabase (cardNo, dbID, dmModeReadOnly);

	if (dbP)
	{
		VoidHand	strH;

		// Get the app name from the 'tAIN' resource.
		
		strH = DmGet1Resource (ainRsc, ainID);
		if (strH)
		{
			uaecptr	strP = (uaecptr) MemHandleLock (strH);
			uae_strcpy (appName, strP);
			MemHandleUnlock (strH);
			DmReleaseResource (strH);
		}

		// Get the version from the 'tver' resource, using ID's 1 and 1000

		strH = DmGet1Resource (verRsc, appVersionID);
		if (strH == NULL)
			strH = DmGet1Resource (verRsc, appVersionAlternateID);
		if (strH)
		{
			uaecptr	strP = (uaecptr) MemHandleLock (strH);
			uae_strcpy (appVersion, strP);
			MemHandleUnlock (strH);
			DmReleaseResource (strH);
		}

		DmCloseDatabase (dbP);
	}

	if (appName[0] == 0)	// No 'tAIN' resource, so use database name
	{
		DmDatabaseInfo (cardNo, dbID,
						appName,
						NULL, NULL, NULL, NULL, NULL,
						NULL, NULL, NULL, NULL, NULL);
	}

	// Copy the strings from the stack to their permanent homes.

	strcpy (gCurrentApplicationName, appName);
	strcpy (gCurrentApplicationVersion, appVersion);

	// Clear the flags that tell us which warnings we've already issued.
	// We reset these flags any time a new application is launched.

	gPreventAccessNotificationFlags = 0;

	// Return false to do the normal app switch.

	return false;
}


// ---------------------------------------------------------------------------
//		� Headpatch::SysUIBusy
// ---------------------------------------------------------------------------

#if TIME_STARTUP

extern uae_u32	gStart;
extern long		gInstructionCount;
extern long		gSpecial;

bool Headpatch::SysUIBusy (void)
{
	static calledOnce;

	if (!calledOnce)
	{
		calledOnce = true;

#if __profile__

	ProfilerSetStatus (false);
	ProfilerDump ("\pEmulator.prof");

#endif
		uae_u32	now = Platform::GetMilliseconds ();
		uae_u32	elapsed = now - gStart;

		char	buffer[200];

#if COUNT_INSTRUCTIONS
		sprintf (buffer, "startup = %ld milliseconds  "
						"instructions = %ld "
						"special = %ld",
						elapsed, gInstructionCount, gSpecial);
#else
		sprintf (buffer, "startup = %ld milliseconds",
						elapsed);
#endif

		Platform::ReportString (buffer);
	}

	return false;
}

#endif


// ---------------------------------------------------------------------------
//		� Headpatch::TimInit
// ---------------------------------------------------------------------------
// TimInit is where the date is read from non-volatile memory into private
// Time Manager memory.  After that, the Time Manager uses its private copy
// to update the non-volatile copy.  Thus, stashing correct values of the
// date into non-volatile memory should be done just before TimInit.

bool Headpatch::TimInit (void)
{
	// Get the current date.

	long	year, month, day;
	Platform::GetDate (&year, &month, &day);

	// Get the current non-volatile variables.

	SysNVParamsType	params;
	MemNVParams (false, &params);

	// Update the "hours adjustment" value to contain the current date.

	params.rtcHours = Utility::DateToDays (year, month, day) * 24;

	// Re-write the non-volatile variables.

	MemNVParams (true, &params);

	return false;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Tailpatch::EvtGetEvent
// ---------------------------------------------------------------------------

void Tailpatch::EvtGetEvent (void)
{
	// void EvtGetEvent(const EventPtr event, SDWord timeout);

	uaecptr	event = get_long (m68k_areg (regs, 7) + 0);

	Gremlins_RecordEvtGetEvent (event);
}


// ---------------------------------------------------------------------------
//		� Tailpatch::EvtGetPen
// ---------------------------------------------------------------------------

void Tailpatch::EvtGetPen (void)
{
	// void EvtGetPen(SWord *pScreenX, SWord *pScreenY, Boolean *pPenDown)

	uaecptr	pScreenX = get_long (m68k_areg (regs, 7) + 0);
	uaecptr	pScreenY = get_long (m68k_areg (regs, 7) + 4);
	uaecptr	pPenDown = get_long (m68k_areg (regs, 7) + 8);

	Gremlins_RecordEvtGetPen (pScreenX, pScreenY, pPenDown);
}


// ---------------------------------------------------------------------------
//		� Tailpatch::ScrInit
// ---------------------------------------------------------------------------
// Set ScrGlobalsType::doDrawNotify so that all drawing routines will end up
// calling ScrDrawNotify after they've drawn to the screen.
//
// (Oops...can't do this yet...ScrGlobalsType is pretty private, and changed
// a lot between 2.0 and 3.0, so we don't know where doDrawNotify really is...


void Tailpatch::ScrInit (void)
{
//	put_byte(LowMem_GetFixedLong(scrGlobalsP) +
//			offsetof(ScrGlobalsType, doDrawNotify), true);
}


// ---------------------------------------------------------------------------
//		� Tailpatch::SysDoze
// ---------------------------------------------------------------------------

void Tailpatch::SysDoze (void)
{
	gSysDozing = false;
}


// ---------------------------------------------------------------------------
//		� Tailpatch::SysSleep
// ---------------------------------------------------------------------------

void Tailpatch::SysSleep (void)
{
	gSysSleeping = false;
}


// ---------------------------------------------------------------------------
//		� Tailpatch::TimInit
// ---------------------------------------------------------------------------
// TimInit is where a special boolean is set to trigger a bunch of
// RTC bug workarounds in the ROM (that is, there are RTC bugs in the
// Dragonball that the ROM needs to workaround).  We're not emulating those
// bugs, so turn off that boolean.  Otherwise, we'd have to add support
// for the 1-second, 1-minute, and 1-day RTC interrupts in order to get
// those workarounds to work.

void Tailpatch::TimInit (void)
{
	// Turn off the RTC bug workaround flag.

	uaecptr	timGlobalsP = LowMem_GetGlobal (timGlobalsP);

	if (get_byte (timGlobalsP + 8) == 0x01)
	{
		put_byte (timGlobalsP + 8, 0x00);
	}
}


// ---------------------------------------------------------------------------
//		� Tailpatch::UIInitialize
// ---------------------------------------------------------------------------

void Tailpatch::UIInitialize (void)
{
	gUIInitialized = true;

	// Prevent the device from going to sleep.

	SysSetAutoOffTime (0);

	// Can't call PrefSetPreference on 1.0 devices....

	if (LowMem_GetGlobal (sysDispatchTableSize) == (uae_u32) TrapIndex (sysTrapLstSetTopItem) + 1)
		return;

	PrefSetPreference (prefAutoOffDuration, 0);
}


// ---------------------------------------------------------------------------
//		� ErrDisplayAndSysFatalAlertCommon
// ---------------------------------------------------------------------------

static int ErrDisplayAndSysFatalAlertCommon (const char* appMsg)
{
	char*	msg;
	char*	appName	= Utility::GetAppName ();
	char*	version = Utility::GetAppVersion ();

	// Format the entire message.  We use different messages depending on
	// whether or not Gremlins is running.

	if (Gremlins_IsOn ())
	{
		msg	= Platform::GetString (kStringErrDisplayWithGremlins);

		assert (msg != NULL);

		msg = Utility::ReplaceParameter (msg, "%application", appName);
		msg = Utility::ReplaceParameter (msg, "%version", version);
		msg = Utility::ReplaceParameter (msg, "%message", appMsg);
		msg = Utility::ReplaceParameter (msg, "#gremlin_number", Gremlins_GremlinNumber ());
		msg = Utility::ReplaceParameter (msg, "#gremlin_event", Gremlins_EventNumber ());
	}
	else
	{
		msg	= Platform::GetString (kStringErrDisplay);

		assert (msg != NULL);

		msg = Utility::ReplaceParameter (msg, "%application", appName);
		msg = Utility::ReplaceParameter (msg, "%version", version);
		msg = Utility::ReplaceParameter (msg, "%message", appMsg);
	}

	int	button = Platform::ErrorDialog (msg, kMsgDebug + kMsgReset);

	free (msg);
	free (appName);
	free (version);

	if (button == kMsgDebug)
	{
		// We're about to signal a bus error.  At this time, the PC is
		// pointing to the Axxx word that follows the TRAP $F instruction.
		// When the bus error is signalled, we don't want the PC there.
		// If we leave it there, the external debugger will end up
		// pointing there, with no reasonable way to restart execution.
		// In order to allow the debugger to restart execution, set the
		// PC to the beginning of the following instruction when the
		// bus error is signalled.

		m68k_setpc (m68k_getpc () + 2);

		// Signal a bus error.  However, Software::BusError will throw
		// an exception in order to abort the rest of the current
		// instruction.  We don't need that to happen here, so we catch
		// the exception and just swallow it.

		try
		{
			Software::BusError ();
		}
		catch (...)
		{
		}
	}
	else
	{
		assert (button == kMsgReset);

		// Reset the emulator (causes it to "reboot")

		Emulator::Reset();
	}

	// Back-up the PC by two.  This function is called by a trap patch
	// that will say that it handled the whole thing, which will cause
	// Software::ProcessTrap15 to bump the PC by two.  We have just set
	// the PC to exactly what we wanted, so we don't want that PC += 2
	// to have any effect.

	m68k_setpc (m68k_getpc () - 2);

	return button;
}


// This stuff is for later, when we look for leaked memory when the app quits.

/*
bool FindAllAppChunks (VoidPtr chunkP, int ver, void* userData)
{
	MemChunkHeaderUnionType	chunk;
	chunk = *(MemChunkHeaderUnionType*) chunkP;
	Canonical (chunk);

	if (memUChunkOwner (&chunk, ver) == (long) userData)
		MemChunkFree ((BytePtr) chunkP + memUSizeOfChunkHeader(ver));

	return false;
}

void WalkHeap (WalkerProc fn, void* userData)
{
	VoidPtr	heapP		= MemHeapPtr(heapID);
	Word	flags		= memUHeapFlags(heapP);	Canonical (flags);
	Word	ver			= (flags & memHeapFlagVers2 ? 2 : 1);
	Word	numEntries	= heapP->mstrPtrTbl.numEntries;	Canonical (numEntries);
	VoidPtr	chunkP		= (VoidPtr) ((BytePtr) heapP + sizeof(HeapHeaderType)
							+ (numEntries * sizeof (Ptr)) );

	MemChunkHeaderUnionType	chunk;
	chunk = *(MemChunkHeaderUnionType*) chunkP;
	Canonical (chunk);

	while (memUChunkSize (&chunk, ver))
	{
		if (fn (chunkP, ver, userData))
			break;

		// Go on to next chunk
		chunkP	= (VoidPtr) ((BytePtr) chunkP + memUChunkSize(chunkP, ver));
		chunk	= *(MemChunkHeaderUnionType*) chunkP;
		Canonical (chunk);
	}
}
*/
