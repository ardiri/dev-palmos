/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#ifdef forSimulator

#pragma once

#include	<Pilot.h>
#include "CGremlins.h"
#include "CGremlinsStubs.h"
#include "Hardware.h"
#include <EmuStubs.h>

#define	NON_PORTABLE
#include <SystemPrv.h>
#include	<DataPrv.h>
#include <SysEvtPrv.h>
#include <SystemPkt.h>

#include "ShellCmd.h"

#include <stdlib.h>		// needed for rand and srand

#else	// !forSimulator

#include "Palm.h"

#include "CGremlins.h"
#include "CGremlinsStubs.h"

// Use our own versions of rand() and srand() so that we generate the
// same numbers on both platforms.

#define RAND_MAX 0x7fff

#define rand	Gremlin_rand
#define srand	Gremlin_srand

static unsigned long int next = 1;

static int rand(void)
{
//	next = next * 1103515245 + 12345;	// MSL numbers
	next = next * 214013L + 2531011L;	// VC++ numbers
	return ((next >> 16) & 0x7FFF);
}

static void srand(unsigned int seed)
{
	next = seed;
}

#endif


#include <string.h>		// needed for strcpy and friends

//#define randN(N) ((N) ? rand() / (RAND_MAX / (N)) : (0))
#define randN(N) ((int) (((long) rand() * (N)) / ((long) RAND_MAX + 1)))
#define randPercent (randN(100))

#define PEN_MOVE_CHANCE 			50			// 50% move pen else pen up
#define PEN_BIG_MOVE_CHANCE		5			// 5% move pen really far

#define KEY_DOWN_EVENT_WITHOUT_FOCUS_CHANCE		10
#define KEY_DOWN_EVENT_WITH_FOCUS_CHANCE			40
#define PEN_DOWN_EVENT_CHANCE							(70 + KEY_DOWN_EVENT_WITHOUT_FOCUS_CHANCE)
#define MENU_EVENT_CHANCE								(PEN_DOWN_EVENT_CHANCE + 4)
#define FIND_EVENT_CHANCE								(MENU_EVENT_CHANCE + 2)
#define KEYBOARD_EVENT_CHANCE							(FIND_EVENT_CHANCE + 1)
#define LOW_BATTERY_EVENT_CHANCE						(KEYBOARD_EVENT_CHANCE + 2)
#define APP_SWITCH_EVENT_CHANCE						(LOW_BATTERY_EVENT_CHANCE + 4)

#define LAUNCHER_EVENT_CHANCE		0			// percent of APP_SWITCH_EVENT_CHANCE


#define commandKeyMask		0x0008


#define TYPE_QUOTE_CHANCE								10

#define MAX_SEED_VALUE				1000		// Max. # of seed values allowed.
#define INITIAL_SEED					1

#define LETTER_PROB					60

// Chars less often than a letter
#define SYMBOL_PROB					(LETTER_PROB / 10)
#define EXT_LTTR_PROB				(LETTER_PROB / 3)
#define EXTENDED_PROB				(LETTER_PROB / 5)
#define CONTROL_PROB					(LETTER_PROB / 2)
#define MENU_PROB						(LETTER_PROB / 10)
#define KBRD_PROB						(LETTER_PROB / 30)
#define NXTFLD_PROB					(LETTER_PROB / 10)

// Chars more often than a letter
#define SPACE_PROB					(LETTER_PROB * 5)
#define TAB_PROB						(LETTER_PROB * 2)
#define BACKSPACE_PROB				(LETTER_PROB * 3) 
#define RETURN_PROB					((LETTER_PROB * 10) * 1)	// extra exercise


//Global variables
Gremlins *theGremlins;					// Pointer to the Gremlins class.
long		IdleTimeCheck;					// Tick count for the next idle query

// Array of probabilities of a key being pressed for gremlin mode.
#define NUM_OF_KEYS		0x110
static int chanceForKey[NUM_OF_KEYS] = {
	0, 0, 0, 0, 0, 0, 0, 0,	// 0x00 - 0x07
	BACKSPACE_PROB, TAB_PROB, RETURN_PROB, CONTROL_PROB, CONTROL_PROB, 0, 0, 0,	// 0x08 - 0x0F
	0, 0, 0, 0, 0, 0, 0, 0,	// 0x10 - 0x17
	0, 0, 0, 0, CONTROL_PROB, CONTROL_PROB, CONTROL_PROB, CONTROL_PROB,	// 0x18 - 0x1F
	
	// Symbols
	SPACE_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,		// 0x20 - 0x23
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x24 - 0x27
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x28 - 0x2B
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x2C - 0x2F
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x30 - 0x33
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x34 - 0x37
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x38 - 0x3B
	SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB, SYMBOL_PROB,	// 0x3C - 0x3F

	// Uppercase
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x40 - 0x43
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x44 - 0x47
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x48 - 0x4B
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x4C - 0x4F
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x50 - 0x53
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x54 - 0x57
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x58 - 0x5B
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x5C - 0x5F

	// Lowercase
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x60 - 0x63
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x64 - 0x67
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x68 - 0x6B
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x6C - 0x6F
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x70 - 0x73
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x74 - 0x77
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x78 - 0x8B
	LETTER_PROB, LETTER_PROB, LETTER_PROB, LETTER_PROB,	// 0x7C - 0x7F

	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x80 - 0x83
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x84 - 0x87
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x88 - 0x8B
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x8C - 0x8F
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x90 - 0x93
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x94 - 0x97
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x98 - 0x9B
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0x9C - 0x9F

	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xA0 - 0xA3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xA4 - 0xA7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xA8 - 0xAB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xAC - 0xAF
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xB0 - 0xB3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xB4 - 0xB7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xB8 - 0xBB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xBC - 0xBF

	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xC0 - 0xC3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xC4 - 0xC7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xC8 - 0xCB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xCC - 0xCF
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xD0 - 0xD3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xD4 - 0xD7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xD8 - 0xDB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xDC - 0xDF

	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xE0 - 0xE3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xE4 - 0xE7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xE8 - 0xEB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xEC - 0xEF
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xF0 - 0xF3
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xF4 - 0xF7
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xF8 - 0xFB
	EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB, EXTENDED_PROB,	// 0xFC - 0xFF
	
	// Virtual events
	CONTROL_PROB, 0, 0, NXTFLD_PROB, 0, MENU_PROB, 0, 0,			// 0x100 - 0x107
	CONTROL_PROB, KBRD_PROB, CONTROL_PROB, 0, NXTFLD_PROB, 0, 0, 0,	// 0x108 - 0x10f

}; 


// Shakespearean quotes used by Gremlins
#define NUM_OF_QUOTES	18
static char * quotes[NUM_OF_QUOTES] = {
	"Out out damn spot!",
	"Et tu, Brute?",
	"When in disgrace with fortune and mens' eyes "
		"I all alone beweep my outcast state.  "
		"And trouble deaf heaven with my bootless cries and "
		"look upon myself and curse my fate. "
		"Wishing me like to one more rich in hope, "
		"featured like him, like him with friends possest, "
		"desiring this man's art and that man's scope, "
		"with what I most enjoy contented least;"
		"\n"
		"Yet in these thoughts myself almost despising- "
		"haply I think on thee: and then my state, "
		"like to the lark at break of day arising "
		"from sullen earth, sings hymns at Heaven's gate; "
		"for thy sweet love rememb'red such wealth brings "
		"that then I scorn to change my state with kings.",
	"I think my wife is honest, and think she is not; "
		"I think that thou art just, and think thou art not.",
	"O that this too too sullied flesh would melt, thaw, "
		"and resolve itself into a dew, "
		"or that the Everlasting had not fixed "
		"His canon 'gainst self-slaughter.",
	"Come, you spirits that tend on mortal thoughts, unsex me here, "
		"and fill me from the crown to the toe top-full "
		"of direst cruelty.",
	"I do not think but Desdemona's honest.",
	"That I did love the Moor to live with him",
	"What a piece of work is a man",
	"Fair is foul, and foul is fair.",
	"All hail, Macbeth, that shalt be King hereafter!",
	"What's Montague?",
	
	"To a nunnery, go, and quickly too.",
	"I'll have some proof.",
	"Now are we well resolved, and by God's help and yours, "
		"the noble sinews of our power, France being ours, "
		"we'll bend it to our awe or break it all to pieces.",
	"Tennis balls, my liege.",
	"De sin. Le col, de nick; le menton, de sin.",
	"But swords I smile at, weapons laugh to scorn, "
		"brandished by man that's of a woman born."
	
	};



/***********************************************************************
 *
 * FUNCTION:	GetFocusObject
 *
 * DESCRIPTION: Return whether the current form has the focus.
 *
 * CALLED BY:  here
 *
 * PARAMETERS:	none
 *
 * RETURNED:	TRUE if the form has a focus set and FALSE if not
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/25/95	Initial Revision
 *			roger	11/27/95	Ignored not editable fields.
 *
 ***********************************************************************/
static FieldPtr GetFocusObject()
{
	FormPtr frm;
	Word focusObj;
	FieldPtr textFieldP;


	// Pick a point within one of the current form's objects
	frm = FrmGetActiveForm ();

	// The active window will not be the active form
	// if a popup list of a menu is displayed.
	if ((! frm) || (FrmGetWindowHandle (frm) != WinGetActiveWindow ()) ||
		((focusObj = FrmGetFocus(frm)) == noFocus))
	{
		return NULL;
	}
	
	// Get the field.  If it's a table get it's field.
	if (FrmGetObjectType(frm, focusObj) == frmTableObj)
		{
		textFieldP = TblGetCurrentField((TablePtr) FrmGetObjectPtr(frm, focusObj));
		if (textFieldP == NULL)
			return NULL;
		}
	else
		textFieldP = (FieldPtr) FrmGetObjectPtr(frm, focusObj);


	return textFieldP;
}


/***********************************************************************
 *
 * FUNCTION:	IsFocus
 *
 * DESCRIPTION: Return whether the current form has the focus.
 *
 * CALLED BY:  EmGremlins.cp
 *
 * PARAMETERS:	none
 *
 * RETURNED:	TRUE if the form has a focus set and FALSE if not
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/25/95	Initial Revision
 *			roger	11/27/95	Ignored not editable fields, broke out GetFocusObject
 *
 ***********************************************************************/
static int IsFocus()
{
	FieldPtr textFieldP;
	FieldAttrType attr;



	textFieldP = GetFocusObject();
	if (textFieldP == NULL)
		return false;

	// Now make sure that the field is editable.
	FldGetAttributes(textFieldP, &attr);
	if (!attr.editable)
		return false;


	return true;
}


/***********************************************************************
 *
 * FUNCTION:	SpaceLeftInFocus
 *
 * DESCRIPTION: Return the number of characters which can be added to 
 *	the object with the focus.
 *
 * CALLED BY:  EmGremlins.cp
 *
 * PARAMETERS:	none
 *
 * RETURNED:	The number of characters which can be added to 
 *	the object with the focus.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/27/95	Initial Revision
 *
 ***********************************************************************/
static int SpaceLeftInFocus()
{
	FieldPtr textFieldP;
	FieldAttrType attr;



	textFieldP = GetFocusObject();
	if (textFieldP == NULL)
		return 0;

	// Now make sure that the field is editable.
	FldGetAttributes(textFieldP, &attr);
	if (!attr.editable)
		return 0;

	

	return FldGetMaxChars(textFieldP) - FldGetTextLength(textFieldP);
}


/***********************************************************************
 *
 * FUNCTION:	FakeLocalMovement
 *
 * DESCRIPTION: Generate a random point within the vicinity of the last
 *						point.
 *
 * CALLED BY:  EmGremlins.cp
 *
 * PARAMETERS:	currentX -	the new x-coordinate of a pen movement.
 *					currentY -	the new y-coordinate of a pen movement.
 * 				lastX -		the last x-coordinate of a pen movement.
 *					lastY -		the last y-coordinate of a pen movement.					
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/15/95	Initial Revision
 *
 ***********************************************************************/
static void FakeLocalMovement(short* currentX, short* currentY, short lastX, short lastY)
{
	*currentX = lastX + (randN(FntLineHeight() * 2) - FntLineHeight());
	*currentY = lastY + (randN(FntLineHeight() * 2) - FntLineHeight());	// FntLineHeight
	
	
	// Clip to screen bounds
	if (*currentX < 0) *currentX = -1;
	if (*currentX > hwrDisplayWidth) 
		*currentX = hwrDisplayWidth;
		
	if (*currentY < 0) *currentY = -1;
	if (*currentY > hwrSystemTop+hwrSystemHeight) 
		*currentY = hwrSystemTop+hwrSystemHeight;
}


/***********************************************************************
 *
 * FUNCTION:	FakeRandomMovement
 *
 * DESCRIPTION: Generate a random point.
 *
 * CALLED BY:  EmGremlins.cp
 *
 * PARAMETERS:	x -	the x-coordinate of a pen movement.
 *					y -	the y-coordinate of a pen movement.
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/15/95	Initial Revision
 *
 ***********************************************************************/
static void FakeRandomMovement(short* x, short* y)
{
	*x = randN(hwrDisplayWidth);
	*y = randN(hwrDisplayHeight);

}


/***********************************************************************
 *
 * FUNCTION:	FakeEvent
 *
 * DESCRIPTION: Generate random (x,y) coordindates to produce an event.
 *
 * CALLED BY:  EmGremlins.cp
 *
 * PARAMETERS:	x -	x-coordinate of a pen down.
 *					y -	y-coordinate of a pen down.
 *
 * RETURNED:	TRUE if an event was generated, FALSE if not event was
 *					generated.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/15/95	Initial Revision
 *
 ***********************************************************************/
static int FakeEvent(short* x, short* y)
{
	FormPtr frm;
#ifdef forSimulator
	unsigned short objIndex;
#else
	short objIndex;	// make it unsigned, otherwise the compare to -1 will always fail!
#endif
	unsigned short numObjects;
	RectangleType bounds;

#ifndef forSimulator
	// Every so often tap anywhere on the screen (2%)
	if (randN(100) < 2)
		{
		FakeRandomMovement(x, y);
		return true;
		}
#endif

	// Pick a point within one of the current form's objects
	frm = FrmGetActiveForm ();

	// Generate a point in the draw window if there no active form, or the active form 
	// is not the the active window.. The active window will not be the active form
	// if a popup list of a menu is displayed.
	//
	// Also do this if there aren't any objects in the form.
	if (!frm || 
		FrmGetWindowHandle (frm) != WinGetActiveWindow () ||
		(numObjects = FrmGetNumberOfObjects (frm)) == 0)
	{
#ifdef forSimulator	// Move this up higher so that we get the 10% random tap
					// on all occassions (including forms like the kind in one
					// application where all it had was a list object).
		// Every so often tap anywhere on the screen (10%)
		if (randN(10) == 1)
			{
			FakeRandomMovement(x, y);
			}
		else
#endif
			{
			WinGetWindowBounds (&bounds);
			*x = bounds.topLeft.x + randN(bounds.extent.x);
			*y = bounds.topLeft.y + randN(bounds.extent.y);
			}
	}
	else
	{
		// Generate a point in an one of the form's objects that we expect
		// can do something with the point (i.e. labels are ignored).

		// Ensure that the do loop that selects an object will exit.

#ifndef forSimulator
		bool	hasHotObject = false;
		for (unsigned short ii = 0; ii < numObjects; ++ii)
		{
			FormObjectKind	objType = FrmGetObjectType (frm, ii);

			switch (objType)
			{
				case frmBitmapObj:
				case frmLineObj:
				case frmFrameObj:
				case frmRectangleObj:
				case frmLabelObj:
				case frmTitleObj:
				case frmPopupObj:
					// do nothing for these
					break;
				
				default:
					hasHotObject = true;
					break;
			}
		}

		if (!hasHotObject)
		{
			WinGetWindowBounds (&bounds);
			*x = bounds.topLeft.x + randN(bounds.extent.x);
			*y = bounds.topLeft.y + randN(bounds.extent.y);
			return true;
		}
#endif

		do 
		{
			objIndex = randN(numObjects);
			switch (FrmGetObjectType (frm, objIndex))
			{
				case frmBitmapObj:
				case frmLineObj:
				case frmFrameObj:
				case frmRectangleObj:
				case frmLabelObj:
				case frmTitleObj:
				case frmPopupObj:
					// do nothing for these
					objIndex = -1;
					break;
				
				default:
					FrmGetObjectBounds (frm, objIndex, &bounds);
					*x = bounds.topLeft.x + randN(bounds.extent.x);
					*y = bounds.topLeft.y + randN(bounds.extent.y);
					WinWindowToDisplayPt(x, y);

					if (	*x < -1 || *x > 1000 || 
							*y < -1 || *y > 1000)
						ErrDisplay("Invalid point made");

					break;
			}	// end switch
		} while (objIndex == -1);	// don't leave until we found a useful object
	}	// end else
	return true;
}

/************************************************************
 *
 * FUNCTION: 	 GremlinsSendEvent
 *
 * DESCRIPTION: Send a synthesized event to the device if it's 
 *              idle.
 *
 * PARAMETERS:  nothing
 *
 * RETURNS:     nothing
 * 
 * CALLED BY:   the debugger's console object
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/2/95	Created.
 *
 *************************************************************/
#ifdef forSimulator

void GremlinsSendEvent (void)
{
	long						tick;
	Boolean					idle;
	LowMemType*				lowMemP = (LowMemType*)PilotGlobalsP;
	SysEvtMgrGlobalsPtr	sysEvtMgrGlobalsP;
	
	if (!theGremlins->IsInitialized())
		return;
		
	// If accessing remote device, low memory is at 0...
	#if MEMORY_TYPE == MEMORY_REMOTE 
	lowMemP = (LowMemType*)0;
	#endif
	
	// Find out if the device is idle.
	tick = StubTimGetTicks();
	if ((tick - IdleTimeCheck) >= 0)
		{
		sysEvtMgrGlobalsP = (SysEvtMgrGlobalsPtr)ShlDWord(&lowMemP->fixed.globals.sysEvtMgrGlobalsP);
		idle = ShlByte(&sysEvtMgrGlobalsP->idle);
		if (! idle) 
			{
			IdleTimeCheck = tick + 12;  // 10 times a second
			return;
			}
		else 
			IdleTimeCheck = 0;
	
		// Clear the idle bit so the the device will not send us another idle packet.
		// Send an event
		theGremlins->GetFakeEvent();	
	}
}
#endif


/************************************************************
 *
 * FUNCTION: 	 GremlinsProcessPacket
 *
 * DESCRIPTION: Send a synthesized event to the device if it's 
 *              idle.
 *
 * PARAMETERS:  bodyP - pointer to Gremlins packet from device.
 *
 * RETURNS:     nothing
 * 
 * CALLED BY:   the debugger's console object
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/2/95	Created.
 *
 *************************************************************/
#ifdef forSimulator

void GremlinsProcessPacket (void* bodyParamP)
{
	Byte						flags;
	SysPktGremlinsCmdType*	bodyP = (SysPktGremlinsCmdType*)bodyParamP;
	LowMemType*				lowMemP = (LowMemType*)PilotGlobalsP;
	SysEvtMgrGlobalsPtr	sysEvtMgrGlobalsP;
	
	if (!theGremlins->IsInitialized())
		return;
		
		
	// See which action code got sent us
	if (bodyP->action == sysPktGremlinsIdle) {

		// If accessing remote device, low memory is at 0...
		#if MEMORY_TYPE == MEMORY_REMOTE 
		lowMemP = (LowMemType*)0;
		#endif

		// Clear the idle bit so the the device will not send us another idle packet.
		// Send an event
		theGremlins->GetFakeEvent();
		
		// Turn the idle bit back on.
		sysEvtMgrGlobalsP = (SysEvtMgrGlobalsPtr)ShlDWord(&lowMemP->fixed.globals.sysEvtMgrGlobalsP);
		flags = ShlByte(&sysEvtMgrGlobalsP->gremlinsFlags);
		flags |= grmGremlinsIdle;
		ShlWriteMem (&flags, (DWord)&sysEvtMgrGlobalsP->gremlinsFlags, sizeof(Byte));

		flags = ShlByte(&sysEvtMgrGlobalsP->gremlinsFlags);
		ErrFatalDisplayIf (!(flags & grmGremlinsIdle), "Invalid flags");
		}
		
	else
		ErrDisplay("Invalid action code");
}
#endif


/************************************************************
 *
 * FUNCTION: Default Constructor
 *
 * DESCRIPTION: Finds the key probablilities sum.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: main() of EmEmulatorApp.cp
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/1/95	Created.
 *
 *************************************************************/
Gremlins::Gremlins()
{
	short i;
	
	keyProbabilitiesSum = 0;
	for (i = 0; i < NUM_OF_KEYS; i++) {
		keyProbabilitiesSum += chanceForKey[i];
	}
	inited = false;
	number = -1;
}

/************************************************************
 *
 * FUNCTION: Destructor
 *
 * DESCRIPTION: Any necessary deallocation or cleanup.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: main() of EmEmulatorApp.cp
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/1/95	Created.
 *
 *************************************************************/
Gremlins::~Gremlins()
{
}

/************************************************************
 *
 * FUNCTION: IsInitialized
 *
 * DESCRIPTION: Returns whether or not Gremlins has be initialized.
 *
 * PARAMETERS: None.
 *
 * RETURNS: TRUE - has been initialized, FALSE - has not been initialized.
 * 
 * CALLED BY: FindCommandStatus() in EmEmulatorApp.cp.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/1/95	Created.
 *
 *************************************************************/
Boolean Gremlins::IsInitialized() const
{
	return inited;
}


/************************************************************
 *
 * FUNCTION: Initialize
 *
 * DESCRIPTION: Initialize the gremlins class.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: ObeyCommand() in EmEmulatorApp.cp.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/1/95	Created.
 *
 *************************************************************/
void Gremlins::Initialize(unsigned short newNumber, unsigned long untilStep)
{

	counter = 0;
	until = untilStep;
	catchUp = false;
	needPenUp = false;
	charsToType[0] = '\0';
	inited = true;
	if (newNumber == -1)
		newNumber = INITIAL_SEED;
		//newNumber = clock() % MAX_SEED_VALUE + 1;	
	number = newNumber;
	srand(number);

	IdleTimeCheck = 0;
		
	// Update menus (needed when init. called from console)
	StubAppGremlinsOn ();
}


/************************************************************
 *
 * FUNCTION: Status
 *
 * DESCRIPTION: Return the gremlin number and counter.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: DoGremlins() in ShellCmdSys.cp.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/4/95	Created.
 *
 *************************************************************/
void Gremlins::Status(unsigned short *currentNumber, unsigned long *currentStep, 
	ULong *currentUntil)
{
	*currentNumber = number;
	*currentStep = counter;
	*currentUntil = until;
}


/************************************************************
 *
 * FUNCTION: SetSeed
 *
 * DESCRIPTION: Allows the user to set the seed to be used.
 *
 * PARAMETERS: newSeed -		the new value of the seed.
 *
 * RETURNS: TRUE - seed value set to new seed, FALSE - value not set.
 * 
 * CALLED BY: Uncalled. (to be called from Debug Console)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/2/95	Created.
 *
 *************************************************************/
Boolean Gremlins::SetSeed(unsigned long newSeed)
{
	if (newSeed > MAX_SEED_VALUE)
		return false;
	else
	{
		number = (unsigned short) newSeed;
		srand(number);
		return true;
	}
}

/************************************************************
 *
 * FUNCTION: SetUntil
 *
 * DESCRIPTION: Allows the user to set the until value to be used.
 *
 * PARAMETERS: newUntil -		the new value of until.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: Uncalled. (to be called from Debug Console)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/2/95	Created.
 *
 *************************************************************/
void Gremlins::SetUntil(unsigned long newUntil)
{
	until = newUntil;
}

/************************************************************
 *
 * FUNCTION: Step
 *
 * DESCRIPTION: Allows Gremlins to go on step further then its
 *						set maximum.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: ObeyCommand() in EmEmulatorApp.cp.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	8/1/95	Created.
 *
 *************************************************************/
void Gremlins::Step()
{
	until = counter + 1;
}




/************************************************************
 *
 * FUNCTION: SendCharsToType
 *
 * DESCRIPTION: Send a char to the emulator if any are pending.
 *
 * PARAMETERS: None.
 *
 * RETURNS: 	true if a char was sent.
 * 
 * CALLED BY: 	GetFakeEvent
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/4/95	Created.
 *
 *************************************************************/
Boolean Gremlins::SendCharsToType()
{
	if (charsToType[0] != '\0')
		{
		StubAppEnqueueKey(charsToType[0], 0, 0);
		strcpy(&charsToType[0], &charsToType[1]);
		return true;
		}
	
	return false;
}


/************************************************************
 *
 * FUNCTION: GetFakeEvent
 *
 * DESCRIPTION: Make a phony event for gremlin mode.
 *
 * PARAMETERS: 
 *
 * RETURNS: TRUE if a key or point was enqueues, FALSE otherwise.
 * 
 * CALLED BY: TDEProcessMacEvents in EmEmulatorEvents.cp.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			Roger	6/1/95	Created.
 *			David	7/31/95	Moved to emulator level.
 *
 *************************************************************/
Boolean Gremlins::GetFakeEvent()
{
	int chance;
	int i;
	int spaceLeft;
	Point pen;
	char *quote;
	
	if (! inited)
		return false;
	
	// check to see if Gremlins has produced its max. # of "events."
	if (counter > until)
	{
		StubAppGremlinsOff ();
		return false;
	}
	
	// check to see if the event loop needs time to catch up.
	if (catchUp)
	{
		catchUp = false;
		return false;
	}
	counter++;
	
	// if no control object was entered, return a pen up.
	if (needPenUp)
	{
		pen.h = -1;
		pen.v = -1;
		lastPoint.h = pen.h;
		lastPoint.v = pen.v;
		lastPenDown = false;
		needPenUp = false;
		StubAppEnqueuePt(&pen);
		return true;
	}
	
	
	if (SendCharsToType())
		return true;
		
	
	chance = randPercent;
	
	
	// Now fake an input
	if (chance < KEY_DOWN_EVENT_WITHOUT_FOCUS_CHANCE ||
		(chance < KEY_DOWN_EVENT_WITH_FOCUS_CHANCE && IsFocus()))
	{
		if (randPercent < TYPE_QUOTE_CHANCE && IsFocus())
			{
			quote = quotes[randN(NUM_OF_QUOTES)];
			strcat(charsToType, quote);
			
			// The full field functionality doesn't need to be tested much
			// If charsToType is more than the space remaining in the current
			// field, then for each char past the full point give 1/3 chance to
			// stop at that char.
			spaceLeft = SpaceLeftInFocus();
			if ((int) strlen(charsToType) > spaceLeft)
				{
				i = spaceLeft + 1;
				while (charsToType[i] != '\0')
					{
					if (randPercent < 33)
						{
						charsToType[i] = '\0';
						break;
						}
					i++;
					}
				}
			 
			SendCharsToType();
			return true;
			}
		else
			{
			chance = randN(keyProbabilitiesSum);
			for (i = 0; i < NUM_OF_KEYS; i++)
			{
				if (chance < chanceForKey[i])
					break;
				chance -= chanceForKey[i];
			}
			// There's a fractional chance for a greater number to be generated.  If
			// so we do nothing.
			if (i >= NUM_OF_KEYS)
				return false;	
			StubAppEnqueueKey(i, 0, (i > 255) ? commandKeyMask : 0);
			return true;
			}
	}		


	else if (chance < PEN_DOWN_EVENT_CHANCE)
	{
		if (!FakeEvent(&pen.h, &pen.v))
			return false;	// There's nothing to pen down on!
		
//		pen.h = randN(hwrDisplayWidth);
//		pen.v = randN(hwrDisplayHeight);
	
		lastPoint.h = pen.h;
		lastPoint.v = pen.v;
		lastPenDown = true;
		needPenUp = true;
		StubAppEnqueuePt(&pen);
		
		// Draw a test pixel on the overlay				
		StubViewDrawPixel(pen.h, pen.v);
		return true;
	}


	else if (chance < MENU_EVENT_CHANCE)
	{
		StubAppEnqueueKey(menuChr, menuChr, commandKeyMask);
	}
	

	else if (chance < FIND_EVENT_CHANCE)
	{
		StubAppEnqueueKey(findChr, findChr, commandKeyMask);
	}
	

	else if (chance < KEYBOARD_EVENT_CHANCE)
	{
		StubAppEnqueueKey(keyboardChr, keyboardChr, commandKeyMask);
	}

	
	else if (chance < LOW_BATTERY_EVENT_CHANCE)
	{
		StubAppEnqueueKey(lowBatteryChr, lowBatteryChr, commandKeyMask);
	}
	

	else if (chance < APP_SWITCH_EVENT_CHANCE)
	{
		if (randPercent < LAUNCHER_EVENT_CHANCE)
			{
			StubAppEnqueueKey(launchChr, launchChr, commandKeyMask);
			}
		else
			{
			Int hardKey;
			
			hardKey = hard1Chr + randN(hard4Chr - hard1Chr);
			StubAppEnqueueKey(hardKey, hardKey, commandKeyMask);
			}
		
	}
	

	// If nothing happened fall out to generate a nilEvent	
	return false;
}


/************************************************************
 *
 * FUNCTION: GetPenMovement
 *
 * DESCRIPTION: Make a phony pen movement.
 *
 * PARAMETERS: None.
 *
 * RETURNS: Nothing.
 * 
 * CALLED BY: 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			Roger	6/1/95	Created.
 *			David	7/31/95	Moved to emulator level.
 *
 *************************************************************/
void Gremlins::GetPenMovement()	
{
	Point	pen;


	// check to see if Gremlins has produced its max. # of "events."
/*	if (counter > until)
	{
		testMode &= ~gremlinsOn;
		theApp->UpdateMenus();
	}
*/	
	counter++;

	needPenUp = false;
	if (randPercent < PEN_MOVE_CHANCE)
	{
		if (lastPenDown)
		{
			// move a small distance from the last pen position
			if (randPercent < PEN_BIG_MOVE_CHANCE)
			{
				FakeRandomMovement(&pen.h, &pen.v);
			}
			else
			{
				FakeLocalMovement(&pen.h, &pen.v, lastPoint.h, lastPoint.v);
			}
		}
		else
		{
			// start the pen anywhere!
			FakeRandomMovement(&pen.h, &pen.v);
		}
		StubViewDrawLine(pen.h, pen.v, lastPoint.h, lastPoint.v);
	}
	else
	{
		lastPenDown = false;
		pen.h = -1;
		pen.v = -1;
		catchUp = true;
	}
	lastPoint.h = pen.h;
	lastPoint.v = pen.v;
	StubAppEnqueuePt(&pen);
}