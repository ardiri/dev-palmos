/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"
#include "Palm.h"		// EventPtr, PointPtr
#include "UAE.h"		// uae_u16

struct AppInfo
{
	ULong		creator;
	ULong		type;
	UInt		version;
	LocalID		dbID;
	UInt 		cardNo;
	ULong		modDate;
	Word		category;

	char		name[dmDBNameLength];
};

void			Gremlins_Initialize					(void);
void			Gremlins_Reset						(void);

bool			Gremlins_IsOn						(void);
bool			Gremlins_InSingleAppMode			(void);
bool			Gremlins_PostFakeEvent				(void);
void			Gremlins_PostFakePenEvent			(void);

uae_u32			Gremlins_GremlinNumber				(void);
uae_u32			Gremlins_EventNumber				(void);

void			Gremlins_AppToRun					(AppInfo*);
void			Gremlins_LogEvents					(bool);
void			Gremlins_LogTraps					(bool);
void			Gremlins_DisplayElapsed				(bool);

bool			Gremlins_IsEventLogging				(void);
bool			Gremlins_IsTrapLogging				(void);

void			Gremlins_New						(unsigned short newNumber,
													 unsigned long untilStep);
void			Gremlins_Step						(void);
void			Gremlins_Resume						(void);
void			Gremlins_Stop						(void);

bool			Gremlins_CanNew						(void);
bool			Gremlins_CanStep					(void);
bool			Gremlins_CanResume					(void);
bool			Gremlins_CanStop					(void);

void			Gremlins_RecordEvtEnqueuePenPoint	(PointType*);
void			Gremlins_RecordKeyHandleInterrupt	(Boolean periodic, DWord status);
void			Gremlins_RecordEvtEnqueueKey		(UInt ascii, UInt keycode, UInt modifiers);
void			Gremlins_RecordEvtGetEvent			(uaecptr event);
void			Gremlins_RecordEvtGetPen			(uaecptr pScreenX, uaecptr pScreenY, uaecptr pPenDown);
void			Gremlins_RecordTrapCall				(uae_u16);

// (doesn't really belong in Gremlins sub-system, but I don't
//  have a better location at the moment...)

void			Gremlins_GetApplicationNames		(AppInfo** appList, long* numApps);
