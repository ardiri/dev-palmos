/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "DebugMgr.h"

#include "Palm.h"

#include "Platform.h"		// Platform::SendPacket
#include "Byteswapping.h"	// Canonical
#include "CPU_REG.h"		// LowMem_GetFixedByte
#include "ATraps.h"			// ATrap
#include "UAE_Utils.h"		// uae_strncpy
#include "TrapPatches.h"	// RemoveAllTailpatches, InstallAllTailpatches
#include "StringData.h"		// kTrapNames

#include <ctype.h>			// isalpha, tolower

#define kOpcode_LINK	0x4E50
#define kOpcode_RTE		0x4E73
#define kOpcode_RTD		0x4E74
#define kOpcode_RTS		0x4E75
#define kOpcode_JMP		0x4ED0


// Types

#pragma mark Types

struct SysPktEmptyRspType
{
	_sysPktBodyCommon;								// Common Body header
};


// Globals

#pragma mark Globals

DebugGlobalsType	gDebuggerGlobals;

SlkPktHeaderType*	gLatestHeader;


// ---------------------------------------------------------------------------
//		� Diagnostics
// ---------------------------------------------------------------------------

#if LOG_DEBUGGER

extern void PRINTF (const char* msg, ...);

#else

inline void PRINTF (const char*) {}
template <class T1> inline void PRINTF (const char*, T1) {}
template <class T1, class T2> inline void PRINTF (const char*, T1, T2) {}
template <class T1, class T2, class T3> inline void PRINTF (const char*, T1, T2, T3) {}

#endif


// Functions

#pragma mark Functions


/*
	+- Called by Debugger
	|	+- Implemented
	|	|								Command
	|	|	Command name				Number
	-------	---------------------------	-----------
	*	*	sysPktStateCmd				0x00		SysPktStateCmdType				SysPktStateRspType
	*	*	sysPktReadMemCmd			0x01		SysPktReadMemCmdType			SysPktReadMemRspType
	*	*	sysPktWriteMemCmd			0x02		SysPktWriteMemCmdType			SysPktWriteMemRspType
	*	.	sysPktSingleStepCmd			0x03		
	*	*	sysPktGetRtnNameCmd			0x04		SysPktRtnNameCmdType			SysPktRtnNameRspType
	*	*	sysPktReadRegsCmd			0x05		SysPktReadRegsCmdType			SysPktReadRegsRspType
	*	*	sysPktWriteRegsCmd			0x06		SysPktWriteRegsCmdType			SysPktWriteRegsRspType
	*	*	sysPktContinueCmd			0x07		SysPktContinueCmdType			<no response>
	*	*	sysPktRPCCmd				0x0A		SysPktRPCType
		*	sysPktGetBreakpointsCmd		0x0B		SysPktGetBreakpointsCmdType		SysPktGetBreakpointsRspType
	*	*	sysPktSetBreakpointsCmd		0x0C		SysPktSetBreakpointsCmdType		SysPktSetBreakpointsRspType
		.	sysPktRemoteUIUpdCmd		0x0C		SysPktRemoteUIUpdCmdType
		.	sysPktRemoteEvtCmd			0x0D		SysPktRemoteEvtCmdType
	*	*	sysPktDbgBreakToggleCmd		0x0D		SysPktDbgBreakToggleCmdType		SysPktDbgBreakToggleRspType
	*	.	sysPktFlashCmd				0x0E		SysPktFlashWriteType
	*	.	sysPktCommCmd				0x0F		SysPktCommCmdType				SysPktCommRspType
	*	*	sysPktGetTrapBreaksCmd		0x10		SysPktGetTrapBreaksCmdType		SysPktGetTrapBreaksRspType
	*	*	sysPktSetTrapBreaksCmd		0x11		SysPktSetTrapBreaksCmdType		SysPktSetTrapBreaksRspType
		+	sysPktGremlinsCmd			0x12		SysPktGremlinsCmdType
	*	*	sysPktFindCmd				0x13		SysPktFindCmdType				SysPktFindRspType
		*	sysPktGetTrapConditionsCmd	0x14		SysPktGetTrapConditionsCmdType	SysPktGetTrapConditionsRspType
		*	sysPktSetTrapConditionsCmd	0x15		SysPktSetTrapConditionsCmdType	SysPktSetTrapConditionsRspType
		.	sysPktChecksumCmd			0x16		SysPktChecksumType
		.	sysPktExecFlashCmd			0x17		sysPktExecFlashType
	*	*	sysPktRemoteMsgCmd			0x7f		SysPktRemoteMsgCmdType
*/


#pragma mark -


// ---------------------------------------------------------------------------
//		� Debug::Initialize
// ---------------------------------------------------------------------------
// Initialize our debugging hooks.  Sets flags to tell the CPU loop to exit
// if any of the exceptions that we're interested in are encountered.  If an
// exception is encountered, the emulator calls Debug::EnterDebugger.

/*-----------------------------------------------------------------------------------*\

	Notes on side-stepping the ROM debugger:

		The debugger manipulates the following low-memory globals:
		
		Byte	dbgWasEntered;		// set true the first time debugger is entered
		Byte	dbgInDebugger;		// true if in debugger
		Byte	dbgTracing;			// tracing in debugger
		Ptr		dbgGlobalsP;		// pointer to dbgGlobals
		Ptr		dbgSerGlobalsP;		// pointer to Debugger Serial globals

		We set dbgWasEntered and dbgInDebugger in EnterDebugger.  We clear
		dbgInDebugger in ExitDebugger.  Both of these values are examined by
		other parts of the ROM.
		
		dbgTracing is set when the ROM debugger needs to single step.  It needs
		to single-step if there are breakpoints in the ROM, or if we need to
		execute over an installed breakpoint.  We have other ways to do these
		(we can actually install breakpoints into the ROM, and our CPU loop has
		a mechanism for fetching the opcode that is currently overwritten by
		a breakpoint), so we never have to set dbgTracing to true.

		dbgGlobalsP appears to be accessed only by the ROM debugger code.  Since
		we should intercept everything that would cause that code to be accessed,
		we shouldn't have to do anything with that block.

		dbgSerGlobalsP is initialized by DbgInit.  None of the ROM debugger code
		looks at it.  Only the serial code does.

	May want to patch the following traps:

		ConGetS
		ConPutS
		
		sysTrapDbgSrcMessage
		sysTrapDbgMessage
		sysTrapDbgGetMessage
		sysTrapDbgCommSettings

\*-----------------------------------------------------------------------------------*/

void Debug::Initialize (void)
{
	memset (&gDebuggerGlobals, 0, sizeof (gDebuggerGlobals));

	// Install functions that will cause the CPU loop to exit if we're
	// connected to an external debugger.

	Software::InstallExceptionHandler (kException_BusErr, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_AddressErr, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_IllegalInstr, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_DivideByZero, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_Chk, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_Trap, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_Privilege, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_Trace, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_ATrap, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_FTrap, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_AutoVec7, Debug::BreakIfConnected);
	Software::InstallExceptionHandler (kException_Trap0 + sysDbgBreakpointTrapNum, Debug::BreakIfConnected);

	// This one's a little different.  We want to exit the CPU loop
	// on a TRAP 8, but we want to do it conditionally.  If desired,
	// HandleTrap8 will cause the CPU loop to exit (leaving the PC just
	// after the TRAP instruction).  Otherwise, it will treat the TRAP
	// like a NOP.

	Software::InstallExceptionHandler (kException_Trap0 + sysDbgTrapNum,
										Debug::HandleTrap8);

#if 0	// !!! TBD

	// Install Debugger Traps into trap table
	dispatchTableP[ TrapIndex (sysTrapDbgSrcMessage) ] = (Ptr)DbgMessage;
	dispatchTableP[ TrapIndex (sysTrapDbgMessage) ] = (Ptr)DbgMessage;
	dispatchTableP[ TrapIndex (sysTrapDbgGetMessage) ] = (Ptr)DbgGetMessage;
	dispatchTableP[ TrapIndex (sysTrapDbgCommSettings) ] = (Ptr)DbgCommSettings;

#endif

	// Open a line to the external debugger (if any).

	Platform::ConnectToDebugger ();
}


// ---------------------------------------------------------------------------
//		� Debug::Reset
// ---------------------------------------------------------------------------

void Debug::Reset (void)
{
	// !!! What happens to the uninstalled breakpoints? What's the
	// external debugger expecting?

	gDebuggerGlobals.firstEntrance	= true;
	gDebuggerGlobals.inDebugger = false;
}


// ---------------------------------------------------------------------------
//		� Debug::HandleNewPacket
// ---------------------------------------------------------------------------
// Completely handle a packet sent from an external debugger, setting any
// state and sending a reply if necessary.
//
// pkt is a reference to a generic packet buffer.  This buffer is large
// enough to hold any currently-defined message.  The contents of the packet
// are determined by the first byte of the packet, which contains a command
// number.  We switch on that command number, cast the packet to the right
// data type, and call a handler function.

uae_u32 Debug::HandleNewPacket (const SlkPktHeaderType& hdr,
								const SysPktBodyType& pkt)
{
	PRINTF ("Entering Debug::HandleNewPacket.");

	// Make a copy of everything (in case we change it in place, we
	// don't upset the caller).

	SlkPktHeaderType	header = hdr;
	SysPktBodyType		packet = pkt;

	// Byteswap the data (if necessary).

	Canonical (header);
	Canonical (packet);

	// If this isn't for the debugger, just return.  Yeah, this just drops
	// the packet on the floor; we might want to form a better response
	// than that sometime later.

	if ((header.src != slkSocketDebugger) && (header.src != slkSocketConsole))
	{
		PRINTF ("Packet not for us; leaving Debug::HandleNewPacket.");

		return kError_NoError;
	}

	// Give us full access to RAM, ROM, Dragonball registers, low-mem, etc.

	CEnableFullAccess	munge;	// Remove blocks on memory access.

	// Goose the ROM, so it doesn't go to sleep while we're exchanging packets.
	// Do this by hand; we can't call ROM functions as subroutines while in
	// the debugger (we don't know what state the ROM is in).

//	EvtResetAutoOffTimer ();
	LowMem_SetGlobal (sysAutoOffEvtTicks, LowMem_GetGlobal (hwrCurTicks));

	// Keep a reference to the header, so that we can use it when forming replies.

	gLatestHeader = &header;

	uae_u32	result = 0;

	switch (packet.command)
	{
		case sysPktStateCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktStateCmd.");
			result = Debug::SendState ();
			break;

		case sysPktReadMemCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktReadMemCmd.");
			result = Debug::ReadMem ((SysPktReadMemCmdType&) packet);
			break;

		case sysPktWriteMemCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktWriteMemCmd.");
			result = Debug::WriteMem ((SysPktWriteMemCmdType&) packet);
			break;

		case sysPktSingleStepCmd:
			// I don't think there's anything to do here.  I think that
			// single-stepping is performed by the debugger setting the
			// trace bit in the SR and sending a sysPktContinueCmd.
			PRINTF ("Debug::HandleNewPacket -- sysPktSingleStepCmd.");
			break;

		case sysPktGetRtnNameCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktGetRtnNameCmd.");
			result = Debug::SendRoutineName ((SysPktRtnNameCmdType&) packet);
			break;

		case sysPktReadRegsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktReadRegsCmd.");
			result = Debug::ReadRegs ((SysPktReadRegsCmdType&) packet);
			break;

		case sysPktWriteRegsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktWriteRegsCmd.");
			result = Debug::WriteRegs ((SysPktWriteRegsCmdType&) packet);
			break;

		case sysPktContinueCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktContinueCmd.");
			result = Debug::Continue ((SysPktContinueCmdType&) packet);
			break;

		case sysPktRPCCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktRPCCmd.");
			result = Debug::RPC ((SysPktRPCType&) packet);
			break;

		case sysPktGetBreakpointsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktGetBreakpointsCmd.");
			result = Debug::GetBreakpoints ((SysPktGetBreakpointsCmdType&) packet);
			break;

		case sysPktSetBreakpointsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktSetBreakpointsCmd.");
			result = Debug::SetBreakpoints ((SysPktSetBreakpointsCmdType2&) packet);
			break;

//		case sysPktRemoteUIUpdCmd:
//			// Sent TO debugger; never received FROM debugger.
//			break;

//		case sysPktRemoteEvtCmd:
//			// Sent TO debugger; never received FROM debugger.
//			break;

		case sysPktDbgBreakToggleCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktDbgBreakToggleCmd.");
			result = Debug::ToggleBreak ((SysPktDbgBreakToggleCmdType&) packet);
			break;

		case sysPktFlashCmd:
			// Not supported in this release.
			PRINTF ("Debug::HandleNewPacket -- sysPktFlashCmd.");
			break;

		case sysPktCommCmd:
			// Not supported in this release.
			PRINTF ("Debug::HandleNewPacket -- sysPktCommCmd.");
			break;

		case sysPktGetTrapBreaksCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktGetTrapBreaksCmd.");
			result = Debug::GetTrapBreaks ((SysPktGetTrapBreaksCmdType&) packet);
			break;

		case sysPktSetTrapBreaksCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktSetTrapBreaksCmd.");
			result = Debug::SetTrapBreaks ((SysPktSetTrapBreaksCmdType2&) packet);
			break;

		case sysPktGremlinsCmd:
			// !!! TBD.
			PRINTF ("Debug::HandleNewPacket -- sysPktGremlinsCmd.");
			break;

		case sysPktFindCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktFindCmd.");
			result = Debug::Find ((SysPktFindCmdType&) packet);
			break;

		case sysPktGetTrapConditionsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktGetTrapConditionsCmd.");
			result = Debug::GetTrapConditions ((SysPktGetTrapConditionsCmdType&) packet);
			break;

		case sysPktSetTrapConditionsCmd:
			PRINTF ("Debug::HandleNewPacket -- sysPktSetTrapConditionsCmd.");
			result = Debug::SetTrapConditions ((SysPktSetTrapConditionsCmdType2&) packet);
			break;

		case sysPktChecksumCmd:
			// Not supported in this release.
			PRINTF ("Debug::HandleNewPacket -- sysPktChecksumCmd.");
			break;

		case sysPktExecFlashCmd:
			// Not supported in this release.
			PRINTF ("Debug::HandleNewPacket -- sysPktExecFlashCmd.");
			break;

		case sysPktRemoteMsgCmd:
			// Nothing for us to do.  With a serial link,
			// these are sent to clear the input port.
			PRINTF ("Debug::HandleNewPacket -- sysPktRemoteMsgCmd.");
			break;

		default:
			PRINTF ("Debug::HandleNewPacket -- unknown command.");
			break;
	}

	// Zap our reference to the latest header now that we're done with it.

	gLatestHeader = NULL;

	return result;
}


// ---------------------------------------------------------------------------
//		� Debug::SendPacket
// ---------------------------------------------------------------------------
// Sends the given packet to the external debugger.

uae_u32 Debug::SendPacket (const void* pkt, long size)
{
	PRINTF ("Entering Debug::SendPacket.");

	// Gen up a header.  If we're replying to a packet from the external
	// debugger, use the information from it to form a reply (socket
	// numbers and transaction ID).  Otherwise, stuff in some of our
	// own values.  We don't use checksums right now, so just leave
	// that at zero.

	SlkPktHeaderType	header;

	if (gLatestHeader)
	{
		header.signature1	= slkPktHeaderSignature1;
		header.signature2	= slkPktHeaderSignature2;
		header.dest			= gLatestHeader->src;
		header.src			= gLatestHeader->dest;
		header.type			= slkPktTypeSystem;
		header.bodySize		= size;
		header.transId		= gLatestHeader->transId;
		header.checksum		= 0;
	}
	else
	{
		header.signature1	= slkPktHeaderSignature1;
		header.signature2	= slkPktHeaderSignature2;
		header.dest			= slkSocketDebugger;
		header.src			= slkSocketDebugger;
		header.type			= slkPktTypeSystem;
		header.bodySize		= size;
		header.transId		= 0;
		header.checksum		= 0;
	}

	// Fold all the parts into a buffer: header, body, footer.

	char	buffer[	sizeof (SlkPktHeaderType) +
					sizeof (SysPktBodyType) +
					sizeof (SlkPktFooterType)];

	memcpy (buffer, &header, sizeof (header));
	memcpy (buffer + sizeof (SlkPktHeaderType), pkt, size);

	// Byteswap, if necessary.

	Canonical (*(SlkPktHeaderType*) buffer);
	Canonical (*(SysPktBodyType*) (buffer + sizeof (SlkPktHeaderType)));

	// Send it to the external debugger.

	uae_u32	result = Platform::SendPacket(buffer, sizeof (SlkPktHeaderType) + size);

	PRINTF ("Exiting Debug::SendPacket.");

	return result;
}


// ---------------------------------------------------------------------------
//		� Debug::SendResponse
// ---------------------------------------------------------------------------
// Sends a simple null-body message to the external debugger.

uae_u32 Debug::SendResponse (int rsp)
{
	SysPktEmptyRspType	response;

	response.command = rsp;
	response._filler = 0;

	return Debug::SendPacket(&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::BreakIfConnected
// ---------------------------------------------------------------------------
// Handle the given exception.  If we're connected to a debugger, we want to
// let it handle it, so change the CPU state and return TRUE (to say that
// we handled the execption).  Otherwise return false to perform default
// handling (which means handing it off to the emulated ROM).

bool Debug::BreakIfConnected (uae_s32 exceptionNumber)
{
	// Attempt to enter the debugger.  If we succeed, set the break-reason
	// so that the CPU loop exits.  Then return true to say that we
	// handled the exception.

	if (Debug::EnterDebugger (exceptionNumber) == kError_NoError)
	{
		Emulator::SetBreakReason (exceptionNumber);

		return true;
	}

	// We were unable to enter the debugger (perhaps there was no external
	// debugger running).  Return false to cause normal processing to occur
	// (which is probably to let the emulated ROM handle the exception,
	// either by contacting a debugger over the serial port, or by showing
	// a fatal exception error).

//	return false;

	// Ohhh...let's not do that.  Letting the ROM debug stubs take over isn't
	// really a good idea; they tend to hang the ROM, and the user wouldn't
	// like that.  Instead, let's show a dialog that let's them Reset.

	char*	msg = Platform::GetString (kStringErrException);
	char*	appName	= Utility::GetAppName ();
	char*	version = Utility::GetAppVersion ();
	char*	operation = Platform::GetString (kStringExceptionBase + exceptionNumber);

	msg = Utility::ReplaceParameter (msg, "%application", appName);
	msg = Utility::ReplaceParameter (msg, "%version", version);
	msg = Utility::ReplaceParameter (msg, "%operation", operation);

	Platform::ErrorDialog (msg, kMsgReset);

	free (msg);
	free (appName);
	free (version);
	free (operation);

	Emulator::Reset();

	return true;
}


// ---------------------------------------------------------------------------
//		� Debug::HandleTrap8
// ---------------------------------------------------------------------------
// The CPU just encountered a TRAP 8, which is what gets compiled into the
// developer's code when he "calls" the DbgBreak or DbgSrcBreak "function".
// HandleTrap8 determines whether or not this TRAP 8 should be handled as
// an exception (in which case we'd enter the debugger) or should be skipped
// like a NOP. If "ignoreDbgBreaks" is true, then merely return TRUE to say
// that we completely handled the exception.  Otherwise, change the CPU
// state to non-running before we return TRUE.

bool Debug::HandleTrap8 (uae_s32 exceptionNumber)
{
	if (gDebuggerGlobals.ignoreDbgBreaks)
	{
		return true;
	}

	return Debug::BreakIfConnected (exceptionNumber);
}


// ---------------------------------------------------------------------------
//		� Debug::HandleTrap15
// ---------------------------------------------------------------------------
// An A-Trap is about to be executed.  This function is called to determine
// if we want to break on this A-Trap.  If there are A-Trap breaks registered
// with the debugger, and if the "continuing" flag is not set (if it were
// set, that would mean that we'd just exited the debugger, and don't need to
// re-break on the A-Trap that caused us to enter the debugger), then scan
// the break table to see if the A-Trap we're about to execute is one we want
// to break on.
//
// If it is, set the CPU break reason to kException_Trace, which will cause
// the CPU to break at the end of this opcode.  Also return TRUE, which tells
// the normal A-Trap handler that we completely handled this A-Trap, and that
// it doesn't need to do any trap dispatcher stuff.  Finally, back-up the PC
// so that it points to the A-Trap again so that when we resume execution we'll
// start at that A-Trap.

bool Debug::HandleTrap15 (void)
{
	bool	doBreak = false;

	if (!gDebuggerGlobals.continuing && gDebuggerGlobals.breakingOnATrap)
	{
		// Get the trapword, and then keep only the low 12 bits of it.
		// Apparently, that's what the debugger sends us when it wants
		// to break on a trap.

		uae_u16	trapWord = get_word (m68k_getpc ()) & 0x0FFF;

		// Do different compares for system traps and library traps.

		if (trapWord < 0x0800)
		{
			for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
			{
				if (trapWord == gDebuggerGlobals.trapBreak[ii])
				{
					doBreak = true;
					break;
				}
			}
		}
		else
		{
			uae_u16	refNum = get_word (m68k_areg (regs, 7));

			for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
			{
				if (trapWord == gDebuggerGlobals.trapBreak[ii] &&
					refNum == gDebuggerGlobals.trapParam[ii])
				{
					doBreak = true;
					break;
				}
			}
		}

		// If we're supposed to break here and we can successfully contact an
		// external debugger, set the CPU state so that the CPU loop breaks at
		// the end of the current instruction.  Also back up the PC to point to
		// the TRAP instruction instead of the $Axxx selector.
		//
		// Ooops...gotta make sure we fudge the PC _before_ sending the state
		// to the debugger...

		if (doBreak)
		{
			m68k_setpc (m68k_getpc () - 2);

			if (Debug::EnterDebugger (kException_Trace) == kError_NoError)
			{
				Emulator::SetBreakReason (kException_Trace);
			}
			else
			{
				m68k_setpc (m68k_getpc () + 2);
			}
		}
	}

	// Clear the flag telling us to inhibit the ATrapBreak check.

	gDebuggerGlobals.continuing = false;

	return doBreak;
}


// ---------------------------------------------------------------------------
//		� Debug::EnterDebugger
// ---------------------------------------------------------------------------
// Put the emulator into "debug mode".  This pretty much consists of setting
// up a bunch of flags, figuring out why we entered the debugger, and telling
// the external debugger that we've entered debug mode and what the current
// CPU state is.
//
//	Reasons for entering the debugger:
//
//		Single step:
//			reason == kException_Trace
//
//			Normal processing.
//
//		Step spy:
//			reason == kException_Trace
//
//			Normal processing.
//
//		User breakpoint (temporary or otherwise):
//			reason == kException_Trap0 + sysDbgBreakpointTrapNum
//
//			Normal processing.
//
//		Compiled breakpoint (DbgBreak, DbgSrcBreak):
//			reason == kException_Trap0 + sysDbgTrapNum
//
//			Ignore if DbgGlobalsType.ignoreDbgBreaks is true.
//			
//			Actually, now we catch this one a little earlier.  In
//			Software_ProcessException, we call an installed exception
//			handler that leads to calling Debug::HandleTrap8.  That
//			function will return TRUE if ignoreDbgBreaks is true, which
//			will effectively turn the TRAP 8 into a NOP.  Otherwise, it
//			returns false, which will lead to EnterDebugger being called
//			to handle the exception.
//
//		"A-Trap" break:
//			reason == kException_Trace
//
//			When looking for an A-Trap to break on, the debugger uses
//			a special trap dispatcher.  Called on every TRAP F, when it
//			finds a trap to break on, it sets DbgGlobalsType.breakingOnATrap,
//			sets the tracing SR bit, and then calls the original trap
//			dispatcher.
//
//			Because the trap dispatcher is run in supervisor mode, the
//			tracing bit doesn't do anything until it RTE's.
//
//			Normal processing.
//
//		Exception (bus error, address error, etc):
//			reason == exception code
//
//			Normal processing.
//
//	The debugger is silently entered if reason == kException_Trace.
//	Otherwise, it displays a message saying what exception occured.

uae_u32 Debug::EnterDebugger (uae_s32 reason)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	// If we entered due to a breakpoint, backup the PC.  The opcode that
	// used to be in this memory location will be dealt with in ExitDebugger.

	if (reason == (kException_Trap0 + sysDbgBreakpointTrapNum))
	{
		m68k_setpc (m68k_getpc () - 2);
	}

	// Save the reason for our entering the debugger.

	gDebuggerGlobals.excType = (Word) (reason * 4);

	// If we're re-entering the debugger, note that fact.

	gDebuggerGlobals.reEntered = LowMem_GetGlobal (dbgInDebugger) != 0;

	// Replace breakpoint instructions with the opcode that normally
	// live there.  Do this _before_ sending the state to the debugger,
	// or else the debugger will see any breakpoints that might be
	// in the instruction stream the state message includes.

	Debug::RemoveBreakpoints ();
	Patches::RemoveAllTailpatches ();

	// Clear temporary breakpoint if we hit it.

	if (m68k_getpc () == (uaecptr) gDebuggerGlobals.bp[dbgTempBPIndex].addr)
	{
		gDebuggerGlobals.bp[dbgTempBPIndex].enabled = false;
		gDebuggerGlobals.bp[dbgTempBPIndex].addr = NULL;
	}

	// Turn off sound in case it was on when the debugger was entered.

	uae_u16	pwmControl = READ_REGISTER (pwmControl);
	WRITE_REGISTER (pwmControl, pwmControl & ~hwr328PWMControlEnable);

	// Send a state message packet notifying the host that we've entered.
	// If we can't send the packet (perhaps because there is no external
	// debugger listening) return false saying that we failed to enter
	// the debugger.  When we return false, we indicate that perhaps the
	// emulated ROM debugger should take over.
	//
	// Concurrency note: in the multi-threaded version of the emulator,
	// EnterDebugger will be called from one thread (the CPU thread),
	// while the UI thread will be listening for packets from the
	// external debugger.  When SendState sends the packet from this
	// thread, the external debugger could receive it and send us back
	// a message immediately.  The question is, is this OK?  Are there
	// problems with the UI thread trying to debug us before the CPU
	// thread has had a chance to stop itself? Let's see: the UI thread
	// will receive the message, and start to handle it by telling the
	// CPU thread to stop.  That means that we should have a chance to
	// clean up (set our flags, remove breakpoints, etc.) and stop before
	// the UI thread tries to debug us.

	uae_u32	result = Debug::SendState ();
	if (result != kError_NoError)
	{
		// Re-install the breakpoints.

		Debug::InstallBreakpoints ();
		Patches::InstallAllTailpatches ();

		// Reverse the pc-munging that we did earlier.

		m68k_setpc (m68k_getpc () + 2);
		
		return result;
	}

	// Flag to the ROM that we're in the debugger. "dbgInDebugger" get's
	// cleared in ExitDebugger. "dbgWasDebugger" stays set to true.

	LowMem_SetGlobal (dbgWasEntered, true);
	LowMem_SetGlobal (dbgInDebugger, true);
	gDebuggerGlobals.inDebugger = true;

	// Return "no error" to say that we successfully entered the debugger.

	return kError_NoError;
}


// ---------------------------------------------------------------------------
//		� Debug::ExitDebugger
// ---------------------------------------------------------------------------

uae_u32 Debug::ExitDebugger (void)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	// Install the breakpoints.

	Debug::InstallBreakpoints ();
	Patches::InstallAllTailpatches ();

	// If we're on a breakpoint, set the "next opcode" so that we execute it and not
	// the breakpoint opcode.  If we entered the debugger because of a soft
	// breakpoint, then the PC has already been backed up (in EnterDebugger) to
	// point at the memory location again.

	for (int ii = 0; ii < dbgTotalBreakpoints; ++ii)
	{
		if (!gDebuggerGlobals.bp[ii].installed)
			continue;

		uaecptr	addr = (uaecptr) gDebuggerGlobals.bp[ii].addr;
		if (!addr)
			continue;
		
		// See if the PC is on this breakpoint.

		if (addr == m68k_getpc ())
		{
			Emulator::SetNextOpcode (gDebuggerGlobals.bpOpcode[ii]);
			break;
		}		
	}

	// Set a flag saying that we are continuing now.  That way, we won't
	// re-break on the same A-Trap or DbgBreak() statement that got us here
	// in the first place.

	gDebuggerGlobals.continuing = true;

	// Set flags that we're no longer in the debugger.

	gDebuggerGlobals.excType = 0;
	LowMem_SetGlobal (dbgInDebugger, false);
	gDebuggerGlobals.inDebugger = false;

	return kError_NoError;
}


// ---------------------------------------------------------------------------
//		� Debug::InDebugger
// ---------------------------------------------------------------------------

bool Debug::InDebugger (void)
{
	return gDebuggerGlobals.inDebugger;
}


// ---------------------------------------------------------------------------
//		� Debug::InstallBreakpoints
// ---------------------------------------------------------------------------

void Debug::InstallBreakpoints (void)
{
	// Install the breakpoints.
	
	for (int ii = 0; ii < dbgTotalBreakpoints; ++ii)
	{
		if (gDebuggerGlobals.bp[ii].enabled)
		{
			uaecptr	addr = (uaecptr) gDebuggerGlobals.bp[ii].addr;
			if (addr)
			{	
				// Save the old opcode.
		
				gDebuggerGlobals.bpOpcode[ii] = get_word (addr);
		
				// Put in the breakpoint instruction (TRAP 0).
		
				put_word (addr, m68kTrapInstr + sysDbgBreakpointTrapNum);
		
				// Mark it as installed.

				gDebuggerGlobals.bp[ii].installed = true;
			}
		}
	}
}


// ---------------------------------------------------------------------------
//		� Debug::RemoveBreakpoints
// ---------------------------------------------------------------------------

void Debug::RemoveBreakpoints (void)
{
	// Restore breakpoint instruction words that are installed

	for (int ii = 0; ii < dbgTotalBreakpoints; ++ii)
	{
		if (gDebuggerGlobals.bp[ii].installed)
		{		
			uaecptr	addr = (uaecptr) gDebuggerGlobals.bp[ii].addr;
	
			put_word (addr, gDebuggerGlobals.bpOpcode[ii]);
	
			gDebuggerGlobals.bp[ii].installed = false;
		}
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Debug::SendState
// ---------------------------------------------------------------------------

uae_u32 Debug::SendState ()
{
	SysPktStateRspType	response;

	// Fill in the response.

	// Command.

	response.command		= sysPktStateRsp;
	response._filler		= 0;

	// Get the resetted boolean.  This flag is true if the "device" has
	// been resetted since the last time we sent a packet.  The debugger
	// needs to know this in order to update it's notion of the device's
	// state (like, for instance, if breakpoints are installed).

	response.resetted		= gDebuggerGlobals.firstEntrance;
	gDebuggerGlobals.firstEntrance = false;

	// Get the exception id.

	response.exceptionId	= gDebuggerGlobals.excType;

	// Get the registers.

	GetRegs (response.reg);

	// Get the breakpoints.

	for (int i = 0; i < dbgTotalBreakpoints; i++)
		response.bp[i] = gDebuggerGlobals.bp[i];

	// Get some code beginning at PC.

	for (int ii = 0; ii < sysPktStateRspInstWords; ++ii)
		response.inst[ii] = get_word (m68k_getpc () + ii * 2);

	// Get the routine name and address range info.

	Err	err = Debug::GetRoutineName (	m68k_getpc (),
										response.name,
										(uaecptr*) &response.startAddr,
										(uaecptr*) &response.endAddr);
	if (err)
	{
		response.name[0] = 0;
	}

	// Send the rev of the trap table.

	response.trapTableRev	= LowMem_GetGlobal (sysDispatchTableRev);

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::ReadMem
// ---------------------------------------------------------------------------

uae_u32 Debug::ReadMem (SysPktReadMemCmdType& packet)
{
	PRINTF ("Debug::ReadMem: address = 0x%08X, length = 0x%08X.", packet.address, packet.numBytes);

	// Use generic system packet body.
	// Allows for command, _filler, and (256 + 16 - 2) bytes of data.

//	SysPktReadMemRspType	response;
	SysPktBodyType			response;

	response.command	= sysPktReadMemRsp;
	response._filler	= 0;

	uae_memcpy ((char*) (&response.data), (uaecptr) packet.address,
				packet.numBytes);

	return Debug::SendPacket (&response, sizeof (SysPktReadMemRspType) + packet.numBytes);
}


// ---------------------------------------------------------------------------
//		� Debug::WriteMem
// ---------------------------------------------------------------------------

uae_u32 Debug::WriteMem (SysPktWriteMemCmdType& packet)
{
	PRINTF ("Debug::WriteMem: address = 0x%08X, length = 0x%08X.", packet.address, packet.numBytes);

	uae_memcpy ((uaecptr) packet.address, (const char*) ((&packet) + 1),
				packet.numBytes);

	return Debug::SendResponse (sysPktWriteMemRsp);
}


// ---------------------------------------------------------------------------
//		� Debug::SendRoutineName
// ---------------------------------------------------------------------------

uae_u32 Debug::SendRoutineName (SysPktRtnNameCmdType& packet)
{
	SysPktRtnNameRspType	response;

	response.command	= sysPktGetRtnNameRsp;
	response._filler	= 0;
	response.address	= (void*) packet.address;
	response.startAddr	= NULL;
	response.endAddr	= NULL;
	response.name[0]	= 0;

	Err	err = Debug::GetRoutineName((uaecptr) packet.address,
									response.name,
									(uaecptr*) &response.startAddr,
									(uaecptr*) &response.endAddr);

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::ReadRegs
// ---------------------------------------------------------------------------

uae_u32 Debug::ReadRegs (SysPktReadRegsCmdType&)
{
	SysPktReadRegsRspType2	response;

	response.command	= sysPktReadRegsRsp;
	response._filler	= 0;

	Debug::GetRegs (response.reg);

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::WriteRegs
// ---------------------------------------------------------------------------

uae_u32 Debug::WriteRegs (SysPktWriteRegsCmdType& packet)
{
	Debug::SetRegs (packet.reg);

	return Debug::SendResponse (sysPktWriteRegsRsp);
}


// ---------------------------------------------------------------------------
//		� Debug::Continue
// ---------------------------------------------------------------------------

uae_u32 Debug::Continue (SysPktContinueCmdType& packet)
{
	Debug::SetRegs (packet.regs);

	gDebuggerGlobals.stepSpy = packet.stepSpy != 0;
	gDebuggerGlobals.ssAddr = packet.ssAddr;
	// ssCount is ignored?
	gDebuggerGlobals.ssValue = packet.ssCheckSum;

	return Debug::ExitDebugger ();
}


// ---------------------------------------------------------------------------
//		� Debug::RPC
// ---------------------------------------------------------------------------

uae_u32 Debug::RPC (SysPktRPCType& packet)
{
	PRINTF ("Debug::RPC: 0x%04X:%s.", packet.trapWord, kTrapNames [ TrapIndex (packet.trapWord) ]);

	SysPktRPCParamInfo*	param = packet.param;

	ATrap	trap;
	for (Word ii = 0; ii < packet.numParams; ++ii)
	{
		if (param->byRef)
		{
			trap.PushLong ((uae_u32) (&param->data));
		}
		else
		{
			if (param->size == 1)
			{
				uae_u8	value = *(uae_u8*) param->data;
				Canonical (value);
				trap.PushByte (value);
			}
			else if (param->size == 2)
			{
				uae_u16	value = *(uae_u16*) param->data;
				Canonical (value);
				trap.PushWord (value);
			}
			else if (param->size == 4)
			{
				uae_u32	value = *(uae_u32*) param->data;
				Canonical (value);
				trap.PushLong (value);
			}
		}

		param = (SysPktRPCParamInfo*) (((char*) param) + offsetof (SysPktRPCParamInfo, data) +
										((param->size + 1) & ~1));
	}

	// Call the trap.  Special case the call to SysReset, as merely calling
	// that function will not return from it.

	if (packet.trapWord == sysTrapSysReset)
	{
		// Set flags that we're no longer in the debugger.  This is the same
		// as the last few steps of ExitDebugger.

		gDebuggerGlobals.excType = 0;
		LowMem_SetGlobal (dbgInDebugger, false);
		gDebuggerGlobals.inDebugger = false;

		// Reset the emulator (causes it to "reboot")

		Emulator::Reset();

		// That's it!  No reply!

		return kError_NoError;
	}

	trap.Call (packet.trapWord);

	packet.resultD0 = trap.GetD0 ();
	packet.resultA0 = trap.GetA0 ();

	SysPktRPCType&	response = packet;
	long			numBytes = ((char*) param) - ((char*) &packet);

	response.command	= sysPktRPCRsp;
	response._filler	= 0;

	return Debug::SendPacket (&response, numBytes);
}


// ---------------------------------------------------------------------------
//		� Debug::GetBreakpoints
// ---------------------------------------------------------------------------

uae_u32 Debug::GetBreakpoints (SysPktGetBreakpointsCmdType&)
{
	SysPktGetBreakpointsRspType2	response;

	response.command	= sysPktGetBreakpointsRsp;
	response._filler	= 0;

	memcpy (response.bp, gDebuggerGlobals.bp, sizeof (gDebuggerGlobals.bp));

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::SetBreakpoints
// ---------------------------------------------------------------------------

uae_u32 Debug::SetBreakpoints (SysPktSetBreakpointsCmdType2& packet)
{
	memcpy (gDebuggerGlobals.bp, packet.bp, sizeof (gDebuggerGlobals.bp));

	return Debug::SendResponse (sysPktSetBreakpointsRsp);
}


// ---------------------------------------------------------------------------
//		� Debug::ToggleBreak
// ---------------------------------------------------------------------------

uae_u32 Debug::ToggleBreak (SysPktDbgBreakToggleCmdType&)
{
	gDebuggerGlobals.ignoreDbgBreaks = !gDebuggerGlobals.ignoreDbgBreaks;

	SysPktDbgBreakToggleRspType	response;

	response.command	= sysPktDbgBreakToggleRsp;
	response._filler	= 0;

	response.newState	= gDebuggerGlobals.ignoreDbgBreaks;

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::GetTrapBreaks
// ---------------------------------------------------------------------------

uae_u32 Debug::GetTrapBreaks (SysPktGetTrapBreaksCmdType&)
{
	SysPktGetTrapBreaksRspType2	response;

	response.command	= sysPktGetTrapBreaksRsp;
	response._filler	= 0;

	memcpy (response.trapBP, gDebuggerGlobals.trapBreak,
			sizeof (gDebuggerGlobals.trapBreak));

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::SetTrapBreaks
// ---------------------------------------------------------------------------

uae_u32 Debug::SetTrapBreaks (SysPktSetTrapBreaksCmdType2& packet)
{
	memcpy (gDebuggerGlobals.trapBreak, packet.trapBP,
				sizeof (gDebuggerGlobals.trapBreak));

	gDebuggerGlobals.breakingOnATrap = false;
	for (int ii = 0; ii < dbgTotalTrapBreaks; ++ii)
	{
		if (gDebuggerGlobals.trapBreak[ii])
		{
			gDebuggerGlobals.breakingOnATrap = true;
			break;
		}
	}

	return Debug::SendResponse (sysPktSetTrapBreaksRsp);
}


// ---------------------------------------------------------------------------
//		� Debug::Find
// ---------------------------------------------------------------------------

uae_u32 Debug::Find (SysPktFindCmdType& packet)
{
	SysPktFindRspType	response;

	response.command	= sysPktFindRsp;
	response._filler	= 0;

	response.addr		= (DWord) NULL;
	response.found		= false;
	
	{
		BytePtr	dataP = (BytePtr) (&packet + 1);
		DWord	startP = packet.firstAddr;

		while (startP <= packet.lastAddr)
		{
			Word	ii;

			for (ii = 0; ii < packet.numBytes; ++ii)
			{
				Byte	b1 = get_byte(startP + ii);
				Byte	b2 = dataP[ii];

				// Handle caseless conversion

				if (packet.caseInsensitive)
				{
					if (isalpha (b1))
						b1 = tolower (b1);

					if (isalpha (b2))
						b2 = tolower (b2);
				}

				if (b1 != b2)			// if different -->
					break;
			}

			// Check if matched

			if (ii >= packet.numBytes)
			{
				response.addr = startP;
				response.found = true;
				break;
			}

			startP++;					// advance start of search pointer
		}
	}

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::GetTrapConditions
// ---------------------------------------------------------------------------

uae_u32 Debug::GetTrapConditions (SysPktGetTrapConditionsCmdType&)
{
	SysPktGetTrapConditionsRspType2	response;

	response.command	= sysPktGetTrapConditionsRsp;
	response._filler	= 0;

	memcpy (response.trapParam, gDebuggerGlobals.trapParam,
			sizeof (gDebuggerGlobals.trapParam));

	return Debug::SendPacket (&response, sizeof (response));
}


// ---------------------------------------------------------------------------
//		� Debug::SetTrapConditions
// ---------------------------------------------------------------------------

uae_u32 Debug::SetTrapConditions (SysPktSetTrapConditionsCmdType2& packet)
{
	memcpy (gDebuggerGlobals.trapParam, packet.trapParam,
			sizeof (gDebuggerGlobals.trapParam));

	return Debug::SendResponse (sysPktSetTrapConditionsRsp);
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Debug::GetRoutineName
// ---------------------------------------------------------------------------

Err Debug::GetRoutineName (uaecptr addr, char* nameP, 
			uaecptr* startAddrP, uaecptr* endAddrP)
{
	uae_u8	length;
	uaecptr	startPtr;
	uaecptr	endPtr = (uaecptr) addr;

	*startAddrP = addr;

	// Find the next RTS

	long	maxLength = 0x02000;

	do {
		// Make sure the address is valid
		if (!valid_address (endPtr, 2))
			goto ExitErr;

		uae_u16	opcode = get_word (endPtr);
		endPtr += 2;

		if (opcode == kOpcode_RTS ||
			opcode == kOpcode_RTE ||
			opcode == kOpcode_JMP ||	// JMP (A0)
			opcode == kOpcode_RTD)

			goto FoundEnd;

	} while (--maxLength);

	goto ExitErr;

FoundEnd:

	startPtr = (uaecptr) addr;
	maxLength = 0x1000;

	do {
		// Make sure the address is valid
		if (!valid_address (startPtr - 2, 2))
			goto ExitErr;

		uae_u16	opcode = get_word (startPtr);

		opcode &= 0xFFF8;	// mask off registers

		if (opcode == kOpcode_LINK)
			goto BegInA2;

		startPtr -= 2;
		opcode = get_word (startPtr);

		if (opcode == kOpcode_RTS ||
			opcode == kOpcode_RTE ||
			opcode == kOpcode_JMP ||	// JMP (A0)
			opcode == kOpcode_RTD)

			goto FoundBeg;

	} while (--maxLength);

	goto ExitErr;

FoundBeg:

	startPtr += 2;

	// Get the length of the macsbug symbol

	length = get_byte (startPtr);

	if (length < 0x80 || length > 0x9F)
		goto BegInA2;

	length &= 0x7F;

	if (length == 0)
	{
		startPtr += 1;
		length = get_byte (startPtr);
	}

	startPtr += length;		// end of label
	startPtr += 3;			// skip length byte  and DC.W 0
	if (startPtr & 1 != 0)	// if ptr is odd, bump to next word
		startPtr += 1;

BegInA2:

	// Now copy the label into our own storage.

	*startAddrP = startPtr;

	// Save end of routine in case there's no label
	
	*endAddrP = endPtr;

	length = get_byte (endPtr);
	endPtr++;

	if (length < 0x80 || length > 0x9F)
		goto ExitErr;

	length &= 0x7F;

	if (length == 0)
	{
		length = get_byte (endPtr);
		endPtr++;
	}

	if (length < 0 || length > 30)
		goto ExitErr;

	// copy the string

	do {
		*nameP++ = (char) get_byte(endPtr++);
	} while (--length);

	// Terminate the string.

	*nameP = 0;

	// Fix the end of routine to include the label

	*endAddrP = endPtr;

	return 0;

ExitErr:
	*endAddrP = endPtr;
	nameP[0] = 0;
	return -1;
}


// ---------------------------------------------------------------------------
//		� Debug::GetRegs
// ---------------------------------------------------------------------------

void Debug::GetRegs (M68KRegsType& debuggerRegs)
{
	debuggerRegs.d[0]	= m68k_dreg (regs, 0);
	debuggerRegs.d[1]	= m68k_dreg (regs, 1);
	debuggerRegs.d[2]	= m68k_dreg (regs, 2);
	debuggerRegs.d[3]	= m68k_dreg (regs, 3);
	debuggerRegs.d[4]	= m68k_dreg (regs, 4);
	debuggerRegs.d[5]	= m68k_dreg (regs, 5);
	debuggerRegs.d[6]	= m68k_dreg (regs, 6);
	debuggerRegs.d[7]	= m68k_dreg (regs, 7);

	debuggerRegs.a[0]	= m68k_areg (regs, 0);
	debuggerRegs.a[1]	= m68k_areg (regs, 1);
	debuggerRegs.a[2]	= m68k_areg (regs, 2);
	debuggerRegs.a[3]	= m68k_areg (regs, 3);
	debuggerRegs.a[4]	= m68k_areg (regs, 4);
	debuggerRegs.a[5]	= m68k_areg (regs, 5);
	debuggerRegs.a[6]	= m68k_areg (regs, 6);
//	debuggerRegs.a[7]	= m68k_areg (regs, 7);

	// Update the usp, isp, and/or msp before returning it.
	// (from m68k_dumpstate() in newcpu.c)
	
	if (regs.s == 0)
		regs.usp = m68k_areg (regs, 7);
	else
		regs.isp = m68k_areg (regs, 7);

	// Make sure the Status Register is up-to-date before moving it
	// into the debugger register set.

	Registers::UpdateSRFromRegisters ();

	// Copy the remaining registers from the UAE register set to the
	// debugger's register set.

	debuggerRegs.usp	= regs.usp;
	debuggerRegs.ssp	= regs.isp;
	debuggerRegs.sr		= regs.sr;
	debuggerRegs.pc		= m68k_getpc ();
}


// ---------------------------------------------------------------------------
//		� Debug::SetRegs
// ---------------------------------------------------------------------------

void Debug::SetRegs (const M68KRegsType& debuggerRegs)
{
	m68k_dreg (regs, 0)	= debuggerRegs.d[0];
	m68k_dreg (regs, 1)	= debuggerRegs.d[1];
	m68k_dreg (regs, 2)	= debuggerRegs.d[2];
	m68k_dreg (regs, 3)	= debuggerRegs.d[3];
	m68k_dreg (regs, 4)	= debuggerRegs.d[4];
	m68k_dreg (regs, 5)	= debuggerRegs.d[5];
	m68k_dreg (regs, 6)	= debuggerRegs.d[6];
	m68k_dreg (regs, 7)	= debuggerRegs.d[7];

	m68k_areg (regs, 0)	= debuggerRegs.a[0];
	m68k_areg (regs, 1)	= debuggerRegs.a[1];
	m68k_areg (regs, 2)	= debuggerRegs.a[2];
	m68k_areg (regs, 3)	= debuggerRegs.a[3];
	m68k_areg (regs, 4)	= debuggerRegs.a[4];
	m68k_areg (regs, 5)	= debuggerRegs.a[5];
	m68k_areg (regs, 6)	= debuggerRegs.a[6];
//	m68k_areg (regs, 7)	= debuggerRegs.a[7];

	regs.usp	= debuggerRegs.usp;
	regs.isp	= debuggerRegs.ssp;
	regs.sr		= debuggerRegs.sr;
	m68k_setpc (debuggerRegs.pc);

	// Make sure 's' bit is correct.  This will also set SPCFLAG_INT, and
	// if either the t0 or t1 bits are set, SPCFLAG_TRACE, too.

	Registers::UpdateRegistersFromSR ();

	// I think we need to do a little extra handling here of the TRACE
	// mode.  If the TRACE mode bit is set, UpdateRegistersFromSR will
	// set its SPCFLAG_TRACE flag, which tells the CPU loop to finish
	// executing the current instruction, and then set the SPCFLAG_DOTRACE
	// flag afterwards, which will then cause execution to stop after
	// the NEXT instruction.  We have a bit of an edge condition here
	// when we set the SPCFLAG_TRACE flag BETWEEN instructions.  Doing it
	// this way will cause the next instruction to be treated as the
	// "current" instruction, and so execution will stop after executing
	// the second opcode.  We want execution to stop with the first
	// opcode, so fix up the flags here.  This code is the same as in
	// Emulator::ExecuteSpecial for managing this stuff.

	if (regs.spcflags & SPCFLAG_TRACE)
	{
		regs.spcflags &= ~SPCFLAG_TRACE;
		regs.spcflags |= SPCFLAG_DOTRACE;
	}

	// Finally, update the stack pointer from the usp or ssp,
	// as appropriate.

	if (regs.s == 0)
		m68k_areg (regs, 7) = debuggerRegs.usp;
	else
		m68k_areg (regs, 7) = debuggerRegs.ssp;
}
