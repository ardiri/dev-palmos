/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "Gremlins.h"

#include "ROMStubs.h"

#include "CGremlins.h"
#include "CGremlinsStubs.h"

#include "Byteswapping.h"		// Canonical
#include "Platform.h"
#include "StringData.h"			// kTrapNames
#include "UAE_Utils.h"			// uae_memcpy

#include <stddef.h>				// offsetof

// -----------------------------
   #pragma mark *** Globals
// -----------------------------


static Gremlins			gGremlins;
static bool				gGremlinsOn;
static uae_u32			gLastTick;

static unsigned long	gGremlinStartTime;
static unsigned long	gGremlinStopTime;

static long				gGremlinNumber = 0;
static long				gGremlinSteps = -1;
static AppInfo			gGremlinAppToRun;
static bool				gGremlinLogEvents = 0;
static bool				gGremlinLogTraps = 0;
static bool				gGremlinDisplayElapsedTime = 0;

static FILE*			gEventFile;
static const long		kLogBufferSize = 128 * 1024L;	// 128K for now
static char				gLogBuffer [kLogBufferSize];
static long				gLogBufferLength;

static long				gCurrentLogFileIndex;		// Number in "Event Log #%d.txt",
													// or zero to force search for
													// free log number.


// -----------------------------
   #pragma mark -
   #pragma mark *** Public Functions
// -----------------------------


// ---------------------------------------------------------------------------
//		� Gremlins_Initialize
// ---------------------------------------------------------------------------

void Gremlins_Initialize (void)
{
}


// ---------------------------------------------------------------------------
//		� Gremlins_Initialize
// ---------------------------------------------------------------------------

void Gremlins_Reset (void)
{
	Gremlins_Stop ();
}


// ---------------------------------------------------------------------------
//		� Gremlins_IsOn
// ---------------------------------------------------------------------------

bool Gremlins_IsOn (void)
{
	return gGremlinsOn;
}


// ---------------------------------------------------------------------------
//		� Gremlins_InSingleAppMode
// ---------------------------------------------------------------------------

bool Gremlins_InSingleAppMode (void)
{
	return gGremlinAppToRun.dbID != 0;
}


// ---------------------------------------------------------------------------
//		� Gremlins_PostFakeEvent
// ---------------------------------------------------------------------------

bool Gremlins_PostFakeEvent (void)
{
	return gGremlins.GetFakeEvent() != 0;
}


// ---------------------------------------------------------------------------
//		� Gremlins_PostFakePenEvent
// ---------------------------------------------------------------------------

void Gremlins_PostFakePenEvent (void)
{
	// Only post every once and a while, so as to not overflow
	// the Palm OS's pen queue. (cf. StubEnqueuePenPosition)

	// (Note: taking out the pause.  It lead to indeterminism (the
	//  same Gremlin didn't do exactly the same thing every time),
	//  and doesn't seem necessary anyway, since we only post fake
	//  events when the event queue is empty anyway.)

//	uae_u32	now = Platform::GetMilliseconds() / 20;

//	if (now != gLastTick)
	{
		gGremlins.GetPenMovement ();

//		gLastTick = now;
	}
}


// ---------------------------------------------------------------------------
//		� OpenLogFile	[ static ]
// ---------------------------------------------------------------------------

static int OpenLogFile (int logFileNumber)
{
	if (gGremlinLogEvents || gGremlinLogTraps)
	{
		if (!gEventFile)
		{
			if (!logFileNumber)
			{
				// Look for an unused file name.

				int		index = 1;
				char	buffer[200];
				while (1)
				{
					sprintf (buffer, "Event Log #%d.txt", index);

					FILE*	f = fopen (buffer, "r");
					if (!f)
					{
						gEventFile = fopen (buffer, "w");	// Create new file for writing
						return index;
					}

					fclose (f);
					index++;
				}
			}
			else
			{
				// Use the given number

				char	buffer[200];
				sprintf (buffer, "Event Log #%d.txt", logFileNumber);
				gEventFile = fopen (buffer, "w");

				return logFileNumber;
			}
		}
	}

	return 0;
}


// ---------------------------------------------------------------------------
//		� LogMessage	[ static ]
// ---------------------------------------------------------------------------

static void LogMessage (const char* msg)
{
	// Copy the string into the log buffer a character at a time, stopping
	// when we've encountered the terminating NULL, and wrapping when we get
	// to the end of the log buffer.

	while (*msg != 0)
	{
		gLogBuffer [gLogBufferLength++ % kLogBufferSize] = *msg++;
	};
}


// ---------------------------------------------------------------------------
//		� Logging	[ static ]
// ---------------------------------------------------------------------------

static bool Logging (void)
{
	return gGremlinsOn;
}


// ---------------------------------------------------------------------------
//		� DumpLog	[ static ]
// ---------------------------------------------------------------------------

static void DumpLog (void)
{
	if (gEventFile)
	{
		// There's no log data, so no chunks to write.

		if (gLogBufferLength == 0)
		{
		}

		// Our log data only fills up part of the buffer; we never wrapped,
		// so there's only one chunk to write.

		else if (gLogBufferLength <= kLogBufferSize)
		{
			fwrite (gLogBuffer, 1, gLogBufferLength, gEventFile);
		}

		// Our log data has wrapped, but ends exactly at the end of the buffer,
		// so there's only one chunk to write.

		else if ((gLogBufferLength % kLogBufferSize) == 0)
		{
			fwrite (gLogBuffer, 1, kLogBufferSize, gEventFile);
		}

		// The log data has wrapped, and the end of our text is somewhere in
		// the middle, so there're two chunks to write.

		else
		{
			fwrite (gLogBuffer, 1, kLogBufferSize - (gLogBufferLength % kLogBufferSize), gEventFile);
			fwrite (gLogBuffer, 1, gLogBufferLength % kLogBufferSize, gEventFile);
		}
	}
}


// ---------------------------------------------------------------------------
//		� CloseLogFile	[ static ]
// ---------------------------------------------------------------------------

static void CloseLogFile (void)
{
	if (gEventFile)
	{
		fclose (gEventFile);
		gEventFile = NULL;
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_GremlinNumber
// ---------------------------------------------------------------------------

uae_u32 Gremlins_GremlinNumber (void)
{
	unsigned short	number;
	unsigned long	step;
	unsigned long	until;
	gGremlins.Status (&number, &step, &until);

	return number;
}

// ---------------------------------------------------------------------------
//		� Gremlins_EventNumber
// ---------------------------------------------------------------------------

uae_u32 Gremlins_EventNumber (void)
{
	unsigned short	number;
	unsigned long	step;
	unsigned long	until;
	gGremlins.Status (&number, &step, &until);

	return step;
}


// ---------------------------------------------------------------------------
//		� Gremlins_AppToRun
// ---------------------------------------------------------------------------

void Gremlins_AppToRun (AppInfo* app)
{
	if (app)
		gGremlinAppToRun = *app;
	else
		gGremlinAppToRun.dbID = 0;
}


// ---------------------------------------------------------------------------
//		� Gremlins_LogEvents
// ---------------------------------------------------------------------------

void Gremlins_LogEvents (bool setting)
{
	gGremlinLogEvents = setting;
}


// ---------------------------------------------------------------------------
//		� Gremlins_LogTraps
// ---------------------------------------------------------------------------

void Gremlins_LogTraps (bool setting)
{
	gGremlinLogTraps = setting;
}


// ---------------------------------------------------------------------------
//		� Gremlins_DisplayElapsed
// ---------------------------------------------------------------------------

void Gremlins_DisplayElapsed (bool setting)
{
	gGremlinDisplayElapsedTime = setting;
}


// ---------------------------------------------------------------------------
//		� Gremlins_IsEventLogging
// ---------------------------------------------------------------------------

bool Gremlins_IsEventLogging (void)
{
	return gGremlinLogEvents && Logging (); 
}


// ---------------------------------------------------------------------------
//		� Gremlins_IsTrapLogging
// ---------------------------------------------------------------------------

bool Gremlins_IsTrapLogging (void)
{
	return gGremlinLogTraps && Logging (); 
}


// ---------------------------------------------------------------------------
//		� Gremlins_New
// ---------------------------------------------------------------------------

void Gremlins_New (unsigned short newNumber, unsigned long untilStep)
{
	gCurrentLogFileIndex = 0;	// Force creation of new log file.
	gLogBufferLength = 0;		// Clear previous buffer.
	gLogBuffer[0] = 0;

	char	buffer[100];
	sprintf (buffer, "Gremlin #%d started, %ld steps.\n", (int) newNumber, untilStep);
	LogMessage (buffer);

	// Try and switch apps.

	if (Gremlins_InSingleAppMode ()) 
		SysUIAppSwitch (gGremlinAppToRun.cardNo, gGremlinAppToRun.dbID,
						sysAppLaunchCmdNormalLaunch, 0);

	gGremlins.Initialize (newNumber, untilStep);
	gGremlinsOn = true;

	gGremlinStartTime = Platform::GetMilliseconds ();

	// Make sure the app's awake.  Normally, we post events on a patch to
	// SysEvGroupWait.  However, if the Palm device is already waiting,
	// then that trap will never get called.  By calling EvtWakeup now,
	// we'll wake up the Palm device from its nap.

	EvtWakeup ();
}


// ---------------------------------------------------------------------------
//		� Gremlins_Step
// ---------------------------------------------------------------------------

void Gremlins_Step (void)
{
	if (!gGremlinsOn)
	{
		gGremlinsOn = true;
		gGremlins.Step ();

		// Make sure the app's awake.  Normally, we post events on a patch to
		// SysEvGroupWait.  However, if the Palm device is already waiting,
		// then that trap will never get called.  By calling EvtWakeup now,
		// we'll wake up the Palm device from its nap.

		EvtWakeup ();
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_Resume
// ---------------------------------------------------------------------------

void Gremlins_Resume (void)
{
	if (!gGremlinsOn)
	{
		gGremlinsOn = true;
		gGremlins.SetUntil (-1);		// in case a step action set the until value

		// Make sure the app's awake.  Normally, we post events on a patch to
		// SysEvGroupWait.  However, if the Palm device is already waiting,
		// then that trap will never get called.  By calling EvtWakeup now,
		// we'll wake up the Palm device from its nap.

		EvtWakeup ();
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_Stop
// ---------------------------------------------------------------------------

void Gremlins_Stop (void)
{
	if (gGremlinsOn)
	{
		gGremlinsOn = false;

		if (gGremlinDisplayElapsedTime)
		{
			gGremlinStopTime = Platform::GetMilliseconds ();

			unsigned short	number;
			unsigned long	step;
			unsigned long	until;
			gGremlins.Status (&number, &step, &until);

			char	buffer[100];
			sprintf (buffer, "Gremlin #%d stopped at %ld of %ld after %ld msecs.\n",
				(int) number, step, until, (gGremlinStopTime - gGremlinStartTime));

			LogMessage (buffer);

			Platform::ReportString (buffer);
		}

		gCurrentLogFileIndex = OpenLogFile (gCurrentLogFileIndex);

		DumpLog ();

		CloseLogFile ();
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_CanNew
// ---------------------------------------------------------------------------

bool Gremlins_CanNew (void)
{
	return true;
}


// ---------------------------------------------------------------------------
//		� Gremlins_CanStep
// ---------------------------------------------------------------------------

bool Gremlins_CanStep (void)
{
	return gGremlins.IsInitialized () != 0;
}


// ---------------------------------------------------------------------------
//		� Gremlins_CanResume
// ---------------------------------------------------------------------------

bool Gremlins_CanResume (void)
{
	return gGremlins.IsInitialized () && !gGremlinsOn;
}


// ---------------------------------------------------------------------------
//		� Gremlins_CanStop
// ---------------------------------------------------------------------------

bool Gremlins_CanStop (void)
{
	return gGremlinsOn;
}


// -----------------------------
   #pragma mark -
   #pragma mark *** Stub Functions
// -----------------------------



// ---------------------------------------------------------------------------
//		� StubEnqueuePt
// ---------------------------------------------------------------------------
// This is a stub routine that called the application object's method that
// enqueues a point.

void	StubAppEnqueuePt(PointPtr pen)
{
	// This is the way we used to do it, but there were intermittent
	// problems.  I think it's because EvtEnqueuePenPoint is intented
	// to be called from an interrupt routine.  If we call it here and
	// the user simultaneously mouses on the emulator window, the
	// interrupt will interrupt the procedural call here, causing the
	// two to stomp all over each other's feet and messing up the
	// machine state.  The result that I saw was that I could no longer
	// get any response to clicking on the screen.

#if 1
	PointType	pt;
	pt.x = pen->h;
	pt.y = pen->v;
	::EvtEnqueuePenPoint(&pt);
#else
	static Point	lastPen;

	if (pen->h == -1 && pen->v == -1)
	{
		Hardware_PenEvent(false, lastPen.h, lastPen.v);
	}
	else
	{
		lastPen = *pen;
		Hardware_PenEvent(true, pen->h, pen->v);
	}
#endif
}


// ---------------------------------------------------------------------------
//		� StubEnqueuePt
// ---------------------------------------------------------------------------
// This is a stub routine that called the Application object's method that
// enqueues a key.

void StubAppEnqueueKey (UInt ascii, UInt keycode, UInt modifiers)
{
	switch (ascii)
	{
		// This translates some control characters into system chars
		case 0x01:	// control-A
			ascii = menuChr;
			modifiers = commandKeyMask;
			break;
		case 0x03:	// control-C
			ascii = commandChr;
			modifiers = commandKeyMask;
			break;
		case 0x04:	// control-D
			ascii = confirmChr;
			modifiers = commandKeyMask;
			break;
		case 0x05:	// control-E
			ascii = launchChr;
			modifiers = commandKeyMask;
			break;
		case 0x06:	// control-F
			ascii = keyboardChr;
			modifiers = commandKeyMask;
			break;
		case 0x0D:	// control-D
			ascii = linefeedChr;
			break;
		case 0x0E:	// control-N
			ascii = nextFieldChr;
			modifiers = commandKeyMask;
			break;			
	}


	// If this is one of the hard keys, send it through the Key Manager so that
	//  it can do the right things concering double-taps, etc.
	if ((modifiers & commandKeyMask) &&
			(ascii > hardKeyMin || (ascii == pageUpChr) || (ascii == pageDownChr))) {

		DWord		status;

		switch (ascii) {
			case hard1Chr: 		status = keyBitHard1; break;
			case hard2Chr: 		status = keyBitHard2; break;
			case hard3Chr: 		status = keyBitHard3; break;
			case hard4Chr: 		status = keyBitHard4; break;
			case hardPowerChr: 	status = keyBitPower; break;
			case pageUpChr: 		status = keyBitPageUp; break;
			case pageDownChr: 	status = keyBitPageDown; break;
			}

		// I'm dubious that this is the correct thing to do in the emulator.
		// This is an interrupt routine that we're calling directly.  But
		// what if a "real" interrupt is triggered from some other source
		// while this call is executing (for instance, the user clicks on
		// one of the "keyboard buttons", thus generating a keyboard
		// interrupt)?  It's possible that the two will stomp on each other.
		// The best thing to do is to post events the emulator way.
		// However, I'm hard-pressed to do that.  That would require calling
		// Hardware_ButtonEvent twice (once to signal the keyboard
		// interrupt, and another to clear it), but I don't know how to give
		// the processor time in between to respond to the first call.

		::KeyHandleInterrupt(false, status);
		}

	// For other keys, enqueue them directly.
	else 
		::EvtEnqueueKey(ascii, keycode, modifiers);
}


// ---------------------------------------------------------------------------
//		� StubAppGremlinsOn
// ---------------------------------------------------------------------------
// Stub routine that update the Gremlins menu an the global variable the
// keeps track of the ????

void StubAppGremlinsOn (void)
{
	// Called from Gremlins::Initialize.
}


// ---------------------------------------------------------------------------
//		� StubAppGremlinsOff
// ---------------------------------------------------------------------------
// Stub routine that update the Gremlins menu an the global variable the
// keeps track of the ????

void StubAppGremlinsOff (void)
{
	// Called by Gremlins when counter > until.

	Gremlins_Stop ();
}


// ---------------------------------------------------------------------------
//		� StubViewDrawLine
// ---------------------------------------------------------------------------
// This is a stub routine that called the View object's method that draw
// a line.

void StubViewDrawLine (int xStart, int yStart, int xEnd, int yEnd)
{
	Platform::ViewDrawLine (xStart, yStart, xEnd, yEnd);
}


// ---------------------------------------------------------------------------
//		� StubViewDrawPixel
// ---------------------------------------------------------------------------
// This is a stub routine that called the View object's method that draw
// a pixel.

void StubViewDrawPixel (int xPos, int yPos)
{
	Platform::ViewDrawPixel (xPos, yPos);
}


// ---------------------------------------------------------------------------
//		� StubEmFrmGetTitle
// ---------------------------------------------------------------------------
// Returns a pointer to the title string of a form.  Copied from Form.c.

static CharPtr StubEmFrmGetTitle (const FormPtr frm)
{
	Word i;
	CharPtr str;

	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmTitleObj)
			{
			str = frm->objects[i].object.title->text;
			if (*str)
				return (str);
			else
				return "";
			}
		}
	return "Untitled";

}


// ---------------------------------------------------------------------------
//		� StubEmPrintFormID
// ---------------------------------------------------------------------------
// Displays the form resource id associated with the window passed.

static void StubEmPrintFormID (WinHandle winHandle, char * desc, char * eventText)
{
	WinPtr winPtr;
	WinPtr exitWinPtr;
	FormPtr frm;
	CharPtr title;
	
#if 0	// This function (and its subordinate functions) needs to be dissuaded
		// from direct memory accesses before we can use it in the emulator.
			
	if (winHandle)
		{
		exitWinPtr = WinGetWindowPointer (winHandle);
		
		// Check if the handle is still valid.  If the form has been deleted 
		// then we can't dereference the window pointer.
		
		// Search the window list for the pointer.
		winHandle = WinGetFirstWindow ();
		while (winHandle)
			{
			winPtr = WinGetWindowPointer (winHandle);
			if (winPtr == exitWinPtr)
				break;
			
			winHandle = winPtr->nextWindow;		
			}
		
		
		if (winHandle && winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			title = StubEmFrmGetTitle(frm);
			if (*title != nullChr)
				sprintf (&eventText[strlen(eventText)],"%s: \"%s\"", desc, title);
			else
				sprintf (&eventText[strlen(eventText)],"%s ID: %d %s", desc, frm->formId);
			}
		}
#endif
}


// ---------------------------------------------------------------------------
//		� VirtualKeyDescriptions
// ---------------------------------------------------------------------------
// Return a key description

char* VirtualKeyDescriptions[] = {
	" (lowBatteryChr)", 
	" (enterDebuggerChr)", 
	" (nextFieldChr)", 
	" (startConsoleChr)", 
	" (menuChr)", 
	" (commandChr)", 
	" (confirmChr)", 
	" (launchChr)", 
	" (keyboardChr)", 
	" (findChr)", 
	" (calcChr)", 
	" (prevFieldChr)", 
	" (alarmChr)", 
	" (ronamaticChr)", 
	" (graffitiReferenceChr)", 
	" (keyboardAlphaChr)", 
	" (keyboardNumericChr)", 
	" (lockChr)", 
	" (backlightChr)", 
	" (autoOffChr)", 
	" (irScanningChr)", 
	" (sendDataChr)"
};

char *HardKeyDescriptions[] = {
	" (hard1Chr)", 
	" (hard2Chr)", 
	" (hard3Chr)", 
	" (hard4Chr)", 
	" (hardPowerChr)", 
	" (hardCradleChr)", 
	" (hardCradle2Chr)"
};

static char * StubEmKeyDescription (Int key)
{
	if (key < lowBatteryChr)
		return "";
	if (key >= lowBatteryChr && key <= sendDataChr)
		return VirtualKeyDescriptions[key - lowBatteryChr];
	else if (key >= hard1Chr && key <= hardCradle2Chr)
		return HardKeyDescriptions[key - hard1Chr];
	
	return "";
}


// ---------------------------------------------------------------------------
//		� StubEmEventTrace
// ---------------------------------------------------------------------------
// Displays the passed event in the emulator's event tracewindow if it is
// active.

static bool StubEmEventTrace(void* eventP, char* eventText)
{
	EventPtr event = (EventPtr) eventP;

	if(event->eType != nilEvent)
	{
	
		switch(event->eType)
		{
			case nilEvent:
					break;
			
			case penDownEvent:
					sprintf(eventText,"penDownEvent    X:%u   Y:%u", 
							event->screenX, event->screenY);
					break;
			
			case penUpEvent:
					strcpy(eventText,"penUpEvent");
					sprintf(eventText,"penUpEvent      X:%u   Y:%u", 
							event->screenX, event->screenY);
					break;
			
			case penMoveEvent:
					strcpy(eventText,"penMoveEvent");
					sprintf(eventText,"penMoveEvent    X:%u   Y:%u", 
							event->screenX, event->screenY);					
					break;
				
			case keyDownEvent:
					sprintf(eventText,"keyDownEvent    Key:'%c' 0x%02x%s,  Modifiers: 0x%04X", 
							event->data.keyDown.chr, event->data.keyDown.chr,  
							StubEmKeyDescription(event->data.keyDown.chr),
							event->data.keyDown.modifiers);
					break;
				
			case winEnterEvent:
					sprintf(eventText,"winEnterEvent   Enter: %lu   Exit: %lu", 
							event->data.winEnter.enterWindow, event->data.winEnter.exitWindow);		
					StubEmPrintFormID (event->data.winEnter.enterWindow, "  Enter Form", eventText);
					StubEmPrintFormID (event->data.winEnter.exitWindow, "  Exit Form", eventText);
					break;
			
			case winExitEvent:
					sprintf(eventText,"winExitEvent    Enter: %lu   Exit: %lu", 
							event->data.winExit.enterWindow, event->data.winExit.exitWindow);
					StubEmPrintFormID (event->data.winExit.enterWindow, "  Enter Form", eventText);
					StubEmPrintFormID (event->data.winExit.exitWindow, "  Exit Form", eventText);
					break;
			
			case ctlEnterEvent:
					sprintf(eventText,"ctlEnterEvent   ID: %u", 
							event->data.ctlEnter.controlID);
					break;
			
			case ctlSelectEvent:
					sprintf(eventText,"ctlSelectEvent  ID: %u   On: %u", 
							event->data.ctlSelect.controlID, event->data.ctlSelect.on);					
					break;
	
			case ctlRepeatEvent:
					sprintf(eventText,"ctlRepeatEvent  ID: %u   Time: %lu", 
							event->data.ctlRepeat.controlID, event->data.ctlRepeat.time);					
					break;
			
			case ctlExitEvent:
					sprintf(eventText,"ctlExitEvent");
					break;
					
			case lstEnterEvent:
					sprintf(eventText,"lstEnterEvent   ID: %u   Item: %u", 
							event->data.lstEnter.listID, event->data.lstEnter.selection);			
					break;
			
			case lstSelectEvent:
					sprintf(eventText,"lstSelectEvent  ID: %u   Item: %u", 
							event->data.lstSelect.listID, event->data.lstSelect.selection);
					break;
			
			case lstExitEvent:
					sprintf(eventText,"lstExitEvent    ID: %u", 
							event->data.lstExit.listID);
					break;
			
			case popSelectEvent:
					sprintf(eventText,"popSelectEvent  CtlID: %u  ListID: %u  Item: %u", 
							event->data.popSelect.controlID, event->data.popSelect.listID,
							event->data.popSelect.selection);
					break;
			
			case fldEnterEvent:
					sprintf(eventText,"fldEnterEvent   ID: %u", 
							event->data.fldEnter.fieldID);
					break;
			
			case fldHeightChangedEvent:
					sprintf(eventText,"fldHeightChangedEvent  ID: %u  Height: %u  Pos: %u", 
							event->data.fldHeightChanged.fieldID, 
							event->data.fldHeightChanged.newHeight,
							event->data.fldHeightChanged.currentPos);
					break;
			
			case fldChangedEvent:
					sprintf(eventText,"fldChanged  ID: %u", 
							event->data.fldChanged.fieldID);
					break;
			
			case tblEnterEvent:
					sprintf(eventText,"tblEnterEvent   ID: %u   Row: %u  Col: %u",
							event->data.tblEnter.tableID,
							event->data.tblEnter.row,
							event->data.tblEnter.column);
					break;
			
			case tblSelectEvent:
					sprintf(eventText,"tblSelectEvent  ID: %u   Row: %u  Col: %u", 
							event->data.tblSelect.tableID, 
							event->data.tblSelect.row, 
							event->data.tblSelect.column);					
					break;
			
			case daySelectEvent:
					strcpy(eventText,"daySelectEvent");
					break;
			
			case menuEvent:
					sprintf(eventText,"menuEvent       ItemID: %u", 
							event->data.menu.itemID);
					break;

			case appStopEvent:
					strcpy(eventText,"appStopEvent");
					break;
			
			case frmLoadEvent:
					sprintf(eventText,"frmLoadEvent    ID: %u", 
							event->data.frmOpen.formID);
					break;
				
			case frmOpenEvent:
					sprintf(eventText,"frmOpenEvent    ID: %u", 
							event->data.frmOpen.formID);
					break;
				
			case frmGotoEvent:
					sprintf(eventText,"frmGotoEvent    ID: %u", 
							event->data.frmGoto.formID);
					break;
				
			case frmUpdateEvent:
					sprintf(eventText,"frmUpdateEvent    ID: %u", 
							event->data.frmUpdate.formID);
					break;
			
			case frmSaveEvent:
					sprintf(eventText,"frmSaveEvent    ID: ??", 
							event->data.frmClose.formID);
					break;
			
			case frmCloseEvent:
					sprintf(eventText,"frmCloseEvent   ID: %u", 
							event->data.frmClose.formID);
					break;
			
			case frmTitleEnterEvent:
					sprintf(eventText,"frmTitleEnterEvent   ID: %u", 
							event->data.frmTitleEnter.formID);
					
					break;
			
			case frmTitleSelectEvent:
					sprintf(eventText,"frmTitleSelectEvent   ID: %u", 
							event->data.frmTitleSelect.formID);
					break;
			
			case sclEnterEvent:
					sprintf(eventText,"sclEnterEvent   ID: %u", 
							event->data.sclEnter.scrollBarID);
					break;

			case sclRepeatEvent:
					sprintf(eventText,"sclRepeatEvent   ID: %u  Value: %u,  New value: %u", 
							event->data.sclRepeat.scrollBarID,
							event->data.sclRepeat.value,
							event->data.sclRepeat.newValue);
					break;

			case sclExitEvent:
					sprintf(eventText,"sclExitEvent   ID: %u", 
							event->data.sclExit.scrollBarID);
					break;

			case firstUserEvent:
					strcpy(eventText,"firstUserEvent");
					break;
			
			default:
					sprintf(eventText,"Unknown Event!   Event->eType #: %u",
							event->eType);
					break;
		}	// end switch

		strcat(eventText, "\n");
		return true;
	}
	else
		return false;
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordEvtEnqueuePenPoint
// ---------------------------------------------------------------------------

void Gremlins_RecordEvtEnqueuePenPoint (PointType* pen)
{
	if (Gremlins_IsEventLogging ())
	{
		char	buffer[200];
		sprintf (buffer,
				">>> EvtEnqueuePenPoint: pen->x=%d, pen->y=%d.\n",
				(int) pen->x, (int) pen->y);
		LogMessage (buffer);
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordKeyHandleInterrupt
// ---------------------------------------------------------------------------

void Gremlins_RecordKeyHandleInterrupt (Boolean periodic, DWord status)
{
	if (Gremlins_IsEventLogging ())
	{
		char	buffer[200];
		sprintf (buffer,
				">>> KeyHandleInterrupt: periodic=%d, status=0x%08lX.\n",
				(int) periodic, status);
		LogMessage (buffer);
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordEvtEnqueueKey
// ---------------------------------------------------------------------------

void Gremlins_RecordEvtEnqueueKey (UInt ascii, UInt keycode, UInt modifiers)
{
	if (Gremlins_IsEventLogging ())
	{
		char	buffer[200];
		sprintf (buffer,
				">>> EvtEnqueueKey: ascii = 0x%04X, keycode = 0x%04X, modifiers = 0x%04X.\n",
				ascii, keycode, modifiers);
		LogMessage (buffer);
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordEvtGetEvent
// ---------------------------------------------------------------------------

void Gremlins_RecordEvtGetEvent (uaecptr eventP)
{
	if (Gremlins_IsEventLogging ())
	{
		unsigned short	currentNumber;
		unsigned long	currentStep;
		unsigned long	currentUntil;	
		gGremlins.Status (&currentNumber, &currentStep, &currentUntil);

		char	eventText[255];
		sprintf (eventText, "<<< %lu: ", currentStep - 1);

		// Get a copy of the event record.  This will be in big-endian
		// format, so byteswap it if necessary..

		EventType	newEvent;
		uae_memcpy ((char*) &newEvent, eventP, sizeof (newEvent));
		Canonical (newEvent);

		// Get the text for this event.  If there is such text, log it.

		if (StubEmEventTrace (&newEvent, &eventText[strlen(eventText)]))
		{
			LogMessage (eventText);
		}
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordEvtGetPen
// ---------------------------------------------------------------------------

void Gremlins_RecordEvtGetPen (uaecptr pScreenX, uaecptr pScreenY, uaecptr pPenDown)
{
	if (Gremlins_IsEventLogging ())
	{
		unsigned short	currentNumber;
		unsigned long	currentStep;
		unsigned long	currentUntil;	
		gGremlins.Status(&currentNumber, &currentStep, &currentUntil);

		// SWord *pScreenX, SWord *pScreenY, Boolean *pPenDown

		SWord	screenX = (SWord) get_word (pScreenX);
		SWord	screenY = (SWord) get_word (pScreenY);
		Boolean	penDown = (Boolean) get_byte (pPenDown);

		char	buffer[200];
		sprintf (buffer,
				"<<< %lu: EvtGetPen: screenX=%d, screenY=%d, penDown=%d.\n",
				currentStep - 1, (int) screenX, (int) screenY, (int) penDown);

		LogMessage (buffer);
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_RecordTrapCall
// ---------------------------------------------------------------------------

void Gremlins_RecordTrapCall (uae_u16 trapWord)
{
	if (Gremlins_IsTrapLogging ())
	{
		char	buffer[200];

		if (trapWord < sysTrapLastTrapNumber)
		{
			sprintf (buffer,
					"--- System Call 0x%04X: %s.\n",
					(long) trapWord, kTrapNames[ TrapIndex (trapWord) ]);
		}
		else
		{
			sprintf (buffer,
					"--- System Call 0x%04X: %s.\n",
					(long) trapWord, ">>> Unknown trap number <<<");
		}
		LogMessage (buffer);
	}
}


// ---------------------------------------------------------------------------
//		� Gremlins_GetApplicationNames
// ---------------------------------------------------------------------------

#define sysFileCLauncher	'lnch'
#define	sysFileTApplication	'appl'	// File type for applications

static int AppCompareDataBaseCreators (const void *a, const void *b)
{
	return ((const AppInfo*) b)->creator - ((const AppInfo*) a)->creator;
}


static int AppCompareDataBaseNames (const void *a, const void *b)
{
	return strcmp (((const AppInfo*) a)->name, ((const AppInfo*) b)->name);
}


void Gremlins_GetApplicationNames (AppInfo** appList, long* numApps)
{
	AppInfo*	appInfoList		= (AppInfo*) malloc(100 * sizeof(AppInfo));
	long		numAppsFound	= 0;
	Boolean		newSearch		= true;

	while (numAppsFound < 100)
	{
		AppInfo	appInfo;

		// Seach for the next DB
		DmSearchStateType	searchState;
		ULong				type			= sysFileTApplication;
		ULong				creator			= 0;
		Boolean				onlyLatestVers	= false;

		Err	err = DmGetNextDatabaseByTypeCreator (
						newSearch,
						&searchState, 
						type,
						creator,
						onlyLatestVers,
						&appInfo.cardNo,
						&appInfo.dbID);
		if (err)
			break;

		newSearch = false;

		DmDatabaseInfo (appInfo.cardNo,
						appInfo.dbID,
						appInfo.name,
						NULL,					// attributes
						&appInfo.version, 
						NULL,					// creation date
						&appInfo.modDate,
						NULL,					// backup date
						NULL,					// modification number
						NULL,					// application info ID
						NULL,					// sort info ID
						&appInfo.type,
						&appInfo.creator);

		// If this DB has the same creator as the Launcher, ignore it

		if (appInfo.creator == sysFileCLauncher)
			continue;

		// If this DB has a 'tAIN' resource, use it for the name.

		DmOpenRef	dbP = DmOpenDatabase (appInfo.cardNo, appInfo.dbID, dmModeReadOnly);

		if (dbP)
		{
			VoidHand	strH = DmGet1Resource ('tAIN', 1000);
			if (strH)
			{
				uaecptr	strP = (uaecptr) MemHandleLock (strH);
				uae_strcpy (appInfo.name, strP);
				MemHandleUnlock (strH);
				DmReleaseResource (strH);
			}

			DmCloseDatabase (dbP);
		}

		// Record data and advance index

		appInfoList[numAppsFound] = appInfo;
		numAppsFound++;
	}

	// Only do the rest if at least 2 entries were found

	if (numAppsFound >= 2)
	{
		// Sort the matches by creator.  This places different versions of apps 
		// next to each other while also ordering the list of apps.  We will
		// need to sort again using the name of the apps should be in a roughly
		// similiar order, especially if the first letter of the creator is the
		// same as the first letter of the app's name. Cost is �(n log n)

		qsort (appInfoList, numAppsFound, sizeof(AppInfo), AppCompareDataBaseCreators);

		// Now look through the apps looking for multiple versions of an app,
		// discarding any earlier versions.  Ideally there will be at most
		// two versions of an app (one in ROM and one in RAM).  We work
		// backwards so that the MemMove moves only bytes already checked.
		// �(n)  (assuming few multiple versions).

		AppInfo*	appInfo = &appInfoList[numAppsFound - 2];
		while (appInfo >= appInfoList)
		{
			// If this app is the same creator as the next one

			if (appInfo->creator == (appInfo + 1)->creator)
			{
				// Remove the older version

				if (appInfo->version >= (appInfo + 1)->version)
					memmove (appInfo + 1, appInfo + 2, (BytePtr) &appInfoList[numAppsFound] - (BytePtr) (appInfo + 2));
				else
					memmove (appInfo, appInfo + 1, (BytePtr) &appInfoList[numAppsFound] - (BytePtr) (appInfo + 1));

				numAppsFound--;		// There is one less database now.
			}

			appInfo--;
		}

		// If the names were requested then sort by the names found.
		// Cost is �(n) (assuming the records are mostly ordered already
		// because the creator and name have the same first letter)

		qsort (appInfoList, numAppsFound, sizeof(AppInfo), AppCompareDataBaseNames);
	}

	*appList = appInfoList;
	*numApps = numAppsFound;
}
