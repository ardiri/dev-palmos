/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "ROMStubs.h"

#include "Byteswapping.h"

#include "Gremlins.h"


// ---------------------------------------------------------------------------
//		� Canonical_If_Not_Null
// ---------------------------------------------------------------------------
// Pointer parameters often need a little extra handling. If they are not
// NULL, they generally point to either stack or heap buffers.  If they're on
// the stack, then on Windows they're in little-endian format and need to be
// converted into big-endian format.  Fortunately, we don't have to worry
// about the goofy word-swapping done for ROM and RAM memory, as the memory
// accessors that deal with data on the stack doesn't do any of that.
//
// For now, we don't actually check to see if data is on the stack or not.
// We just use this functions on pointers that we _expect_ point to
// stack-resident data.  So far we haven't run into any problems with that
// approach.

template <class T>
inline void Canonical_If_Not_Null (T* p)
{
	if (p)
		Canonical (*p);
}


// ---------------------------------------------------------------------------
//		� Data Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

Err DmCloseDatabase (DmOpenRef dbR)
{
	CallROM1 (sysTrapDmCloseDatabase, dbR);

	return (Err) theTrap.GetD0 ();
}

Err DmCreateDatabase (UInt cardNo, const Char * const nameP, 
					ULong creator, ULong type, Boolean resDB)
{
	CallROM5 (sysTrapDmCreateDatabase, cardNo, nameP, creator, type, resDB);

	return (Err) theTrap.GetD0 ();
}

Err		DmDatabaseInfo (UInt cardNo, LocalID	dbID, const CharPtr nameP,
					UIntPtr attributesP, UIntPtr versionP, ULongPtr crDateP,
					ULongPtr modDateP, ULongPtr bckUpDateP,
					ULongPtr modNumP, LocalID* appInfoIDP,
					LocalID* sortInfoIDP, ULongPtr typeP,
					ULongPtr creatorP)
{
	Canonical_If_Not_Null (attributesP);
	Canonical_If_Not_Null (versionP);
	Canonical_If_Not_Null (crDateP);
	Canonical_If_Not_Null (modDateP);
	Canonical_If_Not_Null (bckUpDateP);
	Canonical_If_Not_Null (modNumP);
	Canonical_If_Not_Null (appInfoIDP);
	Canonical_If_Not_Null (sortInfoIDP);
	Canonical_If_Not_Null (typeP);
	Canonical_If_Not_Null (creatorP);

	CallROM13 (sysTrapDmDatabaseInfo, cardNo, dbID, nameP, attributesP,
				versionP, crDateP, modDateP, bckUpDateP, modNumP, appInfoIDP,
				sortInfoIDP, typeP, creatorP);

	Canonical_If_Not_Null (attributesP);
	Canonical_If_Not_Null (versionP);
	Canonical_If_Not_Null (crDateP);
	Canonical_If_Not_Null (modDateP);
	Canonical_If_Not_Null (bckUpDateP);
	Canonical_If_Not_Null (modNumP);
	Canonical_If_Not_Null (appInfoIDP);
	Canonical_If_Not_Null (sortInfoIDP);
	Canonical_If_Not_Null (typeP);
	Canonical_If_Not_Null (creatorP);

	return (Err) theTrap.GetD0 ();
}

Err DmDeleteDatabase (UInt cardNo, LocalID dbID)
{
	CallROM2 (sysTrapDmDeleteDatabase, cardNo, dbID);

	return (Err) theTrap.GetD0 ();
}

LocalID DmFindDatabase (UInt cardNo, const CharPtr nameP)
{
	CallROM2 (sysTrapDmFindDatabase, cardNo, nameP);

	return (LocalID) theTrap.GetD0 ();
}

VoidHand DmGet1Resource (ULong type, Int id)
{
	CallROM2 (sysTrapDmGet1Resource, type, id);

	return (VoidHand) theTrap.GetA0 ();
}

Err	DmGetNextDatabaseByTypeCreator (Boolean newSearch, DmSearchStatePtr stateInfoP,
			 		ULong type, ULong creator, Boolean onlyLatestVers, 
			 		UIntPtr cardNoP, LocalID* dbIDP)
{
	Canonical_If_Not_Null (cardNoP);
	Canonical_If_Not_Null (dbIDP);

	CallROM7 (sysTrapDmGetNextDatabaseByTypeCreator, newSearch, stateInfoP,
				type, creator, onlyLatestVers, cardNoP, dbIDP);

	Canonical_If_Not_Null (cardNoP);
	Canonical_If_Not_Null (dbIDP);

	return (Err) theTrap.GetD0 ();
}

VoidHand DmGetResource (ULong type, Int id)
{
	CallROM2 (sysTrapDmGetResource, type, id);

	return (VoidHand) theTrap.GetA0 ();
}

VoidHand DmNewHandle (DmOpenRef dbR, ULong size)
{
	CallROM2 (sysTrapDmNewHandle, dbR, size);

	return (VoidHand) theTrap.GetA0 ();
}

VoidHand DmNewRecord (DmOpenRef dbR, UIntPtr atP, ULong size)
{
	Canonical_If_Not_Null (atP);

	CallROM3 (sysTrapDmNewRecord, dbR, atP, size);

	Canonical_If_Not_Null (atP);

	return (VoidHand) theTrap.GetA0 ();
}

VoidHand	DmNewResource (DmOpenRef dbR, ULong resType, Int resID, ULong size)
{
	CallROM4 (sysTrapDmNewResource, dbR, resType, resID, size);

	return (VoidHand) theTrap.GetA0 ();
}

DmOpenRef DmOpenDatabase (UInt cardNo, LocalID dbID, UInt mode)
{
	CallROM3 (sysTrapDmOpenDatabase, cardNo, dbID, mode);

	return (DmOpenRef) theTrap.GetA0 ();
}

Err DmReleaseRecord (DmOpenRef dbR, UInt index, Boolean dirty)
{
	CallROM3 (sysTrapDmReleaseRecord, dbR, index, dirty);

	return (Err) theTrap.GetD0 ();
}

Err DmReleaseResource (VoidHand resourceH)
{
	CallROM1 (sysTrapDmReleaseResource, resourceH);

	return (Err) theTrap.GetD0 ();
}

Err DmSetDatabaseInfo (UInt cardNo, LocalID dbID, const CharPtr nameP,
					UIntPtr attributesP, UIntPtr versionP, ULongPtr crDateP,
					ULongPtr modDateP, ULongPtr bckUpDateP,
					ULongPtr modNumP, LocalID* appInfoIDP,
					LocalID* sortInfoIDP, ULongPtr typeP,
					ULongPtr creatorP)
{
	Canonical_If_Not_Null (attributesP);
	Canonical_If_Not_Null (versionP);
	Canonical_If_Not_Null (crDateP);
	Canonical_If_Not_Null (modDateP);
	Canonical_If_Not_Null (bckUpDateP);
	Canonical_If_Not_Null (modNumP);
	Canonical_If_Not_Null (appInfoIDP);
	Canonical_If_Not_Null (sortInfoIDP);
	Canonical_If_Not_Null (typeP);
	Canonical_If_Not_Null (creatorP);

	CallROM13 (sysTrapDmSetDatabaseInfo, cardNo, dbID, nameP, attributesP, versionP,
		crDateP, modDateP, bckUpDateP, modNumP, appInfoIDP, sortInfoIDP, typeP, creatorP);

	Canonical_If_Not_Null (attributesP);
	Canonical_If_Not_Null (versionP);
	Canonical_If_Not_Null (crDateP);
	Canonical_If_Not_Null (modDateP);
	Canonical_If_Not_Null (bckUpDateP);
	Canonical_If_Not_Null (modNumP);
	Canonical_If_Not_Null (appInfoIDP);
	Canonical_If_Not_Null (sortInfoIDP);
	Canonical_If_Not_Null (typeP);
	Canonical_If_Not_Null (creatorP);

	return (Err) theTrap.GetD0 ();
}

Err DmSetRecordInfo (DmOpenRef dbR, UInt index, UIntPtr attrP, ULongPtr uniqueIDP)
{
	Canonical_If_Not_Null (attrP);
	Canonical_If_Not_Null (uniqueIDP);

	CallROM4 (sysTrapDmSetRecordInfo, dbR, index, attrP, uniqueIDP);

	Canonical_If_Not_Null (attrP);
	Canonical_If_Not_Null (uniqueIDP);

	return (Err) theTrap.GetD0 ();
}

Err DmWrite (VoidPtr recordP, ULong offset, const void * const srcP, ULong bytes)
{
	CallROM4 (sysTrapDmWrite, recordP, offset, srcP, bytes);

	return (Err) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Error Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

void ErrDisplayFileLineMsg (const Char * const filename, UInt lineNo, 
			const Char * const msg)
{
	// !!! We'll probably want to map in the filename space, here...

	CallROM3 (sysTrapErrDisplayFileLineMsg, filename, lineNo, msg);
}

// ---------------------------------------------------------------------------
//		� Event Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

Err EvtEnqueueKey (UInt ascii, UInt keycode, UInt modifiers)
{
	Gremlins_RecordEvtEnqueueKey (ascii, keycode, modifiers);

	CallROM3 (sysTrapEvtEnqueueKey, ascii, keycode, modifiers);

	return (Err) theTrap.GetD0 ();
}

Err EvtEnqueuePenPoint (PointType* ptP)
{
	Gremlins_RecordEvtEnqueuePenPoint (ptP);

	// Enqueue the new pen position. We must "reverse" correct it because the
	// Event Manager assumes that all points enqueued are raw digitizer points.

	if (ptP->x != -1 || ptP->y != -1)
	{
		(void) PenScreenToRaw(ptP);
	}

	Canonical_If_Not_Null (ptP);

	CallROM1 (sysTrapEvtEnqueuePenPoint, ptP);

	Canonical_If_Not_Null (ptP);

	return (Err) theTrap.GetD0 ();
}

Err EvtResetAutoOffTimer (void)
{
	CallROM0 (sysTrapEvtResetAutoOffTimer);

	return (Err) theTrap.GetD0 ();
}

Err EvtWakeup (void)
{
	CallROM0 (sysTrapEvtWakeup);

	return (Err) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Field Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

void FldGetAttributes (const FieldPtr fld, const FieldAttrPtr attrP)
{
	Canonical_If_Not_Null (attrP);

	CallROM2 (sysTrapFldGetAttributes, fld, attrP);

	Canonical_If_Not_Null (attrP);
}

Word FldGetMaxChars (const FieldPtr fld)
{
	CallROM1 (sysTrapFldGetMaxChars, fld);

	return (Word) theTrap.GetD0 ();
}

Word FldGetTextLength (const FieldPtr fld)
{
	CallROM1 (sysTrapFldGetTextLength, fld);

	return (Word) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Font Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

SWord FntLineHeight (void)
{
	CallROM0 (sysTrapFntLineHeight);

	return (SWord) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Form Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

FormPtr FrmGetActiveForm (void)
{
	CallROM0 (sysTrapFrmGetActiveForm);

	return (FormPtr) theTrap.GetA0 ();
}

Word FrmGetFocus (const FormPtr frm)
{
	CallROM1 (sysTrapFrmGetFocus, frm);

	return (Word) theTrap.GetD0 ();
}

Word FrmGetNumberOfObjects (const FormPtr frm)
{
	CallROM1 (sysTrapFrmGetNumberOfObjects, frm);

	return (Word) theTrap.GetD0 ();
}

void FrmGetObjectBounds (const FormPtr frm, const Word pObjIndex, const RectanglePtr r)
{
	Canonical_If_Not_Null (r);

	CallROM3 (sysTrapFrmGetObjectBounds, frm, pObjIndex, r);

	Canonical_If_Not_Null (r);
}

VoidPtr FrmGetObjectPtr (const FormPtr frm, const Word objIndex)
{
	CallROM2 (sysTrapFrmGetObjectPtr, frm, objIndex);

	return (VoidPtr) theTrap.GetA0 ();
}

FormObjectKind FrmGetObjectType (const FormPtr frm, const Word objIndex)
{
	CallROM2 (sysTrapFrmGetObjectType, frm, objIndex);

	return (FormObjectKind) theTrap.GetD0 ();
}

WinHandle FrmGetWindowHandle (const FormPtr frm)
{
	CallROM1 (sysTrapFrmGetWindowHandle, frm);

	return (WinHandle) theTrap.GetA0 ();
}

// ---------------------------------------------------------------------------
//		� Hardware Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

void HwrDisableDataWrites (void)
{
	CallROM0 (sysTrapHwrDisableDataWrites);
}

Boolean HwrEnableDataWrites (void)
{
	CallROM0 (sysTrapHwrEnableDataWrites);

	return (Boolean) theTrap.GetD0 ();
}

DWord HwrMemReadable (VoidPtr addr)
{
	CallROM1 (sysTrapHwrMemReadable, addr);

	return (DWord) theTrap.GetD0 ();
}

DWord HwrMemWritable (VoidPtr addr)
{
	CallROM1 (sysTrapHwrMemWritable, addr);

	return (DWord) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Keyboard Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

ULong KeyHandleInterrupt (Boolean periodic, DWord status)
{
	Gremlins_RecordKeyHandleInterrupt (periodic, status);

	CallROM2 (sysTrapKeyHandleInterrupt, periodic, status);

	return (ULong) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Memory Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

VoidPtr MemHandleLock (VoidHand h)
{
	CallROM1 (sysTrapMemHandleLock, h);

	return (VoidPtr) theTrap.GetA0 ();
}

LocalID MemHandleToLocalID (VoidHand h)
{
	CallROM1 (sysTrapMemHandleToLocalID, h);

	return (LocalID) theTrap.GetD0 ();
}

Err MemHandleUnlock (VoidHand h)
{
	CallROM1 (sysTrapMemHandleUnlock, h);

	return (Err) theTrap.GetD0 ();
}

Err MemNVParams (Boolean set, SysNVParamsPtr paramsP)
{
	Canonical_If_Not_Null (paramsP);

	CallROM2 (sysTrapMemNVParams, set, paramsP);

	Canonical_If_Not_Null (paramsP);

	return (Err) theTrap.GetD0 ();
}

Err MemSemaphoreRelease (Boolean writeAccess)
{
	CallROM1 (sysTrapMemSemaphoreRelease, writeAccess);

	return (Err) theTrap.GetD0 ();
}

Err MemSemaphoreReserve (Boolean writeAccess)
{
	CallROM1 (sysTrapMemSemaphoreReserve, writeAccess);

	return (Err) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Pen Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

Err PenScreenToRaw (PointType* penP)
{
	Canonical_If_Not_Null (penP);

	CallROM1 (sysTrapPenScreenToRaw, penP);

	Canonical_If_Not_Null (penP);

	return (Err) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Peferences Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

DmOpenRef PrefOpenPreferenceDBV10 (void)
{
	CallROM0 (sysTrapPrefOpenPreferenceDBV10);

	return (DmOpenRef) theTrap.GetA0 ();
}

DmOpenRef PrefOpenPreferenceDB (Boolean saved)
{
	CallROM1 (sysTrapPrefOpenPreferenceDB, saved);

	return (DmOpenRef) theTrap.GetA0 ();
}

void PrefSetPreference (SystemPreferencesChoice choice, DWord value)
{
	// Coerce "choice" to a 1-byte value to match the way the 68K
	// code-generator determines an enum's size.

	CallROM2 (sysTrapPrefSetPreference, (uae_u8) choice, value);
}

// ---------------------------------------------------------------------------
//		� System Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

Err	SysCurAppDatabase (UIntPtr cardNoP, LocalID* dbIDP)
{
	Canonical_If_Not_Null (cardNoP);
	Canonical_If_Not_Null (dbIDP);

	CallROM2 (sysTrapSysCurAppDatabase, cardNoP, dbIDP);

	Canonical_If_Not_Null (cardNoP);
	Canonical_If_Not_Null (dbIDP);

	return (Err) theTrap.GetD0 ();
}

UInt SysSetAutoOffTime (UInt seconds)
{
	CallROM1 (sysTrapSysSetAutoOffTime, seconds);

	return (UInt) theTrap.GetD0 ();
}

Err SysUIAppSwitch (UInt cardNo, LocalID dbID, Word cmd, Ptr cmdPBP)
{	
	CallROM4 (sysTrapSysUIAppSwitch, cardNo, dbID, cmd, cmdPBP);

	return (Err) theTrap.GetD0 ();
}

// ---------------------------------------------------------------------------
//		� Table Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

FieldPtr TblGetCurrentField (const TablePtr table)
{
	CallROM1 (sysTrapTblGetCurrentField, table);

	return (FieldPtr) theTrap.GetA0 ();
}

// ---------------------------------------------------------------------------
//		� Window Manager functions
// ---------------------------------------------------------------------------

#pragma mark -

WinHandle WinGetActiveWindow (void)
{
	CallROM0 (sysTrapWinGetActiveWindow);

	return (WinHandle) theTrap.GetA0 ();
}

WinHandle WinGetFirstWindow (void)
{
	CallROM0 (sysTrapWinGetFirstWindow);

	return (WinHandle) theTrap.GetA0 ();
}

void WinGetWindowBounds (RectanglePtr r)
{
	Canonical_If_Not_Null (r);

	CallROM1 (sysTrapWinGetWindowBounds, r);

	Canonical_If_Not_Null (r);
}

void WinWindowToDisplayPt (SWordPtr extentX, SWordPtr extentY)
{
	Canonical_If_Not_Null (extentX);
	Canonical_If_Not_Null (extentY);

	CallROM2 (sysTrapWinWindowToDisplayPt, extentX, extentY);

	Canonical_If_Not_Null (extentX);
	Canonical_If_Not_Null (extentY);
}
