/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#ifndef CPU_REG_H	// The pragma once doesn't see to take effect in VC++
#define CPU_REG_H	// for this file, so back it up with conditionals.

#pragma once

#include "Switches.h"
#include "UAE.h"
#include "DragonBall.h"
#include "Palm.h"

#include "Platform.h"	// TByteQueue
#include "RAM_ROM.h"

#include <stddef.h>		// offsetof

// Types

#pragma mark Types

typedef bool (*ExceptionHandlerProc)(uae_s32 exceptionNumber);


// Globals.

#pragma mark Globals

extern bool				gBreakOnException[];

extern bool				gPen_IsDown;
extern uae_s32			gPen_HorzLocation;
extern uae_s32			gPen_VertLocation;

extern AbsRectType		gScreen_UpdateRect;


// Constants.

#pragma mark Constants

enum
{
	kButton_None		= -1,
	kButton_Power		= 0,
	kButton_UpArrow		= 1,
	kButton_DownArrow	= 2,
	kButton_DateBook	= 3,
	kButton_Phone		= 4,
	kButton_ToDo		= 5,
	kButton_Memo		= 6
};


enum
{
	kScreen_WidthChanged		= 1,
	kScreen_HeightChanged		= 2,
	kScreen_DepthChanged		= 4,
	kScreen_ContentsChanged		= 8,
	kScreen_LCDChanged			= 16,
	kScreen_BacklightChanged	= 32
};


enum
{
	kException_BusErr	= 2,						// 08 / 2
	kException_AddressErr,							// 0C / 3
	kException_IllegalInstr,						// 10 / 4
	kException_DivideByZero,						// 14 / 5
	kException_Chk,									// 18 / 6
	kException_Trap,								// 1C / 7
	kException_Privilege,							// 20 / 8
	kException_Trace,								// 24 / 9
	kException_ATrap,								// 28 / A
	kException_FTrap,								// 2C / B
	kException_Reseved12,							// 30 / C
	kException_Coproc,								// 34 / D
	kException_FormatErr,							// 38 / E
	kException_UninitializedInt,					// 3C / F

	kException_Reserved0,							// 40-5C / 10-17
	kException_Reserved1,
	kException_Reserved2,
	kException_Reserved3,
	kException_Reserved4,
	kException_Reserved5,
	kException_Reserved6,
	kException_Reserved7,

	kException_SpuriousInt,							// 60 / 18
	kException_AutoVec1,							// 64 / 19
	kException_AutoVec2,							// 68 / 1A
	kException_AutoVec3,							// 6C / 1B
	kException_AutoVec4,							// 70 / 1C
	kException_AutoVec5,							// 74 / 1D
	kException_AutoVec6,							// 78 / 1E
	kException_AutoVec7,							// 7C / 1F

	kException_Trap0,								// 80 - BC / 20 - 2F	// For soft breakpoints	
	kException_Trap1,
	kException_Trap2,
	kException_Trap3,
	kException_Trap4,
	kException_Trap5,
	kException_Trap6,
	kException_Trap7,
	kException_Trap8,								// For compiled breakpoints	
	kException_Trap9,
	kException_Trap10,
	kException_Trap11,
	kException_Trap12,
	kException_Trap13,								// ATrap returns (emulator convention)
	kException_Trap14,								// Tail patches (emulator convention)
	kException_Trap15,								// Trap dispatcher

	kException_Unassigned0,							// C0 - FC / 30 - 3F
	kException_Unassigned1,
	kException_Unassigned2,
	kException_Unassigned3,
	kException_Unassigned4,
	kException_Unassigned5,
	kException_Unassigned6,
	kException_Unassigned7,
	kException_Unassigned8,
	kException_Unassigned9,
	kException_Unassigned10,
	kException_Unassigned11,
	kException_Unassigned12,
	kException_Unassigned13,
	kException_Unassigned14,
	kException_Unassigned15,

	kException_LastException
};


// CPU loop exit reasons

enum
{
	kBreak_None				= 0x00,
	kBreak_Exception		= 0x3F,			// An exception has occured
	kBreak_CheckForEvents	= 0x40,			// (Mac) Need to check for and handle events
	kBreak_StopRequest		= 0x80,			// (Windows) Other thread requested halt

	kBreak_All				= 0xFFFFFFFF
};


/*
	The following TRAP numbers are used by the ROM and the emulator:

		TRAP 0	- "soft" breakpoints, inserted by an external debugger.
		TRAP 8	- "hard" breakpoints, compiled into an application by DbgBreak.
		TRAP C	- used by the emulator to regain control after calling a ROM
				  function as a subroutine.
		TRAP D	- used by the emulator to regain control after calling a ROM
				  function in order to execute a tailpatch.
		TRAP E	- used by specially-compiled application to communicate with
				  the emulator.
		TRAP F	- standard trap for calling ROM functions from an application.
*/

//	const uae_u16	sysDbgBreakpointTrapNum	= 0x00;	// defined in SysTraps.h
//	const uae_u16	sysDbgTrapNum			= 0x08;	// defined in SysTraps.h
	const uae_u16	kATrapReturnTrapNum		= 0x0C;
	const uae_u16	kATrapTailpatchTrapNum	= 0x0D;
//	const uae_u16	emuTrapNum				= 0x0E;	// defined in EmuTraps.h
//	const uae_u16	sysDispatchTrapNum		= 0x0F;	// defined in SysTraps.h


extern TByteQueue	gKeyQueue;


// Prototypes.

#pragma mark -

#pragma mark Emulator

class Emulator
{
	public:
		static void		Initialize					(FILE* iMemoryFile,
													 FILE* iROMFile,
													 uae_s32 iRAMSize);
		static void		Reset						(void);
		static void		Dispose						(void);

		static long		Execute						(void);
		static void		ExecuteSpecial				(void);
		static void		ExecuteStoppedLoop			(void);
		static long		ExecuteUntilATrap			(void);
		static long		ExecuteUntilBreak			(void);

		static void		SetNextOpcode				(uae_u16);

		static uae_u32	SetBreakReason				(uae_u32);	// set the given bits; leave others alone
		static uae_u32	SetBreakReasonMask			(uae_u32);	// set the given bits; leave others alone
		static uae_u32	ClearBreakReason			(uae_u32);	// clear the given bits; leave others alone
		static uae_u32	ClearBreakReasonMask		(uae_u32);	// clear the given bits; leave others alone

		static bool		SetBreakOnException			(uae_s32 exceptionNumber,
													 bool doBreak);
};

#pragma mark Hardware

class Hardware
{
	public:
		static void		Initialize					(void);
		static void		Reset						(void);
		static void		Cycle						(bool DoAnyway);
		static void		PenEvent					(bool iPen_IsDown, uae_s32 iPen_HorzLocation, uae_s32 iPen_VertLocation);
		static void		ButtonEvent					(bool iButton_IsDown, uae_s32 iButton);
		static void		HotSyncEvent				(bool iButton_IsDown);
		static void		KeyboardEvent				(uae_u8 iKey);

		static bool		fgHotSyncButtonDown;
};

#pragma mark Screen

class Screen
{
	public:
		static int		GetDepth					(void);
		static int		GetWidth					(void);
		static int		GetHeight					(void);
		static void*	GetBaseAddress				(void);
		static bool		LCDIsOn						(void);
		static bool		BacklightIsOn				(void);
		static bool		GetBits						(void** bits, int* width, int* height, int* depth);
		static void		RecordChange				(uae_u32 theChange);
};

#pragma mark Software

class Software
{
	public:
		static void		BusError					(void);
		static void		ProcessException			(uae_s32 iException);
		static void		ProcessInterrupt			(uae_s32 iInterrupt);
		static void		ProcessIllegalInstruction	(uae_u32 iOpcode);
		static void		InstallExceptionHandler		(uae_s32 exceptionNumber, ExceptionHandlerProc);
		static void		RemoveExceptionHandler		(uae_s32 exceptionNumber);
		static bool		ProcessJSR					(uaecptr dest);
		static bool		ProcessRTS					(void);
		static bool		ProcessRTE					(uae_s32 newpc);
		static bool		ProcessTrap13				(uae_s32 iException);
		static bool		ProcessTrap14				(uae_s32 iException);
		static bool		ProcessTrap15				(uae_s32 iException);
};

#pragma mark LowMem

/*
	Low memory is laid out as follows:

	struct LowMemType
	{
		LowMemHdrType			fixed; 
		{
			M68KExcTableType		vectors;
			FixedGlobalsType		globals;
			{
				... most of the goodies are in here ...
			}
		}
	
		CardInfoType			memCardInfo[hwrNumCardSlots];	
		SlkGlobalsType			slkGlobals;
		DbgGlobalsType			dbgGlobals;
		SysAppInfoType			sysAppInfo;
		Ptr						sysDispatchTable[sysNumTraps];
	}

	Note that those last 5 guys don't need to be addressed directly;
	there are pointers to them in the "globals" section.

		--	memCardInfoP
		--	slkGlobalsP
		--	dbgGlobalsP
		--	sysAppInfoP
		--	sysDispatchTableP
*/

class LowMem
{
	public:
		static uae_u8	GetEvtMgrIdle				(void);
		static bool		TrapExists					(uae_u16 iATrap);
		static uaecptr	GetTrapAddress				(uae_u16 iATrap);

	#define LowMem_FixedOffset(field)			\
		(0 /*offsetof(LowMemType, fixed)*/ +	\
		 offsetof(LowMemHdrType, globals) +		\
		 offsetof(FixedGlobalsType, field))

//	#define LowMem_Bias(field)					\
//		(LowMem_FixedOffset(field) >= offsetof(LowMemHdrType, globals) ? LowMem::fgBias : 0)

	#define LowMem_Bias(field)					\
		(0)

	#define LowMem_Location(field)				\
		(LowMem_FixedOffset(field) + LowMem_Bias(field))

	#define LowMem_Size(x)						\
		(sizeof (((FixedGlobalsType*) 0)->x))

	#define In_LowMem_Range(x, v)				\
		((v) > LowMem_Location (x) - LowMem_Size (x) &&	\
		 (v) < LowMem_Location (x) + LowMem_Size (x))

	#define LowMem_GetGlobal(x)		\
		((LowMem_Size(x) == 1) ? get_byte (LowMem_Location(x)) :	\
		 (LowMem_Size(x) == 2) ? get_word (LowMem_Location(x)) :	\
								 get_long (LowMem_Location(x)))

	#define LowMem_SetGlobal(x, v)	\
		((LowMem_Size(x) == 1) ? put_byte (LowMem_Location(x), v) :	\
		 (LowMem_Size(x) == 2) ? put_word (LowMem_Location(x), v) :	\
								 put_long (LowMem_Location(x), v))
};

#pragma mark Registers

class Registers
{
	public:
		static void		GetRegisters				(regstruct& oRegisters);
		static void		SetRegisters				(regstruct& iRegisters);
		static uae_s32	GetInterruptLevel			(void);
		static uae_s32	GetInterruptBase			(void);
		static void		UpdateInterrupts			(void);
		static void		UpdatePortDInterrupts		(void);
		static void		UpdateRTCInterrupts			(void);
		static void		UpdateSRFromRegisters		(void);
		static void		UpdateRegistersFromSR		(void);
};

#pragma mark Utility

class Utility
{
	public:
		static long		GetFileSize					(FILE* iFile);
		static uae_u32	NextPowerOf2				(uae_u32 x);
		static bool		MemCmpy						(void* dest, const void* src, int len);
		static uae_u32	DateToDays					(uae_u32 year, uae_u32 month, uae_u32 day);
		static char*	ReplaceParameter			(char* string,
													 const char* parameter,
													 const char* replacement);
		static char*	ReplaceParameter			(char* string,
													 const char* parameter,
													 long replacement);
		static char*	GetAppName					(void);
		static char*	GetAppVersion				(void);
};


// Inline function to turn a trap word (0xA000) into an index
// into the trap table.

inline uae_u16 TrapIndex (uae_u16 trapWord)
{
	return trapWord & ~0xF000;
}



#endif	// CPU_REG_H
