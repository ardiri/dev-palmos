/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "UAE_Utils.h"


#pragma mark -

// ---------------------------------------------------------------------------
// The functions in this file work with two kinds of "pointers": uaecptr's
// and void*'s.  Accessing memory for each kind of pointer is different.
// Since the functions are template functions, we can't know at the time we
// write the function what kind of pointer we'll be dealing with, so we can't
// hard-code the memory-accessing method.  Instead, we provide all of these
// inline accessors and let the compiler sort it out.
// ---------------------------------------------------------------------------

inline char	_get_byte(const void* p)
	{ return *(char*) p; }

inline char	_get_byte(uaecptr p)
	{ return (char) get_byte(p); }

inline void	_put_byte(void* p, const uae_u8 v)
	{ *(uae_u8*) p = v; }

inline void	_put_byte(uaecptr p, const uae_u8 v)
	{ put_byte(p, v); }

inline uae_u16	_get_word(const void* p)
	{ return *(uae_u16*) p; }

inline uae_u16	_get_word(uaecptr p)
	{ return (uae_u16) get_word(p); }

inline void	_put_word(void* p, const uae_u16 v)
	{ *(uae_u16*) p = v; }

inline void	_put_word(uaecptr p, const uae_u16 v)
	{ put_word(p, v); }

inline uae_u32	_get_long(const void* p)
	{ return *(uae_u32*) p; }

inline uae_u32	_get_long(uaecptr p)
	{ return (uae_u32) get_word(p); }

inline void	_put_long(void* p, const uae_u32 v)
	{ *(uae_u32*) p = v; }

inline void	_put_long(uaecptr p, const uae_u32 v)
	{ put_long(p, v); }

inline const void* _get_real_address(const void* p)
	{ return p; }

inline const void* _get_real_address(uaecptr p)
	{ return get_real_address(p); }


#pragma mark -

// ---------------------------------------------------------------------------
//		� uae_memset
// ---------------------------------------------------------------------------

uaecptr		uae_memset(uaecptr dst, int val, size_t len)
{
	uaecptr		q = dst;

	uae_u32	longVal = val;
	longVal |= (longVal << 8);
	longVal |= (longVal << 16);

	while ((q & 3) && len > 0)	// while there are leading bytes
	{
		_put_byte(q, (uae_u8) val);
		q += 1;
		len -= 1;
	}

	while (len >= 4)			// while there are middle longs
	{
		_put_long(q, longVal);
		q += 4;
		len -= 4;
	}

	while (len > 0)				// while there are trailing bytes
	{
		_put_byte(q, (uae_u8) val);
		q += 1;
		len -= 1;
	}

	return dst;
}


// ---------------------------------------------------------------------------
//		� uae_memchr
// ---------------------------------------------------------------------------

uaecptr	uae_memchr(uaecptr src, int val, size_t len)
{
	// !!! TBD
	return 0;
}


// ---------------------------------------------------------------------------
//		� uae_memcmp
// ---------------------------------------------------------------------------

template <class T1, class T2>
int		uae_memcmp(T1 src1, T2 src2, size_t len)
{
	// !!! TBD
	return 0;
}

	// Instantiate uae_memcmp's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			const char*	uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template int		uae_memcmp<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template int		uae_memcmp<const char*, uaecptr>	(const char* dst, uaecptr src, size_t len);
template int		uae_memcmp<uaecptr, char*>			(uaecptr dst,  char* src, size_t len);
template int		uae_memcmp<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template int		uae_memcmp<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);


// ---------------------------------------------------------------------------
//		� uae_memcpy
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1		uae_memcpy (T1 dst, T2 src, size_t len)
{
	T1		q = dst;
	T2		p = src;

	while (len--)
	{
		_put_byte(q++, _get_byte(p++));
	}

	return dst;
}

	// Instantiate uae_memcpy's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_memcpy<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template uaecptr	uae_memcpy<uaecptr, char*>			(uaecptr dst,  char* src, size_t len);
template uaecptr	uae_memcpy<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template uaecptr	uae_memcpy<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);


// ---------------------------------------------------------------------------
//		� uae_memmove
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1		uae_memmove (T1 dst, T2 src, size_t len)
{
	T1		q = dst;
	T2		p = src;

	bool	backward = _get_real_address(dst) <= _get_real_address(src);

	if (backward)
	{
		while (len--)
		{
			_put_byte(q++, _get_byte(p++));
		}
	}
	else
	{
		q += len;
		p += len;

		while (len--)
		{
			_put_byte(--q, _get_byte(--p));
		}
	}

	return dst;
}

	// Instantiate uae_memmove's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_memmove<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template uaecptr	uae_memmove<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template uaecptr	uae_memmove<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);


#pragma mark -

// ---------------------------------------------------------------------------
//		� uae_strlen
// ---------------------------------------------------------------------------

size_t	uae_strlen(uaecptr str)
{
	size_t	len = -1;

	do {
		len++;
	} while (_get_byte(str++));

	return len;
}


// ---------------------------------------------------------------------------
//		� uae_strcpy
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strcpy(T1 dst, T2 src)
{
	T1		q = dst;
	T2		p = src;
	char	ch;

	do {
		ch = (char) _get_byte(p++);
		_put_byte(q++, ch);
	} while (ch);

	return dst;
}

	// Instantiate uae_strcpy's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strcpy<char*, uaecptr>			(char* dst, uaecptr src);
template uaecptr	uae_strcpy<uaecptr, char*>			(uaecptr dst,  char* src);
template uaecptr	uae_strcpy<uaecptr, const char*>	(uaecptr dst,  const char* src);
template uaecptr	uae_strcpy<uaecptr, uaecptr>		(uaecptr dst, uaecptr src);


// ---------------------------------------------------------------------------
//		� uae_strncpy
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strncpy(T1 dst, T2 src, size_t len)
{
	T1		q = dst;
	T2		p = src;
	char	ch;

	len++;

	while (--len)
	{
		ch = (char) _get_byte(p++);
		_put_byte(q++, ch);

		if (!ch)
		{
			while (--len)
			{
				_put_byte(q++, (char) 0);
			}

			break;
		}
	}

	return dst;
}

	// Instantiate uae_strncpy's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strncpy<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template uaecptr	uae_strncpy<uaecptr, char*>			(uaecptr dst,  char* src, size_t len);
template uaecptr	uae_strncpy<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template uaecptr	uae_strncpy<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);


// ---------------------------------------------------------------------------
//		� uae_strcat
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strcat(T1 dst, T2 src)
{
	// !!! TBD
	return 0;
}

	// Instantiate uae_strcat's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strcat<char*, uaecptr>			(char* dst, uaecptr src);
template uaecptr	uae_strcat<uaecptr, char*>			(uaecptr dst,  char* src);
template uaecptr	uae_strcat<uaecptr, const char*>	(uaecptr dst,  const char* src);
template uaecptr	uae_strcat<uaecptr, uaecptr>		(uaecptr dst, uaecptr src);


// ---------------------------------------------------------------------------
//		� uae_strncat
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strncat(T1 dst, T2 src, size_t len)
{
	// !!! TBD
	return 0;
}

	// Instantiate uae_strncat's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strncat<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template uaecptr	uae_strncat<uaecptr, char*>			(uaecptr dst,  char* src, size_t len);
template uaecptr	uae_strncat<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template uaecptr	uae_strncat<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);


// ---------------------------------------------------------------------------
//		� uae_strcmp
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strcmp(T1 dst, T2 src)
{
	// !!! TBD
	return 0;
}

	// Instantiate uae_strcmp's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			const char*	uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strcmp<char*, uaecptr>			(char* dst, uaecptr src);
template const char*uae_strcmp<const char*, uaecptr>	(const char* dst, uaecptr src);
template uaecptr	uae_strcmp<uaecptr, char*>			(uaecptr dst,  char* src);
template uaecptr	uae_strcmp<uaecptr, const char*>	(uaecptr dst,  const char* src);
template uaecptr	uae_strcmp<uaecptr, uaecptr>		(uaecptr dst, uaecptr src);


// ---------------------------------------------------------------------------
//		� uae_strncmp
// ---------------------------------------------------------------------------

template <class T1, class T2>
T1	uae_strncmp(T1 dst, T2 src, size_t len)
{
	// !!! TBD
	return 0;
}

	// Instantiate uae_strncmp's that work with:
	//
	//			dest		source
	//			------		------
	//			char*		uaecptr
	//			const char*	uaecptr
	//			uaecptr		char*
	//			uaecptr		const char*
	//			uaecptr		uaecptr

template char*		uae_strncmp<char*, uaecptr>			(char* dst, uaecptr src, size_t len);
template const char*uae_strncmp<const char*, uaecptr>	(const char* dst, uaecptr src, size_t len);
template uaecptr	uae_strncmp<uaecptr, char*>			(uaecptr dst,  char* src, size_t len);
template uaecptr	uae_strncmp<uaecptr, const char*>	(uaecptr dst,  const char* src, size_t len);
template uaecptr	uae_strncmp<uaecptr, uaecptr>		(uaecptr dst, uaecptr src, size_t len);
