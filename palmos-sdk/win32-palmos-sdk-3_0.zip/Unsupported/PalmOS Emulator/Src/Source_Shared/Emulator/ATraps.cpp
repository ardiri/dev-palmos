/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/


#include "ATraps.h"

#include "Platform.h"		// Platform_ReportString
#include "DebugMgr.h"		// Debug::InDebugger
#include "Byteswapping.h"	// Canonical
#include "TrapPatches.h"	// Patches::CallHeadpatch, Patches::CallTailpatch

#include <assert.h>


const uae_u16	kOpcode_ATrapReturn	= m68kTrapInstr + kATrapReturnTrapNum;


// ---------------------------------------------------------------------------
//		� ATrap::ATrap
// ---------------------------------------------------------------------------

ATrap::ATrap ()
{
	// Save the registers.

	Registers::GetRegisters (mOldRegisters);
	mNewRegisters = mOldRegisters;

	// We don't necessarily want to go through life in Trace mode, so turn it
	// off when making ATrap::Call's.

	mNewRegisters.t0 = mNewRegisters.t1 = 0;
	mNewRegisters.sr &= ~((1 << 15) | (1 << 14));

	// Give ourselves our own private stack.  We'll want this in case
	// we're in the debugger and the stack pointer is hosed.

	m68k_areg (mNewRegisters, 7) = (uaecptr) &mStack[kStackSize];

	Memory::MapPhysicalMemory (mStack, kStackSize);
}


// ---------------------------------------------------------------------------
//		� ATrap::~ATrap
// ---------------------------------------------------------------------------

ATrap::~ATrap ()
{
	Memory::UnmapPhysicalMemory (mStack);
}


// ---------------------------------------------------------------------------
//		� ATrap::Call
// ---------------------------------------------------------------------------
// Calls the given pseudo-ATrap.

long ATrap::Call (uae_u16 iATrap)
{
	// Up until now, the registers in "regs" have been left alone.  If any
	// values were pushed on the stack, the stack position was reflected in
	// mNewRegisters.  Now's the time to move those values from mNewRegisters
	// to regs.

	Registers::SetRegisters (mNewRegisters);

	// Make the call.

	long	breakReason = this->DoCall(iATrap);

	// Remember the resulting register values so that we can report them to
	// the user when they call GetD0 and/or GetA0.

	Registers::GetRegisters (mNewRegisters);

	// Put things back the way they were.

	Registers::SetRegisters (mOldRegisters);

	return breakReason;
}


// ---------------------------------------------------------------------------
//		� ATrap::PushByte
// ---------------------------------------------------------------------------

void ATrap::PushByte (uae_u8 iByte)
{
	m68k_areg (mNewRegisters, 7) -= 2;
	Memory_SetByte(m68k_areg (mNewRegisters, 7), iByte);
}


// ---------------------------------------------------------------------------
//		� ATrap::PushWord
// ---------------------------------------------------------------------------

void ATrap::PushWord (uae_u16 iWord)
{
	m68k_areg (mNewRegisters, 7) -= 2;
	Memory_SetWord (m68k_areg (mNewRegisters, 7), iWord);
}


// ---------------------------------------------------------------------------
//		� ATrap::PushLong
// ---------------------------------------------------------------------------

void ATrap::PushLong (uae_u32 iLong)
{
	m68k_areg (mNewRegisters, 7) -= 4;
	Memory_SetLong (m68k_areg (mNewRegisters, 7), iLong);
}


// ---------------------------------------------------------------------------
//		� ATrap::GetD0
// ---------------------------------------------------------------------------

uae_u32 ATrap::GetD0 ()
{
	return m68k_dreg (mNewRegisters, 0);
}


// ---------------------------------------------------------------------------
//		� ATrap::GetA0
// ---------------------------------------------------------------------------

uae_u32 ATrap::GetA0 ()
{
	return m68k_areg (mNewRegisters, 0);
}


// ---------------------------------------------------------------------------
//		� ATrap::DoCall
// ---------------------------------------------------------------------------
// Calls the pseudo-ATrap. When we return, D0 or A0 should hold the result,
// the parameters will still be on the stack with the SP pointing to them,
// and the PC will be restored to what it was before this function was called.

long ATrap::DoCall (uae_u16 iATrap)
{
	// Make sure that we're not in the debugger when calling a system function.
	// We really don't know what the state of the machine is, and we're not
	// in a position to move it into a "good state" (that is, a state where
	// we feel confident that we can insert a call to the ROM here).

	// (!!! Why is this commented out?)

//	assert (Debug::InDebugger () == false);

	// If we've patched this trap with a headpatch, call it.  Do this
	// _before_ pushing the return address on the stack, as the trap
	// patches are programmed to not expect those.
	//
	// If CallHeadpatch returns true, it means that the trap patch completely
	// handled the trap, and that the ROM version does not need to be called.

	if (Patches::CallHeadpatch (iATrap))
	{
		return 0;
	}

	// Remember the original PC so that we can restore it when we're done.
	
	uaecptr	oldPC = m68k_getpc ();

	// We get control of the processor back by pushing a return address onto
	// the stack that points to a break instruction.  When the function we call
	// executes its ultimate RTS, the PC will point to the break opcode, which
	// will get executed, causing Emulator::Execute to exit.
	//
	// That break opcode can reside anywhere, so we'll just put it on our
	// real stack.

	uae_u16	breakOpcode = kOpcode_ATrapReturn;
	m68k_areg (regs, 7) -= 4;
	Memory_SetLong (m68k_areg (regs, 7), (uae_u32) &breakOpcode);

	// The next line requires some explaining.  When USE_POINTER is defined, opcodes
	// are fetched with a version of nextiword that is based on do_get_mem_word.  For
	// Intel machines, do_get_mem_word returns memory values assuming "big endian order
	// but with every word byteswapped".  Thus, we need to write out the opcode in
	// little-endian order, which is what the assignment statement above does.  But when
	// USE_POINTER is not defined, the opcode is fetched with a version of nextiword that
	// is based on get_word.  get_word will dispatch through the DummyBank::GetWord
	// routine, which will return memory values assuming straight Big Endian order;
	// the Canonical statement performs that operation.

#if !defined (USE_POINTER)
	Canonical (breakOpcode);
#endif

	// Tell the CPU loop that it should break when it hits the trap exception.

	bool	oldBreak = Emulator::SetBreakOnException (kException_Trap0 + kATrapReturnTrapNum, true);

	// Set up the address banks so that pointers to variables on the stack
	// (like with that breakOpcode variable above) will resolve to their
	// actual physical locations.  This also helps us in our ROMStubs where
	// we may have passed the addresses of stack-based variables.

	Memory::MapPhysicalMemory (&breakOpcode, 64 * 1024L);

	// Get the address of the function we want to call and store it in the pc.

	uaecptr	address = LowMem::GetTrapAddress (iATrap);

	assert (address);	// Make sure it's implemented!

	m68k_setpc (address);

	// Execute until the next break.

	long	breakReason = Emulator::ExecuteUntilBreak ();

	// If we've patched this trap with a tailpatch, call it.

	Patches::CallTailpatch (iATrap);

	// At this point, the stack should be back to normal (pointing to the
	// values that were there when we were called), but the PC is pointing
	// to the break instruction that stopped us.  Restore the original PC.

	m68k_setpc (oldPC);

	// Unmap the stack from the emulator virtual memory space.

	Memory::UnmapPhysicalMemory (&breakOpcode);

	// Tell the CPU loop that we're done handling this exception.

	(void) Emulator::SetBreakOnException (kException_Trap0 + kATrapReturnTrapNum, oldBreak);

	// If we broke for the reason we're expecting, we're cool.

	if ((breakReason & kBreak_Exception) == (kException_Trap0 + kATrapReturnTrapNum))
	{
		breakReason = 0;
	}

	// Otherwise, display an error.

	else
	{
		Platform::ReportString ("ATrap::DoCall returned an exception");
	}

	return breakReason;
}


