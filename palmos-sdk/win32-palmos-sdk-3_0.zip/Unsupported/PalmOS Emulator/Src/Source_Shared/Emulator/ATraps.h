/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"
#include "UAE.h"

#include "RAM_ROM.h"
#include "CPU_REG.h"

// ATrap Class.

#pragma mark ATrap Class

class ATrap
{
	public:
						ATrap();
						~ATrap();

		long			Call(uae_u16 iATrap);

		void			PushByte(uae_u8 iByte);
		void			PushWord(uae_u16 iWord);
		void			PushLong(uae_u32 iLong);

		uae_u32			GetD0();
		uae_u32			GetA0();

	protected:
	
		long			DoCall(uae_u16 iATrap);

	private:
		regstruct		mOldRegisters;
		regstruct		mNewRegisters;

//		static const	kStackSize = 4096;		// VC++ doesn't do this, yet
		enum { kStackSize = 4096 };
		char			mStack[kStackSize];
};


// (I actually tried using function templates here, but they ended up adding
//  more code, instead of saving code by coalescing identical functions like
//  I'd hoped.)

#define PushParm(p)						\
	if (sizeof(p) == 4)					\
		theTrap.PushLong ((uae_u32) p);	\
	else if (sizeof(p) == 2)			\
		theTrap.PushWord ((uae_u16) p);	\
	else								\
		theTrap.PushByte ((uae_u8) p);

#define CallROM0(iATrap)				\
	ATrap theTrap;						\
	theTrap.Call (iATrap)

#define CallROM1(iATrap, p1)			\
	ATrap theTrap;						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM2(iATrap, p1, p2)		\
	ATrap theTrap;						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM3(iATrap, p1, p2, p3)	\
	ATrap theTrap;						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM4(iATrap, p1, p2, p3, p4)	\
	ATrap theTrap;						\
	PushParm(p4);						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM5(iATrap, p1, p2, p3, p4, p5)	\
	ATrap theTrap;						\
	PushParm(p5);						\
	PushParm(p4);						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM6(iATrap, p1, p2, p3, p4, p5, p6)	\
	ATrap theTrap;						\
	PushParm(p6);						\
	PushParm(p5);						\
	PushParm(p4);						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM7(iATrap, p1, p2, p3, p4, p5, p6, p7)	\
	ATrap theTrap;						\
	PushParm(p7);						\
	PushParm(p6);						\
	PushParm(p5);						\
	PushParm(p4);						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)

#define CallROM13(iATrap, p1, p2, p3, p4, p5, p6, p7, p8, p9, pA, pB, pC, pD)	\
	ATrap theTrap;						\
	PushParm(pD);						\
	PushParm(pC);						\
	PushParm(pB);						\
	PushParm(pA);						\
	PushParm(p9);						\
	PushParm(p8);						\
	PushParm(p7);						\
	PushParm(p6);						\
	PushParm(p5);						\
	PushParm(p4);						\
	PushParm(p3);						\
	PushParm(p2);						\
	PushParm(p1);						\
	theTrap.Call (iATrap)
