/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

/*
		A bunch of routines for profiling
*/

#include <string.h>
#include <stddef.h>
#include <stdio.h>
#include "Profiling.h"
#include "UAE.h"
#include "Common.h"		// UInt32
#include "Platform.h"	// Platform::Debugger

// sizes of buffers to use
#define MAXNAMELENGTH		      64
#define MAXROMFNS				2000
#define MAXNESTEDINTERRUPTS	   	   8

// shared values exported via Profiling.h
UInt64 gClockCycles;
UInt64 gReadCycles;
UInt64 gWriteCycles;

long gReadMismatch;		// debug
long gWriteMismatch;	// debug

bool gProfilingEnabled;
bool gProfilingOn;
bool gProfilingCounted;



// Internal stuff

static int gMaxCalls;
static int gMaxDepth;

#define NOADDRESS			0x00000000
#define ROOTADDRESS			0xFFFFFFFF
#define INTERRUPTADDRESS	0xFFFFFFFE
#define OVERFLOWADDRESS		0xFFFFFFFD
#define NORECORD	-1

struct ProfFileHeader {
	UInt32	proF;			// 'proF'
	UInt32	version;		// 0x00040002
	UInt32	fnCount;		// number of unique fns (records) in log
	UInt32	four;			// 0x00000004

	UInt32	zeros1;			// 0x00000000
	UInt32	zeros2;			// 0x00000000
	UInt32	unknown;		// 0xB141A3A9	- maybe timebase data
	UInt32	recordsSize;	// size of header plus size of data (or offset to string table)
	
	UInt32	stringTableSize;// size of string table in bytes
	UInt64	overhead;		// count for overhead
	Int32	rootRec;		// record number of root of tree
	
	UInt32	sixtyfour1;		// 0x00000064
	UInt32	sixtyfour2;		// 0x00000064
	UInt32	countsPerTime;  // translation between counts at nodes and integers in column
							// 0x00FD0000 = 16.580608 MHz with display in seconds
							// 0x000040C4 = 16.580608 MHz with display in milliseconds
	UInt32	oddstuff0;		// seems like it can be 0, set by profiler tool itself
	
	UInt32	oddstuff1;		// seems like it can be 0, set by profiler tool itself
	UInt32	oddstuff2;		// seems like it can be 0, set by profiler tool itself
	UInt32	oddstuff3;		// seems like it can be 0, set by profiler tool itself
	UInt32	oddstuff4;		// seems like it can be 0, set by profiler tool itself

	Byte	unused[0x200 - 0x50];	// for 0x200 bytes
};

struct FnCallRecord {
	UInt32	address;		// address of fn, also offset from start of name table to this fn's name
	UInt32	entries;		// times function was called
	UInt64	cyclesSelf;		// profiling data for this fn alone 
	UInt64	cyclesPlusKids;	// profiling data for this fn with kids
	UInt64	cyclesMin;		// profiling data for this fn alone, min
	UInt64	cyclesMax;		// profiling data for this fn alone, max
	Int32	sib;			// record number of sib, -1 for no sibs
	Int32	kid; 			// record number of kid, -1 for no kids
	UInt32	stackUsed;		// bytes of stack used by fn, we use it to count unmatched returns
};

struct FnStackRecord {
	int call;						// fn data block for fn being called
	uaecptr returnAddress;			// return address aka (SP) to calling fn
	UInt64 cyclesAtEntry;			// cycle count when fn was called
	UInt64 cyclesAtInterrupt;		// cycle count when fn was interrupted
	UInt64 cyclesInKids;			// number of cycles spent in subroutines
	UInt64 cyclesInInterrupts;		// number of cycles spent in interrupts
};

// call tree
static FnCallRecord* calls = NULL;
static int firstFreeCallRec;
static int rootRecord;
static int exceptionRecord;
static int overflowRecord;

// call stack (interrupts and calls in interrupts on same stack)
static FnStackRecord* callStack = NULL;
static int callSP;

// interrupt tracking, interrupt stack is callSP when interrupt happened
static int interruptDepth;
static int interruptStack[MAXNESTEDINTERRUPTS];
static UInt64 interruptCount;
static UInt64 interruptCycles;

static unsigned long missedCount;		// debug
static unsigned long extraPopCount;		// debug
static int interruptMismatch;			// debug


//---------------------------------------------------------------------
// Get function name out of debug symbols compiler produces
//---------------------------------------------------------------------

// in StringData.cpp
extern const char *kTrapNames[];
extern const int kNumTrapNames;
// end of StringData stuff

#define FIRSTTRAP 0x0000A000UL
#define LASTTRAP (FIRSTTRAP + kNumTrapNames)

struct ROMMapRecord {
	UInt32	address;
	char *	name;
};
ROMMapRecord *ROMMap = NULL;
int ROMMapEnd = 0;


// ����DOLATER ���
// We need to handle shared library routines, which are called by
// trap dispatcher.  They start at 0x0000A800

#define kOpcode_LINK	0x4E50
#define kOpcode_RTE		0x4E73
#define kOpcode_RTD		0x4E74
#define kOpcode_RTS		0x4E75
#define kOpcode_JMP		0x4ED0

static void GetRoutineName (uaecptr addr, char* bufferP)
{
	uae_u8	length;
	uaecptr	startPtr;
	uaecptr	endPtr = (uaecptr) addr;
	char *nameP = bufferP;
	
	// if it's a dummy function header, say so
	if (addr == NOADDRESS)
	{
		strcpy(bufferP, "partial");
		return;
	}
	
	if (addr == ROOTADDRESS)
	{
		strcpy(bufferP, "functions");
		return;
	}
	
	if (addr == INTERRUPTADDRESS)
	{
		strcpy(bufferP, "interrupts");
		return;
	}
	
	if (addr == OVERFLOWADDRESS)
	{
		strcpy(bufferP, "overflow");
		return;
	}
	
	if (addr < 0x100)
	{
		sprintf(bufferP, "interrupt $%02lX", addr);
		return;
	}
	
	// check for traps
	if (addr <= LASTTRAP && addr >= FIRSTTRAP)
	{
		sprintf(bufferP, "%s  $%04lX.t", kTrapNames[addr-FIRSTTRAP], addr);
		return;
	}
	
	// look up address in the ROM map
	if (ROMMap != NULL)
	{
		int i = 0;
		// ����DOLATER ���  use binary search, since ROMMap is sorted by address
		while (i < ROMMapEnd && addr > ROMMap[i].address)
			i++;
		if (i < ROMMapEnd && addr == ROMMap[i].address)
		{
			sprintf(bufferP, "%s  $%08lX.m", ROMMap[i].name, addr);
			return;
		}
	}	
		
	// if not in the map, try to get the symbol out of the ROM itself

	// Find the next RTS

	long	maxLength = 0x02000;

	do {
		// Make sure the address is valid
		if (!valid_address (endPtr, 2))
			goto ExitErr;

		uae_u16	opcode = get_word (endPtr);
		endPtr += 2;

		if (opcode == kOpcode_RTS ||
			opcode == kOpcode_RTE ||
			opcode == kOpcode_JMP ||	// JMP (A0)
			opcode == kOpcode_RTD)

			goto FoundEnd;

	} while (--maxLength);

	goto ExitErr;

FoundEnd:
	startPtr = (uaecptr) addr;
	maxLength = 0x1000;

	do {
		// Make sure the address is valid
		if (!valid_address (startPtr - 2, 2))
			goto ExitErr;

		uae_u16	opcode = get_word (startPtr);

		opcode &= 0xFFF8;	// mask off registers

		if (opcode == kOpcode_LINK)
			goto BegInA2;

		startPtr -= 2;
		opcode = get_word (startPtr);

		if (opcode == kOpcode_RTS ||
			opcode == kOpcode_RTE ||
			opcode == kOpcode_JMP ||	// JMP (A0)
			opcode == kOpcode_RTD)

			goto FoundBeg;

	} while (--maxLength);

	goto ExitErr;

FoundBeg:
	startPtr += 2;

	// Get the length of the macsbug symbol

	length = get_byte (startPtr);

	if (length < 0x80 || length > 0x9F)
		goto BegInA2;

	length &= 0x7F;

	if (length == 0)
	{
		startPtr += 1;
		length = get_byte (startPtr);
	}

	startPtr += length;		// end of label
	startPtr += 3;			// skip length byte  and DC.W 0
	if (startPtr & 1 != 0)	// if ptr is odd, bump to next word
		startPtr += 1;

BegInA2:
	length = get_byte (endPtr);
	endPtr++;

	if (length < 0x80 || length > 0x9F)
		goto ExitErr;

	length &= 0x7F;

	if (length == 0)
	{
		length = get_byte (endPtr);
		endPtr++;
	}

	if (length < 0 || length > 30)
		goto ExitErr;

	// copy the string
	do {
		*nameP++ = (char) get_byte(endPtr++);
	} while (--length);

	// Terminate the string.
	sprintf(nameP, "  $%08lX.d", addr);
	return;

ExitErr:
	// no symbol in ROM or invalid address, just output address
	sprintf(bufferP, "unknown  $%08lX", addr);
	return;
}





//---------------------------------------------------------------------
// Converting addresses to human readable names
//---------------------------------------------------------------------

char *stringTable = NULL;
static char *nameBuffer = NULL;
int stringTableEnd;
static void InitStringTable()
{
	// allocate the string table
	stringTable = new char[MAXNAMELENGTH * MAXUNIQUEFNS];
	nameBuffer = new char[MAXNAMELENGTH];
	stringTableEnd = 0;
}

static void CleanupStringTable()
{
	delete [] stringTable;
	stringTable = NULL;
	delete [] nameBuffer;
	nameBuffer = NULL;
}

static int FindOrAddString(char *newS)
{
	int offset = 0;
	while (offset < stringTableEnd)
		if (strcmp(&stringTable[offset], newS) == 0)
			return offset;
		else
			offset += strlen(&stringTable[offset])+1;
	strcpy(&stringTable[offset], newS);
	stringTableEnd = offset + strlen(newS) + 1;
	return (offset);
}

static void RecursiveAddressToStrings(int i)
{
	if (i != NORECORD)
	{
		// Not all addresses are valid. For instance, I've seen the value
		// 0x011dec94 in calls[x].address, which is either the address of the
		// TRAP $C instruction used to regain control in ATrap::DoCall, or
		// December 11, 1994.
		//  ...but that's OK, GetRoutineName handles that (calls valid_address)

		GetRoutineName (calls[i].address, nameBuffer);
		calls[i].address = FindOrAddString(nameBuffer);
		RecursiveAddressToStrings(calls[i].kid);
		RecursiveAddressToStrings(calls[i].sib);
	}
}




//---------------------------------------------------------------------
// debugging routine to print profiling stuff to a log file
//---------------------------------------------------------------------

// in Debugging.cpp
extern void PRINTF (const char* msg, ...);
// end of Debugging stuff

#define MAXNESTING	80
static void RecursivePrintBlock(int i, int depth)
{
	if (i != NORECORD)
	{
		{
			char tabs[MAXNESTING];
			if (depth < MAXNESTING)
			{
				for (int i=0; i<depth; i++)
					tabs[i] = '\t';
				tabs[depth] = '\0';
			}
			else
				sprintf(tabs, "<%d>\t", depth);
			
			char nameBuffer[MAXNAMELENGTH];
			GetRoutineName (calls[i].address, nameBuffer);
			PRINTF("%s-%s(%lu)%c %lu/%lu", tabs, nameBuffer, calls[i].entries,
					(calls[i].stackUsed?'!':' '), calls[i].cyclesSelf, calls[i].cyclesPlusKids);
		}
		RecursivePrintBlock(calls[i].kid, depth+1);
		RecursivePrintBlock(calls[i].sib, depth);
	}
}




//---------------------------------------------------------------------
// Call stack and call record management routines
//---------------------------------------------------------------------

static UInt64 PopCallStackFn(Boolean normalReturn)
{
	assert (callSP >= 0);

	UInt64 cyclesThisCall = U64Subtract(U64Subtract(gClockCycles, callStack[callSP].cyclesAtEntry),
									callStack[callSP].cyclesInInterrupts);
	UInt64 cyclesInMe = U64Subtract(cyclesThisCall, callStack[callSP].cyclesInKids);
	int exiter = callStack[callSP].call;
	
	calls[exiter].entries++;
	calls[exiter].cyclesPlusKids = U64Add(calls[exiter].cyclesPlusKids, cyclesThisCall);
	calls[exiter].cyclesSelf = U64Add(calls[exiter].cyclesSelf, cyclesInMe);
	calls[exiter].cyclesMin = U64Add(calls[exiter].cyclesMin, callStack[callSP].cyclesInInterrupts);

/*
	// ��� using cyclesMin to count time in interrupts for now
	if (U64Compare(cyclesInMe,calls[exiter].cyclesMin) < 0)
		calls[exiter].cyclesMin = cyclesInMe;
*/
	if (U64Compare(cyclesInMe, calls[exiter].cyclesMax) > 0)
		calls[exiter].cyclesMax = cyclesInMe;
	
	if (!normalReturn)
		calls[exiter].stackUsed += 1000;

	--callSP;
	if (callSP >= 0)
		callStack[callSP].cyclesInKids = U64Add(callStack[callSP].cyclesInKids, cyclesThisCall);

	return cyclesThisCall;
}


static int FindOrAddCall(int head, uaecptr address)
{
	int newR;
	int current;
	int prev;
	
	if (head == overflowRecord)
		return overflowRecord;

	if (head == NORECORD)
		newR = firstFreeCallRec++;	// head is empty, just create record
	else
	{
		// look for existing
		current = head;
		while (current != NORECORD && calls[current].address != address)
		{
			prev = current;
			current = calls[current].sib;
		}
		
		if (current != NORECORD)	// also returns if current == overflowRecord, good!
			return current;

		newR = firstFreeCallRec++;
		if (newR >= gMaxCalls)
			return overflowRecord;
		calls[prev].sib = newR;
	}

	if (newR >= gMaxCalls)
		return overflowRecord;

	assert (address == ROOTADDRESS ||
			address == INTERRUPTADDRESS ||
			address == OVERFLOWADDRESS ||
			valid_address (address, 2));

	// fill record
	calls[newR].sib = NORECORD;
	calls[newR].kid = NORECORD;
	calls[newR].address = address;
	calls[newR].entries = 0;
	calls[newR].cyclesSelf = U64Set(0);
	calls[newR].cyclesPlusKids = U64Set(0);
	calls[newR].cyclesMin = U64Set(0);	// 0xFFFFFFFFFFFFFFFF;
	calls[newR].cyclesMax = U64Set(0);
	calls[newR].stackUsed = 0;

	return newR;
}


//---------------------------------------------------------------------
// Main entry points, exported via Profiling.h
//---------------------------------------------------------------------

void ProfileInit(int maxCalls, int maxDepth)
{
	// initialize globals
	gClockCycles = U64Set(0);
	gReadCycles = U64Set(0);
	gWriteCycles = U64Set(0);

	gReadMismatch = 0;		// debug
	gWriteMismatch = 0;		// debug

	gProfilingEnabled = true;
	gProfilingOn = false;
	gProfilingCounted = false;
	interruptCycles = U64Set(0);
	interruptCount = 0;
	gMaxCalls = maxCalls;
	gMaxDepth = maxDepth;
	
	missedCount = 0;		// debug
	extraPopCount = 0;		// debug
	interruptMismatch = 0;	// debug

	// initialize call tree
	if (calls != NULL)
		Platform::Debugger();
	calls = new FnCallRecord[gMaxCalls];
	firstFreeCallRec = 0;
	exceptionRecord = FindOrAddCall(NORECORD, INTERRUPTADDRESS);
	overflowRecord = FindOrAddCall(NORECORD, OVERFLOWADDRESS);
	
	// initialize call stack
	if (callStack != NULL)
		Platform::Debugger();
	callStack = new FnStackRecord[gMaxDepth];
	callSP = 0;
	callStack[callSP].call = rootRecord = FindOrAddCall(NORECORD, NOADDRESS);
	callStack[callSP].returnAddress = NOADDRESS;
	callStack[callSP].cyclesAtEntry = gClockCycles;
	callStack[callSP].cyclesInKids = U64Set(0);
	callStack[callSP].cyclesInInterrupts = U64Set(0);
}



void ProfileCleanup()
{
	if (gProfilingOn)
		return;	// ��� DOLATER throw some error
	gProfilingEnabled = false;

	delete [] calls;
	calls = NULL;

	delete [] callStack;
	callStack = NULL;
}



void ProfileStart()
{
	if (!gProfilingEnabled)
		Platform::Debugger();				// should be an exception
	if (gProfilingOn)
		return;
	if (callSP != 0)			// debug check
		Platform::Debugger();
	gProfilingOn = true;
	interruptDepth = -1;
}



void ProfileStop()
{
	if (!gProfilingEnabled)
		Platform::Debugger();
	if (!gProfilingOn)
		return;

	// pop any functions on stack, updating cycles on the way up
	// stop when callSP == 0, which matches fake "root" fn

	while (interruptDepth >= 0)		// means we stopped profiling in an interrupt...
		ProfileInterruptExit(NOADDRESS);
		
	while (callSP > 0)
		PopCallStackFn(false);		// doesn't gather stats on the way out

	gProfilingOn = false;
}


void ProfilePrint()
{
	if (!gProfilingEnabled)
		Platform::Debugger();
	if (gProfilingOn)
		return;
	PRINTF("address(entries) thisFn/totalWKids");
	RecursivePrintBlock(rootRecord, 0);
	PRINTF("total clocks: %lu, reads: %lu, writes: %lu", gClockCycles, gReadCycles, gWriteCycles);
	PRINTF("return level mis-matches: %lu, non-matching returns: %lu", extraPopCount, missedCount);
}


void ProfileDump()
{
	if (!gProfilingEnabled)
		Platform::Debugger();
	if (gProfilingOn)
		return;

	// read in the ROM.map file
	if (ROMMap != NULL)
		Platform::Debugger();
	ROMMap = new ROMMapRecord[MAXROMFNS];
	ROMMapEnd = 0;
	char *names = new char[36 * MAXROMFNS];
	char *namesEnd = names;
	char name[36];
	UInt32 addr;

	FILE *ROMMapFile = fopen("ROM.map", "r");
	if (ROMMapFile)
	{
		while (!feof(ROMMapFile))
		{
			if (fscanf(ROMMapFile, " %35s $%lx \n", name, &addr) != 2)
				Platform::Debugger();
			ROMMap[ROMMapEnd].address = addr;
			ROMMap[ROMMapEnd++].name = namesEnd;
			strcpy(namesEnd, name);
			namesEnd += strlen(name) + 1;
		}
		fclose(ROMMapFile);
	}

	// fix up trees a bit (sum cycle counts for root nodes)
	calls[rootRecord].address = ROOTADDRESS;
	int current = calls[rootRecord].kid;
	while (current != NORECORD)
	{
		calls[rootRecord].cyclesPlusKids =
			U64Add(calls[rootRecord].cyclesPlusKids, calls[current].cyclesPlusKids);
		current = calls[current].sib;
	}

	current = calls[exceptionRecord].kid;
	while (current != NORECORD)
	{
		calls[exceptionRecord].cyclesPlusKids =
			U64Add(calls[exceptionRecord].cyclesPlusKids, calls[current].cyclesPlusKids);
		current = calls[current].sib;
	}

	// debugging
	if (calls[rootRecord].sib != NORECORD
	|| calls[exceptionRecord].sib != NORECORD
	|| calls[overflowRecord].sib != NORECORD
	|| calls[overflowRecord].kid != NORECORD)
		Platform::Debugger();

	// fix up top-level records
	calls[rootRecord].sib = exceptionRecord;
	calls[exceptionRecord].sib = overflowRecord;

	// free pointer could be really large...
	if (firstFreeCallRec > gMaxCalls)
		firstFreeCallRec = gMaxCalls;

	// munge all the addresses to produce the string table
	InitStringTable();

	RecursiveAddressToStrings(rootRecord);

	// do a little cleanup now
	delete [] ROMMap;
	ROMMap = NULL;
	delete [] names;

	// create the header blocks
	ProfFileHeader header;

	header.proF = 'proF';
	header.version = 0x00040002;
	header.fnCount = firstFreeCallRec;
	header.four = 0x00000004;

	header.zeros1 = 0x00000000;
	header.zeros2 = 0x00000000;
	header.unknown = 0x00000000;
	header.recordsSize = sizeof(ProfFileHeader) + firstFreeCallRec * sizeof(FnCallRecord);

	header.stringTableSize = stringTableEnd;
	header.overhead = interruptCycles;
	header.rootRec = rootRecord;

	header.sixtyfour1 = 0x00000064;
	header.sixtyfour2 = 0x00000064;
	header.countsPerTime = kCyclesPerSecond/100;	// times will be shown in milliseconds
	header.oddstuff0 = 0x00000000;

	header.oddstuff1 = 0x00000000;
	header.oddstuff2 = 0x00000000;
	header.oddstuff3 = 0x00000000;
	header.oddstuff4 = 0x00000000;

	for (int i=0; i < sizeof(header.unused); i++)
		header.unused[i] = 0x00;

	// create and open the output file
	FILE *outputFile = fopen("POSER Profile Results", "wb");

	// write header
	if (fwrite(&header, 1, sizeof(ProfFileHeader), outputFile) != sizeof(ProfFileHeader))
		Platform::Debugger();

	// write data
	if (fwrite(calls, sizeof(FnCallRecord), firstFreeCallRec, outputFile) != (size_t) firstFreeCallRec)
		Platform::Debugger();

	// write stringtable
	if (fwrite(stringTable, 1, stringTableEnd, outputFile) != (size_t) stringTableEnd)
		Platform::Debugger();

	// close the file
	fclose(outputFile);

	// cleanup
	CleanupStringTable();
}



void ProfileFnEnter(uaecptr address, uaecptr returnAddress)
{
	if (!gProfilingOn)
#if PROFILE_ONE_FN
		if (address == FNTOPROFILE)
			ProfileStart();
		else
			return;
#else
		return;
#endif

	// get the caller fn 
	int caller = callStack[callSP].call;
	
	// debug check, watch for overflow
	if (callSP >= gMaxDepth-1)
		Platform::Debugger();

	// push record for callee
	callStack[++callSP].returnAddress = returnAddress;
	callStack[callSP].cyclesAtEntry = gClockCycles;
	callStack[callSP].cyclesInKids = U64Set(0);
	callStack[callSP].cyclesInInterrupts = U64Set(0);
	callStack[callSP].call = FindOrAddCall(calls[caller].kid, address);
	
	// check if this was first kid and update parent
	if (calls[caller].kid == NORECORD && callStack[callSP].call != overflowRecord)
		calls[caller].kid = callStack[callSP].call;
}



void ProfileFnExit(uaecptr returnAddress)
{
	if (!gProfilingOn)
		return;

	// sanity check, try to make sure the returns match the calls we think they do
	if (callStack[callSP].returnAddress != NOADDRESS
	&& callStack[callSP].returnAddress != returnAddress)
	{
		int trySP = callSP;
		while (--trySP >= 0)
			if (returnAddress == callStack[trySP].returnAddress)
				break;

		if (trySP >= 0)
			// found a match on stack, so pop up to it
			while (callSP > trySP)
			{
				extraPopCount++;		// debug, count extra pops
				PopCallStackFn(false);
			}
		else if (callSP != 0)
		// could be a longjump disguised as an RTS, so push instead
		{
			ProfileFnEnter(returnAddress, m68k_getpc());
			calls[callStack[callSP].call].stackUsed += 10000;	// mark it as wierdly called
			missedCount++;				// debug, count unmatched returns
			return;
		}
	}

	PopCallStackFn(true);

#if PROFILE_ONE_FN
	// if we started on entering a function, stop when it exits
	if (callSP == 0)
		ProfileStop();
#else		
	// or an alternate thing to do if we pop too far, re-root and continue
	if (callSP < 0)
	{
		// uh oh, we must have exited the fn we started profiling in!
		// make a new root to handle the new enclosing function
		rootRecord = FindOrAddCall(NORECORD, NOADDRESS);
		if (rootRecord == overflowRecord)
			Platform::Debugger();
		calls[rootRecord].kid = callStack[0].call;	// old root
		callStack[0].returnAddress = NOADDRESS;
		callStack[0].call = rootRecord;
		// callStack[0].cyclesAtEntry = ... don't change, it's the time profiling was started
		callStack[0].cyclesInKids = U64Subtract(gClockCycles, callStack[0].cyclesAtEntry);
		callStack[0].cyclesInInterrupts = U64Set(0);
		callSP = 0;
	}
#endif
}



void ProfileInterruptEnter(uae_s32 iException, uaecptr returnAddress)
{
	if (!gProfilingOn)
		return;

	// get the caller fn 
	int caller = callStack[callSP].call;
	callStack[callSP].cyclesAtInterrupt = gClockCycles;
	interruptCount++;
	interruptStack[++interruptDepth] = callSP;	// mark the fn that was interrupted
	
	// debug check, watch for overflow
	if (callSP >= gMaxDepth-1)
		Platform::Debugger();

	// push record for callee
	callStack[++callSP].returnAddress = returnAddress;
	callStack[callSP].cyclesAtEntry = gClockCycles;
	callStack[callSP].cyclesInKids = U64Set(0);
	callStack[callSP].cyclesInInterrupts = U64Set(0);
	callStack[callSP].call = FindOrAddCall(calls[exceptionRecord].kid, iException);
	// check if this was first exception and update exceptionRecord
	if (calls[exceptionRecord].kid == NORECORD && callStack[callSP].call != overflowRecord)
		calls[exceptionRecord].kid = callStack[callSP].call;
}



void ProfileInterruptExit(uaecptr returnAddress)
{
	uae_s32 needsFakeCall = NOADDRESS;
	if (!gProfilingOn)
		return;

	if (interruptDepth < 0)		// means we started profiling in an interrupt... oh well
		return;

	if (callSP <= interruptStack[interruptDepth])
		Platform::Debugger();
	
	while (callSP > interruptStack[interruptDepth]+1)
	{
		// mismatched jsr/rts set inside interrupt handler, deal with it
		extraPopCount++;		// debug, count extra pops
		PopCallStackFn(false);
	}
		
	// sanity check, try to make sure the returns match the calls we think they do
	if (callStack[callSP].returnAddress != returnAddress)
		// trap handler is sneaky, and pushes stuff on the stack so that the RTE jumps
		// to the implementation of the trap.  Detect this by noticing the RTE address didn't
		// match and generating a fake function call.
		if (calls[callStack[callSP].call].address == 0x2F)
			needsFakeCall = callStack[callSP].returnAddress + 2;	// +2 to skip trap word
		else
			interruptMismatch++;
	
	// pop the interrupt block
	UInt64 cyclesThisCall = PopCallStackFn(true);
	assert(callSP >= 0);
	
	callStack[callSP].cyclesInKids = U64Subtract(callStack[callSP].cyclesInKids, cyclesThisCall);		// interrupt time not counted as kids
	callStack[callSP].cyclesInInterrupts = U64Add(cyclesThisCall, callStack[callSP].cyclesInInterrupts);	// mark it explicitly
	calls[callStack[callSP].call].stackUsed += 1;	// count interrupts this way
	interruptCycles = U64Add(interruptCycles, cyclesThisCall);
	interruptDepth--;

	if (needsFakeCall != NOADDRESS)
		ProfileFnEnter(returnAddress, needsFakeCall);
}


void ProfileTest()
{
	ProfileInit(15,5);
	ProfileStart();
	ProfileIncrementClock(110 * kCyclesPerSecond);
	
	ProfileInterruptExit(0x55555555);
	ProfileIncrementClock(110 * kCyclesPerSecond);
	
	ProfileFnEnter(0xAAAAAAAA, 0);	// new
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnEnter(0xBBBBBBBB, 0);	// new kid
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnEnter(0xCCCCCCCC, 0);		// new kid
				ProfileIncrementClock(1 * kCyclesPerSecond);
				ProfileFnExit(0);
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnEnter(0xDDDDDDDD, 0);		// new sib at end
				ProfileIncrementClock(1 * kCyclesPerSecond);
				ProfileFnExit(0);
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnEnter(0xCCCCCCCC, 0);		// same kid
				ProfileIncrementClock(1 * kCyclesPerSecond);
				ProfileFnExit(0);
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnEnter(0xBBBBBBBB, 0);	// same kid
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnEnter(0xCCCCCCCC, 0);		// new kid
				ProfileIncrementClock(1 * kCyclesPerSecond);
				ProfileFnExit(0);
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnEnter(0xDDDDDDDD, 0);	// new sib at end
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnEnter(0xCCCCCCCC, 0);		// new kid
				ProfileIncrementClock(1 * kCyclesPerSecond);
				ProfileFnExit(0);
	
	ProfileIncrementClock(120 * kCyclesPerSecond);
	ProfileInterruptEnter(0x11111111, 0);	// interrupt
		ProfileIncrementClock(10 * kCyclesPerSecond);
		ProfileFnEnter(0x22222222, 0);		// new kid
			ProfileIncrementClock(1 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(10 * kCyclesPerSecond);
		ProfileInterruptExit(0);

			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnEnter(0xCCCCCCCC, 0);	// new kid in middle
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnEnter(0xAAAAAAAA, 0);	// new kid at beginning
			ProfileIncrementClock(10 * kCyclesPerSecond);
			ProfileFnExit(0);
		ProfileIncrementClock(100 * kCyclesPerSecond);
		ProfileFnExit(0);
	ProfileIncrementClock(100 * kCyclesPerSecond);
	// ProfileFnExit(0);
	// ProfileIncrementClock(100 * kCyclesPerSecond);
	// ProfileFnExit(0);

	ProfileInterruptEnter(0x99999999, 0);	// interrupt
	ProfileIncrementClock(10 * kCyclesPerSecond);

	ProfileStop();
	ProfileDump();
	ProfileCleanup();
}
