/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

class Gremlins
{
public:
				Gremlins();
				~Gremlins();
	Boolean	IsInitialized() const;
	void		Initialize(unsigned short newNumber = -1, unsigned long untilStep = -1);
	void		Status(unsigned short *currentNumber, unsigned long *currentStep,
					unsigned long *currentUntil);
	Boolean	SetSeed(unsigned long newSeed);
	void		SetUntil(unsigned long newUntil);
	void 		Step();
	Boolean	GetFakeEvent();
	void		GetPenMovement();
	Boolean 	SendCharsToType();

private:
	unsigned short	keyProbabilitiesSum;	// The sum of all the key possiblities.
	Point				lastPoint;				// The previous point enqueued to TD.
	Boolean			lastPenDown;			// TRUE - last point caused a penDownEvent, FALSE - pen is up or already down.
	unsigned short	number;					// the random seed (-1 means not started)
	unsigned long	counter;					// The number of "events" produced by Gremlins.
	unsigned long	until;					// The maximum numbe of "events" to produce.
	Boolean		inited;					// TRUE - Gremlins has been initialized, FALSE - not inited.
	Boolean		catchUp;					// TRUE - Event loop needs time to catch up, FALSE - event loop doesn't need time.
	Boolean		needPenUp;				// TRUE - A pen up need to be enqueued, FALSE - pen up doesn't need to be  enqueued.
	char			charsToType[2048];	// Chars to send to the emulator.
};


#ifdef __cplusplus
extern "C" {
#endif

extern void GremlinsSendEvent (void);

extern void GremlinsProcessPacket (void* pktBodyP);

#ifdef __cplusplus 
}
#endif

