/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

/*
	Hitchhiker's Guide To Accessing Memory

	When emulating CPU instructions, all memory access must be emulated
	as well.  In addition, the memory location that the emulated instruction
	is accessing is not necessarily the same as the memory location in
	the emulator's address space.  That is, memory location 0x00001234 in
	the emulated process's address space is not the same as memory location
	0x00001234 in the emulator's address space.  Instead, the emulated
	0x00001234 is actually 0x00001234 bytes into some buffer that we've
	allocate for the purpose of holding the emulated address space's
	contents.

	There are several ranges of Palm OS memory that we need to emulate:

		- Low-memory RAM (for the dynamic heap)
		- High-memory RAM (for the storage heap)
		- ROM
		- Dragonball registers
		- Everything else

	Each of these ranges (except for the last one) is managed by a set of
	functions for reading from and writing to that memory and a chunk of
	memory that we allocate as a "backing store" for that memory.
	
	Thus, for each of these ranges, we need to quickly determine what set
	of functions need to be called.  The UAE-prescribed method for doing this
	is to divide the entire 4GB address space into 64K banks, each 64K long.

	Each 64K bank is managed by a set of functions.  These functions
	handle reading from and writing to that 64K bank, handling 1-byte, 2-byte,
	and 4-byte accesses.  They also manage mapping from the emulated addres
	space to the physical space as viewed by the emulator, and validate
	memory addresses.

	Because there are 64K of these 64K banks, the functions that manage
	each bank are stored in an array of 64K elements.  When we need to invoke
	a function for a particular bank, the upper word of the prospective
	memory address is used as a "bank index" into this array.  From that,
	the right set of functions is found, and the desired function from that
	set of functions is called.

	This 64K array is very sparse.  There are a one or two entries for
	managing the dynamic heap (depending on whether the dynamic heap is
	64K, 96K or 128K), 2 to 128 entries for the storage heap (depending on
	whether the storage heap is 128K to 8Meg), 8 to 32 entries for the ROM
	(again, depending on its size), and 1 for the Dragonball registers.
	That leaves the remaining 64K - 12 entries to be managed by a set of
	functions that do little but signal an address error if the memory they
	manage is being accessed.

	Pictorally, it looks like this:

	Emulated 4G space:				Memory function array							Address Bank functions

	0x00000000	+--------------+	+--------------------------------+
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x00010000	+--------------+	+--------------------------------+		|
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x00020000	+--------------+	+--------------------------------+		|
				|      64K     |											+----->	DRAM::GetLong, DRAM::SetLong
				\/\/\/\/\/\/\/\/													DRAM::GetWord, DRAM::SetWord
				\/\/\/\/\/\/\/\/													DRAM::GetByte, DRAM::SetByte
				|      64K     |													etc.
	0x10000000	+--------------+	+--------------------------------+
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x10010000	+--------------+	+--------------------------------+		|
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x10020000	+--------------+	+--------------------------------+		|
				|      64K     |											+----->	SRAM::GetLong, SRAM::SetLong
				\/\/\/\/\/\/\/\/													SRAM::GetWord, SRAM::SetWord
				\/\/\/\/\/\/\/\/													SRAM::GetByte, SRAM::SetByte
				|      64K     |													etc.
	0x10C00000	+--------------+	+--------------------------------+
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x10C10000	+--------------+	+--------------------------------+		|
				|      64K     |<---| Ptr to fns that mng this range |------+
	0x10C20000	+--------------+	+--------------------------------+		|
				|      64K     |											+----->	ROM::GetLong, ROM::SetLong
				\/\/\/\/\/\/\/\/													ROM::GetWord, ROM::SetWord
				\/\/\/\/\/\/\/\/													ROM::GetByte, ROM::SetByte
				|      64K     |													etc.
	0xFFFE0000	+--------------+	+--------------------------------+
				|      64K     |<---| Ptr to fns that mng this range |
	0xFFFF0000	+--------------+	+--------------------------------+
				|      64K     |<---| Ptr to fns that mng this range |------+
	0xFFFFFFFF	+--------------+	+--------------------------------+		|
																			+----->	Regs::GetLong, Regs::SetLong
																					Regs::GetWord, Regs::SetWord
																					Regs::GetByte, Regs::SetByte
																					etc.

	All of the remaining memory function array entries are initialized with
	pointers to the Dummy::GetLong, Dummy::SetLong, etc., set of functions.

	As an extension to this UAE model, we have added the facility for mapping
	memory from the emulator's address space directly into the emulated address
	space.  Thus, if we have some data at memory location 0x01234567 (for
	instance, some data from a .prc file that we're installing), we can make
	that data also show up at memory location 0x01234567 within the emulated
	address space.  This mechanism makes it easy for us to "inject" data
	into the emulated address space.  It also makes it easier to call emulated
	ROM functions as subroutines.  Some ROM functions take as parameters
	pointers to memory locations that are to receive values (for example,
	pointers to local variables).  For those functions, we just map the
	emulator's stack into the emulated address space.  After that's done,
	we can pass pointers to stack-based variables with impunity.

	Mapping from emulated addresses to "real" addresses (that is, the corresponding
	memory locations within the buffers we've allocated to "stand in" for the
	emulated memory) is performed via UAE-defined macros, described below.

	Executive summary:

		- use get_foo if you want the address checked for even/oddness.
		- use fooget to get the stuff that jumps through the address banks
		- use do_get_mem_foo to actually get the value using a physical address.

	get_long, get_word, get_byte, put_long, put_word, put_byte
		Inline functions that check for bus error (if necessary) and
		then either call one of the following or handle the bus error.

	longget_1, wordget_1, byteget_1, longput_1, wordput_1, byteput_1
		If MD_HAVE_MEM_1_FUNCS is not defined, these are just macros
		to the following functions.  Otherwise, the machdep/memory.h
		file is assumed to have defined them.

	longget, wordget, byteget, longput, wordput, byteput
		If NO_INLINE_MEMORY_ACCESS is not defined, these are macros
		to "call_mem_get_func(get_mem_bank(addr).lget, addr)", etc.
		Otherwise, they are out-of-line functions.  machdep_memory.h
		undefs this, so we get the inlined functions.

	get_mem_bank
		Gets the right addrbank object, with the help of the bankindex
		macro.

	bankindex
		Returns a bank index for the given address.

	call_mem_get_func
		Merely calls the given function through the addrbank fn ptr.

	check_addr
		Macro called by get_long, etc., to check the address for a
		bus error.  Always returns true (OK) if NO_EXCEPTION_3 is
		defined or CPU_LEVEL indicates 68020 or better.  Otherwise
		returns false (error) if low-bit of address is set. config.h
		defines NO_EXCEPTION_3, so this stubs to "true".

	do_get_mem_long, do_get_mem_word, do_get_mem_byte,
	do_put_mem_long, do_put_mem_word, do_put_mem_byte
		Very low-level memory access. They return the value at the
		given physical location, byte-swapping if needed.

	m68k_setpc
		Given a virtual address, sets regs.pc and updates regs.pc_p
		to point to hold the physical address.

	m68k_getpc
		Returns the current virtual address (which is not always
		up-to-date in regs.pc, but _is_ up-to-date in regs.pc_p).

	nextilong, nextiword, nextibyte
		Get the value pointed to by the pc and then bump the pc.
*/

#include "RAM_ROM.h"
#include "CPU_REG.h"

#include "Byteswapping.h"	// Canonical
#include "DebugMgr.h"		// Debug::CheckStepSpy
#include "Platform.h"		// ThrowNotify_foo
#include "Palm.h"			// CardHeaderType
#include "TrapPatches.h"	// RemoveAllTailpatches, InstallAllTailpatches, gSysDozing, etc.

#include "CRC.h"			// Crc16CalcBigBlock

#if HAS_PROFILING
#include "Profiling.h"		// profiling stuff
#endif


// Types.

#pragma mark Types

// Snippet from SystemPrv.h

/************************************************************
 * Common Equates between Native and Emulation mode
 *************************************************************/
#define	sysCardSignature		0xFEEDBEEFL		// card signature long word
#define sysStoreSignature		0xFEEDFACEL		// store signature long word


struct MapRange
{
	uae_u8*	addr;
	uae_u32	size;
};


// Private function declarations

static void		PreventedAccess	(int kind, bool forRead);

class Card
{
	public:
		static bool		IsCardHeader			(const void* p);
		static uae_u32	IsChecksumOK			(const void* p, uae_u32 fileLength);
		static bool		IsBoot10000				(const void* p);
		static long		GetResetVectorOffset	(const void* p);
		static bool		IsResetVectorValid		(const void* p);
		static void*	FindBoot10000			(const void* p, uae_s32 len);
};

class DummyBank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
};

class RegisterBank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
		static void		PreventedAccess	(uaecptr iAddress, long size, bool forRead);
};

class DRAMBank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
		static void		PreventedLowMemAccess	(uaecptr iAddress, long size, bool forRead);
		static void		PreventedGlobalAccess	(uaecptr iAddress, long size, bool forRead);
		static void		PreventedScreenAccess	(uaecptr iAddress, long size, bool forRead);

		static void		InvalidateScreenRange	(void);

	private:
		static void		CalcGlobalEnd	(void);
		static void		CalcScreenRange	(void);

		static uaecptr	fgGlobalEnd;
		static uaecptr	fgScreenStart;
		static uaecptr	fgScreenEnd;
};

class SRAMBank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
		static void		ProtectedAccess	(uaecptr iAddress, long size, bool forRead);
};

class ROMBank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
};

class M68681Bank
{
	public:
		static uae_u32	GetLong			(uaecptr iAddress);
		static uae_u32	GetWord			(uaecptr iAddress);
		static uae_u32	GetByte			(uaecptr iAddress);
		static void		SetLong			(uaecptr iAddress, uae_u32 iLongValue);
		static void		SetWord			(uaecptr iAddress, uae_u32 iWordValue);
		static void		SetByte			(uaecptr iAddress, uae_u32 iByteValue);
		static int		ValidAddress	(uaecptr iAddress, uae_u32 iSize);
		static uae_u8*	GetRealAddress	(uaecptr iAddress);
		static void		InvalidAccess	(uaecptr iAddress, long size, bool forRead);
		static void		PreventedAccess	(uaecptr iAddress, long size, bool forRead);

	private:
		static HwrDuartType	fgDuart;
};

class DBReg
{
	public:
		typedef uae_u32	(*ReadFunction)(uaecptr address, int size);
		typedef void	(*WriteFunction)(uaecptr address, int size, uae_u32 value);

		static void		SetHandler				(ReadFunction, WriteFunction, uae_u32 start, int count);

		static uae_u32	UnsupportedRead			(uaecptr address, int size);
		static void		UnsupportedWrite		(uaecptr address, int size, uae_u32 value);

		static uae_u32	StdRead					(uaecptr address, int size);
		static void		StdWrite				(uaecptr address, int size, uae_u32 value);
		static void		NullWrite				(uaecptr address, int size, uae_u32 value);	// For read-only registers

		static uae_u32	pllFreqSelRead			(uaecptr address, int size);				// Word  $202: PLL Frequency Select Register
		static uae_u32	portCDataRead			(uaecptr address, int size);				// Byte  $411: Port C Data Register
		static uae_u32	portMDataRead			(uaecptr address, int size);				// Byte  $449: Port M Data Register
		static uae_u32	tmr1StatusRead			(uaecptr address, int size);				// Word  $60A: Timer 1 Status Register
		static uae_u32	tmr2StatusRead			(uaecptr address, int size);				// Word  $616: Timer 2 Status Register
		static uae_u32	uReceiveRead			(uaecptr address, int size);				// Word  $904: Uart Receive Register
		static uae_u32	uTransmitRead			(uaecptr address, int size);				// Word  $906: Uart Transmit Register
		static uae_u32	rtcHourMinSecRead		(uaecptr address, int size);				// DWord $B00: RTC Hours, Minutes, Seconds Register

		static void		scrWrite				(uaecptr address, int size, uae_u32 value);	// Byte  $000: System Control Register
		static void		csASelect1Write			(uaecptr address, int size, uae_u32 value);	// DWord $114: Group A Chip Select 1 Register
		static void		intMaskHiWrite			(uaecptr address, int size, uae_u32 value);	// Word  $304: Interrupt Mask Register/HIGH word
		static void		intMaskLoWrite			(uaecptr address, int size, uae_u32 value);	// Word  $306: Interrupt Mask Register/LOW word
		static void		intStatusHiWrite		(uaecptr address, int size, uae_u32 value);	// Word  $30C: Interrupt Status Register/HIGH word
		static void		portDDataWrite			(uaecptr address, int size, uae_u32 value);	// Byte  $419: Port D Data Register
		static void		portDIntReqEnWrite		(uaecptr address, int size, uae_u32 value);	// Byte  $41D: Port D Interrupt Request Enable
		static void		tmr1StatusWrite			(uaecptr address, int size, uae_u32 value);	// Word  $60A: Timer 1 Status Register
		static void		tmr2StatusWrite			(uaecptr address, int size, uae_u32 value);	// Word  $616: Timer 2 Status Register
		static void		wdCounterWrite			(uaecptr address, int size, uae_u32 value);	// Word  $61C: Watchdog Counter
		static void		spiMasterControlWrite	(uaecptr address, int size, uae_u32 value);	// Word  $802: SPI Master Control Register
		static void		uBaudWrite				(uaecptr address, int size, uae_u32 value);	// Word  $902: Uart Baud Control Register
		static void		uTransmitWrite			(uaecptr address, int size, uae_u32 value);	// Word  $906: Uart Transmit Register
		static void		lcdRegisterWrite		(uaecptr address, int size, uae_u32 value);	// Any register that might require a complete redrawing of the screen if changed.
		static void		rtcControlWrite			(uaecptr address, int size, uae_u32 value);	// Word  $B0C: RTC Control Register
		static void		rtcIntStatusWrite		(uaecptr address, int size, uae_u32 value);	// Word  $B0E: RTC Interrupt Status Register
		static void		rtcIntEnableWrite		(uaecptr address, int size, uae_u32 value);	// Word  $B10: RTC Interrupt Enable Register

		static ReadFunction		fgReadFunctions[sizeof(HwrDBallType)];
		static WriteFunction	fgWriteFunctions[sizeof(HwrDBallType)];
};


// Globals.

#pragma mark Globals

// Let us map in at least four segments of emulator RAM into the "virtual
// RAM" of the emulated ROM.  Each time we call a ROM function via the
// ATrap class, two entries are used up.  By setting kNumPhysicalBanks,
// we allow for two of those to go on at the same time.

const int		kNumPhysicalBanks	= 4;

uae_u32			gRAMBank_Size;
uae_u32			gROMBank_Size;

uae_u32			gScreenWidth		= 0x03FF;
uae_u32			gScreenHeight		= 0x01FF;
uae_u32			gScreenDepth		= 1;
uaecptr			gScreenBufferStart	= 0;
uaecptr			gScreenBufferEnd	= 0;

MapRange		gPhysicalBanks[kNumPhysicalBanks];

char*			gRAM_Memory;
char*			gROM_Memory;

uaecptr			DRAMBank::fgGlobalEnd;
uaecptr			DRAMBank::fgScreenStart;
uaecptr			DRAMBank::fgScreenEnd;
HwrDuartType	M68681Bank::fgDuart;
HwrDBallType	g68328Regs;

uae_u16			gLastTmr1Status;
uae_u16			gLastTmr2Status;
uae_u8			gPortDEdge;

int				buserr;					// (normally defined in memory.c)


AddressBank*	gMemory_Banks[65536];	// (normally defined in memory.c)
AddressBank		gDummy_Bank			= { DummyBank::GetLong, DummyBank::GetWord, DummyBank::GetByte, DummyBank::SetLong, DummyBank::SetWord, DummyBank::SetByte, DummyBank::GetRealAddress, DummyBank::ValidAddress };
AddressBank		gRegister_Bank		= { RegisterBank::GetLong, RegisterBank::GetWord, RegisterBank::GetByte, RegisterBank::SetLong, RegisterBank::SetWord, RegisterBank::SetByte, RegisterBank::GetRealAddress, RegisterBank::ValidAddress };
AddressBank		gDRAM_Bank			= { DRAMBank::GetLong, DRAMBank::GetWord, DRAMBank::GetByte, DRAMBank::SetLong, DRAMBank::SetWord, DRAMBank::SetByte, DRAMBank::GetRealAddress, DRAMBank::ValidAddress };
AddressBank		gSRAM_Bank			= { SRAMBank::GetLong, SRAMBank::GetWord, SRAMBank::GetByte, SRAMBank::SetLong, SRAMBank::SetWord, SRAMBank::SetByte, SRAMBank::GetRealAddress, SRAMBank::ValidAddress };
AddressBank		gROM_Bank			= { ROMBank::GetLong, ROMBank::GetWord, ROMBank::GetByte, ROMBank::SetLong, ROMBank::SetWord, ROMBank::SetByte, ROMBank::GetRealAddress, ROMBank::ValidAddress };
AddressBank		g68681_Bank			= { M68681Bank::GetLong, M68681Bank::GetWord, M68681Bank::GetByte, M68681Bank::SetLong, M68681Bank::SetWord, M68681Bank::SetByte, M68681Bank::GetRealAddress, M68681Bank::ValidAddress };

DBReg::ReadFunction		DBReg::fgReadFunctions[sizeof(HwrDBallType)];
DBReg::WriteFunction	DBReg::fgWriteFunctions[sizeof(HwrDBallType)];

unsigned long	gPreventAccessNotificationFlags;

ValidateMemory	gValidateMemory =
{
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH,
	MASTER_RUNTIME_VALIDATE_SWITCH
};

ProtectMemory	gProtectMemory =
{
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH,
	true,	// SRAM-get
	false,	// SRAM-set
	MASTER_RUNTIME_PREVENT_SWITCH,
	MASTER_RUNTIME_PREVENT_SWITCH
};


#if defined (_DEBUG)

	// In debug mode, define a global variable that points to the
	// Palm ROM's low-memory globals.  That makes it easier to find
	// out what's going wrong when something goes wrong.

	LowMemHdrType*	gLowMemory;

#endif

// After 12 Million instructions executed...
#if PROFILE_MEMORY
enum
{
	kDRAMLongRead,		// 2,797,111
	kDRAMLongRead2,		//
	kDRAMWordRead,		// 1,334,295
	kDRAMByteRead,		//   427,936

	kDRAMLongWrite,		// 1,960,933
	kDRAMLongWrite2,	//
	kDRAMWordWrite,		//   800,780
	kDRAMByteWrite,		//   213,029

	kSRAMLongRead,		//     4,167
	kSRAMLongRead2,		//     4,167
	kSRAMWordRead,		//    10,768
	kSRAMByteRead,		//     6,295 (jumped WAY up (5-fold) after playing with Address Book / 20 Million instructions)

	kSRAMLongWrite,		//   516,246 (stable after boot?)
	kSRAMLongWrite2,	//
	kSRAMWordWrite,		//     5,112
	kSRAMByteWrite,		//     2,183

	kROMLongRead,		//    10,156
	kROMLongRead2,		//
	kROMWordRead,		//   557,062
	kROMByteRead,		//    15,516

	kROMLongWrite,		//         0
	kROMLongWrite2,		//
	kROMWordWrite,		//         0
	kROMByteWrite,		//         0

	kREGLongRead,		//     16,638
	kREGLongRead2,		//
	kREGWordRead,		//     30,477
	kREGByteRead,		//      3,553

	kREGLongWrite,		//      9,472
	kREGLongWrite2,		//
	kREGWordWrite,		//     20,709
	kREGByteWrite,		//     12,656
	
	kLastEnum
};

/*
	After 32,439,154 instructions:

	kDRAMLongRead,		// 6,466,064
	kDRAMWordRead,		// 3,342,826
	kDRAMByteRead,		//   940,345

	kDRAMLongWrite,		// 4,136,635
	kDRAMWordWrite,		// 1,462,995
	kDRAMByteWrite,		//   509,189

	kSRAMLongRead,		//    24,355
	kSRAMWordRead,		//    32,190
	kSRAMByteRead,		//    75,917

	kSRAMLongWrite,		// 2,074,137 (8-Meg ROM)
	kSRAMWordWrite,		//    42,050
	kSRAMByteWrite,		//    11,292

	kROMLongRead,		//    25,806
	kROMWordRead,		// 1,302,897
	kROMByteRead,		//    63,590

	kROMLongWrite,		//         0
	kROMWordWrite,		//         0
	kROMByteWrite,		//         0

	kREGLongRead,		//    32,037
	kREGWordRead,		//    74,299
	kREGByteRead,		//    91,930

	kREGLongWrite,		//    20,358
	kREGWordWrite,		//    57,879
	kREGByteWrite,		//    22,592
*/

long	gMemoryAccess[kLastEnum];
#endif


#pragma mark -


// ---------------------------------------------------------------------------
//		� Memory::Initialize
// ---------------------------------------------------------------------------
// Initializes the RAM, ROM, and special memory areas of the emulator.

void Memory::Initialize (FILE*		iRAMFile,
						FILE*		iROMFile,
						uae_s32		iRAMSize)
{
	Memory::Dispose (false);

	try
	{
		// Load the ROM file.

		Memory::InitializeROM (iROMFile);

		// Load the RAM file.

		Memory::InitializeRAM (iRAMFile, iRAMSize);

		// Clear the memory banks.

		for (uae_s32 aBankIndex = 0; aBankIndex < 65536; aBankIndex++)
			gMemory_Banks[aBankIndex] = &gDummy_Bank;

		// Initialize the valid memory banks.

		// Memory banks 0 and 1 are managed by the functions in gDRAM_Bank.

		Memory::InitializeBanks (gDRAM_Bank, bankindex(kDRAMBank_Start), 2);

		// Memory banks 0x1000 to <mumble> are managed byt the functions
		// in gSRAM_Bank.  <mumble> is based on the amount of RAM being emulated.

		Memory::InitializeBanks (gSRAM_Bank, bankindex(kSRAMBank_Start),
									bankindex(kSRAMBank_Start + gRAMBank_Size - 1) -
									bankindex(kSRAMBank_Start) + 1);

		// Memory banks 0x10C0 to <mumble> are managed byt the functions
		// in gROM_Bank.  <mumble> is based on the amount of ROM being emulated.

		Memory::InitializeBanks (gROM_Bank, bankindex(kROMBank_Start),
									bankindex(kROMBank_Start + gROMBank_Size - 1) -
									bankindex(kROMBank_Start) + 1);

		// Memory bank 0x10E0 is managed by the functions in g68681_Bank.

		Memory::InitializeBanks (g68681_Bank, bankindex(k68681Bank_Start), 1);

		// Memory bank 0xFFFF is managed by the functions in gRegister_Bank.

		Memory::InitializeBanks (gRegister_Bank, bankindex(kRegisterBank_Start), 1);

		// The Dragonball register bank is further sub-divided into separate handlers
		// for each memory address.  First, install the default handlers for reading
		// and writing (which basically report the access as invalid).

		DBReg::SetHandler(DBReg::UnsupportedRead, DBReg::UnsupportedWrite,
										kRegisterBank_Start, sizeof(HwrDBallType));

		// Now add standard/specialized handers for the defined registers.

#define INSTALL_HANDLER(read, write, reg) DBReg::SetHandler(read, write, addressof (reg), sizeof(g68328Regs.reg))

		INSTALL_HANDLER(DBReg::StdRead,			DBReg::scrWrite,				scr);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csAGroupBase);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBGroupBase);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCGroupBase);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDGroupBase);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csAGroupMask);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBGroupMask);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCGroupMask);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDGroupMask);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csASelect0);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::csASelect1Write,			csASelect1);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csASelect2);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csASelect3);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBSelect0);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBSelect1);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBSelect2);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csBSelect3);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCSelect0);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCSelect1);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCSelect2);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csCSelect3);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDSelect0);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDSelect1);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDSelect2);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDSelect3);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				csDebug);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pllControl);
		INSTALL_HANDLER(DBReg::pllFreqSelRead,	DBReg::StdWrite,				pllFreqSel);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pllTest);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pwrControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				intVector);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				intControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::intMaskHiWrite,			intMaskHi);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::intMaskLoWrite,			intMaskLo);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				intWakeupEnHi);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				intWakeupEnLo);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::intStatusHiWrite,		intStatusHi);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				intStatusLo);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				intPendingHi);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				intPendingLo);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portADir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portAData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portASelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portBDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portBData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portBSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portCDir);
		INSTALL_HANDLER(DBReg::portCDataRead,	DBReg::StdWrite,				portCData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portCSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portDDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::portDDataWrite,			portDData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portDPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portDPolarity);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::portDIntReqEnWrite,		portDIntReqEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portDIntEdge);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portEDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portEData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portEPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portESelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portFDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		portFData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portFPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portFSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portGDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		portGData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portGPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portGSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portJDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portJData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portJSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portKDir);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portKData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portKPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portKSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portMDir);
		INSTALL_HANDLER(DBReg::portMDataRead,	DBReg::StdWrite,				portMData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portMPullupEn);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				portMSelect);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pwmControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pwmPeriod);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				pwmWidth);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				pwmCounter);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr1Control);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr1Prescaler);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr1Compare);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr1Capture);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				tmr1Counter);
		INSTALL_HANDLER(DBReg::tmr1StatusRead,	DBReg::tmr1StatusWrite,			tmr1Status);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr2Control);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr2Prescaler);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr2Compare);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				tmr2Capture);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::NullWrite,				tmr2Counter);
		INSTALL_HANDLER(DBReg::tmr2StatusRead,	DBReg::tmr2StatusWrite,			tmr2Status);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				wdControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				wdReference);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::wdCounterWrite,			wdCounter);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				spiSlave);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				spiMasterData);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::spiMasterControlWrite,	spiMasterControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				uControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::uBaudWrite,				uBaud);
		INSTALL_HANDLER(DBReg::uReceiveRead,	DBReg::NullWrite,				uReceive);
		INSTALL_HANDLER(DBReg::uTransmitRead,	DBReg::uTransmitWrite,			uTransmit);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				uMisc);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		lcdStartAddr);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdPageWidth);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		lcdScreenWidth);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		lcdScreenHeight);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdCursorXPos);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdCursorYPos);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdCursorWidthHeight);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdBlinkControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::lcdRegisterWrite,		lcdPanelControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdPolarity);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdACDRate);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdPixelClock);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdClockControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdLastBufferAddr);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdOctetTermCount);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdPanningOffset);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdFrameRate);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdGrayPalette);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				lcdReserved);
		INSTALL_HANDLER(DBReg::rtcHourMinSecRead,DBReg::StdWrite,				rtcHourMinSec);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				rtcAlarm);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				rtcReserved);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::rtcControlWrite,			rtcControl);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::rtcIntStatusWrite,		rtcIntStatus);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::rtcIntEnableWrite,		rtcIntEnable);
		INSTALL_HANDLER(DBReg::StdRead,			DBReg::StdWrite,				stopWatch);
	}
	catch (...)
	{
		Memory::Dispose (false);
		throw;
	}
}


// ---------------------------------------------------------------------------
//		� Memory::Reset
// ---------------------------------------------------------------------------

void Memory::Reset (void)
{
}


// ---------------------------------------------------------------------------
//		� Memory::Dispose
// ---------------------------------------------------------------------------
// Deallocates the memory buffers created by Memory::Initialize.
// iAlsoDisposeROM indicates whether or not the ROM buffer should also be
// destroyed.  The default is true.

void Memory::Dispose (bool iAlsoDisposeROM)
{
	if (gRAM_Memory != NULL)
	{
		free (gRAM_Memory);
		gRAM_Memory = NULL;
	}

	if (iAlsoDisposeROM && (gROM_Memory != NULL))
	{
		free (gROM_Memory);
		gROM_Memory = NULL;
	}
}


// ---------------------------------------------------------------------------
//		� Memory::Dispose
// ---------------------------------------------------------------------------
// Saves the current RAM image to a file. iMemoryFile is a reference to a
// file where the memory should be saved. 

void Memory::Save (FILE* iMemoryFile)
{
	// Don't bother if there's nothing to save.

	if (gRAM_Memory == NULL)
		return;

	// Temporarily remove any munging we may have done.

	if (!Debug::InDebugger ())
	{
		Debug::RemoveBreakpoints ();
	}

	Patches::RemoveAllTailpatches ();

	// Unbyteswap the words (if necessary). We save everything in
	// Big-Endian format.

	ByteswapWords (gRAM_Memory, gRAMBank_Size);

	// Write the RAM data header to the file.

	uae_u32	hdr = 'ram ';
	Canonical (hdr);
	fwrite (&hdr, 1, 4, iMemoryFile);

	uae_u32	size = gRAMBank_Size;
	Canonical (size);
	fwrite (&size, 1, 4, iMemoryFile);

	// Write the actual RAM image.

	if (fwrite (gRAM_Memory, gRAMBank_Size, 1, iMemoryFile) != 1)
	{
		ThrowNotify_Always (kError_CantWriteRAM, errno);
	}

	// Rebyteswap the words (if necessary).

	ByteswapWords (gRAM_Memory, gRAMBank_Size);

	// Restore memory munging.

	if (!Debug::InDebugger ())
	{
		Debug::InstallBreakpoints ();
	}

	Patches::InstallAllTailpatches ();
}


// ---------------------------------------------------------------------------
//		� Memory::InitializeBanks
// ---------------------------------------------------------------------------
// Initializes the specified memory banks with the given data.

void Memory::InitializeBanks (	AddressBank&	iBankInitializer,
								uae_s32			iStartingBankIndex,
								uae_s32			iNumberOfBanks)
{
	for (uae_s32 aBankIndex = iStartingBankIndex;
		aBankIndex < iStartingBankIndex + iNumberOfBanks;
		aBankIndex++)
	{
		gMemory_Banks[aBankIndex] = &iBankInitializer;
	}
}


// ---------------------------------------------------------------------------
//		� Memory::InitializeROM
// ---------------------------------------------------------------------------
// Loads the ROM file into memory and initializes it.

void Memory::InitializeROM (FILE* iROMFile)
{
	// Don't bother if the ROM is already loaded.

	if (gROM_Memory != NULL)
		return;

	try
	{
		// Get the file size.

		uae_s32	fileSize = Utility::GetFileSize (iROMFile);
		if (fileSize == -1)
			ThrowNotify_Always (kError_CantLoadROMFile, errno);

		// Create a buffer to hold the ROM data.

		gROMBank_Size = fileSize;
		gROM_Memory = (char*) malloc (fileSize);
		ThrowNotify_IfNil (gROM_Memory, kError_NotEnoughMemoryForROM, kDefaultException);

		// Load the ROM file.

		if (fread (gROM_Memory, fileSize, 1, iROMFile) != 1)
			ThrowNotify_Always (kError_CantLoadROMFile, errno);

		// See if the header looks good.

		if (!Card::IsCardHeader (gROM_Memory))
			ThrowNotify_Always (kError_InvalidROMData, kDefaultException);

		// See if the checksum looks OK.

		uae_u32	error = Card::IsChecksumOK (gROM_Memory, fileSize);
		ThrowNotify_IfError (error, error, kDefaultException);

		// Header's good, but the code at the reset vector doesn't look quite
		// right. It's possible that this is just a BigROM image, and that there's
		// no SmallROM. If that's the case, we need to figure out where to relocate
		// the BigROM to and dummy up a SmallROM.

		if (!Card::IsResetVectorValid (gROM_Memory))
		{
			long	romShift;

			CardHeaderType	cardHdr = *(CardHeaderType*) gROM_Memory;
		
			Canonical (cardHdr);

			if ( cardHdr.hdrVersion == 1 )
			{
				long	boot_10000_actual_offset = ((char*) Card::FindBoot10000 (gROM_Memory, fileSize)) -
													gROM_Memory;
				long	boot_10000_intended_loc = Card::GetResetVectorOffset(gROM_Memory);

				romShift = boot_10000_intended_loc - boot_10000_actual_offset;
			}
			else
			{
				// "bigROMOffset" holds the offset from the start of the card for the ROM.
				// (NOT the offset from the beginning of the small rom, ie, 0x10C00000).

				romShift = cardHdr.bigROMOffset + kSRAMBank_Start - 0x10C00000;
			}

			// Out with the old...

			free (gROM_Memory);

			// ...and in with the new.

			gROMBank_Size = fileSize + romShift;
			gROM_Memory = (char*) malloc (fileSize + romShift);
			ThrowNotify_IfNil (gROM_Memory, kError_NotEnoughMemoryForROM, kDefaultException);

			// Re-read the ROM image into the new (larger) buffer at the correct location.

			if ( (fseek (iROMFile, 0, SEEK_SET)) )
				ThrowNotify_Always (kError_CantLoadROMFile, errno);

			if ( fread (gROM_Memory + romShift, fileSize, 1, iROMFile) != 1 )
				ThrowNotify_Always (kError_CantLoadROMFile, errno);

			// Copy the card header down to the SmallROM-reserved space. That should be
			// enough to get us booted.

			*(CardHeaderType*) gROM_Memory = *(CardHeaderType*) (((char*) gROM_Memory) + romShift);

			// Again, see if the header looks good

//			if ( !Card::IsCardHeader (gROM_Memory) )
//				ThrowNotify_Always (kError_CantLoadROMFile, kDefaultException);

			// Again, check the resetVector. This time, if it's not right, then there's
			// nothing else we can do.

			if ( !Card::IsResetVectorValid (gROM_Memory) )
				ThrowNotify_Always (kError_InvalidROMData, kDefaultException);
		}

		// Byteswap all the words in the ROM (if necessary). Most accesses
		// are 16-bit accesses, so we optimize for that case.

		ByteswapWords (gROM_Memory, gROMBank_Size);

		// Make sure that gROMBank_Size is a power-of-2. The ROMBank memory
		// routines seem to require this.

		gROMBank_Size = Utility::NextPowerOf2 (gROMBank_Size);
	}
	catch (...)
	{
		Memory::Dispose ();
		throw;
	}
}


// ---------------------------------------------------------------------------
//		� Memory::InitializeRAM
// ---------------------------------------------------------------------------
// Loads a RAM image from a file.  Note: This function should only be called
// from Memory::Initialize.

void Memory::InitializeRAM (FILE* iRAMFile, uae_s32 iRAMSize)
{
	try
	{
		// Clear any existing memory.

		if (gRAM_Memory != NULL)
			Memory::Dispose (false);

		// If a RAM file's been specified, load it.

		if (iRAMFile)
		{
			// Get the size of the file.

#if 0
			gRAMBank_Size = Utility::GetFileSize (iRAMFile);
			if (gRAMBank_Size == -1)
				ThrowNotify_Always (kError_CantLoadRAMFile, errno);
#else
			// Read the header type.

			uae_u32	hdr;
			if (!fread (&hdr, 1, 4, iRAMFile))
				ThrowNotify_Always (kError_CantLoadRAMFile, errno);

			Canonical (hdr);
			if (hdr != 'ram ')
				ThrowNotify_Always (kError_CantLoadRAMFile, errno);

			if (!fread (&gRAMBank_Size, 1, 4, iRAMFile))
				ThrowNotify_Always (kError_CantLoadRAMFile, errno);

			Canonical (gRAMBank_Size);
#endif

			// Use it to create a RAM buffer.

			gRAM_Memory = (char*) calloc (gRAMBank_Size, 1);
			ThrowNotify_IfNil (gRAM_Memory, kError_NotEnoughMemoryForRAM, kDefaultException);

			// Read the RAM data into memory.

			if (fread (gRAM_Memory, gRAMBank_Size, 1, iRAMFile) != 1)
				ThrowNotify_Always (kError_CantLoadRAMFile, errno);

			// Rebyteswap the words (if necessary).

			ByteswapWords (gRAM_Memory, gRAMBank_Size);
		}

		// If a RAM file was NOT specified or the attempt to load it fails, just
		// create a new buffer of the specified size.

		if (!gRAM_Memory)
		{
			gRAMBank_Size = iRAMSize * 1024;
			gRAM_Memory = (char*) calloc (gRAMBank_Size, 1);
			ThrowNotify_IfNil (gRAM_Memory, kError_NotEnoughMemoryForRAM, kDefaultException);
		}

#if defined (_DEBUG)

		// In debug mode, define a global variable that points to the
		// Palm ROM's low-memory globals.  That makes it easier to find
		// out what's doing wrong when something goes wrong.

		gLowMemory = (LowMemHdrType*) gRAM_Memory;

#endif
	}
	catch (...)
	{
		Memory::Dispose (false);

		throw;
	}
}


// ---------------------------------------------------------------------------
//		� Memory::MapPhysicalMemory
// ---------------------------------------------------------------------------
// Maps a range of physical memory to appear at the same location of the
// emulated Palm OS's virtual memory.

void Memory::MapPhysicalMemory (const void* addr, uae_u32 size)
{
	// Make sure that the passed in memory range doesn't overlap with
	// memory ranges already in use.

	uae_s32	startIndex = bankindex(addr);
	uae_s32	endIndex = bankindex(((uae_u8*) addr) + size);

	for (uae_s32 ii = startIndex; ii <= endIndex; ++ii)
	{
		assert (gMemory_Banks[ii] == &gDummy_Bank);
	}

	// We're cool...map in the range.

	int	jj;
	for (jj = 0; jj < kNumPhysicalBanks; ++jj)
	{
		if (gPhysicalBanks[jj].addr == NULL)
		{
			gPhysicalBanks[jj].addr = (uae_u8*) addr;
			gPhysicalBanks[jj].size = size;
			break;
		}
	}

	if (jj == kNumPhysicalBanks)
	{
		assert (!"Too many physical memory mappings.");
		abort ();
	}
}


// ---------------------------------------------------------------------------
//		� Memory::UnmapPhysicalMemory
// ---------------------------------------------------------------------------
// Unmaps a range of physical memory from appearing at the same location of
// the emulated Palm OS's virtual memory.

void Memory::UnmapPhysicalMemory (const void* addr)
{
	for (int ii = 0; ii < kNumPhysicalBanks; ++ii)
	{
		if (gPhysicalBanks[ii].addr == (uae_u8*) addr)
		{
			gPhysicalBanks[ii].addr = NULL;
			gPhysicalBanks[ii].size = 0;
		}
	}
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Card::IsCardHeader
// ---------------------------------------------------------------------------
// Determines if the memory pointed to looks like a card header.

bool Card::IsCardHeader (const void* p)
{
	CardHeaderType	cardHdr = *(CardHeaderType*) p;

	Canonical (cardHdr);

	if (cardHdr.signature != sysCardSignature)
		return false;

/*
	if ( (cardHdr.hdrVersion != 1) && (cardHdr.hdrVersion != 2) )
		return false;

	if ( strcmp ( (char*) card->name, "PalmCard" ) != 0 )
		return false;

	if ( strcmp ((char*) card->manuf, "Palm Computing") != 0 )
		return false;

	if ( cardHdr.version != 1 )
		return false;
*/

	return true;
}


// ---------------------------------------------------------------------------
//		� Card::IsChecksumOK
// ---------------------------------------------------------------------------
// Determines if the memory pointed to looks like a card header.

uae_u32 Card::IsChecksumOK (const void* p, uae_u32 fileLength)
{
	uae_u32	error = kError_InvalidROMData;

	CardHeaderType	cardHdr = *(CardHeaderType*) p;

	Canonical (cardHdr);

	if (cardHdr.hdrVersion == 1)
	{
		static const Word	kDebug20 = 0x9BED;
		static const Word	kROMChecksums[] =
		{
			0x67C8,		// 1.0 - English - v30 ROMs - ROM5Rel - 1/9/96
			0x83FC,		// 1.0 - French - v10 ROMs - ROM5Rel - 3/28/96
			0xE1D9,		// 1.0 - French - v11 ROMs - ROM5Rel - 4/4/96
			0x41BE,		// 1.0 - French - v13 ROMs - ROM5Rel - 4/11/96
			0xC2AE,		// 1.0 - German - v10 ROMs - ROM5Rel - 4/1/96
			0x1FCE,		// 1.0 - German - v12 ROMs - ROM5Rel - 4/10/96
			0x3D33,		// 1.0 - German - v13 ROMs - ROM5Rel - 4/10/96

			kDebug20,	// 2.0 - Debug - 12/23/97
			0x3EA3,		// 2.0 - ROMA - ROM5Rel - 1/28/97
			0xEFB6,		// 2.0 - ROMB - English - ROM.2.0B.GM.US - 2/18/97
			0x11A9,		// 2.0 - ROMB - WorkPad - ROMf2wProFatRel - 7/7/97
			0x9573,		// 2.0 - International ROMA - French - ROMf2fRel - 4/29/97
			0x2422,		// 2.0 - International ROMA - German - ROMf2gRel - 3/7/97
			0x0BFC,		// 2.0 - International ROMB - French - ROMf1fProRel - 5/28/97
			0xFCBB,		// 2.0 - International ROMB - German - ROMf2gProRel - 5/29/97
			0x2E10		// 2.0 - International ROMB - Spanish - ROMf1sFatRel - 11/18/97
		};

		Word	checksumValue = Crc16CalcBigBlock ((/*non-const*/ void*) p, fileLength, 0);

#if 0
		// Can't do this, yet, as the above set of checksums may not match
		// what's actually in shipping devices (I only know that they match
		// what we have on our servers around here).

		for (int ii = 0; ii < (sizeof (kROMChecksums) / sizeof (kROMChecksums[0])); ++ii)
		{
			if (kROMChecksums[ii] == checksumValue)
			{
				error = 0;
				break;
			}
		}
#else
		error = 0;
#endif

		// Special hack for 2.0 Debug ROMs.  The version with this checksum was
		// bogus, so let's make sure we never load it.

		if (checksumValue == kDebug20)
		{
			error = kError_ROMNotSupported;
		}
	}
	else
	{
		// The checksum is the cumulative checksum of the ROM image before
		// the stored checksum value and the ROM image following the checksum
		// value.  First, calculate the first part.

		DWord	chunkSize = offsetof (CardHeaderType, checksumValue);
		Word	checksumValue = Crc16CalcBigBlock ((/*non-const*/ void*) p, chunkSize, 0);

		// Now calculate the second part.

		checksumValue = Crc16CalcBigBlock (
			((char*) p) + chunkSize + sizeof (cardHdr.checksumValue),
			cardHdr.checksumBytes - chunkSize - sizeof (cardHdr.checksumValue),
			checksumValue);

		if (checksumValue == cardHdr.checksumValue)
		{
			error = 0;
		}
	}

	return error;
}


// ---------------------------------------------------------------------------
//		� Card::IsBoot10000
// ---------------------------------------------------------------------------
// Determines if the memory pointed to looks like the entry point for the
// boot(10000) resource.

bool Card::IsBoot10000 (const void* p)
{
	// Make a test assuming that the entry point looks like:
	//
	//		JMP <some 2-byte offset>
	//		#'boot'
	//		#10000

	const unsigned char*	ptr = (const unsigned char*) p;
	return (ptr[0] == 0x4E &&		// JMP op
			ptr[1] == 0xFA &&		// JMP op
//			ptr[2] == 0x?? &&		// could be anything...
//			ptr[3] == 0x?? &&		// could be anything...
			ptr[4] == 'b' &&
			ptr[5] == 'o' &&
			ptr[6] == 'o' &&
			ptr[7] == 't' &&
			ptr[8] == (10000 / 256) &&
			ptr[9] == (10000 % 256));
}


// ---------------------------------------------------------------------------
//		� Card::GetResetVectorOffset
// ---------------------------------------------------------------------------

long Card::GetResetVectorOffset(const void* p)
{
	CardHeaderType	cardHdr = *(CardHeaderType*) p;

	Canonical (cardHdr);

	long	offset = ((const char*) cardHdr.resetVector) - ((const char*) kROMBank_Start);

	return offset;
}


// ---------------------------------------------------------------------------
//		� Card::IsResetVectorValid
// ---------------------------------------------------------------------------
// Tests the reset vector in the card header to make sure it looks like it
// points to a valid entry point.

bool Card::IsResetVectorValid (const void* p)
{
	long	offset = Card::GetResetVectorOffset(p);

	return Card::IsBoot10000 (((const char*) p) + offset);
}


// ---------------------------------------------------------------------------
//		� Card::FindBoot10000
// ---------------------------------------------------------------------------
// Scans memory for something that looks like a valid entry point (that is,
// it passes the Card::IsBoot10000 test).  Returns a pointer to the first
// memory location within the range that passes the test, NULL otherwise.

void* Card::FindBoot10000 (const void* p, uae_s32 len)
{
	len /= 2;
	short*	ptr = (short*) p;

	while (len--)
	{
		if (Card::IsBoot10000 (ptr))
			return ptr;

		++ptr;
	}

	return NULL;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Dummy Bank Accessors
// ---------------------------------------------------------------------------
// Dummy banks are non-existent blocks of memory.  Dummy bank accessors do
// not do anything.

uae_u32 DummyBank::GetLong (uaecptr iAddress)
{
#if (VALIDATE_DUMMY_GET)

	if (gValidateMemory.fDummyGet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementRead(2, WAITSTATES_DUMMYBANK);
#endif

	uae_u8*	p = (uae_u8*) iAddress;
	return (((uae_u32) p[0]) << 24) | (((uae_u32) p[1]) << 16) | (((uae_u32) p[2]) << 8) | p[3];
}

// ..................................................................................

uae_u32 DummyBank::GetWord (uaecptr iAddress)
{
	// Hack to keep HwrGetRAMSize working: it runs off
	// the end of RAM while testing it.

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementRead(1, WAITSTATES_DUMMYBANK);
#endif

	if ((iAddress & 0xFF000000) == kSRAMBank_Start)
		return 0;

#if (VALIDATE_DUMMY_GET)

	if (gValidateMemory.fDummyGet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, true);
	}

#endif

	uae_u8*	p = (uae_u8*) iAddress;
	return (((uae_u32) p[0]) << 8) | p[1];
}

// ..................................................................................

uae_u32 DummyBank::GetByte (uaecptr iAddress)
{
#if (VALIDATE_DUMMY_GET)

	if (gValidateMemory.fDummyGet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementRead(1, WAITSTATES_DUMMYBANK);
#endif

	uae_u8*	p = (uae_u8*) iAddress;
	return p[0];
}

// ..................................................................................

void DummyBank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
#if (VALIDATE_DUMMY_SET)

	if (gValidateMemory.fDummySet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, false);
	}

#endif

	uae_u8*	p = (uae_u8*) iAddress;
	p[0] = (uae_u8) (iLongValue >> 24);
	p[1] = (uae_u8) (iLongValue >> 16);
	p[2] = (uae_u8) (iLongValue >> 8);
	p[3] = (uae_u8) (iLongValue >> 0);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementWrite(2, WAITSTATES_DUMMYBANK);
#endif
}

// ..................................................................................

void DummyBank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
	// Hack to keep HwrGetRAMSize working: it runs off
	// the end of RAM while testing it.

	if ((iAddress & 0xFF000000) == kSRAMBank_Start)
		return;

#if (VALIDATE_DUMMY_SET)

	if (gValidateMemory.fDummySet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, false);
	}

#endif

	uae_u8*	p = (uae_u8*) iAddress;
	p[0] = (uae_u8) (iWordValue >> 8);
	p[1] = (uae_u8) (iWordValue >> 0);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementWrite(1, WAITSTATES_DUMMYBANK);
#endif
}

// ..................................................................................

void DummyBank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
#if (VALIDATE_DUMMY_SET)

	if (gValidateMemory.fDummySet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, false);
	}

#endif

	uae_u8*	p = (uae_u8*) iAddress;
	p[0] = (uae_u8) (iByteValue >> 0);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
		ProfileIncrementWrite(1, WAITSTATES_DUMMYBANK);
#endif
}

// ..................................................................................

int DummyBank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	int	result = false;

	// Allow access to the physical range of memory that we've
	// mapped into Palm OS-emulated space.

	for (int ii = 0; ii < kNumPhysicalBanks; ++ii)
	{
		if (gPhysicalBanks[ii].addr)
		{
			uae_u32	start = (uae_u32) gPhysicalBanks[ii].addr;
			uae_u32	end = start + gPhysicalBanks[ii].size;
			if ((iAddress >= start) && (iAddress + iSize <= end))
			{
				result = true;
				break;
			}
		}
	}

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* DummyBank::GetRealAddress (uaecptr iAddress)
{
	return (uae_u8*) iAddress;
}

// ..................................................................................

void DummyBank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� Register Bank Accessors
// ---------------------------------------------------------------------------
// These functions provide fetch and store access to the emulator's register
// memory.

uae_u32 RegisterBank::GetLong (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGLongRead]++;
	if (iAddress & 2)
		gMemoryAccess[kREGLongRead2]++;

#endif

#if (PREVENT_USER_REGISTER_GET)

	if (gProtectMemory.fRegisterGet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 4, true);
	}

#endif

#if (VALIDATE_REGISTER_GET)

	if (gValidateMemory.fRegisterGet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_REGISTERS)));
		gReadCycles = U64Add(gReadCycles, U64Set(2));
	}
#endif

	return DBReg::fgReadFunctions[iAddress - kRegisterBank_Start] (iAddress, 4);
}

// ..................................................................................

uae_u32 RegisterBank::GetWord (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGWordRead]++;

#endif

#if (PREVENT_USER_REGISTER_GET)

	if (gProtectMemory.fRegisterGet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 2, true);
	}

#endif

#if (VALIDATE_REGISTER_GET)

	if (gValidateMemory.fRegisterGet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_REGISTERS)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	return DBReg::fgReadFunctions[iAddress - kRegisterBank_Start] (iAddress, 2);
}

// ..................................................................................

uae_u32 RegisterBank::GetByte (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGByteRead]++;

#endif

#if (PREVENT_USER_REGISTER_GET)

	if (gProtectMemory.fRegisterGet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 1, true);
	}

#endif

#if (VALIDATE_REGISTER_GET)

	if (gValidateMemory.fRegisterGet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_REGISTERS)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	return DBReg::fgReadFunctions[iAddress - kRegisterBank_Start] (iAddress, 1);
}

// ..................................................................................

void RegisterBank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGLongWrite]++;
	if (iAddress & 2)
		gMemoryAccess[kREGLongWrite2]++;

#endif

#if (PREVENT_USER_REGISTER_SET)

	if (gProtectMemory.fRegisterSet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 4, false);
	}

#endif

#if (VALIDATE_REGISTER_SET)

	if (gValidateMemory.fRegisterSet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, false);
	}

#endif

	DBReg::fgWriteFunctions[iAddress - kRegisterBank_Start] (iAddress, 4, iLongValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_REGISTERS)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(2));
	}
#endif
}

// ..................................................................................

void RegisterBank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGWordWrite]++;

#endif

#if (PREVENT_USER_REGISTER_SET)

	if (gProtectMemory.fRegisterSet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 2, false);
	}

#endif

#if (VALIDATE_REGISTER_SET)

	if (gValidateMemory.fRegisterSet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, false);
	}

#endif

	DBReg::fgWriteFunctions[iAddress - kRegisterBank_Start] (iAddress, 2, iWordValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_REGISTERS)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif
}

// ..................................................................................

void RegisterBank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kREGByteWrite]++;

#endif

#if (PREVENT_USER_REGISTER_SET)

	if (gProtectMemory.fRegisterSet && (m68k_getpc () < kROMBank_Start))
	{
		PreventedAccess (iAddress, 1, false);
	}

#endif

#if (VALIDATE_REGISTER_SET)

	if (gValidateMemory.fRegisterSet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, false);
	}

#endif

	DBReg::fgWriteFunctions[iAddress - kRegisterBank_Start] (iAddress, 1, iByteValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_REGISTERS)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif
}

// ..................................................................................

int RegisterBank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	int	result = 	(iAddress >= kRegisterBank_Start) && 
					(iAddress - kRegisterBank_Start + iSize <= sizeof(g68328Regs));

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* RegisterBank::GetRealAddress (uaecptr iAddress)
{
	uae_u8*	loc = ((uae_u8*) &g68328Regs) + (iAddress - kRegisterBank_Start);

	return loc;
}

// ..................................................................................

void RegisterBank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}

// ..................................................................................

void RegisterBank::PreventedAccess (uaecptr iAddress, long size, bool forRead)
{
	::PreventedAccess (kRegister, forRead);
}



#pragma mark -


void DBReg::SetHandler(ReadFunction read, WriteFunction write, uae_u32 start, int count)
{
	int	index = start - kRegisterBank_Start;
	for (int ii = 0; ii < count; ++ii, ++index)
	{
		DBReg::fgReadFunctions[index] = read;
		DBReg::fgWriteFunctions[index] = write;
	}
}

// ..................................................................................

uae_u32 DBReg::UnsupportedRead(uaecptr address, int size)
{
	RegisterBank::InvalidAccess (address, size, true);

	return 0;
}

// ..................................................................................

void DBReg::UnsupportedWrite(uaecptr address, int size, uae_u32 value)
{
	RegisterBank::InvalidAccess (address, size, false);
}

// ..................................................................................

uae_u32 DBReg::StdRead (uaecptr address, int size)
{
	// The order of these tests is based on the frequency at which
	// the registers are accessed.

	if (size == 1)
		return do_get_mem_byte (RegisterBank::GetRealAddress (address));

	if (size == 2)
		return do_get_mem_word (RegisterBank::GetRealAddress (address));

	return do_get_mem_long (RegisterBank::GetRealAddress (address));
}

// ..................................................................................

void DBReg::StdWrite (uaecptr address, int size, uae_u32 value)
{
	// The order of these tests is based on the frequency at which
	// the registers are accessed.

	if (size == 2)
		do_put_mem_word (RegisterBank::GetRealAddress (address), value);

	else if (size == 4)
		do_put_mem_long (RegisterBank::GetRealAddress (address), value);

	else
		do_put_mem_byte (RegisterBank::GetRealAddress (address), value);
}

// ..................................................................................

void DBReg::NullWrite(uaecptr address, int size, uae_u32 value)
{
	// Do nothing (for read-only registers).
}

// ..................................................................................

uae_u32 DBReg::pllFreqSelRead(uaecptr address, int size)	// Word $202: PLL Frequency Select Register
{
	// Simulate the rising and falling of the CLK32 signal so that functions like
	// HwrPreRAMInit, HwrShutDownPLL, PrvSetPLL, and PrvShutDownPLL won't hang.

	uae_u16	pllFreqSel = READ_REGISTER (pllFreqSel) ^ 0x8000;
	WRITE_REGISTER (pllFreqSel, pllFreqSel);

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::portCDataRead(uaecptr address, int size)	// Byte $411: Port C Data Register
{
	// This makes the power on key work. If the signal is not asserted, the
	// unit will not transition between asleep and awake (cf. HwrSleep, HwrWake).

	uae_u8	portCData = READ_REGISTER (portCData) | hwr328PortCNMI;
	WRITE_REGISTER (portCData, portCData);

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::portMDataRead(uaecptr address, int size)	// Byte $449: Port M Data Register
{
	// Ensure that bit hwrTD1PortMDockIn is set.  If it's clear, HotSync
	// will sync via the modem instead of the serial port.

	uae_u8	portMData = READ_REGISTER (portMData) | hwrTD1PortMDockIn;
	WRITE_REGISTER (portMData, portMData);

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::tmr1StatusRead(uaecptr address, int size)	// Word $60A: Timer 1 Status Register
{
	uae_u16	tmr1Counter = READ_REGISTER (tmr1Counter) + 16;
	uae_u16	tmr1Compare = READ_REGISTER (tmr1Compare);
	uae_u16	tmr1Control = READ_REGISTER (tmr1Control);

	// Increment the timer.

	WRITE_REGISTER (tmr1Counter, tmr1Counter);

	// If the timer has passed the specified value...

	if ( (tmr1Counter - tmr1Compare) < 16 )
	{
		// Set the flag saying the timer timed out.

		uae_u16	tmr1Status = READ_REGISTER (tmr1Status) | hwr328TmrStatusCompare;
		WRITE_REGISTER (tmr1Status, tmr1Status);

		// If it's not a free-running timer, reset it to zero.

		if ( (tmr1Control & hwr328TmrControlFreeRun) == 0 )
			WRITE_REGISTER (tmr1Counter, 0);
	}

	gLastTmr1Status |= READ_REGISTER (tmr1Status);	// remember this guy for later (see DBReg::tmr1StatusWrite())

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::tmr2StatusRead(uaecptr address, int size)	// Word $616: Timer 2 Status Register
{
#if 0	// (Greg doesn't do this for Timer 2...I wonder why)
	uae_u16	tmr2Counter = READ_REGISTER (tmr2Counter) + 16;
	uae_u16	tmr2Compare = READ_REGISTER (tmr2Compare);
	uae_u16	tmr2Control = READ_REGISTER (tmr2Control);

	// Increment the timer.

	WRITE_REGISTER (tmr2Counter, tmr2Counter);

	// If the timer has passed the specified value...

	if ( (tmr2Counter - tmr2Compare) < 16 )
	{
		// Set the flag saying the timer timed out.

		uae_u16	tmr2Status = READ_REGISTER (tmr1Status) | hwr328TmrStatusCompare;
		WRITE_REGISTER (tmr2Status, tmr2Status);

		// If it's not a free-running timer, reset it to zero.

		if ( (tmr2Control & hwr328TmrControlFreeRun) == 0 )
			WRITE_REGISTER (tmr2Counter, 0);
	}
#endif

	gLastTmr2Status |= READ_REGISTER (tmr2Status);	// remember this guy for later (see DBReg::tmr2StatusWrite())

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::uReceiveRead(uaecptr address, int size)	// Word $904: Uart Receive Register
{
	// If we're reading the data along with the status bits,
	// clear some flags to indicate that a buffered byte has
	// been read.

	if (size == 2)
	{
		// Clear the "we have data" bit (it was set in Hardware::Cycle if
		// we had data in the serial input queue).

		uae_u16	uReceive = READ_REGISTER (uReceive) & ~hwr328UReceiveDataRdy;
		WRITE_REGISTER (uReceive, uReceive);

		// Clear the interrupt that probably got us here in the first place.

		uae_u16	intPendingLo = READ_REGISTER (intPendingLo) & ~hwr328IntLoUART;
		WRITE_REGISTER (intPendingLo, intPendingLo);

		// Respond to the new interrupt state.

		Registers::UpdateInterrupts ();
	}

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::uTransmitRead(uaecptr address, int size)	// Word $906: Uart Transmit Register
{
	uae_u16	uTransmit = READ_REGISTER (uTransmit);

	// Update the serial port status bits.

	if (Platform::OutgoingSerialBytes () == 0)
		uTransmit |= hwr328UTransmitFIFOEmpty;		// 8 byte FIFO buffer is empty
	else
		uTransmit &= ~hwr328UTransmitFIFOEmpty;

	if (Platform::OutgoingSerialBytes () < 4)
		uTransmit |= hwr328UTransmitFIFOHalf;		// 8 byte FIFO buffer is less than 1/2 full
	else
		uTransmit &= ~hwr328UTransmitFIFOHalf;

	if (Platform::OutgoingSerialBytes () < 8)		// 8 byte FIFO buffer has room for at least one byte
		uTransmit |= hwr328UTransmitTxAvail;
	else
		uTransmit &= ~hwr328UTransmitTxAvail;

	// If CTS is being used, a byte can only be sent if CTS is asserted. On the
	// 68328, CTS is asserted when hwr328UTransmitCTSStatus is 0.

	// !!! We may want to see if the following is better for
	// setting the hwr328UTransmitCTSStatus bit.

//	if (((uTransmit & hwr328UTransmitIgnoreCTS) != 0) || (Platform::OutgoingSerialBytes () == 0))
//		uTransmit &= ~hwr328UTransmitCTSStatus;		// CTS when IgnoreCTS is set or when buffer is empty.
//	else
//		uTransmit |= hwr328UTransmitCTSStatus;

	if (Platform::OutgoingSerialBytes () != 0)
		uTransmit |= hwr328UTransmitCTSStatus;
	else
		uTransmit &= ~hwr328UTransmitCTSStatus;		// CTS when buffer is empty

	WRITE_REGISTER (uTransmit, uTransmit);

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

uae_u32 DBReg::rtcHourMinSecRead(uaecptr address, int size)	// DWord $B00: RTC Hours, Minutes, Seconds Register
{
	// Get the desktop machine's time.

	long	hour, min, sec;
	Platform::GetTime (&hour, &min, &sec);

	// Update the register.

	WRITE_REGISTER (rtcHourMinSec, (hour << hwr328RTCHourMinSecHoursOffset)
								| (min << hwr328RTCHourMinSecMinutesOffset)
								| (sec << hwr328RTCHourMinSecSecondsOffset));

	// Finish up by doing a standard read.

	return DBReg::StdRead (address, size);
}

// ..................................................................................

void DBReg::scrWrite(uaecptr address, int size, uae_u32 value)	// Byte $000: System Control Register
{
	// Writing a 1 to any of the upper 3 bits clears that bit in the register.
	// Writing a 0 to those bits should have no effect.  All other bits should
	// get merged in "as is".

	uae_u8	scr = READ_REGISTER (scr);

	scr = (scr & ~(value & 0xE0)) | (value & 0x1F);

	WRITE_REGISTER (scr, scr);
}

// ..................................................................................

void DBReg::csASelect1Write(uaecptr address, int size, uae_u32 value)	// DWord $114: Group A Chip Select 1 Register
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Check its new state and update our ram-protect flag.

	gProtectMemory.fSRAMSet = (READ_REGISTER (csASelect1) & 0x0008) != 0;
}

// ..................................................................................

void DBReg::intMaskHiWrite(uaecptr address, int size, uae_u32 value)	// Word $304: Interrupt Mask Register/HIGH word
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Respond to the new interrupt state.

	Registers::UpdateInterrupts ();
}

// ..................................................................................

void DBReg::intMaskLoWrite(uaecptr address, int size, uae_u32 value)	// Word $306: Interrupt Mask Register/LOW word
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Respond to the new interrupt state.

	Registers::UpdateInterrupts ();
}

// ..................................................................................

void DBReg::intStatusHiWrite(uaecptr address, int size, uae_u32 value)	// Word $30C: Interrupt Status Register/HIGH word
{
	// IRQ1, IRQ2, IRQ3, IRQ6 and IRQ7 are cleared by writing to their
	// respective status bits.  We handle those there. Since there are
	// no interrupt status bits like this in intStatusLo, we don't need
	// a handler for that register; we only handle intStatusHi.

	// Even though this is a 16-bit register as defined by the Palm headers,
	// it's a 32-bit register according to Dragonball docs, and is in fact
	// accessed that way in the kernal files (cf. HwrIRQ4Handler). In those
	// cases, we're still only interested in access to the IRQ# bits, so we
	// can turn 4-byte accesses into 2-byte accesses.

	if (size == 4)
		value >>= 16;

	// Take into account the possibility of 1-byte accesses, too. If we're
	// accessing the upper byte, just return. If we're accessing the lower
	// byte, we can treat it as a 2-byte access.

	else if (size == 1 && address == addressof (intStatusHi))
		return;

	// Now we can treat the rest of this function as a word-write to intStatusHi.

	uae_u16	intPendingHi = READ_REGISTER (intPendingHi);

	//	For each interrupt:
	//		If we're writing to that interrupt's status bit and its edge bit is set:
	//			- clear the interrupt's pending bit
	//			- respond to the new interrupt state.

	#undef CLEAR_PENDING_INTERRUPT
	#define CLEAR_PENDING_INTERRUPT(edge, irq)							\
		if ( (READ_REGISTER (intControl) & edge) && (value & (irq)) )	\
		{																\
			intPendingHi &= ~(irq);										\
		}

	CLEAR_PENDING_INTERRUPT (hwr328IntCtlEdge1, hwr328IntHiIRQ1);
	CLEAR_PENDING_INTERRUPT (hwr328IntCtlEdge2, hwr328IntHiIRQ2);
	CLEAR_PENDING_INTERRUPT (hwr328IntCtlEdge3, hwr328IntHiIRQ3);
	CLEAR_PENDING_INTERRUPT (hwr328IntCtlEdge6, hwr328IntHiIRQ6);

	// IRQ7 is not edge-programmable, so clear it if we're merely writing to it.

	if (value & hwr328IntHiNMI)
	{
		intPendingHi &= ~(hwr328IntHiNMI);
	}

	// If we're emulating the user pressing the hotsync button, make sure the
	// interrupt stays asserted.  (!!! Should we use the same technique for
	// other buttons, too?  It doesn't seem to be needed right now, but doing
	// that may more closely mirror the hardware.)

	if (Hardware::fgHotSyncButtonDown)
	{
		intPendingHi |= hwr328IntHiIRQ1;
	}
	else
	{
		intPendingHi &= ~hwr328IntHiIRQ1;
	}

	WRITE_REGISTER (intPendingHi, intPendingHi);
	Registers::UpdateInterrupts ();
}

// ..................................................................................

void DBReg::portDDataWrite(uaecptr address, int size, uae_u32 value)	// Byte $419: Port D Data Register
{
	// Clear the interrupt bits that are having a 1 written to them.

	gPortDEdge &= ~value;

	// Set the new interrupt state.

	Registers::UpdatePortDInterrupts ();
}

// ..................................................................................

void DBReg::portDIntReqEnWrite(uaecptr address, int size, uae_u32 value)	// Byte $41D: Port D Interrupt Request Enable
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Set the new interrupt state.

	Registers::UpdatePortDInterrupts ();
}

// ..................................................................................

void DBReg::tmr1StatusWrite(uaecptr address, int size, uae_u32 value)	// Word $60A: Timer 1 Status Register
{
	assert (size == 2);	// This function's a hell of a lot easier to write if
						// we assume only full-register access.

	// Get the current value.

	uae_u16	tmr1Status = READ_REGISTER (tmr1Status);

	// If the user had previously read the status bits while they
	// were set, then it's OK for them to be clear now.  Otherwise,
	// we have to merge any set status bits back in.

	tmr1Status &= value | ~gLastTmr1Status;	// gLastTmr1Status was set in DBReg::tmr1StatusRead()

	WRITE_REGISTER (tmr1Status, tmr1Status);

	gLastTmr1Status = 0;
	if ( (tmr1Status & hwr328TmrStatusCompare) == 0 )
	{
		uae_u16	intPendingHi = READ_REGISTER (intPendingHi) & ~hwr328IntHiTimer1;
		WRITE_REGISTER (intPendingHi, intPendingHi);

		// Respond to the new interrupt state.

		Registers::UpdateInterrupts ();
	}
}

// ..................................................................................

void DBReg::tmr2StatusWrite(uaecptr address, int size, uae_u32 value)	// Word $616: Timer 2 Status Register
{
	assert (size == 2);	// This function's a hell of a lot easier to write if
						// we assume only full-register access.

	// Get the current value.

	uae_u16	tmr2Status = READ_REGISTER (tmr2Status);

	// If the user had previously read the status bits while they
	// were set, then it's OK for them to be clear now.  Otherwise,
	// we have to merge any set status bits back in.

	tmr2Status &= value | ~gLastTmr2Status;	// gLastTmr2Status was set in DBReg::tmr2StatusRead()

	WRITE_REGISTER (tmr2Status, tmr2Status);

	gLastTmr2Status = 0;
	if ( (tmr2Status & hwr328TmrStatusCompare) == 0 )
	{
		uae_u16	intPendingLo = READ_REGISTER (intPendingLo) & ~hwr328IntLoTimer2;
		WRITE_REGISTER (intPendingLo, intPendingLo);

		// Respond to the new interrupt state.

		Registers::UpdateInterrupts ();
	}
}

// ..................................................................................

void DBReg::wdCounterWrite(uaecptr address, int size, uae_u32 value)	// Word $61C: Watchdog Counter
{
	// Always set it to zero (a write to this register always resets it).

	WRITE_REGISTER (wdCounter, 0);
}

// ..................................................................................

void DBReg::spiMasterControlWrite(uaecptr address, int size, uae_u32 value)	// Word $802: SPI Master Control Register
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Get the current value.

	uae_u16	spiMasterControl = READ_REGISTER (spiMasterControl);

	// Check to see if data exchange and interrupts are enabled.

	#define BIT_MASK (hwr328SPIMControlExchange | hwr328SPIMControlIntEnable)
	if ((spiMasterControl & BIT_MASK) == BIT_MASK)
	{
		// If so, assert the interrupt and clear the exchange bit.

		spiMasterControl |= hwr328SPIMControlIntStatus;
		spiMasterControl &= ~hwr328SPIMControlExchange;

		WRITE_REGISTER (spiMasterControl, spiMasterControl);

		// If we wanted digitizer data, load it into the SPIM data register.

		switch (READ_REGISTER (portFData) & hwrTD1PortFPanelMask)
		{
			case (hwrTD1PortFPanelCfgXMeas):
				WRITE_REGISTER (spiMasterData, (0xFF - gPen_HorzLocation) * 2);
				break;

			case (hwrTD1PortFPanelCfgYMeas):
				WRITE_REGISTER (spiMasterData, (0xFF - gPen_VertLocation) * 2);
				break;
		}
	}
}

// ..................................................................................

void DBReg::uBaudWrite(uaecptr address, int size, uae_u32 value)
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Change the baud rate.

	Platform::SetBaud (READ_REGISTER (uBaud));
}

// ..................................................................................

void DBReg::uTransmitWrite(uaecptr address, int size, uae_u32 value)
{
	uae_u16	origUTransmit = READ_REGISTER (uTransmit);

	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Respond to any CTS change.

	uae_u16	uTransmit = READ_REGISTER (uTransmit);

	if (((uTransmit ^ origUTransmit) & hwr328UTransmitIgnoreCTS) != 0)
	{
		Platform::SetCTS (uTransmit);
	}

	// See if we're in loopback mode. If so, send the data to our
	// serial receive port.

	Word	uMisc = READ_REGISTER (uMisc);

	if ((uMisc & hwr328UMiscLoopback) != 0)
	{
		uae_u16	uTransmit = READ_REGISTER (uTransmit);
		uae_u16	uReceive = READ_REGISTER (uReceive);

		uTransmit &= hwr328UTransmitData;	// Get JUST the data byte
		uReceive &= ~hwr328UReceiveData;	// Clear out where the data byte goes
		uReceive |= uTransmit;				// Merge in the data byte
		uReceive |= hwr328UReceiveDataRdy;	// Set the "data ready" bit.

		WRITE_REGISTER (uReceive, uReceive);

		// If "receive data" interrupt is enabled, signal the interrupt.

		if ((READ_REGISTER (uControl) & hwr328UControlRxRdyEn) != 0)
		{
			WRITE_REGISTER (intPendingLo, READ_REGISTER (intPendingLo) | hwr328IntLoUART);

			// Respond to the new interrupt state.

			Registers::UpdateInterrupts ();
		}
	}

	// If we're not in loopback mode, just send it out the platform serial port.

	else
	{
		Platform::WriteSerialByte (READ_REGISTER (uTransmit) & hwr328UTransmitData);
	}

}

// ..................................................................................

void DBReg::lcdRegisterWrite(uaecptr address, int size, uae_u32 value)
{
	// First, get the old value in case we need to see what changed.

	uae_u32	oldValue = DBReg::StdRead (address, size);

	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Note what changed.

	if (address == addressof (lcdScreenWidth))
	{
		Screen::RecordChange (kScreen_ContentsChanged | kScreen_WidthChanged);

		gScreenWidth = value;
		gScreenBufferEnd = gScreenBufferStart + gScreenWidth * gScreenHeight * gScreenDepth / 8;
	}
	else if (address == addressof (lcdScreenHeight))
	{
		Screen::RecordChange (kScreen_ContentsChanged | kScreen_HeightChanged);

		gScreenHeight = value;
		gScreenBufferEnd = gScreenBufferStart + gScreenWidth * gScreenHeight * gScreenDepth / 8;
	}
	else if (address == addressof (lcdPanelControl))
	{
		if (((value ^ oldValue) & hwr328LcdPanelControlGrayScale) != 0)
		{
			Screen::RecordChange (kScreen_ContentsChanged | kScreen_DepthChanged);

			gScreenDepth = ((value & hwr328LcdPanelControlGrayScale) != 0) ? 2 : 1;
			gScreenBufferEnd = gScreenBufferStart + gScreenWidth * gScreenHeight * gScreenDepth / 8;
		}
	}
	else if (address == addressof (lcdStartAddr))
	{
		Screen::RecordChange (kScreen_ContentsChanged);

		gScreenBufferStart = value;
		gScreenBufferEnd = gScreenBufferStart + gScreenWidth * gScreenHeight * gScreenDepth / 8;
	}
	else if (address == addressof (portFData))
	{
		if (((value ^ oldValue) & hwrTD1PortFLCDEnableOn) != 0)
			Screen::RecordChange (kScreen_LCDChanged);
	}
	else if (address == addressof (portGData))
	{
		if (((value ^ oldValue) & hwrTD1PortGBacklightOn) != 0)
			Screen::RecordChange (kScreen_BacklightChanged);
	}

#if (PREVENT_USER_SCREEN_GET || PREVENT_USER_SCREEN_SET)

	// Invalidate the range used to prevent user access.

	DRAMBank::InvalidateScreenRange ();

#endif
}

// ..................................................................................

void DBReg::rtcControlWrite(uaecptr address, int size, uae_u32 value)
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Respond to the new interrupt state.

	Registers::UpdateRTCInterrupts ();
}

// ..................................................................................

void DBReg::rtcIntStatusWrite(uaecptr address, int size, uae_u32 value)
{
	// Status bits are cleared by writing ones to them.

	// If we're doing a byte-write to the upper byte, shift the byte
	// so that we can treat the operation as a word write.  If we're
	// doing a byte-write to the lower byte, this extension will happen
	// automatically.

	if (address == addressof (rtcIntStatus) && size == 1)
		value <<= 8;

	// Get the current value.

	uae_u16	rtcIntStatus = READ_REGISTER (rtcIntStatus);

	// Clear the requested bits.

	rtcIntStatus &= ~value;

	// Update the register.

	WRITE_REGISTER (rtcIntStatus, rtcIntStatus);

	// Respond to the new interrupt state.

	Registers::UpdateRTCInterrupts ();
}

// ..................................................................................

void DBReg::rtcIntEnableWrite(uaecptr address, int size, uae_u32 value)
{
	// Do a standard update of the register.

	DBReg::StdWrite (address, size, value);

	// Respond to the new interrupt state.

	Registers::UpdateRTCInterrupts ();
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� DRAM Bank Accessors
// ---------------------------------------------------------------------------
// These functions provide fetch and store access to the emulator's random
// access memory.

/*
// !!! TBD Use these to determine heap size(s):

	UInt		MemNumCards(void)
	UInt		MemNumHeaps(UInt cardNo)
	UInt		MemHeapID(UInt cardNo, UInt heapNo)
	Boolean		MemHeapDynamic(UInt heapID)
	VoidPtr		MemHeapPtr(UInt heapID)
	ULong		MemHeapSize(UInt heapID)
*/

uae_u32 DRAMBank::GetLong (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMLongRead]++;
	if (iAddress & 2)
		gMemoryAccess[kDRAMLongRead2]++;

#endif

#if (PREVENT_USER_LOWMEM_GET)

	if (gProtectMemory.fLowMemGet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 4, true);
	}

#endif

#if (PREVENT_USER_GLOBAL_GET)

	if (gProtectMemory.fGlobalGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 4, true);
	}

#endif

#if (PREVENT_USER_SCREEN_GET)

	if (gProtectMemory.fScreenGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 4, true);
	}

#endif

#if (VALIDATE_DRAM_GET)

	if (gValidateMemory.fDRAMGet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_DRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(2));
	}
#endif

	return do_get_mem_long (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

uae_u32 DRAMBank::GetWord (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMWordRead]++;

#endif

#if (PREVENT_USER_LOWMEM_GET)

	if (gProtectMemory.fLowMemGet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 2, true);
	}

#endif

#if (PREVENT_USER_GLOBAL_GET)

	if (gProtectMemory.fGlobalGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 2, true);
	}

#endif

#if (PREVENT_USER_SCREEN_GET)

	if (gProtectMemory.fScreenGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 2, true);
	}

#endif

#if (VALIDATE_DRAM_GET)

	if (gValidateMemory.fDRAMGet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_DRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	return do_get_mem_word (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

uae_u32 DRAMBank::GetByte (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMByteRead]++;

#endif

#if (PREVENT_USER_LOWMEM_GET)

	if (gProtectMemory.fLowMemGet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 1, true);
	}

#endif

#if (PREVENT_USER_GLOBAL_GET)

	if (gProtectMemory.fGlobalGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 1, true);
	}

#endif

#if (PREVENT_USER_SCREEN_GET)

	if (gProtectMemory.fScreenGet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 1, true);
	}

#endif

#if (VALIDATE_DRAM_GET)

	if (gValidateMemory.fDRAMGet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_DRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	return do_get_mem_byte (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

// See notes for Screen_GetBits for why this code is commented out.

//static void MaybeMarkScreenDirty (uaecptr iAddress)
//{
//	if (iAddress >= gScreenBufferStart && iAddress < gScreenBufferEnd)
//	{
//		Screen_RecordChange (kScreen_ContentsChanged);
//	}
//}

void DRAMBank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMLongWrite]++;
	if (iAddress & 2)
		gMemoryAccess[kDRAMLongWrite2]++;

#endif

#if (PREVENT_SYSTEM_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () >= kROMBank_Start) &&
		!gSysDozing && !gSysSleeping && gUIInitialized &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 4, false);
	}

#endif

#if (PREVENT_USER_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 4, false);
	}

#endif

#if (PREVENT_USER_GLOBAL_SET)

	if (gProtectMemory.fGlobalSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 4, false);
	}

#endif

#if (PREVENT_USER_SCREEN_SET)

	if (gProtectMemory.fScreenSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 4, false);
	}

#endif

#if (VALIDATE_DRAM_SET)

	if (gValidateMemory.fDRAMSet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, false);
	}

#endif

//	if ((Screen_GetChange() & kScreen_ContentsChanged) == 0)
//	{
//		MaybeMarkScreenDirty (iAddress);
//	}

	do_put_mem_long (((char*) gRAM_Memory) + iAddress, iLongValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_DRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(2));
	}
#endif
}

// ..................................................................................

void DRAMBank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMWordWrite]++;

#endif

#if (PREVENT_SYSTEM_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () >= kROMBank_Start) &&
		!gSysDozing && !gSysSleeping && gUIInitialized &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 4, false);
	}

#endif

#if (PREVENT_USER_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 2, false);
	}

#endif

#if (PREVENT_USER_GLOBAL_SET)

	if (gProtectMemory.fGlobalSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 2, false);
	}

#endif

#if (PREVENT_USER_SCREEN_SET)

	if (gProtectMemory.fScreenSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 2, false);
	}

#endif

#if (VALIDATE_DRAM_SET)

	if (gValidateMemory.fDRAMSet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, false);
	}

#endif

//	if ((Screen_GetChange() & kScreen_ContentsChanged) == 0)
//	{
//		MaybeMarkScreenDirty (iAddress);
//	}

	do_put_mem_word (((char*) gRAM_Memory) + iAddress, iWordValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_DRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif
}

// ..................................................................................

void DRAMBank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kDRAMByteWrite]++;

#endif

#if (PREVENT_SYSTEM_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () >= kROMBank_Start) &&
		!gSysDozing && !gSysSleeping && gUIInitialized &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 4, false);
	}

#endif

#if (PREVENT_USER_LOWMEM_SET)

	if (gProtectMemory.fLowMemSet &&
		(m68k_getpc () < kROMBank_Start) &&
		(iAddress < offsetof(LowMemHdrType, globals)))
	{
		PreventedLowMemAccess (iAddress, 1, false);
	}

#endif

#if (PREVENT_USER_GLOBAL_SET)

	if (gProtectMemory.fGlobalSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgGlobalEnd == NULL)
			CalcGlobalEnd ();

		if (iAddress >= offsetof(LowMemHdrType, globals) && iAddress < fgGlobalEnd)
			PreventedGlobalAccess (iAddress, 1, false);
	}

#endif

#if (PREVENT_USER_SCREEN_SET)

	if (gProtectMemory.fScreenSet && (m68k_getpc () < kROMBank_Start))
	{
		if (fgScreenStart == NULL)
			CalcScreenRange ();
		
		if (iAddress >= fgScreenStart && iAddress < fgScreenEnd)
			PreventedScreenAccess (iAddress, 1, false);
	}

#endif

#if (VALIDATE_DRAM_SET)

	if (gValidateMemory.fDRAMSet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, false);
	}

#endif

//	if ((Screen_GetChange() & kScreen_ContentsChanged) == 0)
//	{
//		MaybeMarkScreenDirty (iAddress);
//	}

	do_put_mem_byte (((char*) gRAM_Memory) + iAddress, iByteValue);

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_DRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif
}

// ..................................................................................

int DRAMBank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	int	result = (iAddress + iSize) <= gRAMBank_Size;

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* DRAMBank::GetRealAddress (uaecptr iAddress)
{
	return (uae_u8*) &(((char*) gRAM_Memory)[iAddress]);
}

// ..................................................................................

void DRAMBank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}

// ..................................................................................

void DRAMBank::PreventedLowMemAccess (uaecptr iAddress, long size, bool forRead)
{
	::PreventedAccess (kLowMem, forRead);
}

// ..................................................................................

void DRAMBank::PreventedGlobalAccess (uaecptr iAddress, long size, bool forRead)
{
	::PreventedAccess (kGlobal, forRead);
}

// ..................................................................................

void DRAMBank::PreventedScreenAccess (uaecptr iAddress, long size, bool forRead)
{
	::PreventedAccess (kScreen, forRead);
}

// ..................................................................................

void DRAMBank::InvalidateScreenRange (void)
{
	fgScreenStart = NULL;
	fgScreenEnd = NULL;
}

// ..................................................................................

void DRAMBank::CalcGlobalEnd (void)
{
	// Turning off memory checking is VERY important right here, as the
	// LowMem_GetGlobal fetches memory by calling back into the appropriate
	// DRAMBank::GetFoo function, which would otherwise lead us right back
	// to here.

	CEnableFullAccess	munge;	// Remove blocks on memory access.

	fgGlobalEnd = LowMem_GetGlobal (sysDispatchTableP) + 
				LowMem_GetGlobal (sysDispatchTableSize) * (sizeof (void*));
}

// ..................................................................................

void DRAMBank::CalcScreenRange (void)
{
	CEnableFullAccess	munge;	// Remove blocks on memory access.

	fgScreenStart = READ_REGISTER (lcdStartAddr);

	int	width	= Screen::GetWidth ();
	int	height	= Screen::GetHeight ();
	int	depth	= Screen::GetDepth ();

	fgScreenEnd = fgScreenStart + width * height * depth / 8;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� SRAM Bank Accessors
// ---------------------------------------------------------------------------
// These functions provide fetch and store access to the emulator's random
// access memory.

uae_u32 SRAMBank::GetLong (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMLongRead]++;
	if (iAddress & 2)
		gMemoryAccess[kSRAMLongRead2]++;

#endif

#if (PREVENT_USER_SRAM_GET)

	if (gProtectMemory.fSRAMGet)
	{
		ProtectedAccess (iAddress, 4, true);
	}

#endif

#if (VALIDATE_SRAM_GET)

	if (gValidateMemory.fSRAMGet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_SRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(2));
	}
#endif

	// Strip the uppermost bit of the address.
	iAddress &= (gRAMBank_Size - 1);

	return do_get_mem_long (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

uae_u32 SRAMBank::GetWord (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMWordRead]++;

#endif

#if (PREVENT_USER_SRAM_GET)

	if (gProtectMemory.fSRAMGet)
	{
		ProtectedAccess (iAddress, 2, true);
	}

#endif

#if (VALIDATE_SRAM_GET)

	if (gValidateMemory.fSRAMGet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_SRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	return do_get_mem_word (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

uae_u32 SRAMBank::GetByte (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMByteRead]++;

#endif

#if (PREVENT_USER_SRAM_GET)

	if (gProtectMemory.fSRAMGet)
	{
		ProtectedAccess (iAddress, 1, true);
	}

#endif

#if (VALIDATE_SRAM_GET)

	if (gValidateMemory.fSRAMGet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_SRAM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	// Strip the uppermost bit of the address.
	iAddress &= (gRAMBank_Size - 1);

	return do_get_mem_byte (((char*) gRAM_Memory) + iAddress);
}

// ..................................................................................

void SRAMBank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMLongWrite]++;
	if (iAddress & 2)
		gMemoryAccess[kSRAMLongWrite2]++;

#endif

#if (PREVENT_USER_SRAM_SET)

	if (gProtectMemory.fSRAMSet)
	{
		ProtectedAccess (iAddress, 4, false);
	}

#endif

#if (VALIDATE_SRAM_SET)

	if (gValidateMemory.fSRAMSet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, false);
	}

#endif

	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	do_put_mem_long (((char*) gRAM_Memory) + iAddress, iLongValue);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_SRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(2));
	}
#endif

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();
}

// ..................................................................................

void SRAMBank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMWordWrite]++;

#endif

#if (PREVENT_USER_SRAM_SET)

	if (gProtectMemory.fSRAMSet)
	{
		ProtectedAccess (iAddress, 2, false);
	}

#endif

#if (VALIDATE_SRAM_SET)

	if (gValidateMemory.fSRAMSet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, false);
	}

#endif

	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	do_put_mem_word (((char*) gRAM_Memory) + iAddress, iWordValue);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_SRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();
}

// ..................................................................................

void SRAMBank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kSRAMByteWrite]++;

#endif

#if (PREVENT_USER_SRAM_SET)

	if (gProtectMemory.fSRAMSet)
	{
		ProtectedAccess (iAddress, 1, false);
	}

#endif

#if (VALIDATE_SRAM_SET)

	if (gValidateMemory.fSRAMSet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, false);
	}

#endif

	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	do_put_mem_byte (((char*) gRAM_Memory) + iAddress, iByteValue);

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_SRAM)));
		gWriteCycles = U64Add(gWriteCycles, U64Set(1));
	}
#endif

	// See if any interesting memory locations have changed.  If so,
	// CheckStepSpy will change gBreakReason, which we'll check later.

	Debug::CheckStepSpy ();
}

// ..................................................................................

int SRAMBank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	int	result = false;

	// Check for a valid RAM access.

	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	result = (iAddress + iSize) <= gRAMBank_Size;

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* SRAMBank::GetRealAddress (uaecptr iAddress)
{
	// Strip the uppermost bit of the address.

	iAddress &= (gRAMBank_Size - 1);

	return (uae_u8*) &(((char*) gRAM_Memory)[iAddress]);
}

// ..................................................................................

void SRAMBank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}

// ..................................................................................

void SRAMBank::ProtectedAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� ROM Bank Accessors
// ---------------------------------------------------------------------------
// These functions provide fetch and store access to the emulator's read only
// memory.

uae_u32 ROMBank::GetLong (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMLongRead]++;
	if (iAddress & 2)
		gMemoryAccess[kROMLongRead2]++;

#endif

#if (VALIDATE_ROM_GET)

	if (gValidateMemory.fROMGet && !ValidAddress (iAddress, 4))
	{
		InvalidAccess (iAddress, 4, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(2*(4 + WAITSTATES_ROM)));
		gReadCycles = U64Add(gReadCycles, U64Set(2));
	}
#endif

	// Make the address a zero offset into ROM memory.
	iAddress -= kROMBank_Start & (gROMBank_Size - 1);

	// Strip the uppermost bit of the address.
	iAddress &= gROMBank_Size - 1;

	return do_get_mem_long (gROM_Memory + iAddress);
}

// ..................................................................................

uae_u32 ROMBank::GetWord (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMWordRead]++;

#endif

#if (VALIDATE_ROM_GET)

	if (gValidateMemory.fROMGet && !ValidAddress (iAddress, 2))
	{
		InvalidAccess (iAddress, 2, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_ROM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	// Make the address a zero offset into ROM memory.
	iAddress -= kROMBank_Start & (gROMBank_Size - 1);

	// Strip the uppermost bit of the address.
	iAddress &= gROMBank_Size - 1;

	return do_get_mem_word (gROM_Memory + iAddress);
}

// ..................................................................................

uae_u32 ROMBank::GetByte (uaecptr iAddress)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMByteRead]++;

#endif

#if (VALIDATE_ROM_GET)

	if (gValidateMemory.fROMGet && !ValidAddress (iAddress, 1))
	{
		InvalidAccess (iAddress, 1, true);
	}

#endif

#if HAS_PROFILING
	if (gProfilingEnabled && gProfilingCounted)
	{
		gClockCycles = U64Add(gClockCycles, U64Set(1*(4 + WAITSTATES_ROM)));
		gReadCycles = U64Add(gReadCycles, U64Set(1));
	}
#endif

	// Make the address a zero offset into ROM memory.
	iAddress -= kROMBank_Start & (gROMBank_Size - 1);

	// Strip the uppermost bit of the address.
	iAddress &= gROMBank_Size - 1;

	return do_get_mem_byte (gROM_Memory + iAddress);
}

// ..................................................................................

void ROMBank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMLongWrite]++;
	if (iAddress & 2)
		gMemoryAccess[kROMLongWrite2]++;

#endif

#if (VALIDATE_ROM_SET)

	if (gValidateMemory.fROMSet)
	{
		InvalidAccess (iAddress, 4, false);
	}

#endif

	iAddress &= (gROMBank_Size - 1);

	do_put_mem_long (((char*) gROM_Memory) + iAddress, iLongValue);

#if HAS_PROFILING
	// writing to ROM?? don't know what to make of this
	if (gProfilingEnabled && gProfilingCounted)
	{
		// Debugger();
	}
#endif
}

// ..................................................................................

void ROMBank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMWordWrite]++;

#endif

	assert (ValidAddress (iAddress, 2));

#if (VALIDATE_ROM_SET)

	if (gValidateMemory.fROMSet)
	{
		InvalidAccess (iAddress, 2, false);
	}

#endif

	iAddress &= (gROMBank_Size - 1);

	do_put_mem_word (((char*) gROM_Memory) + iAddress, iWordValue);

#if HAS_PROFILING
	// writing to ROM?? don't know what to make of this
	if (gProfilingEnabled && gProfilingCounted)
	{
		// Debugger();
	}
#endif
}

// ..................................................................................

void ROMBank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
#if PROFILE_MEMORY

	gMemoryAccess[kROMByteWrite]++;

#endif

	assert (ValidAddress (iAddress, 1));
	
#if (VALIDATE_ROM_SET)

	if (gValidateMemory.fROMSet)
	{
		InvalidAccess (iAddress, 1, false);
	}

#endif

	iAddress &= (gROMBank_Size - 1);

	do_put_mem_byte (((char*) gROM_Memory) + iAddress, iByteValue);

#if HAS_PROFILING
	// writing to ROM?? don't know what to make of this
	if (gProfilingEnabled && gProfilingCounted)
	{
		// Debugger();
	}
#endif
}

// ..................................................................................

int ROMBank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	// Make the address a zero offset into ROM memory.

	iAddress -= kROMBank_Start & (gROMBank_Size - 1);

	// Strip the uppermost bit of the address.

	iAddress &= gROMBank_Size - 1;

	int	result = (iAddress + iSize) <= gROMBank_Size;

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* ROMBank::GetRealAddress (uaecptr iAddress)
{
	// Make the address a zero offset into ROM memory.

	iAddress -= kROMBank_Start & (gROMBank_Size - 1);

	// Strip the uppermost bit of the address.

	iAddress &= gROMBank_Size - 1;

	return &(((uae_u8*) gROM_Memory)[iAddress]);
}

// ..................................................................................

void ROMBank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� M68681 Bank Accessors
// ---------------------------------------------------------------------------
// These functions provide fetch and store access to the emulated M68681
// serial port.

uae_u32 M68681Bank::GetLong (uaecptr iAddress)
{
	InvalidAccess (iAddress, 4, true);

	return 0;
}

// ..................................................................................

uae_u32 M68681Bank::GetWord (uaecptr iAddress)
{
	InvalidAccess (iAddress, 2, true);

	return 0;
}

// ..................................................................................

uae_u32 M68681Bank::GetByte (uaecptr iAddress)
{
	return ((uae_u8*) &fgDuart)[iAddress - k68681Bank_Start];
}

// ..................................................................................

void M68681Bank::SetLong (uaecptr iAddress, uae_u32 iLongValue)
{
	InvalidAccess (iAddress, 4, false);
}

// ..................................................................................

void M68681Bank::SetWord (uaecptr iAddress, uae_u32 iWordValue)
{
	InvalidAccess (iAddress, 2, false);
}

// ..................................................................................

void M68681Bank::SetByte (uaecptr iAddress, uae_u32 iByteValue)
{
	((uae_u8*) &fgDuart)[iAddress - k68681Bank_Start] = iByteValue;
}

// ..................................................................................

int M68681Bank::ValidAddress (uaecptr iAddress, uae_u32 iSize)
{
	const uaecptr	offset = iAddress - k68681Bank_Start;

	int	result = (offset >= 0) && (offset < sizeof (fgDuart));

	assert (result);

	return result;
}

// ..................................................................................

uae_u8* M68681Bank::GetRealAddress (uaecptr iAddress)
{
	return &(((uae_u8*) &fgDuart)[iAddress - k68681Bank_Start]);
}

// ..................................................................................

void M68681Bank::InvalidAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}

// ..................................................................................

void M68681Bank::PreventedAccess (uaecptr iAddress, long size, bool forRead)
{
	Software::BusError ();
}



// ---------------------------------------------------------------------------
//		� PreventedAccess
// ---------------------------------------------------------------------------

static void PreventedAccess (int kind, bool forRead)
{
	// See if we've already issued this warning for this application.
	// If so, just leave.

	if ((gPreventAccessNotificationFlags & kind) != 0)
	{
		return;
	}

	// Remember that we've issued a warning for this application.

	gPreventAccessNotificationFlags |= kind;

	// Generate the warning message.

	short	formatIndex;
	
	switch (kind)
	{
		case kLowMem:	formatIndex = kStringLowMemory;			break;
		case kGlobal:	formatIndex = kStringGlobalMemory;		break;
		case kScreen:	formatIndex = kStringScreenMemory;		break;
		case kRegister:	formatIndex = kStringRegisterMemory;	break;
	}

	char*	msg	= Platform::GetString (formatIndex);
	char*	appName	= Utility::GetAppName ();

	char*	operation1;
	char*	operation2;
	if (forRead)
	{
		operation1 = Platform::GetString (kStringRead);
		operation2 = Platform::GetString (kStringFrom);
	}
	else
	{
		operation1 = Platform::GetString (kStringWritten);
		operation2 = Platform::GetString (kStringTo);
	}

	msg = Utility::ReplaceParameter (msg, "%application", appName);
	msg = Utility::ReplaceParameter (msg, "%operation", operation1);
	msg = Utility::ReplaceParameter (msg, "%direction", operation2);

	int button = Platform::ErrorDialog (msg, kMsgContinue + kMsgDebug);

	free (msg);
	free (appName);
	free (operation1);
	free (operation2);

	if (button == kMsgDebug)
	{
		Software::BusError ();
	}
}
