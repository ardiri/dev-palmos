/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1996-1997
 * Greg Hewgill.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Bernd Schmidt.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#pragma once

#include "Switches.h"

#include "UAE.h"		// uae_u32

/*
**	--------------------------------------------------------------------------------
**		Byte swapping
**	--------------------------------------------------------------------------------
*/

#define BYTE_SWAP_16(n)	((((unsigned short) n) >> 8) |	\
						 (((unsigned short) n) << 8))

#define BYTE_SWAP_32(n)	( (((unsigned long) n) << 24) |					\
						 ((((unsigned long) n) << 8) & 0x00FF0000) |	\
						 ((((unsigned long) n) >> 8) & 0x0000FF00) |	\
						  (((unsigned long) n) >> 24))


#if BYTESWAP

#include "Palm.h"			// PointType, RectangleType, etc.
#include "DebugMgr.h"		// SysPktReadRegsRspType2, etc.

	inline void Canonical(char& v)
	{
	}

	inline void Canonical(signed char& v)
	{
	}

	inline void Canonical(unsigned char& v)
	{
	}

	inline void Canonical(short& v)
	{
		v = (short) BYTE_SWAP_16(v);
	}

	inline void Canonical(unsigned short& v)
	{
		v = (unsigned short) BYTE_SWAP_16(v);
	}

	inline void Canonical(int& v)
	{
		if (sizeof(int) == 4)
			v = (int) BYTE_SWAP_32(v);

		else if (sizeof(int) == 2)
			v = (int) BYTE_SWAP_16(v);
	}

	inline void Canonical(unsigned int& v)
	{
		if (sizeof(unsigned int) == 4)
			v = (unsigned int) BYTE_SWAP_32(v);

		else if (sizeof(unsigned int) == 2)
			v = (unsigned int) BYTE_SWAP_16(v);
	}

	inline void Canonical(long& v)
	{
		v = (long) BYTE_SWAP_32(v);
	}

	inline void Canonical(unsigned long& v)
	{
		v = (unsigned long) BYTE_SWAP_32(v);
	}

	inline void Canonical(void*& v)
	{
		v = (void*) BYTE_SWAP_32(v);
	}

	inline void Canonical(char*& v)
	{
		v = (char*) BYTE_SWAP_32(v);
	}

	inline void Canonical(WinHandle& v)
	{
		v = (WinHandle) BYTE_SWAP_32(v);
	}

	void Canonical (BreakpointType& p);
	void Canonical (CardHeaderType& p);
	void Canonical (DatabaseHdrType& p);
	void Canonical (EventType& event);
	void Canonical (FieldAttrType& p);
	void Canonical (M68KRegsType& p);
	void Canonical (Point& p);
	void Canonical (PointType& p);
	void Canonical (RecordEntryType& p);
	void Canonical (RectangleType& p);
	void Canonical (RsrcEntryType& p);
	void Canonical (SlkPktHeaderType& p);
	void Canonical (SysNVParamsType& p);
	void Canonical (SysPktBodyType& p);
	void Canonical (SysPktContinueCmdType& p);
	void Canonical (SysPktDbgBreakToggleCmdType& p);
	void Canonical (SysPktFindCmdType& p);
	void Canonical (SysPktFindRspType& p);
	void Canonical (SysPktGetBreakpointsCmdType& p);
	void Canonical (SysPktGetBreakpointsRspType2& p);
	void Canonical (SysPktGetTrapBreaksCmdType& p);
	void Canonical (SysPktGetTrapBreaksRspType2& p);
	void Canonical (SysPktGetTrapConditionsCmdType& p);
	void Canonical (SysPktGetTrapConditionsRspType2& p);
	void Canonical (SysPktReadMemCmdType& p);
	void Canonical (SysPktReadRegsCmdType& p);
	void Canonical (SysPktReadRegsRspType2& p);
	void Canonical (SysPktRPCType& p);
	void Canonical (SysPktRtnNameCmdType& p);
	void Canonical (SysPktRtnNameRspType& p);
	void Canonical (SysPktSetBreakpointsCmdType2& p);
	void Canonical (SysPktSetTrapBreaksCmdType2& p);
	void Canonical (SysPktSetTrapConditionsCmdType2& p);
	void Canonical (SysPktStateCmdType& p);
	void Canonical (SysPktStateRspType& p);
	void Canonical (SysPktWriteRegsCmdType& p);
	void Canonical (SysPktWriteMemCmdType& p);

#else	// !BYTESWAP

	template <class T>
	inline void Canonical(T& v)
	{
	}

#endif	// BYTESWAP

#if defined (WORDSWAP_MEMORY)

	inline void ByteswapWords (void* start, uae_u32 length)
	{
		for (uae_u32 ii = 0; ii < length / 2; ++ii)
		{
			uae_u16*	p = ((uae_u16*) start) + ii;
			uae_u8*		bp = (uae_u8*) p;
			*p = (*bp << 8) | *(bp + 1);
		}
	}

#else

	inline void ByteswapWords (void*, uae_u32)
	{
	}

#endif	// WORDSWAP_MEMORY
