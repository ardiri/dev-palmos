

#include <BuildRules.h>


char* AppResourceList[] =
{
	":Resources:Rom Transfer.rsrc", 
	""
};

