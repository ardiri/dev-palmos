/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "Serial Port Tools.h"
#include <SysEvtMgr.h>


// Globals.

UInt16		gPortReference		= 0;
Boolean		gCommEstablished	= false;


// ---------------------------------------------------------------------------
//		� Comm_Initialize
// ---------------------------------------------------------------------------
// Opens the communications port.

SInt16 Comm_Initialize (SInt16 iPort, SInt16 iBaud)
{
	SInt16				aError;
	SerSettingsType		aSettings;

	// Exit if communications have already been established.

	if (gCommEstablished)
		return (kError_CommOpen);

	// Clear the globals.

	gPortReference		= 0;
	gCommEstablished	= false;

	// Find the serial library.

	Comm_ClearError ();

	aError = SysLibFind ("Serial Library", &gPortReference);
	if (aError != 0)
		return (kError_CantOpenPort);

	// Open the serial port.

	if (iPort != kPort_Pilot)
		return (kError_InvalidPort);

	Comm_ClearError ();

	aError = SerOpen (gPortReference, iPort, iBaud);

	if (aError == serErrAlreadyOpen)
	{
		SerClose (gPortReference);
		return (kError_PortOpen);
	}
	else if (aError != 0)
		return (kError_CantOpenPort);

	// Set the serial attributes.

	Comm_ClearError ();

	aSettings.baudRate		= iBaud;
	aSettings.flags			= serSettingsFlagBitsPerChar8 | serSettingsFlagStopBits1 | serSettingsFlagRTSAutoM | serSettingsFlagCTSAutoM;
	aSettings.ctsTimeout	= serDefaultCTSTimeout;

	aError = SerSetSettings (gPortReference, &aSettings);

	if (aError != 0)
	{
		SerClose (gPortReference);
		return (kError_CantOpenPort);
	}

	gCommEstablished = true;

	return (0);
}


// ---------------------------------------------------------------------------
//		� Comm_Dispose
// ---------------------------------------------------------------------------
// Closes the communications port.

void Comm_Dispose (void)
{
	// Exit if communications have not been established.

	if (!gCommEstablished)
		return;

	// Close the serial port.

	Comm_ClearError ();

	SerClose (gPortReference);

	gPortReference = 0;

	// Clear the globals.

	gCommEstablished = false;
}


// ---------------------------------------------------------------------------
//		� Comm_ClearError
// ---------------------------------------------------------------------------
// Clears the current serial errors.

void Comm_ClearError (void)
{
	// Exit if communications have not been established.

	if (!gCommEstablished)
		return;

	SerClearErr (gPortReference);
}
