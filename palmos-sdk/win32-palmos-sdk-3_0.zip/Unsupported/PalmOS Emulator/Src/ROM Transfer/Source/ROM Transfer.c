/*********************************************************************
 *
 * Copyright (c) 1998
 * 3Com/Palm Computing Division.  All rights reserved.
 *
 * Portions copyright (c) 1995-1997
 * Illume Software, Inc.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgement:
 *
 *		This product includes software developed by 3Com and its
 *		contributors.
 *
 * 4. Neither 3Com nor the names of its contributors may be used to
 *    endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 *******************************************************************/

#include "ROM Transfer.h"
#include <SysEvtMgr.h>


static char*	GetROMStart (UInt32 aROMVersion);
static UInt32	GetROMSize (UInt32 aROMVersion);

// ---------------------------------------------------------------------------
//		� PilotMain
// ---------------------------------------------------------------------------
// The main entry point for ROM Transfer.

UInt32 PilotMain (	UInt16		iCommand,
					Ptr			iCommandParams,
					UInt16		iLaunchFlags)
{
	#pragma unused (iCommandParams)
	#pragma unused (iLaunchFlags)

	if (iCommand != sysAppLaunchCmdNormalLaunch)
		return 0;

	ErrTry
	{
		InitializeApplication ();
		ExecuteApplication ();
	}

	// Catch any unhandled exceptions.

	ErrCatch (iError)
	{
	}
	ErrEndCatch

	// Clean up.

	DisposeApplication ();

	return 0;
}


#pragma mark -


// ---------------------------------------------------------------------------
//		� InitializeApplication
// ---------------------------------------------------------------------------
// Initializes the application globals and prepares to execute the event loop.

void InitializeApplication (void)
{
	CharPtr			aLabel;
	ListPtr			aList;
	Word			aListItem;
	ControlPtr		aControl;

	// Initialize and draw the main form.

	FormPtr aMainForm = FrmInitForm (MainForm);
	Throw_IfNil (aMainForm, 0);

	FrmSetActiveForm (aMainForm);
	FrmDrawForm	(aMainForm);

	// Set up the speed popup.

	aListItem = kItem_57600;
	aList = FrmGetObjectPtr (aMainForm, FrmGetObjectIndex (aMainForm, MainSpeedList));
	aLabel = LstGetSelectionText (aList, aListItem);
	aControl = FrmGetObjectPtr (aMainForm, FrmGetObjectIndex (aMainForm, MainSpeedPopTrigger));
	CtlSetLabel (aControl, aLabel);
	LstSetSelection (aList, aListItem);
}


// ---------------------------------------------------------------------------
//		� DisposeApplication
// ---------------------------------------------------------------------------
// Disposes the application globals and prepares to exit.

void DisposeApplication (void)
{
}


// ---------------------------------------------------------------------------
//		� ExecuteApplication
// ---------------------------------------------------------------------------
// Executes an event loop until the application quits.

void ExecuteApplication (void)
{
	EventType aEvent;

	aEvent.eType = nilEvent;

	// Repeat until the application quits.

	while (aEvent.eType != appStopEvent)
	{
		// Get the next available event.

		EvtGetEvent (&aEvent, evtWaitForever);

		// Give the system a chance to handle the event.

		if (!SysHandleEvent (&aEvent))

			// Try to handle the event ourselves.

			if (!ProcessEvent (&aEvent))

				// Let the form provide default handling of the event.

				FrmHandleEvent (FrmGetActiveForm (), &aEvent);
	}
}


// ---------------------------------------------------------------------------
//		� ProcessEvent
// ---------------------------------------------------------------------------
// Attempts to process the specified event.

Boolean ProcessEvent (EventPtr iEvent)
{
	Boolean		aWasHandled = false;

	if (iEvent->eType == ctlSelectEvent)
	{
		switch (iEvent->data.ctlEnter.controlID)
		{
			case MainBeginTransferButton:

				TransferROM ();
	   		aWasHandled = true;
	   		break;
		}
	}

	return aWasHandled;
}


// ---------------------------------------------------------------------------
//		� TransferROM
// ---------------------------------------------------------------------------
// Downloads the ROM via the serial connection.

void TransferROM (void)
{
	SInt16	aError;
	UInt32	aROMVersion;
	UInt32	aHeaderCode;
	SInt32	aOffset;
	char*	aROMStart;
	SInt32	aROMSize;
	Word	aROMChecksum;

	SInt16	aSpeedChoice;
	SInt16	aSpeed;
	FormPtr aForm;
	
	aForm = FrmGetActiveForm ();

	ErrTry
	{
		Throw_IfNil (aForm, 0);

		aSpeedChoice = LstGetSelection (FrmGetObjectPtr (aForm, FrmGetObjectIndex (aForm, MainSpeedList)));
		switch (aSpeedChoice)
		{
			case kItem_1200: aSpeed = kBaud_1200; break;
			case kItem_2400: aSpeed = kBaud_2400; break;
			case kItem_4800: aSpeed = kBaud_4800; break;
			case kItem_9600: aSpeed = kBaud_9600; break;
			case kItem_14400: aSpeed = kBaud_14400; break;
			case kItem_19200: aSpeed = kBaud_19200; break;
			case kItem_28800: aSpeed = kBaud_28800; break;
			case kItem_38400: aSpeed = kBaud_38400; break;
			case kItem_57600: aSpeed = kBaud_57600; break;
			default: aSpeed = kBaud_28800; break;
		}

		aError = Comm_Initialize (kPort_Pilot, aSpeed);
		Throw_IfError (aError, aError);

		// Determine which ROM we're transferring.

		FtrGet (sysFtrCreator, sysFtrNumROMVersion, &aROMVersion);

		// Tell the Emulator that we're going to start.

		aHeaderCode		= 0xDEADC0DE;
		aROMStart		= GetROMStart (aROMVersion);
		aROMSize		= GetROMSize (aROMVersion);
		aROMChecksum	= Crc16CalcBlock (aROMStart, aROMSize, 0);

		Comm_ClearError ();
		aError = SerSend10 (gPortReference, (void*) &aHeaderCode, sizeof (aHeaderCode));
		Throw_IfError (aError, aError);

		Comm_ClearError ();
		aError = SerSend10 (gPortReference, (void*) &aROMSize, sizeof (aROMSize));
		Throw_IfError (aError, aError);

		Comm_ClearError ();
		aError = SerSend10 (gPortReference, (void*) &aROMChecksum, sizeof (aROMChecksum));
		Throw_IfError (aError, aError);

		// Wait for the port to clear.

		Comm_ClearError ();
		aError = SerSendWait (gPortReference, 5 * sysTicksPerSecond);
		Throw_IfError (aError, aError);

		// Change the status text.

		FrmCopyLabel (aForm, MainStatusTextLabel, "Sending...          ");

		// Send the ROM one block at a time until it's done.

		aOffset		= 0;

		while (aOffset < aROMSize)
		{
			EvtResetAutoOffTimer ();

			// Change the status text.
			
			{
				DWord	percentComplete = (aOffset * 100) / (aROMSize - 0x1000);
				char	buffer1[100];
				char	buffer2[20];

				StrCopy (buffer1, "Sending...");
				StrIToA (buffer2, percentComplete);
				StrCat (buffer1, buffer2);
				StrCat (buffer1, "%          ");

				FrmCopyLabel (aForm, MainStatusTextLabel, buffer1);
			}

			Comm_ClearError ();
			aError = SerSend10 (gPortReference, (void*) (aROMStart + aOffset), 0x1000);
			Throw_IfError (aError, aError);

			// Wait for the port to clear.

			Comm_ClearError ();
			aError = SerSendWait (gPortReference, 5 * sysTicksPerSecond);
			Throw_IfError (aError, aError);

			aOffset += 0x1000;
		}

		// Change the status text.

		FrmCopyLabel (aForm, MainStatusTextLabel, "Finished               ");
	}

	// Catch any exceptions.

	ErrCatch (iError)
	{
		// Change the status text.

		if (aForm != NULL)
		{
			char	buffer1[100];
			char	buffer2[20];

			StrCopy (buffer1, "Error #");
			StrIToA (buffer2, iError);
			StrCat (buffer1, buffer2);
			StrCat (buffer1, "        ");

			FrmCopyLabel (aForm, MainStatusTextLabel, buffer1);
		}
	}
	ErrEndCatch

	Comm_Dispose ();
}

// Describes the card header format. This struct also includes
// the new fields present in Palm OS 3.0 devices.

#define	memMaxNameLen				32			// size of name and manuf fields including null

typedef struct CardHeaderTypeX
{
	DWord			initStack;					// initial stack pointer
	DWord			resetVector;				// reset vector
	DWord			signature;					// must be sysCardSignature
	Word			hdrVersion;					// header version
	Word			flags;						// card flags;
	Byte			name[memMaxNameLen];		// card name
	Byte			manuf[memMaxNameLen];		// card manufacturer's name
	Word			version;					// card version
	DWord			creationDate;				// card creation date
	Word			numRAMBlocks;				// number of RAM blocks on card
	DWord			blockListOffset;			// offset to RAM block list
	DWord			readWriteParmsOffset;		// v2: offset to read/write system data if any (in ROM)
	DWord			readWriteParmsSize;			// v2: size of read/write system data if any (in ROM)
	DWord			readOnlyParmsOffset;		// v2: offset to read-only system data (in ROM)
	DWord			bigROMOffset;				// v2: in SmallROM header: where SmallROM expects bigROM to live
												//	   in BigROM header: where BigROM expects itself to live
	DWord			checksumBytes;				// v2: size of card image in bytes (for checksum)
	Word			checksumValue;				// v2: checksum of card image (from Crc16CalcBlock)
	Byte			reserved[142];				// to bring us to 0x100 alignment
} CardHeaderTypeX;


// ---------------------------------------------------------------------------
//		� GetROMStart
// ---------------------------------------------------------------------------

char* GetROMStart (UInt32 aROMVersion)
{
	DWord	bigROMOffset;
	char*	bigROMStart;

	if ((aROMVersion >> 24) == 1)
		return (char*) 0x10C00000;

	if ((aROMVersion >> 24) == 2)
		return (char*) 0x10C00000;

	bigROMOffset = ((CardHeaderTypeX*) 0x10C00000)->bigROMOffset;
	bigROMStart = (char*) 0x10000000 + bigROMOffset;

	return bigROMStart;
}


// ---------------------------------------------------------------------------
//		� GetROMSize
// ---------------------------------------------------------------------------

UInt32 GetROMSize (UInt32 aROMVersion)
{
	char*	bigROMStart;

	if ((aROMVersion >> 24) == 1)
		return 512 * 1024L;

	if ((aROMVersion >> 24) == 2)
		return 1024 * 1024L;

	bigROMStart = GetROMStart (aROMVersion);

	return ((CardHeaderTypeX*) bigROMStart)->checksumBytes;
}
