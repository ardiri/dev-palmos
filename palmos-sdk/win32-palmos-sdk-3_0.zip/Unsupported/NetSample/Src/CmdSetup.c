/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot Sample Internet Application
 * FILE:     CmdSetup.c
 *
 * DESCRIPTION:
 *	
 * This module provides various commands to open, close, and change the
 *	timeout value used by the Berkeley sockets API macros of the Net Library.
 *
 **********************************************************************/


// Socket Equates
#include <sys_socket.h>

// StdIO header
#include "AppStdIO.h"

// Application headers
#include "NetSample.h"


/***********************************************************************
 *
 * FUNCTION:   CmdDivider()
 *
 * DESCRIPTION: This command exists solely to print out a dividing line
 *		when the user does a help all.
 *
 *	CALLED BY:	 
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdDivider(int argc, CharPtr argv[])
{
	// Check for short help
	if (argc > 1 && !StrCompare(argv[1], "?")) 
		printf("\n-- Setup Cmds --\n");
}


/***********************************************************************
 *
 * FUNCTION:   CmdTimeout
 *
 * DESCRIPTION:Setup Timeout for all subsequent Net commands
 *
 *	CALLED BY:	 AppExecCommand  
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdTimeout(int argc, CharPtr argv[])
{

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	
	// Get the new timeout value in seconds
	if (argc > 1) 
		AppNetTimeout = sysTicksPerSecond * atol(argv[1]);
	printf("Timeout set to %ld seconds\n", AppNetTimeout/sysTicksPerSecond);
	return;
	
ShortHelp:
	printf("%s\t\t# Get/Set AppNetTimeout\n", argv[0]);
	return;
	
FullHelp:
	printf("\nGet/Set timeout (in seconds) for NetLib commands");
	printf("\nSyntax: %s [<seconds>]", argv[0]);
	printf("\n");
}





/***********************************************************************
 *
 * FUNCTION:   CmdOpen()
 *
 * DESCRIPTION: Test NetLibOpen
 *
 *	CALLED BY:	AppProcessCommand in response to the "open" command
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdOpen(int argc, CharPtr argv[])
{
	Word		ifErrs;
	Err		err;
	DWord		ifCreator;
	Word		ifInstance;
	
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	
	
	
	// If there are no interfaces attached, print error message
	err = NetLibIFGet(AppNetRefnum, 0, &ifCreator, &ifInstance);
	if (err) {
		StdPutS(	"\n##Error: No internet service setup.\n\n");
		#if EMULATION_LEVEL == EMULATION_NONE
			StdPutS(	"Please switch to the Network preference panel "
						"and setup your internet service before you "
						"continue.\n");
		#else
			StdPutS(	"Please quit, "
					 	"run the Network preference panel application, "
					 	"save it's memory card images, and copy them (Pilot Card 0,1) "
					 	"to the current directory before re-launching "
					 	"this application.\n");
		#endif
		return;
		}

	printf("Opening Connection...");
	err = NetLibOpen(AppNetRefnum, &ifErrs);

	if (err == netErrAlreadyOpen)  {
		printf("\nNote: Net Lib was open, open count incremented");
		err = 0;
		}
	if (err) {
		printf("\nOpen Error: %s\n", appErrString(err));
		return;
		}
	if (!err) {
		AppNeedNetLibClose++;
		printf("\nOpened.");
		}

	//-------------------------------------------------------------------
	// If there were errors bringup any interfaces, see which ones
	//-------------------------------------------------------------------
	if (ifErrs) {
		Word		index;
		Byte		up;
		Word		settingSize;
		Char		ifName[32];
		
		printf("\nInterface Error: %s", appErrString(ifErrs));
		if (ifErrs == netErrPrefNotFound) {
			printf("\nThis most likely means that your internet setup is incomplete.");
			printf("\nSwitch to the Network preference panel and check your setup.");
			}
		for (index = 0; 1; index++) {
			err = NetLibIFGet(AppNetRefnum, index, &ifCreator, &ifInstance);
			if (err) break;

			settingSize = sizeof(up);
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance,
				netIFSettingUp, &up, &settingSize);
			if (err || up) continue;
			
			settingSize = 32;
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance,
				netIFSettingName, ifName, &settingSize);
			if (err) continue;
			
			printf("\nInterface %s did not come up.", ifName);
			}

			
		// Close the NetLib if any interfaces failed to come up.
		AppExecCommand("close");
		}


	printf("\n");
	return;
	
ShortHelp:
	printf("%s\t\t# Open NetLib\n", argv[0]);
	return;
	
FullHelp:
	printf("\nOpen NetLib");
	printf("\nSyntax: %s ", argv[0]);
	printf("\n");

}


/***********************************************************************
 *
 * FUNCTION:   CmdClose()
 *
 * DESCRIPTION: Test NetLibClose
 *
 *	CALLED BY:	AppProcessCommand in response to the "close" command
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdClose(int argc, CharPtr argv[])
{
	Err		err;
	
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	
	printf("\nClosing NetLib...");
	err = NetLibClose(AppNetRefnum, false);
	if (err) printf("\nError closing: %s", appErrString(err));
	else printf("\nClosed.");
	
	if (AppNeedNetLibClose) AppNeedNetLibClose--;

	printf("\n");
	return;
	
ShortHelp:
	printf("%s\t\t# Close NetLib\n", argv[0]);
	return;
	
FullHelp:
	printf("\nClose NetLib");
	printf("\nSyntax: %s ", argv[0]);
	printf("\n");

}



/***********************************************************************
 *
 * FUNCTION:   	CmdSetupInstall
 *
 * DESCRIPTION: 	Installs the commands from this module into the
 *		master command table used by AppProcessCommand.
 *
 *	CALLED BY:		AppStart 
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
void CmdSetupInstall(void)
{
	AppAddCommand("_", CmdDivider);
	
	AppAddCommand("timeout", CmdTimeout);
	AppAddCommand("open", CmdOpen);
	AppAddCommand("close", CmdClose);
}




