/***********************************************************************
 *
 Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 All rights reserved.
   
 This software may be copied and used solely for developing products for 
 the Palm Computing platform and for archival and backup purposes.  Except 
 for the foregoing, no part of this software may be reproduced or transmitted 
 in any form or by any means or used to make any derivative work (such as 
 translation, transformation or adaptation) without express written consent 
 from 3Com.

 3Com reserves the right to revise this software and to make changes in content 
 from time to time without obligation on the part of 3Com to provide notification 
 of such revision or changes.  
 3COM MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE SOFTWARE IS FREE OF ERRORS 
 OR THAT THE SOFTWARE IS SUITABLE FOR YOUR USE.  THE SOFTWARE IS PROVIDED ON AN 
 "AS IS" BASIS.  3COM MAKES NO WARRANTIES, TERMS OR CONDITIONS, EXPRESS OR IMPLIED, 
 EITHER IN FACT OR BY OPERATION OF LAW, STATUTORY OR OTHERWISE, INCLUDING WARRANTIES, 
 TERMS, OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND 
 SATISFACTORY QUALITY.

 TO THE FULL EXTENT ALLOWED BY LAW, 3COM ALSO EXCLUDES FOR ITSELF AND ITS SUPPLIERS 
 ANY LIABILITY, WHETHER BASED IN CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR 
 DIRECT, INCIDENTAL, CONSEQUENTIAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES OF 
 ANY KIND, OR FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION 
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH THIS SOFTWARE, 
 EVEN IF 3COM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

 3Com, HotSync, Palm Computing, and Graffiti are registered trademarks, and 
 Palm III and Palm OS are trademarks of 3Com Corporation or its subsidiaries.

 IF THIS SOFTWARE IS PROVIDED ON A COMPACT DISK, THE OTHER SOFTWARE AND 
 DOCUMENTATION ON THE COMPACT DISK ARE SUBJECT TO THE LICENSE AGREEMENT 
 ACCOMPANYING THE COMPACT DISK.

 *************************************************************************
 *
 * PROJECT:  Pilot Sample Internet Application
 * FILE:     NetSample.h
 *
 * DESCRIPTION:
 *	
 * This application is provided as an example of how to use the Net Library
 * of the PalmOS when writing internet applications. It does NOT have a pretty
 * UI and should not be used as a model application. It does however show
 * how to use the Net Library to implement various internet applications like
 * ftp, telnet, etc. 
 *
 * When launched, this application shows a scrolling text window where commands
 * can be entered using Graffiti, or chosen from the menus. Most of the
 * commands take a wide range of command-line arguments. The 'help' command
 * will list the available commands and 'help <command>' will list help
 * on a specific command.
 *
 * IMPORTANT: In order to run this application in the Simulator, you must 
 * have a memory card image file ("Pilot Card 0") in it's directory that has 
 * the "Net Prefs" database created by the "Network" preference panel 
 * in it. Without this database present, you won't be able to dial up and
 * establish a connection with an internet service provider. To create this
 * memory card image, run the "Network" preference panel simulator app and
 * set things up for your ISP. Then, save the memory card image using the 
 * "File" menu and then copy it to the NetSample directory. 
 *
 **********************************************************************/

/*#include <unix_stdarg.h>*/


/********************************************************************
 * #define these to include the corresponding commands in the final 
 *  executable.
 *
 * When compiling for the device, we don't have room for all the commands
 *
 ********************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE	
	#define	INCLUDE_ALL		1
#else
	#define	INCLUDE_ALL		0
#endif


#define	INCLUDE_HOSTENT				(1 | INCLUDE_ALL)	
#define	INCLUDE_DAYTIME				(1 | INCLUDE_ALL)	
#define	INCLUDE_TIMER					(1 | INCLUDE_ALL)	
#define	INCLUDE_ECHO					(1 | INCLUDE_ALL)	
#define	INCLUDE_DISCARD				(1 | INCLUDE_ALL)	
#define	INCLUDE_READ					(1 | INCLUDE_ALL)	
#define	INCLUDE_CHARGEN				(1 | INCLUDE_ALL)	
#define	INCLUDE_TORTURE				(1 | INCLUDE_ALL)	
#define	INCLUDE_SETTINGS				(1 | INCLUDE_ALL)	
#define	INCLUDE_DM						(1 | INCLUDE_ALL)
#define	INCLUDE_SM						(1 | INCLUDE_ALL)
#define	INCLUDE_FTP						(1 | INCLUDE_ALL)
#define	INCLUDE_TELNET					(1 | INCLUDE_ALL)



/********************************************************************
 * Normal stuff
 ********************************************************************/
// General Equates
#define	kAppCreator							'NETS'


//--------------------------------------------
// Main Form
//--------------------------------------------
#define	kMainFormID							1000
#define	kMainTextFldID						1002					// the text field
#define	kMainScrollerID					1003					// Scroll bar



//--------------------------------------------
// Menus
//--------------------------------------------

//...............................................
// Main View Menu bar and menus
//...............................................
#define	kMainMenuBarID						1000

// Utility Menu
#define 	kMainUtilDaytime					1000
#define 	kMainUtilDNS						1001
#define 	kMainUtilEcho						1002
#define 	kMainUtilDiscard					1003
#define 	kMainUtilCharGen					1004
#define 	kMainUtilTelnet					1005
#define 	kMainUtilFTP						1006

// Debug Menu
#define	kMainDebugConnectLog				1100
#define	kMainDebugIFInfo					1101
#define	kMainDebugIFStats					1102
#define	kMainDebugIPStats					1103
#define	kMainDebugICMPStats				1104
#define	kMainDebugUDPStats				1105
#define	kMainDebugTCPStats				1106
#define	kMainDebugTraceAll				1107
#define	kMainDebugTraceErrMsg			1108
#define	kMainDebugTraceNone				1109
#define	kMainDebugTraceDisplay			1110

// Misc Menu
#define	kMainMiscAboutCmd					1200




//--------------------------------------------
// Alerts
//--------------------------------------------
// Unimplemented Alert
#define kUnimplementedAlertID				1000
// Rom Incompatible Alert
#define RomIncompatibleAlert				1001
#define NetLibIncompatibleAlert			1002



//--------------------------------------------
// Error Handling
//--------------------------------------------
#define	kAppErrStrLen		32
extern	Char					AppErrStr[kAppErrStrLen];
#define	appErrString(err)	\
				SysErrString(err,AppErrStr,kAppErrStrLen)


//--------------------------------------------
// Functions
//--------------------------------------------
typedef 	void (*CmdProcPtr)(int argc, char* argv[]);

void 		AppExecCommand(CharPtr cmd);
void 		AppAddCommand(CharPtr cmdStr, CmdProcPtr cmdProcP);


void 		CmdInfoInstall(void);
void 		CmdStevensInstall(void);
void 		CmdSetupInstall(void);
void 		CmdFTPInstall(void);
void 		CmdTelnetInstall(void);


//--------------------------------------------
// Globals
//--------------------------------------------
extern UInt		AppNeedNetLibClose;
