/******************************************************************************
 *
 * Copyright (c) 1994-2003 PalmSource, Inc. All rights reserved.
 *
 * File: CPMLib68KInterface.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 * Description:
 *    This module contains the interface definition for the Cryptographic
 *    Provider Manager library on Pilot for 68K code.
 *
 *****************************************************************************/

#ifndef _CPMLIB_68K_INTERFACE_H
#define _CPMLIB_68K_INTERFACE_H
#include "CPMLibCommon.h"

/** CPMLib Trap number selectors
 *
 * CPM library call ID's. Each library call gets the trap number:
 * cpmTrapXXXX which serves as an index into the library's dispatch table.
 * The constant sysLibTrapCustom is the first available trap number after
 * the system predefined library traps Open, Close, Sleep and Wake.
 *
 * <b>WARNING!!! This order of these traps MUST match the order of the dispatch
 * table in CPMLibDispatch.c!!!</b>
 */
#define cpmLibTrapOpen					sysLibTrapOpen
#define cpmLibTrapClose					sysLibTrapClose
#define cpmLibTrapSleep					sysLibTrapSleep
#define cpmLibTrapWake					sysLibTrapWake


#define cpmLibTrapGetInfo					sysLibTrapCustom
#define cpmLibTrapSetDebugLevel			(sysLibTrapCustom+1)

#define cpmLibTrapEnumerateProviders	(sysLibTrapCustom+2)
#define cpmLibTrapGetProviderInfo		(sysLibTrapCustom+3)
#define cpmLibTrapSetDefaultProvider	(sysLibTrapCustom+4)

#define cpmLibTrapGenerateRandomBytes	(sysLibTrapCustom+5)
#define cpmLibTrapAddRandomSeed			(sysLibTrapCustom+6)

#define cpmLibTrapGenerateKey				(sysLibTrapCustom+7)
#define cpmLibTrapImportKeyInfo			(sysLibTrapCustom+8)
#define cpmLibTrapExportKeyInfo			(sysLibTrapCustom+9)
#define cpmLibTrapReleaseKeyInfo			(sysLibTrapCustom+10)

#define cpmLibTrapGenerateKeyPair				(sysLibTrapCustom+11)
#define cpmLibTrapImportKeyPairInfo			(sysLibTrapCustom+12)
#define cpmLibTrapExportKeyPairInfo			(sysLibTrapCustom+13)

#define cpmLibTrapDeriveKey			(sysLibTrapCustom+14)

#define cpmLibTrapHashInit					(sysLibTrapCustom+15)
#define cpmLibTrapHashUpdate				(sysLibTrapCustom+16)
#define cpmLibTrapHashFinal				(sysLibTrapCustom+17)
#define cpmLibTrapHash						(sysLibTrapCustom+18)
#define cpmLibTrapImportHashInfo			(sysLibTrapCustom+19)
#define cpmLibTrapExportHashInfo			(sysLibTrapCustom+20)
#define cpmLibTrapReleaseHashInfo		(sysLibTrapCustom+21)

#define cpmLibTrapEncryptInit				(sysLibTrapCustom+22)
#define cpmLibTrapEncryptUpdate			(sysLibTrapCustom+23)
#define cpmLibTrapEncryptFinal			(sysLibTrapCustom+24)
#define cpmLibTrapEncrypt					(sysLibTrapCustom+25)
#define cpmLibTrapDecryptInit				(sysLibTrapCustom+26)
#define cpmLibTrapDecryptUpdate			(sysLibTrapCustom+27)
#define cpmLibTrapDecryptFinal			(sysLibTrapCustom+28)
#define cpmLibTrapDecrypt					(sysLibTrapCustom+29)
#define cpmLibTrapImportCipherInfo		(sysLibTrapCustom+30)
#define cpmLibTrapExportCipherInfo		(sysLibTrapCustom+31)
#define cpmLibTrapReleaseCipherInfo		(sysLibTrapCustom+32)

#define cpmLibTrapMACInit					(sysLibTrapCustom+33)
#define cpmLibTrapMACUpdate				(sysLibTrapCustom+34)
#define cpmLibTrapMACFinal				(sysLibTrapCustom+35)
#define cpmLibTrapMAC						(sysLibTrapCustom+36)
#define cpmLibTrapImportMACInfo			(sysLibTrapCustom+37)
#define cpmLibTrapExportMACInfo			(sysLibTrapCustom+38)
#define cpmLibTrapReleaseMACInfo		(sysLibTrapCustom+39)

#define cpmLibTrapVerifyInit				(sysLibTrapCustom+40)
#define cpmLibTrapVerifyUpdate			(sysLibTrapCustom+41)
#define cpmLibTrapVerifyFinal				(sysLibTrapCustom+42)
#define cpmLibTrapVerify					(sysLibTrapCustom+43)
#define cpmLibTrapImportVerifyInfo		(sysLibTrapCustom+44)
#define cpmLibTrapExportVerifyInfo		(sysLibTrapCustom+45)
#define cpmLibTrapReleaseVerifyInfo		(sysLibTrapCustom+35)

#define cpmLibTrapSignInit				(sysLibTrapCustom+46)
#define cpmLibTrapSignUpdate			(sysLibTrapCustom+47)
#define cpmLibTrapSignFinal				(sysLibTrapCustom+48)
#define cpmLibTrapSign					(sysLibTrapCustom+49)
#define cpmLibTrapImportSignInfo		(sysLibTrapCustom+50)
#define cpmLibTrapExportSignInfo		(sysLibTrapCustom+51)
#define cpmLibTrapReleaseSignInfo		(sysLibTrapCustom+52)
		
#define cpmLibTrapLast						(sysLibTrapCustom+53)

#ifndef TRAPS_ONLY

#ifdef  __cplusplus
extern "C" {
#endif

/*
 * Library initialization and shutdown
 */
status_t CPMLibOpen(uint16_t refnum, uint16_t *numProviders)  SYS_TRAP(sysLibTrapOpen);
status_t CPMLibClose(uint16_t refnum)  SYS_TRAP(sysLibTrapClose);
status_t CPMLibSleep(uint16_t refnum)  SYS_TRAP(sysLibTrapSleep);
status_t CPMLibWake(uint16_t refnum)  SYS_TRAP(sysLibTrapWake);

/* 
 * Library settings
 */
status_t CPMLibGetInfo(uint16_t refnum, CPMInfoType *infoP)  SYS_TRAP(cpmLibTrapGetInfo);
status_t CPMLibSetDebugLevel(uint16_t refnum, uint8_t debugLevel)  SYS_TRAP(cpmLibTrapSetDebugLevel);

/* 
 * Provider information
 */
status_t CPMLibEnumerateProviders(uint16_t refnum, uint32_t providerIDs[], uint16_t *numProviders)  SYS_TRAP(cpmLibTrapEnumerateProviders);
status_t CPMLibGetProviderInfo(uint16_t refnum, uint32_t providerID, APProviderInfoType *providerInfoP)  SYS_TRAP(cpmLibTrapGetProviderInfo);
status_t CPMLibSetDefaultProvider(uint16_t refnum, uint32_t providerID)  SYS_TRAP(cpmLibTrapSetDefaultProvider);

/*
 * Random bytes
 */
status_t CPMLibGenerateRandomBytes(uint16_t refnum, uint8_t *bufferP, uint32_t *bufLenP)  SYS_TRAP(cpmLibTrapGenerateRandomBytes);
status_t CPMLibAddRandomSeed(uint16_t refnum, uint8_t *seedDataP, uint32_t dataLen)  SYS_TRAP(cpmLibTrapAddRandomSeed);

/*
 * Symmetric key generation operations
 */
status_t CPMLibGenerateKey(uint16_t refnum, uint8_t *keyDataP, uint32_t dataLen, APKeyInfoType *keyInfoP)  SYS_TRAP(cpmLibTrapGenerateKey);
status_t CPMLibImportKeyInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APKeyInfoType *keyInfoP)  SYS_TRAP(cpmLibTrapImportKeyInfo);
status_t CPMLibExportKeyInfo(uint16_t refnum, APKeyInfoType *keyInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportKeyInfo);
status_t CPMLibReleaseKeyInfo(uint16_t refnum, APKeyInfoType *keyInfoP)  SYS_TRAP(cpmLibTrapReleaseKeyInfo);

/*
 * Asymmetric key generation operations
 */
status_t CPMLibGenerateKeyPair(uint16_t refnum, uint8_t *keyDataP, uint32_t dataLen, APKeyInfoType *privateKeyInfoP, APKeyInfoType *publicKeyInfoP)  SYS_TRAP(cpmLibTrapGenerateKeyPair);
status_t CPMLibImportKeyPairInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APKeyInfoType *privateKeyInfoP, APKeyInfoType *publicKeyInfoP)  SYS_TRAP(cpmLibTrapImportKeyPairInfo);
status_t CPMLibExportKeyPairInfo(uint16_t refnum, APKeyInfoType *privateKeyInfoP, APKeyInfoType *publicKeyInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportKeyPairInfo);

/*
 * Derived key generation operations (uint16_t refnum, PBE)
 */
status_t CPMLibDeriveKey(uint16_t refnum, APDerivedKeyInfoType *derivedKeyInfoP, uint8_t *keyDataP, uint32_t *dataLen)  SYS_TRAP(cpmLibTrapDeriveKey);

/*
 * Message digest operations
 */
status_t CPMLibHashInit(uint16_t refnum, APHashInfoType *hashInfoP)  SYS_TRAP(cpmLibTrapHashInit);
status_t CPMLibHashUpdate(uint16_t refnum, APHashInfoType *hashInfoP, uint8_t *bufIn, uint32_t bufInLen)  SYS_TRAP(cpmLibTrapHashUpdate);
status_t CPMLibHashFinal(uint16_t refnum, APHashInfoType *hashInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapHashFinal);
status_t CPMLibHash(uint16_t refnum, APHashEnum type, APHashInfoType *hashInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapHash);
status_t CPMLibImportHashInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APHashInfoType *hashInfoP)  SYS_TRAP(cpmLibTrapImportHashInfo);
status_t CPMLibExportHashInfo(uint16_t refnum, APHashInfoType *hashInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportHashInfo);
status_t CPMLibReleaseHashInfo(uint16_t refnum, APHashInfoType *hashInfoP)  SYS_TRAP(cpmLibTrapReleaseHashInfo);

/*
 * Cipher operations
 */
status_t CPMLibEncryptInit(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP)  SYS_TRAP(cpmLibTrapEncryptInit);
status_t CPMLibEncryptUpdate(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapEncryptUpdate);
status_t CPMLibEncryptFinal(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapEncryptFinal);
status_t CPMLibEncrypt(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapEncrypt);
status_t CPMLibDecryptInit(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP)  SYS_TRAP(cpmLibTrapDecryptInit);
status_t CPMLibDecryptUpdate(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapDecryptUpdate);
status_t CPMLibDecryptFinal(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapDecryptFinal);
status_t CPMLibDecrypt(uint16_t refnum, APKeyInfoType *keyInfoP, APCipherInfoType *cipherInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapDecrypt);
status_t CPMLibImportCipherInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APCipherInfoType *cipherInfoP)  SYS_TRAP(cpmLibTrapImportCipherInfo);
status_t CPMLibExportCipherInfo(uint16_t refnum, APCipherInfoType *cipherInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportCipherInfo);
status_t CPMLibReleaseCipherInfo(uint16_t refnum, APCipherInfoType *cipherInfoP)  SYS_TRAP(cpmLibTrapReleaseCipherInfo);

/*
 * MAC operations
 */
status_t CPMLibMACInit(uint16_t refnum, APKeyInfoType *keyInfoP, APHashInfoType *hashInfoP, APMACInfoType *macInfoP)  SYS_TRAP(cpmLibTrapMACInit);
status_t CPMLibMACUpdate(uint16_t refnum, APMACInfoType *macInfoP, uint8_t *bufIn, uint32_t bufInLen)  SYS_TRAP(cpmLibTrapMACUpdate);
status_t CPMLibMACFinal(uint16_t refnum, APMACInfoType *macInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapMACFinal);
status_t CPMLibMAC(uint16_t refnum, APKeyInfoType *keyInfoP, APHashInfoType *hashInfoP, APMACEnum type, APMACInfoType *macInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP)  SYS_TRAP(cpmLibTrapMAC);
status_t CPMLibImportMACInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APMACInfoType *macInfoP)  SYS_TRAP(cpmLibTrapImportMACInfo);
status_t CPMLibExportMACInfo(uint16_t refnum, APMACInfoType *macInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportMACInfo);
status_t CPMLibReleaseMACInfo(uint16_t refnum, APMACInfoType *macInfoP)  SYS_TRAP(cpmLibTrapReleaseMACInfo);

/*
 * Verification operations
 */
status_t CPMLibVerifyInit(uint16_t refnum, APKeyInfoType *keyInfoP, APVerifyInfoType *verifyInfoP)  SYS_TRAP(cpmLibTrapVerifyInit);
status_t CPMLibVerifyUpdate(uint16_t refnum, APKeyInfoType *keyInfoP, APVerifyInfoType *verifyInfoP, uint8_t *bufIn, uint32_t bufInLen)  SYS_TRAP(cpmLibTrapVerifyUpdate);
status_t CPMLibVerifyFinal(uint16_t refnum, APKeyInfoType *keyInfoP, APVerifyInfoType *verifyInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP, uint8_t *signature, uint32_t signatureLen, VerifyResultType *verifyResultP)  SYS_TRAP(cpmLibTrapVerifyFinal);
status_t CPMLibVerify(uint16_t refnum, APKeyInfoType *keyInfoP, APVerifyInfoType *verifyInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP, uint8_t *signature, uint32_t signatureLen, VerifyResultType *verifyResultP)  SYS_TRAP(cpmLibTrapVerify);
status_t CPMLibImportVerifyInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APVerifyInfoType *verifyInfoP)  SYS_TRAP(cpmLibTrapImportVerifyInfo);
status_t CPMLibExportVerifyInfo(uint16_t refnum, APVerifyInfoType *verifyInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportVerifyInfo);
status_t CPMLibReleaseVerifyInfo(uint16_t refnum, APVerifyInfoType *verifyInfoP)  SYS_TRAP(cpmLibTrapReleaseVerifyInfo);

/*
 * Signing operations
 */
status_t CPMLibSignInit(uint16_t refnum, APKeyInfoType *keyInfoP, APSignInfoType *signInfoP)  SYS_TRAP(cpmLibTrapSignInit);
status_t CPMLibSignUpdate(uint16_t refnum, APKeyInfoType *keyInfoP, APSignInfoType *signInfoP, uint8_t *bufIn, uint32_t bufInLen)  SYS_TRAP(cpmLibTrapSignUpdate);
status_t CPMLibSignFinal(uint16_t refnum, APKeyInfoType *keyInfoP, APSignInfoType *signInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP, uint8_t *signature, uint32_t *signatureLenP)  SYS_TRAP(cpmLibTrapSignFinal);
status_t CPMLibSign(uint16_t refnum, APKeyInfoType *keyInfoP, APSignInfoType *signInfoP, uint8_t *bufIn, uint32_t bufInLen, uint8_t *bufOut, uint32_t *bufOutLenP, uint8_t *signature, uint32_t *signatureLenP)  SYS_TRAP(cpmLibTrapSign);
status_t CPMLibImportSignInfo(uint16_t refnum, uint8_t encoding, uint8_t *importDataP, uint32_t dataLen, APSignInfoType *signInfoP)  SYS_TRAP(cpmLibTrapImportSignInfo);
status_t CPMLibExportSignInfo(uint16_t refnum, APSignInfoType *signInfoP, uint8_t encoding, uint8_t *exportDataP, uint32_t *dataLenP)  SYS_TRAP(cpmLibTrapExportSignInfo);
status_t CPMLibReleaseSignInfo(uint16_t refnum, APSignInfoType *signInfoP)  SYS_TRAP(cpmLibTrapReleaseSignInfo);

#ifdef  __cplusplus
}
#endif

#endif /* TRAPS_ONLY */
#endif /* _CPMLIB_68K_INTERFACE_H */
