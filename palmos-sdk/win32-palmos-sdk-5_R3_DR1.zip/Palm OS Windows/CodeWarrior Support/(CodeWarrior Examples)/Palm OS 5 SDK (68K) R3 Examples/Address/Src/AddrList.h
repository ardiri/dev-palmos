/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: AddrList.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRLIST_H
#define ADDRLIST_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean ListHandleEvent (EventType * event);

#endif // ADDRLIST_H
