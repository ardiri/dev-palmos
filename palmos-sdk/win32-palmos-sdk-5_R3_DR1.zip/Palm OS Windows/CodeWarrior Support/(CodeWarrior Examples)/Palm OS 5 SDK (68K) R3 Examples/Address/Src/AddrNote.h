/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: AddrNote.h
 *
 * Release: Palm OS 5 SDK (68K) R3.
 *
 *****************************************************************************/

#ifndef ADDRNOTE_H
#define ADDRNOTE_H

#include <Form.h>
#include <ErrorMgr.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean	NoteViewHandleEvent (EventType * event);
Boolean	NoteViewCreate (void);
void	NoteViewDelete (void);

#endif // ADDRNOTE_H
