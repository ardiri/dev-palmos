# obsolete.tcl --
#
# This file contains obsolete procedures that people really shouldn't
# be using anymore, but which are kept around for backward compatibility.
#
# RCS: @(#) $Id: obsolete.tcl,v 1.7.6.1 2000/05/04 21:26:25 spolk Exp $
#
# Copyright (c) 1994 The Regents of the University of California.
# Copyright (c) 1994 Sun Microsystems, Inc.
#
# See the file "license.terms" for information on usage and redistribution
# of this file, and for a DISCLAIMER OF ALL WARRANTIES.
#

# The procedures below are here strictly for backward compatibility with
# Tk version 3.6 and earlier.  The procedures are no longer needed, so
# they are no-ops.  You should not use these procedures anymore, since
# they may be removed in some future release.

proc tk_menuBar args {}
proc tk_bindForTraversal args {}

