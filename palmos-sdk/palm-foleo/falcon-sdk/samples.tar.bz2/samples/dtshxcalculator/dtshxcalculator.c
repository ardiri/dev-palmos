
/**
 * @brief This is a basic calculator application. It shows how to display 
 * and respond to more than 
 * one commandbutton. The application also shows how to respond to 
 * keyboard strokes. 
 *
 * @ingroup dtshxcalculator sample
 * @file dtshxcalculator.c
 * <hr>
 **/
 
#include <hx/ui/hxui.h>
#include <locale.h>
#include "AppResources.h"

#define Err 1
#define	APP_NAME		"dtshxcalculator"
#define APP_RES_FILE    	"Resources/dtscalculator.hxui"
#define RESID(x)    (LookupResID(#x))
#define RESET 1
#define CLEAR 2
#define SPACE 32
#define ZERO  48
#define MINUS 45
#define PERIOD 46
/*********************************************************************/

static 		HxResFile_t *spResFile = NULL;
static 		HxResult CmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static 		HxCommandButton_t* spCmdButton[23];


/************************************************************************/

void			displayParameter();
void 			Set_parameter(int param);
void			Period_Pressed();
double 			doMath();
void 			POSorNEG_Pressed();
void	 		Backspace_Pressed();
void 			Display_Result(double fnum);
void 			ResetDisplayVariables();
void	 		CEorC_Pressed(int param);
static 			uint32_t LookupResID();
static void 		AtExit_UserInterface();
static 			HxResult HandleButtonPress(const HxMessage_t* pMessage, void* data);  
static	 		HxResult KeyboardCallback( const HxMessage_t* pMessage, void* pData); 
static HxResult 	InitMenus(HxResFile_t* pResFile);
static HxResult 	MenuCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData);
void 			math_button_pressed(int buttonID);
/************************************************************************/

double 			x_parameter;
double 			y_parameter;
int			Math_Function;
char   			DisplayStr[20];
int 			DisplayCounter,y_param_set_flag;
HxWindow_t* 		pAppWindow = NULL;
HxLabel_t*  		pLabelResult = NULL;
HxField_t* 		pField = NULL;

typedef enum{
	Add = 1,
	Sub,
	Mult,
	Div,
	Sqrt,
	OneDiv,
	Mod
}Operators;

/**
	Change the calculator display.
	
	This function sets the calculators display field to whatever is stored
	in the variable DisplayStr
*/
void displayParameter(){
	int result;
	result = HxFieldSetText(pField,DisplayStr);
	HX_ASSERT(HX_OK == result);
	result = HxWidgetDraw(pField,NULL); 
    	HX_ASSERT(HX_OK == result); 
}

/**
	Set the x or y parameters used in the doMath() function

	This functions sets the x or y varialbe to whatever value the calculator is displaying. The int param
	determines whether the x or y parameter is set 

	@param[in] 	param 	int 

*/
void Set_parameter(int param){
	int result;
	char* str1;
	result = HxFieldGetText(pField,&str1);
	if(param==1)
		x_parameter = atof(str1);
	else
		y_parameter = atof(str1);	
}
/**
	Adds a decimal place to number being displayed

	The function checks if a period is already displayed before adding one if it doesn't already exist
*/
void Period_Pressed(){
	int i,periodExists = 0;
	for (i=0; i<DisplayCounter; i++){
		if (DisplayStr[i]==46){
			periodExists = 1;
			break;
		}
	}
	if (!periodExists){
		DisplayStr[DisplayCounter++] = 46;	
		displayParameter();
	}
}
/**
	This function uses the global variables x_parameter, y_parameter and Math_Function
	to do whatever math function was requested.

	@param[out] 	 	

	@return double
	@retval result returns the result of the mathical equation

*/
double doMath(){
	double result = 0;
    switch(Math_Function){
	    case Add:
	    	result = x_parameter + y_parameter;
	    	break;
		case Sub:
			result = x_parameter - y_parameter;
			break;
		case Mult :
			result = x_parameter * y_parameter;
			break;
		case Div:
			result = x_parameter / y_parameter;
			break;
		case Mod:
		default:
		result = 0;
    }
    y_param_set_flag=0;
	x_parameter = 0; 
    y_parameter = 0;
return result;

}

/**
	Backspace Pressed.

	This function removes the last character entered and updates the display
*/
void Backspace_Pressed(){
	if (DisplayCounter>1){
          DisplayStr[--DisplayCounter] = 0;
	  if(DisplayCounter == 1){
	      DisplayStr[1] = SPACE;	
	      DisplayStr[1] = ZERO;
              DisplayStr[2] = 0;
		}
	  displayParameter();
	}
}
/**
	This function converts the result (double) from the doMath() function into a string and displays the result
*/
void Display_Result(double fnum){
	int i,result;
	char* str;
	char buffer[20],doubleToStr[20];
	
	sprintf(doubleToStr, "%lf", fnum);
	if (fnum>0){
           buffer[0] = SPACE;
	   buffer[1] = '\0';	
	   strcat(buffer,doubleToStr);	
           strcpy(DisplayStr,buffer);
        }	
	else{
          strcpy(DisplayStr,doubleToStr);
        }
	displayParameter();
}
/**
	This function resets the calculator display string and counter
*/
void ResetDisplayVariables(){	
	int i;
	for(i=1;i<20;i++)
		DisplayStr[i]=0;
	
    DisplayStr[0]=SPACE;
        DisplayStr[1]=ZERO;
	DisplayCounter=1;
	
}
/**
	This function resets the global variables used in the doMath() function depending on param passed in.
	If param = Reset C was pressed
	If param = Clear, CE was pressed

	@param[in] 	param 	int 

*/
void CEorC_Pressed(int param){		
	if (param == RESET)
		x_parameter = 0;
	y_parameter=0;
	ResetDisplayVariables();
	displayParameter();
}

/**
	@internal

	routine and macro to easily convert a string to a resource ID

	@param[in] 	idString 	a pointer to const char

	@return uint32_t
	@retval id

*/
static uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        fprintf(stderr, APP_NAME ": Unknown resource ID string '%s'\n", idString);
        exit(1);        
    }
    return id;
}


/**
	@internal

	called to clean up the HxUI resources and system on application exit

*/
static void AtExit_UserInterface(void)
{
    HxResFileClose(spResFile);
    HxUiRelease();
    //free(spAppResourceDirString);
}
void math_button_pressed(int buttonID){
	if (y_param_set_flag == 0){
		Set_parameter(1);
		Math_Function = buttonID;
	}else{ 					
		Set_parameter(2);
		Display_Result(doMath());
		Math_Function = buttonID;
		Set_parameter(1); 					
	}				
	if(x_parameter!=0)
		ResetDisplayVariables();
}
/**
	@internal

	@brief this function handles the button press callback.  
 * 
 * @params pMessage			IN: pMessage  
 * @Params data				IN: data 
 *
 * @return 			    	HxResult

	@param[in] 	pMessage 	a pointer to const HxMessage_t
	@param[in,out] 	data 	a pointer to void

	@return HxResult
	@retval HX_OK

*/
static HxResult
HandleButtonPress(const HxMessage_t* pMessage, void* data)
{
    int32_t buttonID;
    int i;
    HxResult result = HxMessageGetSenderID (pMessage, &buttonID);
    if (result != HX_OK) return result;

    /* Check if the button pressed is from the about dialog */
	/* Check the buttonID */
    	switch (buttonID)
		{
			case cmdButton0:
			case cmdButton1: 
			case cmdButton2:
			case cmdButton3:
			case cmdButton4:
			case cmdButton5:
			case cmdButton6:
			case cmdButton7:
			case cmdButton8:
			case cmdButton9:
				if (DisplayStr[1]==ZERO && buttonID==cmdButton0){
				//beep
				}
				else{	
					DisplayStr[DisplayCounter++] = buttonID-52; //buttonid minus 52 gives the ascii value
					displayParameter(); 	
					if(x_parameter != 0 && y_param_set_flag == 0)
						y_param_set_flag = 1;
				}	
				break;
			case cmdButtonAdd:
			case cmdButtonSub:
			case cmdButtonMult: 
			case cmdButtonDiv:
				math_button_pressed(buttonID - 109);					
				break;
			case cmdButtonSqrt: 
				Set_parameter(1);
				if(x_parameter > 0)
					Display_Result(sqrt(x_parameter));	
				ResetDisplayVariables();
				x_parameter = 0;
				y_parameter = 0;
				break;
			case cmdButtonEquals:
				if(x_parameter==0)
					break;
				Set_parameter(2);
				Display_Result(doMath()); 
				ResetDisplayVariables();
				break;
			case cmdButton1x: 	
				Set_parameter(1);
				if(x_parameter==0)
					break;
				Display_Result(1/x_parameter);
				ResetDisplayVariables();
				x_parameter = 0;
				y_parameter = 0;
				break;
			case cmdButtonBsp: 	
				Backspace_Pressed();
				break;
			case cmdButtonC:
				CEorC_Pressed(RESET); 		
				break;
			case cmdButtonCE: 
				CEorC_Pressed(CLEAR);	
				break;
			case cmdButtonPeriod:
				Period_Pressed();				 
				break;
			case cmdButtonAddSub:
			        if(atof(DisplayStr)!=0){
				  if(DisplayStr[0]==MINUS){
                                    DisplayStr[0]=SPACE;
				  } 
				  else
				    DisplayStr[0]=MINUS;
				  displayParameter();		
				}
				break;
			case cmdButtonPerc: 
				if(x_parameter == 0){
					CEorC_Pressed(RESET);
				}else{
					Set_parameter(2);	
					y_parameter = y_parameter / 100;
					Display_Result(doMath()); 
					ResetDisplayVariables();
				}
				break;
								
			default:
				break;	
		}
    

    return HX_OK;
}

/**
	@internal

	@brief this function handles the keyboard callback if the key pressed has a cooresponding commandbutton  
 * 
 * @params pMessage			IN: pMessage  
 * @Params data				IN: data 
 *
 * @return 			    	HxResult

	@param[in] 	pMessage 	a pointer to const HxMessage_t
	@param[in,out] 	pData 	a pointer to void

	@return HxResult

*/
static HxResult KeyboardCallback( const HxMessage_t* pMessage, void* pData )
{
  	HxResult result = HX_OK;
	void* voidWinEvent = NULL;
	unsigned int size;

	result = HxMessageGetData( pMessage, &voidWinEvent, &size );
	HX_EXIT_IF_ERROR( HX_OK == result, result, error );

    HxInputEvent_t* winEvent = voidWinEvent;
    
    HX_ASSERT(result == HX_OK);
	// Process key down events only.
	if (winEvent->type == kHxEventKeyUp)
	{
		/* Check which key was pressed and respond accordingly */
		if(winEvent->keyModifiers==1){
			switch (winEvent->keySymbol)
			{
				//num key 0 through 9 pressed
				case ZERO:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57:
				case 58:
					if (DisplayStr[1]==ZERO && winEvent->keySymbol==ZERO){
						//beep
					}else{
					DisplayStr[DisplayCounter++] = winEvent->keySymbol;
						displayParameter();
					
						if(x_parameter != 0 && y_param_set_flag == 0)
							y_param_set_flag = 1; 	
					}
					break;
				case 8: //Backspace				
				case 127: // Delete
        	        Backspace_Pressed();
					break;				
				case 45: // -
					math_button_pressed(Sub);
					break;
				case 47:// /
    	            math_button_pressed(Div);
    	            break;
				case 61:// Equals pressed
                	if(x_parameter==0)
						break;
					Set_parameter(2);
					Display_Result(doMath()); 
					ResetDisplayVariables();
					break;
				case 27:// Escape button pressed
                	CEorC_Pressed(RESET);
					break;					
				case 46: // Period pressed
					Period_Pressed();
				default:
					break;
			}
		}else{
			if(winEvent->keyModifiers==2){
				switch(winEvent->keySymbol){
					case 43:// + this is the correct symbol but for the simulator
                	case 61:// we need to use this	
                		math_button_pressed(Add);                		
						break;
					case 42:// *
					case 56:
                		math_button_pressed(Mult);
                		break;			
                	case 37:// %
					case 53:
                		if(x_parameter == 0){
							CEorC_Pressed(RESET);
						}else{
							Set_parameter(2);	
							y_parameter = y_parameter / 100;
							Display_Result(doMath()); 
							ResetDisplayVariables();
						}
                		break;	
				}		
			}
		}
	}

error:

	return result;
}

/**
	@brief main!
 *
 *  @param argc				IN: number of command line parameters
 *  @param argv				IN: array of pointers to command line parameters 
 *
 *  @return int: 	              	return 0 (OK) or some HX error

	@param[in] 	argc 	int
	@param[in,out] 	argv 	a pointer to an array of char

	@return int
	@retval result

*/


int main (int argc, char* argv[])
{
    
    HxRectangle_t 		bounds;
    HxLabel_t*  		pLabel1 = NULL;
    HxLabel_t*  		pLabel2 = NULL;
    HxCommandButton_t* 	pCmdButton = NULL;
    HxMessageListener_t* 	spListener = NULL;
    HxResult 			result; 
    int 			id = 0;
    
    /* initialize the UI toolkit */
    result = HxUiInit(&pAppWindow, "dtshxcalculator");
    HX_ASSERT(HX_OK == result);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* load the menus from the hxui file */
    result = InitMenus(spResFile);
	HX_ASSERT(HX_OK == result);    
   	
    //Create a new field, this will be used for the calculators display
    bounds.x = 350;
    bounds.y = 100;
    bounds.w = 200;
    bounds.h = 25;
    result = HxFieldNew(kHxWidgetAutoID, (HxWidget_t*)pAppWindow, &bounds, NULL,
                kHxFieldNumeric,
                &pField);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);            
    
       
    // Create a commandbuttons for each key of the calculator
    /* Backspace*/                  
    bounds.x = 350;
    bounds.y = 130;
    bounds.w = 100;
    result = HxCommandButtonNew(cmdButtonBsp,(HxWidget_t*)pAppWindow,"Backspace",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);    
	/* CE*/
	bounds.x = 450;
    bounds.w = 50;
    result = HxCommandButtonNew(cmdButtonCE,(HxWidget_t*)pAppWindow,"CE",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* C*/
	bounds.x = 500;
	result = HxCommandButtonNew(cmdButtonC,(HxWidget_t*)pAppWindow,"C",
    								&bounds, &pCmdButton); 
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);   
    
    /* 7*/                  
    bounds.x = 350;
    bounds.y = 160;
    bounds.w = 40;
    result = HxCommandButtonNew(cmdButton7,(HxWidget_t*)pAppWindow,"7",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 8*/
	bounds.x = 390;
	result = HxCommandButtonNew(cmdButton8,(HxWidget_t*)pAppWindow,"8",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 9*/
	bounds.x = 430;
	result = HxCommandButtonNew(cmdButton9,(HxWidget_t*)pAppWindow,"9",
    								&bounds, &pCmdButton);	
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* / Divide*/    
    bounds.x = 470;
	result = HxCommandButtonNew(cmdButtonDiv,(HxWidget_t*)pAppWindow,"/",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* SpuareRoot*/
    bounds.x = 510;
	result = HxCommandButtonNew(cmdButtonSqrt,(HxWidget_t*)pAppWindow,"sqrt",
    								&bounds, &pCmdButton);																							   								        
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* 4*/                  
    bounds.x = 350;
    bounds.y = 190;
    bounds.w = 40;
    result = HxCommandButtonNew(cmdButton4,(HxWidget_t*)pAppWindow,"4",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 5*/
	bounds.x = 390;
	result = HxCommandButtonNew(cmdButton5,(HxWidget_t*)pAppWindow,"5",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 6*/
	bounds.x = 430;
	result = HxCommandButtonNew(cmdButton6,(HxWidget_t*)pAppWindow,"6",
    								&bounds, &pCmdButton);	
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* Multiple */
    bounds.x = 470;
	result = HxCommandButtonNew(cmdButtonMult,(HxWidget_t*)pAppWindow,"*",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* Percentage */    
    bounds.x = 510;
	result = HxCommandButtonNew(cmdButtonPerc,(HxWidget_t*)pAppWindow,"%",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    
    /* 1 */                  
    bounds.x = 350;
    bounds.y = 220;
    bounds.w = 40;
    result = HxCommandButtonNew(cmdButton1,(HxWidget_t*)pAppWindow,"1",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 2*/
	bounds.x = 390;
	result = HxCommandButtonNew(cmdButton2,(HxWidget_t*)pAppWindow,"2",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* 3 */
	bounds.x = 430;
	result = HxCommandButtonNew(cmdButton3,(HxWidget_t*)pAppWindow,"3",
    								&bounds, &pCmdButton);	
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* Minus */    
    bounds.x = 470;
	result = HxCommandButtonNew(cmdButtonSub,(HxWidget_t*)pAppWindow,"-",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* invert */    
    bounds.x = 510;
	result = HxCommandButtonNew(cmdButton1x,(HxWidget_t*)pAppWindow,"1/x",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);   
    
     																															
    /* 0 */                  
    bounds.x = 350;
    bounds.y = 250;
    bounds.w = 40;
    result = HxCommandButtonNew(cmdButton0,(HxWidget_t*)pAppWindow,"0",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* Positive/Negative */
	bounds.x = 390;
	result = HxCommandButtonNew(cmdButtonAddSub,(HxWidget_t*)pAppWindow,"+/-",
    								&bounds, &pCmdButton);         
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	
	/* Period */
	bounds.x = 430;
	result = HxCommandButtonNew(cmdButtonPeriod,(HxWidget_t*)pAppWindow,".",
    								&bounds, &pCmdButton);	
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* Plus */    
    bounds.x = 470;
	result = HxCommandButtonNew(cmdButtonAdd,(HxWidget_t*)pAppWindow,"+",
    								&bounds, &pCmdButton);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* Equals */
    bounds.x = 510;
	result = HxCommandButtonNew(cmdButtonEquals,(HxWidget_t*)pAppWindow,"=",
    								&bounds, &pCmdButton);
    HX_ASSERT(HX_OK == result);
    
	//Set the startup value of the display to 0
	DisplayStr[0]=SPACE;
	DisplayCounter=1;
        DisplayStr[DisplayCounter] = ZERO;    
	displayParameter();

    /* listen for all command button messages */
        result = HxMessageNewListener(&spListener);
	HX_ASSERT(HX_OK == result);
    /* listen for buttons in about dialog */
    result = result ||
        HxMessageListen(
            spListener,
            kHxActionMessageClass,
            kHxCommandButtonChanged,
            HandleButtonPress,
            NULL);
	HX_ASSERT(HX_OK == result);
    /* setup keyboard event listener */
	result = result ||
	    HxMessageListen(
	        spListener,
	        kHxInputMessageClass,
	        kHxKeyboardKeyGenerated,
	        KeyboardCallback,
	        NULL );
	HX_ASSERT(HX_OK == result);
    result = HxWidgetUpdate ((HxWidget_t*)pAppWindow, NULL);
    HX_ASSERT(HX_OK == result);

    /* enter the event loop */
    result = HxWindowEventLoop(pAppWindow, 0);

error:

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}

static HxResult 
InitMenus(HxResFile_t* pResFile)
{
    uint32_t id;
    HxMenu_t* pRootMenu;
    HxResult result;

	/* load the root menu and all the submenus */
    result = HxResFileLookupID(pResFile, "MenuRoot", &id);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	result = HxResFileNewRootMenu(pResFile, id, &pRootMenu, NULL);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /*
        Applications can call HxMessageListen, and provide a single callback
        for all menu items.  Alternatively, define callbacks that are targeted
        to particular menu items.
    */
    
	/* provide a callback for all menu messages */
	result = HxMessageListen(NULL, kHxActionMessageClass,
	                            kHxMenuItemIDSelected, MenuCallback, pResFile);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* provide a callback for the About Box menu item */
    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxMenuItemIDSelected, id,
                                MenuAboutBoxCallback, pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxMessageSenderID_t menuID;
    HxResult result;
    
    HX_NULL_PARAMETER_CHECK(pData);    
    HxResFile_t* pResFile = (HxResFile_t*)pData;
    
	result = HxMessageGetSenderID(pMessage, &menuID);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    if (menuID != id)
    {
        uint32_t button = 0;
        
        result = HxResFileLookupID(pResFile, "AlertNotImplemented", &id);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxResFileAlert(pResFile, id, NULL, NULL);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

error:

    return result;
}


static HxResult
MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxDialog_t* pDialog;
    HxWidget_t* pWidget;
    HxResult result;

    HX_NULL_PARAMETER_CHECK(pData);
    HxResFile_t* pResFile = (HxResFile_t*)pData;

    result = HxResFileLookupID(pResFile, "DialogAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileNewDialog(pResFile, id, &pDialog, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "AboutButtonOK", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxWidgetGetWidgetFromID(id, &pWidget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for the command button press */
    result = HxWidgetMapMessageCallback(pWidget,
                    kHxActionMessageClass, kHxCommandButtonChanged,
                    AboutCmdButtonCallback, pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxDialogShowAndWait(pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);

    return HxDialogDelete((HxDialog_t*)pData);
}

