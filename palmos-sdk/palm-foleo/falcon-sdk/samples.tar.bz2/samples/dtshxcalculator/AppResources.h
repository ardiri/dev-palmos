#ifndef APPRESOURCES_H_
#define APPRESOURCES_H_

#endif /*APPRESOURCES_H_*/
//
#define cmdButton0 		100
#define cmdButton1 		101
#define cmdButton2 		102
#define cmdButton3 		103
#define cmdButton4 		104
#define cmdButton5 		105
#define cmdButton6 		106
#define cmdButton7 		107
#define cmdButton8 		108
#define cmdButton9 		109
#define cmdButtonAdd 		110
#define cmdButtonSub 		111
#define cmdButtonMult 		112
#define cmdButtonDiv 		113
#define cmdButtonSqrt 		114
#define cmdButtonEquals 	115
#define cmdButton1x 		116
#define cmdButtonBsp 		117
#define cmdButtonC 		118
#define cmdButtonCE 		119
#define cmdButtonPeriod 	120
#define cmdButtonAddSub 	121
#define cmdButtonPerc 		122

