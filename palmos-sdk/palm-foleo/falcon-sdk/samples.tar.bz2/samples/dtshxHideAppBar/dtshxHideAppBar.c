/******************************************************************************
 * Copyright (c) 2004-2007 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/

/**
 * @brief This is a simple application that shows how to hide and then show the ApplicationBar
 *
 * @ingroup Samples
 * @file dtshxHideAppBar.c
 * <hr>
 **/


#include <hx/ui/hxui.h>
#include <locale.h>
#include "images.h"

#define RESID(x)    (LookupResID(#x))

HxResFile_t* pResFile;

static HxResult OpenResFile(const char** ppAppString, HxResFile_t** ppResFile);
static HxResult InitAppBar(void);
static HxResult InitMenus(HxResFile_t* pResFile);
static HxResult MenuCallback(const HxMessage_t* pMessage, void* pData);
static HxResult MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData);
static HxResult AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResult PressMeCmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static uint32_t LookupResID();

/**
	@internal

	routine and macro to easily convert a string to a resource ID

	@param[in] 	idString 	a pointer to const char

	@return uint32_t
	@retval id

*/
static uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(pResFile, idString, &id);
    if (result != HX_OK)
    {
        fprintf(stderr, "dtshxHideAppBar: Unknown resource ID string '%s'\n", idString);
        exit(1);        
    }
    return id;
}

/**
 *  @brief main!
 *
 *  @param argc				IN: number of command line parameters
 *  @param argv				IN: array of pointers to command line parameters 
 *
 *  @return int: 	              	return 0 (OK) or some HX error
 */
int main (int argc, char* argv[])
{
    const char* pAppString;
    HxWindow_t* pAppWindow;
    HxResult result;

    /* open the hxui file and get localized application name */
    result = OpenResFile(&pAppString, &pResFile);
   
    /* initialize the UI toolkit */
    result = HxUiInit(&pAppWindow, pAppString);
    HX_ASSERT(HX_OK == result);

    /* load a gadget in the application bar */
    result = InitAppBar();
    HX_ASSERT(HX_OK == result);

    /* load the menus from the hxui file */
    result = InitMenus(pResFile);
    HX_ASSERT(HX_OK == result);

    /* load a container with widgets */
    uint32_t id;
    result = HxResFileLookupID(pResFile, "ContainerOne", &id);
    HX_ASSERT(HX_OK == result);
    
    result = HxResFileLoadContainer(pResFile, id,
                                    (HxContainer_t*)pAppWindow, NULL);
    HX_ASSERT(HX_OK == result);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxCommandButtonChanged, RESID(PressmeButtonOK),
                                PressMeCmdButtonCallback, pResFile);
                                
    /* enter the event loop when ready for the user */
    result = HxWindowEventLoop(pAppWindow, 0 /* no timeout */);
    HX_ASSERT(HX_OK == result);

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}


static HxResult
OpenResFile(const char** ppAppString, HxResFile_t** ppResFile)
{
    HxResult result;
    size_t length;

    const char* APP_RES_FILE = "/dtshxHideAppBar.hxui";

    /* get the language string length */
    result = HxPropertyGetString(kHxPropertyLocaleLanguage, 0, NULL, &length);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* allocate the language string, and get the language property */
    {
        char pLocale[length];
        result = HxPropertyGetString(kHxPropertyLocaleLanguage, 0, pLocale,
                                        &length);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);

        /* setup localization based on property value -- LANG isn't set
         * correctly by the start-at-system-start code */
        setlocale(LC_ALL, pLocale);
    }

    /* open the resource file */
    {
        result = HxPropertyGetString(kHxPropertyResourcePath ,0, NULL, &length);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    	char pResFilePath[length + strlen(APP_RES_FILE) + 1];
        result = HxPropertyGetString(kHxPropertyResourcePath, 0, pResFilePath,
                                        &length);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        strcat(pResFilePath, APP_RES_FILE);

        result = HxResFileOpen(pResFilePath, ppResFile);
        if(result != HX_OK)
        {
            HX_ERROR_MESSAGE("Resource file (%s) not found\n", pResFilePath);
            goto error;
        }
    }

    /* get the app name string from the resource file */
    uint32_t id;
    result = HxResFileLookupID(*ppResFile, "IdAppName", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    result = HxResFileGetStringPtr(*ppResFile, id, ppAppString, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
InitAppBar(void)
{
    size_t length;
    HxWindow_t* pAppBar;
    HxImageDescription_t* pDescription;
    HxGadgetObject_t object;
    HxGadget_t* pGadget;
    HxRectangle_t bounds;
    HxResult result;

    result = HxApplicationBarGetWindow(&pAppBar);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    {
        result = HxPropertyGetString(kHxPropertyResourcePath, 0, NULL, &length);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        char pPath[length + strlen("/icon.png") + 1];
        result = HxPropertyGetString(kHxPropertyResourcePath, 0, pPath, &length);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);

        strcat(pPath, "/icon.png");
        result = HxImageDescriptionNewFromData (
              _FileListDocUnknown_on_normal_png_desc.width, 
              _FileListDocUnknown_on_normal_png_desc.width, 
              kHxPixelFormatRGB32,
              _FileListDocUnknown_on_normal_png_desc.preallocated[0].pitch, 
              _FileListDocUnknown_on_normal_png_data, 
                     &pDescription);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

    object.image.pImage = pDescription;
    object.type = kHxGadgetObjImage;
    object.x = 0;
    object.y = 0;

    result = HxImageDescriptionGetBounds(pDescription, &bounds);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxGadgetNew(kHxWidgetAutoID, (HxWidget_t*)pAppBar, &bounds, 1,
                            &object, kHxGadgetNoFocusRing, &pGadget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxApplicationBarAddWidget((HxWidget_t*)pGadget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult 
InitMenus(HxResFile_t* pResFile)
{
    uint32_t id;
    HxMenu_t* pRootMenu;
    HxResult result;

	/* load the root menu and all the submenus */
    result = HxResFileLookupID(pResFile, "MenuRoot", &id);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	result = HxResFileNewRootMenu(pResFile, id, &pRootMenu, NULL);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /*
        Applications can call HxMessageListen, and provide a single callback
        for all menu items.  Alternatively, define callbacks that are targeted
        to particular menu items.
    */
    
	/* provide a callback for all menu messages */
	result = HxMessageListen(NULL, kHxActionMessageClass,
	                            kHxMenuItemIDSelected, MenuCallback, pResFile);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* provide a callback for the About Box menu item */
    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxMenuItemIDSelected, id,
                                MenuAboutBoxCallback, pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxMessageSenderID_t menuID;
    HxResult result;
    
    HX_NULL_PARAMETER_CHECK(pData);    
    HxResFile_t* pResFile = (HxResFile_t*)pData;
    
	result = HxMessageGetSenderID(pMessage, &menuID);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    if (menuID != id)
    {
        uint32_t button = 0;
        
        result = HxResFileLookupID(pResFile, "AlertNotImplemented", &id);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxResFileAlert(pResFile, id, &button, NULL);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

error:

    return result;
}


static HxResult
MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxDialog_t* pDialog;
    HxWidget_t* pWidget;
    HxResult result;

    HX_NULL_PARAMETER_CHECK(pData);
    HxResFile_t* pResFile = (HxResFile_t*)pData;

    result = HxResFileLookupID(pResFile, "DialogAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileNewDialog(pResFile, id, &pDialog, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "AboutButtonOK", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxWidgetGetWidgetFromID(id, &pWidget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for the command button press */
    result = HxWidgetMapMessageCallback(pWidget,
                    kHxActionMessageClass, kHxCommandButtonChanged,
                    AboutCmdButtonCallback, pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxDialogShowAndWait(pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);

    return HxDialogDelete((HxDialog_t*)pData);
}

static HxResult
PressMeCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);
	bool pVisible = 0;
	// API Call to get appbar visibility
	HxResult result = HxApplicationBarGetVisible (&pVisible);
	HX_ASSERT(result == HX_OK);
	// Depending on visibility make API call to hide or show ApplicationBar
	if(pVisible){
    	return HxApplicationBarShow(false);
    }else{
    	return HxApplicationBarShow(true);	
    }	
}

