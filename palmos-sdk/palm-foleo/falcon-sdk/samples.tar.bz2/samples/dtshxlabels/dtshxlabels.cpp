/**
 *  @brief 
 *
 *  HxLabel is a positive API testing of hxlabel.h. The test covers
 *  all functions calls defined in the hxlabel API.  Different labels
 *  are drawn on screen according to their set attributes and colors.
 *
 * @ingroup Samples 
 * @file dtshxlabels.cpp
 * <hr>
 */
 
#include "dtshxlabels.h"
#include <locale.h>
#include <iostream>

static HxResult OpenResFile(const char** ppAppString, HxResFile_t** ppResFile);
static HxResult InitAppBar(void);
static HxResult InitMenus(HxResFile_t* pResFile);
static HxResult MenuCallback(const HxMessage_t* pMessage, void* pData);
static HxResult MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData);
static HxResult AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData);

using namespace std;


#define APP_RES_FILE             "Resources/dtshxlabels.hxui"
#define APP_NAME                 "dtshxlabels"

#define RESID(x) (LookupResID(#x))

static HxMessageListener_t       *spMenuListener = NULL;
static HxMessageListener_t       *spButtonListener = NULL;
static HxDialog_t                *spAboutDialog = NULL;
static HxResFile_t               *spResFile = NULL;
static HxMenu_t                  *spRootMenu = NULL;

HxWindow_t* pAppWindow = NULL;

//Array of ID numbers for each label
const int HxLabel::labelId [7] = {0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d };

/** 
 *  @brief default Constructor for the Label Class.  Instantiates a label 
 * entity 
 */
HxLabel::HxLabel() 
{
    handle = NULL;
    label1 = NULL;
    label2 = NULL;
    label3 = NULL;
    label4 = NULL;
    label5 = NULL;
    label6 = NULL;
    label7 = NULL;
    idCount = 0;
}

/** 
 * @brief default destructor for the Label Class.  Instantiates a label 
 * entity 
 */
HxLabel::~HxLabel() {}

/** 
 * @brief returns a HxRectangle_t who is assigned the passed in args
 *
 * @params int x 			IN: x coord of origin  
 * @params int y 			IN: y coord of origin 
 * @params int w 			IN: width of rect 
 * @params int h 			IN: height of rect 
 *
 * @return			return initialize HxRectangle_t	
 */
HxRectangle_t HxLabel::getBounds(int x, int y, int w, int h)
{
	bounds.x = x;
    bounds.y = y;
    bounds.w = w;
    bounds.h = h;

    return bounds;
}

/** 
 * @brief Creates a new Label with the specified HxRectangle_t, HxWindow_t, 
 * and title 
 *
 * @params int bounds 			IN: Rectangle bounding label 
 * @params int pAppWindow 		IN: Widget to place the label into
 * @params char *title 			IN: string title 
 *
 * @return			returns pointer to HxLabel_t
 */
HxLabel_t* HxLabel::newLabel(HxRectangle_t bounds, HxWindow_t* pAppWindow, char *title)
{
	HxLabelNew (labelId[idCount], (HxWidget_t*)pAppWindow, &bounds, NULL,
                            title, &handle);
     	idCount++;
     	return handle;
}

/** 
 * @brief draws a set of labels
 *
 * @return void 
 */
void HxLabel::drawLabels(void)
{
    HxResult result;
    HxTextFlags_t attributes, gAttributes;
    HxColor_t color, gColor;
    HxFont_t* pFont;
	
	//API call to crete new label
	label1 = newLabel(getBounds(10, 10, 200, 50), pAppWindow, "Default");
    // API call to delete label
    HxLabelDelete(label1);
    cout << "Default label deleted" << endl;

    label1 = newLabel(getBounds(20, 20, 200, 100), pAppWindow, "New Default");
	label2 = newLabel(getBounds(40, 40, 200, 100), pAppWindow, "Center Aligned");
    label3 = newLabel(getBounds(40, 70, 200, 100), pAppWindow, "Right Aligned");
    label4 = newLabel(getBounds(40, 130, 200, 100), pAppWindow, "Left Aligned");

	//API call to set text for Label1
	HxLabelSetText(label1, "Set New Default Text");

	color.a = 0xff;
	color.r = 0xff;
	color.g = 0x00;
	color.b = 0x00;
	//Set text flags
	attributes = (HxTextFlags_t) (kHxTextCenterAlign | kHxTextOriginTop);
	//API call to set attributes for Label2
	result = HxLabelSetAttributes (label2, attributes);
	HX_ASSERT(HX_OK == result);
	//API call to set text color for label2
	result = HxLabelSetColor (label2, &color);
	HX_ASSERT(HX_OK == result);
   
	color.r = 0x00;
	color.g = 0xaa;
	attributes = (HxTextFlags_t) (kHxTextRightAlign | kHxTextOriginTop);
	result = HxLabelSetAttributes (label3, attributes);
	if(result == HX_OK)
	{
		result = HxLabelGetAttributes(label3, &gAttributes);
		if (result == HX_OK)
		{
			label6 = newLabel(getBounds(40, 90, 200, 100), pAppWindow,
                                "Right Aligned Attributes");
			HxLabelSetAttributes (label6, gAttributes);
		}
	}
	result = HxLabelSetColor (label3, &color);
	if(result == HX_OK)
	{
		result = HxLabelGetColor(label3, &gColor);
		if (result == HX_OK)
		{
			label7 = newLabel(getBounds(90, 110, 200, 100), pAppWindow, "Right Aligned Color");
			HxLabelSetColor (label7, &gColor);
		}
	}

	HX_ASSERT(HX_OK == result);

	attributes = (HxTextFlags_t) (kHxTextLeftAlign | kHxTextOriginBottom);
	color.g = 0x00;
	color.b = 0xaa;
	result = HxLabelSetColor (label4, &color);
	HX_ASSERT(HX_OK == result);

    //result = HxFontLoadDefaultSize(14, &pFont);
    result = HxFontLoad(kHxFontDefault, 14, kHxFontPlain, kHxFontAttrNone, NULL, &pFont);

    bounds.x = 200;
    bounds.y = 200;

    result = HxLabelNew (labelId[idCount], (HxWidget_t*)pAppWindow, &bounds, pFont,
                            "Size 14 font", &label5);
    HX_ASSERT(HX_OK == result);
}

/*
 * routine to easily convert a string to a resource ID
 *
**/
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        printf(": Unknown resource ID string '%s'\n", idString);
        exit(1);
     }
    return id;
}
static HxResult 
InitMenus(HxResFile_t* pResFile)
{
    uint32_t id;
    HxMenu_t* pRootMenu;
    HxResult result;

	/* load the root menu and all the submenus */
    result = HxResFileLookupID(pResFile, "MenuRoot", &id);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	result = HxResFileNewRootMenu(pResFile, id, &pRootMenu, NULL);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /*
        Applications can call HxMessageListen, and provide a single callback
        for all menu items.  Alternatively, define callbacks that are targeted
        to particular menu items.
    */
    
	/* provide a callback for all menu messages */
	result = HxMessageListen(NULL, kHxActionMessageClass,
	                            kHxMenuItemIDSelected, MenuCallback, pResFile);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* provide a callback for the About Box menu item */
    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxMenuItemIDSelected, id,
                                MenuAboutBoxCallback, pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxMessageSenderID_t menuID;
    HxResult result;
    
    HX_NULL_PARAMETER_CHECK(pData);    
    HxResFile_t* pResFile = (HxResFile_t*)pData;
    
	result = HxMessageGetSenderID(pMessage, &menuID);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    if (menuID != id)
    {
        uint32_t button = 0;
        
        result = HxResFileLookupID(pResFile, "AlertNotImplemented", &id);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxResFileAlert(pResFile, id, &button, NULL);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

error:

    return result;
}


static HxResult
MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxDialog_t* pDialog;
    HxWidget_t* pWidget;
    HxResult result;

    HX_NULL_PARAMETER_CHECK(pData);
    HxResFile_t* pResFile = (HxResFile_t*)pData;

    result = HxResFileLookupID(pResFile, "DialogAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileNewDialog(pResFile, id, &pDialog, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "AboutButtonOK", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxWidgetGetWidgetFromID(id, &pWidget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for the command button press */
    result = HxWidgetMapMessageCallback(pWidget,
                    kHxActionMessageClass, kHxCommandButtonChanged,
                    AboutCmdButtonCallback, pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxDialogShowAndWait(pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);

    return HxDialogDelete((HxDialog_t*)pData);
}

int main (int argc, char* argv[])
{
    HxLabel label;
    HxResult result;

    // Init UI interface
    HxUiInit(&pAppWindow, _("dtshxlabel"));

    label.drawLabels();	
 
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_ASSERT(HX_OK == result);

    /* load the menus from the hxui file */
    result = InitMenus(spResFile);
	HX_ASSERT(HX_OK == result);
    
    /* enter the event loop when ready for the user */
    HxWindowEventLoop(pAppWindow, 0 /* no timeout */);
 
	/* close up the UI toolkit */
    HxUiRelease();
    return 1;
}
