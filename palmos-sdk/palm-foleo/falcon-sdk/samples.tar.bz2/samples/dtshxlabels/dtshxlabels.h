/**
 * @brief  
 *
 * Header file the HxLabel.cpp class
 *
 * @ingroup Samples 
 * @file dtshxlabels.h
 * <hr>
 */

#ifndef HXLABEL_H
#define HXLABEL_H

// explicitly include macros defined in stdint.h
#define __STDC_LIMIT_MACROS

// Header files for HxLabel
#include <stddef.h>
#include <hx/ui/hxwindow.h>
#include <hx/ui/hxlabel.h>
#include <hx/ui/hxui.h>
#include <hx/ui/hxgraphics.h>
#include <hx/ui/hxfont.h>

// Rest of SDK files
#include <hx/ui/hxui.h>

#include <lite/button.h>
#include <lite/cursor.h>
#include <lite/event.h>
#include <lite/font.h>
#include <lite/image.h>
#include <lite/label.h>
#include <lite/lite.h>
#include <lite/slider.h>
#include <lite/theme.h>
#include <lite/util.h>

using namespace std;


//HxLabel Class
class HxLabel
{
public:
    HxLabel();
    ~HxLabel();
    HxRectangle_t getBounds(int x, int y, int w, int h);
    HxLabel_t* newLabel(HxRectangle_t bounds, HxWindow_t* pAppWindow, char * title);
    void drawLabels(void);
private:
    HxLabel_t* handle;
    HxRectangle_t bounds;
    HxLabel_t* label1;
    HxLabel_t* label2;
    HxLabel_t* label3;
    HxLabel_t* label4;
    HxLabel_t* label5;
    HxLabel_t* label6;
    HxLabel_t* label7;
    int idCount;
    static const int labelId[7];
};

#endif

