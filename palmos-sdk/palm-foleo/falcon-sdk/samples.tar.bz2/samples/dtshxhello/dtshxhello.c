/**
 * @brief This file contains a simple hello world application. Includes a 
 * menu with quit option and an about dialog 
 *
 * @ingroup dtshxhello 
 * @file dtshxhello.c
 * <hr>
 **/

#include <hx/ui/hxui.h>
#include <hx/ui/hxwindow.h>
#include <hx/ui/hxlabel.h>
#include <hx/ui/hxresfile.h>

#define HELLO_LABEL_ID   0x67
#define HELLO_ROOTMENU         1000
#define HELLO_MENU_CMD_ABOUT   1001
#define HELLO_MENU_CMD_QUIT    1002
#define HELLO_ABOUT_DIALOG     2000
#define HELLO_ABOUT_BUTTON_OK  2001

HxResFile_t  *pResFile = NULL;
HxMenu_t     *pRootMenu = NULL;
HxMessageListener_t *pListener = NULL;
HxMessageListener_t *pButtonListener = NULL;
HxDialog_t    *pAboutDialog = NULL;

static void cleanup_hxhello(void);

const char resource_file[] =
"<?xml version='1.0' encoding='UTF-8'?>\n"
"<!DOCTYPE hxui SYSTEM 'hxui_1.0.dtd'>\n"
"<hxui version='1.0' default_locale='en_US'>\n"
" <root_menu id='1000'>\n"
"  <submenu id='$AUTO'>\n"
"   <text>File</text>\n"
"   <menu_item id='1001' shortcut='A'>\n"
"    <text>About hxhello...</text>\n"
"   </menu_item>\n"
"  </submenu>\n"
" </root_menu>\n"
"<dialog id='2000'>\n"
" <text>About dtshxhello</text>\n"
" <label id='$AUTO'>\n"
"  <pos x='100' y='10'/><size w='220' h='26'/>\n"
"  <text>dtshxhello - 1.0.2</text>\n"
"  <font point_size='16' weight='bold' />\n"
" </label>\n"
"<gadget id='$AUTO'>\n"
"            <pos x='20' y='20' />\n"
"            <size w='54' h='54' />\n"
"            <graphic_object>\n"
"                <pos x='0' y='0' />\n"
"                <image file='Resources/logo_palm.png' />\n"
"            </graphic_object>\n"
"        </gadget>\n"
" <label id='$AUTO'>\n"
"  <pos x='100' y='36'/><size w='220' h='16'/>\n"
"  <text>a simple hello application!</text>\n"
" </label>\n"
" <label id='$AUTO'>\n"
"  <pos x='100' y='52'/><size w='220' h='16'/>\n"
"  <text>Copyright 2007, Palm, Inc.</text>\n"
" </label>\n"
" <command_button id='2001'>\n"
"   <text>OK</text>\n"
" </command_button>\n"
"</dialog>\n"
"</hxui>";

#define HW_GADGET_PICFRAME  500

static HxResult
HandleButtonPress(const HxMessage_t* pMessage, void* data)
{
    int32_t buttonID;
    HxResult result = HxMessageGetSenderID (pMessage, &buttonID);
    if (result != HX_OK) return result;

    fprintf(stderr, "HxHello: HandleButtonPress from buttonID %d\n", buttonID);

    if (buttonID == HELLO_ABOUT_BUTTON_OK)
    {
        HxDialogDelete(pAboutDialog);
        pAboutDialog = NULL;
    }

    return HX_OK;
}


static HxResult
HandleMenuCommand(const HxMessage_t* pMessage, void* data)
{
    int32_t menuid;
    int32_t itemid;
    int32_t size = sizeof(int32_t);

    HxResult result;
    
    result = HxMessageGetSenderID (pMessage, &menuid);
    result = result || HxMessageGetData(pMessage, (void *)&itemid, &size);
    if (result != HX_OK) return result;

    fprintf(stderr, "HOLLYVIEW: HandleMenuCommand, menuid = %d, itemid = %d\n", menuid, itemid);

    switch (itemid)
    {
        case HELLO_MENU_CMD_ABOUT:
        {
            result = HxResFileNewDialog(pResFile, HELLO_ABOUT_DIALOG, &pAboutDialog, NULL);
            result = result || HxDialogShow(pAboutDialog, true);
            return result;
        }

        case HELLO_MENU_CMD_QUIT:
            cleanup_hxhello();
    }
               
    return HX_OK;
}

int main (int argc, char* argv[])
{
    HxWindow_t* pAppWindow = NULL;
    HxLabel_t*  helloLabel = NULL;
    HxRectangle_t bounds;
    HxResult result;

   
    /* Initialize the UI toolkit and create new window. */
    result = HxUiInit(&pAppWindow, "hxhello");
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    bounds.x = 200;
    bounds.y = 200;
    bounds.w = 100;
    bounds.h = 20;

    result = HxLabelNew (HELLO_LABEL_ID, (HxWidget_t*)pAppWindow, 
             &bounds, NULL, "Hello World", &helloLabel);
    HX_ASSERT(HX_OK == result);

    /* open the in-memory resource file */
    result = HxResFileOpenBuffer(resource_file, NULL, &pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* setup the root menu for the app */
    result = HxResFileNewRootMenu(pResFile, HELLO_ROOTMENU, &pRootMenu, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* nothing takes focus here */
    result = HxWidgetSetFocusArray(NULL, 0);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* setup listeners for menu items and about dialog */
    result = HxMessageNewListener(&pListener);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageNewListener(&pButtonListener);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = result ||
        HxMessageListen(
            pListener,
            kHxActionMessageClass,
            kHxMenuSelected,
            HandleMenuCommand,
            NULL);
    
    result = result ||
        HxMessageListen(
            pListener,
            kHxActionMessageClass,
            kHxCommandButtonChanged,
            HandleButtonPress,
            NULL);

    /* Enter the event loop when ready for the user. */
    result = HxWindowEventLoop(pAppWindow, 0 /* no timeout */);
    HX_ASSERT(HX_OK == result);

error:

    /* Close up the UI toolkit & close application window. */
    result = HxUiRelease();

    return result;
}


static void cleanup_hxhello(void)
{
    HxResFileClose(pResFile);
    HxUiRelease();
}

