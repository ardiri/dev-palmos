/**
	Copyright (c) 2005 Palm, Inc. or its subsidiaries.
 * All rights reserved.

*/


/**
 * @brief  This sample includes a simple image view program.  It includes 
 * a demonstration of how to load an image via an image description.  It also 
 * demonstrates menus
 *
 * @ingroup dtshxdisplayimage samples 
 * @file dtshxdisplayimage.c
 * 
 * <hr>
 **/

#include <stdlib.h>
#include <string.h>

#include <stddef.h>
#include <stdlib.h>
#include <string.h>

#include <glib-2.0/glib/gstring.h>
#include <glib-2.0/glib/gmem.h>

#include <hx/hx.h>
#include <hx/ui/hxui.h>

#define	APP_NAME		"dtshxdisplayimage"

const char resource_file[] =
"<?xml version='1.0' encoding='UTF-8'?>\n"
"<!DOCTYPE hxui SYSTEM 'hxui_1.0.dtd'>\n"
"<hxui version='1.0' default_locale='en_US'>\n"
" <root_menu id='1000'>\n"
"  <submenu id='$AUTO'>\n"
"   <text>File</text>\n"
"   <menu_item id='1001' shortcut='A'>\n"
"    <text>About dtshxdisplayimage...</text>\n"
"   </menu_item>\n"
"   <menu_separator id='$AUTO'/>\n"
"   <menu_item id='1002' shortcut='Q'>\n"
"    <text>Quit dtshxdisplayimage</text>\n"
"   </menu_item>\n"
"   <menu_separator id='$AUTO'/>\n"
"   <menu_item id='1003' shortcut='O'>\n"
"    <text>Load Image</text>\n"
"   </menu_item>\n"
"  </submenu>\n"
" </root_menu>\n"
"<dialog id='2000'>\n"
" <pos x='280' y='180'/><size w='240' h='115'/>\n"
" <text>About dtshxdisplayimage</text>\n"
" <label id='$AUTO'>\n"
"  <pos x='10' y='10'/><size w='220' h='26'/>\n"
"  <text>dtshxdisplayimage</text>\n"
"  <font point_size='16' weight='bold' />\n"
" </label>\n"
" <label id='$AUTO'>\n"
"  <pos x='10' y='36'/><size w='220' h='16'/>\n"
"  <text>a quick and dirty image viewer</text>\n"
" </label>\n"
" <label id='$AUTO'>\n"
"  <pos x='10' y='52'/><size w='220' h='16'/>\n"
"  <text>Copyright 2007, Palm, Inc.</text>\n"
" </label>\n"
" <command_button id='2001'>\n"
"   <pos x='7' y='81'/>\n"
"   <text>OK</text>\n"
" </command_button>\n"
"</dialog>\n"
"</hxui>";

#define HW_GADGET_PICFRAME  500
#define HV_ROOTMENU         1000
#define HV_MENU_CMD_ABOUT   1001
#define HV_MENU_CMD_QUIT    1002
#define HV_MENU_CMD_OPEN    1003
#define HW_ABOUT_DIALOG     2000
#define HW_ABOUT_BUTTON_OK  2001

static HxResFile_t *spResFile = NULL;
static HxMenu_t *spRootMenu = NULL;
static HxMessageListener_t* spListener = NULL;
static HxDialog_t *spAboutDialog = NULL;
static HxWindow_t *spAppWindow = NULL;
static char *pFilename = NULL;

static HxResult
HandleButtonPress(const HxMessage_t* pMessage, void* data)
{
    int32_t buttonID;
    HxResult result = HxMessageGetSenderID (pMessage, &buttonID);
    if (result != HX_OK) return result;

    fprintf(stderr, "HOLLYVIEW: HandleButtonPress from buttonID %d\n", buttonID);

    if (buttonID == HW_ABOUT_BUTTON_OK)
    {
        HxDialogDelete(spAboutDialog);
        spAboutDialog = NULL;
    }

    return HX_OK;
}

HxResult SetupImageData(char *pFilename)
{
    HxResult result = HX_OK;
    /* setup the picture view gadget */
    HxRectangle_t bounds;
    result = HxWindowGetBounds(spAppWindow, &bounds);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* load the image */
    HxImageDescription_t* pDescription;
    result = HxImageDescriptionNewFromFile(pFilename, &pDescription);
    
    if(result != HX_OK)
	 return HX_INVALID_ARG;

    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    HxRectangle_t imageBounds;
    result = HxImageDescriptionGetBounds(pDescription, &imageBounds);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* if picture is too large, remove app bar to allow full screen display */
    if (imageBounds.h > bounds.h)
    {
        result = HxApplicationBarShow(false);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxWindowGetBounds(spAppWindow, &bounds);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

    // position gadget at top-left of app window
    bounds.x = bounds.y = 0;

    // create the image object
    HxGadgetObject_t newImageObj;
    newImageObj.type = kHxGadgetObjImage;
    newImageObj.image.pImage = pDescription;

    // center it inside the gadget or pin it to top left if its too large
    newImageObj.x = MAX(0, (bounds.w - imageBounds.w) / 2);
    newImageObj.y = MAX(0, (bounds.h - imageBounds.h) / 2);

    /* create gadget with one object */
    HxGadget_t *pPictureFrame;
    result = HxGadgetNew(HW_GADGET_PICFRAME, (HxWidget_t*)spAppWindow, &bounds, 
        1, &newImageObj, false, &pPictureFrame);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    goto out; 
error:
    /* close the in-memory resource file */
    result = HxResFileClose(spResFile);

    /* close up the UI toolkit */
    HxUiRelease();
out: 
    return result;
}

/**
	@internal

	Brief description needed.

	Followed by a more complete description.

	@param[in] 	pMessage 	a pointer to const HxMessage_t
	@param[in,out] 	data 	a pointer to void

	@return HxResult
	@retval HX_OK
	@retval result

	@todo edit me (automatically generated by insertdox)
*/
static HxResult
HandleMenuCommand(const HxMessage_t* pMessage, void* data)
{
    int32_t menuid;
    int32_t itemid;
    int32_t size = sizeof(int32_t);

    HxResult result;
    
    result = HxMessageGetSenderID (pMessage, &menuid);
    result = result || HxMessageGetData(pMessage, (void *)&itemid, &size);
    if (result != HX_OK) return result;

    fprintf(stderr, "HOLLYVIEW: HandleMenuCommand, menuid = %d, itemid = %d\n", menuid, itemid);

    switch (itemid)
    {
        case HV_MENU_CMD_ABOUT:
        {
            result = HxResFileNewDialog(spResFile, HW_ABOUT_DIALOG, &spAboutDialog, NULL);
            result = result || HxDialogShow(spAboutDialog, true);
            return result;
        }

        case HV_MENU_CMD_QUIT:
            exit(1);
        case HV_MENU_CMD_OPEN:
	{
            char                         *pfile = NULL;
	    HxFileDialogButtonType_t     selection; 
popalert:
	    result = HxFileDialog("Select Image", kFileDialogOpen, NULL, 
			    &pfile, &selection);
	    if(selection == kHxFileDialogButtonSelect)
	    {
                if(!pfile || (HX_INVALID_ARG == SetupImageData(pfile)))
		{
                    HxImageDescription_t *pAlertIcon = NULL;
                    result = HxAlertGetIcon(kHxAlertSystemIcon,&pAlertIcon);

                    result = HxAlert(kHxWidgetAutoID, kHxAlertStyleOK, 
				    pAlertIcon, "Invalid Image File!",
				    "Please select a valid png or jpg file", 
				    NULL);
		    free(pfile);
                    goto popalert;
		}
	        free(pfile);	
	    } 

	}
    }
               
    return HX_OK;
}

/**
	@internal

	Brief description needed.

	Followed by a more complete description.

	@todo edit me (automatically generated by insertdox)
*/
static void cleanup_hollyview(void)
{
    HxResFileClose(spResFile);
    HxUiRelease();
}

/**
	Brief description needed.

	Followed by a more complete description.

	@param[in] 	argc 	int
	@param[in,out] 	argv 	a pointer to an array of char

	@return int
	@retval result
	@retval 0

	@todo edit me (automatically generated by insertdox)
*/
int main (int argc, char* argv[])
{
    HxResult result = HX_OK;

    /* initialize the UI toolkit */

    GString *title;
    title = g_string_new("");
    g_string_printf(title, "%s: %s", _(APP_NAME), "Display Image");

    result = HxUiInit(&spAppWindow, title->str);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    g_string_free(title, true);

    /* open the in-memory resource file */
    result = HxResFileOpenBuffer(resource_file, NULL, &spResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* register cleanup function */
    atexit(cleanup_hollyview);


    /* setup the root menu for the app */
    result = HxResFileNewRootMenu(spResFile, HV_ROOTMENU, &spRootMenu, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* nothing takes focus here */
    result = HxWidgetSetFocusArray(NULL, 0);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* setup listeners for menu items and about dialog */
    result = HxMessageNewListener(&spListener);

    result = result ||
        HxMessageListen(
            spListener,
            kHxActionMessageClass,
            kHxCommandButtonChanged,
            HandleButtonPress,
            NULL);

    result = result ||
        HxMessageListen(
            spListener,
            kHxActionMessageClass,
            kHxMenuSelected,
            HandleMenuCommand,
            NULL);

    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* enter event loop */
    result = HxWindowEventLoop(spAppWindow, 0);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:
    /* close the in-memory resource file */
    result = HxResFileClose(spResFile);

    /* close up the UI toolkit */
    HxUiRelease();

    return result;
}
