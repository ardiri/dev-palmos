/**
 * @brief This sample shows how to open a HollyMail email and pre-fill the fields
 *
 * @ingroup Samples
 * @file dtshxprepopemail.c
 * <hr>
 **/
 

#define Err 1
#define APP_RES_FILE "Resources/dtshxprepopemail.hxui"

#include <hx/ui/hxui.h>
#include <locale.h>
/*********************************************************************/

static HxResult 	InitMenus(HxResFile_t* pResFile);
static HxResult 	MenuCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	CmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResFile_t 	*spResFile = NULL;

/************************************************************************/

HxWindow_t* pAppWindow = NULL;

/*
 * routine to easily convert a string to a resource ID
 *
**/
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        printf(": Unknown resource ID string '%s'\n", idString);
        exit(1);
     }
    return id;
}

/**
 *  
 * macro to easily convert a string to a resource ID
 * 
 **/
#define RESID(x) (LookupResID(#x))
/**
 *  @brief main!
 *
 *  @param argc				IN: number of command line parameters
 *  @param argv				IN: array of pointers to command line parameters 
 *
 *  @return int: 	              	return 0 (OK) or some HX error
 */
int main (int argc, char* argv[])
{
    HxMessageListener_t* spListener = NULL;
    HxResult result;       
    
    /* initialize the UI toolkit */
    result = HxUiInit(&pAppWindow, "dtshxprepopemail");
    HX_ASSERT(HX_OK == result);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* load the menus from the hxui file */
    result = InitMenus(spResFile);
	HX_ASSERT(HX_OK == result);
	
    /* load a container with widgets */
    result = HxResFileLoadContainer(spResFile, RESID(ContainerOne),
                                    (HxContainer_t*)pAppWindow, NULL);
	HX_ASSERT(HX_OK == result);
	
	/* listen for messages */
    result = HxMessageNewListener(&spListener);
    HX_ASSERT(HX_OK == result);
    
   
    result = HxMessageListenFrom(NULL,kHxActionMessageClass, kHxCommandButtonChanged, RESID(ButtonPressMe),
        CmdButtonCallback, NULL);
    HX_ASSERT(HX_OK == result);
    
    /* enter the event loop */
    result = HxWindowEventLoop(pAppWindow, 0);

error:

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}
/** Call back function iniated when "GetQuote" button is pressed*/
static HxResult
CmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HxResult result;    
	HxMIMEScheme_t   scheme = "mailto";
	HxMIMEVerb_t   mimeVerb = "com.palm.open";
	const char *path ="enda.mcgrath@palm.com?cc=devsupport@palm.com&subject=test subject&body=This is the bodytest";
	const char *name ="";
	
	result = HxApplicationLaunchScheme (scheme,mimeVerb,path,name);
    HX_ASSERT(result == HX_OK);                            
	
}
static HxResult 
InitMenus(HxResFile_t* pResFile)
{
    uint32_t id;
    HxMenu_t* pRootMenu;
    HxResult result;

	/* load the root menu and all the submenus */
    result = HxResFileLookupID(pResFile, "MenuRoot", &id);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	result = HxResFileNewRootMenu(pResFile, id, &pRootMenu, NULL);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /*
        Applications can call HxMessageListen, and provide a single callback
        for all menu items.  Alternatively, define callbacks that are targeted
        to particular menu items.
    */
    
	/* provide a callback for all menu messages */
	result = HxMessageListen(NULL, kHxActionMessageClass,
	                            kHxMenuItemIDSelected, MenuCallback, pResFile);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* provide a callback for the About Box menu item */
    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxMenuItemIDSelected, id,
                                MenuAboutBoxCallback, pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxMessageSenderID_t menuID;
    HxResult result;
    
    HX_NULL_PARAMETER_CHECK(pData);    
    HxResFile_t* pResFile = (HxResFile_t*)pData;
    
	result = HxMessageGetSenderID(pMessage, &menuID);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    if (menuID != id)
    {
        uint32_t button = 0;
        
        result = HxResFileLookupID(pResFile, "AlertNotImplemented", &id);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxResFileAlert(pResFile, id, &button, NULL);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

error:

    return result;
}


static HxResult
MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxDialog_t* pDialog;
    HxWidget_t* pWidget;
    HxResult result;

    HX_NULL_PARAMETER_CHECK(pData);
    HxResFile_t* pResFile = (HxResFile_t*)pData;

    result = HxResFileLookupID(pResFile, "DialogAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileNewDialog(pResFile, id, &pDialog, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "AboutButtonOK", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxWidgetGetWidgetFromID(id, &pWidget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for the command button press */
    result = HxWidgetMapMessageCallback(pWidget,
                    kHxActionMessageClass, kHxCommandButtonChanged,
                    AboutCmdButtonCallback, pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxDialogShowAndWait(pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);

    return HxDialogDelete((HxDialog_t*)pData);
}
