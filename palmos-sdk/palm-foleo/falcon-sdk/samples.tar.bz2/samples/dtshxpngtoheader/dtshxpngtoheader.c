/**
 * @brief  This file contains sample routines for including a png image in an 
 * application.  This is an optimization for the loading of images.  It is 
 * ideal for loading application icons/images programmatically via a data
 * structure defined in a .h file.  There is an alternate method to load images
 * via the HxImageDescription data structure which is more cpu-intensive. 
 *
 * From a command line please run 
 * /opt/holly/sysroot/i386-linux/usr/bin/i386-linux-directfb-csource or  
 * --name=lock Resources/lock_icon.png > lock.h
 *
 * Then include lock.h as a header file in your application
 *
 * @ingroup sample 
 * @file dtshxpngtoheader.c
 * <hr>
 **/

#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <locale.h>
#include <pthread.h>
#include <sys/types.h>
#include <time.h>

#include <glib-2.0/glib/glist.h> 

#include <hx/hx.h>

#include <hx/ui/hxwidget.h>
#include <hx/hxproperty.h>
#include <hx/ui/hximage.h>
#include <hx/ui/hxuiinit.h>
#include <hx/ui/hxresfile.h>
#include <hx/ui/hxgraphics.h>
#include <hx/ui/hxapplicationbar.h>
#include <hx/ui/hxcontainer.h>

#include "lock.h"

static HxResFile_t *spResFile = NULL;
HxWindow_t *AppWindow = NULL;
HxImageDescription_t *pDescription = NULL;
HxRectangle_t Image_Window = { 50, 100, 300, 200 };
HxContainer_t *TheContainer = NULL;
HxColor_t     color = { 0, 100, 100, 100 };
static HxMessageListener_t       *spMenuListener = NULL;
static HxMessageListener_t       *spButtonListener = NULL;
static HxDialog_t                *spAboutDialog = NULL;
static HxMenu_t                  *spRootMenu = NULL;

#define APP_RES_FILE "Resources/dtshxpngtoheader.hxui"
#define APP_NAME "dtshxpngtoheader"

/**
 * macro to easily convert a string to a resource ID 
 *
**/

#define RESID(x) (LookupResID(#x))


static void DrawContainerWindow(HxWindow_t* pWindow, const HxRegion_t* pRegion, bool clear);

/**
 * @brief LookupResID returns a uint32_t for the matching string defined 
 * in a resource file
 *
 * @params idString		IN: ptr to string to lookup
 *
 * @returns uint32_t		Id of string resource
 */
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        fprintf(stderr, ": Unknown resource ID string '%s'\n", idString);
        exit(1);        
    }
    return id;
}

static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t           id, size;
    
    HxResult result;
    
    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    result = HxMessageGetData(pMessage, (void*)&id,  &size);
    HX_ASSERT(HX_OK == result);
    
    if(id == RESID(Quit))
        exit(1);
    else if(id == RESID(About))
    {
        result = HxResFileNewDialog(spResFile, RESID(DialogAbout), \
			   &spAboutDialog, NULL);
        result = result || HxDialogShowAndWait(spAboutDialog);
    }
    return result;
}

static HxResult
ButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t            id;
    HxResult           result = HX_OK;

    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    result = HxMessageGetSenderID(pMessage, &id);
    HX_ASSERT(HX_OK == result);

    if(id == RESID(ButtonAboutOK))
    {
	    printf("about ok\n");
            HxDialogDelete(spAboutDialog);
	    spAboutDialog = NULL;
    }
    return result;
}

/* override the container's draw function */
static void DrawContainerWindow(HxWindow_t* pWindow, const HxRegion_t* pRegion,bool clear)
{
    HxResult result = HX_OK;
    HxRectangle_t       bounds;
    HxColor_t            color = { 255, 255, 255, 255 };

    result = HxWidgetGetBounds((HxWidget_t *)pWindow, &bounds);
    
    bounds.x = bounds.y = 0;

    result = HxGfxSetColor((HxWidget_t *)pWindow, &color);

    result = HxGfxFillRectangle ((HxWidget_t *)pWindow, &bounds);

   /**
    * Draw the image into the canvas.
    **/

   bounds.x = 0;
   bounds.y = 0;
   bounds.w = 16;
   bounds.h = 16;

   result = HxImageDescriptionDraw(pDescription, NULL, NULL, &bounds);
   //
   HX_ASSERT(HX_OK == result);

}

/**
 *
 * Cleanup handler.  Closes the ResourceFile, releases HxUI resources 
 * free Strings
 *
**/
static void AtExit_UserInterface(void)
{
    HxResFileClose(spResFile);
    HxUiRelease();
}

/* 
  * @main    Main
  * 
*/
 
int main (int argc, char* argv[])
{
    HxResult    result = HX_OK;

    HxRectangle_t rect;

    /* initialize the UI toolkit */
    result = HxUiInit(&AppWindow, APP_NAME);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /** 
     *
     *   Create an image description from a data pointer generated 
     *   from the directfb-csource command line utility. 
     *
     **/

    result = HxImageDescriptionNewFromData (lock_desc.width, lock_desc.height, 
		    kHxPixelFormatRGB32,
		    lock_desc.preallocated[0].pitch,
		    lock_data, &pDescription);

    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    /* register cleanup function */
    atexit(AtExit_UserInterface);

    /* Display the application bar */
    result = HxApplicationBarShow(true);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* setup the root menu for the app */
    rect.x = 50;
    rect.y = 100;
    rect.w = 300;
    rect.h = 200;
    
    result = HxContainerNew(kHxWidgetAutoID, (HxWidget_t*)AppWindow, &rect,
           kHxContainerAttrNone, &TheContainer);

    fprintf(stderr, "Container New res:%d\n",  result);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxContainerSetBackgroundColor(TheContainer, &color);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_ASSERT(HX_OK == result);
 
    result = HxResFileNewRootMenu(spResFile, RESID(RootMenu), &spRootMenu, NULL);
    HX_ASSERT(HX_OK == result);
    /** 
     * @brief Prepare to hook into the window draw callback 
     *         
     **/
    result = HxWidgetSetCallback((HxWidget_t*)TheContainer, kHxWidgetDraw,
                                    DrawContainerWindow, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for messages */
    result = HxMessageNewListener(&spMenuListener);
    HX_ASSERT(HX_OK == result);
    
    result = HxMessageListen(spMenuListener, kHxActionMessageClass,
                                kHxMenuSelected, MenuCallback, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxMessageNewListener(&spButtonListener);
    HX_ASSERT(HX_OK == result);

    result = HxMessageListen(spButtonListener, kHxActionMessageClass,
                 kHxCommandButtonChanged, ButtonCallback, NULL);

    /* enter event loop */
    result = HxWindowEventLoop(AppWindow, 0);
    HX_ASSERT(HX_OK == result);

    /* Close up the UI toolkit & close application window. */
    result = HxUiRelease();

error:

    return result;
}

