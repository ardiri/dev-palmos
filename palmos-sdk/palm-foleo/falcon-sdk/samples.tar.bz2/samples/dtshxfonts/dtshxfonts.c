/**
 * @brief This file contains a demonstration of the font loading 
 * application.  It iterates through the system fonts rendering them accordingly.  It
 * also contains a menu, about box and quit option.
 *
 * @ingroup Samples
 * @file dtshxfonts.c
 * <hr>
 **/
//#include <glib-2.0/glib.h>

#include <hx/ui/hxui.h>
#include <hx/hxmessage.h>
#include <hx/hxproperty.h>
#include <hx/ui/hxdialog.h>
#include <hx/ui/hxresfile.h>
#include <hx/ui/hxmenu.h>

#define APP_NAME              "dtshxfonts"         

HxResFile_t                   *spResFile = NULL;
HxDialog_t                    *pAboutDialog = NULL;
HxMenu_t                      *spRootMenu = NULL;

#define RESID(x)    (LookupResID(#x))

/* TODO add a user defined font load sample */
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        fprintf(stderr, APP_NAME ": Unknown resource ID string '%s'\n", idString);
        exit(1);        
    }
    return id;
}
   	
HxResult
HandleAboutButton(const HxMessage_t* pMessage, void* context)
{
    HxResult result = HX_OK;
    
    if(pAboutDialog)
    {
        result = HxDialogDelete(pAboutDialog);  
        pAboutDialog = NULL;	
    } 

    return result;
}

HxResult
HandleMenuCommand(const HxMessage_t* pMessage, void* data)
{
    int32_t menuid;
    int32_t itemid;
    int32_t size = sizeof(int32_t);

    HxResult result;
    
    result = HxMessageGetSenderID (pMessage, &menuid);
    result = result || HxMessageGetData(pMessage, (void *)&itemid, &size);
    if (result != HX_OK) return result;

    fprintf(stderr, APP_NAME ": HandleMenuCommand, menuid = %d, itemid = %d\n", menuid, itemid);

    //int32_t x, y, maxX, maxY;

    if(itemid == RESID(MenuHelpAbout))
    { 

        result = HxResFileNewDialog(spResFile, RESID(DialogAbout), &pAboutDialog, NULL);
        
	result = result || HxDialogShowAndWait(pAboutDialog);
    }
    else if(itemid == RESID(Menu_Quit))
    {
        exit(0); 
    }
               
    return result;
}


static void DrawAppWindow(HxWidget_t* pWindow, HxRegion_t* pRegion, bool clear);


static HxWidgetDrawFnPtr sSavedCallback = NULL;


inline long hxu_get_clocktime(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);

    return (tv.tv_sec * 1000L + tv.tv_usec / 1000L);
}

char *property_get_new_string(
    HxPropertyId_t id, 
    HxPropertyIndex_t index)
{
    size_t len = 0;

    HxResult result = HxPropertyGetString(id, index, NULL, &len);
    if (result == HX_OK)
    {
        char *str = malloc(len);
        result = HxPropertyGetString(id, index, str, &len);
        if (result == HX_OK)
        {
            return str;        
        }
        else
        {
            free(str);
        }        
    }

    return NULL;
}

int main (int argc, char* argv[])
{
    HxWindow_t         *pAppWindow = NULL;
    HxResult           result = HX_OK;
    char               *spAppResourceDirString = NULL;

    /* initialize the UI toolkit */
    result = HxUiInit(&pAppWindow, _("HxFonts"));
    HX_ASSERT(HX_OK == result);

    result = HxWidgetSetCallback((HxWidget_t*)pAppWindow, kHxWidgetDraw,
                                    DrawAppWindow, (void**) &sSavedCallback);

    result = HxWidgetUpdate((HxWidget_t*)pAppWindow, NULL);

    /* open the resource file */
    spAppResourceDirString = property_get_new_string(kHxPropertyResourcePath, 0);
    char *resFileName = g_build_filename(spAppResourceDirString, APP_NAME ".hxui", NULL);
    result = HxResFileOpen(resFileName, &spResFile);
    g_free(resFileName);
    
    /* setup the root menu for the app */
    result = HxResFileNewRootMenu(spResFile, RESID(RootMenu), &spRootMenu, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxMessageListenFrom(
        NULL,
        kHxActionMessageClass, kHxCommandButtonChanged, RESID(ButtonAboutOK),
        HandleAboutButton, NULL);

    HX_ASSERT(HX_OK == result);
    
    result = HxMessageListen(
        NULL,
        kHxActionMessageClass, kHxMenuSelected,
        HandleMenuCommand, NULL);

    HX_ASSERT(HX_OK == result);

    /* enter the event loop when ready for the user */
    result = HxWindowEventLoop(pAppWindow, 0 /* no timeout */);
    HX_ASSERT(HX_OK == result);

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}


static void
DrawAppWindow(HxWidget_t* pWindow, HxRegion_t* pRegion, bool clear)
{
    long time1, time2;
    HxFont_t* pFont;
    int32_t x, y, index;
    char pTestString[16];
    char pBigString[80];
    HxResult result;

    if (NULL != sSavedCallback)
    {
        sSavedCallback((HxWidget_t*)pWindow, pRegion, clear);
    }
    
    /* ellipsis */
    pTestString[0] = 0xE2;
    pTestString[1] = 0x80;
    pTestString[2] = 0xA6;

    /* quotation marks */
    pTestString[3] = 0xE2;
    pTestString[4] = 0x80;
    pTestString[5] = 0x9C;

    pTestString[6] = 0xE2;
    pTestString[7] = 0x80;
    pTestString[8] = 0x9D;

    /* apostrophe */
    pTestString[9] = 0xE2;
    pTestString[10] = 0x80;
    pTestString[11] = 0x99;

    pTestString[12] = 0;
    
    x = 20;
    y = 20;

    time1 = hxu_get_clocktime();
    const char** hFontName;
    const char** hFontUserName;
    result = HxFontGetNames(&hFontName, &hFontUserName);

    time2 = hxu_get_clocktime();
    printf("HxFontGetNames = %ld ms\n", time2 - time1);
    time1 = time2;

    for (index = 0; NULL != hFontName[index]; index++)
    {
        /*
            Use kHxFontPlain weight for system fonts, since the system fonts
            have separate font files for each weight.
        */

        /* set the font and size for the string */
        result = HxFontLoad(kHxFontSystem, 12, kHxFontPlain, kHxFontAttrNone,
                                hFontName[index], &pFont);
        HX_ASSERT(HX_OK == result);

        strcpy(pBigString, hFontName[index]);
        strcat(pBigString, pTestString);
        HxGfxDrawString((HxWidget_t*)pWindow, pFont, pBigString, x, y);

        time2 = hxu_get_clocktime();
        printf("%s = %ld ms\t%s\n", hFontName[index], time2 - time1,pBigString);
        time1 = time2;

        y += 30;

        if (y > 400)
        {
            x += 200;
            y = 20;
        }

        HxFontUnload(pFont);
    }

    x = 600;
    y = 20;
    int32_t size = 12 << 6;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12.00 font size", x, y);
    HxFontUnload(pFont);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12.25 font size", x, y);    
    HxFontUnload(pFont);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12.50 font size", x, y);
    HxFontUnload(pFont);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12.75 font size", x, y);
    HxFontUnload(pFont);

    y += 20;
    size = 13 << 6;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13.00 font size", x, y);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13.25 font size", x, y);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13.50 font size", x, y);
    HxFontUnload(pFont);

    y += 20;
    size += 16;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13.75 font size", x, y);
    HxFontUnload(pFont);

    y += 20;
    size = 14 << 6;
    result = HxFontLoad(kHxFontSansSerif, size, kHxFontPlain,
                            kHxFontAttrFractionalSizes, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "14.00 font size", x, y);
    HxFontUnload(pFont);

    x = 400;
    y = 240;
    result = HxFontLoad(kHxFontSansSerif, 12, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSansSerif, 13, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSansSerif, 14, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "14 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSansSerif, 15, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "15 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSansSerif, 16, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "16 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSansSerif, 46, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "46 pts", x, y);
    HxFontUnload(pFont);

    x = 700;
    y = 240;
    result = HxFontLoad(kHxFontSerif, 12, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "12 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSerif, 13, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "13 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSerif, 14, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "14 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSerif, 15, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "15 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSerif, 16, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "16 points", x, y);
    HxFontUnload(pFont);

    y += 25;
    result = HxFontLoad(kHxFontSerif, 46, kHxFontPlain,
                            kHxFontAttrPoints, NULL, &pFont);
    HxGfxDrawString((HxWidget_t*)pWindow, pFont, "46 pts", x, y);
    HxFontUnload(pFont);
}
