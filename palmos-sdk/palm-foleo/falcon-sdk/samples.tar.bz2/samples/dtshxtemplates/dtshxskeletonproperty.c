/**
 * @brief Skeleton sample file for a developer to build an application.  This 
 * skeleton application provides a few stubbed out routines as a stepping 
 * stone/sandpit.  This application creates a menu, opens a resource file, 
 * instantiates the HxUI toolkit, the Event Loop, and sets up default handlers 
 * for exiting the application.  It also contains an About Dialog, and a 
 * simple Text Label.  This template also includes a property retrieval API. 
 *
 * @ingroup Samples
 * @file dtshxskeletonproperty.c
 * <hr>
 **/
#include <hx/ui/hxapplicationbar.h>
#include <hx/ui/hxfont.h>
#include <hx/ui/hxgraphics.h>
#include <hx/ui/hxdropdownbox.h>
#include <hx/ui/hxui.h>
#include <hx/ui/hxwidget.h>
#include <hx/ui/hxresfile.h>
#include <hx/ui/hxwindow.h>
#include <hx/ui/hxdialog.h>
#include <hx/ui/hxcontainer.h>
#include <hx/hxmessage.h>

static HxWindow_t                *spAppWindow = NULL;
static HxMessageListener_t       *spMenuListener = NULL;
static HxMessageListener_t       *spButtonListener = NULL;
static HxDialog_t                *spAboutDialog = NULL;
static HxResFile_t               *spResFile = NULL;
static HxMenu_t                  *spRootMenu = NULL;
static HxContainer_t             *spContainer = NULL;

static HxResult ButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResult MenuCallback(const HxMessage_t* pMessage, void* pData);
static void DrawAppWindow(HxWindow_t* pWindow, const HxRegion_t* pRegion, bool clear);

#define APP_NAME "dtshxskeleton"
#define APP_RES_FILE "Resources/dtshxskeleton.hxui"

/*
 * routine to easily convert a string to a resource ID
 *
**/
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        printf(": Unknown resource ID string '%s'\n", idString);
        exit(1);
     }
    return id;
}

/**
 *  
 * macro to easily convert a string to a resource ID
 * 
 **/
#define RESID(x) (LookupResID(#x))

int main(int argc, char** argv)
{
    HxRectangle_t      bounds;
    HxWindow_t         *pAppBarWindow = NULL;
    HxResult           result;
    int                bundlesize = 256;
    char               bundlestring[bundlesize];
    uint32_t           SelectedButton = 0;

    result = HxUiInit(&spAppWindow, _(APP_NAME));
    HX_ASSERT(HX_OK == result);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_ASSERT(HX_OK == result);

    result = HxResFileNewRootMenu(spResFile, RESID(RootMenu), &spRootMenu, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxWidgetSetCallback((HxWidget_t*)spAppWindow, kHxWidgetDraw,
                                    DrawAppWindow, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxWidgetUpdate((HxWidget_t*)spAppWindow, NULL);
    HX_ASSERT(HX_OK == result);

   /* listen for messages */
    result = HxMessageNewListener(&spMenuListener);
    HX_ASSERT(HX_OK == result);
    
    result = HxMessageListen(spMenuListener, kHxActionMessageClass,
                                kHxMenuSelected, MenuCallback, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxMessageNewListener(&spButtonListener);
    HX_ASSERT(HX_OK == result);

    result = HxMessageListen(spButtonListener, kHxActionMessageClass,
                 kHxCommandButtonChanged, ButtonCallback, NULL);
    HX_ASSERT(HX_OK == result);
    
    bounds.x = bounds.y = 50;
    bounds.w = bounds.h = 200;

    result = HxContainerNew(kHxWidgetAutoID, (HxWidget_t*)spAppWindow, \
                  &bounds, kHxContainerAttrHasFrame | \
                  kHxContainerAttrRoundedBottom, &spContainer);
    HX_ASSERT(HX_OK == result);

    result = HxResFileLoadContainer(spResFile, RESID(AContainer), spContainer, \
                  NULL);
    HX_ASSERT(HX_OK == result);
   
    result = HxPropertyGetString(kHxPropertyBundlePath, 0, bundlestring, \
		    &bundlesize); 
    HX_ASSERT(HX_OK == result);

    result = HxAlert(kHxWidgetAutoID, kHxAlertStyleOK, NULL, \
		    "Property Retrieval", bundlestring, &SelectedButton);   
    HX_ASSERT(HX_OK == result);

    /* enter the event loop */
    result = HxWindowEventLoop(spAppWindow, 0 /* no timeout */);
    HX_ASSERT(HX_OK == result);

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}

void
RedrawAppWindow()
{
    HxResult result;
    result = HxWidgetUpdate((HxWidget_t*)spAppWindow, NULL);
    HX_ASSERT(HX_OK == result);
}

static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t           id, size;
    
    HxCommandButton_t *pButton;
    HxResult result;
    
    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    result = HxMessageGetData(pMessage, (void*)&id,  &size);
    HX_ASSERT(HX_OK == result);
    
    if(id == RESID(Quit))
        exit(1);
    else if(id == RESID(About))
    {
        result = HxResFileNewDialog(spResFile, RESID(DialogAbout), \
			   &spAboutDialog, NULL);
        result = result || HxDialogShowAndWait(spAboutDialog);
    }
    return result;
}

static HxResult
ButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t            id;
    HxCommandButton_t  *pButton = NULL;
    HxResult           result = HX_OK;

    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    pButton = (HxCommandButton_t*)pData;

    result = HxMessageGetSenderID(pMessage, &id);
    HX_ASSERT(HX_OK == result);

    if(id == RESID(ButtonAboutOK))
    {
	    printf("about ok\n");
            HxDialogDelete(spAboutDialog);
	    spAboutDialog = NULL;
    }
    
    return result;
}

/**
 * @brief List callback that updates the Font selection and calls the draw
 * function. 
 *
 * @param pMessage		IN: pointer to Message
 * @param pData			IN: pointer to data
 *
 * @return			HxResult
 */ 
static void
DrawAppWindow(HxWindow_t* pWindow, const HxRegion_t* pRegion, bool clear)
{
    HxLabel_t       *pLabel = NULL;
    HxRectangle_t   rect;
    HxResult        result = HX_OK;

    rect.x = rect.y = 20;
    rect.w = 100;
    rect.h = 20;

    result = HxLabelNew(kHxWidgetAutoID, (HxWidget_t*)spAppWindow, &rect, NULL, 
		    "Hi", &pLabel);

    HX_ASSERT(result == HX_OK);
}

