/**
 * @brief Skeleton sample file for a developer to build an application.  This 
 * skeleton application provides a few stubbed out routines as a stepping 
 * stone/sandpit.  This application creates a menu, opens a resource file, 
 * instantiates the HxUI toolkit, the Event Loop, and sets up default handlers 
 * for exiting the application.  It also contains an About Dialog, and a 
 * simple Text Label.  This template includes a WidgetMapMessage Callback 
 * along with the User defined Message Post and Callback.
 *
 * @ingroup Samples
 * @file dtshxskeletonmesgmap.c
 * <hr>
 **/
#include <hx/ui/hxapplicationbar.h>
#include <hx/ui/hxfont.h>
#include <hx/ui/hxgraphics.h>
#include <hx/ui/hxdropdownbox.h>
#include <hx/ui/hxui.h>
#include <hx/ui/hxwidget.h>
#include <hx/ui/hxresfile.h>
#include <hx/ui/hxwindow.h>
#include <hx/ui/hxdialog.h>

#include <hx/hxmessage.h>

static HxWindow_t                *spAppWindow = NULL;
static HxMessageListener_t       *spMenuListener = NULL;
static HxMessageListener_t       *spButtonListener = NULL;
static HxMessageListener_t       *spUserMessageListener = NULL;
static HxDialog_t                *spAboutDialog = NULL;
static HxResFile_t               *spResFile = NULL;
static HxMenu_t                  *spRootMenu = NULL;
static HxMessage_t               *pUserMessage = NULL;

static HxResult ButtonCallback(const HxMessage_t*, void*);
static HxResult MenuCallback(const HxMessage_t*, void*);
static void DrawAppWindow(HxWindow_t*, const HxRegion_t*, bool);
static HxResult MyMessageHandler(const HxMessage_t*, void *);

#define APP_NAME "dtshxskeleton"
#define APP_RES_FILE "Resources/dtshxskeleton.hxui"
#define UserMessageID 10

/*
 * routine to easily convert a string to a resource ID
 *
**/
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        printf(": Unknown resource ID string '%s'\n", idString);
        exit(1);
     }
    return id;
}
static HxResult MyMessageHandler(const HxMessage_t* message, void *data) 
{ 
    HxResult       result = HX_OK;
    uint32_t       pSelectButton = 0; 
    
    result = HxAlert(kHxWidgetAutoID, kHxAlertStyleOK, NULL, "Received Message", "Received User Message", &pSelectButton);  
    HX_ASSERT(result == HX_OK); 

    HxMessageDelete(pUserMessage);
    pUserMessage = NULL;
    return result; 
}	
	
HxResult SendMySelfAMessage()
{
    HxResult       result = HX_OK;

    result = HxMessageNew(&pUserMessage, kHxUserMessageClass, UserMessageID); 
    HX_ASSERT(HX_OK == result);

    result = HxMessagePost(NULL, pUserMessage, 0); 
    HX_ASSERT(HX_OK == result);

    return result; 
}

/**
 *  
 * macro to easily convert a string to a resource ID
 * 
 **/
#define RESID(x) (LookupResID(#x))

int main(int argc, char** argv)
{
    HxRectangle_t      bounds;
    HxWindow_t         *pAppBarWindow = NULL;
    HxResult           result;

    result = HxUiInit(&spAppWindow, _(APP_NAME));
    HX_ASSERT(HX_OK == result);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_ASSERT(HX_OK == result);

    result = HxResFileNewRootMenu(spResFile, RESID(RootMenu), &spRootMenu, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxWidgetSetCallback((HxWidget_t*)spAppWindow, kHxWidgetDraw,
                                    DrawAppWindow, NULL);
    HX_ASSERT(HX_OK == result);

    result = HxWidgetUpdate((HxWidget_t*)spAppWindow, NULL);
    HX_ASSERT(HX_OK == result);

   /* listen for messages */
    result = HxMessageNewListener(&spMenuListener);
    HX_ASSERT(HX_OK == result);
   
     
   // result = HxMessageListen(spMenuListener, kHxActionMessageClass,
   // kHxMenuSelected, MenuCallback, NULL);
   result = HxWidgetMapMessageCallback((HxWidget_t*)spRootMenu, 
		   kHxActionMessageClass, kHxMenuSelected, MenuCallback, NULL);
				HX_ASSERT(HX_OK == result);

    result = HxMessageNewListener(&spButtonListener);
    HX_ASSERT(HX_OK == result);

    result = HxMessageListen(spButtonListener, kHxActionMessageClass,
                 kHxCommandButtonChanged, ButtonCallback, NULL);

    result = HxMessageNewListener(&spUserMessageListener);
    HX_ASSERT(HX_OK == result);
    
    result = HxMessageListen(spUserMessageListener, kHxUserMessageClass,
                 UserMessageID, MyMessageHandler, NULL);
    
    HX_ASSERT(HX_OK == result);

    result = SendMySelfAMessage();
    HX_ASSERT(HX_OK == result);

    /* enter the event loop */
    result = HxWindowEventLoop(spAppWindow, 0 /* no timeout */);
    HX_ASSERT(HX_OK == result);
    
    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}


void
RedrawAppWindow()
{
    HxResult result;
    result = HxWidgetUpdate((HxWidget_t*)spAppWindow, NULL);
    HX_ASSERT(HX_OK == result);
}

static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t           id, size;
    
    HxCommandButton_t *pButton;
    HxResult result;
    
    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    result = HxMessageGetData(pMessage, (void*)&id,  &size);
    HX_ASSERT(HX_OK == result);
    
    if(id == RESID(Quit))
        exit(1);
    else if(id == RESID(About))
    {
        result = HxResFileNewDialog(spResFile, RESID(DialogAbout), \
			   &spAboutDialog, NULL);
        result = result || HxDialogShowAndWait(spAboutDialog);
    }
    return result;
}

static HxResult
ButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    int32_t            id;
    HxCommandButton_t  *pButton;
    HxResult           result = HX_OK;

    HX_ASSERT(NULL != pMessage);
    HX_ASSERT(NULL != pData);

    pButton = (HxCommandButton_t*)pData;

    result = HxMessageGetSenderID(pMessage, &id);
    HX_ASSERT(HX_OK == result);

    if(id == RESID(ButtonAboutOK))
    {
	    printf("about ok\n");
            HxDialogDelete(spAboutDialog);
	    spAboutDialog = NULL;
    }
    return result;
}

/**
 * @brief List callback that updates the Font selection and calls the draw
 * function. 
 *
 * @param pMessage		IN: pointer to Message
 * @param pData			IN: pointer to data
 *
 * @return			HxResult
 */ 
static void
DrawAppWindow(HxWindow_t* pWindow, const HxRegion_t* pRegion, bool clear)
{
    HxLabel_t       *pLabel = NULL;
    HxRectangle_t   rect;
    HxResult        result = HX_OK;

    rect.x = rect.y = 50;
    rect.w = 200;
    rect.h = 40;

    result = HxLabelNew(kHxWidgetAutoID, (HxWidget_t*)spAppWindow, &rect, NULL, 
		    "Hi", &pLabel);

    HX_ASSERT(result == HX_OK);
}


