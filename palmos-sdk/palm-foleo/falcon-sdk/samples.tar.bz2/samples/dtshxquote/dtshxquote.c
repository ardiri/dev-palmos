/**
 * @brief This is a fully functional webservices stock quote application. The user enters a ticker symbol, clicks
 * on the "Get" button and receives a delayed stock quote.
 * This sample demonstrates how to use the following hx UI elements
 * hxWindow, hxLabel, hxAlert, hxField, hxcommandbutton and callback. The UI elements are loaded in from the hxui file.
 * The webservers code was automatically generated using gsoap. Refer to http://www.cs.fsu.edu/~engelen/soap.html
 * for more information on gsoap.
 *
 * @ingroup Samples
 * @file dtshxquote.c
 * <hr>
 **/
 

#define Err 1
#define APP_RES_FILE "Resources/dtshxquote.hxui"

#include <hx/ui/hxui.h>
#include <locale.h>
#include "soapH.h"	/* include generated proxy and SOAP support */
#include <pthread.h>

/*********************************************************************/

static HxResult 	InitMenus(HxResFile_t* pResFile);
static HxResult 	MenuCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResult 	CmdButtonCallback(const HxMessage_t* pMessage, void* pData);
static HxResFile_t 	*spResFile = NULL;

/************************************************************************/

HxWindow_t* pAppWindow = NULL;

/* The namespace mapping table is required and associates namespace prefixes with namespace names: */
struct Namespace namespaces[] =
{
  {"SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/", "http://www.w3.org/*/soap-envelope", NULL}, /* MUST be the first */
  {"SOAP-ENC", "http://schemas.xmlsoap.org/soap/encoding/", "http://www.w3.org/*/soap-encoding", NULL}, /* MUST be the second */
  {"xsi", "http://www.w3.org/1999/XMLSchema-instance", "http://www.w3.org/*/XMLSchema-instance", NULL}, /* MUST be the third */
  {"xsd", "http://www.w3.org/1999/XMLSchema", "http://www.w3.org/*/XMLSchema", NULL},
  {"ns", "urn:xmethods-delayed-quotes"},	/* Method namespace URI */
  {NULL, NULL, NULL, NULL}
};
/*
 * routine to easily convert a string to a resource ID
 *
**/
uint32_t LookupResID(const char *idString)
{
    uint32_t id = UINT32_MAX; /* bad value that won't match anything */
    HxResult result = HxResFileLookupID(spResFile, idString, &id);
    if (result != HX_OK)
    {
        printf(": Unknown resource ID string '%s'\n", idString);
        exit(1);
     }
    return id;
}

/**
 *  
 * macro to easily convert a string to a resource ID
 * 
 **/
#define RESID(x) (LookupResID(#x))
/** 
 * @brief Makes a call to the gsoap generated webservices files to get a stock price for a given ticker symbol
 *  @param ticker*             IN:     	Ticker symbol 
 *  @param s_price*            IN:     	Stock price
 *
 *  @return int:               OUT: 	gsoap error code
 */
HxResult getQuote(char *ticker,char * s_price){
	struct soap soap;
	float price=0;
	soap_init(&soap);
    if (soap_call_ns__getQuote(&soap, "http://services.xmethods.net/soap", "", ticker, &price) == 0)
      sprintf(s_price, "%.2f", price);    	
    else{
      soap_print_fault(&soap, stderr);
    	return Err;
    }
    soap_end(&soap);
    soap_done(&soap);    
return 0;
}

/**
 *  @brief main!
 *
 *  @param argc				IN: number of command line parameters
 *  @param argv				IN: array of pointers to command line parameters 
 *
 *  @return int: 	              	return 0 (OK) or some HX error
 */
int main (int argc, char* argv[])
{
    HxMessageListener_t* spListener = NULL;
    HxResult result;       
    
    /* initialize the UI toolkit */
    result = HxUiInit(&pAppWindow, "dtshxQuote");
    HX_ASSERT(HX_OK == result);
    
    /* open the resource file */
    result = HxResFileOpen(APP_RES_FILE, &spResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    /* load the menus from the hxui file */
    result = InitMenus(spResFile);
	HX_ASSERT(HX_OK == result);
	
    /* load a container with widgets */
    result = HxResFileLoadContainer(spResFile, RESID(ContainerOne),
                                    (HxContainer_t*)pAppWindow, NULL);
	HX_ASSERT(HX_OK == result);
	
	/* listen for messages */
    result = HxMessageNewListener(&spListener);
    HX_ASSERT(HX_OK == result);
    
   
    result = HxMessageListenFrom(NULL,kHxActionMessageClass, kHxCommandButtonChanged, RESID(ButtonGetQuote),
        CmdButtonCallback, NULL);
    HX_ASSERT(HX_OK == result);
    
    /* enter the event loop */
    result = HxWindowEventLoop(pAppWindow, 0);

error:

    /* close up the UI toolkit */
    result = HxUiRelease();

    return result;
}
/** Call back function iniated when "GetQuote" button is pressed*/
static HxResult
CmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HxResult result;    
	char tvalue[10];
	int32_t buttonID;
    HxLabel_t   *pLabel = NULL;
    HxField_t   *pField = NULL;
	const char      *ticker = NULL;   
	HxPinWheel_t   *pPinWheel = NULL;
	                              
	HX_ASSERT(NULL != pMessage);
	result = HxWidgetGetWidgetFromID(RESID(FieldTicker),(HxWidget_t**)&pField );
    HX_ASSERT(result == HX_OK);
	
    //Get the ticker symbol entered from the field, pField
    result = HxFieldGetText(pField,&ticker);
    //Make sure the ticker symbol has more than 3 characters
    if (strlen(ticker)<3){
    	//Display an error alert if pField contains less than 3 characters
    	result = HxAlert(kHxWidgetAutoID,kHxAlertStyleOK,NULL,"Error", "Please enter a correct symbol.",NULL);
    	HX_ASSERT(result == HX_OK);
    	return 0;	
    }
    result = HxWidgetGetWidgetFromID(RESID(LabelResult2),(HxWidget_t**)&pLabel);
    HX_ASSERT(result == HX_OK);	     
    
    //Display status while networking is being preformed.
    result = HxLabelSetText(pLabel,"Processing...");                                        
    HX_ASSERT(HX_OK == result);

    result = HxWidgetDraw(pLabel,NULL); 
    HX_ASSERT(HX_OK == result); 
	result = HxPinWheelNew(kHxWidgetAutoID, (HxWidget_t*)pAppWindow, 380, 220, &pPinWheel);  
	HxWidgetUpdate((HxWidget_t*)pAppWindow, NULL);
    //Call webservices function to retrieve quote
    if (getQuote(ticker,tvalue) == Err)
    {		
		HxAlert(kHxWidgetAutoID,kHxAlertStyleOK,NULL,"Error", "Network error please try again",NULL);		
		result = HxLabelSetText(pLabel,"");
		HX_ASSERT(HX_OK == result);
		return 0;
	}
	else
	{
    	char buffer[11];
    	buffer[0]='$';
    	buffer[1]='\0';
    	strcat(buffer,tvalue);	
    	//Display result
    	result = HxLabelSetText(pLabel,buffer);
		HX_ASSERT(HX_OK == result);
		// Set the focus on the ticker field, so another symbol can be entered easily
    	result = HxWidgetSetFocus(pField);
	} 
	result = HxPinWheelDelete(pPinWheel);       	
    return result;
}
static HxResult 
InitMenus(HxResFile_t* pResFile)
{
    uint32_t id;
    HxMenu_t* pRootMenu;
    HxResult result;

	/* load the root menu and all the submenus */
    result = HxResFileLookupID(pResFile, "MenuRoot", &id);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);
	result = HxResFileNewRootMenu(pResFile, id, &pRootMenu, NULL);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /*
        Applications can call HxMessageListen, and provide a single callback
        for all menu items.  Alternatively, define callbacks that are targeted
        to particular menu items.
    */
    
	/* provide a callback for all menu messages */
	result = HxMessageListen(NULL, kHxActionMessageClass,
	                            kHxMenuItemIDSelected, MenuCallback, pResFile);
	HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* provide a callback for the About Box menu item */
    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    result = HxMessageListenFrom(NULL, kHxActionMessageClass,
                                kHxMenuItemIDSelected, id,
                                MenuAboutBoxCallback, pResFile);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
MenuCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxMessageSenderID_t menuID;
    HxResult result;
    
    HX_NULL_PARAMETER_CHECK(pData);    
    HxResFile_t* pResFile = (HxResFile_t*)pData;
    
	result = HxMessageGetSenderID(pMessage, &menuID);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "MenuOptionsAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    
    if (menuID != id)
    {
        uint32_t button = 0;
        
        result = HxResFileLookupID(pResFile, "AlertNotImplemented", &id);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
        
        result = HxResFileAlert(pResFile, id, &button, NULL);
        HX_EXIT_IF_ERROR(HX_OK == result, result, error);
    }

error:

    return result;
}


static HxResult
MenuAboutBoxCallback(const HxMessage_t* pMessage, void* pData)
{
    uint32_t id;
    HxDialog_t* pDialog;
    HxWidget_t* pWidget;
    HxResult result;

    HX_NULL_PARAMETER_CHECK(pData);
    HxResFile_t* pResFile = (HxResFile_t*)pData;

    result = HxResFileLookupID(pResFile, "DialogAbout", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileNewDialog(pResFile, id, &pDialog, NULL);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxResFileLookupID(pResFile, "AboutButtonOK", &id);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxWidgetGetWidgetFromID(id, &pWidget);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    /* listen for the command button press */
    result = HxWidgetMapMessageCallback(pWidget,
                    kHxActionMessageClass, kHxCommandButtonChanged,
                    AboutCmdButtonCallback, pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

    result = HxDialogShowAndWait(pDialog);
    HX_EXIT_IF_ERROR(HX_OK == result, result, error);

error:

    return result;
}


static HxResult
AboutCmdButtonCallback(const HxMessage_t* pMessage, void* pData)
{
    HX_NULL_PARAMETER_CHECK(pData);

    return HxDialogDelete((HxDialog_t*)pData);
}
