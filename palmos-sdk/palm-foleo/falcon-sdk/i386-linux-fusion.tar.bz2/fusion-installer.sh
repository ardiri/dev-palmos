#!/bin/sh -e
set -e
# NOTE: This assumes you could run sudo without a password on your
# system, this is a requirement anyway for the build environment.
# TODO: In the SDK case (not here), the /etc/modules file
# needs to contain the fusion module name so that it's loaded
# after each reboot.
# Also, there's a need for a mount tmpfs /dev/shm -ttmpfs to get
# the tmpfs shared file system in place. This can't really be done
# as part of the install, so there has to be something else for
# making sure this is dynamically mounted each time the developer system
# reboots.

# Must be able to install fusion as part of sdk install or as stand-alone
# script in case modules had not been enabled at time of sdk install.
# fusion-installer expected within sdk's src dir with toolroot, etc. above.

# Any simple command that fails will immediately abort the install
set -e

ARCH=i386-linux
SCRIPT_NAME=fusion-installer.sh
FUSION=${ARCH}-fusion
SDK_DIR=/opt/holly/sysroot/${ARCH}

# The makefile wants to depmod the module, so ensure it can find the tool
export PATH=$PATH:/sbin

CWDIR=`dirname $0`

[ -n "${KERNEL_SOURCE}" ] || KERNEL_SOURCE=/lib/modules/$(uname -r)/build
[ -d ${KERNEL_SOURCE} ] || KERNEL_SOURCE=/usr/src/linux-$(uname -r)
[ -d ${KERNEL_SOURCE} ] || KERNEL_SOURCE=/usr/src/linux

echo "Please tell me where to find the sources for the kernel that's running."
echo "Press [ENTER] if the path below is correct."
echo -n "[${KERNEL_SOURCE}]: "
# read -t returns an error that the "set -e" above would abort for.
# Use "|| true" to keep whole statement true and continue script.
read -t 60 reply || true
KERNEL_SOURCE=${reply:-${KERNEL_SOURCE}}

if [ ! -d "${KERNEL_SOURCE}" ]; then
	echo "${KERNEL_SOURCE} doesn't exist"
	exit 1
fi

echo "Using kernel sources in: ${KERNEL_SOURCE}"

if [ ! -d "${KERNEL_SOURCE}/kernel" -o \
     ! -d "${KERNEL_SOURCE}/include" -o \
     ! -d "${KERNEL_SOURCE}/arch/i386/boot" ]; then
	echo "${KERNEL_SOURCE} doesn't look like kernel sources!"
	exit 1
fi


# functions

function abort()
{
   echo $@
   exec /bin/false
}


function DoConfigure
{
    echo "Configuring ${FUSION}..."
    
    # Do a sanity check on the kernel source
    echo "Using kernel sources in: ${KERNEL_SOURCE}"
    echo "  Which is a symlink to: $(readlink -f ${KERNEL_SOURCE})"
    KERNEL_CANONICAL=$(readlink -f ${KERNEL_SOURCE})
    [ -d ${KERNEL_SOURCE} ] || abort "Can't find kernel source"

    configured=yes
    [ -f ${KERNEL_SOURCE}/.config ] || configured=no

    # for 2.4, check for the .depend file, created with "make dep"
    if grep -q 'dep: dep-files' "${KERNEL_SOURCE}/Makefile"; then
        [ -f ${KERNEL_SOURCE}/.depend ] || configured=no
	MAKEPREP="dep"
    fi

    # for 2.6, check for include/asm symlink, created with "make prepare"
    if grep -q 'prepare:' "${KERNEL_SOURCE}/Makefile"; then
        [ -L ${KERNEL_SOURCE}/include/asm ] || configured=no
	MAKEPREP="prepare"
    fi

    if [ $configured != yes ]; then
	echo -e \
          "The kernel does not appear to be configured..." \
          "\nRun this in the kernel source directory and then try again:" \
          "\n make oldconfig" \
          "\n make ${MAKEPREP}"
	exit 1
    fi

    # copy the header file that declares the interface to the module...

    FUSION_H=${FUSION}/linux/include/linux/fusion.h

    # update the workstation's copy since we changed the module version
    # so any non-Holly builds that use fusion will need to use this one
    sudo cp -f ${FUSION_H} /usr/include/linux/

    # update the Holly sdk copy so the workstation's /usr/include
    # doesn't have to be in the include path when building for Holly
    mkdir -p ${SDK_DIR}/usr/include/linux
    cp -f ${FUSION_H} ${SDK_DIR}/usr/include/linux/
}


function DoBuild
{
    echo "Building ${FUSION} kernel module..."
	echo ""

    sudo -v -p "Enter password for user [%u] to allow sudo access: "

    # Unload the old fusion module first if it's already loaded
    if lsmod | grep -q fusion ; then
        sudo rmmod fusion \
            || abort "Shut down all apps that are using fusion and try again"
    fi

	echo "copying over headers"

    # Make sure the version string that gets embedded in the module matches
    # the kernel that we're building it for
    VERSION_H=${KERNEL_SOURCE}/include/linux/version.h
    [ -f ${VERSION_H} ] && sudo mv ${VERSION_H} ${VERSION_H}.bak 
    sudo make -C ${KERNEL_SOURCE} include/linux/version.h \
        KERNELRELEASE=`uname -r` KERNEL_SOURCE=${KERNEL_SOURCE} \
        || abort "Can't generate nice version.h"

	echo "building $FUSION cd - $KERNEL_SOURCE"
   	export KERNEL_SOURCE=$KERNEL_SOURCE 
	sudo make -C ./${FUSION} ${KERNEL_SOURCE} \
        || abort "Problems building ${FUSION}"
    
    # Restore the old version.h
    [ -f ${VERSION_H}.bak ] && sudo mv ${VERSION_H}.bak ${VERSION_H}
}


function CreateFusionNodes
{
    if [ ! -d /dev/fusion ] ; then
       sudo mkdir /dev/fusion
       # Must have access to open dev when running.
       sudo chmod 777 /dev/fusion
    fi

    for i in 0 1 2 3 4 5 6 7; do
        if [ ! -c /dev/fusion/$i ] ; then
            sudo mknod /dev/fusion/$i c 252 $i
            sudo chmod 777 /dev/fusion/$i
        fi
    done
}


function DoInstall
{
    echo "Installing ${FUSION}..."
    sudo make -C ./${FUSION} install KERNEL_SOURCE=${KERNEL_SOURCE} \
        || abort "Problems installing ${FUSION}"

    CreateFusionNodes

    # Setup tmpfs for rapid data exchange.
    sudo mount tmpfs /dev/shm -ttmpfs
    
    # install the fusion module
    sudo /sbin/modprobe fusion

    # Need to install fusion module on startup to use Hollywood SDK.
    # Red Hat specific module startup?
    
    _startupscript="/etc/rc.d/rc.local"
    _modprobe=$(which modprobe)
    if [ -f $_startupscript ]; then
        # Has fusion startup already been added?
        if ! grep -q "modprobe fusion" $_startupscript; then
            echo "Updating $_startupscript to install fusion module..."
            # Do we have permission to add to startup script?
            new_writer=""
            if ! [ -w $_startupscript ]; then
                if [ -O $_startupscript ]; then
                    new_writer="u"
                elif [ -G $_startupscript ]; then
                    new_writer="g"
                else
                    new_writer="o"
                fi
                #Make the startup script writable
                sudo chmod ${new_writer}+w $_startupscript
            fi

            echo >> $_startupscript
            echo "# Install fusion module for Maguffin SDK simulator." \
                >> $_startupscript
            echo "$_modprobe fusion" >> $_startupscript

            #Do we have to restore permissions?
            if ! [ -z $new_writer ]; then
                sudo chmod ${new_writer}-w $_startupscript
            fi
        fi
    else
        echo "Maguffin SDK requires fusion module to run simulator."
        echo "Either manually \"modprobe fusion\" or add it to startup script."
    fi
}


function DoClean
{
    echo "Cleaning ${FUSION}..."
    if [ -f ./${FUSION}/Makefile ] ; then
       make -C ./${FUSION} KERNEL_SOURCE=${KERNEL_SOURCE} clean
    fi

    # make didn't clean up dev entries.
    if [ -d /dev/fusion ] ; then
        sudo rm -r /dev/fusion
    fi
}


echo "===> Do ${CWDIR}/${SCRIPT_NAME}"

# "all" is the default command if none given
case "${1:-all}" in
    clean)
	DoClean
    ;;

    all)
        DoConfigure
        DoBuild
        DoInstall
    ;;

    *)
    	abort "Unknown command: $1"
    ;;

esac

echo -e "\n\n===> ${CWDIR}/${SCRIPT_NAME} successful!\n\n"
