/*
 *	Fusion Kernel Module
 *
 *	(c) Copyright 2002-2003  Convergence GmbH
 *
 *      Written by Denis Oliver Kropp <dok@directfb.org>
 *
 *
 *	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 */

#ifdef HAVE_LINUX_CONFIG_H
#include <linux/config.h>
#endif
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/smp_lock.h>
#include <linux/sched.h>

#include <linux/fusion.h>

#include "fusiondev.h"
#include "fusionee.h"
#include "list.h"
#include "skirmish.h"


#define FUSION_DEBUG_SKIRMISH_DEADLOCK

#define MAX_PRE_ACQUISITIONS  32

#ifdef  FUSION_DEBUG_SKIRMISH_DEADLOCK
#define NUM_WORLDS 8  // this should be synced with NUM_MINORS in fusiondev.c
static FusionEntries *worldwide_skirmish_entries[NUM_WORLDS];
static DECLARE_MUTEX(worldwide_skirmish_entries_lock);

int
world_get_skirmishs_interruptible(int world, FusionEntries **ret_entries)
{
    if (down_interruptible(&worldwide_skirmish_entries_lock))
    {
        *ret_entries = NULL;
        return -EINTR;
    }

    *ret_entries = worldwide_skirmish_entries[world];

    up(&worldwide_skirmish_entries_lock);
    return 0;
}
#endif

typedef struct __FUSION_FusionSkirmish FusionSkirmish;

struct __FUSION_FusionSkirmish {
     FusionEntry entry;

     int         lock_fid;  /* non-zero if locked */
     int         lock_pid;
     int         lock_count;

     int         lock_total;

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     int         pre_acquis[MAX_PRE_ACQUISITIONS];
     int         pre_acquis_worlds[MAX_PRE_ACQUISITIONS];

     bool        outer;
#endif
};

static int
fusion_skirmish_print( FusionEntry *entry,
                       void        *ctx,
                       char        *buf )
{
     int             written  = 0;
     FusionSkirmish *skirmish = (FusionSkirmish*) entry;

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     int             i, n;


     for (i=0, n=0; i<MAX_PRE_ACQUISITIONS; i++) {
          if (skirmish->pre_acquis[i]) {
               n++;
          }
     }

     written += sprintf( buf + written, "[%2d]%s", n, skirmish->outer ? "." : " " );

     for (i=0, n=0; i<MAX_PRE_ACQUISITIONS; i++) {
          if (skirmish->pre_acquis[i]) {
               /* Write list of world:lock_id pairs */
               written += sprintf( buf + written, "%s%d:%02x", n ? "," : "",
                    skirmish->pre_acquis_worlds[i] - 1,
                    skirmish->pre_acquis[i] - 1 );

               n++;
          }
     }
#endif

     if (skirmish->lock_fid) {
          if (skirmish->entry.waiters)
               return sprintf( buf + written, " - %dx [0x%08x] (%d)  %d WAITING\n",
                               skirmish->lock_count, skirmish->lock_fid,
                               skirmish->lock_pid, skirmish->entry.waiters ) + written;
          else
               return sprintf( buf + written, " - %dx [0x%08x] (%d)\n",
                               skirmish->lock_count, skirmish->lock_fid,
                               skirmish->lock_pid ) + written;
     }

     return sprintf( buf + written, "\n" ) + written;
}

FUSION_ENTRY_CLASS( FusionSkirmish, skirmish, NULL, NULL, fusion_skirmish_print )

/******************************************************************************/

int
fusion_skirmish_init (FusionDev *dev)
{
     fusion_entries_init( &dev->skirmish, &skirmish_class, dev );

     create_proc_read_entry( "skirmishs", 0, dev->proc_dir,
                             fusion_entries_read_proc, &dev->skirmish );

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     if (down_interruptible(&worldwide_skirmish_entries_lock))
        return -EINTR;
     worldwide_skirmish_entries[dev->index] = &dev->skirmish;
     up(&worldwide_skirmish_entries_lock);
#endif

     return 0;
}

void
fusion_skirmish_deinit (FusionDev *dev)
{
     remove_proc_entry ("skirmishs", dev->proc_dir);

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     down(&worldwide_skirmish_entries_lock);
     worldwide_skirmish_entries[dev->index] = NULL;
     up(&worldwide_skirmish_entries_lock);
#endif

     fusion_entries_deinit( &dev->skirmish );
}

/******************************************************************************/

int
fusion_skirmish_new (FusionDev *dev, int *ret_id)
{
     return fusion_entry_create( &dev->skirmish, ret_id, NULL );
}

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
int
detect_world_deadlock(int world_to_anaylze, 
                      FusionEntries *skirmish_entries,
                      FusionSkirmish *skirmish,
                      int skirmish_wid,
                      int fusion_id)
{
     FusionSkirmish *s;
     int             i;
     int             ret = 0;
     bool            outer = true;

     int skirmish_id  = skirmish->entry.id;

     /* look in currently acquired skirmishs for this one being
        a pre-acquisition, indicating a potential deadlock */
     fusion_list_foreach (s, skirmish_entries->list) {
          if (s->lock_pid != current->pid)
               continue;

          outer = false;

          for (i=0; i<MAX_PRE_ACQUISITIONS; i++) {
               if (s->pre_acquis_worlds[i] == skirmish_wid + 1  &&
                       s->pre_acquis[i] == skirmish_id + 1) {

                    char msg[1024];

                    snprintf(msg, 1023, KERN_DEBUG "FusionSkirmish: Potential deadlock "
                            "between locked \"%s\" (0x%x) in world %d and to be locked \"%s\" (0x%x) in world %d!\n",
                            s->entry.name, s->entry.id, world_to_anaylze, /*locked*/
                            skirmish->entry.name, skirmish->entry.id, skirmish_wid /*tobe locked*/
                          );

                    printk( msg );

#ifdef CONFIG_MINI_CORE
                    {
                        char path[128];
                        int localret;

                        snprintf(path, 127, "/cores/minideadlock-%d.%02x:%d.%02x",
                                world_to_anaylze, s->entry.id, 
                                skirmish_wid, skirmish->entry.id);

                        int minicore_backtrace(struct task_struct *task, char *minicore_path, char *msg);
                        localret = minicore_backtrace(current, path, msg);
                        if (localret)
                        {
                            printk(KERN_DEBUG "Could not dump a minicore for deadlock: %d\n", localret);
                        }
                    }
#endif
               }
          }
     } // fusion_list_foreach
   
     if (!outer) 
          skirmish->outer = false;

     /* remember all previously acquired skirmishs being pre-acquisitions for
        this one, to detect potential deadlocks due to a lock order twist */
     fusion_list_foreach (s, skirmish_entries->list) {
          int free = -1;

          if (s->lock_pid != current->pid)
               continue;

          /* look for pre_acquisition record, and ignore if
           * it has been already recorded */
          for (i=0; i<MAX_PRE_ACQUISITIONS; i++) {
               if (skirmish->pre_acquis[i]) {
                    if (skirmish->pre_acquis_worlds[i] == world_to_anaylze + 1 &&
                            skirmish->pre_acquis[i] == s->entry.id + 1) {
                        break;
                    }
               }
               else
                    free = i;
          }

          /* not found? */
          if (i == MAX_PRE_ACQUISITIONS) {
               if (free != -1) {
                    skirmish->pre_acquis_worlds[free] = world_to_anaylze + 1;
                    skirmish->pre_acquis[free] = s->entry.id + 1;
               }
               else {
                    printk( KERN_DEBUG "FusionSkirmish: Too many pre-acquisitions to remember.\n" );

                    printk( KERN_DEBUG " [ '%s' ] <- ", skirmish->entry.name );

                    for (i=0; i<MAX_PRE_ACQUISITIONS; i++)
                         printk( "%d:0x%03x ",
                                skirmish->pre_acquis_worlds[i] - 1,
                                skirmish->pre_acquis[i] - 1 );

                    printk( "\n" );
               }
          }
      } // fusion_list_foreach

     return ret;
}

/**
 * Check all worlds for deadlocks except for your own world.
 */
int
detect_multi_world_deadlock(FusionDev *dev,
                            FusionSkirmish *skirmish,
                            int fusion_id)
{
    int ret = 0;

    /* detect deadlocks in all other worlds */
    int world;
    for (world = 0; world < NUM_WORLDS; world++)
    {
        FusionEntries *skirmish_entries;

        /* skip your own world. */
        if (world == dev->index)
            continue;

        if (world_get_skirmishs_interruptible(world, &skirmish_entries))
            continue;

        if (!skirmish_entries)
            continue;

        if (down_interruptible(&skirmish_entries->lock))
        {
            ret = -EINTR;
            goto cleanup;
        }

        ret = detect_world_deadlock(world, skirmish_entries,
                        skirmish, dev->index, fusion_id);
        if (ret)
        {
            up(&skirmish_entries->lock);
            goto cleanup;
        }

        up(&skirmish_entries->lock);
    }

cleanup:
    return ret;
}
#endif

int
fusion_skirmish_prevail (FusionDev *dev, int id, int fusion_id)
{
     int             ret;
     FusionSkirmish *skirmish;

     dev->stat.skirmish_prevail_swoop++;

     ret = fusion_skirmish_lock( &dev->skirmish, id, true, &skirmish );
     if (ret)
          return ret;

     if (skirmish->lock_pid == current->pid) {
          skirmish->lock_count++;
          skirmish->lock_total++;
          fusion_skirmish_unlock( skirmish );
          up( &dev->skirmish.lock );
          return 0;
     }

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     skirmish->outer = true;

     /* detect potential deadlock for one's own world. */
     ret = detect_world_deadlock(
                dev->index, &dev->skirmish,
                skirmish, dev->index, fusion_id);
     if (ret)
     {
         fusion_skirmish_unlock( skirmish );
         up( &dev->skirmish.lock );
         return ret;
     }
#endif

     up( &dev->skirmish.lock );

#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     ret = detect_multi_world_deadlock(dev, skirmish, fusion_id);
     if (ret)
     {
         fusion_skirmish_unlock( skirmish ); 
         return ret;
     }
#endif

     while (skirmish->lock_pid) {
          ret = fusion_skirmish_wait( skirmish, NULL );
          if (ret)
               return ret;
     }

     skirmish->lock_fid   = fusion_id;
     skirmish->lock_pid   = current->pid;
     skirmish->lock_count = 1;

     skirmish->lock_total++;

     fusion_skirmish_unlock( skirmish );

     return 0;
}

int
fusion_skirmish_swoop (FusionDev *dev, int id, int fusion_id)
{
     int             ret;
     FusionSkirmish *skirmish;

     ret = fusion_skirmish_lock( &dev->skirmish, id, false, &skirmish );
     if (ret)
          return ret;

     dev->stat.skirmish_prevail_swoop++;

     if (skirmish->lock_fid) {
          if (skirmish->lock_pid == current->pid) {
               skirmish->lock_count++;
               skirmish->lock_total++;
               fusion_skirmish_unlock( skirmish );
               return 0;
          }

          fusion_skirmish_unlock( skirmish );

          return -EAGAIN;
     }

     skirmish->lock_fid   = fusion_id;
     skirmish->lock_pid   = current->pid;
     skirmish->lock_count = 1;

     skirmish->lock_total++;

     fusion_skirmish_unlock( skirmish );

     return 0;
}

int
fusion_skirmish_lock_count (FusionDev *dev, int id, int fusion_id, int *ret_lock_count)
{
     int             ret;
     FusionSkirmish *skirmish;

     ret = fusion_skirmish_lock( &dev->skirmish, id, false, &skirmish );
     if (ret)
          return ret;

     if (skirmish->lock_fid == fusion_id &&
         skirmish->lock_pid == current->pid)
     {
          *ret_lock_count = skirmish->lock_count;
     }
     else
     {
          *ret_lock_count = 0; 
     }

     fusion_skirmish_unlock( skirmish );

     return 0;
}

int
fusion_skirmish_dismiss (FusionDev *dev, int id, int fusion_id)
{
     int             ret;
     FusionSkirmish *skirmish;

     ret = fusion_skirmish_lock( &dev->skirmish, id, false, &skirmish );
     if (ret)
          return ret;

     dev->stat.skirmish_dismiss++;

     if (skirmish->lock_pid != current->pid) {
          fusion_skirmish_unlock( skirmish );
          return -EIO;
     }

     if (--skirmish->lock_count == 0) {
          skirmish->lock_fid = 0;
          skirmish->lock_pid = 0;

          fusion_skirmish_notify( skirmish, true );
     }

     fusion_skirmish_unlock( skirmish );

     return 0;
}

int
fusion_skirmish_destroy (FusionDev *dev, int id)
{
#ifdef FUSION_DEBUG_SKIRMISH_DEADLOCK
     int             i;
     int             ret = 0;
     FusionSkirmish *s;
     int world;

     for (world = 0; world < NUM_WORLDS; world++)
     {
         FusionEntries *skirmish_entries;

         if (world_get_skirmishs_interruptible(world, &skirmish_entries))
         {
            ret = -EINTR;
            goto cleanup;
         }

         if (!skirmish_entries)
            continue;

         /* Lock entries. */
         if (down_interruptible( &skirmish_entries->lock ))
         {
             ret = -EINTR;
             goto cleanup;
         }

         /* remove from all pre-acquisition lists */
         fusion_list_foreach (s, skirmish_entries->list) {
             for (i=0; i<MAX_PRE_ACQUISITIONS; i++) {
                 if (s->pre_acquis_worlds[i] == dev->index + 1 &&
                         s->pre_acquis[i] == id + 1)
                 {
                     s->pre_acquis_worlds[i] = 0;
                     s->pre_acquis[i] = 0;
                 }
             }
         }

         up( &skirmish_entries->lock );
     }

cleanup:

     /* FIXME: gap? */
#endif

     return fusion_entry_destroy( &dev->skirmish, id );
}

void
fusion_skirmish_dismiss_all (FusionDev *dev, int fusion_id)
{
     FusionLink *l;

     down (&dev->skirmish.lock);

     fusion_list_foreach (l, dev->skirmish.list) {
          FusionSkirmish *skirmish = (FusionSkirmish *) l;

          down (&skirmish->entry.lock);

          if (skirmish->lock_fid == fusion_id) {
               skirmish->lock_fid   = 0;
               skirmish->lock_pid   = 0;
               skirmish->lock_count = 0;

               wake_up_interruptible_all (&skirmish->entry.wait);
          }

          up (&skirmish->entry.lock);
     }

     up (&dev->skirmish.lock);
}

void
fusion_skirmish_dismiss_all_from_pid (FusionDev *dev, int pid)
{
     FusionLink *l;

     down (&dev->skirmish.lock);

     fusion_list_foreach (l, dev->skirmish.list) {
          FusionSkirmish *skirmish = (FusionSkirmish *) l;

          down (&skirmish->entry.lock);

          if (skirmish->lock_pid == pid) {
               skirmish->lock_fid   = 0;
               skirmish->lock_pid   = 0;
               skirmish->lock_count = 0;

               wake_up_interruptible_all (&skirmish->entry.wait);
          }

          up (&skirmish->entry.lock);
     }

     up (&dev->skirmish.lock);
}

