/******************************************************************************
 *
 * Copyright (c) 1994-1999 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: StartupCode.c
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *		Application startup code for applications compiled using Metrowerks
 *	Tools. 
 *
 *    This module must be linked in with Pilot applications that run
 *  on the device.
 *
 * History:
 *   	2/ 1/95 RM - Created by Ron Marianetti
 *   	4/17/97 SL - Changes for PalmOS 2.0 SDK
 *   11/ 6/97 SL - Commented out references to __InitCode__() since
 *							CWPro2 linker no longer supplies corresponding stub
 *   12/ 3/99 SL - Changes for PalmOS 3.5 SDK
 *
 *****************************************************************************/

// Include only the specific headers that we need
#include <PalmTypes.h>
#include <SystemMgr.h>
#include <ErrorBase.h>
#include <ErrorMgr.h>		// for ErrDisplay()


// this is data init code called by __startup__()
//extern  void	__InitCode__(void);				

// Our internal startup code
UInt32 __Startup__(void);


/****************************************************************/
/* Purpose..: The Startup routine for Applications		*/
/* Input....: ---						*/
/* Returns..: ---						*/
/****************************************************************/
UInt32 __Startup__(void)
{
	UInt32			result;
	void *			prevGlobalsP;
	void *			globalsP;
	Err				err;
	SysAppInfoPtr	appInfoP;
	
	
	// Call the Standary system code for allocating and initializing globals and
	//  setting up A5, and getting the command line arguments
	err = SysAppStartup(&appInfoP, &prevGlobalsP, &globalsP);
	if (err) {
		ErrDisplay("Error launching application");
		return 0;
		}
		
		
	// Call Init code provided by the compiler
//	if (appInfoP->launchFlags & sysAppLaunchFlagNewGlobals)
//		__InitCode__();


	// Call the PilotMain routine and get the result
	result = PilotMain(appInfoP->cmd, appInfoP->cmdPBP, appInfoP->launchFlags);
	
	
	// Call SysAppExit to dispose of application allocated memory chunks
	//  and delete the AMX task if this app was on it's own thread
	SysAppExit(appInfoP, prevGlobalsP, globalsP);
	
	return result;
}



// Include runtime support unless the compiler variable SEPARATE_RUNTIME is
//  specified
#ifndef	SEPARATE_RUNTIME
#include "CWRuntime.c"
#endif
