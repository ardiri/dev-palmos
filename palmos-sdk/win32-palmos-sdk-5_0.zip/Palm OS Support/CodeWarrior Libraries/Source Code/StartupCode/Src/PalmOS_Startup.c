/*
 *	File:		PalmOS_Startup.c
 *				�1993-1998 metrowerks Inc. All rights reserved
 *	Author:	Berardino E. Baratta
 *
 *	Content:	Startup code for PalmOS applications.
 *
 *	History:	12/ 7/99 SCL	Eliminated dependencies on private OS header files.
 *
 */

#include <PalmTypes.h>
#include <SystemMgr.h>
#include <ErrorMgr.h>

#include <Exception68K.h>
#include <NMWException.h>

#include <setjmp.h>

/*
 *	The following macros control what routines will be linked into the runtime
 *	library.  You can turn them off in order to conserve space in your application.
 *
 *	If you are not going to run your app on a 1.0 device, then set the
 *	"SUPPORT_1_0_DEVICES" macro to 0.
 *
 *	If you are not going to take advantage of the multi segment support, then
 *	set the "SUPPORT_MULTI_SEGMENT_CODE" macro to 0.
 *
 */

#define SUPPORT_MULTI_SEGMENT_CODE		1
#define SUPPORT_1_0_DEVICES				1

/* typedefs */
typedef union GetData {
	char	raw[4];
	short	word;
	long	lword;
} GetData; 

typedef struct SegmentHeader {	/* the structure of a segment header								*/
	short	jtsoffset;			/* A5 relative offset of this segments jump table (short version)	*/
	short	jtentries;			/* number of entries in this segments jump table					*/
	long	jtloffset;			/* A5 relative offset of this segments jump table (long version)	*/
	long	xrefoffset;			/* offset of xref data in this CODE resource						*/
	char	code[];				/* the code															*/
};

typedef struct JumpTableEntry {	/* the structure of a jumptable entry								*/
	short	jumpinstruction;	/* instruction: jmp routine											*/
	long	jumpaddress;		/* absolute or relative address of rountine							*/
};

/* forward declarations for prototypes */
static void 	__PatchV10Devices__(SysAppInfoPtr appInfoP);
static void		__LoadAndRelocate__(Boolean load, MemHandle code1H);
void				__InitCode__(void);				
UInt32			__Startup__(void);

/* imported data */
extern segment_map	SEGMAPNAME[];

/* global data */
jmp_buf		__exit_jmp_buf;		/* jmpbuf to handle abort/exit */

/* inline routines */
static long GetA5(void) = 0x200D;			/* move.l a5,d0 */


/*
 *	Main entry point for applications
 */
UInt32 __Startup__(void)
{
	UInt32			result;
	MemPtr			prevGlobalsP;
	MemPtr			globalsP;
	Err				err;
	SysAppInfoPtr	appInfoP;
	int				abort_result = 0;
	Boolean			globals_are_setup;
	
	/*
	 *	Call the standard system code for allocating and initializing globals and
	 *	setting up A5, and getting the command line arguments
	 */
	err = SysAppStartup(&appInfoP, &prevGlobalsP, &globalsP);
	if (err) {
		ErrDisplay("Error launching application");
		return 0;
	}

	globals_are_setup = appInfoP->launchFlags & sysAppLaunchFlagNewGlobals;

	if (globals_are_setup)
	{
#if SUPPORT_1_0_DEVICES
		/* Patch 1.0 apps post launch so that they can handle data-data relocations */
		__PatchV10Devices__(appInfoP);
#endif

		/* Initialize the global exit/abort buffer */
		abort_result = setjmp(__exit_jmp_buf);
	}
	
	if (abort_result == 0)
	{
		if (globals_are_setup)
		{
#if SUPPORT_MULTI_SEGMENT_CODE
			/* Relocate multi-segment applications */
			__LoadAndRelocate__(true, appInfoP->codeH);
#endif

			/* Call Init code provided by the compiler */
			__InitCode__();
		}

		/* Call the PilotMain routine and get the result */
		result = PilotMain(appInfoP->cmd, appInfoP->cmdPBP, appInfoP->launchFlags);

		/* Call destrcutor code provided by the compiler */
		if (globals_are_setup)
			__destroy_global_chain();
	}
	
#if SUPPORT_MULTI_SEGMENT_CODE

	if (appInfoP->launchFlags & sysAppLaunchFlagNewGlobals)
		__LoadAndRelocate__(false, appInfoP->codeH);

#endif

__STARTUP_EXIT__:

	/*
	 *	Call SysAppExit to dispose of application allocated memory chunks
	 *	and delete the AMX task if this app was on it's own thread
	 */
	SysAppExit(appInfoP, prevGlobalsP, globalsP);
	
	return result;
}


/*
 *	The linker will replace this dummy routine with a linker generated routine containing
 *	a list of calls to all our static initialization routines ...
 *
 *					__InitCode0__
 *					...
 *					__InitCodeN__
 *
 */
void __InitCode__(void)
{
}


#if SUPPORT_1_0_DEVICES

/*
 *	Skip over the compressed data part of the DATA section to get to the
 *	XREF relocation info.
 */
static char *__SkipToXREFs__(char *ptr)
{
	int			i,data;
	
	ptr += 4;

	for(i = 0; i<3; i++)
	{
		ptr += 4;
		while(1)
		{
			data = *ptr++;

			if(data & 0x80)
			{	/* skip (x&0x7f)+1 raw data bytes */
				data &= 0x7F;
				ptr += data + 1;
				continue;
			}

			if(data & 0x40)
			{	/* skip (x&0x3f)+1 0x00 data bytes */
				continue;
			}

			if(data & 0x20)
			{	/* skip (x&0x1f)+2 repeating data bytes */
				data = (data & 0x1F) + 1;
				ptr++;
				continue;
			}

			if(data & 0x10)
			{	/* skip (x&0x0f)+1 0xFF data bytes */
				continue;
			}

			switch(data)
			{
				default:
				case 0x00:
					break;

				case 0x01:
					ptr += 2;
					continue;

				case 0x02:
				case 0x03:
					ptr += 3;
					continue;

				case 0x04:
					ptr += 4;
					continue;
			}
			break;
		}
	}
	return ptr;
}

#endif


#if SUPPORT_MULTI_SEGMENT_CODE || SUPPORT_1_0_DEVICES

/*
 *	Relocate a given set of XREFS
 */
static char *__Relocate__(char *ptr,char *segment,long relocbase)
{
	GetData	data;
	long	offset,relocations;
	char	c;

	data.raw[0]=*ptr++; data.raw[1]=*ptr++; data.raw[2]=*ptr++; data.raw[3]=*ptr++;
	relocations=data.lword;

	for(offset=0L; relocations>0; relocations--)
	{
		c=*ptr++;
		if(c&0x80)
		{	//	8-bit signed delta
			c<<=1; offset+=c;
		}
		else
		{
			data.raw[0]=c; data.raw[1]=*ptr++;
			if(c&0x40)
			{	//	15-bit unsigned delta
				
				offset+=(short)(data.word<<2)>>1;
			}
			else
			{	//	direct signed 31-bit offset
				data.raw[2]=*ptr++; data.raw[3]=*ptr++;
				offset=(data.lword<<2)>>1;
			}
		}
		*(long *)(segment+offset)+=relocbase;
	}
	return ptr;
}

#endif

#if SUPPORT_1_0_DEVICES

/*
 *	Patch 1.0 devices so that DATA-DATA and DATA-CODE relocations
 *	can occur.
 */
static void __PatchV10Devices__(SysAppInfoPtr appInfoP)
{
	if ((appInfoP->launchFlags & sysAppLaunchFlagDataRelocated) == 0)
	{
		MemHandle		dataH;
		char				*a5World, *code1P, *dataP, *xrefs;
		Err				err = 0;
	
		/* get a locked down pointer to the base of the CODE 1 segment. */
		code1P = MemHandleLock(appInfoP->codeH);
	
		/* get the A5 world's address */
		a5World = (char *)GetA5();
	
		/* get a locked down pointer to the DATA section */
		dataH = DmGet1Resource(sysResTAppGData, 0);
		dataP = MemHandleLock(dataH);
	
		/* skip over the compressed Data to get to the XREFs */
		xrefs = __SkipToXREFs__(dataP);
	
		/* relocate DATA to DATA references */
		xrefs = __Relocate__(xrefs, a5World, (long)a5World);
		
		/* relocate DATA to CODE 1 references */
		xrefs = __Relocate__(xrefs, a5World, (long)code1P);
	
		/* release our CODE section lock */
		/* NOTE: CODE is still locked since SysAppLaunch() locked it! */
		MemPtrUnlock(code1P);

		/* release the DATA section lock */
		MemHandleUnlock(dataH);
		DmReleaseResource(dataH);

		/* mark the DATA section as relocated */
		appInfoP->launchFlags |= sysAppLaunchFlagDataRelocated;
	}
}

#endif

#if SUPPORT_MULTI_SEGMENT_CODE

/*
 *	Load and relocate all secondary CODE segments of the application.
 */
static void __LoadAndRelocate__(Boolean load, MemHandle code1H)
{
	Err						err = 0;
	MemHandle				codeH;
	long						codeID = 2;
	Boolean					done = false;

	if (load)
	{
		struct SegmentHeader	*header;
		struct JumpTableEntry	*jumptable;
		char					*codeP, *code1P, *xrefs;
		long					a5World, i;
		segment_map			*smp;
	
		/* get a locked down pointer to the base of the CODE 1 segment. */
		code1P = MemHandleLock(code1H);

		/* get the A5 world's address */
		a5World = GetA5();

		/* get the base of the segment map exception info */
		smp = SEGMAPNAME;
	
		while (!done)
		{	/* loop through all the seconday CODE segments and relocate them */
			if ((codeH = DmGet1Resource(sysResTAppCode, codeID)) != NULL)
			{
				/*
				 * get the base offset pointer we lock it again to get the
				 * base pointer but will unlock it at the end to be safe.
				 */
				codeP = MemHandleLock(codeH);
				header = (struct SegmentHeader *)codeP;
				xrefs = codeP + header->xrefoffset;

				/* relocate references to DATA segment */
				xrefs = __Relocate__(xrefs, codeP, a5World); 
				
				/* relocate references to CODE segment 1 */
				xrefs = __Relocate__(xrefs, codeP, (long)code1P);
				
				/* relocate references to same CODE segment */
				/*
				 *	NB: these relocations should never occur, I leave this
				 *	in here, so that it will crash to flag an illegal relocation
				 *	although the linker is testing for these relocations internally ...
				 */
				xrefs = __Relocate__(xrefs, codeP, (long)codeP);
		
				/* fixup the jumptable */
				jumptable = (struct JumpTableEntry *)(a5World + header->jtloffset);
				for (i = header->jtentries; i > 0; --i)
				{
					jumptable->jumpaddress		+= (long)codeP;		/* add base address */ 
					jumptable++;
				}
				
				/* patch the exception tables for this segment */
				smp++;
				smp->codeptr = codeP;
			}
			else
			{	/* if we can't load the resource then we're done */
				done = true;
			}

			codeID++;
		}

		/* release our CODE section lock */
		/* NOTE: CODE is still locked since SysAppLaunch() locked it! */
		MemPtrUnlock(code1P);

	}
	else
	{	/* release all locked resources */
		while (!done)
		{
			if ((codeH = DmGet1Resource(sysResTAppCode, codeID)) != NULL)
			{
				MemHandleUnlock(codeH);
			}
			else
				done = true;

			codeID++;
		}
	}
}

#endif
