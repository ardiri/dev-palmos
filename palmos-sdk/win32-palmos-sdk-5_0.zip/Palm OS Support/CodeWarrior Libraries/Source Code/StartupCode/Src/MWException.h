/************************************************************************/
/*	Project...:	Standard C++ Library									*/
/*	Name......:	MWException.h											*/
/*	Purpose...:	portable exception handling								*/
/*  Copyright.: Copyright � 1993-1997 Metrowerks, Inc.					*/
/************************************************************************/

#ifndef __MWEXCEPTIONS__
#define __MWEXCEPTIONS__

#define CATCH_BUFSIZE	128					/*	size of global catch buffer*/

#if		defined(__MC68K__)

	#define CATCH_REGBUFSIZE	(11)		/*	D3-D7,A2-A6,SP */

#elif	defined(__POWERPC__)

	#define CATCH_REGBUFSIZE	(70)		/*	??? */

#elif	defined(__INTEL__)

	#define CATCH_REGBUFSIZE	(10)		/*	??? */

#else
#error
#endif

/*	[this section is copied from CException.h */

typedef enum ExceptionElementType {
	EET_AUTODESTROY,		/*  (partly) constructed automatic object that needs to be destroyed */
	EET_TEMPDESTROY,		/*	(partly) constructed temporary object that will need destruction */
	EET_PRETEMPDESTROY,		/*	unconstructed temporary object that will need destruction */
	EET_CATCHBLOCK,			/*	catch block type */
	EET_HANDLEDEXCEPT,		/*	exception currently beeing handled */
	EET_UNWIND,				/*	unwind marker  */
	EET_NOP,				/*	ignored node   */
	EET_DELETEOBJECT		/*	destroy and deallocate new allocated object */
}	ExceptionElementType;

typedef long CatchRegBuffer[CATCH_REGBUFSIZE];	/*	buffer to store non-volatile registers */

typedef struct CatchData {
	void					*catch_pc;		/*	pointer to catch block pc */
	CatchRegBuffer			*catch_buffer;	/*	pointer to catch jmp_buf  */
	char					last_catch;		/*	true: a try block's last catcher */
	char					reserved;		/*	reserved */
}	CatchData;

typedef struct ExceptionElement {
	struct ExceptionElement	*next;			/*	pointer to next ExceptionElement */
	union {
		struct {							/*	type == { EET_AUTODESTROY || EET_TEMPDESTROY || EET_PREAUTODESTROY || EET_DELETEOBJECT } */
			void			*destructor;	/*	pointer to destructor function */
			void			*object;		/*	pointer to memory location */
		}	autodestroy;

		struct {							/*	type == {�EET_CATCHBLOCK }  */
			char			*catchtype;		/*	pointer to catch type string */
			CatchData		*catchdata;		/*	pointer to catch data block */
		}	catchblock;

		struct {							/*	type == { EET_HANDLEDEXCEPT } */
		void				*exceptinfo;	/*	pointer to ExceptInfo */
		}	handleexcept;

	}	data;								/*	sizeof (union data) == 2 * sizeof(void *) */
	unsigned short			type;			/*	exception type one of: { ExceptionElementType } */
}	ExceptionElement;

/*	this section is copied from CException.h] */

typedef struct ExceptionState {				/*	exception context state */
	ExceptionElement	*ldc_save;			/*	__local_destructor_chain */
	void				*exc_save;			/*	__except_current */
	void				*buf_save;			/*	__except_buffer */
}	ExceptionState;

typedef struct DestructorChain {			/*	global destructor chain */
	struct DestructorChain	*next;			/*	pointer to next destructor chain element */
	void					*destructor;	/*	pointer to destructor function */
	void					*object;		/*	pointer to memory location (0L: element is marker) */
}	DestructorChain;

#ifdef __cplusplus
extern "C" {
#endif

#if __CFM68K__
#pragma import on
#endif

extern DestructorChain	*__global_destructor_chain;
extern ExceptionElement	*__local_destructor_chain;

extern void		*__register_global_object(void *object,void *destructor,void *regmem);
extern void		*__register_temp_object(void *object,void *destructor,void *regmem);
extern void		*__register_auto_object(void *object,void *destructor,void *regmem);
extern void		*__preregister_temp_object(void *object,void *destructor,void *regmem);
extern void		*__reregister_temp_object(void *regmem);
extern void		*__register_delete_object(void *object,void *destructor,void *regmem);
extern void		*__unregister_delete_object(void *object,void *regmem);

extern void		__destroy_global_chain(void);
extern void		__destroy_temp_objects(void *regmem);
extern void		__destroy_autotemp_objects(void *regmem);
extern void		__destroy_autotemp_objects_to(void *regmem);
extern void		__destroy_local_chain(void);
extern void		__dummy(void);

extern void		*__except_alloc(long size,void *destructor);
extern void		*__except_getcurp(void);
extern void		__throw(char *throwtype);
extern void		__install_catcher(long,ExceptionElement *,CatchData *,CatchRegBuffer *,void *,char *);
extern void		__setup_catchregbuffer(CatchRegBuffer *);
extern void		__catch_jump(CatchRegBuffer *,void *);

extern void		__set_exception_buffer(char *buffer,long size);
extern void		__new_exception_state(ExceptionState *newp,char *buffer,long size);
extern void		__switch_exception_state(ExceptionState *newp,ExceptionState *curp);

#if __CFM68K__
#pragma import reset
#endif

#ifdef __cplusplus
}
#endif

#endif
