/*
 *	File:		PalmOS_setjmp.c
 *				�1993-1995 metrowerks Inc. All rights reserved
 *	Author:		Berardino Baratta
 *
 *	Content:	setjmp/longjmp routines for PalmOS support ...
 *
 */

#include <setjmp.h>

asm int setjmp(jmp_buf env)
{
	movea.l	(sp)+,a1
	movea.l	(sp),a0
	movem.l	d3-d7/a1-a7,4(a0)
	moveq	#0,d0
	jmp		(a1)
}

asm void longjmp(jmp_buf env,int val)
{
	addq.l	#4,sp
	movea.l	(sp)+,a0
#if __option(fourbyteints)
	move.l	(sp), d0
#else
	move.w	(sp), d0
#endif
	bne.s	l0
	moveq	#1,d0
l0:	movem.l	4(a0),d3-d7/a1-a7
	jmp		(a1)
}
