/************************************************************************/
/*	Project...:	Standard C++ Library									*/
/*	Name......:	New.cp													*/
/*	Purpose...:	standard C++ library									*/
/*  Copyright.: Copyright � 1993-1997 Metrowerks, Inc.					*/
/************************************************************************/

#include <new>
#include <stdlib.h>
#include <MemoryMgr.h>
using namespace std;

#ifdef __MC68K__
#pragma a6frames on
#endif

// hh 971207 Moved these up to get them out of std::
//
//	allow user definined replacements of operator new/delete
//

#pragma overload	extern void *operator new(size_t) throw(bad_alloc);
#pragma overload	extern void *operator new(size_t,const nothrow_t&) throw();
#pragma overload	extern void operator delete(void *) throw();

#if __MWERKS__>=0x2020
#pragma overload	extern void *operator new[](size_t) throw(bad_alloc);
#pragma overload	extern void *operator new[](size_t,const nothrow_t&) throw();
#pragma overload	extern void operator delete[](void *) throw();
#endif

#ifdef _MSL_USING_NAMESPACE      // hh 971207 Added namespace support
	namespace std {
#endif

#ifndef NEWMODE
#define NEWMODE NEWMODE_SIMPLE	//	mode used to compile this file
#endif

#define NEWMODE_NONE	0				//	do not define operator new/delete
#define NEWMODE_SIMPLE	1			//	call NewPtr/DisposPtr
#define NEWMODE_MALLOC	2			//	use malloc/free

#if	NEWMODE==NEWMODE_SIMPLE
	#define MALLOCFUNC(x)	MemPtrNew(x)
	#define MFREEFUNC(x)		MemChunkFree(x)
	#define PTRTYPE			MemPtr
#elif	NEWMODE==NEWMODE_MALLOC
	#define MALLOCFUNC(x)	malloc(x)
	#define MFREEFUNC(x)		free(x)
	#define PTRTYPE			void *
#endif

extern new_handler	__new_handler;
nothrow_t nothrow;                // hh 980124 added nothrow

// These macros allow DebugNew.cp to redefine operators
// new and delete in debug mode while not adding any overhead
// for the non-debug case.

#ifndef OPERATOR_NEW
#define OPERATOR_NEW	operator new
#endif
#ifndef OPERATOR_DELETE
#define OPERATOR_DELETE	operator delete
#endif

#ifdef _MSL_USING_NAMESPACE       // hh 971207 Added namespace support
	}
#endif

#if NEWMODE!=NEWMODENONE

/************************************************************************/
/*	Purpose..: 	Allocate memory											*/
/*	Input....:	size of memory to allocate								*/
/*	Return...:	pointer to memory or 0L									*/
/************************************************************************/
void *OPERATOR_NEW(size_t size) throw(bad_alloc)
{
	void *ptr;

#if defined(__MODENALIB__) && NEWMODE==NEWMODE_MALLOC
	if (size==0) { size = sizeof(int); }     // hh 971208 Changed sizeof(1) to sizeof(int)
#endif

	for(;;)
	{
		if((ptr=MALLOCFUNC(size))!=NULL) break;
		if(!__new_handler)
		{
			__throw_bad_alloc();
			 break;
		}
		__new_handler();
	}
	return ptr;
}

/************************************************************************/
/*	Purpose..: 	Allocate memory											*/
/*	Input....:	size of memory to allocate								*/
/*	Return...:	pointer to memory or 0L									*/
/************************************************************************/
void *OPERATOR_NEW(size_t size,const nothrow_t&) throw()
{
	void *ptr;

#if defined(__MODENALIB__) && NEWMODE==NEWMODE_MALLOC
	if (size==0) { size = sizeof(1); }
#endif

	for(;;)
	{
		if((ptr=MALLOCFUNC(size))!=NULL) break;
		if(!__new_handler)  break;
		try { __new_handler(); }
		catch(bad_alloc&)
		{
			break;
		}
	}
	return ptr;
}

/************************************************************************/
/*	Purpose..: 	Dispose memory											*/
/*	Input....:	pointer to memory or 0L (no action if 0L)				*/
/*	Return...:	---														*/
/************************************************************************/
void OPERATOR_DELETE(void *ptr) throw()
{
	if(ptr) MFREEFUNC((PTRTYPE)ptr);
}

/************************************************************************/
/*	Purpose..: 	Array allocation/deallocation functions					*/
/*	Input....:	---														*/
/*	Return...:	---														*/
/************************************************************************/
#if __MWERKS__>=0x2020
extern void *operator new[](size_t size) throw(bad_alloc)
{
	return operator new(size);
}
extern void *operator new[](size_t size,const nothrow_t& nt) throw()
{
	return operator new(size,nt);
}
extern void operator delete[](void *ptr) throw()
{
	operator delete(ptr);
}
#endif

#endif

// hh 971207 Added namespace support
// hh 971207 Moved operator new and company up to get them out of std::
// hh 971208 Changed sizeof(1) to sizeof(int)
// hh 980121 commented out Debug_New dance.  #define new to anything at your own risk!  Not recommended!
// hh 980124 added nothrow
