/******************************************************************************
 *
 * Copyright (c) 1996-1999 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: MailTruncate.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This file defines the structures and functions of the Mail HotSync 
 *   Truncation options.
 *
 * History:
 *		July 26, 1996	Created by Art Lamb
 *
 *****************************************************************************/

extern Boolean TruncateHandleEvent (EventPtr event);
