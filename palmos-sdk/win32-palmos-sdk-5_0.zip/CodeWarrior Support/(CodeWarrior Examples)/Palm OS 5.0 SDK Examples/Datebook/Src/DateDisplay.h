/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: DateDisplay.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This file defines the display options functions.
 *
 * History:
 *		July 17, 1996	Created by Art Lamb
 *
 *****************************************************************************/

extern Boolean DisplayOptionsHandleEvent (EventType * event);
