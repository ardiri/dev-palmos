/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: DateWeek.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This file defines the Datebook's Week View functions.
 *
 * History:
 *		August 10, 1995	Created by Art Lamb
 *
 *****************************************************************************/

extern Boolean WeekViewHandleEvent (EventType * event);
