/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: DatePref.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This file defines the preference functions.
 *
 * History:
 *		September 27, 1995	Created by Art Lamb
 *
 *****************************************************************************/

extern Boolean PreferencesHandleEvent (EventType * event);
