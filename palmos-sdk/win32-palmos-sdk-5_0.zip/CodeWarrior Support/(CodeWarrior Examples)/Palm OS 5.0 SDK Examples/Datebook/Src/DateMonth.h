/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: DateMonth.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *	  This file defines the Datebook's Month View functions.
 *
 * History:
 *		April 8, 1996	Created by Art Lamb
 *
 *****************************************************************************/

extern Boolean MonthViewHandleEvent (EventType * event);
