/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrSortSim.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#define MAC_SIMULATOR_APP 1