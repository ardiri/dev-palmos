/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrList.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#ifndef ADDRLIST_H
#define ADDRLIST_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean ListHandleEvent (EventType * event);

#endif // ADDRLIST_H
