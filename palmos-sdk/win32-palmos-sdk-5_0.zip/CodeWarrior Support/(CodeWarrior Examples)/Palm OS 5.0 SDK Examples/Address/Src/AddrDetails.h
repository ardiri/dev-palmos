/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrDetails.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#ifndef ADDRDETAILS_H
#define ADDRDETAILS_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean DetailsHandleEvent (EventType * event);
Boolean DetailsDeleteRecord (void);

#endif // ADDRDETAILS_H
