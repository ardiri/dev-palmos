/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrEdit.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#ifndef ADDREDIT_H
#define ADDREDIT_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean	EditHandleEvent (EventType * event);
void	EditNewRecord ();

#endif // ADDREDIT_H
