/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrView.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#ifndef ADDRVIEW_H
#define ADDRVIEW_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean ViewHandleEvent (EventType * event);

#endif // ADDRVIEW_H
