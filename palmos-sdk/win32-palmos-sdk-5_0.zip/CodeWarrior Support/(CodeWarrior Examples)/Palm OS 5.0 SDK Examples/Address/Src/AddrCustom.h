/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: AddrCustom.h
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 *****************************************************************************/

#ifndef ADDRCUSTOM_H
#define ADDRCUSTOM_H

#include <Event.h>


/************************************************************
 * Function Prototypes
 *************************************************************/

Boolean CustomEditHandleEvent (EventType * event);

#endif // ADDRCUSTOM_H
