/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: example_data_type.c
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *
 *
 *****************************************************************************/


typedef struct {
	unsigned long number1;
	unsigned long number2;
} ExampleStructType;
