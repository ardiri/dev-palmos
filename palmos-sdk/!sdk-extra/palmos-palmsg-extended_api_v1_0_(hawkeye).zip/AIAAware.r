
#define kAIAAwareApp            1   
#define kRotateAwareApp         2

type 'Smrt' {
    //Currently no data is stored in resource, need dummy otherwise 
    //resource is not linked in
    unsigned longint;   
};


resource 'Smrt' (1000, "Smart App")
{
    kAIAAwareApp + kRotateAwareApp;
};
