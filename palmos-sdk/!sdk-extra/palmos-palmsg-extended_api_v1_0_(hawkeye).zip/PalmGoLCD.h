/******************************************************************************
 *
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: PalmGoLCD.h
 *
 * Description:
 *      Public API for the GoLCD Library
 *
 * History:
 *		Version 1.1		- Fixed LibTraps and added creator ID (03/03/03)
 *		Version 1.0		- Intial Revision (02/04/03)
 *
 *****************************************************************************/

#ifndef __PALMGOLCD_H__
#define __PALMGOLCD_H__

#include <PalmTypes.h>
#include <LibTraps.h>

/********************************************************************
 * Library type and creator
 ********************************************************************/
#define goLcdLibName          "GoLcdLib" 
#define goLcdLibType          'libr'
#define goLcdLibCreator       'GAny'
#define goLcdLibFtrNum         0

/********************************************************************
 * Constants
 ********************************************************************/
typedef Int32 GoLcdStatusType;

#define	goLcdNotAvailable	   -1
#define goLcdDisabled			0
#define goLcdEnabled			1

typedef Int32 GoLcdInkStateType;

#define goLcdInkDisabled		0
#define goLcdInkEnabled			1

typedef UInt32 GoLcdModeType;

#define goLcdGraffitiMode		0
#define goLcdPenTapMode			1
#define goLcdModeCount			2

typedef UInt32 GoLcdGsiStateType;

#define goLcdGsiNormal			0 
#define goLcdGsiOverride		1 

typedef UInt32 GoLcdColorModeType;

#define goLcdColorDefault		0
#define goLcdColorOverride		1
#define goLcdColorInverted		2  

/********************************************************************
 * Traps
 ********************************************************************/
#define kGoLcdLibTrapOpen				sysLibTrapOpen
#define kGoLcdLibTrapClose				sysLibTrapClose

#define kGoLcdLibTrapGetStatus			(sysLibTrapCustom)
#define kGoLcdLibTrapSetStatus			(sysLibTrapCustom+1)
#define kGoLcdLibTrapGetInkState		(sysLibTrapCustom+2)
#define kGoLcdLibTrapSetInkState		(sysLibTrapCustom+3)
#define kGoLcdLibTrapGetTimeout			(sysLibTrapCustom+4)
#define kGoLcdLibTrapSetTimeout			(sysLibTrapCustom+5)
#define kGoLcdLibTrapGetBounds			(sysLibTrapCustom+6)
#define kGoLcdLibTrapSetBounds			(sysLibTrapCustom+7)
#define kGoLcdLibTrapGetGsiState		(sysLibTrapCustom+8)
#define kGoLcdLibTrapSetGsiState		(sysLibTrapCustom+9)

#define GoLcdLibAPIVersion				(sysMakeROMVersion(3, 6, 0, sysROMStageBeta, 0))

/********************************************************************
 * Prototypes
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

Err GoLcdLibOpen(UInt16 refnum)
				SYS_TRAP(kGoLcdLibTrapOpen);

Err GoLcdLibClose(UInt16 refnum)
				SYS_TRAP(kGoLcdLibTrapClose);

GoLcdStatusType GoLcdGetStatus(UInt16 refnum)
				SYS_TRAP(kGoLcdLibTrapGetStatus);

GoLcdStatusType GoLcdSetStatus(UInt16 refnum, GoLcdStatusType status)
				SYS_TRAP(kGoLcdLibTrapSetStatus);

void GoLcdGetInkState(UInt16 refnum,GoLcdInkStateType *stateP,GoLcdColorModeType *colorModeP,RGBColorType *rgbP)
				SYS_TRAP(kGoLcdLibTrapGetInkState);

void GoLcdSetInkState(UInt16 refnum, GoLcdInkStateType state,GoLcdColorModeType colorMode,RGBColorType *rgbP)
				SYS_TRAP(kGoLcdLibTrapSetInkState);

void GoLcdGetGsiState(UInt16 refnum,GoLcdGsiStateType *stateP,GoLcdColorModeType *colorModeP,RGBColorType *rgbP)
				SYS_TRAP(kGoLcdLibTrapGetGsiState);

void GoLcdSetGsiState(UInt16 refnum, GoLcdGsiStateType state,GoLcdColorModeType colorMode,RGBColorType *rgbP)
				SYS_TRAP(kGoLcdLibTrapSetGsiState);

UInt32 GoLcdGetTimeout(UInt16 refnum, GoLcdModeType mode)
				SYS_TRAP(kGoLcdLibTrapGetTimeout);

UInt32 GoLcdSetTimeout(UInt16 refnum, GoLcdModeType mode, UInt32 ticks)
				SYS_TRAP(kGoLcdLibTrapSetTimeout);

void GoLcdGetBounds(UInt16 refnum, RectangleType *r)
				SYS_TRAP(kGoLcdLibTrapGetBounds);

void GoLcdSetBounds(UInt16 refnum, RectangleType *r)
				SYS_TRAP(kGoLcdLibTrapSetBounds);

#ifdef __cplusplus 
}
#endif

#endif 	//__PALMGOLCD_H__
