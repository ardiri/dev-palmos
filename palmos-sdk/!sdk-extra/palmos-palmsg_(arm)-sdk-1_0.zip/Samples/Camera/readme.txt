. Camera Library Sample Code

This sample code shows how to use the camera library API.
This project was built using CodeWarrior 9. It uses PilRC
resources but I also have included a regular constructor
resource, although you might need to change the names of
the pop-up trigger and button.

Features:

- Simple Camera application.
- Shows 2 different preview sizes.
- Handles slider notifications and status.
- Has "ready to use" code for capture.

Files:

- CameraSample : Main application. Does all the work.
- CameraSliderUtils: Wrapper functions for the camera slider API.
- CameraUtils: Wrapper functions for the camera API.

Issues:

- The header file for the PilRC resource is read-only. You need to
change it back to write mode before compiling. CW9 will complain!