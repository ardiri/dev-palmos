/***********************************************************************
 *
 * Copyright (c) 2001 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CameraUtils.c
 *
 * Description:
 *	
 *
 *	Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/

#include <PalmTypes.h>
#include "CameraUtils.h"

/***********************************************************************
 *
 * FUNCTION:	LoadCameraLib
 *
 * DESCRIPTION: Load the camera lib, open it and check the version.
 *
 * PARAMETERS:	refNumP			- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/
 
Err LoadCameraLib(UInt16 *refNumP)
{
	Err 	err = errNone; 
	UInt16 	refNum = 0;
	Boolean loaded = true;
	UInt32 	libVersion = 0;
	
	// Try to find the hardware utils library
	err = SysLibFind(kCamLibName, &refNum);
	if (err != errNone)
	{
		err = SysLibLoad(kCamLibType, kCamLibCreator, &refNum);
		loaded = true;
	}
	if (err)
		goto Done;

	// Open it
	err = CamLibOpen(refNum);
	if (err != errNone)
	{
		if (loaded)	{
			// Only remove it if it was just loaded
			SysLibRemove(refNum);
		}
		goto Done;
	}
			
Done:
	*refNumP = refNum;
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	UnloadCameraLib
 *
 * DESCRIPTION: Onload the hardware lib
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/
 
Err UnloadCameraLib(UInt16 refNum)
{
	Err err = errNone;
	if (refNum == sysInvalidRefNum)
		return kCamLibErrNotOpen;
		
	err = CamLibClose(refNum);
	if (err == errNone)
	{
		err = SysLibRemove(refNum);
		ErrNonFatalDisplayIf(err, "SysLibRemove failed");
	}
	
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	ShowSettingsDialog
 *
 * DESCRIPTION: Display the camera hardware settings dialog
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	ShowSettingsDialog(UInt16 refNum)
{
	return CamLibControl(refNum, kCamLibCtrlHardwareSettingsDlg, 0);
}

/***********************************************************************
 *
 * FUNCTION:	TurnCameraOn
 *
 * DESCRIPTION: Turn the camera on.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	TurnCameraOn(UInt16 refNum)
{
	return CamLibControl(refNum, kCamLibCtrlPowerOn, 0);
}

/***********************************************************************
 *
 * FUNCTION:	TurnCameraOff
 *
 * DESCRIPTION: Turn the camera off.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	TurnCameraOff(UInt16 refNum)
{
	return CamLibControl(refNum, kCamLibCtrlPowerOff, 0);
}

/***********************************************************************
 *
 * FUNCTION:	StartCameraPreview
 *
 * DESCRIPTION: Start the preview.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	StartCameraPreview(UInt16 refNum)
{
	return CamLibControl(refNum, kCamLibCtrlPreviewStart, 0);
}

/***********************************************************************
 *
 * FUNCTION:	StopCameraPreview
 *
 * DESCRIPTION: Stop the preview. It's important to stop the proview when
 *				other UI are being displayed (like a dialog) because the
 *				preview image would be drawn on top of it.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err StopCameraPreview(UInt16 refNum)
{
	return CamLibControl(refNum, kCamLibCtrlPreviewStop, 0);
}

/***********************************************************************
 *
 * FUNCTION:	SetPreviewSize
 *
 * DESCRIPTION: Set the preview size.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	SetPreviewSize(UInt16 refNum, CamLibImageSizeType *previewSize)
{
	return CamLibControl(refNum, kCamLibCtrlPreviewSizeSet, (void*)previewSize);
}

/***********************************************************************
 *
 * FUNCTION:	SetPreviewRectangle
 *
 * DESCRIPTION: Set the preview rextangle.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	SetPreviewRectangle(UInt16 refNum, RectangleType *rectP)
{
	return CamLibControl(refNum, kCamLibCtrlPreviewRectSet, (void*)rectP);
}

/***********************************************************************
 *
 * FUNCTION:	SetCaptureSize
 *
 * DESCRIPTION: Set the capture size.
 *
 * PARAMETERS:	refNum		- Library reference number
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

Err	SetCaptureSize(UInt16 refNum, CamLibImageSizeType *captureSize)
{
	return CamLibControl(refNum, kCamLibCtrlCaptureSizeSet, (void*)captureSize);
}
