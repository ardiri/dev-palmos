/***********************************************************************
 *
 * Copyright (c) 2001 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CameraUtils.h
 *
 * Description:
 *	Camera utility functions.
 *
 * Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/

#ifndef CAMERAUTILS_H_
#define CAMERAUTILS_H_

#include "PalmCameraLib.h"

/************************************************************
 * Function Prototypes
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

Err		LoadCameraLib(UInt16 *refNumP);
Err		UnloadCameraLib(UInt16 refNum);

Err		TurnCameraOn(UInt16 refNum);
Err		TurnCameraOff(UInt16 refNum);

Err		StartCameraPreview(UInt16 refNum);
Err		StopCameraPreview(UInt16 refNum);

Err		SetPreviewSize(UInt16 refNum, CamLibImageSizeType *previewSize);
Err		SetPreviewRectangle(UInt16 refNum, RectangleType *rectP);
Err		SetCaptureSize(UInt16 refNum, CamLibImageSizeType *captureSize);

Err		ShowSettingsDialog(UInt16 refNum);

#ifdef __cplusplus 
}
#endif
 
#endif // CAMERAUTILS_H_