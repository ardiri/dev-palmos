/***********************************************************************
 *
 * Copyright (c) 2001 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CameraSliderUtils.h
 *
 * Description:
 *	Camera Slider utility functions.
 *
 * Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/

#ifndef CAMERASLIDERUTILS_H_
#define CAMERASLIDERUTILS_H_

#include "PalmCameraSlider.h"

/************************************************************
 * Function Prototypes
 *************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

Boolean IsCameraSliderAvailable();
Boolean IsCameraSliderOpen();
Err		UnregisterCameraSlider(Int8 priority);
Err		RegisterCameraSlider(Int8 priority, SysNotifyProcPtr procP, void *userDataP);

#ifdef __cplusplus 
}
#endif
 
#endif // CAMERAUTILS_H_