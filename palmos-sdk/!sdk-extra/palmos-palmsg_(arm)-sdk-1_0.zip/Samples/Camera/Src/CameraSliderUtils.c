/***********************************************************************
 *
 * Copyright (c) 2001 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CameraSliderUtils.c
 *
 * Description:
 *	Camera Slider utility functions.
 *
 *	Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/

#include <PalmTypes.h>
#include "CameraSliderUtils.h"

/***********************************************************************
 *
 * FUNCTION:    IsCameraSliderAvailable
 *
 * DESCRIPTION: Check if the camera slider is available.
 *
 * PARAMETERS:  -
 *
 * RETURNED:    True if available
 *
 ***********************************************************************/

Boolean IsCameraSliderAvailable()
{
	UInt32 sliderVersion;
	Err err = FtrGet(kCamSliderCreator, kCamSliderFtrVersionNum, &sliderVersion);
	
	return (err == errNone);
}


/***********************************************************************
 *
 * FUNCTION:    IsCameraSliderOpen
 *
 * DESCRIPTION: Check if the camera slider is open.
 *
 * PARAMETERS:  -
 *
 * RETURNED:    True if the camera slider is open, false if closed.
 *
 ***********************************************************************/

Boolean IsCameraSliderOpen()
{

	UInt32 	flags = 0;
	Boolean isSliderOpened = false;
	Err 	err = errNone;
	
	err = FtrGet(kCamSliderCreator, kCamSliderFtrFlagsNum, &flags);
	if (err == errNone)	{
		isSliderOpened = (flags & kCamSliderFlagsOpened);
	}
	
	return isSliderOpened;
}

/***********************************************************************
 *
 * FUNCTION:    UnregisterCameraSlider
 *
 * DESCRIPTION: Unregister the camera slider notification for the
 *				current application.
 *
 * PARAMETERS:  priority	- The registration priority
 *
 * RETURNED:    Err
 *
 ***********************************************************************/

Err UnregisterCameraSlider(Int8 priority)
{
	UInt16 	cardNo;
	LocalID dbID;
	Err 	err = errNone;
	
	err = SysCurAppDatabase(&cardNo, &dbID);
	if(err)
		goto Done;
	
	// Unregister for the notification		
	err = SysNotifyUnregister(cardNo, dbID, kCamSliderCreator, priority);		
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:    RegisterCameraSlider
 *
 * DESCRIPTION: Register the camera slider notification with the
 *				current application.
 *
 * PARAMETERS:  priority	- The registration priority
 *				procP		- A SysNotifyProcPtr pointer
 *				userDataP	- Pointer to user data
 *
 * RETURNED:    Err
 *
 ***********************************************************************/

Err RegisterCameraSlider(Int8 priority, SysNotifyProcPtr procP, void *userDataP)
{
	UInt16 	cardNo;
	LocalID dbID;
	Err		err = errNone;
	
	err = SysCurAppDatabase(&cardNo, &dbID);
	if(err)
		goto Done;
	
	// Registering for camera slider notification
	err = SysNotifyRegister(cardNo, dbID, kCamSliderCreator, procP, priority, userDataP);
	
Done:
	return err;
}
