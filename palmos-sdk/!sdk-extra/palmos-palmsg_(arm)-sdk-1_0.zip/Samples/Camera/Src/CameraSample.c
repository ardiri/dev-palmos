/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CamerSample.c
 *
 * Description:
 *	Sample code for the camera API
 *
 *	Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/
 
#include <PalmOS.h>
#include "PalmChars.h"
#include "CameraSample.h"
#include "CameraSample_Rsc.h"
#include "CameraUtils.h"
#include "CameraSliderUtils.h"

/*********************************************************************
 * Internal Constants
 *********************************************************************/

#define ourMinVersion    sysMakeROMVersion(5,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

#define kSliderNotificationPriority		(sysNotifyNormalPriority - 32)

/*********************************************************************
 * Internal globals
 *********************************************************************/

static UInt16	gCameraRefNum		= 0;
static Boolean 	gIsSliderRegistered = false;
static Boolean	gCameraIsOn			= false;
static Boolean	gPreviewIsOn		= false;
static UInt32	gPreviousDepth		= 0;

static RectangleType gPreviewQVGARectangle = { { 0, 0 }, { 160, 120 } };
static RectangleType gPreviewQQVGARectangle = { { 40, 30 }, { 80, 60 } };
static RectangleType *gPreviewRectangle = &gPreviewQQVGARectangle;
static CamLibImageSizeType gCurrentPreviewSize = { kCamLibImageSizeQQVGA };

/***********************************************************************
 *
 * FUNCTION:    SetScreenDepth
 *
 * DESCRIPTION: Changes the screen depth
 *
 * PARAMETERS:	depth	- Screen depth e.g. 1, 2, 4, 8, 16
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

static Err SetScreenDepth(UInt32 depth)
{
	Boolean color = true;
	WinScreenMode(winScreenModeSet, 0, 0, &depth, &color);
	FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
	return errNone;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    SliderNotifyProc
 *
 * DESCRIPTION: Notification handler for the camera slider.
 *				We assume globals are always available here.
 *
 * PARAMETERS:	notifyParamsP	- Pointer to the notifiaction parameter
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

static Err SliderNotifyProc(SysNotifyParamType *notifyParamsP)
{
	Err err = errNone;
	Boolean isSliderOpened = false;
	
	// Is it the expected notification
	if(notifyParamsP->notifyType != kCamSliderNotifyEvent)
		goto Done;

	// Is it handled? We are in a cooperative mode
	if(notifyParamsP->handled)
		goto Done;

	// Check the camera slider
	if(IsCameraSliderOpen())
	{
		if(!gCameraIsOn)
		{
			// Turn the camer on
			err = TurnCameraOn(gCameraRefNum);
			if(err)
				goto Done;
								
			gCameraIsOn = true;
			
			// Set the capture size
			err = SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
			if(err)
				goto Done;
			
			// Set the preview size
			err = SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
			if(err)
				goto Done;
			
			// Set the preview rectangle
			err = SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
			if(err)
				goto Done;
			
			// Start the preview
			err = StartCameraPreview(gCameraRefNum);
			if(err)
				goto Done;
				
			gPreviewIsOn = true;
		}
	}
	else
	{
		// Stop the preview
		if( gPreviewIsOn )
		{
			err = StopCameraPreview(gCameraRefNum);
			if(err)
				goto Done;
			
			gPreviewIsOn = false;
		}
		
		// Turn the camera off		
		if( gCameraIsOn )
		{
			err = TurnCameraOff(gCameraRefNum);
			if(err)
				goto Done;
				
			gCameraIsOn = false;
		}
		
		// Refresh the current form
		FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
	}
	
	// I have handheld the notification and don't want any other app to do so
	notifyParamsP->handled = true;
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	CameraLibCaptureCallback
 *
 * DESCRIPTION:	This routine capture the image in a callback
 *
 * PARAMETERS:	None
 *
 * RETURNED:	Err
 *
 ***********************************************************************/
typedef struct
{
	MemHandle bmpH;
	UInt32 size;
} MyCallbackDataType;

static Err MyCaptureCallback(void* bufP, UInt32 size, void* userDataP)
{
	//
	// Write your capture code here
	//
	
	// Simulate a long capture time
	SysTaskDelay(sysTicksPerSecond / 2);
	
	
	return errNone;
}

static Err CameraLibCaptureCallback()
{
	MyCallbackDataType data;
	CamLibCaptureType capture;
	Err err 	= errNone;
	data.bmpH 	= 0;
	
	if (gCameraRefNum == sysInvalidRefNum)
		return kCamLibErrNotOpen;

	capture.userDataP = &data;
	capture.callbackP = MyCaptureCallback;
	err = CamLibControl(gCameraRefNum, kCamLibCtrlCapture, &capture);
	if (err == errNone)
	{
		if (data.bmpH)
			MemHandleFree(data.bmpH);
	}
	return err;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: Form event handler.
 *				Note: You should handle all the events that bring a UI
 *				up while in preview mode because the proview rectangle
 *				will overwrite anything. For example, if you try to bring
 *				the Find dialog, you'll see the preview drawn on top of 
 *				part of it. This is a sample code.
 *
 * PARAMETERS:	eventP		- Pointer to an event
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/

static Boolean MainFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormType *frmP = FrmGetActiveForm();
	
	switch(eventP->eType)
	{
		case frmOpenEvent:
			FrmDrawForm(frmP);	
			handled = true;
			break;
		
		//
		// Handle control select events
		//	
		case ctlSelectEvent:
			switch(eventP->data.ctlSelect.controlID)
			{
			case Options:
				ShowSettingsDialog(gCameraRefNum);
				handled = true;
				break;
			}
			break;
		
		//
		// Handle the key dowm events
		//		
		case keyDownEvent:
			if( EvtKeydownIsVirtual(eventP) && (eventP->data.keyDown.chr == vchrCameraShutter ) )
			{
				StopCameraPreview(gCameraRefNum);
				CameraLibCaptureCallback();	
				StartCameraPreview(gCameraRefNum);
				handled = true;
			}
			break;
			
		//
		// Handle the pop-up trigger event
		//	
		case popSelectEvent:
			switch(eventP->data.popSelect.controlID)
			{
			case PreviewSize:
				if( gPreviewIsOn ) {
					StopCameraPreview(gCameraRefNum);
					FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
				}
				if( eventP->data.popSelect.selection == 0 )
				{
					gCurrentPreviewSize.type = kCamLibImageSizeQQVGA;
					gPreviewRectangle = &gPreviewQQVGARectangle;
				}
				else
				{
					gCurrentPreviewSize.type = kCamLibImageSizeQVGA;
					gPreviewRectangle = &gPreviewQVGARectangle;
				}
				
				SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
				SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
				SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
				
				if( gPreviewIsOn )
					StartCameraPreview(gCameraRefNum);
				break;
				
			default:
				break;
			}
			break;
			
		default:
			break;
	}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: Main application event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event.
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/
 
static Boolean AppHandleEvent(EventType *eventP)
{
	UInt16 formId = 0;
	FormType *frmP = NULL;
	
	if(eventP->eType == frmLoadEvent)
	{
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);
		
		switch (formId)
		{
		case MainForm:
			FrmSetEventHandler(frmP, MainFormHandleEvent);
			break;
			
		default:
			break;
		}
		return true;
	}
	
	return false;
}

/***********************************************************************
 *
 * FUNCTION:    ApplEventLoop
 *
 * DESCRIPTION: Main Application event loop.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void AppEventLoop(void)
{
	Err error = errNone;
	EventType event;
	
	do
	{
		EvtGetEvent(&event, evtWaitForever);
				
		if(!SysHandleEvent(&event))
		{
			if (! MenuHandleEvent(0, &event, &error))
			{
				if(!AppHandleEvent(&event))
				{
					FrmDispatchEvent(&event);
				}
			}
		}
	} while(event.eType != appStopEvent);
}

/***********************************************************************
 *
 * FUNCTION:    AppStart
 *
 * DESCRIPTION: Called when the application starts
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err AppStart(void)
{	
	Err err = errNone;
	
	// Load the camera library
	err = LoadCameraLib(&gCameraRefNum);
	if( err )
		goto Done;
	
	// Check if the slider is available
	if( IsCameraSliderAvailable() )
	{
		// Register for slider notification
		err = RegisterCameraSlider(kSliderNotificationPriority, SliderNotifyProc, NULL);
		if( err == errNone )
			gIsSliderRegistered = true;
	}
	
	// Save current screen color depth
	WinScreenMode(winScreenModeGet, 0, 0, &gPreviousDepth, 0);
	
	// Switch to 16bit color
	err = SetScreenDepth(16);
	
	// Check the current slider status
	if( IsCameraSliderAvailable() && IsCameraSliderOpen() )
	{
		// Turn the camera on
		err = TurnCameraOn(gCameraRefNum);
		if(err)
			goto Done;
							
		gCameraIsOn = true;
		
		// Set the capture size
		err = SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
		if(err)
			goto Done;
		
		// Set the preview size	
		err = SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
		if(err)
			goto Done;
		
		// Set the preview rectangle
		err = SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
		if(err)
			goto Done;
		
		// Start the preview
		err = StartCameraPreview(gCameraRefNum);
		if(err)
			goto Done;
			
		gPreviewIsOn = true;
	}
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Called when the application exits
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void AppStop(void)
{
	// Stop the preview
	if( gPreviewIsOn )
	{
		StopCameraPreview(gCameraRefNum);
		gPreviewIsOn = false;
	}

	// Turn the camera off	
	if( gCameraIsOn )
	{
		TurnCameraOff(gCameraRefNum);
		gCameraIsOn = false;
	}
	
	// Unregister the slider notification
	if( gIsSliderRegistered )
	{
		UnregisterCameraSlider(kSliderNotificationPriority);
	}
	
	// Restore the previous color depth
	if( gPreviousDepth )
		SetScreenDepth(gPreviousDepth);
	
	// Close all the forms
	FrmCloseAllForms();
}

/* all code from here to end of file should use no global variables */
#pragma warn_a5_access on

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check the if the ROM is compatible with the application
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
    UInt32 romVersion;

    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion < requiredVersion)
    {
        if ((launchFlags & 
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
        {
            FrmAlert (RomIncompatibleAlert);

             if (romVersion < kPalmOS20Version)
            {
                AppLaunchWithCommand(
                    sysFileCDefaultApp, 
                    sysAppLaunchCmdNormalLaunch, NULL);
            }
        }

        return sysErrRomIncompatible;
    }

    return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: Main entry point for the application.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err error;

    error = RomVersionCompatible (ourMinVersion, launchFlags);
    if (error) return (error);

    switch (cmd)
    {
    case sysAppLaunchCmdNormalLaunch:
        error = AppStart();
        if (error) 
            return error;

        FrmGotoForm(MainForm);
        AppEventLoop();
        
        AppStop();
        break;

    default:
        break;
    }

    return errNone;
}

/* turn a5 warning off to prevent it being set off by C++
 * static initializer code generation */
#pragma warn_a5_access reset
