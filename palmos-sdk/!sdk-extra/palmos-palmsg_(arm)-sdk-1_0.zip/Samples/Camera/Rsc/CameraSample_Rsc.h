/* pilrc generated file.  Do not edit!*/
#define Options 1005
#define PreviewSizeList 1004
#define PreviewSize 1003
#define MainForm 1002
#define RomIncompatibleAlert 1001
