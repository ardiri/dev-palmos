. Five Way Sample Code

This sample code shows how to use the Five Way.
This project was built using CodeWarrior 8.

Features:

- Traps all 5-Way events.
- Uses the macros provided in PalmChars.h
- Uses keyState to allow simultaneous keys pressed

Files:

- Common : Usefeul functions for PalmOS.
- TestFiveWay : Main application.