/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	TestFiveWay.c
 *
 * Description:
 *	Test Application for Five Way
 *
 *	Version 1.0 	- Initial Revision (09/19/02)
 *
 ***********************************************************************/
 
#include <PalmOS.h>
#include <KeyMgr.h>

#include "Common.h"
#include "PalmNavigator.h"
#include "TestFiveWay.h"
#include "TestFiveWayRsc.h"

/*********************************************************************
 * Internal Constants
 *********************************************************************/

#define ourMinVersion    sysMakeROMVersion(3,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

static Char* keyName[] = { "Select", "Up", "Down", "Right", "Left" };
static Char* keyState[] = { "Pressed", "Repeat", "Released", "Not Pressed" };

/***********************************************************************
 *
 * FUNCTION:    DisplayKeyState
 *
 * DESCRIPTION: Display the 5 Way states.
 *
 * PARAMETERS:	frmP	- Pointer to a form
 *				eventP	- Event to process
 *
 * RETURNED:	True is the key was handled.
 *
 ***********************************************************************/

static Boolean DisplayKeyState(FormType *frmP, EventType *eventP)
{
	Boolean		handled		= false;
	FieldType 	*fieldP		= NULL;
	ControlType *ctlP		= NULL;
	
	// Get the KeyEvent fields
	WChar 		chr			= eventP->data.keyDown.chr;
	UInt16 		keyCode		= eventP->data.keyDown.keyCode;
	UInt16 		modifiers	= eventP->data.keyDown.modifiers;
	
	//
	// Macro section
	// 
	
	// Use macro to determine is a Select has been pressed
	ctlP = FrmGetPtr(frmP, MainSelectCheckbox);
	if(ctlP) CtlSetValue(ctlP, NavKeyPressed(eventP, Select)?true:false);
	
	// Use macro to determine is a Up has been pressed
	ctlP = FrmGetPtr(frmP, MainUpCheckbox);
	if(ctlP) CtlSetValue(ctlP, NavKeyPressed(eventP, Up)?true:false);
	
	// Use macro to determine is a Down has been pressed
	ctlP = FrmGetPtr(frmP, MainDownCheckbox);
	if(ctlP) CtlSetValue(ctlP, NavKeyPressed(eventP, Down)?true:false);
	
	// Use macro to determine is a Right has been pressed
	ctlP = FrmGetPtr(frmP, MainRightCheckbox);
	if(ctlP) CtlSetValue(ctlP, NavKeyPressed(eventP, Right)?true:false);
	
	// Use macro to determine is a Left has been pressed
	ctlP = FrmGetPtr(frmP, MainLeftCheckbox);
	if(ctlP) CtlSetValue(ctlP, NavKeyPressed(eventP, Left)?true:false);
	
	
	//
	// Chr section
	//
	
	fieldP = FrmGetPtr(frmP, MainChrField);
	switch(chr)
	{
		case vchrPageUp:
			SetFieldTextFromStr(fieldP, keyName[1] , true);
			break;
		case vchrPageDown:
			SetFieldTextFromStr(fieldP, keyName[2] , true);
			break;
		case vchrNavChange:
			if(keyCode & navBitRight)
				SetFieldTextFromStr(fieldP, keyName[3] , true);
			else if(keyCode & navBitLeft)
				SetFieldTextFromStr(fieldP, keyName[4] , true);
			else if(keyCode & navBitSelect)
				SetFieldTextFromStr(fieldP, keyName[0] , true);
			break;
	}
	
	//
	// Key state section
	//
		
	// Up
	fieldP = FrmGetPtr(frmP, MainUpField);
	if( keyCode & navBitUp ) {
		if( keyCode & navChangeUp )
			SetFieldTextFromStr(fieldP, keyState[0], true);	// Press
		else
			SetFieldTextFromStr(fieldP, keyState[1], true); // Repeat
	} else {
		if( keyCode & navChangeUp )
			SetFieldTextFromStr(fieldP, keyState[2], true);	// Released
		else
			SetFieldTextFromStr(fieldP, keyState[3], true);	// Not Pressed
	}
		
		
	////////////////////////////////////////////////////////////
	// Other Way, but doesn't handle multiple keys correctly
	////////////////////////////////////////////////////////////
	// 	if( chr == vchrPageUp ) {
	//		if( modifiers & autoRepeatKeyMask )
	//			SetFieldTextFromStr(fieldP, keyState[1], true);
	//		else
	//			SetFieldTextFromStr(fieldP, keyState[0], true);
	// 	} else {
	// 		SetFieldTextFromStr(fieldP, keyState[2], true);
	// 	}
	////////////////////////////////////////////////////////////
	
	
	
	// Down
	fieldP = FrmGetPtr(frmP, MainDownField);
	if( keyCode & navBitDown ) {
		if( keyCode & navChangeDown )
			SetFieldTextFromStr(fieldP, keyState[0], true);	// Press
		else
			SetFieldTextFromStr(fieldP, keyState[1], true);	// Repeat
	} else {
		if( keyCode & navChangeDown )
			SetFieldTextFromStr(fieldP, keyState[2], true);	// Released
		else
			SetFieldTextFromStr(fieldP, keyState[3], true);	// Not Pressed
	}

    ////////////////////////////////////////////////////////////
	// Other Way, but doesn't handle multiple keys correctly
	////////////////////////////////////////////////////////////
	//
	// if( chr == vchrPageDown ) {
	//    	if( modifiers & autoRepeatKeyMask )
	//    		SetFieldTextFromStr(fieldP, keyState[1], true);
	//   	else
	//    		SetFieldTextFromStr(fieldP, keyState[0], true);
	// } else {
	//   	SetFieldTextFromStr(fieldP, keyState[2], true);
	// }
	////////////////////////////////////////////////////////////
    
    // Left
    fieldP = FrmGetPtr(frmP, MainLeftField);
    if( keyCode & navBitLeft ) {
		if( keyCode & navChangeLeft )
			SetFieldTextFromStr(fieldP, keyState[0], true);	// Press
		else
			SetFieldTextFromStr(fieldP, keyState[1], true);	// Repeat
	} else {
		if( keyCode & navChangeLeft )
			SetFieldTextFromStr(fieldP, keyState[2], true);	// Released
		else
			SetFieldTextFromStr(fieldP, keyState[3], true);	// Not Pressed
	}

	////////////////////////////////////////////////////////////
	// Other Way, but doesn't handle multiple keys correctly
	////////////////////////////////////////////////////////////
	//
	//	if( chr == vchrNavChange && (keyCode & navBitLeft)) {
	//		if( modifiers & autoRepeatKeyMask )
	//			SetFieldTextFromStr(fieldP, keyState[1], true);
	//		else
	//			SetFieldTextFromStr(fieldP, keyState[0], true);
	//	} else {
	//		SetFieldTextFromStr(fieldP, keyState[2], true);
	//	}
	////////////////////////////////////////////////////////////
	
	// Right
	fieldP = FrmGetPtr(frmP, MainRightField);
	if( keyCode & navBitRight ) {
		if( keyCode & navChangeRight )
			SetFieldTextFromStr(fieldP, keyState[0], true);	// Press
		else
			SetFieldTextFromStr(fieldP, keyState[1], true);	// Repeat
	} else {
		if( keyCode & navChangeRight )
			SetFieldTextFromStr(fieldP, keyState[2], true);	// Released
		else
			SetFieldTextFromStr(fieldP, keyState[3], true);	// Not Pressed
	}
		
    ////////////////////////////////////////////////////////////
	// Other Way, but doesn't handle multiple keys correctly
	////////////////////////////////////////////////////////////
	//
	//	if( chr == vchrNavChange && (keyCode & navBitRight)) {
	//		if( modifiers & autoRepeatKeyMask )
	//			SetFieldTextFromStr(fieldP, keyState[1], true);
	//		else
	//			SetFieldTextFromStr(fieldP, keyState[0], true);
	//	} else {
	//		SetFieldTextFromStr(fieldP, keyState[2], true);
	//	}
	////////////////////////////////////////////////////////////
    
    // Select
    fieldP = FrmGetPtr(frmP, MainSelectField);
    if( keyCode & navBitSelect ) {
		if( keyCode & navChangeSelect )
			SetFieldTextFromStr(fieldP, keyState[0], true);	// Press
		else
			SetFieldTextFromStr(fieldP, keyState[1], true);	// Repeat
	} else {
		if( keyCode & navChangeSelect )
			SetFieldTextFromStr(fieldP, keyState[2], true);	// Released
		else
			SetFieldTextFromStr(fieldP, keyState[3], true);	// Not Pressed
	}
		
    ////////////////////////////////////////////////////////////
	// Other Way, but doesn't handle multiple keys correctly
	////////////////////////////////////////////////////////////
	//
	//	if( chr == vchrNavChange && (keyCode & navBitSelect)) {
	//		if( modifiers & autoRepeatKeyMask )
	//			SetFieldTextFromStr(fieldP, keyState[1], true);
	//		else
	//			SetFieldTextFromStr(fieldP, keyState[0], true);
	//	} else {
	//		SetFieldTextFromStr(fieldP, keyState[2], true);
	//	}
	////////////////////////////////////////////////////////////
    
    
    // Draw a line for the select button
    WinDrawLine(76, 49, 105, 34);
    
    return true;
}

/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: Form event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/

static Boolean MainFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormType *frmP = FrmGetActiveForm();
	
	EventType cleanEvent;
	cleanEvent.eType = keyDownEvent;
	cleanEvent.data.keyDown.chr = 0;
	cleanEvent.data.keyDown.keyCode = 0;
	cleanEvent.data.keyDown.modifiers = 0;

	
	switch(eventP->eType)
	{
		case frmOpenEvent:
			FrmDrawForm(frmP);	
			// Refresh the display	
			DisplayKeyState(frmP, &cleanEvent);
			handled = true;
			break;
			
		case keyDownEvent:
			handled = DisplayKeyState(frmP, eventP);
			break;
			
		default:
			break;
	}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: Main application event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event.
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/
 
static Boolean AppHandleEvent(EventType *eventP)
{
	UInt16 formId = 0;
	FormType *frmP = NULL;
	
	if(eventP->eType == frmLoadEvent)
	{
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);
		
		switch (formId)
		{
		case MainForm:
			FrmSetEventHandler(frmP, MainFormHandleEvent);
			break;
			
		default:
			break;
		}
		return true;
	}
	
	return false;
}

/***********************************************************************
 *
 * FUNCTION:    ApplEventLoop
 *
 * DESCRIPTION: Main Application event loop.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void AppEventLoop(void)
{
	EventType event;
	
	do
	{
		EvtGetEvent(&event, evtWaitForever);
		
		if(EvtKeydownIsVirtual(&event) && (event.data.keyDown.chr == vchrNavChange)
			&& ((event.data.keyDown.keyCode & (navChangeBitsAll | navBitsAll)) == (navChangeSelect | navBitSelect))
			&& (event.data.keyDown.modifiers & poweredOnKeyMask) )
		{
			// If you want your application to turn on and not to show the pop-up clock
			// Use the following code:
			// // Simply reset the auto off...
			// EvtResetAutoOffTimer();
			
			// Pop the regular clock dialog
			SysHandleEvent(&event);
			// Skip the loop
			continue;
		}
		
		// If the event is a five way event, pass it to the form
		// event handler.
		if(IsFiveWayNavEvent(&event) || !SysHandleEvent(&event))
		{
			if(!AppHandleEvent(&event))
			{
				FrmDispatchEvent(&event);
			}
		}
	} while(event.eType != appStopEvent);
}

/***********************************************************************
 *
 * FUNCTION:    AppStart
 *
 * DESCRIPTION: Called when the application starts
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err AppStart(void)
{
	// Check for 5 Way
	UInt32 	version = 0;
	Err		err = FtrGet(navFtrCreator, navFtrVersion, &version);
	
	if(err)
		FrmAlert(NotAvailableAlert);
	
	return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Called when the application exits
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void AppStop(void)
{
	FrmCloseAllForms();
}

/* all code from here to end of file should use no global variables */
#pragma warn_a5_access on

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check the if the ROM is compatible with the application
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
    UInt32 romVersion;

    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion < requiredVersion)
    {
        if ((launchFlags & 
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
        {
            FrmAlert (RomIncompatibleAlert);

             if (romVersion < kPalmOS20Version)
            {
                AppLaunchWithCommand(
                    sysFileCDefaultApp, 
                    sysAppLaunchCmdNormalLaunch, NULL);
            }
        }

        return sysErrRomIncompatible;
    }

    return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: Main entry point for the application.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err error;

    error = RomVersionCompatible (ourMinVersion, launchFlags);
    if (error) return (error);

    switch (cmd)
    {
    case sysAppLaunchCmdNormalLaunch:
        error = AppStart();
        if (error) 
            return error;

        FrmGotoForm(MainForm);
        AppEventLoop();
        
        AppStop();
        break;

    default:
        break;
    }

    return errNone;
}

/* turn a5 warning off to prevent it being set off by C++
 * static initializer code generation */
#pragma warn_a5_access reset
