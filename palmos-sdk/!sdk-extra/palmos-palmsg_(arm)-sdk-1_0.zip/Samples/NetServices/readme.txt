. NetServices Sample Code

This sample code shows how to use the NetServices API.
This project was built using CodeWarrior 8.

Features:

- Gets the MAC address of the device.
- Displays the signal strength and signal quality.
- Shows the IP.
- Does a BSS Scan and list results.
- Displays the Firmware information.

Files:

- NetServicesTest.c : Main form. Displays the signal strength.
- IPInfoForm.c : IP form. Displays the IP info.
- FirmwareInfoForm.c : Firmware form. Displays the firmware information.
- BSSScanForm.c : BSS Scan form. Displays all the APs found.