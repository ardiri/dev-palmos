/*
 * NetServicesTest.h
 *
 * header file for NetServices
 *
 * This wizard-generated code is based on code adapted from the
 * stationery files distributed as part of the Palm OS SDK 4.0.
 *
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 */
 
#ifndef NETSERVICESTEST_H_
#define NETSERVICESTEST_H_

/*********************************************************************
 * Internal Constants
 *********************************************************************/

#define appFileCreator			'nStS'
#define appName					"NetServicesTest"
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

#define appFeatureNum			0		

/************************************************************
 * Typedefs and Structures.
 *************************************************************/

// State structure used by all the routines
typedef struct NetStatStateStruct
{
	Boolean scanning;
	UInt16	appRef;
	UInt16	ifInstance;
	MemPtr	qualityP;
	MemPtr	strengthP;
	UInt16	loopCount;
	UInt16  instance;
	UInt16  creator;
	UInt16	libRef;
	UInt32	evtWait;
	Boolean netInterfaceFound;
	Boolean	shlLoaded;
	
	NetQueryType	*queryP;
	// BSS scan state information
	Boolean			bssScanInProcess;
	Boolean			scanComplete;
	Boolean			scanEventReceived;
	UInt32			scanStartTime;
	UInt32			scanTimeLimit;
	UInt32			timePhase;
	NetBssListType	*bssListP;
	UInt32			curBss;
	ProgressPtr		prgP;
} NetStatType;

// Global data
extern NetStatType gNetStat;

/************************************************************
 * Global functions
 *************************************************************/

Err FindInterface();
Boolean IPInfoFormHandleEvent(EventType *eventP);
Boolean FWInfoFormHandleEvent(EventType *eventP);
Boolean BSSScanFormHandleEvent(EventType *eventP);

#endif // NETSERVICESTEST_H_
