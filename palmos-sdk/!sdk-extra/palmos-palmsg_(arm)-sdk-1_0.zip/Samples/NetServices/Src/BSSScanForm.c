/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	BSSScanForm.c
 *
 * Description:
 *	Implements the interface to request the driver to perform a scan of
 *	all available AP's.  The request is generated and then a "LED" is
 *	flashed and a button is enabled to cancel the scan.  If the scan
 *	is allowed to complete, the BSS information is extracted from the
 *	driver and kept in a array of structures..
 *
 *	Version 1.0 	- Initial Revision (04/08/03)
 *
 ***********************************************************************/

#include <PalmOS.h>
#include "Common.h"
#include "PalmWiFiCommon.h"
#include "PalmNetServices.h"
#include "NetServicesTest.h"
#include "NetServicesTestRsc.h"

// Form state
typedef enum FormStateEnum
{
	stateIdle,
	stateScanning,
	stateShowScan
	
} FormStateType;

/***********************************************************************
 *
 * FUNCTION:    ScanProgressCallback
 *
 * DESCRIPTION: Updates the progress dialog by changing the bar
 *				showing up. 
 *
 * PARAMETERS:  dataP - Suppled to the PrgStartDialog.  Points to the
 *				gNetStat
 *
 * RETURNED:    update - Indicates if the progress should be updated.
 *
 ***********************************************************************/
 
static Boolean ScanProgressCallback(PrgCallbackDataPtr cbP)
{
	Boolean update = true;
		
	if( cbP->stage ) {
		// Take the string pointer for the progress and update
		StrPrintF( cbP->textP, "%d Seconds remaining", (14 - cbP->stage) / 2 );
		cbP->textChanged = true;
		
		if( cbP->stage >= 14 )
			// Update the global variable to indicate scan complete
			((NetStatType *) (cbP->userDataP))->scanComplete = true;
	}
	
	return update;
}
/***********************************************************************
 *
 * FUNCTION:    SetFormState
 *
 * DESCRIPTION: Used by the data collection/display routine to set the
 *				state of the UI.  This isolates all UI related stuff
 *				to one area and allows the porting of all the data
 *				collection to a different UI concept.
 *
 * PARAMETERS:  N/A
 *
 * RETURNED:    N/A
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/

static void SetFormState(FormStateType state)
{
	FormType *frmP = FrmGetActiveForm();
	
	switch( state ) {
	case stateScanning:
		// Turn off the search and turn on the abort button.
		CtlSetEnabled(FrmGetPtr(frmP, BSSScanSearchButton), false);
		CtlSetUsable(FrmGetPtr(frmP, BSSScanSearchButton), false);
		CtlDrawControl(FrmGetPtr(frmP, BSSScanSearchButton));
		
		CtlSetEnabled(FrmGetPtr(frmP, BSSScanAbortButton), true);
		CtlSetUsable(FrmGetPtr(frmP, BSSScanAbortButton), true);
		CtlDrawControl(FrmGetPtr(frmP, BSSScanAbortButton));
		
		// Start the progress dialog
		gNetStat.prgP = PrgStartDialog( "AP Scan In Process", ScanProgressCallback, &gNetStat );
		
		gNetStat.timePhase = 0;
		// Set the start time.
		gNetStat.evtWait = SysTicksPerSecond() >> 1;
		gNetStat.scanComplete = false;
		break;		
	
	case stateShowScan:
		// Bring back to the scan button
		CtlSetEnabled(FrmGetPtr(frmP, BSSScanSearchButton), true);
		CtlSetUsable(FrmGetPtr(frmP, BSSScanSearchButton), true);
		
		CtlSetEnabled(FrmGetPtr(frmP, BSSScanAbortButton), false);
		CtlSetUsable(FrmGetPtr(frmP, BSSScanAbortButton), false);

		// Draw the form
		FrmDrawForm(frmP);
		gNetStat.evtWait = evtWaitForever;
		break;
	default:
		break;
	}
}
	
		
/***********************************************************************
 *
 * FUNCTION:    StartBSSScan
 *
 * DESCRIPTION: Uses the driver interface routines to request the scan
 *				to start.
 *
 * PARAMETERS:  -
 *
 * RETURNED:    Err - returned from driver
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/

static Err StartBSSScan()
{
	Err err = NetServicesStartScan(gNetStat.libRef);
	
	return err;
}

/***********************************************************************
 *
 * FUNCTION:    CollectScanData
 *
 * DESCRIPTION: Uses the driver interface routines to request the scan
 *				data from the last scan request.
 *
 * PARAMETERS:  listPP - Pointer to pointer.  The pointer to the scan
 *				list is returned to the caller.  Note:  The caller
 *				must manage the memory allocated for the list
 *
 * RETURNED:    Err - returned from driver
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/

static Err CollectScanData(NetBssListType **listPP, NetQueryType *queryP)
{
	Err 			err;
	UInt16			prefSize = sizeof(NetQueryType);
	NetBssListType	*bssListP = NULL;
	UInt32			reqSize;	
	
	// Get the amount of data required to collect all the data from the scan.
	reqSize = 0;
	err = NetServicesGetScanResults( gNetStat.libRef, NULL, &reqSize );	
	if( err == netErrBufTooSmall )
		err = errNone;
		
	if( err == errNone ) {
		// Check to see if we already have a list allocated.  If so, free it up.
		if( *listPP )
			MemPtrFree( *listPP );
			
		bssListP = MemPtrNew( reqSize );
		if( bssListP == NULL ) 
			err = errNetOutOfMemory;
		else {
			err = NetServicesGetScanResults( gNetStat.libRef, (UInt8 *) bssListP, &reqSize );
			*listPP = bssListP;
		}
	}
	return err;	
}

/***********************************************************************
 *
 * FUNCTION:    GetInfrastructureModeStr
 *
 * DESCRIPTION: Returns a string representing the current infrastructure
 *				mode for a BSS
 *
 * PARAMETERS:  mode - Enumeration value for mode
 *
 * RETURNED:    strP - Pointer to string.  Can be "UNKNOWN"
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/

static const Char *GetInfrastructureModeStr(Net80211InfrastructureModeType mode)
{
	const Char *strP;
	
	switch( mode ) {
	case net80211Bss:
		strP = "IBSS";
		break;
	case net80211Infrastructure:
		strP = "Infrastructure";
		break;
	case net80211AutoUnknown:
		strP = "??Auto Unknown??";
		break;
	default:
		strP = "!! UNKNOWN !!";
		break;
	}
	
	return strP;
}

const static Char HexChars[] =
{
	'0', '1', '2', '3', '4', '5', '6', '7', 
	'8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
};

#define HTOA( x ) (x >= 0 && x <= 0x0f ? HexChars[x] : '?')

/***********************************************************************
 *
 * FUNCTION:    GetMacAddrStr
 *
 * DESCRIPTION: Creates a string with hex digits for the mac address.
 *				The ':' is also placed in the string as a seperator.
 *
 * PARAMETERS:  strP - Pointer to storage area for string.  NOTE:  Since
 *				the caller must use the string after returning, cannot
 *				use an automatic variable.
 *				macP - Pointer to the mac address data in the BSS.
 *
 * RETURNED:    strP - Pointer to string.  Identical to the input 
 *				parameter but makes it easier to use local storage
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/

static Char *GetMacAddrStr(UInt8 *macP, Char *strP)
{
	Char *retP = strP;
	Int32 n;
	
	for( n = 0; n < netMacAddrLength; n++ ) {
		if( n > 0 )
			*strP++ = ':';
		
		*strP++ = HTOA(((macP[n] >> 4) & 0x0f));	
		*strP++ = HTOA((macP[n] & 0x0f));
	}
	
	// Make sure and NULL terminate the string
	*strP = 0;
	return retP;
}
/***********************************************************************
 *
 * FUNCTION:    ShowBSSElement
 *
 * DESCRIPTION: Updates the field info for the current BSS element.
 *
 * PARAMETERS:  bssP - Pointer to BSS data to display.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void ShowBSSElement(NetBssInfoType *bssP)
{
	Char *strP;
	Char macAddrStr[32];
	FormType *frmP = FrmGetActiveForm();
		
	// Currently displaying the name of the BSS, the mac address
	// infrastructure mode, and the supported rates.
	strP = FldGetTextPtr(FrmGetPtr(frmP, BSSScanBSSField));
	if( strP == NULL ) {
		// The text pointer has not been allocated as of yet.  Allocate
		// a large enough buffer to hold all the info above.  For
		// safety purposes, 512 bytes are allocated.  This can obviously
		// be changed if needed.
		strP = MemPtrNew( 512 );
		if( strP == NULL )
			return;
	}
	
	StrPrintF( strP, "SSID: %s\nBSS_ID: %s\nMode: %s\nWEP: %s\nChannel ID: %ld, ANL=%ld",
				bssP->bssSsid,
				GetMacAddrStr( bssP->bssMacAddr, macAddrStr ),
				GetInfrastructureModeStr( bssP->bssNetworkMode ),
				bssP->bssWepEnabled ? "Enabled" : "Disabled",
				bssP->bssChannelId,
				bssP->bssANL );
				
	FldSetTextPtr( FrmGetPtr(frmP, BSSScanBSSField ), strP );
	FldRecalculateField( FrmGetPtr(frmP, BSSScanBSSField ), true );
	
	// Show the current element
	StrPrintF(macAddrStr, "%ld/%ld", gNetStat.curBss + 1, gNetStat.bssListP->count);
	SetFieldTextFromStr(FrmGetPtr(frmP, BSSScanCurrentField), macAddrStr, true);
}
				

/***********************************************************************
 *
 * FUNCTION:    BSSScanFormHandleControl
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean BSSScanFormHandleControl(UInt16 control)
{
	Boolean handled = false;
	switch( control ) {
	
	case BSSScanSearchButton:
		// Invoke the necessary routine to start the scan with the device
		// driver.
		StartBSSScan();
		SetFormState( stateScanning );
		handled = true;
		break;
		
	case BSSScanDoneButton:
		// Go back to the main form
		FrmGotoForm( MainForm );
		handled = true;
		break;
		
	case BSSScanNextButton:
		// Determine if we are at the end of the list or not.
		if( ++gNetStat.curBss >= gNetStat.bssListP->count )
			gNetStat.curBss = 0;
			
		ShowBSSElement( &gNetStat.bssListP->BSS[gNetStat.curBss] );
		handled = true;
		break;
		
	case BSSScanPrevButton:
		// Determine if we are at the end of the list or not.
		if( gNetStat.curBss == 0 )
			gNetStat.curBss = gNetStat.bssListP->count - 1;
		else
			--gNetStat.curBss;
			
		ShowBSSElement( &gNetStat.bssListP->BSS[gNetStat.curBss] );
		handled = true;
		break;
		
	default:
		break;
	}
	
	return handled;
}
/***********************************************************************
 *
 * FUNCTION:    DisplayScanData
 *
 * DESCRIPTION: Displays the scan data retrieved from the 802.11
 *				network connnection.
 *
 * PARAMETERS:  listP - Pointer to netstat data area
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void DisplayScanData(NetBssListType *listP )
{
	Char *strP;
	FormType *frmP = FrmGetActiveForm();
	
	// Number of entries in the list
	strP = FldGetTextPtr(FrmGetPtr(frmP, BSSScanNumEntriesField));
	if( strP == NULL ) {
		// Attempt to allocate a new string and set this as the string pointer
		strP = MemPtrNew( 64 );
		if( strP == NULL )
			return;
	} 

	// Display the number of entries in the list.	
	StrPrintF( strP, "%ld AP(s) Available", listP->count );
	FldSetTextPtr(FrmGetPtr(frmP, BSSScanNumEntriesField), strP );
	FrmShowObject(FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanNumEntriesField ));
		
	// Make sure and enable the BSS scan data field.
	if( listP->count )
	{
		FrmShowObject( FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanBSSField ));
	
		// Show the first item in the list.  If there are additional items, then
		// enable the next button.
		ShowBSSElement( &listP->BSS[0] );
	}
	else
	{
		FrmHideObject( FrmGetActiveForm(), FrmGetObjectIndex(FrmGetActiveForm(), BSSScanBSSField ));
	}
	
	if( listP->count > 1 ) {
		// Enable the next button to allow the user to "scroll" through the items.
		FrmShowObject( FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanNextButton ));
		FrmShowObject( FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanPrevButton ));
	} else {
		FrmHideObject( FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanNextButton ));
		FrmHideObject( FrmGetActiveForm(), FrmGetObjectIndex( FrmGetActiveForm(), BSSScanPrevButton ));
	}
	
	// Indicate we are currently displaying the first element in the list.
	gNetStat.curBss = 0;
}

static void FreeFormData(FormType *frmP)
{
	Char *strP;
	UInt16 	cardNo;
	LocalID	dbID; 
	
	// Free the memory which was allocated for the text pointers for the fields.
	strP = FldGetTextPtr(FrmGetPtr(frmP, BSSScanNumEntriesField));
	if( strP ) {
		FldSetTextPtr(FrmGetPtr(frmP, BSSScanNumEntriesField), NULL );
		MemPtrFree( strP );
	}
	
	strP = FldGetTextPtr(FrmGetPtr(frmP, BSSScanBSSField ));
	if( strP ) {
		FldSetTextPtr(FrmGetPtr(frmP, BSSScanBSSField), NULL );
		MemPtrFree( strP );
	}
	
	// Unregister for the events.
	SysCurAppDatabase(&cardNo, &dbID);
	SysNotifyUnregister(cardNo, dbID, WIFI_SCAN_COMPLETE_EVENT, sysNotifyNormalPriority );
}
	
/***********************************************************************
 *
 * FUNCTION:    BSSScanFormInit
 *
 * DESCRIPTION: This routine initializes the BSSScanForm form.
 *
 * PARAMETERS:  frm - pointer to the BSSScanForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void BSSScanFormInit(FormType *frmP)
{
	UInt16 	cardNo;
	LocalID	dbID; 
	// Clear any previous status indicators for BSS scan
	gNetStat.bssScanInProcess = false;
	gNetStat.scanEventReceived = false;
	
	// The scan limit is 6 seconds.  This is a theoritical limit to 
	// establish the identity of all the local AP's.  
	gNetStat.scanTimeLimit = SysTicksPerSecond() * 6;
	
	// Indicate working on the first LED
	gNetStat.timePhase = 0;
	
	// Register for the system notification that is sent when the scan
	// is complete
	SysCurAppDatabase(&cardNo, &dbID);
	SysNotifyRegister(cardNo, dbID, WIFI_SCAN_COMPLETE_EVENT, NULL, sysNotifyNormalPriority, &gNetStat );
	
	// Did we previously complete a scan and have at least 1 BSS to show.
	if( gNetStat.bssListP && gNetStat.bssListP->count )
		DisplayScanData(gNetStat.bssListP );
}

/***********************************************************************
 *
 * FUNCTION:    BSSFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the BSS Scan form.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 ***********************************************************************/

Boolean BSSScanFormHandleEvent(EventType *eventP)
{
	Char	errStr[64];
	Err		err		= errNone;
	Boolean handled	= false;
	FormPtr frmP	= FrmGetActiveForm();;
	
	switch (eventP->eType) 
	{
		case ctlSelectEvent:
			return BSSScanFormHandleControl(eventP->data.ctlSelect.controlID);
			
		case frmOpenEvent:
			BSSScanFormInit(frmP);
			FrmDrawForm(frmP);
			handled = true;
			break;
			
		case frmCloseEvent:
			FreeFormData(frmP);
			break;
			
		case nilEvent:
			// Indicates a timer has went off.  The scan should be left running for
			// 6 seconds.  If we have reached this limit, then request the scan data
			// from the driver. Check if scan is complete.
			if( gNetStat.scanComplete || gNetStat.scanEventReceived )
			{
				PrgStopDialog(gNetStat.prgP, true);
				
				// Make sure and kill the event loop processing.
				gNetStat.prgP = NULL;
				
				// Set the new form state.
				SetFormState( stateShowScan );
				err = CollectScanData( &gNetStat.bssListP, gNetStat.queryP );
				if( err ) {
					StrPrintF( errStr, "CollectScan failed, err = %d", err );
					FrmCustomAlert( ErrorAlert, errStr, NULL, NULL );
				} else {
					DisplayScanData(gNetStat.bssListP);
				}
			} else {
				PrgUpdateDialog( gNetStat.prgP, errNone, (UInt16) ++gNetStat.timePhase, NULL, true );
			}
			handled = true;
			break;
		default:
			break;
		
		}
	
	return handled;
}

