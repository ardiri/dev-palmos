/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	IPInfoForm.c
 *
 * Description:
 *	Provides IP related info for a connection.  The data is displayed
 *	to the user when the form is initialized.  The only available option
 *	is to indicate done.
 *
 *	Version 1.0 	- Initial Revision (04/08/03)
 *
 ***********************************************************************/

#include <PalmOS.h>
#include "Common.h"
#include "PalmWiFiCommon.h"
#include "PalmNetServices.h"
#include "NetServicesTest.h"
#include "NetServicesTestRsc.h"

/***********************************************************************
 *
 * FUNCTION:    BSSScanFormHandleControl
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/

static Boolean IPInfoFormHandleControl(UInt16 control)
{
	Boolean handled = false;
	
	switch( control )
	{
	case IPInfoDoneButton:
		FrmGotoForm( MainForm );	// Go back to the main form
		handled = true;
		break;
		
	default:
		break;
	}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    InterfaceState
 *
 * DESCRIPTION: This routine sets the interface state and may disable
 *				all other controls if the interface is down. 
 *
 * PARAMETERS:  frmP - Pointer to the form
 *				up	- Boolean indicating if IF is up.
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/

static void InterfaceState(FormType *frmP, Boolean up)
{
	if( up )
	{
		// Interface is currently up.  All the controls are enabled by 
		// default.  Set the string for the interface state and done.
		SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoIfStateField), "Up", true );
		return;
	}
	
	// Interface is down.  Set the string to indicate down and then
	// disable all the controls.
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoIfStateField), "DOWN", true);	
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoIPAddrField ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoIPAddrLabel ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoSubnetField ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoSubnetLabel ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoGatewayField ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoGatewayLabel ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoDNSLabel ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoPrimaryDNSField ));
	FrmHideObject( frmP, FrmGetObjectIndex( frmP, IPInfoSecondaryDNSField ));
}

/***********************************************************************
 *
 * FUNCTION:    IPInfoFormInit
 *
 * DESCRIPTION: This routine initializes the BSSScanForm form.
 *
 * PARAMETERS:  frm - pointer to the BSSScanForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void IPInfoFormInit(FormType *frmP)
{
	Char		ipAscii[32];
	UInt32 		ifCreator	= WIFI_CREATOR_ID;
	UInt16		ifInstance	= 0;
	UInt16		settingSize	= 0;
	NetIPAddr	ipData		= 0;
	Err			err			= errNone;
	UInt8		ifUp		= false;
	
	// Get the IP info and set the data on the form.  Make sure we
	// have the interface available to issue the commands.
	if( FindInterface() != errNone )
		return;
		
	// Make sure the interface is up.  If the interface is up, the rest of the fields
	// will be hidden.
	settingSize = sizeof( ifUp );
	err = NetLibIFSettingGet( gNetStat.appRef, ifCreator, ifInstance, netIFSettingUp, &ifUp, &settingSize );
	if( err != errNone || (err == errNone && ifUp == false )) 
	{
		InterfaceState( frmP, false );
		return;
	}
	
	// Interface is up.  Enable all the rest of the controls and indicate interface is up.
	InterfaceState( frmP, true );
	
	// The netlib interface into the wifi exists.  None use the NetLibIFSettingGet
	// to extract the IP addr, subnet mask, gateway, and DNS information
	settingSize = sizeof( ipData );
	err = NetLibIFSettingGet( gNetStat.appRef, ifCreator, ifInstance, netIFSettingActualIPAddr, &ipData, &settingSize );
	if( err == errNone ) {
		NetLibAddrINToA( gNetStat.appRef, ipData, ipAscii );
	} else  {
		StrCopy( ipAscii, "" );
	}
	
	// Display the IP address
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoIPAddrField), ipAscii, false);
	
	err = NetLibIFSettingGet( gNetStat.appRef, ifCreator, ifInstance, netIFSettingSubnetMask, &ipData, &settingSize );
	if( err == errNone ) {
		NetLibAddrINToA( gNetStat.appRef, ipData, ipAscii );
	} else {
		StrCopy( ipAscii, "" );
	}
	
	// Display the IP subnet
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoSubnetField), ipAscii, false);
	
	err = NetLibSettingGet( gNetStat.appRef, netSettingDefaultRouter, &ipData, &settingSize );
	if( err == errNone ) {
		NetLibAddrINToA( gNetStat.appRef, ipData, ipAscii );
	} else {
		StrCopy( ipAscii, "" );
	}
	
	// Display the IP gateway
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoGatewayField), ipAscii, false);
	
	err = NetLibSettingGet( gNetStat.appRef, netSettingRTPrimaryDNS, &ipData, &settingSize );
	if( err == errNone ) {
		NetLibAddrINToA( gNetStat.appRef, ipData, ipAscii );
	} else {
		StrCopy( ipAscii, "" );
	}
	
	// Display the primary DNS
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoPrimaryDNSField), ipAscii, false);
	
	err = NetLibSettingGet( gNetStat.appRef, netSettingRTSecondaryDNS, &ipData, &settingSize );
	if( err == errNone ) {
		NetLibAddrINToA( gNetStat.appRef, ipData, ipAscii );
	} else {
		StrCopy( ipAscii, "" );
	}
	
	// Display the secondary DNS
	SetFieldTextFromStr( FrmGetPtr(frmP, IPInfoSecondaryDNSField), ipAscii, false);
}

/***********************************************************************
 *
 * FUNCTION:    IPInfoFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the IP form.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 ***********************************************************************/
Boolean IPInfoFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormPtr frmP = FrmGetActiveForm();
	
	switch (eventP->eType) 
		{
        case ctlSelectEvent:
            return IPInfoFormHandleControl(eventP->data.ctlSelect.controlID);
            
		case frmOpenEvent:
			IPInfoFormInit( frmP );
			FrmDrawForm ( frmP );
			handled = true;
			break;
			
		default:
			break;
		
		}
	
	return handled;
}

