/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	FirmwareInfoForm.c
 *
 * Description:
 *	Provides firmware info.
 *
 *	Version 1.0 	- Initial Revision (04/08/03)
 *
 ***********************************************************************/

#include <PalmOS.h>
#include "Common.h"
#include "PalmWiFiCommon.h"
#include "PalmNetServices.h"
#include "NetServicesTest.h"
#include "NetServicesTestRsc.h"

/***********************************************************************
 * Internal globals
 ***********************************************************************/
 
static UInt16 *gpdaP	= NULL;
static Int16 gcurIndex	= 0;
static Int16 gmaxIndex	= 0;
static Int16 gcurOffset	= 0;

/***********************************************************************
 *
 * FUNCTION:    FWInfoFormHandleControl
 *
 * DESCRIPTION: Handles controls of the form.
 *
 * PARAMETERS:  control  - Control id
 *
 * RETURNED:    True if handled.
 *
 ***********************************************************************/
 
static Boolean FWInfoFormHandleControl(UInt16 control)
{
	Boolean handled = false;
	switch( control )
	{
		case FirmwareInfoOKButton:
			FrmGotoForm( MainForm );	// Go back to the main form
			handled = true;
			break;
	
		default:
			break;
	}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    IsAscii
 *
 * DESCRIPTION: Checks if a string contains only ASCII characters.
 *
 * PARAMETERS:  str		- Pointer to a string
 *				strLen	- Length of the string
 *
 * RETURNED:    Trus if the string is composed of ASCII characters.
 *
 ***********************************************************************/
 
static Boolean IsAscii(Char *str, Int32 strLen )
{
	while( strLen-- )
	{
		if( TxtCharIsValid( *str ) && TxtCharIsPrint( *str ))
			str++;
		else
			return false;
	}
	
	return true;
}

/***********************************************************************
 *
 * FUNCTION:    ShowFWInfo
 *
 * DESCRIPTION: Displays the available firmware info.  The valid flags
 *				in the structure indicates which fields are valid.
 *
 * PARAMETERS:  frmP		- Pointer to form for controls
 *				infoP		- Pointer to firmware info
 *				channelList	- Channel list
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/

static void ShowFWInfo( FormPtr frmP, Net80211DeviceInfoP infoP, UInt16 channelList )
{
	Char	localStr[64];
	Int32	n;
	
	if( infoP->validFlags & 1 )
	{
		// FW rev info is supplied.  These are hex reps.
		StrPrintF( 	localStr, "%lX", infoP->fwRev[0] );
		SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoStaFWRevField), localStr, false);
		
		StrPrintF( localStr, "%lX", infoP->fwRev[1] );
		SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoPriFWRevField), localStr, false);
	}
	
	if( infoP->validFlags & 2 )
	{
		// Driver date.  This is ascii.
		// The little check is done because the string contains character \37 at the
		// end, and that doesn't print nicely :) 
		if( infoP->driverDate[StrLen(infoP->driverDate) - 1] == '\37' )
			infoP->driverDate[StrLen(infoP->driverDate) - 1] = '\0';
		SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoDriverBuildDateField), infoP->driverDate, false);
	}
	
	if( infoP->validFlags & 4 )
	{
		// FW Name is valid.
		SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoFWNameField), infoP->fwName, false);
	}
	
	if( infoP->validFlags & 8 )
	{
		// Serial number is valid.  Should be a serie of numbers.  There
		// is a member of the structure which will tell us how big the serial
		// number is.
		// Check if the data is already in ascii format.
		if( IsAscii( (Char *) infoP->serialNumber, infoP->serialNumberSize ))
		{
			MemMove( localStr, infoP->serialNumber, infoP->serialNumberSize );
			localStr[infoP->serialNumberSize] = 0;
		}
		else
		{
			for( n = 0; n < infoP->serialNumberSize; n++ )
				StrPrintF( &localStr[n << 1], "%02X", infoP->serialNumber[n] );
		}
		
		SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoSerialNumberField), localStr, false);
	}
	
	// Show the channel list as well
	StrPrintF( localStr, "%04X", channelList );
	SetFieldTextFromStr( FrmGetPtr(frmP, FirmwareInfoChannelListField), localStr, false);
}

/***********************************************************************
 *
 * FUNCTION:    FWInfoFormInit
 *
 * DESCRIPTION: This routine initializes the BSSScanForm form.
 *
 * PARAMETERS:  frm - pointer to the BSSScanForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
 
static void FWInfoFormInit( FormPtr frmP )
{
	Net80211DeviceInfo	fwInfo;
	UInt16				channelList;
	Err					err;
	
	// Use net services to get the fw info.
	err = NetServicesGetDeviceInfo( gNetStat.libRef, &fwInfo );
	if( err == errNone ) {
		// Also get the channel list.
		err = NetServicesGetChannelList( gNetStat.libRef, &channelList );
	}
	
	if( err == errNone )
		ShowFWInfo( frmP, &fwInfo, channelList );
}

/***********************************************************************
 *
 * FUNCTION:    FWInfoFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the Firmware form.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 ***********************************************************************/

Boolean FWInfoFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormPtr frmP = FrmGetActiveForm();
	
	switch (eventP->eType) 
		{
        case ctlSelectEvent:
            return FWInfoFormHandleControl(eventP->data.ctlSelect.controlID);
            
		case frmOpenEvent:
			FWInfoFormInit( frmP );
			FrmDrawForm ( frmP );
			handled = true;
			break;

		default:
			break;
		
		}
	
	return handled;
}

