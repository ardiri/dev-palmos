/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	NetServicesTest.c
 *
 * Description:
 *	Test Application for NetServices
 *
 *	Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/
 
#include <PalmOS.h>
#include "Common.h"
#include "PalmWiFiCommon.h"
#include "PalmNetServices.h"
#include "NetServicesTest.h"
#include "NetServicesTestRsc.h"

/*********************************************************************
 * Internal Constants
 *********************************************************************/

#define ourMinVersion    sysMakeROMVersion(3,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

#if 0
#pragma mark Globals
#endif

NetStatType gNetStat;

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:	PrvLoadNetServices
 *
 * DESCRIPTION: Load the NetServices library
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
static Err PrvLoadNetServices()
{
	Err err = SysLibFind(ShlLibName, &gNetStat.libRef);
	if(err)
	{
		err = SysLibLoad(sysFileTLibrary, ShlCreatorID, &gNetStat.libRef);
		if( err != errNone )
			FrmAlert(NoNetServicesAlert);
		else
			gNetStat.shlLoaded = true;
	}
			
	return err;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:	DoScan
 *
 * DESCRIPTION: Do a scan and check the signal strength.
 *
 * PARAMETERS:	
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
static void DoScan(FormType *frmP, NetQueryType *queryP)
{
	Char	s[32];
	UInt16	prefSize	= sizeof(NetQueryType);
	UInt8	strength	= 0;
	UInt8	quality		= 0;
	UInt32	ifInstance	= 0;
	UInt16	channel		= 0;
	UInt16	mode		= 0;
	Err		err			= errNone;
	
	// Get the signal strength and quality
	err = NetServicesGetCommsQuality( gNetStat.libRef, &strength, &quality );
		
	// Update the signal strength field
	if( err == errNone ) {
		StrPrintF( s, "%d", (int) strength );
		StrCopy( gNetStat.strengthP, s );
	}  else  {
		StrCopy( gNetStat.strengthP, "N/A" );
	}
	
	SetFieldTextFromStr(FrmGetPtr(frmP, MainSignalStrengthField), gNetStat.strengthP, true);

	// Update the signal quality field
	if( err == errNone ) {
		StrPrintF( s, "%d", (int) quality );
		StrCopy( gNetStat.qualityP, s );
	} else {
		StrCopy( gNetStat.qualityP, "N/A" );
	}
	
	/**
	 * Note:
	 * For the signal quality, which is used by the WiFi Panel,the
	 * following table convert the results into percentages. The
	 * result of the signal quality is a number between 0 and 15.
	 * The scale is not linear and might be different for another device.
	 * The table is only valid for Tungsten|C devices.
	 *
	 * signal strength: 0  1  2  3  4  5  6  7  8  9  10->15
	 * percentage:      0  5 10 18 26 38 50 65 83 100  100
	 *
	 * 9 and above means you have a very good signal.
	 *
	 * Converting this rnge to the 4 bar style:
	 * - if 0, no signal
	 * - if less or equal to 4, signal quality is poor
	 * - if less or equal to 6, signal quality is fair
	 * - if less or equal to 8, signal quality is good
	 * - if less or equal to 15, signal quality is excellent
	 *
	 * Again: These numbers are valid only on Tungsten|C
	 */
	SetFieldTextFromStr(FrmGetPtr(frmP, MainSignalQualityField), gNetStat.qualityP, true);
	
	// Get the channel info.
	if( err == errNone )
		err = NetServicesGetChannel( gNetStat.libRef, &channel );

	if( err == errNone )
		StrPrintF( s, "%d", channel );
	else
		StrCopy( s, "N/A" );
		
	SetFieldTextFromStr(FrmGetPtr(frmP, MainChannelField), s, true);

	// Get the current power mode.
	if( err == errNone )
		err = NetServicesGetPowerState( gNetStat.libRef, &mode );
		
	if( err == errNone )
		SetFieldTextFromStr(FrmGetPtr(frmP, MainPowerModeField), ( mode == 1 ? "Active" : ( mode == 2 ? "Doze" : "UNKNOWN" )), true);
	else
		SetFieldTextFromStr(FrmGetPtr(frmP, MainPowerModeField), "N/A", true);
}

/***********************************************************************
 *
 * FUNCTION:	FindInterface
 *
 * DESCRIPTION: Check if the interface is available.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
Err FindInterface()
{
	Err err = errNone, ifErrs = errNone;
	UInt16	ifInstance	= 0;
	UInt16	index		= 0;
	UInt32 	ifCreator	= 0;
	Boolean	found		= false;
	
	// If previously found, return no errors
	if( gNetStat.netInterfaceFound )
		return errNone;
	
	// Not currently scanning.  Get a connection to netlib.
	err = SysLibFind( "Net.lib", &gNetStat.appRef );
	if( err != errNone )
		return errNetLibMissing;
		
	// Open net lib and find the interface we are looking for
	err = NetLibOpen( gNetStat.appRef, &ifErrs );
	if( err )
	{
		// The err code of netErrAlreadyOpen is not really an error.  Netlib will increment
		// the open count and return this indication back.
		if( err != netErrAlreadyOpen )
			return err;
	}
	
	do {
		err = NetLibIFGet( gNetStat.appRef, index, &ifCreator, &ifInstance );
		if( err == errNone ) {
			// Did we find what we are looking for 
			if( ifCreator == WIFI_CREATOR_ID )
			{
				found = true;
				gNetStat.ifInstance = ifInstance;
			}
			else
				index++;
		}
	} while( found == false && err == errNone );
	
	// Make sure we found it.
	if( found == false ) {
		return errNetInterfaceNotFound;
	}
	
	// Save the instance and createor
	gNetStat.creator = ifCreator;
	gNetStat.instance = ifInstance;
	gNetStat.netInterfaceFound = true;
	
	return errNone;
}

/***********************************************************************
 *
 * FUNCTION:	StartScanning
 *
 * DESCRIPTION: Start a scan session. The display will be updated every
 *				seconds.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
static void StartScanning()
{
	Err err;
	
	// First make sure we aren't already scanning.
	if( gNetStat.scanning == true )
		return;
		
	// Have we already found the network interface.
	if( gNetStat.netInterfaceFound == false )
	{
		if((err = FindInterface()) != errNone )
		{
			Char errStr[64];
			
			switch( err ) {
			case errNetLibMissing:
				FrmAlert( NetLibAlert );
				break;
			case errNetInterfaceNotFound:
				FrmAlert( NoWiFiAlert );
				break;
			default:
				StrPrintF( errStr, "!UNKNOWN ERR: %d", err );
				FrmCustomAlert( ErrorAlert, errStr, NULL, NULL );
				break;
			}
			
			// Don't attempt to do any scanning.
			return;
		}
	}
	
	// OK, set the flag that indicates scanning is happening.
	// This will cause the wait to exit every second and check
	// the current state.
	gNetStat.scanning = true;
	gNetStat.evtWait = SysTicksPerSecond();
}

/***********************************************************************
 *
 * FUNCTION:	StopScanning
 *
 * DESCRIPTION: Stop the scanning process.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
static void StopScanning()
{
	gNetStat.scanning = false;
	gNetStat.evtWait = evtWaitForever;
}

#define HexToAscii(x) (x > 9 ? (x - 10 + 'A'): (x + '0'))

/***********************************************************************
 *
 * FUNCTION:	FormatHexByte
 *
 * DESCRIPTION: Write a byte in hexadecimal string.
 *
 * PARAMETERS:	hexByte	- Byte to format
 *				p		- Pointer to string
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/

static void FormatHexByte( UInt8 hexByte, Char *p )
{
	p[0] = HexToAscii(((hexByte & 0xF0) >> 4));
	p[1] = HexToAscii((hexByte & 0x0f));
	p[2] = 0;
}

/***********************************************************************
 *
 * FUNCTION:	GetMacAddr
 *
 * DESCRIPTION: Get the MAC address.
 *
 * PARAMETERS:	frmP	- Pointer to a form.
 *
 * RETURNED:	Error code
 *
 ***********************************************************************/
 
static void GetMacAddr(FormType *frmP, Boolean redraw)
{
	UInt8 	hwAddr[6];
	Char	hwAddrStr[18];
	int		n	= 0;
	Err		err = errNone;
	
	// Get the MAC address
	err = NetServicesGetHWAddr( gNetStat.libRef, hwAddr );
	if( err == errNone )
	{
		// Convert the address into a nicely formatted string
		for( n = 0; n < 6; n++ )
		{
			if( n )
				StrCat( hwAddrStr, ":" );
				
			FormatHexByte( hwAddr[n], &hwAddrStr[(n << 1) + n] );
		}
		
		SetFieldTextFromStr(FrmGetPtr(frmP, MainMACAddrField), hwAddrStr, redraw);
	}
	else
	{
		// Problem getting the MAC address
		FrmAlert( MacAddrAlert );
	}
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:	PrvFormShowMenu
 *
 * DESCRIPTION: Main form Initialization.
 *
 * PARAMETERS:	frmP	- Pointer to main form
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static Boolean PrvFormShowMenu(UInt16 command)
{
	Boolean handled = false;
	FormType *frmP = NULL;
	
	switch (command)
	{
	case OptionsAbout:
		MenuEraseStatus(0);
		
		frmP = FrmInitForm(AboutForm);
		FrmDoDialog(frmP);
		FrmDeleteForm(frmP);
		handled = true;
		break;
	}
	
	return handled;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:	MainFormInit
 *
 * DESCRIPTION: Main form Initialization.
 *
 * PARAMETERS:	frmP	- Pointer to main form
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void MainFormInit(FormType *frmP)
{
	// Create the signal strength string
	if( gNetStat.strengthP == NULL )
	{
		gNetStat.strengthP = MemPtrNew( 8 );
		StrCopy( gNetStat.strengthP, "" );
	}
	
	// Set the corresponding field (should use pointer instead of copying...)
	SetFieldTextFromStr(FrmGetPtr(frmP, MainSignalQualityField ), gNetStat.strengthP, false);
	
	// Create the signal quality strength
	if( gNetStat.qualityP == NULL )
	{
		gNetStat.qualityP = MemPtrNew( 8 );
		StrCopy( gNetStat.qualityP, "" );
	}
	
	// Set the corresponding field (should use pointer instead of copying...)
	SetFieldTextFromStr(FrmGetPtr(frmP, MainSignalStrengthField ), gNetStat.qualityP, false);
	
	// Get the MAC address
	GetMacAddr(frmP, false);
}

/***********************************************************************
 *
 * FUNCTION:	MainFormHandleEvent
 *
 * DESCRIPTION: Main form event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/

static Boolean MainFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormType *frmP = FrmGetActiveForm();
	
	switch(eventP->eType)
	{
		case frmOpenEvent:
			MainFormInit(frmP);
			FrmDrawForm(frmP);			
			handled = true;
			break;
			
		case frmCloseEvent:
			// Make sure scanning is turned off
			if( gNetStat.scanning )
				StopScanning();
			break;
			
		case menuEvent:
			handled = PrvFormShowMenu(eventP->data.menu.itemID);
			break;
			
		case nilEvent:
			// Should only get this if we are scanning.
			if( gNetStat.scanning )
				DoScan(frmP, gNetStat.queryP);
			handled = true;
			break;
		
		case ctlSelectEvent:
			switch(eventP->data.ctlSelect.controlID)
			{
				case MainStartButton:
					if( !gNetStat.scanning ) {
						StartScanning();
						CtlSetLabel(FrmGetPtr(frmP, MainStartButton), "Stop Scan");
					} else {
						StopScanning();
						CtlSetLabel(FrmGetPtr(frmP, MainStartButton), "Start Scan");
					}
					handled = true;
					break;
					
				case MainIPInfoButton:
					FrmGotoForm(IPInfoForm);
					handled = true;
					break;
					
				case MainFWInfoButton:
					FrmGotoForm(FirmwareInfoForm);
					handled = true;
					break;
					
				case MainAPScanButton:
					FrmGotoForm(BSSScanForm);
					handled = true;
					break;
			}
			break;
			
		case ctlRepeatEvent:
			handled = false;
			break;
			
		default:
			break;
	}
	
	return handled;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: Main application event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event.
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/
 
static Boolean AppHandleEvent(EventType *eventP)
{
	UInt16 formId = 0;
	FormType *frmP = NULL;
	
	if(eventP->eType == frmLoadEvent)
	{
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);
		
		switch (formId)
		{
		case MainForm:
			FrmSetEventHandler(frmP, MainFormHandleEvent);
			break;
			
		case IPInfoForm:
			FrmSetEventHandler(frmP, IPInfoFormHandleEvent);
			break;
			
		case FirmwareInfoForm:
			FrmSetEventHandler(frmP, FWInfoFormHandleEvent);
			break;
			
		case BSSScanForm:
			FrmSetEventHandler(frmP, BSSScanFormHandleEvent);
			break;
			
		default:
			break;
		}
		return true;
	}
	
	return false;
}

/***********************************************************************
 *
 * FUNCTION:    ApplEventLoop
 *
 * DESCRIPTION: Main Application event loop.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void AppEventLoop(void)
{
	EventType event;
	Err error = errNone;
	Boolean	handled = false;
	
	do
	{
		EvtGetEvent(&event, gNetStat.evtWait);
		
		if( gNetStat.prgP ) {
			if( event.eType == nilEvent )
				// Pass off to the event handler of the AP scan.
				handled = BSSScanFormHandleEvent( &event );
			else
				handled = PrgHandleEvent( gNetStat.prgP, &event );
		}
		else
			handled = SysHandleEvent( &event );
					
		if(!handled)
		{
			if(!MenuHandleEvent(0, &event, &error) )
			{
				if(!AppHandleEvent(&event))
				{
					FrmDispatchEvent(&event);
				}
			}
		}
	} while(event.eType != appStopEvent);
}

/***********************************************************************
 *
 * FUNCTION:    AppStart
 *
 * DESCRIPTION: Called when the application starts
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

static Err AppStart(void)
{
	Err err = errNone;
	
	// Clear out the global data 
	MemSet( &gNetStat, sizeof( NetStatType ), 0 );
	gNetStat.evtWait = evtWaitForever;
	
	// Allocate memory for the query data.  
	// NOTE:  Never use stack variables for the query data from a 68K
	// app.  This is not guaranteed to be 4 byte aligned and can cause
	// faults in the network driver.
	gNetStat.queryP = MemPtrNew( sizeof( NetQueryType ));

	// Load the NetServices library
	err = PrvLoadNetServices();

Done:		
	return err;
}

/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Called when the application exits
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void AppStop(void)
{
	if( gNetStat.qualityP )
		MemPtrFree( gNetStat.qualityP );
	if( gNetStat.strengthP )
		MemPtrFree( gNetStat.strengthP );
	if( gNetStat.queryP )
		MemPtrFree( gNetStat.queryP );
	if( gNetStat.bssListP )
		MemPtrFree( gNetStat.bssListP );

	if( gNetStat.netInterfaceFound )
		NetLibClose( gNetStat.appRef, false );
	
	// Unload the NetServices library
	if( gNetStat.shlLoaded )
		SysLibRemove(gNetStat.libRef);
		
	FrmCloseAllForms();
}

/* all code from here to end of file should use no global variables */
#pragma warn_a5_access on

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check the if the ROM is compatible with the application
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
    UInt32 romVersion;

    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion < requiredVersion)
    {
        if ((launchFlags & 
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
        {
            FrmAlert (RomIncompatibleAlert);

             if (romVersion < kPalmOS20Version)
            {
                AppLaunchWithCommand(
                    sysFileCDefaultApp, 
                    sysAppLaunchCmdNormalLaunch, NULL);
            }
        }

        return sysErrRomIncompatible;
    }

    return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: Main entry point for the application.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err error;

    error = RomVersionCompatible (ourMinVersion, launchFlags);
    if (error) return (error);

    switch (cmd)
    {
    case sysAppLaunchCmdNormalLaunch:
        error = AppStart();
        if (error) 
            return error;

        FrmGotoForm(MainForm);
        AppEventLoop();
        
        AppStop();
        break;
        
    case sysAppLaunchCmdNotify:
		// The only event we register for is the scan complete.  The pointer
		// to the global area was passed in.  Set the flag indicating the scan
		// complete event was received.
		if (((SysNotifyParamType*)cmdPBP)->notifyType == WIFI_SCAN_COMPLETE_EVENT )
		{
			((SysNotifyParamType*)cmdPBP)->handled = true;
			((NetStatType *)((SysNotifyParamType*)cmdPBP)->userDataP)->scanEventReceived = true;
		}
		break;

    default:
        break;
    }

    return errNone;
}

/* turn a5 warning off to prevent it being set off by C++
 * static initializer code generation */
#pragma warn_a5_access reset
