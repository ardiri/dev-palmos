//
// VPPI & VPN Shim Sample Code
//

This sample code demonstrate how to create a VPN Panel Plug In
and a very simple VPN Shim. This project was built using CodeWarrior 9.

//
// Overview
//

The VPPI part is a 68K application with a type set to 'Vppi'
instead of 'appl'. VPPI applications responds to sublaunch
code sent by the VPN Panel or by the VPN Shim.
The VPN Panel will need access to a list of accounts while
the VPN Shim will sublaunch the VPPI in order to get info from
a user or to inform a user on the current VPN status.

NOTE: You will need to build the ARMlet first and split it
before you can create the VPPI PRC. [See below for info]

//
// VPPI
//

The sample code includes a fully working VPPI with a basic database
for storing user accounts. The 'Debug' and 'Release' target will
build the VPPI.

Files used:
-> VPPSSample.c      : Main file.
-> VPPISampleRsc.h   : Resources.
-> VPNSampleCommon.h : Shared header with the VPN Shim.

//
// VPN Shim
//

The VPN Shim is build as an ARMlet since it interface directly
with the main ARM Shim engine.
Because of this, no OS calls are available but a structure
containing function pointers is passed to each callback. You'll
find utility functions among them, like memAlloc()...

The VPN shim has a unique entry point, namely ShimProc(). This
function is responsible for dispatching the command passed to it.
Always try to use the provided sample code for ShimProc(), you
should not have to modify it. The code is is VPNShimProcARM.c and
the prototype is declared in PalmShimCmd.h.

All the other needed functions are declared in PalmShim.h as well
as teh IFShim structure passed to each functions. The IFShim
structure contains all the function pointers needed to write
the shim.

Files used:
-> VPNShimProcARM.c : Entry point.
-> VPNShimARM.c     : Shim functions.
-> VPNSampleCommon.h : Shared header with the VPN Shim.

//
// Building the ARMlet
//

Although there is an ARMlet target in CW9, it is not recommanded
to use because you might get some alignment issue. Use at your
own risk. But everything is there (I almost got it to work
properly but I had some random crashes...).

If you don't have or don't want to use CW9, you will need to
compile the code with GCC for ARM. The recommended compiler
to use is the GCC provided by Intel for their XScale processors.

Go To:
 http://developer.intel.com/design/intelxscale/dev_tools/010827/

and select the following file:
 GNUpro for Windows NT hosts - ELF targeted binaries [53.1 MB]

Use the "BuildGCC.cmd" to build the ARMlet.
NOTE: You will need to modify the GCC path.

The ARM binary code will be placed in the top folder and is called
'ShimCode.bin'


//
// Merging the ARMlet with the PRC
//

The VPN Shim code has to be in the same binary as the panel plug-in.
Since the VPN SHim has great chances to be bigger than 64KB, we
provided a utility to split the ARM binary and generate some extra
resources to inform the VPN Panel about the number of pieces needed
to put back the ARM code in one piece.

Use "SplitARMlet.exe" that will call Splitter.exe for you.

//
// Building the PRC for the Simulator
//

For the simulator, the VPN Shim and VPPI have to be two distinct
files. You can keep the VPPI as is, but you will need to build
the PRC for the simulator.

The target 'NTSim' in CW will create this PRC for you.

Files used:
-> VPNShimNTPRC.c : Empty startup code
-> VPNShimNTSim.r : Create a resource of type 'x86c' that contains
the path and entry point of the DLL version of your shim.

Always respect the \000 for the path. The current path expect the DLL
to be placed in the same directory as PalmSim.exe. You can always
change this.

//
// Building the NTSim DLL Shim
//

The final step is to create a DLL so you can debug the shim with
the Tungsten|C NTSim.
A project has been setup to build the DLL(VPNShimNTSim.dsw) as well
as a make file(VPNShimNTSim.mak). Use 'BuildDLL.bat' to call the
makefile. It will create both targets (debug & release) although
you really only need the Debug one.

The built DLLs are currently placed in NTSim/[target]. You should
set the output path to the your NTSim path.

//
// Mini FAQ
//

Q: The Shim works fine in PalmSim but I get a "Fatal Exception"
   on the device?
A: This is an alignment issue. Make sure you use the same options
   as in BuildGCC.cmd.

Q: I see all these command prompt window poping and disappearing?
A: Targets might call a batch file for example to automatically
   build the NTSim, split the ARMlet...

-----------------------------------------------------------------

For convenience, the binaries of the ARMlet are left in this
sample so you can test the VPN Plug-in Panel directly.