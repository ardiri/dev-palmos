
@REM    attempt to save path
@set ORIGINALpath=%path%

@REM	add gcc path(s)
@set GNUpath=D:\xscale-gcc\H-i686-pc-cygwin\bin;%path%

@REM	build ARM native code
@set path=%GNUpath%
@if exist armDbg rmdir /S armDbg
@mkdir armDbg

@echo Starting gcc build of ARM native code
@set GCCFLAGS=-mcpu=arm7tdmi -fshort-enums -mthumb-interwork -mno-apcs-frame -ffixed-r8 -ffixed-r9 -fPIC -Wno-multichar
@set GCCINCLUDES=-I..\..\Incs -ISrc

xscale-elf-gcc %GCCFLAGS% %GCCINCLUDES% -nostdinc -O1 -c Src\VPNShimProcARM.c -o armDbg\VPNShimProcARM.o
xscale-elf-gcc %GCCFLAGS% %GCCINCLUDES% -nostdinc -O1 -c Src\VPNShimARM.c -o armDbg\VPNShimARM.o

@REM
@REM	in the next command, the -e is the entrypoint function name
@REM
xscale-elf-gcc %GCCFLAGS% -nostdlib -e ShimProc -Ttext 0x0 -o armDbg\ShimProc.exe armDbg\VPNShimProcARM.o armDbg\VPNShimARM.o -lgcc
xscale-elf-objcopy -O binary armDbg\ShimProc.exe ShimCode.bin
@if exist armDbg\build.log del armDbg\build.log
xscale-elf-objdump -d armDbg\ShimProc.exe >> armDbg\build.log

@REM    attempt to restore original path
@set path=%ORIGINALpath%
