// Automatically Generated .r file

data 'tint' (1600, "blocksize") {
	$"00008000"
};

data 'tint' (1601, "numfiles") {
	$"00000001"
};

data 'tint' (1602, "total size") {
	$"0000042c"
};

read 'ARMc' (0) "ShimCode.000";
