# Microsoft Developer Studio Generated NMAKE File, Based on VPNShimNTSim.dsp
!IF "$(CFG)" == ""
CFG=Shim - Win32 Debug
!MESSAGE No configuration specified. Defaulting to Shim - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "Shim - Win32 Release" && "$(CFG)" != "Shim - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "VPNShimNTSim.mak" CFG="Shim - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Shim - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "Shim - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "Shim - Win32 Release"

OUTDIR=.\Obj/Release
INTDIR=.\Obj/Release

ALL : ".\NTSim\Release\VPNShimNTSim.dll"


CLEAN :
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\VPNShimARM.obj"
	-@erase "$(INTDIR)\VPNShimProcARM.obj"
	-@erase "$(OUTDIR)\VPNShimNTSim.exp"
	-@erase "$(OUTDIR)\VPNShimNTSim.lib"
	-@erase ".\NTSim\Release\VPNShimNTSim.dll"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MT /W3 /GX /O2 /I "..\..\Incs" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /D "SHIM_EXPORTS" /Fp"$(INTDIR)\VPNShimNTSim.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC=rc.exe
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\VPNShimNTSim.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /incremental:no /pdb:"$(OUTDIR)\VPNShimNTSim.pdb" /machine:I386 /out:"NTSim/Release/VPNShimNTSim.dll" /implib:"$(OUTDIR)\VPNShimNTSim.lib" 
LINK32_OBJS= \
	"$(INTDIR)\VPNShimARM.obj" \
	"$(INTDIR)\VPNShimProcARM.obj"

".\NTSim\Release\VPNShimNTSim.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "Shim - Win32 Debug"

OUTDIR=.\Obj/Debug
INTDIR=.\Obj/Debug
# Begin Custom Macros
OutDir=.\Obj/Debug
# End Custom Macros

ALL : ".\NtSim\Debug\VPNShimSample.dll" "$(OUTDIR)\VPNShimNTSim.bsc"


CLEAN :
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(INTDIR)\VPNShimARM.obj"
	-@erase "$(INTDIR)\VPNShimARM.sbr"
	-@erase "$(INTDIR)\VPNShimProcARM.obj"
	-@erase "$(INTDIR)\VPNShimProcARM.sbr"
	-@erase "$(OUTDIR)\VPNShimNTSim.bsc"
	-@erase "$(OUTDIR)\VPNShimSample.exp"
	-@erase "$(OUTDIR)\VPNShimSample.lib"
	-@erase "$(OUTDIR)\VPNShimSample.pdb"
	-@erase ".\NtSim\Debug\VPNShimSample.dll"
	-@erase ".\NtSim\Debug\VPNShimSample.ilk"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MTd /W3 /Gm /GX /ZI /Od /I "..\..\Incs" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\VPNShimNTSim.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC=rc.exe
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\VPNShimNTSim.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\VPNShimARM.sbr" \
	"$(INTDIR)\VPNShimProcARM.sbr"

"$(OUTDIR)\VPNShimNTSim.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /dll /incremental:yes /pdb:"$(OUTDIR)\VPNShimSample.pdb" /debug /machine:I386 /out:"NtSim/Debug/VPNShimSample.dll" /implib:"$(OUTDIR)\VPNShimSample.lib" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\VPNShimARM.obj" \
	"$(INTDIR)\VPNShimProcARM.obj"

".\NtSim\Debug\VPNShimSample.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("VPNShimNTSim.dep")
!INCLUDE "VPNShimNTSim.dep"
!ELSE 
!MESSAGE Warning: cannot find "VPNShimNTSim.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "Shim - Win32 Release" || "$(CFG)" == "Shim - Win32 Debug"
SOURCE=.\Src\VPNShimARM.c

!IF  "$(CFG)" == "Shim - Win32 Release"


"$(INTDIR)\VPNShimARM.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Shim - Win32 Debug"


"$(INTDIR)\VPNShimARM.obj"	"$(INTDIR)\VPNShimARM.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 

SOURCE=.\Src\VPNShimProcARM.c

!IF  "$(CFG)" == "Shim - Win32 Release"


"$(INTDIR)\VPNShimProcARM.obj" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ELSEIF  "$(CFG)" == "Shim - Win32 Debug"


"$(INTDIR)\VPNShimProcARM.obj"	"$(INTDIR)\VPNShimProcARM.sbr" : $(SOURCE) "$(INTDIR)"
	$(CPP) $(CPP_PROJ) $(SOURCE)


!ENDIF 


!ENDIF 

