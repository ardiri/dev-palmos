/***********************************************************************
 *
 * Copyright (c) 2003 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	VPNShimProc.c
 *
 * Description:
 *	Main file for the VPN shim. This is the entry point of the Shim.
 *
 *	Version 1.0 	- Initial Revision (03/30/03)
 *
 ***********************************************************************/
 
#include "PalmShimCmd.h"

//#pragma thumb off

/**
 * Overrides the ShimProc to be ARMlet_Main.
 * This allow us to compile the ARMlet with CW9.
 */
#ifdef __MWERKS__
#define ShimProc ARMlet_Main
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimProc
 *
 * DESCRIPTION: This is the entry point of our shim. This code will
 *				dispatch the shim command to the right function.
 * 				
 *				IMPORTANT: This code needs to be first!!!
 *
 * PARAMETERS:	type	- The Shim command type
 *				cmd		- Pointer to a ShimCmd
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
NATIVE_CODE void ShimProc(ShimCmdType type, ShimCmd* cmd)
{
	switch(type)
	{
	/** Initializing the Shim. */
	case ShimCmd_INIT:
		ShimInit(cmd->init.shim);
		break;
	
	/** De-Initialize the Shim. */
	case ShimCmd_DE_INIT:
		ShimDeinit(cmd->deinit.shim);
		break;
	
	/** Interface is up. */	
	case ShimCmd_IFACE_IS_UP:
		ShimInterfaceIsUp(cmd->interfaceIsUp.shim);
		break;
		
	/** Interface will go down. */
	case ShimCmd_IFACE_WILL_GO_DOWN:
		ShimInterfaceWillGoDown(cmd->interfaceWillGoDown.shim);
		break;
		
	/** Called when receiving a packet during an IP connection. */
	case ShimCmd_IP_RECEIVE:
		ShimIPReceive(cmd->ipReceive.shim, cmd->ipReceive.packet);
		break;
	
	/** Called when sending a packet during an IP connection. */
	case ShimCmd_IP_SEND:
		ShimIPSend(cmd->ipSend.shim, cmd->ipSend.packet);
		break;
	
	/** Called when a TCP connection is opening. */	
	case ShimCmd_TCP_ON_OPEN:
		ShimTCPOnOpen(	cmd->tcpOnOpen.shim,
						cmd->tcpOnOpen.con,
						cmd->tcpOnOpen.cookie);
		break;
	
	/** Called when receiving packets during a TCP connection. */	
	case ShimCmd_TCP_ON_RECEIVE:
		cmd->tcpOnReceive.retVal = ShimTCPOnReceive(cmd->tcpOnReceive.shim,
													cmd->tcpOnReceive.con,
													cmd->tcpOnReceive.packet,
													cmd->tcpOnReceive.cookie);
		break;
	
	/** Called when a TCP connection is transmitting packets. */
	case ShimCmd_TCP_ON_TRANSMIT:
		ShimTCPOnTransmit(		cmd->tcpOnTransmit.shim,
								cmd->tcpOnTransmit.con,
								cmd->tcpOnTransmit.cookie);
		break;
	
	/**	Called when a TCP connection is closed remotely. */
	case ShimCmd_TCP_ON_REMOTE_CLOSE:
		ShimTCPOnRemoteClose(	cmd->tcpOnRemoteClose.shim,
								cmd->tcpOnRemoteClose.con,
								cmd->tcpOnRemoteClose.cookie);
		break;
	
	/**	Called when a TCP connection is closing. */
	case ShimCmd_TCP_ON_CLOSE:
		ShimTCPOnClose(			cmd->tcpOnClose.shim,
								cmd->tcpOnClose.con,
								cmd->tcpOnClose.why,
								cmd->tcpOnClose.cookie);
		break;
	
	/** Called when a DNS query is successful. */	
	case ShimCmd_DNS_QUERY_SUCCESS:
		ShimDNSQuerySuccess(	cmd->dnsQuerySuccess.shim,
								cmd->dnsQuerySuccess.query,
								cmd->dnsQuerySuccess.canonicalName,
								cmd->dnsQuerySuccess.numAddrs,
								cmd->dnsQuerySuccess.addrs,
								cmd->dnsQuerySuccess.cookie);
		break;
	
	/** Called when a DNS query fails. */	
	case ShimCmd_DNS_QUERY_FAILURE:
		ShimDNSQueryFailure(	cmd->dnsQueryFailure.shim,
								cmd->dnsQueryFailure.query,
								cmd->dnsQueryFailure.error,
								cmd->dnsQueryFailure.cookie);
		break;
	
	/** Called when a Timer expires. */	
	case ShimCmd_TIMER_EXPIRATION:
		ShimTimerExpiration(	cmd->timerExpiration.shim,
								cmd->timerExpiration.timer,
								cmd->timerExpiration.cookie);
		break;
	
	/** Called after config is set by NetLibIFSettingSet. */	
	case ShimCmd_CONFIG_SETTING_WAS_SET:
		ShimConfigSettingWasSet(cmd->configSettingWasSet.shim);
		break;
		
	default:
		break;
	}
}


