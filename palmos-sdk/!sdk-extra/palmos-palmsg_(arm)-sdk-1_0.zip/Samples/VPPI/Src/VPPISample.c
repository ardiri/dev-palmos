/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	VPPISample.c
 *
 * Description:
 *	Sample code for the VPN Plug-In Panel.
 *
 *	Version 1.0 	- Initial Revision (03/27/09)
 *
 ***********************************************************************/
 
#include <PalmOS.h>

#include "Common.h"
#include "PalmVPPI.h"
#include "PalmShimSettings.h"
#include "VPPISampleRsc.h"
#include "VPNSampleCommon.h"

/*********************************************************************
 * Internal Constants
 *********************************************************************/
 
#define appFileCreator			'VpPp'
#define appName					"VPPISample"
#define appCreatorStr			"VpPp"
#define appDBName				appName "-" appCreatorStr
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

#define ourMinVersion    sysMakeROMVersion(3,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

/***********************************************************************
 *
 * FUNCTION:	PrvSetupDatabase
 *
 * DESCRIPTION: When the VPPI is called for the first time, we create
 *				the database that will contain the accounts for the VPN
 *				panel. If it already exists, do nothing.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	Error is unable to setup the account database.
 *
 ***********************************************************************/

static Err PrvSetupDatabase()
{
	Err 	err = errNone;	
	LocalID dbId = 0;
	
	// Try to see if the database already exists
	dbId = DmFindDatabase(0, appDBName);
	if(!dbId)
	{
		// Create the database if not found
		err = DmCreateDatabase(0, appDBName, appFileCreator, 'data', false);
		if(err)
			goto Done;
	}
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	PrvAddRecord
 *
 * DESCRIPTION: Adds a VPN account to the current database.
 *
 * PARAMETERS:	accountP	- Pointer to a VPNAccountType
 *
 * RETURNED:	Error is unable to add the account to the database.
 *
 ***********************************************************************/

static Err PrvAddRecord(VPNAccountType* accountP)
{
	Err 		err 		= errNone;	
	void*		memLockP 	= NULL;
	LocalID 	dbId 		= 0;
	MemHandle	recordHandle= NULL;
	DmOpenRef	dbRef 		= NULL;
	UInt16		recordIndex	= dmMaxRecordIndex;
	
	// Look for the database
	dbId = DmFindDatabase(0, appDBName);
	if( !dbId )
	{
		PrvSetupDatabase();
		dbId = DmFindDatabase(0, appDBName);
		if( !dbId ) {
			err = DmGetLastErr();
			goto Done;
		}
	}
	
	// Open the database
	dbRef = DmOpenDatabase(0, dbId, dmModeReadWrite | dmModeExclusive);
	if(!dbRef)
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	// Create a new record
	recordHandle = DmNewRecord(dbRef, &recordIndex, sizeof(VPNAccountType));
	if(!recordHandle)
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	// Get the record info since it will generate a unique ID for us
	DmRecordInfo(dbRef, recordIndex, NULL, &accountP->accountID, NULL);
	
	// Lock the record and write it
	// Notice that the record is not that great since I am only using the
	// VPNAccountType structure. You will need to add support for password
	// or other information.
	memLockP = MemHandleLock(recordHandle);
	err = DmWrite(memLockP, 0, accountP, sizeof(VPNAccountType));
	MemHandleUnlock(recordHandle);
	DmReleaseRecord(dbRef, recordIndex, true);
	
	// If an error occured, remove the record
	if(err)
	{
		DmRemoveRecord(dbRef, recordIndex);
	}	
	
Done:
	// Close the database
	if( dbRef )
		err = DmCloseDatabase(dbRef);
		
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	PrvUpdateRecord
 *
 * DESCRIPTION: Updates a VPN account
 *
 * PARAMETERS:	accountP	- Pointer to a VPNAccountType
 *
 * RETURNED:	Error is unable to update the account to the database.
 *
 ***********************************************************************/

static Err PrvUpdateRecord(VPNAccountType* accountP)
{
	Err 		err 		= errNone;	
	void*		memLockP 	= NULL;
	LocalID 	dbId 		= 0;
	MemHandle	recordHandle= NULL;
	DmOpenRef	dbRef 		= NULL;
	UInt16		recordIndex	= dmMaxRecordIndex;
	
	// Look for the database
	dbId = DmFindDatabase(0, appDBName);
	if( !dbId )
	{
		PrvSetupDatabase();
		dbId = DmFindDatabase(0, appDBName);
		if( !dbId ) {
			err = DmGetLastErr();
			goto Done;
		}
	}
	
	// Open the database
	dbRef = DmOpenDatabase(0, dbId, dmModeReadWrite | dmModeExclusive);
	if(!dbRef)
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	err = DmFindRecordByID(dbRef, accountP->accountID, &recordIndex);
	if(err)
		goto Done;
		
	recordHandle = DmGetRecord(dbRef, recordIndex);
	if(recordHandle == NULL) {
		err = DmGetLastErr();
		goto Done;
	}
		
	memLockP = MemHandleLock(recordHandle);
	MemMove(memLockP, (void*)accountP, sizeof(VPNAccountType));
	MemHandleUnlock(recordHandle);
	DmReleaseRecord(dbRef, recordIndex, true);
	
Done:
	// Close the database
	if( dbRef )
		err = DmCloseDatabase(dbRef);
		
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	PrvGetRecord
 *
 * DESCRIPTION: Get a VPN account
 *
 * PARAMETERS:	accountP	- Pointer to a VPNAccountType
 *
 * RETURNED:	Error is unable to get the account to the database.
 *
 ***********************************************************************/

static Err PrvGetRecord(VPNAccountType* accountP)
{
	Err 		err 		= errNone;	
	void*		memLockP 	= NULL;
	LocalID 	dbId 		= 0;
	MemHandle	recordHandle= NULL;
	DmOpenRef	dbRef 		= NULL;
	UInt16		recordIndex	= dmMaxRecordIndex;
	
	// Look for the database
	dbId = DmFindDatabase(0, appDBName);
	if( !dbId )
	{
		PrvSetupDatabase();
		dbId = DmFindDatabase(0, appDBName);
		if( !dbId ) {
			err = DmGetLastErr();
			goto Done;
		}
	}
	
	// Open the database
	dbRef = DmOpenDatabase(0, dbId, dmModeReadWrite | dmModeExclusive);
	if(!dbRef)
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	err = DmFindRecordByID(dbRef, accountP->accountID, &recordIndex);
	if(err)
		goto Done;
		
	recordHandle = DmGetRecord(dbRef, recordIndex);
	if(recordHandle == NULL) {
		err = DmGetLastErr();
		goto Done;
	}
		
	memLockP = MemHandleLock(recordHandle);
	MemMove((void*)accountP, memLockP, sizeof(VPNAccountType));
	MemHandleUnlock(recordHandle);
	DmReleaseRecord(dbRef, recordIndex, true);
	
Done:
	// Close the database
	if( dbRef )
		err = DmCloseDatabase(dbRef);
		
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	PrvDeleteRecord
 *
 * DESCRIPTION: Deletes a VPN account to the current database.
 *
 * PARAMETERS:	accountP	- Pointer to a VPNAccountType
 *
 * RETURNED:	Error is unable to delete the account to the database.
 *
 ***********************************************************************/

static Err PrvDeleteRecord(VPNAccountType* accountP)
{
	Err 		err			= errNone;
	LocalID 	dbId 		= 0;
	DmOpenRef	dbRef 		= NULL;
	UInt16		recordIndex	= dmMaxRecordIndex;
	
	// Look for the database
	dbId = DmFindDatabase(0, appDBName);
	if( !dbId )
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	// Open the database
	dbRef = DmOpenDatabase(0, dbId, dmModeReadWrite | dmModeExclusive);
	if(!dbRef)
	{
		err = DmGetLastErr();
		goto Done;
	}
	
	// Find the database
	err = DmFindRecordByID(dbRef, accountP->accountID, &recordIndex);
	if( err )
		goto Done;
		
	// Delete the record
	err = DmRemoveRecord(dbRef, recordIndex);
	
	
Done:
	// Close the database
	if( dbRef )
		err = DmCloseDatabase(dbRef);
	
	return err;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    PrvGetAccounts
 *
 * DESCRIPTION: The VPN panel will zero numAccounts and accounts before
 *				calling the VPPI. If the VPPI doesn't have any accounts,
 *				it should just zero err. If there are accounts to return,
 *				it should allocate a chunk in the dynamic heap to store
 *				them and put a pointer to this chunk in the accounts
 *				field. The VPN panel will free this chunk. Note that the
 *				VPPI creator ID is duplicated in each account.
 *
 * PARAMETERS:	accountP	- Pointer to a SysVPPILaunchCmdGetAccountsType
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void PrvGetAccounts(SysVPPILaunchCmdGetAccountsType *accountP)
{
	LocalID 	dbId 		= 0;
	DmOpenRef	dbRef 		= NULL;
	void*		memLockP 	= NULL;
	MemHandle	recordHandle= NULL;
	UInt16		index		= 0;
	UInt16		recordIndex	= dmMaxRecordIndex;
	
	// Look for the database
	dbId = DmFindDatabase(0, appDBName);
	if( !dbId )
	{
		accountP->err = PrvSetupDatabase();
		dbId = DmFindDatabase(0, appDBName);
		if( !dbId ) {
			accountP->err = DmGetLastErr();
			goto Done;
		}
	}
	
	// Open the database
	dbRef = DmOpenDatabase(0, dbId, dmModeReadWrite | dmModeExclusive);
	if(!dbRef)
		goto Done;
	
	// Get the number of records
	accountP->numAccounts = DmNumRecords(dbRef);
	if(accountP->numAccounts == 0) {
		accountP->accounts = NULL;
		accountP->err = errNone;
		goto Done;
	}

	// Allocate dynamic memory. This memory will be deleted by the VPN Panel.
	accountP->accounts = (VPNAccountType*) MemPtrNew(accountP->numAccounts * sizeof(VPNAccountType));
	if(!accountP->accounts)
	{
		accountP->numAccounts = 0;
		accountP->err = memErrNotEnoughSpace;
		goto Done;
	}
	
	// Clean the memory
	MemPtrSetOwner(accountP->accounts, 0);
	MemSet(accountP->accounts, accountP->numAccounts * sizeof(VPNAccountType), 0);
	
	// Fill the account array
	for(index = 0; index < accountP->numAccounts; index++)
	{
		recordHandle = DmGetRecord(dbRef, index);
		if(recordHandle == NULL) {
			accountP->numAccounts = index;
			goto Done;
		}
		
		memLockP = MemHandleLock(recordHandle);
		MemMove((void*)&accountP->accounts[index], memLockP, sizeof(VPNAccountType));
		MemHandleUnlock(recordHandle);
		DmReleaseRecord(dbRef, index, true);
	}
	
	// Set the error code to 0
	accountP->err = errNone;
	
Done:
	// Close the database
	if( dbRef )
		DmCloseDatabase(dbRef);
		
	return;
}

/***********************************************************************
 *
 * FUNCTION:    PrvEditAccount
 *
 * DESCRIPTION: In this case, the account struct will be zeroed out by
 *				the VPN panel and should be filled in by the VPPI if an
 *				account is successfully created. If there is only one
 *				VPPI installed, the user isn't asked which protocol to
 *				use. In this case, the VPPI should put up a dialog with
 *				OK and Cancel buttons. The useWizardUI field will be
 *				false in this case. On the other hand, if there are
 *				several VPPIs,the user will first choose one, and then
 *				enter the protocol-specific information. In this case,
 *				the VPPI should put up a dialog with Previous and Done
 *				buttons. The useWizardUI field will be true in this case.
 *				In both cases, there are two choices. OK and Done will
 *				attempt to create an account. This may fail because of
 *				missing required fields. The Cancel and Previous buttons
 *				will abort. To indicate this, the VPPI should leave the
 *				account field zeroed out and zero the err field.
 *				[ More info in the SDK documentation :) ]
 *
 * PARAMETERS:	accountP	- Pointer to a SysVPPILaunchCmdEditAccountType
 *
 * RETURNED:	-
 *
 ***********************************************************************/
  
static void PrvEditAccount(SysVPPILaunchCmdEditAccountType *accountP)
{
	UInt16 buttonID = 0;
	FieldType *fieldP = NULL;
	
	// Initialize the input form
	FormType *formP = FrmInitForm(VPPISampleForm);
	if( !formP )
		return;
	
	// Set the form controls depending on useWizardUI
	if( accountP->useWizardUI )
	{
		// Enable the Previous and Done buttons
		ControlType *controlP = (ControlType*)FrmGetPtr(formP, VPPISamplePreviousButton);
		if(controlP)
			CtlSetUsable(controlP, true);
			
		controlP = (ControlType*)FrmGetPtr(formP, VPPISampleDoneButton);
		if(controlP)
			CtlSetUsable(controlP, true);
	}
	else
	{
		// Enable the OK and Cancel buttons
		ControlType *controlP = (ControlType*)FrmGetPtr(formP, VPPISampleOKButton);
		if(controlP)
			CtlSetUsable(controlP, true);
			
		controlP = (ControlType*)FrmGetPtr(formP, VPPISampleCancelButton);
		if(controlP)
			CtlSetUsable(controlP, true);
	}
	
	// Write the current account information
	fieldP = (FieldType*)FrmGetPtr(formP, VPPISampleAccountField);
	if(fieldP)
		SetFieldTextFromStr(fieldP, (Char*)&accountP->account.accountName, false);
	
	// Pop the dialog
	buttonID = FrmDoDialog(formP);
	
	// 
	switch(buttonID)
	{
		case VPPISampleOKButton:
		case VPPISampleDoneButton:
			accountP->useSavedAccount = false;
			// Set the VPPI creator
			accountP->account.vppiCreator = appFileCreator;
			// Copy the name from the field
			fieldP = (FieldType*)FrmGetPtr(formP, VPPISampleAccountField);
			if(fieldP)
				StrCopy(accountP->account.accountName, FldGetTextPtr(fieldP));
			if(accountP->account.accountID) {
				// Update the record
				accountP->err = PrvUpdateRecord(&accountP->account);
			} else {
				// Add the record
				accountP->err = PrvAddRecord(&accountP->account);
			}
			break;
			
		case VPPISampleCancelButton:
			accountP->useSavedAccount = false;
			break;
			
		case VPPISamplePreviousButton:
			accountP->useSavedAccount = true;
			break;
	}
	
	
	FrmDeleteForm(formP);	
}

/***********************************************************************
 *
 * FUNCTION:     PrvDeleteAccount
 *
 * DESCRIPTION: This shouldn't put up a confirmation dialog; if one is
 *				needed, the VPN panel will take care of that. It should
 *				delete the specified account and zero the err field.
 *				The VPN panel will prevent the user from deleting an
 *				account that's logged in.
 *
 * PARAMETERS:	accountP	- Pointer to a SysVPPILaunchCmdDeleteAccountType
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void PrvDeleteAccount(SysVPPILaunchCmdDeleteAccountType *accountP)
{
	// Remove the record form the database
	accountP->err = PrvDeleteRecord(&accountP->account);
}

/***********************************************************************
 *
 * FUNCTION:    PrvSetCurrentAccount
 *
 * DESCRIPTION: This functions will be called by the VPN Panel for
 *				setting the current account. This is called when a user
 *				creates the first account since this account is implicitly
 *				chosen. If a user delete the current account, we may
 *				automatically pick another one.
 *
 * PARAMETERS:	accountP	- Pointer to a SysVPPILaunchCmdSetCurrentAccountType
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void PrvSetCurrentAccount(SysVPPILaunchCmdSetCurrentAccountType *accountP)
{
	// Get the requested account
	// Should be smarter, but it works
	accountP->err = PrvGetRecord(&accountP->account);
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    PrvPromptAndConfigure
 *
 * DESCRIPTION: This is invoked to bring up the prompt dialog (VPPI
 *				decides if prompt is necessary). Upon exit, the feature
 *				for pvConfig should be set up.
 *
 * PARAMETERS:	launchTypeP	- Pointer to a SysVPPILaunchCmdPromptAndConfigureType
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void PrvPromptAndConfigure(SysVPPILaunchCmdPromptAndConfigureType *launchTypeP)
{
	Err            error;
	UInt16         netLibRef;
	UserPassConfig *upc = (UserPassConfig *)MemPtrNew(sizeof(UserPassConfig));
	UInt16         upcLen = sizeof(UserPassConfig);
	
	// Get a ref to NetLib
	SysLibFind("Net.lib", &netLibRef);
	
	if(netLibRef == 0)
		return;
		
	// Get the current config
	error = NetLibIFSettingGet(	netLibRef,
								launchTypeP->origCreator,
								launchTypeP->origInstance,
								netIFSettingShimConfig,
								upc, &upcLen);
								
	if (upcLen == 0)  // no configuration found
	{
		upc->type = Config_USERNAME;
		MemSet(upc->text, 100, chrNull);
		
		FrmCustomResponseAlert(UserAlert, 0, 0, 0, upc->text, 99, NULL);
		
		error = NetLibIFSettingSet(	netLibRef,
									launchTypeP->origCreator,
									launchTypeP->origInstance,
									netIFSettingShimConfig,
									upc, sizeof(UserPassConfig));
	}
	else 
	// Configuration found so we must have already sent the user info to the shim
	{
	
		upc->type = Config_PASSWORD;
		MemSet(upc->text, 100, chrNull);
		
		FrmCustomResponseAlert(PasswordAlert, 0, 0, 0, upc->text, 99, NULL);
		
		error = NetLibIFSettingSet(	netLibRef,
									launchTypeP->origCreator,
									launchTypeP->origInstance,
									netIFSettingShimConfig,
									upc, sizeof(UserPassConfig));
    }
    
    MemPtrFree(upc);
    
	launchTypeP->errOut = errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PrvProgressPaint
 *
 * DESCRIPTION: This is invoked to paint the progress dialog's client rect.
 *
 * PARAMETERS:	launchTypeP	- Pointer to a SysVPPILaunchCmdProgressPaintType
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void PrvProgressPaint(SysVPPILaunchCmdProgressPaintType *launchTypeP)
{
	MemHandle handle	= NULL;
	UInt16    bitmapID	= SHIM_INIT_STAGE;
	
	// Select the correct bitmap ID
	switch(launchTypeP->stage)
	{
		case SHIM_INIT_STAGE:
			bitmapID = InitBitmapFamily;
			break;
		case SHIM_INTERFACE_IS_UP:
			bitmapID = InterfaceIsUpBitmapFamily;
			break;
		case SHIM_DNSQUERYSUCCESS:
			bitmapID = DNSSuccessBitmapFamily;
			break;
		case SHIM_DNSQUERYFAILURE:
			bitmapID = DNSFailureBitmapFamily;
			break;
		case SHIM_CONFIG_WAS_SET:
			bitmapID = ConfigWasSetBitmapFamily;
			break;
    }
    
    // Get the bitmap resource
    handle = DmGetResource(bitmapRsc, bitmapID);
    if(handle)
    {
    	BitmapPtr bitmapP = (BitmapType*)MemHandleLock(handle);
    	
    	if(bitmapP)
    	{
    		// Draw our little icon
    		WinDrawBitmap(bitmapP, launchTypeP->clientRect.topLeft.x + launchTypeP->clientRect.extent.x / 2 - 8,
    						launchTypeP->clientRect.topLeft.y + 2 );
    						
    		// Display the state
    		WinDrawChars("Hello", 5, launchTypeP->clientRect.topLeft.x + launchTypeP->clientRect.extent.x / 2 - 8,
    						launchTypeP->clientRect.topLeft.y + 20 );
    						
    		MemHandleUnlock(handle);
    	}
    	
    	DmReleaseResource(handle);
    }
    
    // Wait for a second...
    SysTaskDelay(SysTicksPerSecond());
    
    // Everything was fine
    launchTypeP->errOut = errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PrvErrorDialog
 *
 * DESCRIPTION: This is invoked to put up an error dialog.
 *
 * PARAMETERS:	launchTypeP	- Pointer to a SysVPPILaunchCmdErrorDialogType
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void PrvErrorDialog(SysVPPILaunchCmdErrorDialogType *launchTypeP)
{
	Char errorText[32];
	StrPrintF(errorText, "%ld", launchTypeP->error);
	FrmCustomAlert(VPPIErrorAlert, errorText, NULL, NULL);
}

/***********************************************************************
 *
 * FUNCTION:    PrvClearPWCache
 *
 * DESCRIPTION: This is invoked to request a password cache clear.
 *
 * PARAMETERS:	launchTypeP	- Pointer to a SysVPPILaunchCmdClearPWCacheType
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void PrvClearPWCache(SysVPPILaunchCmdClearPWCacheType *launchTypeP)
{
}

/***********************************************************************
 *
 * FUNCTION:    PrvWillPWPrompt
 *
 * DESCRIPTION: This is invoked to determine if the VPPI will prompt for
 *				a password at, but not before, some seconds in the future.
 *				Result is a Boolean.
 *
 * PARAMETERS:	launchTypeP	- Pointer to a SysVPPILaunchCmdWillPWPromptType
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void PrvWillPWPrompt(SysVPPILaunchCmdWillPWPromptType *launchTypeP)
{
}

#if 0
#pragma mark -
#endif

/* all code from here to end of file should use no global variables */
#pragma warn_a5_access on

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check the if the ROM is compatible with the application
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
	{
		if ((launchFlags & 
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		{
			FrmAlert (RomIncompatibleAlert);

			 if (romVersion < kPalmOS20Version)
			{
				AppLaunchWithCommand(
					sysFileCDefaultApp, 
					sysAppLaunchCmdNormalLaunch, NULL);
			}
		}

		return sysErrRomIncompatible;
	}

	return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: Main entry point for the application.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	Err error = errNone;

	error = RomVersionCompatible (ourMinVersion, launchFlags);
	if(error)
		goto Done;

	switch (cmd)
	{
	//
	// Normal launch
	//
	case sysAppLaunchCmdNormalLaunch:
		error = PrvSetupDatabase();
		break;
	//
	// Called by the VPN Panel
	// 		
	case sysVPPILaunchCmdGetAccounts:
		PrvGetAccounts((SysVPPILaunchCmdGetAccountsType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdEditAccount:
		PrvEditAccount((SysVPPILaunchCmdEditAccountType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdDeleteAccount:
		PrvDeleteAccount((SysVPPILaunchCmdDeleteAccountType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdSetCurrentAccount:
		PrvSetCurrentAccount((SysVPPILaunchCmdSetCurrentAccountType*)cmdPBP);
		break;
	
	//
	// Called by the VPN Engine
	// 	
	case sysVPPILaunchCmdPromptAndConfigure:
		PrvPromptAndConfigure((SysVPPILaunchCmdPromptAndConfigureType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdProgressPaint:
		PrvProgressPaint((SysVPPILaunchCmdProgressPaintType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdErrorDialog:
		PrvErrorDialog((SysVPPILaunchCmdErrorDialogType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdClearPWCache:
		PrvClearPWCache((SysVPPILaunchCmdClearPWCacheType*)cmdPBP);
		break;
		
	case sysVPPILaunchCmdWillPWPrompt:
		PrvWillPWPrompt((SysVPPILaunchCmdWillPWPromptType*)cmdPBP);
		break;
		
	default:
		break;
	}

Done:
	return error;
}

/* turn a5 warning off to prevent it being set off by C++
 * static initializer code generation */
#pragma warn_a5_access reset
