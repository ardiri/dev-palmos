/***********************************************************************
 *
 * Copyright (c) 2001 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	VPNSampleCommon.h
 *
 * Description:
 *	Common header for VPPI and VPN Shim.
 *	Contains the stages for the progress paint.
 *
  *	Version 1.0 	- Initial Revision (03/30/03)
 *
 ***********************************************************************/

#ifndef VPNSAMPLESTAGES_H_
#define VPNSAMPLESTAGES_H_

/***********************************************************************
 * Enums
 ***********************************************************************/

enum {
	SHIM_INIT_STAGE,
	SHIM_INTERFACE_IS_UP,
	SHIM_DNSQUERYSUCCESS,
	SHIM_DNSQUERYFAILURE,
	SHIM_CONFIG_WAS_SET
};

/***********************************************************************
 * Enums
 ***********************************************************************/

typedef enum
{
	Config_USERNAME,
	Config_PASSWORD
} ConfigType;

typedef struct
{
	Int32 type;
	Char  text[64];
} UserPassConfig;


 
#endif VPNSAMPLESTAGES_H_