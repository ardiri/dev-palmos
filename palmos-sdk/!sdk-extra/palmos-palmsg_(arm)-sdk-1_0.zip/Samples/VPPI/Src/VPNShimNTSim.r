data 'x86c' (0, "ShimProc")
{
  "VPNShimSample.dll\000ShimProc\000"
};
