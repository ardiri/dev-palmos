//
//	This file is for the code warrior project only...
//
void __Startup__();

void __Startup__()
{
  ;
}
