/***********************************************************************
 *
 * Copyright (c) 2003 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	VPNShimARM.c
 *
 * Description:
 *	Implementation of the functions for the ShimProc.
 *
 *	Version 1.0 	- Initial Revision (03/30/03)
 *
 ***********************************************************************/

#include "PalmShim.h"
#include "VPNSampleCommon.h"

/**
 * Sample cookie.
 */
typedef struct
{
	TCPCon *con;
} ShimSpecificState;

/***********************************************************************
 *
 * FUNCTION:    ShimInit
 *
 * DESCRIPTION: Called when the Shim is initialized.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
void ShimInit(IFShim *shimP)
{
	/**
	 * This is a good place to adjust the packet size
	 * so that you can add your VPN header. Also a good
	 * place to create your cookie (pseudo global).
	 *
	 * UInt16 newHeaderLen = (UInt16)(shimP->getHeaderLen(shimP) + 40); // Change the size
	 * UInt16 newMTU       = (UInt16)(shimP->getMTU(shimP) - 40); // Adjust MTU
	 *
	 * // Set the new header and MTU values
	 * shimP->setHeaderLen(shimP, newHeaderLen);
	 * shimP->setMTU(shimP, newMTU);
	 *
	 * // Create shim-specific state and save it
	 * cookie = shimP->memAlloc(sizeof(ShimSpecificState));
	 * shimP->setCookie(shimP, cookie);
	 */
	
	// Enable progress UI -- Can Only be called in ShimInit()!!
	shimP->enableProgressUI(shimP, (Char*)"ExampleShim for SDK");
	
	// Try to pop the dialog for stage init
	// Note: Might not been seen since shim stage is too fast.
	//shimP->updateProgressUI(shimP, 0, SHIM_INIT_STAGE);
}

/***********************************************************************
 *
 * FUNCTION:    ShimDeinit
 *
 * DESCRIPTION: De-Initialize the Shim.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimDeinit(IFShim *shimP)
{
	/**
	 * Here we should delete the cookie we allocated
	 * earlier.
	 *
	 * ShimSpecificState *cookie = shimP->getCookie(shimP);
	 * if(cookie != NULL) 
	 * {
	 *	// Free everything
	 *	shimP->setCookie(shimP, NULL);
	 *	shimP->memFree(cookie);
	 * }
	 */
}

/***********************************************************************
 *
 * FUNCTION:    ShimInterfaceIsUp
 *
 * DESCRIPTION: Shim Interface is up.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure 
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimInterfaceIsUp(IFShim *shimP)
{
	shimP->shimIsUp(shimP);
	
/*	// Update the progess dialog
	shimP->updateProgressUI(shimP, 0, SHIM_INTERFACE_IS_UP);
	// Call the VPPI to prompt for User Name
	shimP->promptInProgressUI(shimP);
*/
}  

/***********************************************************************
 *
 * FUNCTION:    ShimInterfaceWillGoDown
 *
 * DESCRIPTION: Shim Interface will go down.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimInterfaceWillGoDown(IFShim *shimP)
{
	shimP->shimIsDown(shimP);
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimIPReceive
 *
 * DESCRIPTION: Called when receiving a packet during an IP connection.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				packetP	- Pointer to a Packet
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimIPReceive(IFShim *shimP, Packet *packetP)
{
	// Simply push the packet on the stack
	shimP->upIPReceive(shimP, packetP);
}

/***********************************************************************
 *
 * FUNCTION:    ShimIPSend
 *
 * DESCRIPTION: Called when sending a packet during an IP connection.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				packetP	- Pointer to a Packet
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimIPSend(IFShim *shimP, Packet *packetP)
{
	// Send the packet to the hardware
	shimP->downIPSend(shimP, packetP);
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimDNSQuerySuccess
 *
 * DESCRIPTION: Called when a DNS query succeeded.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimDNSQuerySuccess(IFShim*   shim,
                         DNSQuery* query,
                         Char*     canonicalName,
                         Int32     numAddrs,
                         INAddr    addrs[],
                         void*     cookie)
{
	shim->updateProgressUI(shim, 0, SHIM_DNSQUERYSUCCESS);
}
/***********************************************************************
 *
 * FUNCTION:    ShimDNSQueryFailure
 *
 * DESCRIPTION: Called when a DNS query failed.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimDNSQueryFailure(IFShim*   shim,
                         DNSQuery* query,
                         DNSError  error,
                         void*     cookie)
{
	shim->updateProgressUI(shim, 0, SHIM_DNSQUERYFAILURE);
}


#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimTCPOnOpen
 *
 * DESCRIPTION: Called when a TCP connection is opening.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				conP	- Pointer to a TCP connection.
 *				cookieP	- Pointer to a cookie.
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimTCPOnOpen(IFShim *shimP, TCPCon *conP, void *cookieP)
{
}

/***********************************************************************
 *
 * FUNCTION:    ShimTCPOnReceive
 *
 * DESCRIPTION: Called when receiving packets during a TCP connection.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				conP	- Pointer to a TCP connection.
 *				packetP	- Pointer to a Packet.
 *				cookieP	- Pointer to a cookie.
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt16 ShimTCPOnReceive(IFShim *shimP, TCPCon *conP, Packet *packetP, void *cookieP)
{
	shimP->packetFree(shimP, packetP);
	return 8*536;
}

/***********************************************************************
 *
 * FUNCTION:    ShimTCPOnTransmit
 *
 * DESCRIPTION: Called when a TCP connection is transmitting packets.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				conP	- Pointer to a TCP connection.
 *				cookieP	- Pointer to a cookie.
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimTCPOnTransmit(IFShim *shimP, TCPCon *conP, void *cookieP)
{
}

/***********************************************************************
 *
 * FUNCTION:    ShimTCPOnRemoteClose
 *
 * DESCRIPTION: Called when a TCP connection is closed remotely.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				conP	- Pointer to a TCP connection.
 *				cookieP	- Pointer to a cookie.
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimTCPOnRemoteClose(IFShim *shimP, TCPCon *conP, void *cookieP)
{
}

/***********************************************************************
 *
 * FUNCTION:    ShimTCPOnClose
 *
 * DESCRIPTION: Called when a TCP connection is closing.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				conP	- Pointer to a TCP connection.
 *				why		- The reason for closing the TCP connection.
 *				cookieP	- Pointer to a cookie 
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimTCPOnClose(IFShim *shimP, TCPCon *conP, TCPCloseReason why, void *cookieP)
{
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimTimerExpiration
 *
 * DESCRIPTION: Called when a timer expires.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *				timerP	- Pointer to a Timer.
 *				cookieP	- Pointer to a cookie.
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimTimerExpiration(IFShim *shimP, Timer *timerP, void *cookieP)
{
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    ShimConfigSettingWasSet
 *
 * DESCRIPTION: Called after config is set by NetLibIFSettingSet.
 *
 * PARAMETERS:	shimP	- Pointer to a IFShim structure
 *
 * RETURNED:	-
 *
 ***********************************************************************/

void ShimConfigSettingWasSet(IFShim *shimP)
{
	UserPassConfig *upc;
	UInt16          upcLen;
	
	shimP->getConfig(shimP, (void*)&upc, &upcLen);
	
	switch(SwapUInt32(upc->type))
	{
		case Config_USERNAME:
			// First time called, the VPPI did set the username
			upc->type    = SwapUInt32(Config_PASSWORD);
			upc->text[0] = '\0';
			// Now we clear the upc text and ask the VPPI to query
			// the password.
			shimP->setConfig(shimP, upc, upcLen);
			shimP->promptInProgressUI(shimP);
			break;
		
		case Config_PASSWORD:
			// The VPPI just got a password
			// Update the progess UI and alert allow the shim to proceed
			shimP->updateProgressUI(shimP, 0, SHIM_CONFIG_WAS_SET);
			shimP->shimIsUp(shimP);
			break;
			
		default:
			break;
	}
}
