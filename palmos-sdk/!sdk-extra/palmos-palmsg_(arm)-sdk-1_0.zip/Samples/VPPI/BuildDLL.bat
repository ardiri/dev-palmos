@echo off
IF NOT EXIST NTSim\Debug MKDIR NTSim\Debug
IF NOT EXIST NTSim\Release MKDIR NTSim\Release

set CFG=Shim - Win32 Debug
nmake VPNShimNTSim.mak

set CFG=Shim - Win32 Release
nmake VPNShimNTSim.mak
