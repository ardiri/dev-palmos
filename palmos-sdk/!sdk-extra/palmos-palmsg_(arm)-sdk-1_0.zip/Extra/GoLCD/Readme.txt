This folder includes the DLLs and PRCs needed to test GoLCD on a Palm Simulator
that doesn't already have GoLCD (E.g. Palm Source Simulator).

Install:

1) Copy the DLL in the PalmSim folder, where the other DLLs are.
2) You can either:
 a- Install the PRCs on the PalmSim and Soft-Reset.
 b- Create an "Autoload" folder where PalmSim.exe is and add the PRCs to this folder.

Use the GoLCD sample code coming with the SDK to enable/disable GoLCD.