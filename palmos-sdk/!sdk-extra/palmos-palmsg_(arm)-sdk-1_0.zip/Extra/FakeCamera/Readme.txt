You can use the fake camera PRC to test the camera library of the Zire 71 on
the NTSimulator. 
The fake camera PRC generates random colors and is updated every second. It
will work only on the Zire 71 simulator.