/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmShim.h
 * @version 1.0
 * @date 	10/28/2002
 *
 * Functions and callbacks for the VPN Shim.
 *
 * Since the VPN Shim is compiled as an ARMlet
 * and doesn't have access to OS calls, the IFSHim
 * structure contains a list of callbacks to control
 * packets and interface with the VPN Panel PlugIn.
 *                                                																																				
 * <hr>                                             																																				
 */
#ifndef PALM_SHIM_H_
#define PALM_SHIM_H_

#include "PalmNative.h"

// Forward declaration
struct         IFShim;
typedef struct IFShim IFShim;

// Common types
typedef UInt32 INAddr;			/**< Internet Adress. */
typedef void * Packet;			/**< Opaque pointer to a packet. */
typedef void * TCPCon;			/**< Opaque pointer to a TCP connection. */
typedef void * DNSQuery;		/**< Opaque pointer to a DNS query. */
typedef void * Timer;			/**< Opaque pointer to a timer. */

/**
 * Shim stages.
 */
typedef enum
{
	ShimStage_UNINSTALLED,		/**< The shim is not installed. */
	ShimStage_INSTALLING,		/**< The shim is being installed. */
	ShimStage_INSTALLED,		/**< The shim is installed. */
	ShimStage_COMING_UP,		/**< The shim interface is coming up. */
	ShimStage_UP,				/**< The shim interface is up. */
	ShimStage_REQUESTED_DOWN, 	/**< The shim interface is asked to come donwn. */ // before NetLibIFMediaDown()
	ShimStage_COMING_DOWN,		/**< The shim interface is coming down. */
	ShimStage_DOWN,				/**< The shim interface is down. */
	ShimStage_UNINSTALLING,		/**< The shim is being uninstalled. */
	ShimStage_FAILED_BUT_IF_LEFT_UP /**< The shim failed to come up, leaving interface up and will bring down shim later. */
	
} ShimStage;


/**
 * TCP structs, enums and callbacks
 */
typedef enum
{
	TCPCloseReason_OK = 1,		/**< The TCP connection was closed normally. */
	TCPCloseReason_RESET,		/**< The TCP connection was closed because of a reset. */
	TCPCloseReason_TIMEOUT,		/**< The TCP connection was closed because it did timeout. */
	TCPCloseReason_UNREACHABLE	/**< The TCP connection was closed because it was unreachable. */
} TCPCloseReason;


/**
 * DNS Query structs, enums and callbacks
 */
typedef enum
{
	DNSError_OK                   =  0,		/**< No error. */
	DNSError_NAME_TOO_LONG        = -1,		/**< The DNS name was too long. */
	DNSError_BAD_NAME             = -2,		/**< The DNS name was a bad name. */
	DNSError_BAD_ARGS             = -3,		/**< One or more arguments to the DNS query were bad. */
	DNSError_LABEL_TOO_LONG       = -4,		/**< The label is too long. */
	DNSError_ALLOCATION_FAILURE   = -5,		/**< Allocation failed. */
	DNSError_TIMEOUT              = -6,		/**< The DNS query timeout. */
	DNSError_UNREACHABLE          = -7,		/**< Unreachable. */
	DNSError_FORMAT               = -8,		/**< Format error. */
	DNSError_SERVER_FAILURE       = -9,		/**< The server failed. */
	DNSError_NONEXISTENT_NAME     = -10,	/**< The DNS name does not exist. */
	DNSError_NIY                  = -11,	/**< DNSError_NIY. */
	DNSError_REFUSED              = -12,	/**< The DNS query was refused. */
	DNSError_IMPOSSIBLE           = -13,	/**< The DNS query was impossible. */
	DNSError_NO_RRS               = -14,	/**< No RRS. */
	DNSError_ABORTED              = -15,	/**< The DNS query was aborted. */
	DNSError_BAD_PROTOCOL         = -16,	/**< The protocal was bad. */
	DNSError_TRUNCATED            = -17,	/**< DNSError_TRUNCATED. */
	DNSError_NO_RECURSION         = -18,	/**< DNSError_NO_RECURSION. */
	DNSError_IRRELEVANT           = -19,	/**< DNSError_IRRELEVANT. */
	DNSError_NOT_IN_LOCAL_CACHE   = -20,	/**< DNSError_NOT_IN_LOCAL_CACHE. */
	DNSError_NO_PORT              = -21		/**< DNSError_NO_PORT. */
  
} DNSError;


/**
 * Log error
 */
typedef enum
{
	LogError_OK,				/**< No error. */
	LogError_NO_LOG_CREATED,	/**< The error log has not been created yet. */
	LogError_INVALID_LENGTH,	/**< The log has an invalid length. */
	LogError_MESSAGE_TOO_LONG	/**< The log message is too long. */
	
} LogError;

//
// Main Shim interface
// Note: Shim clients must implement these functions
//

/**
 * Called when the Shim is initializing.
 *
 * @param	shim	Pointer to IFShim structure.
 */
NATIVE_CODE void   ShimInit(IFShim *shim);

/**
 * Called when the Shim is deinitializing.
 *
 * @param	shim	Pointer to IFShim structure.
 */
NATIVE_CODE void   ShimDeinit(IFShim *shim);

/**
 * Called when the Shim interface is up.
 *
 * @param	shim	Pointer to IFShim structure.
 */
NATIVE_CODE void   ShimInterfaceIsUp(IFShim *shim);

/**
 * Called when the Shim interface will go down.
 *
 * @param	shim	Pointer to IFShim structure.
 */
NATIVE_CODE void   ShimInterfaceWillGoDown(IFShim *shim);

//
// IP callbacks to shim
//

/**
 * Called when an IP packet is received.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	packet	Pointer to a packet.
 */
NATIVE_CODE void   ShimIPReceive(IFShim *shim, Packet *packet);

/**
 * Called when an IP packet is going to be sent.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	packet	Pointer to a packet.
 */
NATIVE_CODE void   ShimIPSend(IFShim *shim, Packet *packet);

//
// TCP callbacks to shim
//

/**
 * Called when a TCP connection is being opened.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	con		Pointer to TCP connection.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimTCPOnOpen(IFShim *shim, TCPCon *con, void *cookie);

/**
 * Called when a TCP packet is received.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	con		Pointer to TCP connection.
 * @param	packet	Pointer to a packet.
 * @param	cookie	Pointer to a cookie.
 *
 * @return	The new size of the receive window. This is usually a constant.
 */
NATIVE_CODE UInt16 ShimTCPOnReceive(IFShim *shim, TCPCon *con, Packet *packet, void *cookie);

/**
 * Called when 
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	con		Pointer to TCP connection.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimTCPOnTransmit(IFShim *shim, TCPCon *con, void *cookie);

/**
 * Called when a TCP connection is being closed remotely.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	con		Pointer to TCP connection.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimTCPOnRemoteClose(IFShim *shim, TCPCon *con, void *cookie);

/**
 * Called when a TCP connection is being closed.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	con		Pointer to TCP connection.
 * @param	why		The reason for closing the connection.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimTCPOnClose(IFShim *shim, TCPCon *con, TCPCloseReason why, void *cookie);

//
// DNS callbacks to shim
//

/**
 * Called when a DNS Query succeeded.
 *
 * @param	shim			Pointer to IFShim structure.
 * @param	query			Pointer to a DNSQuery.
 * @param	canonicalName	Pointer to the canonical name.
 * @param	numAddrs		Number of INAddr contained in addrs.
 * @param	addrs			Array of INAddr.
 * @param	cookie			Pointer to a cookie.
 */
NATIVE_CODE void   ShimDNSQuerySuccess(IFShim 	*shim,
									   DNSQuery *query,
									   Char 	*canonicalName,
									   Int32     numAddrs,
									   INAddr    addrs[],
									   void 	*cookie);
									   
/**
 * Called when a DNS Query failed.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	query	Pointer to a DNSQuery.
 * @param	error	Reason for the failure.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimDNSQueryFailure(IFShim 	*shim,
									   DNSQuery *query,
									   DNSError  error,
									   void 	*cookie);


/**
 * Called when a timer expires.
 *
 * @param	shim	Pointer to IFShim structure.
 * @param	timer	Pointer to a Timer.
 * @param	cookie	Pointer to a cookie.
 */
NATIVE_CODE void   ShimTimerExpiration(IFShim *shim,
									   Timer  *timer,
									   void   *cookie);

/**
 * Called after config is set by NetLibIFSettingSet.
 *
 * @param	shim	Pointer to IFShim structure.
 */
NATIVE_CODE void   ShimConfigSettingWasSet(IFShim *shim);

/**
 * @brief IFShim Sturcture.
 *
 * This structure is passed to the Shim functions and contains
 * a list of useful function pointers. Since the functions are
 * written as ARMlets, you cannot call directly ARM library functions.
 */ 
typedef struct IFShim
{
	/**
	 * Get the current Shim stage.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The current Shim stage.
	 */
	ShimStage	(*getShimStage)(IFShim *shimP);
	
	/**
	 * Allow underlying driver to proceed.
	 * This should be called when the Shim interface is up
	 * or soon after.
	 *
	 * @param		shimP	Pointer to IFShim structure.
	 */
	void		(*shimIsUp)(IFShim *shimP);
	
	/**
	 * Allow underlying driver to proceed.
	 * This should be called when the Shim interface is going down.
	 *
	 * @param		shimP	Pointer to IFShim structure.
	 */
	void		(*shimIsDown)(IFShim *shimP);
	
	/**
	 * Get the current header length.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The current header length.
	 */
	UInt16		(*getHeaderLen)(IFShim *shimP);
	
	/**
	 * Set the header length.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	len		The new header length.
	 */
	void		(*setHeaderLen)(IFShim *shimP, UInt16 len);
	
	/**
	 * Get the current MTU size.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The current MTU size.
	 */
	UInt16		(*getMTU)(IFShim *shimP);
	
	/**
	 * Set the MTU size.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The new MTU size.
	 */
	void		(*setMTU)(IFShim *shimP, UInt16 mtu);
	
	/**
	 * Get the IP address.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The current IP address.
	 */
	INAddr		(*getIPAddr)(IFShim *shimP);
	
	/**
	 * Get the subnet mask.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The subnet mask.
	 */
	INAddr		(*getSubnetMask)(IFShim *shimP);
	
	/**
	 * Get the broadcast address.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The broadcast address.
	 */
	INAddr		(*getBroadcastAddr)(IFShim *shimP);
	
	/**
	 * Get the Hardware (MAC) address length.
	 * Use in conjunction with getHWAddr.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	The length of the address.
	 */
	Int16		(*getHWAddrLen)(IFShim *shimP);
	
	/**
	 * Get the Hardware (MAC) address.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	A pointer to the Hardware address.
	 */
	UInt8*		(*getHWAddr)(IFShim *shimP);
	
	/**
	 * Get the cookie associated with the shim.
	 * This is used as a pseudo-global. This pointer
	 * can be retieved from anywhere is the ARMlet.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	A pointer to the cookie.
	 */
	void*		(*getCookie)(IFShim *shimP);
	
	/**
	 * Set the cookie associated with the shim.
	 * A cookie is usually a piece of memory allocated
	 * with the memAlloc() function.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	cookieP	Pointer to the cookie.
	 */
	void		(*setCookie)(IFShim *shimP, void *cookieP);
	
	/**
	 * Allocate a Packet.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	len		The size of the packet.
	 * @return	A pointer to the packet.
	 */
	Packet*		(*packetAlloc)(IFShim *shimP, UInt16 len);
	
	/**
	 * Delete a Packet.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	packetP	Pointer to the packet to free.
	 */
	void		(*packetFree)(IFShim *shimP, Packet *packetP);
	
	/**
	 * Return a pointer to the data section of the packet.
	 * Use with packetGetDataLenPtr() to determine the length of the data section.
	 *
	 * @param	packetP	Pointer to a packet.
	 * @return	A pointer to the data section of the packet.
	 */
	UInt8**		(*packetGetDataPtr)(Packet *p);
	
	/**
	 * Returns a pointer to the data section length of a packet.
	 *
	 * @param	packetP	Pointer to a packet.
	 * @return	A pointer to the data section length of a packet.
	 */
	UInt32*		(*packetGetDataLenPtr)(Packet *p);
	
	/**
	 * Allocate a timer.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @return	A pointer to the newly allocated timer.
	 */
	Timer*		(*timerAlloc)(IFShim *shimP);
	
	/**
	 * Delete a timer.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	timerP	A pointer to a timer.
	 */
	void		(*timerFree)(IFShim *shimP, Timer *timerP);
	
	/**
	 * Set a timer delay.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	timerP	Pointer to a timer.
	 * @param	msDelay	The timer delay.
	 * @param	cookieP	Pointer to the cookie.
	 */
	void		(*timerSet)(IFShim *shimP, Timer *timerP, UInt32 msDelay, void *cookieP);
	
	/**
	 * Cancel a timer.
	 * If a timer delay was set, it cancels it.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	timerP	Pointer to a timer.
	 */
	void		(*timerCancel)(IFShim *shimP, Timer *timerP);
	
	/**
	 * Get the current date.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	secondP	Pointer to the seconds.
	 * @param	minuteP	Pointer to the minutes.
	 * @param	hourP	Pointer to the hours.
	 * @param	dayP	Pointer to the days.
	 * @param	monthP	Pointer to the months.
	 * @param	yearP	Pointer to the years.
	 * @param	weekDayP	Pointer to the starting week day.
	 */
	void		(*getDateTime)(	IFShim *shimP,
								Int16 *secondP,
								Int16 *minuteP,
								Int16 *hourP,
								Int16 *dayP,
								Int16 *monthP,
								Int16 *yearP,
								Int16 *weekDayP);
								
	/**
	 * Get the current system ticks.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	ticksP	Pointer to the current system ticks value.
	 * @param	ticksPerSecondP	Pointer to the number of ticks per second.
	 */
	void		(*getTicks)(IFShim *shimP,
							UInt32 *ticksP,
							UInt32 *ticksPerSecondP);
							
	// yield functions
	void		(*yield)(IFShim *shimP);
	
	/**
	 * Pass received and processed packet upward to stack.
	 * This is usually called in the ShimIPReceive() function.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	packetP	Pointer to a packet.
	 */
	void		(*upIPReceive)(IFShim *shimP, Packet *packetP);
	
	/**
	 * Pass sent and processed packet downward to physical interface.
	 * This is usually called in the ShimIPSend() function.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	packetP	Pointer to a packet.
	 */
	void		(*downIPSend)(IFShim *shimP, Packet *p);
	
	/**
	 * Allocate a TCP packet.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	length	Length o fthe packet.
	 * @return	A pointer to teh newly allocated packet.
	 */
	Packet*		(*tcpAlloc)(IFShim *shimP, UInt16 length);
	
	/**
	 * Free a TCP packet.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	packetP	Pointer to a packet.
	 */
	void		(*tcpFree)(IFShim *shimP, Packet *packetP);
	
	/**
	 * Write a TCP packet to the TCP connection.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	conP	Pointer to a TCP connection.
	 * @param	packetP	Pointer to a packet.
	 * @return	???
	 */
	Int16		(*tcpWrite)(IFShim *shimP, TCPCon *con, Packet *packetP);
	
	/**
	 * Close a TCP connection.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	conP	Pointer to a TCP connection.
	 * @param	abortUngracefully	If true, close the connection right away.
	 */
	void		(*tcpClose)(IFShim *shimP, TCPCon *conP, Boolean abortUngracefully);
	
	/**
	 * Set the receive window for the TCP connection.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	conP	Pointer to a TCP connection.
	 * @param	len		The window length.
	 */
	void		(*tcpSetReceiveWindow)(IFShim *shimP, TCPCon *conP, UInt16 len);
	
	/**
	 * Open a TCP connection.
	 *
	 * @param	shimP		Pointer to IFShim structure.
	 * @param	remoteAddr	The remote Internet Address.
	 * @param	remotePort	The remote connection port.
	 * @param	localPort	The local connection port.
	 * @param	window		The window length for this connection.
	 * @param	cookieP		Pointer to a cookie.
	 * @return	The new TCP connection.
	 */
	TCPCon*		(*tcpActiveOpen)(	IFShim *shimP,
									INAddr  remoteAddr,
									UInt16  remotePort,
									UInt16  localPort,
									UInt16  window,
									void   *cookieP);
									
	/**
	 * Set the primary DNS address.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	dnsAddr	Primary DNS address.
	 */
	void		(*setPrimaryDNS)(IFShim *shimP, INAddr dnsAddr);
	
	/**
	 * Set the secondary DNS address.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	dnsAddr	Secondary DNS address.
	 */
	void		(*setSecondaryDNS)(IFShim *shimP, INAddr dnsAddr);
	
	/**
	 * Set the domain name.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	domainNameStr	Domain name string. Must be null terminated.
	 */
	void		(*setDomainName)(IFShim *shimP, Char *domainNameStr);
	
	/**
	 * Abort a DNS quyery.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	queryP	Pointer to the query to abort..
	 */
	void		(*dnsAbortQuery)(IFShim *shimP, DNSQuery *queryP);
	
	/**
	 * Create a DNS query.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	nameP	Pointer to the name to query.
	 * @param	cookieP	Pointer to a cookie.
	 * @return	A DNS query.
	 */
	DNSQuery*	(*dnsNameToAddr)(IFShim *shimP, Char *nameP, void *cookieP);
									
	/**
	 * Get a string given an error from the Shim log database.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	error	The error to look for.
	 * @param	strBuf	Pointer to a string to fill.
	 * @param	maxStrLen	Maximum length of the string.
	 */
	void		(*dbGetStringByError)(	IFShim *shimP,
										Int16   error,
										Char   *strBuf,
										UInt16  maxStrLen);
										
	/**
	 * Get a string given an index from the Shim log database.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	index	The index to look for.
	 * @param	strBuf	Pointer to a string to fill.
	 * @param	maxStrLen	Maximum length of the string.
	 */
	void		(*dbGetStringByIndex)(	IFShim *shimP,
										Int16   index,
										Char   *strBuf,
										UInt16  maxStrLen);
										
	/**
	 * Appends a message to log used by Network Panel.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	msg		String to append to the log.
	 */
	void		(*sysLogAppend)(IFShim *shimP, Char *msg);
	
	/**
	 * Create a log record.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	logLength	Length of the record.
	 */
	LogError	(*logCreate)(IFShim*, UInt16 logLength);
	
	/**
	 * Append a message to the current log record.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	msg		String to append to the log.
	 */
	LogError	(*logAppend)(IFShim *shimP, Char *msg);
	
	// config info - Don't touch this!
	void		(*getConfig)(IFShim *shim, void* *config, UInt16 *configLen);
	void		(*setConfig)(IFShim *shim, void * config, UInt16  configLen);
	
	/**
	 * Enable the progress dialog.
	 * This function succeed only if the shim is in INIT stage.
	 * (E.g. Call it in ShimInit())
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	title	Title of the dialog.
	 */
	void		(*enableProgressUI)(IFShim *shimP, Char *title);
	
	/**
	 * Update the progress dialog.
	 * The stage parameter is specific to the VPPI and Shim. It
	 * is up to developers to select a values.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	err		Set the error if an error occured, otherwise set to errNone.
	 * @param	stage	The stage value to send to the progress paint in the VPPI.
	 */
	void		(*updateProgressUI)(IFShim *shimP, UInt16 err, UInt16 stage);
	
	/**
	 * Call the VPPI wit the SysVPPILaunchCmdPromptAndConfigureType launch flag.
	 * This is used to prompt a user for password... 
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 */
	void		(*promptInProgressUI)(IFShim *shim);
	
	/**
	 * Allocate memory. 
	 *
	 * @param	size	Allocate memory.
	 * @return	Pointer to the newly allocated memory.
	 */
	void*		(*memAlloc)(UInt16 size);
	
	/**
	 * Free memory. 
	 *
	 * @param	memPtr	Pointer to the memory to free.
	 */
	void		(*memFree)(void *memPtr);
	
	/**
	 * Convert a name to an Internet Address. 
	 *
	 * @param	addrStr	String to convert.
	 * @return	An INAddr on success, -1 on failure.
	 */
	INAddr		(*inetAtoI)(Char *addrStr);
	
	/**
	 * Convert an Internet Address to a name.
	 *
	 * @param	addr	Internet Address.
	 * @param	addrBug	Pointer to the string to convert to.
	 * @return	Pointer to the name string.
	 */
	Char*		(*inetItoA)(INAddr addr, Char *addrBuf);
	
	//
	// Experimental debug routines - Use at your own risk
	//
	void		(*dbgScreen)(UInt32 id, UInt32 val);
	void		(*dbgString)(const Char *s);         // use CAREFULLY!!!
	void		(*dbgPause)(Int32 ticks);            // like SysTaskDelay
	
	void		(*traceSD)(UInt32 id, UInt32 val);   // like dbgScreen
	void		(*writeSD)(const Char *s);           // like dbgString
	void		(*writelnSD)(const Char *s);         // like dbgString
	
	Char*		(*strAdjust)(IFShim *shim, Char *s);
	void*		(*pfnAdjust)(IFShim *shim, void *pfn);
	
	//
	// Version string
	//
	void		(*getVersion)(IFShim *shim, Char *versionStr, UInt16 bufLen);
	void		(*setVersion)(IFShim *shim, Char *versionStr);
	
	
	/**
	 * Get settings of shim and underlying interface
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	setting	Same as the NetLibIF setting.
	 * @param	valueP	Pointer to the value to pass.
	 * @param	valueLenP	Pointer to the length of the valueP parameter.
	 *
	 * @return	Error code.
	 */
	Err			(*ifSettingGet)(IFShim *shimP, UInt16 setting, void *valueP, UInt16 *valueLenP);
	
	/**
	 * Set settings of shim and underlying interface
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 * @param	setting	Same as the NetLibIF setting.
	 * @param	valueP	Pointer to the value to pass.
	 * @param	valueLen	Length of the valueP parameter.
	 *
	 * @return	Error code.
	 */
	Err			(*ifSettingSet)(IFShim *shimP, UInt16 setting, void *valueP, UInt16  valueLen);
	
	/**
	 * Get the auto-off timeout in seconds.
	 *
	 * @return The auto-off timeout.
	 */
	UInt16		(*getAutoOffTimeoutSecs)();
	
	/**
	 * Reset the auto-off timer.
	 */
	void		(*resetAutoOffTimer)();
	
	// Opaque shim state - Don't use this!
	void *opaque;
	
	/**
	 * This will place the shim into the 'FAILED_BUT_IF_LEFT_UP' stage and sent
	 * and received shim->shim->packets will be routed around the shim.
	 * The shim will not receive a ShimInterfaceWillGoDown() call until
	 * the interface is brought down at some future time.
	 * Right before the ShimInterfacaeWillGoDown() the shim's stage is 
	 * changed back to 'COMING_DOWN' and you *will*, once again, see any
	 * traffic sent or received so you should just pass it on probably
	 * like you are today (obviously you shouldn't initiate your shut down
	 * communication behaviors).
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 */
	void          (*shimIsDownLeaveIFUp)(IFShim *shimP);
	
	/**
	 * If the progress UI is enabled *at that instant* returns true. To
	 * clarify, the progress UI is not enabled while the shim is being
	 * initialized.  Typically, it's only enabled after the underlying
	 * interface has completed its connection.  This happens some short
	 * amount of time *after* ShimInterfaceIsUp().
	 * Additionally, an application can 'veto' the display of the progress
	 * UI by setting netIFSettingShimHideProgress equal to true on an
	 * interface that is wrapped by a shim.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 */
	Boolean       (*isProgressUIEnabled)(IFShim *shimP);
	
	/**
	 * Clear the DNS cache.
	 *
	 * @param	shimP	Pointer to IFShim structure.
	 */ 
	void          (*dnsClearCache)(IFShim *shimP);
	
	/**
	 * Returns the current version of the VPNShim library.  See the 
	 * sysMakeROMVersion macro for how to interpret this UInt32.
	 * The version double-word can also be fetched by getting the setting
	 * netIFSettingShimLibVersion.
	 *
	 * @return The current version of the VPNShim library.
	 */
	UInt32        (*getShimLibVersion)();
  
} IFShim;


#endif // PALM_SHIM_H_

