/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmSoundCustomCtrl.h
 * @version 1.0
 * @date 	03/04/2003
 *
 * Header file for the sound manager custom controls.
 *
 * <hr>
 */

#ifndef __PALMSOUNDCUSTOMCTRL_H__
#define __PALMSOUNDCUSTOMCTRL_H__

/********************************************************************
 * Custom Control for the IMA_ADPCM codec
 ********************************************************************/

#define	codecDriverIMAADPCM					'APCM'	/**< IMA ADPCM codec driver. */
#define	codecIMAADPCMSetBlockSize			0x0001	/**< IMA ADPCM block size set command. */

enum {
    sndControlCodecCustomControl = 12	/**< Param is a SndCodecCustomControlType*. */
};

/**
 * @brief Custom control type for the extended sound manager.
 *
 * This codec is used to set/get values specific to a codec.
 * Note that if this custom control comes from a 68K app, it's the responsibility
 * of the 68K app to flip and align the fields of the structure correctly (the fields
 * are defined as being in little-endian format).
 */
typedef struct {
	UInt32	apiCreator;		/**< The codec creator. (codecDriverIMAADPCM...) */
	UInt32	apiSelector;	/**< The codec selector. (codecIMAADPCMSetBlockSize...) */
	void	*valueP;		/**< Pointer to the parameters to be passed to the codec. */
	UInt16	*valueLenP;		/**< Size of the parameters to be passed to the codec. */
} SndCodecCustomControlType;

/***
 * How to use the IMA_ADPCM code custom control:
 *
 * When you create a stream, make sure you set the format to sndFormatIMA_ADPCM and
 * that the type is set to 0.
 *
 * Then use the custom control to set the block align  paramter:
 *
 * SndCodecCustomControlType ct;
 * UInt16 blockAlign= Swap16(blockAlign); // This needs to be in little endian
 * ct.apiCreator	= Swap32(codecDriverIMAADPCM);
 * ct.apiSelector	= Swap32(codecIMAADPCMSetBlockSize);
 * ct.valueP		= (void*)Swap32(&blockAlign);
 * ct.valueLenP		= NULL;
 * err = SndStreamDeviceControl(streamRef, sndControlCodecCustomControl, &ct, sizeof(ct));
 *
 */
 
#endif // __PALMSOUNDCUSTOMCTRL_H__

