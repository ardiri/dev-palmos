/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmNetServices.h
 * @version 1.0
 * @date 	10/28/2002
 *
 * NetServices provides a set of API to access 802.11.
 *
 * <hr>
 */
 
#ifndef PALM_NETSERVICES_H__
#define PALM_NETSERVICES_H__

#include <LibTraps.h>


/********************************************************************
 * Traps
 ********************************************************************/
#define NetServicesLibTrapGetHWAddr			(sysLibTrapCustom+0)
#define NetServicesLibTrapStartScan			(sysLibTrapCustom+1)
#define NetServicesLibTrapGetScanResults	(sysLibTrapCustom+2)
#define NetServicesLibTrapGetChannel		(sysLibTrapCustom+3)
#define NetServicesLibTrapGetPowerState		(sysLibTrapCustom+4)
#define NetServicesLibTrapGetCommsQuality	(sysLibTrapCustom+5)
#define NetServicesLibTrapSetRadioState		(sysLibTrapCustom+6)
#define NetServicesLibTrapGetRadioState		(sysLibTrapCustom+7)
#define NetServicesLibTrapGetDeviceInfo		(sysLibTrapCustom+10)
#define NetServicesLibTrapGetChannelList	(sysLibTrapCustom+11)

#define NetServicesLibTrapProfileGetInfo	(sysLibTrapCustom+0x10)
#define NetServicesLibTrapProfileRead		(sysLibTrapCustom+0x11)
#define NetServicesLibTrapProfileWrite		(sysLibTrapCustom+0x12)
#define NetServicesLibTrapProfileAdd		(sysLibTrapCustom+0x13)
#define NetServicesLibTrapProfileDelete		(sysLibTrapCustom+0x14)
#define NetServicesLibTrapProfileSetOrder	(sysLibTrapCustom+0x15)
#define NetServicesLibTrapProfileGetOrder	(sysLibTrapCustom+0x16)
#define NetServicesLibTrapProfileFind		(sysLibTrapCustom+0x17)




/********************************************************************
 * Library type and creator
 ********************************************************************/
 
#define ShlLibName		"NetServLib"	/**< PalmNetServices library name. */
#define ShlCreatorID	'NETs'			/**< PalmNetServices creator ID. */
#define ShlLibType		'libr'			/**< PalmNetServices library type. */


/********************************************************************
 * Typedefs and constants for the device information returned from
 * NetServicesGetDeviceInfo.
 ********************************************************************/

#define kNetDriverDateLength	16		/**< Length for the driver date info string. */
#define kNetFWNameLength		16		/**< Length for the firmware name info string. */
#define kNetSerialNumberLength	16		/**< Length for the serial number info string. */

/**
 * @brief  Device information concerning Hardware and Firmware information for the "adapter". 
 *
 * Revision information and product name data is returned.
 */
typedef struct Net80211DeviceInfo
{
	UInt32		validFlags;								/**< Bit flag indicating validity of fields. */
	UInt32		fwRev[2];								/**< Firmware revision. STA/BB (32 bits), PRI/MAC (32 bits). Valid is (validFlags & 1) == 1.*/
	Int32		serialNumberSize;						/**< Serial number size. Valid is (validFlags & 8) == 1. */
	UInt8		serialNumber[kNetSerialNumberLength];	/**< Serial number. Valid is (validFlags & 8) == 1. */
	Char		driverDate[kNetDriverDateLength];		/**< Driver date. Valid is (validFlags & 2) == 1. */
	Char		fwName[kNetFWNameLength];				/**< Firmware name. Valid is (validFlags & 4) == 1. */
} Net80211DeviceInfo, *Net80211DeviceInfoP;


/**
 * @brief Data returned from NetServicesProfileGetInfo.
 */
typedef struct NetServicesProfileInfo
{
	UInt16	profileRev;			/**< Revision of profile database. */
	UInt16	numProfiles;		/**< Number of profiles contained in the database. */
	UInt16	profileEntrySize;	/**< Size of each individual profile entry. */
} NetServicesProfileInfo, *NetServicesProfileInfoP;

/**
 * @brief Profile entries for SmartConnect
 */
typedef struct NetServicesProfile
{
	Char	profileName[32];	/**< ASCII string - profile reference. */
	UInt8	SSID[32];			/**< SSID associated with this profile. */
	UInt32	ssidLength;			/**< Length of bytes of the SSID. */
	UInt16	ipAllocType;		/**< DHCP/STATIC/IPIPA. */
	UInt16	preambleType;		/**< Long or short preamble. */
	UInt16	keyIndex;			/**< WEP key index.  Only valid if wep active. */
	UInt16	authentication;		/**< OPEN / 64 bit / 128 bit. */
	UInt32	opMode;				/**< BSS, IBSS. */
	UInt32	channel;			/**< DS Channel.  Only used for ad-hoc. */
	UInt32	reqIP;				/**< Static IP address. */
	UInt32	ipMask;				/**< IP mask. */
	UInt32	ipGateway;			/**< IP gateway. */
	UInt32	ipPrimaryDNS;		/**< IP primary DNS. */
	UInt32	ipSecondaryDNS;		/**< IP secondary DNS. */
	UInt8	wep[4][16];			/**< WEP keys. Up to 5 keys. */
	UInt8	dhcpRequestDNS;		/**< 0 = DNS info static, 1 = DNS from DHCP. */
} NetServicesProfile, *NetServicesProfileP;



/********************************************************************
 * Priority order information
 ********************************************************************/

#define MAX_ACTIVE_PROFILES		32		/**< Maximum number of profiles. */
#define END_OF_LIST				0xFFFF	/**< End of list marker. */
#define PRIORITY_LIST_SIZE		(sizeof(UInt16) * (MAX_ACTIVE_PROFILES + 1)) /**< Priority list size. */
#define INVALID_INDEX			0xFFFF	/**< Invalid index tag. */

/**
 * @brief Priority order to smart connect.
 *
 * Provided for ease of reference.
 */
typedef struct NetServicesProfileOrder
{
	UInt16	order[MAX_ACTIVE_PROFILES+1];	/**< Array of order for each active profiles. */
} NetServicesProfileOrder, *NetServicesProfileOrderP;

/********************************************************************
 * Prototypes
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * Gets the HW address (i.e. MAC address) for the interface
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	hwAddrP		Pointer to store MAC address in.
 *						Must be 6 bytes in length.
 *
 * @return	Error code.
 */
Err NetServicesGetHWAddr( UInt16 libRefNum, UInt8 *hwAddrP )
				SYS_TRAP(NetServicesLibTrapGetHWAddr);

/**
 * Inititate a BSS scan.
 * The scan completes by broadcasting a notification of
 * type WIFI_SCAN_COMPLETE_EVENT.
 * 
 * @param  	libRefNum	Reference number of the library.
 *
 * @return	Error code.
 */
Err NetServicesStartScan( UInt16 libRefNum )
				SYS_TRAP(NetServicesLibTrapStartScan);

/**
 * Retreives scan results from a recent request for a  BSS scan.
 * The caller can determine the amount of data available by passing
 * a NULL pointer and a zero size for the buffer. The network device
 * driver will return the space required to store the result.
 * 
 * @param  	libRefNum		Reference number of the library.
 * @param	scanResultsP	Pointer to storage area which will
 *							hold the BSS scan data.
 * @param	scanBufSizeP	Pointer to variable which holds the
 *							size of the buffer.  Also used as
 *							output to determine size of results.
 *
 * @return	Error code.
 */
Err NetServicesGetScanResults( UInt16 libRefNum, UInt8 *scanResultsP, UInt32 *scanBufSizeP )
				SYS_TRAP(NetServicesLibTrapGetScanResults);
	
/**
 * Retreives the current channel number being used by the adapter.
 * The exact method to get this data is determined by the adapter driver.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	channelP	Pointer to storage area to store current
 *						channel number.
 *
 * @return	Error code.
 */
Err NetServicesGetChannel( UInt16 libRefNum, UInt16 *channelP )
				SYS_TRAP(NetServicesLibTrapGetChannel);
	
/**
 * Retreives the current mode (i.e. DSS, Freq. Hop) being  used
 * by the adapter.  The exact method to get this data is determined
 * by the adapter driver.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	stateP		Pointer to storage area to store current mode.
 *
 * @return	Error code.
 */
Err NetServicesGetPowerState( UInt16 libRefNum, UInt16 *stateP )
				SYS_TRAP(NetServicesLibTrapGetPowerState);

/**
 * Retreives the comms quality from the driver / firmware.
 * The comms quality is the signal strength and quality.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	strengthP	Pointer to storage area to store signal strength.
 * @param	qualityP	Pointer to storage area for signal quality.
 *
 * @return	Error code.
 */
Err NetServicesGetCommsQuality( UInt16 libRefNum, UInt8 *strengthP, UInt8 *qualityP )
				SYS_TRAP(NetServicesLibTrapGetCommsQuality);

/**
 * Enables/disable the radio at the driver.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	radioState	Boolean value indicating on/off.
 *
 * @return	Error code.
 */
Err NetServicesSetRadioState( UInt16 libRefNum, UInt32 radioState )
				SYS_TRAP(NetServicesLibTrapSetRadioState);

/**
 * Returns current status of the radio (0 = disabled, 1 = enabled).
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	radioStateP	Pointer to storage area for the radio status.
 *
 * @return	Error code.
 */
Err NetServicesGetRadioState( UInt16 libRefNum, UInt32 *radioStateP )
				SYS_TRAP(NetServicesLibTrapGetRadioState);
	
/**
 * Queries the Firmware on the 802.11 chipset for revision and status info.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	infoP		Pointer to storage area for the firmware info.
 *
 * @return	Error code.
 */
Err NetServicesGetDeviceInfo( UInt16 libRefNum, Net80211DeviceInfoP infoP )
				SYS_TRAP(NetServicesLibTrapGetDeviceInfo);

/**
 * Retrieves the allowed channel list from the device driver.
 * Used for regulatory domain control.  The channel list is a 16 bit,
 * bit significant field with each bit indicating the channel + 1
 * (i.e. bit 0 = CHN1).
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	channelListP	Pointer to storage area for the channel list.
 *
 * @return	Error code.
 */
Err NetServicesGetChannelList( UInt16 libRefNum, UInt16 *channelListP )
				SYS_TRAP(NetServicesLibTrapGetChannelList);

/**
 * Provides information about the current profile database and profile manager.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	infoP		Pointer to storage area where the info will be stored.
 *
 * @return	Error code.
 */
Err NetServicesProfileGetInfo( UInt16 libRefNum, NetServicesProfileInfoP infoP )
				SYS_TRAP(NetServicesLibTrapProfileGetInfo);
	
/**
 * Reads the specified record from the database.  The index is verified
 * first and then the data read into the user space.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	profIndex	Profile index number.
 * @param	profileP	Pointer to area where the profile will be read.
 *
 * @return	Error code.
 */
Err NetServicesProfileRead( UInt16 libRefNum, UInt16 profIndex, NetServicesProfileP profileP )
				SYS_TRAP(NetServicesLibTrapProfileRead);

/**
 * Updates the content of the specified record.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	profIndex	Record index number.
 * @param	profileP	Pointer to profile data to be written to the database.
 *
 * @return	Error code.
 */
Err NetServicesProfileWrite( UInt16 libRefNum, UInt16 profIndex, NetServicesProfileP profileP )
				SYS_TRAP(NetServicesLibTrapProfileWrite);

/**
 * Deletes/removes the specified record from the database.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	profIndex	Profile index number.
 *
 * @return	Error code.
 */
Err NetServicesProfileDelete( UInt16 libRefNum, UInt16 profIndex )
				SYS_TRAP(NetServicesLibTrapProfileDelete);

/**
 * Adds a new record to the end of the profiles database.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	profileP	Pointer to new profile entry.
 *
 * @return	Error code.
 */
Err NetServicesProfileAdd( UInt16 libRefNum, NetServicesProfileP profileP )
				SYS_TRAP(NetServicesLibTrapProfileAdd);

/**
 * Requests to update the priority order of the profiles.
 * The routine verifies all the profile entries exist and
 * then updates the profile header with the info.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	orderP		Pointer to new priority list.
 *						Must be terminated by END_OF_LIST (0xFFFF).
 *
 * @return	Error code.
 */
Err NetServicesProfileSetOrder( UInt16 libRefNum, NetServicesProfileOrderP orderP )
				SYS_TRAP(NetServicesLibTrapProfileSetOrder);

/**
 * Requests to retreive the current priority order to the SmartConnect.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	orderP		Pointer to storage area where the list will be stored.
 *
 * @return	Error code.
 */
Err NetServicesProfileGetOrder( UInt16 libRefNum, NetServicesProfileOrderP orderP )
				SYS_TRAP(NetServicesLibTrapProfileGetOrder);

/**
 * Searches through the records in the database for the specified
 * profile name.  If the profile exists, the index is returned to
 * the caller. A value of INVALID_INDEX indicates the profile was not found.
 * 
 * @param  	libRefNum	Reference number of the library.
 * @param	profNameP	Pointer to storage area where the list will be stored.
 *
 * @return	Error code.
 */
Err NetServicesProfileFind( UInt16 libRefNum, Char *profNameP )
				SYS_TRAP(NetServicesLibTrapProfileFind);


#ifdef __cplusplus 
}
#endif
	
#endif // PALM_NETSERVICES_H__
