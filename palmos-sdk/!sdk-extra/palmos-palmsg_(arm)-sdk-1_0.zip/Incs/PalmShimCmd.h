/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmShimCmd.h
 * @version 1.0
 * @date 	10/28/2002
 *
 * Functions and callbacks for net Shims.
 * A shim main entry point must match the definition
 * of ShimProc(). ShimProc() will then call the right
 * function depending on the ShimCmdType parameter.
 * The ShimCmdType also defines witch structure should
 * be used. For example, ShimCmd_INIT means that the
 * cmdP points to an 'init' structure.
 *
 * <hr>
 */
#ifndef PALM_SHIMCMD_H_
#define PALM_SHIMCMD_H_

#include "PalmNative.h"
#include "PalmShim.h"

/**
 * @brief Shim command types.
 *
 * This type is used in conjecture of a ShimCmd in order
 * to know which Shim structure is pointed by a generic ShimCmd pointer.
 */
typedef enum
{
	// Downcalls to shim
	ShimCmd_INIT,				/**< ShmCmd is an init stucture. */
	ShimCmd_DE_INIT,			/**< ShmCmd is a deinit stucture. */
	ShimCmd_IFACE_IS_UP,		/**< ShmCmd is a interfaceIsUp stucture. */
	ShimCmd_IFACE_WILL_GO_DOWN,	/**< ShmCmd is an interfaceWillGoDown stucture. */
	ShimCmd_IP_RECEIVE,			/**< ShmCmd is an ipReceive stucture. */
	ShimCmd_IP_SEND,			/**< ShmCmd is an ipSend stucture. */

	// TCP callbacks to shim
	ShimCmd_TCP_ON_OPEN,		/**< ShmCmd is a tcpOnOpen stucture. */
	ShimCmd_TCP_ON_RECEIVE,		/**< ShmCmd is a tcpOnReceive stucture. */
	ShimCmd_TCP_ON_TRANSMIT,	/**< ShmCmd is a tcpOnTransmit stucture. */
	ShimCmd_TCP_ON_REMOTE_CLOSE,/**< ShmCmd is a tcpOnRemoteClose stucture. */
	ShimCmd_TCP_ON_CLOSE,		/**< ShmCmd is a tcpOnClose stucture. */

	// DNS callbacks to shim
	ShimCmd_DNS_QUERY_SUCCESS,	/**< ShmCmd is a dnsQuerySuccess stucture. */
	ShimCmd_DNS_QUERY_FAILURE,	/**< ShmCmd is a dnsQueryFailure stucture. */

	// Timer callback to shim
	ShimCmd_TIMER_EXPIRATION,	/**< ShmCmd is a timerExpiration stucture. */

	// Config setting callback
	ShimCmd_CONFIG_SETTING_WAS_SET	/**< ShmCmd is a configSettingWasSet stucture. */

} ShimCmdType;

/**
 * @brief Shim Command.
 *
 * Interface to the Shim.
 */
typedef union
{
	/**
	 * Init structure.
	 * Used when the ShimCmdType is set to ShimCmd_INIT.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
	} init;
	
	/**
	 * Denit structure.
	 * Used when the ShimCmdType is set to ShimCmd_DE_INIT.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
	} deinit;
	
	/**
	 * InterfaceIsUp structure. 
	 * Used when the ShimCmdType is set to ShimCmd_IFACE_IS_UP.
	 */
	 struct {
	 	IFShim *shim;	/**< Pointer to IFShim structure. */
	 } interfaceIsUp;
	 
	/**
	 * InterfaceWillGoDown structure.
	 * Used when the ShimCmdType is set to ShimCmd_IFACE_WILL_GO_DOWN.
	 */
	struct {
	 	IFShim* shim;	/**< Pointer to IFShim structure. */
	 } interfaceWillGoDown;

	/**
	 * IpReceive structure.
	 * Used when the ShimCmdType is set to ShimCmd_IP_RECEIVE.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		Packet *packet;	/**< Pointer to a packet structure. */
	} ipReceive;
	
	/**
	 * IpSend structure.
	 * Used when the ShimCmdType is set to ShimCmd_IP_SEND.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		Packet *packet;	/**< Pointer to a packet structure. */
	} ipSend;
	
	/**
	 * TcpOnOpen structure.
	 * Used when the ShimCmdType is set to ShimCmd_TCP_ON_OPEN.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		TCPCon *con;	/**< Pointer to a TCP connection. */
		void   *cookie;	/**< Pointer to a cookie. */
	} tcpOnOpen;
	
	/**
	 * TcpOnReceive structure.
	 * Used when the ShimCmdType is set to ShimCmd_TCP_ON_RECEIVE. 
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		TCPCon *con;	/**< Pointer to a TCP connection. */
		Packet *packet;	/**< Pointer to a Packet. */
		void   *cookie;	/**< Pointer to a cookie. */
		UInt16 retVal;	/**< New size of the receive window. */
	} tcpOnReceive;
	
	/**
	 * TcpOnTransmit structure.
	 * Used when the ShimCmdType is set to ShimCmd_TCP_ON_TRANSMIT.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		TCPCon *con;	/**< Pointer to a TCP connection. */
		void   *cookie;	/**< Pointer to a cookie. */
	} tcpOnTransmit;
	
	/**
	 * TcpOnRemoteClose structure.
	 * Used when the ShimCmdType is set to ShimCmd_TCP_ON_REMOTE_CLOSE.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		TCPCon *con;	/**< Pointer to a TCP connection. */
		void   *cookie;	/**< Pointer to a cookie. */
	} tcpOnRemoteClose;
	
	/**
	 * TcpOnClose structure.
	 * Used when the ShimCmdType is set to ShimCmd_TCP_ON_CLOSE.
	 */
	struct {
		IFShim         *shim;	/**< Pointer to IFShim structure. */
		TCPCon         *con;	/**< Pointer to a TCP connection. */
		void           *cookie;	/**< Pointer to a cookie. */
		TCPCloseReason why;		/**< Reason for TCP to close. */
	} tcpOnClose;
	
	/**
	 * DnsQuerySuccess structure.
	 * Used when the ShimCmdType is set to ShimCmd_DNS_QUERY_SUCCESS.
	 */
	struct {
		IFShim    *shim;			/**< Pointer to IFShim structure. */
		DNSQuery  *query;			/**< Pointer to a DNSQuery. */
		Char      *canonicalName;	/**< Pointer to the canonical name. */
		INAddr    *addrs;			/**< Pointer to an Internet Address array. */
		void      *cookie;			/**< Pointer to a cookie. */
		Int32     numAddrs;			/**< Number of INAddr in the array addrs. */
	} dnsQuerySuccess;
	
	/**
	 * DnsQueryFailure structure.
	 * Used when the ShimCmdType is set to ShimCmd_DNS_QUERY_FAILURE.
	 */
	struct {
		IFShim     *shim;	/**< Pointer to IFShim structure. */
		DNSQuery   *query;	/**< Pointer to a DNSQuery. */
		void       *cookie;	/**< Pointer to a cookie. */
		DNSError   error;	/**< DNS error. */
	} dnsQueryFailure;
	
	/**
	 * TimerExpiration structure.
	 * Used when the ShimCmdType is set to ShimCmd_TIMER_EXPIRATION.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
		Timer  *timer;	/**< Pointer to a Timer. */
		void   *cookie;	/**< Pointer to a cookie. */
	} timerExpiration;
	
	/**
	 * ConfigSettingWasSet structure.
	 * Used when the ShimCmdType is set to ShimCmd_CONFIG_SETTING_WAS_SET.
	 */
	struct {
		IFShim *shim;	/**< Pointer to IFShim structure. */
	} configSettingWasSet;

} ShimCmd;

/**
 * Main entry point for the VPN Shim.
 * This function needs to be first.
 *
 * @param  	type	Shim command type.
 * @param	cmdP	Pointer to a ShimCmd structure.
 */
NATIVE_CODE void ShimProc(ShimCmdType type, ShimCmd *cmdP);


#endif // PALM_SHIMCMD_H_
