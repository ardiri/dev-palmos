/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmShimSettings.h
 * @version 1.0
 * @date 	10/28/2002
 *
 * Shim settings for NetIFSettingGet()/Set().
 *
 * <hr>
 */

#ifndef PALM_SHIM_SETTINGS_H_
#define PALM_SHIM_SETTINGS_H_

/**
 * NetIFSettings for the shim.
 * Used by NetIFSettingGet()/Set().
 */
typedef enum {

  netIFSettingShimUp = 0xA000,    /**< True if shim is up; read-only. */
  netIFSettingShimHideProgress,   /**< Defaults to false. */
  netIFSettingShimConfig,         /**< Mechanism for passing data between app & proto tasks. */
  netIFSettingShimLog,            /**< Copy the shim log; read-only. */
  netIFSettingShimCreator,        /**< Creator ID of shim; UInt32; read-only. */
  netIFSettingShimVersion         /**< Version of the shim; Char[32]; read-only. */

} NetIFSettingShimEnum;

#endif // PALM_SHIM_SETTINGS_H_
