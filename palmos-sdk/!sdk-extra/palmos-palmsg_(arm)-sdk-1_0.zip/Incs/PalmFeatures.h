/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmFeatures.h
 * @version 1.0
 * @date 	02/29/2002
 *
 * Contains Palm-specific feature definitions.
 *
 * <hr>
 */
 
#ifndef __PALMFEATURES_H__
#define	__PALMFEATURES_H__

#define kInitialButtonPrefsVersion	0
#define kFargoButtonPrefsVersion	1
#define kPacificButtonPrefsVersion	2


// The following feature should be defined on all devices that support hi-res
// screens & include NotePad 2.0 or higher.  As the OS does not yet provide a
// method for the desktop SW/conduits to query the handheld in order to
// determine the density capabilities of the device, this feature has been
// added.  By testing the presence/content of this feature, the device can
// properly convert any old lo-density RLE data to be hi-density PNG data on
// the first hotsync to the device rather than have to do a note-by-note
// conversion at run time on the handheld the first time each old note has been
// opened.
#define densityFtrCreator       'dnsT'
#define densityFtrVersion       0
// one of the DensityType values defined in the Bitmap.h file should be stored
// in this feature designating the density supported by the device.

// headset feature
#define headsetFtrCreator		'hseT'
#define headsetFtrVersion		0

#endif // __PALMFEATURES_H__