/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmSoundMgrExt.h
 * @version 1.0
 * @date 	03/03/2003
 *
 * Header file for the extended sound manager.
 * 
 * <hr>
 */

#ifndef __SOUNDMGREXT_H__
#define __SOUNDMGREXT_H__

#include <SoundMgr.h>

/********************************************************************
 * Traps
 ********************************************************************/
#define sysTrapSndStreamCreateExtended				0xA466
#define sysTrapSndStreamDeviceControl				0xA467

/********************************************************************
 * Constants and Typedefs
 ********************************************************************/
enum {
	sndFormatPCM		= 0,			/**< Raw PCM (Pulse Code Modulation), (attributes defined by type parameter). */
	sndFormatIMA_ADPCM	= 'APCM',		/**< IMA ADPCM (Interactive Multimedia Association Adaptive Differential PCM). */
	sndFormatDVI_ADPCM	= 'DPCM',		/**< Intel/MS/DVI ADPCM. */
	sndFormatMP3		= 'MPG3',		/**< Moving Picture Experts Group, Audio Layer III (MPEG-1 and MPEG-2 depending on bit-rate). */
	sndFormatAAC		= 'DAAC',		/**< Dolby Advanced Audio Coding. */
	sndFormatOGG		= 'OGGV'		/**< Ogg Vorbis. */
};
/** Sound format type. */
typedef UInt32 SndFormatType;


/********************************************************************
 * Extended Sound Manager Callback
 ********************************************************************/
 
/**
 * Externded Sound Manager callback.
 *
 * @param userDataP		Pointer to the user data passed in SndStreamCreateExtended.
 * @param streamRef		Opaque reference to the stream returned by SndStreamCreateExtended.
 * @param bufferP		Data buffer.
 * @param bufferSizeP	Pointer to the buffer size in bytes. This MUST be set before returning to the number of bytes read or written.
 * @return				Error code.
 */
typedef Err (*SndStreamVariableBufferCallback) (
	void 			*userDataP,
	SndStreamRef 	streamRef,
	void 			*bufferP,
	UInt32 			*bufferSizeP
);


/********************************************************************
 * Prototypes
 ********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * Creates a sound stream using the Extended Sound API.
 *
 * @param streamP		Receives the opaque reference to the stream.
 * @param mode			Direction of the sream, either sndInput or sndOutput.
 * @param format		Sound format. (sndFormatPCM...)
 * @param sampleRate	Sampling rate, in frames-per-second. (8000, 44100,...)
 * @param sampleType	Sample size and endianness of the data. (sndInt16...)
 * @param width			The number of channels: sndMono for one channel, sndStrereo for two.
 * @param sndCallback	A callback function that gets called when another buffer for sound is needed.
 * @param userDataP		Caller-defined data that gets passed to SndStreamVariableBufferCallback.
 * @param bufferSize	Preferred size in bytes for the buffers that are passed to sndCallback.
 * @param armNative		Pass true if the callback function is written in ARM-native code. If it�s 68K, pass false.
 * @return				Error code.
 */
extern Err SndStreamCreateExtended(
		SndStreamRef 					*streamP,
		SndStreamMode 					mode,
		SndFormatType 					format,
		UInt32 							sampleRate,
		SndSampleType 					sampleType,
		SndStreamWidth 					width,
		SndStreamVariableBufferCallback	sndCallback,
		void 							*userDataP,
		UInt32 							bufferSize,
		Boolean 						armNative)
			SYS_TRAP(sysTrapSndStreamCreateExtended);

/**
 * An extended function to handle new or device specific custom sound controls.
 *
 * @param stream	Opaque reference to the stream returned by SndStreamCreateExtended.
 * @param cmd		One of the defined custom control enums, such as sndControlCodecCustomControl.
 * @param paramP	Pointer to data specific to the specific custom control defined by cmd.
 * @param size		Size in bytes of the structure passed in paramP.
 * @return			Error code.
 */
extern Err SndStreamDeviceControl(SndStreamRef stream, Int32 cmd, void *paramP, Int32 size)
							SYS_TRAP(sysTrapSndStreamDeviceControl);

#ifdef __cplusplus 
}
#endif

#endif // __SOUNDMGREXT_H__

