/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmCameraLib.h
 * @version 1.0
 * @date 	02/29/2002
 *
 * Exported Camera functions.
 *
 * <hr>
 */

#ifndef __PalmCameraLib_H__
#define __PalmCameraLib_H__

// Palm OS common definitions
#include <PalmTypes.h>
#include <ErrorBase.h>
#include <SystemMgr.h>
#include <LibTraps.h>

#define CAM_LIB_TRAP(trapNum) SYS_TRAP(trapNum)

/***********************************************************************
 * Type and creator of the Library
 ***********************************************************************/

#define		kCamLibType		'libr'				/**< Camera library type. */
#define		kCamLibCreator	'camL'				/**< Camera database creator. */

/***********************************************************************
 * Internal library name which can be passed to SysLibFind()
 ***********************************************************************/

#define		kCamLibName		"CameraLib-camL"	/**< Camera library name. */

/***********************************************************************
 * Library versionning
 ***********************************************************************/

#define		kCamLibVersion1	sysMakeROMVersion(1, 0, 0, sysROMStageRelease, 0)
#define		kCamLibVersion	kCamLibVersion1

/***********************************************************************
 * CameratLib result codes
 * (appErrorClass is reserved for 3rd party apps/libraries.
 * It is defined in SystemMgr.h)
 ***********************************************************************/

#define kCamLibErrorClass			(oemErrorClass + 0x100)

/** Invalid parameter. */
#define kCamLibErrBadParam			(kCamLibErrorClass | 0x01)		
/** Memory error. */
#define	kCamLibErrNoMemory			(kCamLibErrorClass | 0x02)
/** Library is not open. */
#define kCamLibErrNotOpen			(kCamLibErrorClass | 0x03)		
/** Returned from CamLibClose() if the library is still open. */
#define kCamLibErrStillOpen			(kCamLibErrorClass | 0x04)	
/** Internal error. */
#define	kCamLibErrInternal			(kCamLibErrorClass | 0x05)
/** Unsupported function. */
#define	kCamLibErrNotSupported		(kCamLibErrorClass | 0x06)
/** Bad Version. */
#define	kCamLibErrNotCompatible		(kCamLibErrorClass | 0x07)
/** Camera not powered. */
#define	kCamLibErrNoPower			(kCamLibErrorClass | 0x08)

/***********************************************************************
 * Constants - control commands
 ***********************************************************************/

/** Power on and initialize the camera module. No parameter. */ 
#define	kCamLibCtrlPowerOn					0x01
/** Power off the camera module. No parameter. */
#define	kCamLibCtrlPowerOff					0x02
/** Display the hardware camera settings dialog. No parameter. */
#define kCamLibCtrlHardwareSettingsDlg		0x03
/** Starts the camera preview mode. No parameter. No parameter. */
#define kCamLibCtrlPreviewStart				0x04
/** Stops the camera preview mode. No parameter. */
#define kCamLibCtrlPreviewStop				0x05
/** Use to determine the captured image properties. Parameter is CamLibBitmapInfoType*. */
#define kCamLibCtrlCaptureGetBitmapInfo		0x06
/** Captures the current image. Parameter is CamLibCaptureType*. */
#define kCamLibCtrlCapture					0x07
/** Use to determine if a certain camera status is currently in effect. Parameter is CamLibStatusType*. */
#define kCamLibCtrlStatusGet				0x08
/** Use to determine if a certain camera status is available. Parameter is CamLibStatusType*. */
#define kCamLibCtrlStatusQuery				0x09
/** Set the capture format. Parameter is CamLibCaptureFormatType*. */
#define kCamLibCtrlCaptureFormatSet			0x10
/** Get the current capture format. Parameter is CamLibCaptureFormatType*. */
#define kCamLibCtrlCaptureFormatGet			0x11
/** Check the capture formats available. Parameter is CamLibCaptureFormatType*. */
#define kCamLibCtrlCaptureFormatQuery		0x12
/** Set the capture size. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlCaptureSizeSet			0x13
/** Get the current capture size. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlCaptureSizeGet			0x14
/** Check the capture sizes available. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlCaptureSizeQuery			0x15
/** Set the capture area. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlCaptureAreaSet			0x16
/** Get the capture area. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlCaptureAreaGet			0x17
/** Set the preview size. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlPreviewSizeSet			0x20
/** Get the preview size. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlPreviewSizeGet			0x21
/** Check the preview sizes available. Parameter is CamLibImageSizeType*. */
#define kCamLibCtrlPreviewSizeQuery			0x22
/** Set the preview rectangle. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlPreviewRectSet			0x23
/** Get the preview rectangle. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlPreviewRectGet			0x24
/** Set the preview area. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlPreviewAreaSet			0x26
/** Get the preview area. Parameter is RectangleType*. Low-res value. */
#define kCamLibCtrlPreviewAreaGet			0x27
/** Set the white balance. Parameter is CamLibWhiteBalanceType*. */
#define kCamLibCtrlWhiteBalanceSet			0x30
/** Get the current white balance. Parameter is CamLibWhiteBalanceType*. */
#define kCamLibCtrlWhiteBalanceGet			0x31
/** Check the white balances available. Parameter is CamLibWhiteBalanceType*. */
#define kCamLibCtrlWhiteBalanceQuery		0x32
/** Set the exposure. Parameter is CamLibExposureType*. */
#define kCamLibCtrlExposureSet				0x40
/** Get the exposure. Parameter is CamLibExposureType*. */
#define kCamLibCtrlExposureGet				0x41
/** Check the exposures available. Parameter is CamLibExposureType*. */
#define kCamLibCtrlExposureQuery			0x42
/** Set the contrast. Parameter is CamLibContrastType*. */
#define kCamLibCtrlContrastSet				0x43
/** Get the current contrast. Parameter is CamLibContrastType*. */
#define kCamLibCtrlContrastGet				0x44
/** Check the contrast available. Parameter is CamLibContrastType*. */
#define kCamLibCtrlContrastQuery			0x45

/** Camera library control type. */
typedef UInt16 CamLibControlType;

/***********************************************************************
 * Constants - Status
 ***********************************************************************/

/** Is the camera powered on? */
#define kCamLibStatusPoweredOn		0x01
/** Is the camera in preview mode? */
#define kCamLibStatusInPreview		0x02

/** @brief Camera library status type structure. */
typedef struct CamLibStatusTag
{
	UInt32 status;	/**< Camera status. */
} CamLibStatusType;

/***********************************************************************
 * Constants - Capture and Bitmap info
 ***********************************************************************/

/** @brief Camera library bitmap info structure. */
typedef struct CamLibBitmapInfoTag // For every format except PalmBmpV4
{
	UInt16 width;			/**< Width of the bitmap. */
	UInt16 height;			/**< Height of the bitmap. */
	UInt32 numBytes;		/**< Number or Bytes to be streamed. */
	UInt8  bitsPerPixel;	/**< Number of bits per pixel. */
	UInt8  reserved0;		// For packing
	UInt16 reserved1;		// For packing
	// Data start here
} CamLibBitmapInfoType;

/**
 * Camera library image caputre callback function.
 *
 * @param bufP		Pointer to the image buffer.
 * @param size		Size of the buffer.
 * @param userDataP	Pointer to user data.
 * @return 			Error code.
 */
typedef Err CamLibCaptureCallbackFunc(void *bufP, UInt32 size, void *userDataP);

/**
 * @brief Capture settings.
 * The callback is callled with userDataP passed.
 */
typedef struct CamLibCaptureTag {
	CamLibCaptureCallbackFunc *callbackP;	/**< Callback function. */
	void *userDataP;	/**< User data pointer. */
} CamLibCaptureType;

/***********************************************************************
 * Constants - Capabilities Settings
 ***********************************************************************/

/**
 * @brief Settings Capabilities structure.
 * For settings without manual values, only type is used
 */
typedef struct CamLibSettingTag
{
	UInt32 type;		/**< Setting type. */
	Int32 value;		/**< For manual settings only. */
	Int32 minValue;		/**< Used for Get/Query only and is valid for manual value. */
	Int32 maxValue;		/**< Used for Get/Query only and is valid for manual value. */
} CamLibSettingType;

/** Capture format in 16-bit RGB color. */
#define kCamLibCaptureDataFormatRGB565		0x02
/** Capture format in 16-bit YUVB color. */
#define kCamLibCaptureDataFormatYUV422		0x04

typedef struct CamLibSettingTag CamLibCaptureFormatType;

/** 160 x 120 High Resolution. */
#define kCamLibImageSizeQQVGA			0x02
/** 320 x 240 High Resolution. */
#define kCamLibImageSizeQVGA			0x04
/** 640 x 480 High Resolution. */
#define kCamLibImageSizeVGA				0x08

typedef struct CamLibSettingTag CamLibImageSizeType;

/**
 * The camera automatically determines the correct white
 * balance for capturing and previewing images.
 */
#define kCamLibWhiteBalanceAuto				0x02

/**
 * The camera sets the white balance for indoor capturing
 * and previewing of images.
 */
#define kCamLibWhiteBalanceIndoor			0x04

/**
 * The camera sets the white balance for outdoor capturing
 * and previewing of images.
 */
#define kCamLibWhiteBalanceOutdoor			0x08

/**
 * The camera sets the white balance for flourescent indoor
 * lighting capturing and previewing of images.
 */
#define kCamLibWhiteBalanceExtra			0x10

typedef struct CamLibSettingTag CamLibWhiteBalanceType;

/**
 * Used to set the exposure level manually through an additional
 * passed parameter with kCamLibCtrlExposureSet.
 * For manual value, all values are x1000 of real exposure
 * i.e. exp 1.5 is 1500. */
#define kCamLibExposureManual			0x01	// Set the value in whiteBalance

/**
 * The camera sets the exposure level automatically.
 */
#define kCamLibExposureAuto				0x02

typedef struct CamLibSettingTag CamLibExposureType;

/**
 * Used to set the contrast value manually. Use kCamLibCtrlContrastGet
 * to determine the minimum and maximum values allowed and the unit of
 * measurement. */
#define kCamLibContrastManual			0x01	// Set the value in value

typedef struct CamLibSettingTag CamLibContrastType;
                           
/***********************************************************************
 * Library trap
 ***********************************************************************/

#define kCamLibTrapGetVersion		(sysLibTrapCustom + 0)
#define kCamLibTrapControl			(sysLibTrapCustom + 1)

/***********************************************************************
 * API Prototypes
 ***********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Opens the Camera Manager.
 *
 * @param refNum	Library reference number.
 * @return			Error code.
 */
extern Err CamLibOpen(UInt16 refNum)
	CAM_LIB_TRAP(sysLibTrapOpen);

/**
 * Closes the Camera Manager.
 *
 * @param refNum	Library reference number.
 * @return			Error code.
 */
extern Err CamLibClose(UInt16 refNum)
	CAM_LIB_TRAP(sysLibTrapClose);

/**
 * Standard library sleep function.
 *
 * @param refNum	Library reference number.
 * @return			Error code.
 */
extern Err CamLibSleep(UInt16 refNum)
	CAM_LIB_TRAP(sysLibTrapSleep);

/**
 * Standard library wake function.
 *
 * @param refNum	Library reference number.
 * @return			Error code.
 */
extern Err CamLibWake(UInt16 refNum)
	CAM_LIB_TRAP(sysLibTrapWake);

/**
 * Checks the version of the Camera Manager Library.
 *
 * @param refNum		Library reference number.
 * @param sdkVersion	The version the application expects.
 * @param libVersionP	The actual version of the library.
 * @return				Error code.
 */
extern Err CamLibGetVersion(UInt16 refNum, UInt32 sdkVersion, UInt32* libVersionP)
	CAM_LIB_TRAP(kCamLibTrapGetVersion);

/**
 * Check or set a Camera property.
 *
 * @param refNum		Library reference number.
 * @param cmdId			The control command uses to check or set the camera property.
 * @param parameterP	Pointer to a parameter based on the control command type.
 * @return				Error code.
 */	
extern Err CamLibControl(UInt16 refNum, CamLibControlType cmdId, void *parameterP)
	CAM_LIB_TRAP(kCamLibTrapControl);

#ifdef __cplusplus
}
#endif

#endif // __PalmCameraLib_H__

