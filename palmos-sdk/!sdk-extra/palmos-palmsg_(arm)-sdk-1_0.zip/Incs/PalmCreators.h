/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmCreators.h
 * @version 1.0
 * @date 	02/29/2002
 *
 * Contains Palm-specific creator codes.
 *
 * <hr>
 */

#ifndef __PALMCREATORS_H__
#define __PALMCREATORS_H__

#include <SystemResources.h>	// for classic creator code definitions

#define sysFileCTelMgrLibOem		'toem'	/**< Creator ID for the Telephony Manager Extension shared library. */
#define sysFileCSimATDriverOem		'sims'	/**< Creator ID for the SIM AT Driver. */
#define sysFileCSimOfficer			'sats'	/**< Creator ID for the SIM Application Toolkit client application. */
#define sysFileCSimWatcherLib		'simw'	/**< Creator ID for the SIM Watcher library. */
#define sysFileCProvisioning		'prov'	/**< Creator ID for the provisioning application. */
#define sysFileCMobileServices		'msvc'	/**< Creator ID for the Mobile Service Library. */
#define sysFileCMyFavorite			'myfv'	/**< Creator ID for the MyFavorite App. */
#define sysFileCNotePad				'npad'	/**< Creator ID for the Notepad app. */
#define sysFileCMobileApp			'mobi'  /**< Creator ID for the Mobile application */



#endif	// __PALMCREATORS_H__