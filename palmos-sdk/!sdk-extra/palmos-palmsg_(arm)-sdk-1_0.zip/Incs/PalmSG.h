/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmSG.h
 * @version 1.0
 * @date 	02/29/2002
 *
 * All Palm Solutions Group specific includes.
 *
 * <hr>
 */
 
#ifndef __PALMSG_H__
#define __PALMSG_H__

#include "PalmChars.h"
#include "PalmCreators.h"
#include "PalmFeatures.h"
#include "PalmNavigator.h"
#include "PalmResources.h"

#endif // __PALMSG_H__