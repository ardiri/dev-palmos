/******************************************************************************
 * Copyright (c) 2003 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *****************************************************************************/
 
/**
 * @file 	PalmCameraSlider.h
 * @version 1.0
 * @date 	02/29/2002
 *
 * Slider notification.
 *
 * This contains the Slider notification and status information
 * Any application can register to the notification to be nofity
 * when the slider is opened or closed
 * any application can also get the status of the slider by checking
 * the feature.
 * This is specific to the camera slider.
 * The notifyDetailsP param in SysNotifyParamType is null in the notification
 * Application should check the status of the slider by using the Feature.
 *
 * <hr>
 */

#ifndef __PalmCameraSlider_H__
#define __PalmCameraSlider_H__

// Palm OS common definitions
#include <PalmTypes.h>
#include <SystemMgr.h>

/***********************************************************************
 * Slider notification and status
 ***********************************************************************/

#define		kCamSliderVersion1	sysMakeROMVersion(1, 0, 0, sysROMStageDevelopment, 0)
#define		kCamSliderVersion	kCamSliderVersion1

/** Feature for testing if the slider is open. */
#define kCamSliderFlagsOpened			0x00000001

/** Camera Slider creator ID. */
#define kCamSliderCreator		'cslP'

/** Notification creator. */
#define kCamSliderNotifyEvent	kCamSliderCreator

/** Feature value should be kCamSliderVersion. */
#define kCamSliderFtrVersionNum	0

/** Feature value should be kCamSliderFlagsOpened or 0. */
#define kCamSliderFtrFlagsNum	1

#endif // __PalmCameraSlider_H__
