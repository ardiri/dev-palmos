
typedef union {
  unsigned short value;
  union {
    unsigned char high;
    unsigned char low;
  };
} _register;

unsigned int _cs, _ds, _ss, _es;
_register    _ax, _bx, _cx, _dx;
unsigned int _si, _di;
unsigned int _sp, _bp;
unsigned int _pc;

unsigned char *memory;
unsigned int _ea;
unsigned int _flag;

#define GetCarry() ((_flag & 0x10) >> 5)

void cpu() {
  unsigned int  *src, *dest;
  unsigned int  value, result, temp;
  unsigned char opcode;

  value = *((unsigned int *) (memory + _cs * 4 + _pc));

  opcode = value >> 24;

  switch (opcode) {
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
    result = *dest  = *dest + *src + GetCarry();
    *dest &= 0xFFFF;
    break;
  case 0x00:
  case 0x01:
  case 0x02:
  case 0x03:
  case 0x04:
  case 0x05:
    result = *dest  = *dest + *src;
    *dest &= 0xFFFF;
    break;
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
    result = *dest  = *dest & *src;
    break;
  case 0x38:
  case 0x39:
  case 0x3A:
  case 0x3B:
  case 0x3C:
  case 0x3D:
    result = *dest - *src;
    break;
  case 0xCD:
    temp = (value >> 16) & 0x00FF;
    break;
  case 0x77:
    temp = (value >> 16) & 0x00FF;
    break;
  case 0x73:
    temp = (value >> 16) & 0x00FF;
    break;
  case 0x88:
  case 0x89:
  case 0x8A:
  case 0x8B:
  case 0x8C:
  case 0x8E:
    *dest = *src;
    break;
  case 0x90:
    pc++;
    break;
  case 0x08:
  case 0x09:
  case 0x0A:
  case 0x0B:
  case 0x0C:
  case 0x0E:
    result = *dest = *dest | *src;
    break;
  case 0xc3:
    // near return
    break;
  case 0xcB:
    // far return
    break;
  case 0x18:
  case 0x19:
  case 0x1A:
  case 0x1B:
  case 0x1C:
  case 0x1E:
    result = *dest = *dest - (*src + GetCarry());
    break;
  case 0xF9:
    // stc
    break;
  case 0xFD:
    // std
    break;
  case 0xFb:
    // sti
    break;
  }
  
}
