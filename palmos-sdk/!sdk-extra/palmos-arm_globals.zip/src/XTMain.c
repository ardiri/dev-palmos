#include <PalmOS.h>
#include <PceNativeCall.h>

#include <stdio.h>

#include "armlets-id.h"

void *LoadArmResource(UInt32 id_armc, UInt32 id_armg) {
  MemHandle armc = DmGetResource ('armc', id_armc);
  void *armcm = MemHandleLock (armc);
  MemHandle armg = DmGetResource ('armg', id_armg);
  void *armgm = MemHandleLock (armg);
  void *armlet;
  UInt32 temp1, temp2;
  UInt16 count, loop, csize, gsize;

  csize = MemHandleSize(armc);
  gsize = MemHandleSize(armg);

  MemSemaphoreReserve(true);

  FtrPtrFree('ARML', 1);
  FtrPtrNew ('ARML', 1, csize + gsize, (void **) &armlet);

  MemMove(        armlet, armcm, csize);
  if (gsize > 16) MemMove(armlet + csize, armgm, gsize);

  temp2 = *((UInt32 *) (armlet + csize + 12));
  asm("rol.w #8, %0\nswap %0\nrol.w #8, %0\nmove.l %0, %1" : :  "d" (temp2), "m" (temp2));
  count = temp2;
  
  temp2 = (unsigned long) armlet;

  for (loop = 0; loop < count; loop++) {
    temp2 = *((UInt32 *) (armlet + csize + 16 + loop * 4));
    asm("rol.w #8, %0\nswap %0\nrol.w #8, %0\nmove.l %0, %1" : :  "d" (temp2), "m" (temp2));
    temp2 = temp2 + (unsigned long) armlet;
    asm("rol.w #8, %0\nswap %0\nrol.w #8, %0\nmove.l %0, %1" : :  "d" (temp2), "m" (temp2));
    *((UInt32 *) (armlet + csize + 16 + loop * 4)) = temp2;
  }

  MemSemaphoreRelease(true);

  DmReleaseResource(armc);
  DmReleaseResource(armg);

  return armlet;
}

UInt32 PilotMain (UInt16 cmd, void *params, UInt16 flags) {
  EventType e;

  if (cmd == sysAppLaunchCmdNormalLaunch) {
    UInt32 pt;
    void  *armlet = LoadArmResource(0, 0);

    MemSemaphoreReserve(true);
    pt = PceNativeCall (armlet, NULL);
    printf ("add() %04X%04X\n", (unsigned int) (pt >> 16), (unsigned int) (pt & 0x0000FFFF));
    MemSemaphoreRelease(true);

    FtrPtrFree('ARML', 1);

    do {
      EvtGetEvent (&e, evtWaitForever);
      SysHandleEvent (&e);
    } while (e.eType != appStopEvent);
  }

  return 0;
}
