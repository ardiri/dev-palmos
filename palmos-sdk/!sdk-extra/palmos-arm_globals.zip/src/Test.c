#include <PceNativeCall.h>
#include <Standalone.h>

#include "armlets-id.h"

STANDALONE_CODE_RESOURCE_ID (test_id);

int value[10] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A};
int code1 = 0, code2 = 0;
int memory[16] = {0xAA};

int test1(int *v);

unsigned long start(const void *emulStateP, void *userData68KP, Call68KFuncType *call68KFuncP) {

  code1 = test1(value);
  code2 += 10;

  code2 = code1 - code2;

  return code2;
}

int test1(int *v) {
  int count1, count2;

  count2 = 0;
  for (count1 = 0; count1 < 10; count1++) count2 += value[count1];
  for (count1 = 0; count1 < 10; count1++) {
    memory[count1] = value[count1];
    count2 += memory[count1];
  }

  return count2;
}
