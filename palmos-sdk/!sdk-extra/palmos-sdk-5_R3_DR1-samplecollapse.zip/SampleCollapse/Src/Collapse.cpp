/*********************************************************************
 *
 Sample Code Disclaimer

 Copyright c 2002 PalmSource, Inc. or its subsidiaries. All rights
 reserved.

 You may incorporate this sample code (the "Code") into your
 applications for Palm OS(R) platform products and may use the Code to
 develop such applications without restriction. The Code is provided
 to you on an "AS IS" basis and the responsibility for its operation
 is 100% yours. PALMSOURCE, INC. AND ITS SUBSIDIARIES (COLLECTIVELY,
 "PALMSOURCE") DISCLAIM ALL WARRANTIES, TERMS AND CONDITIONS WITH
 RESPECT TO THE CODE, EXPRESS, IMPLIED, STATUTORY OR OTHERWISE,
 INCLUDING WARRANTIES, TERMS OR CONDITIONS OF MERCHANTABILITY, FITNESS
 FOR A PARTICULAR PURPOSE, NONINFRINGEMENT AND SATISFACTORY QUALITY.
 You are not permitted to redistribute the Code on a stand-alone basis
 and you may only redistribute the Code in object code form as
 incorporated into your applications. TO THE FULL EXTENT ALLOWED BY
 LAW, PALMSOURCE ALSO EXCLUDES ANY LIABILITY, WHETHER BASED IN
 CONTRACT OR TORT (INCLUDING NEGLIGENCE), FOR INCIDENTAL,
 CONSEQUENTIAL, INDIRECT, SPECIAL OR PUNITIVE DAMAGES OF ANY KIND, OR
 FOR LOSS OF REVENUE OR PROFITS, LOSS OF BUSINESS, LOSS OF INFORMATION
 OR DATA, OR OTHER FINANCIAL LOSS ARISING OUT OF OR IN CONNECTION WITH
 THE USE OR PERFORMANCE OF THE CODE. The Code is subject to Restricted
 Rights for U.S. government users and export regulations.

 SAMPLE NAME:  SampleCollapse

 FILE:         collapse.c

 DATE:         July 2nd, 2003

 DESCRIPTION:  Source Code
 *
 *
 * NOTE: You will need the OS R3 SDk to compile this sample project
 ********************************************************************/


#include <PalmOS.h>
#include "CollapseRsc.h"

#pragma mark -
#pragma mark ==structs==
/***********************************************************************
 *
 *	Internal Structures
 *
 ***********************************************************************/
typedef struct 
	{
	UInt8 replaceme;
	} StarterPreferenceType;

typedef struct 
	{
	UInt8 replaceme;
	} StarterAppInfoType;

typedef StarterAppInfoType* StarterAppInfoPtr;

#pragma mark -
#pragma mark ==globals==
/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
UInt32 g_PinMgrVersion;


#pragma mark -
#pragma mark ==constants==
/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'dsCO'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

// Define the minimum OS version we support (3.5 for now).
#define kOurMinVersion	sysMakeROMVersion(5,0,0,sysROMStageRelease,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)

#ifndef SetBits
#define SetBits( b, len )      ( ( ( 1U << ( ( len ) - 1 ) ) - 1U + ( 1U << ( ( len ) - 1 ) ) ) << ( b ) )
#endif

//pinMaxConstraintSize is set to the max value of a Coord such that it can grow as big as the 
//hardware supports
#ifndef pinMaxConstraintSize
#define pinMaxConstraintSize 	SetBits( 0, ( sizeof( Coord) * 8 ) - 1 )
#endif

/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/


#pragma mark -
/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


//////////////////////
//initialize the text in a field
//////////////////////
static Err SetTextPtr(FieldType* fldP, const Char* str, Boolean needToedraw)
{
	MemHandle textH = FldGetTextHandle(fldP);
	Char* str2;
	
	Err error;
	
	if (textH)
	{
		FldSetTextHandle(fldP, NULL);
		if ((error = MemHandleResize(textH, StrLen(str) + 1)) != 0)
		{
			FldSetTextHandle(fldP, textH);
			
			return error;
		}
		
	}
	else
	{
		textH = MemHandleNew(StrLen(str) + 1);
		if (!textH)
			return memErrNotEnoughSpace;
	
	}	
	
	str2 = (Char*) MemHandleLock(textH);
	StrCopy(str2, str);
	MemHandleUnlock(textH);
	
	FldSetTextHandle(fldP, textH);
	
	if(needToedraw)
		FldDrawField(fldP);
		
	return 0;
	
}

///////////////////
//Show an info style alert with given text
////////////////////
static void MyInfoAlert(const char* theText)
{
	//nothing special needs to be done to make use of FrmAlert or FrmCustomAlert
	//and collapsible input
	FrmCustomAlert(GenericInfoAlert, theText, NULL, NULL);

}



#pragma mark -

#define collapseStateLockUp 		0
#define collapseStateUp				1
#define collapseStateUser			2
#define collapseStateDown			3
#define collapseStateLockDown		4

////////////////////////////////////
//Set form to handle collapsible input area and set initial 
//input area and trigger state
////////////////////////////////////
/***********************************************************************
 *
 * FUNCTION:    CollapseUtilSetState
 *
 *	The user has just opened or closed the Active Input area.
 *	Now we need to resize the form to fill the draw window
 *	.
 *
 *	
 *
 *
 * DESCRIPTION: Resizes form for active input -- filling available space
 *
 * PARAMETERS:  frmP - a pointer to a FormType struct
 				newState - selector for initial state
 *
 * RETURNED:   void
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			EZE			5/15/03			initial 
 *
 ***********************************************************************/

static void CollapseUtilSetState(FormType* frmP, UInt8 newState)
{

	Err theErr;
	
	switch(newState)
	{

		case collapseStateUp:
			WinSetConstraintsSize(WinGetWindowHandle(frmP), 160, 160, pinMaxConstraintSize, 160, 160, pinMaxConstraintSize);		
			FrmSetDIAPolicyAttr( frmP, frmDIAPolicyCustom );		
			PINSetInputTriggerState(pinInputTriggerEnabled);
			PINSetInputAreaState(pinInputAreaOpen);
			
			break;
			
		case collapseStateUser:
			//This is the default behaivor of apps -- do not pull up or push down input area
			//just respect what the user setting is
			WinSetConstraintsSize(WinGetWindowHandle(frmP), 160, 160, pinMaxConstraintSize, 160, 160, pinMaxConstraintSize);
			FrmSetDIAPolicyAttr( frmP, frmDIAPolicyCustom );
			PINSetInputTriggerState(pinInputTriggerEnabled);
			theErr = PINSetInputAreaState(pinInputAreaUser); 
			break;		
			
		case collapseStateDown:
			WinSetConstraintsSize(WinGetWindowHandle(frmP), 160, 240, pinMaxConstraintSize, 160, 160, pinMaxConstraintSize);		
			FrmSetDIAPolicyAttr( frmP, frmDIAPolicyCustom );
			PINSetInputTriggerState(pinInputTriggerEnabled);
			PINSetInputAreaState(pinInputAreaClosed);
			break;
			
			
		case collapseStateLockDown:
			WinSetConstraintsSize(WinGetWindowHandle(frmP), 160, 240, pinMaxConstraintSize, 160, 160, pinMaxConstraintSize);		
			FrmSetDIAPolicyAttr( frmP, frmDIAPolicyCustom );
			PINSetInputTriggerState( pinInputTriggerDisabled);
			PINSetInputAreaState(pinInputAreaClosed);
			break;
			
		//doing nothing results in legacy mode (lock input area up)
		//which is also the default behavior
		case collapseStateLockUp:
		default:
			break;
	
	}

}

/***********************************************************************
 *
 * FUNCTION:    CollapseVertResizeForm
 *
 *	The user has just opened or closed the Active Input area.
 *	Now we need to resize the form to fill the draw window
 *	.
 *
 *	
 *
 *
 * DESCRIPTION: Resizes form for active input -- filling available space
 *
 * PARAMETERS:  frmP - a pointer to a FormType struct
 				isModal specifies that this is a modal form
 				returnOffsetX, returnOffsetY - returns change in size of form to
 				 be used in relocating/resizing form objects
 *
 * RETURNED:    Boolean - true if resize was needed, else false
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			EZE			9/10/02			initial 
 *
 ***********************************************************************/
static Boolean CollapseResizeForm(FormType *frmP, Boolean isModal, Int16* returnOffsetX, Int16* returnOffsetY)
{
	Coord			drawAreaHeightCoords, drawAreaWidthCoords;
	Int16			offsetCoordsX, offsetCoordsY;
	RectangleType	formBounds;
	WinHandle		frmWinH;


	//------------------------------------------------------------------
	// 1. Get the height of the drawing area available to this app
	//    (by calling WinGetDisplayExtent()). There has been a change in window diminsions
	//    such as the Active Input area being either opened or closed
	//   , and the value of the display extent will reflect that.
	//------------------------------------------------------------------
	WinGetDisplayExtent( &drawAreaWidthCoords, &drawAreaHeightCoords );

	//------------------------------------------------------------------
	// 2. Get the height/width of the current form's draw window and compute the
	//    difference between the draw window and the 
	//    the current app's drawing area. At this point,
	//    the form's draw window has not changed
	//------------------------------------------------------------------
	frmWinH = FrmGetWindowHandle(FrmGetActiveForm());
	WinGetBounds(frmWinH, &formBounds);

	// Example #1: The user just closed the Active input area,
	//     so the drawing area is now > form draw window
	// eg: offsetCoordsY = drawAreaHeightCoords - formBounds.extent.y - formBounds.topLeft.y;
	//     offsetPixelsY = 225 - 160 - 0 = +65.

	// Example #2: The user just opened the Active input area,
	//     so the drawing area is now < form draw window (drawing area has shrunk !).
	// eg:offsetCoordsY = drawAreaHeightCoords - formBounds.extent.y - formBounds.topLeft.y;
	//     offsetPixels = 160 - 225 = -65.

	//for full screen windows topLeft.y is simply 0, or 1 for modal dialogs
	offsetCoordsX = drawAreaWidthCoords - formBounds.extent.x - formBounds.topLeft.x;
	offsetCoordsY = drawAreaHeightCoords - formBounds.extent.y - formBounds.topLeft.y;

	//modal dialogs need room for line at the bottom
 	if (isModal)
 	{
 		offsetCoordsX -=2;
 		offsetCoordsY -=2;
 	}	
 	
 	//return these values
 	*returnOffsetX = offsetCoordsX;
 	*returnOffsetY = offsetCoordsY;
 	
	//------------------------------------------------------------------
	// 3. If the form draw window is now smaller than the draw area,
	//    then we need to increase the size of the form draw window
	//    to equal the drawing area to take advantage of this newly
	//    available  space. The user just closed the Active input area.
	//    ... or ...
	//    If the form draw window is now larger than the draw area,
	//    then we need to decrease the size of the form draw window
	//    to equal the drawing area so no part of the draw window
	//    is outside this app's drawing area (or it'll get clipped).
	//    The user just opened the Active input area.
	//
	//------------------------------------------------------------------

	//------------------------------------------------------------------
	// 3. a. Increase/Decrease form height and width
	//------------------------------------------------------------------
	if (offsetCoordsX || offsetCoordsY)
	{
		formBounds.extent.x += offsetCoordsX;
		formBounds.extent.y += offsetCoordsY;

		// Change current draw window to match the display extent (app's drawing area)
		WinSetBounds( frmWinH, &formBounds );
		
		//return that the form has changed size
		return true;
	}
	
	return false;

}

/***********************************************************************
 *
 * FUNCTION:    CollapseMoveResizeDialog
 *
 *	The user has just opened or closed the Active Input area.
 *	Now we need to move the draw window to keep the dialod on the bottom of the screen. 
 *	This will move the form down to the bottom
 *
 *	We adjust the dialog to fill the screen left to right
 *
 *
 * DESCRIPTION: Moves form for active input
 *
 * PARAMETERS:  frmP - a pointer to a FormType struct
 				isModal defaults to modal dialog
 				returnOffsetX, returnOffsetY - returns change in size of form to be used in relocating/resizing form objects
 *
 * RETURNED:    Boolean - true if resize was needed, else false
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			EZE			9/10/02			initial 
 *
 ***********************************************************************/
static Boolean CollapseMoveResizeDialog(FormType* frmP, Boolean isModal, Int16* returnOffsetX, Int16* returnOffsetY)
{
	Coord			drawAreaHeightCoords, drawAreaWidthCoords;
	RectangleType	formDrawWindowRect;
	Int16			offsetCoordsX, offsetCoordsY;
	WinHandle		formDrawWindowH;
	
	WinGetDisplayExtent( &drawAreaWidthCoords, &drawAreaHeightCoords);
	
	formDrawWindowH = WinGetWindowHandle( frmP );
	WinGetBounds( formDrawWindowH, &formDrawWindowRect );
	
	offsetCoordsX = drawAreaWidthCoords - formDrawWindowRect.extent.x - formDrawWindowRect.topLeft.x;	
	offsetCoordsY = drawAreaHeightCoords - formDrawWindowRect.extent.y - formDrawWindowRect.topLeft.y;	
	
	if (isModal)
	{
		offsetCoordsX -=2;
		offsetCoordsY -=2;
	}
	
	*returnOffsetX = offsetCoordsX;
 	*returnOffsetY = offsetCoordsY;
	
	if (offsetCoordsX || offsetCoordsY)
	{

		formDrawWindowRect.extent.x += offsetCoordsX;
		formDrawWindowRect.topLeft.y += offsetCoordsY;

		// Change current draw window to match the display extent (app's drawing area)
		WinSetBounds( formDrawWindowH, &formDrawWindowRect );
		
		return true;
	}
	
	return false;
}

/***********************************************************************
 *
 * FUNCTION:    CollapseMoveResizeFormObject
 *
 *  
 *
 *
 *
 * DESCRIPTION: Move form object by offset
 *
 * PARAMETERS:  frmP - a pointer to a FormType struct
 				objectID - ID of object
 				moveOffsetCoordsX, moveOffsetCoordsY - offset to move by
 				resizeOffsetCoordsX, resizeOffsetCoordsY - offset to resize by
 *
 * RETURNED:    void
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			EZE			9/10/02			initial 
 *
 ***********************************************************************/
static void CollapseMoveResizeFormObject(FormType* frmP, UInt16 objectID, 
										Int16 moveOffsetCoordsX, Int16 moveOffsetCoordsY,
										Int16 resizeOffsetCoordsX, Int16 resizeOffsetCoordsY)
{
	
	RectangleType objectRect;

	FrmGetObjectBounds(frmP, FrmGetObjectIndex(frmP, objectID), &objectRect);
	
	objectRect.topLeft.x += moveOffsetCoordsX;
	objectRect.topLeft.y += moveOffsetCoordsY;
	objectRect.extent.x += resizeOffsetCoordsX;
	objectRect.extent.y += resizeOffsetCoordsY;	
	
	FrmSetObjectBounds(frmP, FrmGetObjectIndex(frmP, objectID), &objectRect);

}



/***********************************************************************
 *
 * FUNCTION:    CollapseMoveResizeFormObject
 *	Form bitmap objects need to be handled differently then other form objects
 *  
 *
 *
 *
 * DESCRIPTION: Move form object by offset
 *
 * PARAMETERS:  frmP - a pointer to a FormType struct
 				objectID - ID of object
 				moveOffsetCoordsX, moveOffsetCoordsY offset to move object by
 *
 * RETURNED:    void
 *
 * REVISION HISTORY:
 *			Name		Date		Description
 *			----		----		-----------
 *			EZE			5/20/03			initial 
 *
 ***********************************************************************/
static void CollapseMoveFormBitmapObject(FormType* frmP, UInt16 objectID, 
										Int16 moveOffsetCoordsX, Int16 moveOffsetCoordsY)
{
	//Form Bitmaps just need to be repositioned. 
	Coord x, y;

	FrmGetObjectPosition(frmP, FrmGetObjectIndex(frmP, objectID), &x, &y);
	
	x += moveOffsetCoordsX;
	y += moveOffsetCoordsY;
	
	FrmSetObjectPosition(frmP, FrmGetObjectIndex(frmP, objectID), x, y);

}

/************************
*
*************************/
static Err CollapseDisplayResizedEventCallback( SysNotifyParamType *notifyParamsP )
{
	//uniquely post back a winDisplayChangedEvent in response to the notification
	//PinMgr 1.0 only posts the notification while PinMgr 1.1 posts back. By doing it this way 
	//your code need only handle the winDisplayChangedEvent
	EventType eventToAdd;
	
	MemSet(&eventToAdd, sizeof(EventType), 0);

	eventToAdd.eType = (eventsEnum) winDisplayChangedEvent;
	
	EvtAddUniqueEventToQueue(&eventToAdd, 0, true);
	
	return 0;
}


///////////////////////////
//This is a fairly generic gadget handler. The gadget is part of this project because it represents 
//the type of object that might want to resize to take advantage of the extended sisze of the screen. 
//there is nothing in the gadget code here that is specific to the collapsible input area functionality.
//It just takes pen input and draws.
//////////////////////////
#pragma mark -
static Boolean TheGadgetHandler(FormGadgetTypeInCallback* pGadget,
  	UInt16 cmd, void* pParam)
{
  Boolean handled;

  //   the gadget handler is called with one of 4 cmd:
  //   formGadgetDrawCmd to draw and initialize the gadget
  //   formGadgetHandleEventCmd in response to a gadget tap or an
  //	event
  //     keyed by your application
  //   formGadgetEraseCmd if there is any custom screen
  //	erasing that needs
  //     to be done when it is erased
  //   formGadgetDeletionCmd to clean up any memory
  //	used for the gadget

  //////////////////////////////////
  //use formGadgetDrawCmd as a chance to initialize, draw, or
  //redraw your gadget
  //////////////////////////////////
  switch (cmd)
  {
  case formGadgetDrawCmd:
     //initialize the gadget data or redraw the gadget

     WinDrawRectangleFrame(rectangleFrame, &(pGadget->rect));
     handled = true;
     break;

     //////////////////////////////////
     //cmd is formGadgetHandleEventCmd when the gadget
     //is asked to handle an
     //event that has come in to it.Either it is a
     //response to a tap in the
     //gadgets bounds, or the program has sent something
     //over to be handled.
     //We can tell which one of these it is by looking at
     //the eType of pParam.
     //////////////////////////////////

  case formGadgetHandleEventCmd:
     //you need to cast pParam to an EventType* to use it
     EventType* pToEvent = (EventType*) pParam;

     //pToEvent points to the event we need to handle.
     //if it is eType
     //frmGadgetEnterEvent then there was a tap in the
     //gadget's bounds

     if (pToEvent->eType == frmGadgetEnterEvent)
     {
        //you may find it useful to track if they
        //lift the pen still
        //within the boundaries of the gadget
        Boolean isPenDown = true;
        Int16 newPointX, newPointY, oldPointX, oldPointY;
        
        
        EvtGetPen(&oldPointX, &oldPointY,
           	&isPenDown);
           	
        UInt16 ticksPerSec = SysTicksPerSecond();

        //track the pen down event
        while (isPenDown){
           EvtGetPen(&newPointX, &newPointY,
           	&isPenDown);
           
           //if both pen points are in thegadget rect, draw a line	
           if (RctPtInRectangle(oldPointX, oldPointY, &(pGadget->rect)) && 
           			RctPtInRectangle(newPointX, newPointY, &(pGadget->rect)))
           {
           		WinDrawLine(oldPointX, oldPointY, newPointX, newPointY);
           }
           
           oldPointX = newPointX;
           oldPointY = newPointY;

           //it is a good idea to put a delay such
           //that the system does
           //not need to fetch pen events more often
           //then need be
           SysTaskDelay(ticksPerSec / 10);
        }

     }
     else if (pToEvent->eType == frmGadgetMiscEvent)
     {

     }

     handled = true;
     break;

  //////////////////////////////////
  //This is sent to erase the gadget. Generally,
  //FrmHideObject takes care of
  //hiding the object, so return false.
  ///////////////////////////////////
  case formGadgetEraseCmd:
     //erase the frame drawn around the gadget
     WinEraseRectangleFrame (rectangleFrame,
     	&(pGadget->rect));
     handled = false;
     break;

  ////////////////////////////////
  //When the gadget is being deleted... So clean up any
  //memory allocated.
  /////////////////////////////////
  case formGadgetDeleteCmd:

     handled = true;
     break;

  default:
     break;

  }//Switch(cmd)

  return handled;
}


/**************************
*Resizes the form and moves/resizes the form objects. Returns true if the form needed resizing.
***************************/
static Boolean MainFormResize(FormPtr frmP)
{
	Int16 horizontalOffset, verticalOffset;
	
	//resize the form. Note that this function returns the vert and horiz offsets the form was resized by
	Boolean formHasChanged = CollapseResizeForm(frmP, false, &horizontalOffset, &verticalOffset);
	
	if (formHasChanged)
	{
		//Vertically Move objects by offset
		//this is good for objects that are meant to be
		//"stuck" to the bottom of forms like buttons
		//These buttons are left justified so leave the horizontal offset alone
		//no resizing of button needed
		CollapseMoveResizeFormObject(frmP, MainGuessButton, 0, verticalOffset, 0, 0);
		CollapseMoveResizeFormObject(frmP, MainAllDoneButton, 0, verticalOffset, 0, 0);

		//vertically and horizontally resize objects like gadgets, tables or lists that 
		//can take advantage of being larger
		//In this case the draw gadget will resize but not move.
		CollapseMoveResizeFormObject(frmP, MainDrawGadget, 0, 0, horizontalOffset, verticalOffset);
		
		//Some objects should be horizontally or vertically moved such that they stay centered on another 
		//form object. So move them by offset/2
		CollapseMoveResizeFormObject(frmP, MainDrawTextLabel, horizontalOffset/2, 0, 0, 0);
		
		//Form bitmaps need special handling because their bounds.extent will not change and
		//because trying to query their bounds before a form has draw will result in an error
		CollapseMoveFormBitmapObject(frmP, MainFaceBitMap, 0, verticalOffset/2);

		//Text fields will need to have their word wrapping recalculated after they are resized
		//For vertical resizing this is less important, but if a text field is resized horizontally
		//you will need to recalculate the word wrapping.
		CollapseMoveResizeFormObject(frmP, MainAtTheTopField, 0, 0, horizontalOffset, 0);
		FldRecalculateField((FieldType*)GetObjectPtr(MainAtTheTopField), false);
		
		
	}

	return formHasChanged;
}


 

/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr frmP)
{
	//Set some default text for the field to test word wrapping.
	SetTextPtr((FieldType*) GetObjectPtr(MainAtTheTopField), "This is some sample text that should need to word wrap", false);

	MainFormResize(frmP);
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutStarterApp:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	Boolean needToRedraw;
	FormPtr frmP;
	Int16 offsetX, offsetY;
	UInt16 oldPinTriggerState;

	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			
			//set the form to handle collapsible input area
			CollapseUtilSetState(frmP, collapseStateUser);
		
			MainFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
			
		case ctlSelectEvent:
			switch (eventP->data.ctlSelect.controlID)
				{
				case MainGuessButton:
					MyInfoAlert("I think it looks like a fish riding a unicycle");
					
					frmP = FrmGetActiveForm();
					
					//I am not saving the drawing in the gadget so hide/show
					//will erase it 
					FrmHideObject(frmP, FrmGetObjectIndex(frmP, MainDrawGadget));
					FrmShowObject(frmP, FrmGetObjectIndex(frmP, MainDrawGadget));
					
					break;
					
				case MainAllDoneButton:
					frmP = FrmInitForm(AllDoneForm);
					
					//Dialogs can be initialized to take advantage of the the collapsed 
					//input area much the same way normal forms are

					//If you do nothing the dialog will bring the input area up as a legacy 
					//form. Meaning it will bring up the input are and lock the trigger.
					
					CollapseUtilSetState(frmP, collapseStateUser);
					CollapseMoveResizeDialog(frmP, true, &offsetX, &offsetY);
					
					//When placing the dialog at the bottom of the screen lock the 
					//trigger unless the dialog has its own form handler. If you do use a 
					//form handler for the dialog you can move the dialog up and down in the
					//same way you would resize a form. However, by default, 
					//if you are calling FrmDoDialog and the input area trigger is left unlocked,
					//the input area could be raised to cover up your dialog.
					
					//Note: it would also be a good idea to lock the rotation as well
					//look in the TapWave header files for
					//SysSetOrientationTriggerState
					
					
					oldPinTriggerState = PINGetInputTriggerState();
					PINSetInputTriggerState(pinInputTriggerDisabled);
					
			      	// open the dialog, and wait until a button is pressed to close it.
			       	UInt16 whichButton = FrmDoDialog(frmP);
					
					//set the trigger back to its state before the dialog
					PINSetInputTriggerState(oldPinTriggerState);

			       	FrmDeleteForm(frmP);
			       	handled=true;					
					break;
				
				default:
					break;
				}
			
			break;
			
		case frmUpdateEvent:
			break;
			
			
		case winDisplayChangedEvent:
		
			//resize and move everything
			frmP = FrmGetActiveForm();
			needToRedraw = MainFormResize(frmP);
			
			//Redraw if there was a change in the form 
			//It is important to make sure a redraw is needed because I post
			//a winDisplayChangedEvent back to the form in response to a winEnterEvent
			//(see AppEventLoop below). If I simply always redraw it would cause problems 
			//with menus 
			if (needToRedraw)
				FrmDrawForm(frmP);
			
			break;

		default:
			break;
		
		}
	
	return handled;
}

#pragma mark -
/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);


		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
			
				//set the gadget handler for the form
  				FrmSetGadgetHandler(frmP, FrmGetObjectIndex(frmP, MainDrawGadget), TheGadgetHandler);
  
  				//set the form handler
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;
	FormType* frmP;
	EventType eventToAdd;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (event.eType == winEnterEvent)
		{
			frmP = FrmGetActiveForm();
			if (frmP)
			{	
				//PinMgr 1.0 allows for a change in input area while a
				//modal dialog had the event loop. So you need to check
				//and see if the size changed while your application did not have the event loop
				//Note that PinMgr 1.1 fixes this issue. In any case, posting a winDisplayChangedEvent
				//will allow the active form's form handler a chance to check and see if a resize has happened
				//and redraw if needed.
				
				MemSet(&eventToAdd, sizeof(EventType), 0);
				eventToAdd.eType = (eventsEnum) winDisplayChangedEvent;
				EvtAddUniqueEventToQueue(&eventToAdd, 0, true);			

			}
		}	
		
		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	StarterPreferenceType prefs;
	UInt16 prefsSize;
	UInt16 cardNo;
	LocalID dbID;
	Err error;
	
	
	
	error = FtrGet(pinCreator, pinFtrAPIVersion, &g_PinMgrVersion);
	if (error)
		g_PinMgrVersion = 0;

	// Read the saved preferences / saved-state information.
	prefsSize = sizeof(StarterPreferenceType);
	if (PrefGetAppPreferences(appFileCreator, appPrefID, &prefs, &prefsSize, true) != 
		noPreferenceFound)
		{
		}
	
	//register for the notification sent when the the win display changes size
	error = SysCurAppDatabase( &cardNo, &dbID );
    ErrFatalDisplayIf( ( error != errNone ), "can't get app db info" );

    error = SysNotifyRegister( cardNo, dbID, sysNotifyDisplayResizedEvent, CollapseDisplayResizedEventCallback, 
    							sysNotifyNormalPriority, NULL );
    ErrFatalDisplayIf( ( error != errNone ), "can't register" );
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	StarterPreferenceType prefs;
	UInt16 cardNo;
	LocalID dbID;
	Err error;

	// Write the saved preferences / saved-state information.  This data 
	// will saved during a HotSync backup.
	PrefSetAppPreferences (appFileCreator, appPrefID, appPrefVersionNum, 
		&prefs, sizeof (prefs), true);
		
		
	// Close all the open forms.
	FrmCloseAllForms ();

	//unregister for the notification sent when the the win display changes size
	error = SysCurAppDatabase( &cardNo, &dbID );
    ErrFatalDisplayIf( ( error != errNone ), "can't get app db info" );
    
	SysNotifyUnregister( cardNo, dbID, sysNotifyDisplayResizedEvent, sysNotifyNormalPriority);

}


/***********************************************************************
 *
 * FUNCTION:    StarterPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;
	UInt32 version;

	error = RomVersionCompatible (kOurMinVersion, launchFlags);
	if (error) return (error);

	//make sure we are running on a system with the PinMgr
	error = FtrGet(pinCreator, pinFtrAPIVersion, &version);
	if (error || !version) 
	{
		MyInfoAlert("Can not run on system with no pin input manager support");
		return errNone;
	}	
		
	
	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return StarterPalmMain(cmd, cmdPBP, launchFlags);
}
