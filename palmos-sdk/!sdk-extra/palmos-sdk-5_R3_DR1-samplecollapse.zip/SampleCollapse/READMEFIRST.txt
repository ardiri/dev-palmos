The sample's CodeWarrior project file is stored as an XML file for
better compatibility accross versions of CodeWarrior. To import the
project via CodeWarrior:

1) Open CodeWarrior

2) Choose "Import Project" from the CodeWarrior's File Menu

3) From the project folder choose the FILE_NAME_HERE.mcp.xml file

4) Then "Name new project as" FILE_NAME_HERE.mcp

This will create a FILE_NAME_HERE.mcp project file for the version of
CodeWarrior that you use. You only need to import the project from the
XML file the one time, after that you will only need open
FILE_NAME_HERE.mcp to launch the project.

**Note - If you are using a Mac and the XML file is present but not
         coming up as an option to import, you may want to use ResEdit
         to confirm that the type and creator ID of the file are set
         correctly to 'TEXT' and 'CWIE'.

For IDEs other than CodeWarrior you can use the included source code
and header files to recreate the application. In most cases you will
have to create the resource files on your own.

