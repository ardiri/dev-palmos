#ifndef _STDLIB_H_
#define _STDLIB_H_

#include "PceNativeCall.h"

#include "armlet__ansi.h"
#include "armlet_stddef.h"

_PTR malloc(size_t nbytes, 
	const void *emulStateP, Call68KFuncType *call68KFuncP);
_PTR calloc(size_t n, size_t size, 
	const void *emulStateP, Call68KFuncType *call68KFuncP);
_PTR realloc(_PTR p, size_t nbytes, 
	const void *emulStateP, Call68KFuncType *call68KFuncP);
_VOID free(_PTR p, 
	const void *emulStateP, Call68KFuncType *call68KFuncP);

#define alloca(size) __builtin_alloca(size)

_VOID       _EXFUN(qsort,(_PTR __base, size_t __nmemb, size_t __size, int(*_compar)(const _PTR, const _PTR)));


int	_EXFUN(abs,(int));
long	_EXFUN(labs,(long));

#endif // _STDLIB_H_
