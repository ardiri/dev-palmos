#ifndef _ENDIAN_H_
#define _ENDIAN_H_

#define __LITTLE_ENDIAN 1234
#define LITTLE_ENDIAN __LITTLE_ENDIAN

#define BYTE_ORDER LITTLE_ENDIAN

#endif
