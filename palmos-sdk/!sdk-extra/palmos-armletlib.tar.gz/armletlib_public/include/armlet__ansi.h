#ifndef _ANSIDECL_H_
#define _ANSIDECL_H_


#ifndef __IMPORT
#define __IMPORT
#endif


#define _PTR                         void *
#define _AND                         ,
#define	_CONST		const
#define _VOID                        void
#define	_EXFUN(name, proto)		name proto
#define	_DEFUN(name, arglist, args)	name(args)

#ifndef _PARAMS
#define _PARAMS(paramlist)              paramlist
#endif


#endif //_ANSIDECL_H_
