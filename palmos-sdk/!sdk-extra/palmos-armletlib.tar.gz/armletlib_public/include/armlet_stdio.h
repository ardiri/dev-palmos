#ifndef __STDIO_H__
#define __STDIO_H__

#include "armlet_stddef.h"
#include "armlet_PalmOS.h"

//#define FILE void

#ifndef SEEK_SET
#define SEEK_SET        0       /* set file offset to offset */
#endif
#ifndef SEEK_CUR
#define SEEK_CUR        1       /* set file offset to current plus offset */
#endif
#ifndef SEEK_END
#define SEEK_END        2       /* set file offset to EOF plus offset */
#endif

#define EOF            -1

size_t fread(void *bufp, size_t size, size_t nmemb, FileRef datasource, int *errnop, const void *emulStateP, Call68KFuncType *call68KFuncP);
int fseek(FileRef datasource, long offset, int whence, const void *emulStateP, Call68KFuncType *call68KFuncP);
int fclose(FileRef datasource);
int ftell(FileRef datasource);

#endif // __STDIO_H__
