#ifndef __STRING_H__
#define __STRING_H__

#include "armlet__ansi.h"
#include "armlet_stddef.h"

_PTR 	 _EXFUN(memchr,(const _PTR, int, size_t));
int 	 _EXFUN(memcmp,(const _PTR, const _PTR, size_t));
_PTR 	 _EXFUN(memcpy,(_PTR, const _PTR, size_t));
_PTR	 _EXFUN(memmove,(_PTR, const _PTR, size_t));
_PTR	 _EXFUN(memset,(_PTR, int, size_t));

char 	*_EXFUN(strcat,(char *, const char *));
char 	*_EXFUN(strcpy,(char *, const char *));
size_t	 _EXFUN(strlen,(const char *));
//#define strlen __builtin_strlen

//_PTR memset(const _PTR p, int i, size_t size);
//_PTR memmove(_PTR p, const _PTR q, size_t s);
//_PTR memcpy(_PTR p, const _PTR q, size_t s);
//char *strcat(char * c, const char *d);
//size_t strlen(const char * c);
//char strcpy(char * c, const char * d);
//_PTR memchr(const _PTR p, int i, size_t s);
//int memcmp(const _PTR p, const _PTR q, size_t s);
//int toupper(int c);

#endif // __STRING_H__
