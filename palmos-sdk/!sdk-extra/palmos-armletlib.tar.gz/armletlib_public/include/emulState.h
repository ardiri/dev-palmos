typedef struct EmulStateTag {
        // Current instruction
        // At the top so its visible in the debugger
        // in the same window as the registers below
        UInt32                                          instr;


        // Basic registers
        UInt32                                          regD0;
        UInt32                                          regD1;
        UInt32                                          regD2;
        UInt32                                          regD3;
        UInt32                                          regD4;
        UInt32                                          regD5;
        UInt32                                          regD6;
        UInt32                                          regD7;
        UInt32                                          regA0;
        UInt32                                          regA1;
        UInt32                                          regA2;
        UInt32                                          regA3;
        UInt32                                          regA4;
        UInt32                                          regA5;
        UInt32                                          regA6;
        UInt32                                          regA7;
                        // aka stack pointer
        UInt32                                          regPC;


} EmulStateType;
