#ifndef _ARMLETPALMOS_H_
#define _ARMLETPALMOS_H_

#include "PceNativeCall.h"
#include "endianutils.h" // for byte-swapping macros

// typedefs
typedef char           Int8;
typedef unsigned char  UInt8;
typedef short          Int16;
typedef unsigned short UInt16;
typedef long           Int32;
typedef unsigned long  UInt32;

typedef UInt16 Err;

typedef UInt32 FileRef;

#define vfsOriginBeginning		0	// from the beginning (first data byte of file)
#define vfsOriginCurrent		1	// from the current position
#define vfsOriginEnd				2	// from the end of file (one position beyond last data byte, only negative offsets are legal)


// prototypes for our OS call convenience function
void* PalmOS_MemPtrNew(unsigned long sizeLE, const void *emulStateP, Call68KFuncType *call68KFuncP);
Err PalmOS_MemPtrFree(void *pLE, const void *emulStateP, Call68KFuncType *call68KFuncP);
Err PalmOS_MemPtrResize(void *pLE, UInt32 newSizeLE, const void *emulStateP, Call68KFuncType *call68KFuncP);
UInt32 PalmOS_MemPtrSize(void* pLE, const void *emulStateP, Call68KFuncType *call68KFuncP);

Err PalmOS_VFSFileClose(FileRef fileRefBE, const void *emulStateP, Call68KFuncType *call68KFuncP);
Err PalmOS_VFSFileRead(FileRef fileRefBE, UInt32 numBytesLE, void *bufPLE, UInt32 *numBytesReadPLE, const void *emulStateP, Call68KFuncType *call68KFuncP);
Err PalmOS_VFSFileSeek(FileRef fileRefBE, UInt16 originLE, Int32 offsetLE, const void *emulStateP, Call68KFuncType *call68KFuncP);
Err PalmOS_VFSFileTell(FileRef fileRefBE, UInt32 *filePosPLE, const void *emulStateP, Call68KFuncType *call68KFuncP);

#endif // _ARMLETPALMOS_H_
