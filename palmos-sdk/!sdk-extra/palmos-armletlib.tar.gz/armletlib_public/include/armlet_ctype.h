#ifndef __CTYPE_H___
#define __CTYPE_H___

#include "armlet__ansi.h"

int _EXFUN(toupper, (int __c));
int _EXFUN(islower, (int __c));

#endif // __CTYPE_H___
