#include "armlet_stdio.h"
#include "armlet_PalmOS.h"

size_t fread(void *bufp, size_t size, size_t nmemb, FileRef datasource, int *errnop, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	UInt32 bytesToRead = size * nmemb;
	UInt32 bytesRead = 0;

	*errnop = PalmOS_VFSFileRead(datasource, bytesToRead, bufp, &bytesRead, emulStateP, call68KFuncP);
	
	return bytesRead;
}
