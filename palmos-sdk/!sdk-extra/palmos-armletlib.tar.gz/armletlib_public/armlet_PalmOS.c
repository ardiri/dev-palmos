#include "PceNativeCall.h"
#include "endianutils.h" // for byte-swapping macros

#include "armlet_PalmOS.h"

// from CoreTraps.h
#define sysTrapMemPtrNew    0xA013
#define sysTrapMemChunkFree 0xA012
#define sysTrapMemMove      0xA026
#define sysTrapMemPtrResize 0xA01C
#define sysTrapMemPtrSize   0xA016


void* PalmOS_MemPtrNew(unsigned long sizeLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	// First, we must declare the argument(s) that will be passed to the OS call.
	// In this case, we're calling MemPtrNew, so we need a size argument.

	// Remember that this code is compiled by an ARM compiler (little endian),
	// and MemPtrNew expects its argument to be big endian, so we swap it.
	unsigned long sizeBE = ByteSwap32(sizeLE);

	return ((void *)((call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapMemPtrNew),
		&sizeBE,
		4 | kPceNativeWantA0))); // must OR in the constant because MemPtrNew returns a pointer
}

Err PalmOS_MemPtrFree(void *pLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	void *pBE;

	pBE = (void*)ByteSwap32(pLE);

	return (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapMemChunkFree),
		&pBE,
		4);
}

Err PalmOS_MemPtrResize(void *pLE, UInt32 newSizeLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	UInt32 args[2];
	
	args[0] = ByteSwap32(pLE);
	args[1] = ByteSwap32(newSizeLE);

	return (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapMemPtrResize),
		&args,
		8);
}

UInt32 PalmOS_MemPtrSize(void* pLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	void *pBE;
	
	pBE = (void*)ByteSwap32(pLE);
	
	return (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapMemPtrSize),
		&pBE,
		4);
}


#define sysTrapFileSystemDispatch					0xA348  /* Reserved for FileSystemMgr (was sysTrapSysReserved3) */

#define vfsTrapFileClose				4
#define vfsTrapFileRead					6
#define vfsTrapFileSeek					10
#define vfsTrapFileTell					12

#include "emulState.h"

Err PalmOS_VFSFileClose(FileRef fileRefBE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	FileRef fileRefBEcopy = fileRefBE;
	
	// load the trap selector into D2
	((EmulStateType*)emulStateP)->regD2 = vfsTrapFileClose;

	return (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapFileSystemDispatch),
		&fileRefBEcopy,
		4);
}

Err PalmOS_VFSFileRead(FileRef fileRefBE, UInt32 numBytesLE, void *bufPLE, UInt32 *numBytesReadPLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	Err    result;
	UInt32 numBytesReadBE;

	UInt32 args[4];

	args[0] = fileRefBE;
	args[1] = ByteSwap32(numBytesLE);
	args[2] = ByteSwap32(bufPLE);
	args[3] = ByteSwap32(&numBytesReadBE);

	// load the trap selector into D2
	((EmulStateType*)emulStateP)->regD2 = vfsTrapFileRead;
	
	result = (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapFileSystemDispatch),
		&args,
		16);
		
	*numBytesReadPLE = ByteSwap32(numBytesReadBE);

	return result;
}

Err PalmOS_VFSFileSeek(FileRef fileRefBE, UInt16 originLE, Int32 offsetLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	UInt8 args[10];
	
	*((UInt32*)(&(args[0]))) = fileRefBE;
	*((UInt16*)(&(args[4]))) = ByteSwap16(originLE);
	WriteUnaligned32(&(args[6]), offsetLE);
	
	// load the trap selector into D2
	((EmulStateType*)emulStateP)->regD2 = vfsTrapFileSeek;
	
	return (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapFileSystemDispatch),
		&args,
		16);
}

Err PalmOS_VFSFileTell(FileRef fileRefBE, UInt32 *filePosPLE, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	Err    result;
	UInt32 filePosBE;
	UInt32 args[2];
	
	args[0] = (UInt32)fileRefBE;
	args[1] = (UInt32)ByteSwap32(&filePosBE);

	// load the trap selector into D2
	((EmulStateType*)emulStateP)->regD2 = vfsTrapFileTell;

	result = (call68KFuncP)(
		emulStateP,
		PceNativeTrapNo(sysTrapFileSystemDispatch),
		&args,
		8);
	
	*filePosPLE = ByteSwap32(filePosBE);

	return result;
}
