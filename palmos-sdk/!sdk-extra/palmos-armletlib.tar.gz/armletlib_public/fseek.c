#include "armlet_stdio.h"
#include "armlet_PalmOS.h"

int fseek(FileRef datasource, long offset, int whence, const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	Err result;
	
	result = PalmOS_VFSFileSeek(datasource, whence, offset, emulStateP, call68KFuncP);
	
	if (result == 0) return 0;
	
	//else
	return EOF;
}
