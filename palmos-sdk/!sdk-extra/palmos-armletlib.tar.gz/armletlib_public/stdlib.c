#include "armlet_stdlib.h"
#include "armlet_string.h"

#include "armlet_PalmOS.h"

#include "PceNativeCall.h"

_PTR malloc(size_t nbytes,
	const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	return PalmOS_MemPtrNew(nbytes, emulStateP, call68KFuncP);
}

_PTR calloc(size_t n, size_t size,
	const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	return malloc(n * size, emulStateP, call68KFuncP);
}

_PTR realloc(_PTR p, size_t nbytes,
	const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	Err result;
	_PTR newp;
	size_t oldsize;

	// special case when nbytes=0 ==> free
	if (nbytes == 0)
		{
			PalmOS_MemPtrFree(p, emulStateP, call68KFuncP);
			return NULL;
		}
	
	if (p == NULL) return malloc(nbytes, emulStateP, call68KFuncP);
	
	result = PalmOS_MemPtrResize(p, nbytes, emulStateP, call68KFuncP);
	if (result == 0)
		{
			// success
			return p;
		}

	// failed; try to allocate a new chunk
	newp = PalmOS_MemPtrNew(nbytes, emulStateP, call68KFuncP);
	if (newp == 0) return NULL;
	oldsize = PalmOS_MemPtrSize(p, emulStateP, call68KFuncP);
	memmove(newp, p, oldsize);
	PalmOS_MemPtrFree(p, emulStateP, call68KFuncP);
	return newp;
}


_VOID free(_PTR p,
	const void *emulStateP, Call68KFuncType *call68KFuncP)
{
	PalmOS_MemPtrFree(p, emulStateP, call68KFuncP);
}

int
_DEFUN (abs, (i), int i)
{
  return (i < 0) ? -i : i;
}

long
_DEFUN (labs, (x),
	long x)
{
  if (x < 0)
    {
      x = -x;
    }
  return x;
}
#include "newlib/qsort.c"
