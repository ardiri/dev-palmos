#include "armlet_ctype.h"

int
_DEFUN(toupper,(c),int c)
{
  return islower(c) ? c - 'a' + 'A' : c;
}

int
_DEFUN(islower,(c),int c)
{
	if (('a' <= c) && (c <= 'z')) return 1;
	return 0;
}
