#include <PalmOs.h>
#include <PalmCompatibility.h>

#include "PceNativeCall.h"

static unsigned long PceNativeResourceCall(DmResType resType, DmResID resID, void *userDataP)
{
	MemHandle armH;
	MemPtr    armP;
	unsigned long    result = 0x0;
	
	void *pExec;
	
   // running on ARM; call the actual ARM resource
	if (!(armH = DmGetResource(resType, resID)))
      return 0;

	if (!(armP = MemHandleLock(armH)))
      return 0;
	
	pExec = MemPtrNew (MemHandleSize (armH));
	MemMove (pExec, armP, MemHandleSize (armH));
	
	result = PceNativeCall(pExec, userDataP);

	MemPtrFree (pExec);

	MemHandleUnlock(armH);
	DmReleaseResource(armH);
		
	return result;
}

void SayHello (unsigned int uCount)
{
   short nCharWidth = 0;
   short width = 0, height = 0;
      
   unsigned long   uValue;
   unsigned short uHi, uLo;
      
   char *pText = NULL;
   char tcMethod;

   if (uCount & 1)
   	  {
   	  tcMethod = 'P';
      pText = (char*) MemPtrNew(40);
      }
   else
      {
      tcMethod = 'A';
      if (!(pText = (char *) PceNativeResourceCall ('ARMC', 1000, (void *) 0x0)))
         pText = NULL;
      }
      
	if (!pText)     
		{
		pText = (char*) MemPtrNew(40);
		tcMethod = 'B';
		} 
      
   uValue = (unsigned long) pText;
   uHi = ((uValue >> 16) & 0xffff);
   uLo = ((uValue >>  0) & 0xffff);
      
   StrPrintF (pText, "Hello Palm! (%c %04d) 0x%04x%04x", tcMethod, uCount, uHi, uLo);
           
   nCharWidth = FntCharsWidth(pText, StrLen(pText));
   WinGetWindowExtent (&width, &height);
      
   WinDrawChars(pText, StrLen(pText), (width / 2) - (nCharWidth / 2), height/2);
      
   MemPtrFree(pText);
}

UInt32 PilotMain (UInt16 launchCode, MemPtr launchParameters, UInt16 launchFlags) 
{ 
   unsigned int uCount = 0;

   EventType event; 
   if (launchCode == sysAppLaunchCmdNormalLaunch) 
      { 	  
      SayHello(uCount++);
      
      do 
         { 
         EvtGetEvent( &event, evtWaitForever ); 
            
   		 if (event.eType == 1)
   		    SayHello(uCount++);

         SysHandleEvent( &event ); 
        } while (event.eType != appStopEvent); 
    } 
    return 0; 
}