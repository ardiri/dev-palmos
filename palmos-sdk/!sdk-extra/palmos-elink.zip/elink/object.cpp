#include "stdafx.h"

#include "ObjectFile.h"
#include "Elf\Elf.h"

#include "library.h"
#include "object.h"

#include "elink.h"

int object (CObjectFile **pHead, CObjectFile **pTail, TCHAR *pFile, DWORD dwOffset)
{
   FILE *pObj;

   if (!(pObj = (FILE *) fopen (pFile, "rb")))
      return 0;   

   if (fseek (pObj, dwOffset, SEEK_SET))
      return 0;

   // Read first two byes of file in an attempt to determine file type
   unsigned short uType;

   if (!(fread (&uType, sizeof (uType), 1, pObj)))
      {fclose (pObj); return 0;}

   CObjectFile *pObject;
   switch (uType)
      {
      case 0x457f : pObject = (CObjectFile *) new CElf (pObj, dwOffset); break;
      }

   if (!pObject->IsValid ())
      {delete (pObject); return 0;}

   printf ("File: \"%s\"\n", pFile);

   pObject->m_pPred = *pTail;

   if (pHead)
      {
      if (!(*pHead))
         *pHead = pObject;
      }

   if ( pTail)
      {
      if (*pTail)
        (*pTail)->m_pNext = pObject;

       *pTail = pObject;
      }

   return 1;
}

DWORD locate_symbol (CObjectFile *_object, TCHAR *pName)
{
   DWORD dwSymTable = 0;
   for (dwSymTable = _object->SymbolTbl (dwSymTable); dwSymTable; dwSymTable = _object->SymbolTbl (++dwSymTable))
      {
      DWORD dwSymbol;
      if (!(dwSymbol = _object->SymbolFnd (dwSymTable, pName)))
         continue;

      return ((dwSymTable << 24) | dwSymbol);
      }

//   printf ("Unable to locate symbol \"%s\"!\n", pName);

   return 0;
}

int symbol_find (CObjectFile *pHead, TCHAR *pSymbol)
{
   CObjectFile   *_object;
   for (_object = pHead; _object; _object = _object->m_pNext)
      {
      DWORD dwSymbol;
      if (!(dwSymbol = locate_symbol (_object, pSymbol)))
         continue;

      DWORD dwInfo;
      dwInfo = _object->SymbolSec ((dwSymbol >> 24) & 0x0000ff, (dwSymbol >> 00) & 0xffffff);
            
      if (dwInfo == SHN_UNDEF)
         continue;
      
      return dwInfo;      
      }

   // Ok, I have search all symbol files, and the symbol is not found.
   return 0;
}

int library_find (TCHAR *pSymbol)
{
   struct Library *_library;
   for (_library = pLibHead; _library; _library = _library->pNext)
      {
      if (strcmp (_library->tcImport, pSymbol))
         continue;

      if (!(object (&pObjHead, &pObjTail, _library->tcPath, _library->dwOffset)))
         continue;

      return symbol_find (pObjTail, pSymbol);
      }

   // It was not in any of the import libraries!
   return 0;
}

int symbols (CObjectFile *pHead, CObjectFile *pDest)
{
   CObjectFile   *_object;
   for (_object = pHead; _object; _object = _object->m_pNext)
      {
      DWORD dwSymTable = 0;
      for (dwSymTable = _object->SymbolTbl (dwSymTable); dwSymTable; dwSymTable = _object->SymbolTbl (++dwSymTable))
         {
         DWORD dwIndex;

         while ((dwIndex = _object->SymbolUnd(dwSymTable)))
            {            
            TCHAR *pSymbol = _object->SymbolName (dwSymTable, dwIndex);

            // Ok, I need to search all objects for the current symbol
            DWORD dwType;            
            dwType = symbol_find (pDest, pSymbol);
   
            if (!dwType)
               dwType = symbol_find (pHead, pSymbol);

            if (!dwType)
               dwType = library_find (pSymbol);

            if (!dwType)
               printf ("Unable to locate symbol \"%s\"!\n", pSymbol);

            _object->SymbolDef (dwSymTable, dwIndex); 
            }
         }
      }      

   return 1;
}

int size (CObjectFile *pHead, DWORD dwType, DWORD dwAttr)
{
   DWORD dwRtn = 0;

   CObjectFile   *_object;
   for (_object = pHead; _object; _object = _object->m_pNext)
      {
      for (UINT uIndex = 0; uIndex < _object->SectionNum(); uIndex++)
         {
         if ((_object->SectionType(uIndex) != dwType) || (_object->SectionAttr(uIndex) != dwAttr))
            continue;

         dwRtn += _object->SectionSize (uIndex);
         }
      }  

   return dwRtn;
}

int cpy (CObjectFile *pHead, CObjectFile *pDest, TCHAR *pName)
{
   DWORD dwSectionD;
   if (!(dwSectionD = pDest->SectionFind (pName)))
      return 0;

   DWORD dwRtn = 0;

   for (CObjectFile *_object = pHead; _object; _object = _object->m_pNext)
      {
      DWORD dwSectionO;

      // Find the correct "section" in _object
      if (!(dwSectionO = _object->SectionFind (pName)))
         continue; // Section not found

      _object->SectionLink (dwSectionO, pDest->SectionInfo (dwSectionD));

      // Find all the "symbols" in "section" and copy them to pDest object
      DWORD dwSymTable = 0;
      for (dwSymTable = _object->SymbolTbl (dwSymTable); dwSymTable; dwSymTable = _object->SymbolTbl (++dwSymTable))
         {
         DWORD dwExpectedValue = 0;

         while (dwExpectedValue != _object->SectionSize (dwSectionO))
            {
            for (DWORD dwIndex = 1; dwIndex < _object->SymbolCnt(dwSymTable); dwIndex++)
               {
               if (_object->SymbolSec(dwSymTable, dwIndex) != dwSectionO)
                  continue;

               if (_object->SymbolVal(dwSymTable, dwIndex) != dwExpectedValue)
                  continue;

               DWORD dwInfo = _object->SymbolInfo (dwSymTable, dwIndex);


               TCHAR *pName = _object->SymbolName (dwSymTable, dwIndex);
               if (!strlen (pName))
                  continue;

               DWORD  dwSize = 0x0;
               TCHAR *pData = _object->SymbolData (dwSymTable, dwIndex, &dwSize);         
 
               DWORD dwSym;
               dwSym = pDest->SymbolAdd (dwSectionD, pName, pData, dwSize, dwInfo);

               dwRtn++;

               dwExpectedValue += dwSize;
               }
            }
         }            
      }

   return dwRtn;
}

/*
int got (CObjectFile *pHead, CObjectFile *pDest, TCHAR *pName, DWORD dwOffset)
{
   DWORD dwSectionD;
   if (!(dwSectionD = pDest->SectionFind (_T(".got"))))
      return 0;

   for (CObjectFile *_object = pHead; _object; _object = _object->m_pNext)
      {
      DWORD dwSectionO;

      // Find the correct "section" in _object
      if (!(dwSectionO = _object->SectionFind (pName)))
         continue; // Section not found

      // Find all the "symbols" in "section" and copy them to pDest object
      DWORD dwSymTable = 0;
      for (dwSymTable = _object->SymbolTbl (dwSymTable); dwSymTable; dwSymTable = _object->SymbolTbl (++dwSymTable))
         {
         for (DWORD dwIndex = 1; dwIndex < _object->SymbolCnt(dwSymTable); dwIndex++)
            {
            if (_object->SymbolSec(dwSymTable, dwIndex) != dwSectionO)
               continue;

            TCHAR *pName = _object->SymbolName (dwSymTable, dwIndex);
            if (!strlen (pName))
               continue;                      

            // Locate the symboltable and symbol for pName, and then remove it.
            DWORD dwSymbol;
            if (!(dwSymbol = locate_symbol (pDest, pName)))
               continue;

            // Locate the symbol name in the new object
            pDest->SymbolRem ((dwSymbol >> 24) & 0x0000ff, (dwSymbol >> 00) & 0xffffff);

            DWORD  dwSize = 4;
            DWORD  dwData = _object->SymbolVal (dwSymTable, dwIndex) + dwOffset;

            TCHAR *pData = (TCHAR *) &dwData;

            pDest->SymbolAdd (dwSectionD, pName, pData, dwSize, 0x01);
            }
         }            
      }

   return 1;
}
*/

int got (CObjectFile *pHead, CObjectFile *pDest)
{
   DWORD dwSymTable = 0;
   if (!(dwSymTable = pDest->SymbolTbl (dwSymTable)))
      return 0;


   DWORD dwSize = 0;

   for (CObjectFile *_object = pHead; _object; _object = _object->m_pNext)
      {
      for (DWORD dwSection = 1; dwSection < _object->SectionNum(); dwSection++)
         {
         if (_object->SectionType (dwSection) != SHT_RELA && _object->SectionType (dwSection) != SHT_REL)
            continue;

         // Now cycle thru all 
         // Find all the "symbols" in "section" and copy them to pDest object
         for (DWORD dwIndex = 0; dwIndex < _object->RelocationCnt(dwSection); dwIndex++)
            {
            TCHAR *pRel  = _object->RelocationName (dwSection, dwIndex);

            // dwAddr is based upon this section "dwSectionS" addr
            DWORD dwInfo = _object->RelocationInfo (dwSection, dwIndex);

            DWORD dwSym;
            if (!(dwSym  = pDest->SymbolFnd (dwSymTable,  pRel)))
               continue;

            DWORD dwSec;
            if (!(dwSec  = pDest->SymbolSec (dwSymTable, dwSym)))
               continue;

            if ((pDest->SectionAttr (dwSec) & SHF_EXECINSTR) != SHF_EXECINSTR)
               continue;

            if (ELF32_R_TYPE(dwInfo) == R_ARM_GOT32)
               dwSize += 1;
            }          
         }
      }


   return dwSize;
}


DWORD locate_symbol_value (CObjectFile *_object, TCHAR *pSymbol, DWORD *pAddr)
{
   if (!pAddr)
      return 0;

   DWORD dwSymbol;
   if (!(dwSymbol = locate_symbol (_object, pSymbol)))
      return 0;

   *pAddr += _object->SymbolVal ((dwSymbol >> 24) & 0x0000ff, (dwSymbol >> 00) & 0xffffff);

   return (dwSymbol >> 00) & 0xffffff;
}

int locate_got_value (CObjectFile *pDest, TCHAR *pRel, DWORD dwValue)
{
   struct got *_got = NULL;

   for (_got = pGotHead; _got; _got = _got->pNext)
      {
      if (!(strcmp (_got->tcName, pRel)))
         return _got->dwOffset;
      }

   DWORD dwOffset = 0;

   DWORD dwSymbol;
   if (!(dwSymbol = locate_symbol (pDest, pRel)))
      return 0;

   dwValue += pDest->SectionAddr (pDest->SymbolSec ((dwSymbol >> 24) & 0x0000ff, (dwSymbol >> 00) & 0xffffff));

   if (pDest->SectionType (pDest->SymbolSec ((dwSymbol >> 24) & 0x0000ff, (dwSymbol >> 00) & 0xffffff))  == SHT_NOBITS)
      {
      dwValue = 0;
      for (_got = pGotHead; _got; _got = _got->pNext)
         {
         if ((_got->dwOffset & 0x8000000))
            dwValue += 4;
         }      

      dwValue |= 0x80000000;
      }


   DWORD dwSectionG; // .got section
   if (!(dwSectionG = pDest->SectionFind (_T(".got"))))
      return 0;

   if (!(_got = (struct got *) malloc (sizeof (struct got))))
      return 0;

   if (!pGotHead)
      pGotHead = _got;

   if ( pGotTail)
      {
      pGotTail->pNext = _got;
      dwOffset = pGotTail->dwOffset + 4;
      }   

   memset (_got, 0, sizeof (struct got));

   _got->dwOffset = dwOffset;
   sprintf (_got->tcName, "%s", pRel);
   
   _got->pPred = pGotTail;

   pGotTail    = _got;   

   *pDest->SectionVal (dwSectionG, dwOffset) = dwValue;

   return dwOffset;
}

int rel (CObjectFile *pHead, CObjectFile *pDest, TCHAR *pName)
{
   DWORD dwSectionD;
   if (!(dwSectionD = pDest->SectionFind (pName)))
      return 0;

   DWORD dwSectionG; // .got section
   if (!(dwSectionG = pDest->SectionFind (_T(".got"))))
      return 0;

   for (CObjectFile *_object = pHead; _object; _object = _object->m_pNext)
      {
      DWORD dwSectionS;
      if (!(dwSectionS = _object->SectionFind (pName)))
         continue; // Section not found

      DWORD *pData    = 0;
      
      for (DWORD dwRelTable = 1; dwRelTable < _object->SectionNum(); dwRelTable++)
         {
         if (_object->SectionType (dwRelTable) != SHT_REL) 
            continue;

         if (_object->SectionInfo (dwRelTable) != dwSectionS)
            continue;

         // Find all the "symbols" in "section" and copy them to pDest object
         for (DWORD dwIndex = 0; dwIndex < _object->RelocationCnt(dwRelTable); dwIndex++)
            {
            TCHAR *pRel  = _object->RelocationName (dwRelTable, dwIndex);

            // dwAddr is based upon this section "dwSectionS" addr
            DWORD dwAddr = _object->RelocationAddr (dwRelTable, dwIndex);
            DWORD dwInfo = _object->RelocationInfo (dwRelTable, dwIndex);

            DWORD dwSymbol0 = 0;
            DWORD dwSymbol1 = 0;
            DWORD dwDelta   = 0;
            DWORD dwValue   = 0;

//            printf ("0x%02x: %-30s 0x%08x 0x%04x\n", dwRelTable, pRel, dwAddr, dwInfo);
                        
            

            dwSymbol1 = _object->SectionLink (dwSectionS);

            // Addr points to the actual location in the section that needs to be updated.
            DWORD dwTemp = dwAddr;
            dwAddr = (dwAddr + dwSymbol1) - dwSymbol0;

            // Get the pointer to the dword of the value that needs to be changed.
            if (!(pData = pDest->SectionVal (dwSectionD, dwAddr)))
               continue;            

            // Now, I need to locate the relocation symbol
            if (!(locate_symbol_value (pDest, pRel  , &dwValue )))
               dwValue = (((*pData & 0xffffff) * 4) + 8) + dwSymbol1;


            // Ok, now it all depends upon the relocation type what I need to do.
            switch (ELF32_R_TYPE(dwInfo))
               {
               case R_ARM_PC24  :  dwValue = (((dwValue - dwAddr) - 8) / 4) & 0xffffff;
                                  *pData = ((*pData & 0xff000000) | dwValue); break;

               case R_ARM_ABS32 : *pData = dwValue; break;

               case R_ARM_GOTPC : dwValue = (pDest->SectionAddr (dwSectionG) - (dwSymbol1 + 0x1c));

                                 *pData = dwValue; break;

               case R_ARM_GOT32 : dwValue = locate_got_value (pDest, pRel, dwValue); 
                                  *pData = dwValue; 
                                  break;
               }            
            }        
         }
      }

   return 1;
}
