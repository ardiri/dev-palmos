#include "stdafx.h"

#include "library.h"

#define SWAP32(x) x=((x&0xff000000)>>24)|((x&0x00ff0000)>>8)|((x&0x0000ff00)<<8)|((x&0x000000ff)<<24)

void library (struct Library **pHead, struct Library **pTail, TCHAR *pPath, FILE *pLib)
{
   // Just because
   fseek (pLib, 0x44, SEEK_SET);

   DWORD dwEntries;
   if (!(fread (&dwEntries, sizeof (dwEntries), 1, pLib)))
      return;

   dwEntries = SWAP32(dwEntries);

   TCHAR tcImport[MAX_PATH], tcSkipIt[MAX_PATH];
   DWORD dwOffset = dwEntries * 4 + 0x48;


   for (UINT uIndex = 0; uIndex < dwEntries; uIndex++)
      {
      if (fseek (pLib, dwOffset, SEEK_SET))
         continue;

      fgets (tcImport, sizeof (tcImport), pLib);

      dwOffset += (strlen (tcImport) + 1);

      if (fseek (pLib, 0x48 + (uIndex * 4), SEEK_SET))
         continue;

      DWORD dwRel;
      if (!(fread (&dwRel, sizeof (dwRel), 1, pLib)))
         continue;

      SWAP32 (dwRel);

      if (fseek (pLib, dwRel, SEEK_SET))
         continue;

      fgets (tcSkipIt, sizeof (tcSkipIt), pLib);
      dwRel += (strlen (tcSkipIt) + 0);

      struct Library *_library;
      if (!(_library = (struct Library *) malloc (sizeof (struct Library))))
         continue;

      memset (_library, 0, sizeof (struct Library));

      _library->pPred = *pTail;
      sprintf (_library->tcPath  , "%s", pPath);
      sprintf (_library->tcImport, "%s", tcImport);
      
      _library->dwOffset = dwRel;

      if (pHead)
         {
         if (!(*pHead))
            *pHead = _library;
         }

      if ( pTail)
         {
         if (*pTail)
           (*pTail)->pNext = _library;

         *pTail = _library;
         }
      }
}
