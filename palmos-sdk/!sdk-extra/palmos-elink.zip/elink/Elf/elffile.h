#pragma once

#include "Elf.h"

struct Sections
{
   TCHAR *pName;
   Elf32_Shdr section;
   void  *pData;
};

class CElfFile : public CObjectFile
   {
   public:
               CElfFile (TCHAR *pObjectName = NULL);
      virtual ~CElfFile (void);

   protected:
      Elf32_Ehdr      m_Header;
      BOOL            m_bBigEndian;

      struct Sections *m_pSections;

      BOOL     SectionHeaders (void);
   };