#pragma once

struct Library
   {
   TCHAR tcPath  [MAX_PATH];
   TCHAR tcImport[MAX_PATH];

   DWORD dwOffset;


   struct Library *pNext, *pPred;
   };

struct got 
   {
   TCHAR tcName[MAX_PATH];
   DWORD dwOffset;

   struct got *pNext, *pPred;
   };

extern "C" void library (struct Library* *pHead, struct Library* *pTail, TCHAR *pPath, FILE *pLib);