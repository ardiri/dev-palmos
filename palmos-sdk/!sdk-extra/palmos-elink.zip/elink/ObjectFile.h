#pragma once

class CObjectFile
   {
   public:
               CObjectFile (void);
      virtual ~CObjectFile (void);

               // Create an object from input file.
               CObjectFile (FILE *pFile, DWORD dwOffset = 0);

              void   SetOutput       (TCHAR *pOutput, DWORD dwMode);


      virtual BOOL   IsValid         (void) {return (m_pFile) ? 1:0;}

      // Section Interface
      virtual DWORD  SectionNum   (void)            {return 0;}
      virtual DWORD  SectionType  (DWORD dwSection) {return 0;}
      virtual DWORD  SectionAttr  (DWORD dwSection) {return 0;}
      virtual DWORD  SectionSize  (DWORD dwSection) {return 0;}
      virtual DWORD  SectionSize  (DWORD dwSection, DWORD dwSize) {return 0;}

      virtual DWORD  SectionAddr  (DWORD dwSection) {return 0;}

      virtual DWORD  SectionInfo  (DWORD dwSection) {return 0;}

      virtual DWORD  SectionFind  (TCHAR *pName)    {return 0;}

      virtual DWORD  SectionAdd   (TCHAR *pName, DWORD dwType, DWORD dwAttr, DWORD dwSize, DWORD dwIndex = 1) {return 0;}

      virtual DWORD *SectionVal   (DWORD dwSection, DWORD dwOffset) {return 0;}

      virtual DWORD  SectionLink  (DWORD dwSection)                 {return 0;}
      virtual DWORD  SectionLink  (DWORD dwSection, DWORD dwOffset) {return 0;}


      // Symbol  Interface
      virtual DWORD  SymbolTbl       (DWORD dwStart   ) {return 0;}
      virtual DWORD  SymbolCnt       (DWORD dwSymTable) {return 0;}

      virtual DWORD  SymbolAdd       (DWORD dwSection, TCHAR *pName, TCHAR *pData, DWORD dwSize, DWORD dwInfo) {return 0;}
      virtual DWORD  SymbolRem       (DWORD dwSymTable, DWORD dwSymbol) {return 0;}

      virtual DWORD  SymbolDef       (DWORD dwSymTable, DWORD dwSymbol) {return 0;}
      virtual DWORD  SymbolUnd       (DWORD dwSymTable) {return 0;}
      virtual DWORD  SymbolFnd       (DWORD dwSymTable, TCHAR *pSymbol) {return 0;}      

      virtual TCHAR *SymbolName      (DWORD dwSymTable, DWORD dwSymbol) {return NULL;}
      virtual TCHAR *SymbolData      (DWORD dwSymTable, DWORD dwSymbol, DWORD *dwSize) {return 0;}

      virtual DWORD  SymbolSec       (DWORD dwSymTable, DWORD dwSymbol) {return 0;}
      virtual DWORD  SymbolInfo      (DWORD dwSymTable, DWORD dwSymbol) {return 0;}
      virtual DWORD  SymbolVal       (DWORD dwSymTable, DWORD dwSymbol) {return 0;}
      virtual DWORD  SymbolVal       (DWORD dwSymTable, DWORD dwSymbol, DWORD dwValue) {return 0;}

      virtual DWORD  SymbolSize      (DWORD dwSymTable, DWORD dwSymbol) {return 0;}

      // Relocation Interface
      virtual DWORD  RelocationCnt  (DWORD dwRelTable)                     {return 0;}
      virtual DWORD  RelocationAddr (DWORD dwRelTable, DWORD dwRelocation) {return 0;}
      virtual DWORD  RelocationInfo (DWORD dwRelTable, DWORD dwRelocation) {return 0;}
      virtual TCHAR *RelocationName (DWORD dwRelTable, DWORD dwRelocation) {return 0;}


      CObjectFile *m_pPred, *m_pNext;

   protected:
      FILE *m_pFile;
      
      DWORD m_dwBinary;
      TCHAR m_tcOutput[MAX_PATH];

      virtual BOOL Access (void);
      virtual BOOL Secure (void);
   };