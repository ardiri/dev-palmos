#include "stdafx.h"

#include "ObjectFile.h"


CObjectFile::CObjectFile (void)
{
   m_pFile = NULL;
   m_pNext = m_pPred = NULL;

   m_dwBinary = 0; // Elf Object
   memset (m_tcOutput, 0, sizeof (m_tcOutput));
}

CObjectFile::CObjectFile (FILE *pFile, DWORD dwOffset)
{
   CObjectFile::CObjectFile();

   m_pFile = pFile;

   if (fseek (m_pFile, dwOffset, SEEK_SET))
      return;

   m_pNext = m_pPred = NULL;
}

CObjectFile::~CObjectFile (void)
{
   this->Secure ();
}

BOOL CObjectFile::Access (void)
{
   return 1;
}

BOOL CObjectFile::Secure (void)
{    
   if (m_pFile) {fclose (m_pFile); m_pFile = NULL;}

   return 1;
}

void CObjectFile::SetOutput (TCHAR *pOutput, DWORD dwBinary)
{
   m_dwBinary = dwBinary;
   memcpy (m_tcOutput, pOutput, __min (sizeof (m_tcOutput)-1, strlen (pOutput)));
}