#pragma once

int _nop      (int iIndex, char *argv[], void *pData);
int _lib_path (int iIndex, char *argv[], void *pData);
int _lib      (int iIndex, char *argv[], void *pData);
int _set      (int iIndex, char *argv[], void *pData);
int _obj      (int iIndex, char *argv[], void *pData);
int _bin      (int iIndex, char *argv[], void *pData);

extern struct Library             *pLibHead, *pLibTail;
extern class  CObjectFile         *pObjHead, *pObjTail;
extern struct got                 *pGotHead, *pGotTail;