; Arm PalmOs Startup
; Entry point for arm programs

	SECTION .text
		
	global	_startup

	extern  __entry
			
	_startup:
		; Save the base start address into r0
		sub r0, pc, #8

		; Save all important information onto the stack		
		mov     ip, sp
	    stmdb   sp!, {sl, fp, ip, lr, pc}
        sub     fp, ip, #4      ; 0x4

		; allocate the .bss section onto the stack
		ldr     r3, [got_bsz]
		add     r3, r3, 12


        sub     sp, sp, r3
        str     r0, [fp, #-20]
        str     r1, [fp, #-24]
        str     r2, [fp, #-28]	        	


		; Set the .got pointer
		ldr     sl, [got_x]
		add     sl, sl, r0
        	        		        	        		        							
		; correct the .got section
		mov r1, 0
		ldr r2, [got_xsz] ; number of words that need to be corrected
		
		
		; Handle the relocation
		bl  _relocation				
		
			
		; Allocate a new stack pointer here
		; Add code here

		
		; Call the defined entry point
        ldr     r0, [fp, #-20]
        ldr     r1, [fp, #-24]
        ldr     r2, [fp, #-28]	        	
		bl      __entry	
		
		; restore the old stack pointer and return to calling code
		ldmdb	fp, {sl, fp, sp, pc}
		
	_relocation:	
		cmp   r1, r2
		moveq pc, lr
		
		ldr   r3, [sl, r1]
		
		tst   r3, #0x80000000
		addeq r3, r3, r0

		ldrne r5, [clr]		
		andne r3, r3, r5
		subne r3, fp, r3
		subne r3, r3, #32
		movne r5, 0
		strne r5, [r3]
		
		str   r3, [sl, r1]
				
		add   r1, r1, #4
		b     _relocation																																						

	clr:
		dcd   0xffffff7f

	got_x:
		extern _GLOBAL_OFFSET_TABLE_
	 	dcd    _GLOBAL_OFFSET_TABLE_	
    got_xsz:
		extern __got_xsz
	 	dcd    __got_xsz
			
	got_b:
		extern __got_b
	 	dcd    __got_b	
	got_bsz:
		extern __got_bsz
	 	dcd    __got_bsz
	 			