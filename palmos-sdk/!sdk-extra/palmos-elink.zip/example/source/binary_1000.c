/******************************************************************************
 *
 * Copyright (c) 1995-2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: armlet-simple.c
 *
 * Release: Palm OS SDK 5.0 (111823)
 *
 * Description:
 *
 *    This is an example of a most trivial armlet; it simply returns the 
 *    same pointer it receives.  
 *
 *    PACE byte-swaps userData68KP (but not what it points to!) so it's ready 
 *    to be dereferenced.  PACE also byte-swaps the 4-byte return value, so the 
 *    calling function receives back the same pointer it passed in.
 *
 *    The armlet entry point needs to be the first function in the file.
 *
 *****************************************************************************/

/*
 * NOTE: Add the path to your "Palm OS Support folder" in you Visual Studio 
 * environment. Go to Options >> Directories and add the path to the include files section.
 */

#include "PceNativeCall.h"

#include <PalmOs.h>
#include <PalmCompatibility.h>

int       offset =  0;
int       multi  =  2;
int const delta  = 20;

void *NativeFunction(const void *emulStateP, void *userData68KP, Call68KFuncType *call68KFuncP)
{
   int local = 0;
	
   offset = 8;

   local = (multi * delta) + offset;

   return (void *) MemPtrNew (local);
}
