/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: armlet-simple.c
 *
 * Release: Palm OS 5 SDK (68K) R2.
 *
 * Description:
 *    This is an example of a most trivial armlet; it simply returns the 
 *    same pointer it receives.  
 *
 *    PACE byte-swaps userData68KP (but not what it points to!) so it's ready 
 *    to be dereferenced.  PACE also byte-swaps the 4-byte return value, so the 
 *    calling function receives back the same pointer it passed in.
 *
 *    The armlet entry point needs to be the first function in the file.
 *
 *****************************************************************************/

#include "PceNativeCall.h"
#ifdef WIN32
	#include "SimNative.h"
#endif
#include "endianutils.h"
#include "CoreTraps.h"
#include "stdio.h"
#include "armlet.h"
//extern "C" {
#include <jpeglib.h>

//}
FILE *fpI, *log;
unsigned long NativeFunction(const void *emulStateP, void *userData68KP, Call68KFuncType *call68KFuncP)
{


		unsigned int lineSize, outputLineSize, i, j, offset, xFloor, yLimit;	 	
		unsigned short *dataLine;
		unsigned long size;
		unsigned short blue, red, green;
		unsigned short screenWidth, screenHeight, xOffset, yOffset, *offsets;
		void *myPtrFree;
		MyUserData *userData;		
		struct jpeg_decompress_struct cinfo;
		struct jpeg_error_mgr jerr;
		JSAMPROW row[1];
		unsigned char buffer[2000];
        DmWriteArgsType dmArgs;
		float scale, hRatio, wRatio;
		float yMult, xMult, usedMult, yF, xF, xScaled, fract;
		unsigned char pos;
		
		log=fopen("C:\\log.txt","w");
		fpI=fopen("C:\\testPhoto.jpg","rb");

	
		
		userData=(MyUserData *)userData68KP;
		cinfo.myUserData=userData;
		cinfo.emulStateP=emulStateP;
		cinfo.call68KFuncP=call68KFuncP;

		cinfo.err = jpeg_std_error(&jerr);

		jpeg_create_decompress(&cinfo);

	    //reassign all this stuff because jpeg_create_decompress
		//zero's out the structure
		cinfo.myUserData=userData;
		cinfo.emulStateP=emulStateP;
		cinfo.call68KFuncP=call68KFuncP;
	
		
		jpeg_stdio_src(&cinfo, NULL);

		jpeg_read_header(&cinfo, TRUE);
		//set parameters here

		screenWidth=ByteSwap16(userData->width);
		screenHeight=ByteSwap16(userData->height);

		hRatio=(float)cinfo.image_height/(float)screenHeight;
		wRatio=(float)cinfo.image_width/(float)screenWidth;
	

		if (hRatio>wRatio) scale=hRatio;
		else scale=wRatio;
		if (scale<1) scale=1;
		

		cinfo.scale_denom=(int)(scale+0.5);

		if (cinfo.scale_denom == 3) cinfo.scale_denom=4;
		if (cinfo.scale_denom > 4 && cinfo.scale_denom < 8)
			cinfo.scale_denom=8;
	
		cinfo.out_color_space=JCS_RGB;

		row[0]=buffer;

		xOffset=0;

		//cinfo.do_fancy_upsampling=FALSE;
		//cinfo.dct_method=JDCT_IFAST;
		
		if ( scale - (float)((int)scale)==0.0) {
		//no interpolation
		
			jpeg_start_decompress(&cinfo);
			
			xOffset=(screenWidth-cinfo.output_width)/2;
			yOffset=(screenHeight-cinfo.output_height)/2;

			userData->width=ByteSwap16(cinfo.output_width);
			userData->height=ByteSwap16(cinfo.output_height);
		
			lineSize=screenWidth*sizeof(unsigned short);
			size=ByteSwap32(lineSize);
			dataLine=(unsigned short *)((call68KFuncP)(emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));
			for (j=0;j<screenWidth;j++) dataLine[j]=0;


			for (j=0;j<cinfo.output_height;j++) {
				if (cinfo.output_scanline < cinfo.output_height) 
						jpeg_read_scanlines(&cinfo, row, 1);
				
				for (i=0;i<screenWidth-xOffset*2;i++) {			
					offset=i*3;
					red=buffer[offset]>>3; 
					green=buffer[offset+1]>>3;
					blue=buffer[offset+2]>>3;
					//blue gets the 6 low bits, green the next 5, and red the high 5 bits					
					dataLine[i+xOffset]=0;  				
					dataLine[i+xOffset]|=blue;
					dataLine[i+xOffset]|=green<<6;
					dataLine[i+xOffset]|=red<<11;
					dataLine[i+xOffset]=ByteSwap16(dataLine[i+xOffset]);
					
				}
				dmArgs.dest=userData->ftrMemory;
				dmArgs.offset=ByteSwap32(lineSize*(j+yOffset));
				dmArgs.src=ByteSwap32(dataLine);
				dmArgs.bytes=ByteSwap32(lineSize);
				(call68KFuncP)(emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,
				16);			
				
			}
		}
		else {
		//nearest neighbor interpolation

			cinfo.scale_denom/=2;

			jpeg_start_decompress(&cinfo);

			lineSize=cinfo.output_width*sizeof(unsigned short);
			outputLineSize=screenWidth*sizeof(unsigned short);
			size=ByteSwap32(lineSize);
			dataLine=(unsigned short *)((call68KFuncP)(emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));

			for (j=0;j<cinfo.output_width;j++) dataLine[j]=0;

			xMult=(float)cinfo.output_width/(float)screenWidth;
			yMult=(float)cinfo.output_height/(float)screenHeight;
			if (yMult > xMult) {
				usedMult=yMult;
				xOffset=(screenWidth - (int)(cinfo.output_width/yMult+0.5))/2;
				userData->width=ByteSwap16(screenWidth-xOffset*2);
				userData->height=ByteSwap16(screenHeight);

			}
			else  {			
				usedMult=xMult;
				userData->width=ByteSwap16((int)(cinfo.output_height/xMult + 0.5));
				userData->height=ByteSwap16(screenHeight);
				yOffset=(screenHeight - (int)(cinfo.output_height/xMult+0.5))/2;
			}
		
			jpeg_read_scanlines(&cinfo, row, 1);
			
			
			yLimit=(int)(cinfo.output_height/usedMult);
			if (yLimit > screenHeight - 1) yLimit=screenHeight-1;

			size=ByteSwap32( (screenWidth-xOffset*2) *sizeof(unsigned short));
			offsets=(unsigned short *)((call68KFuncP)(emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));
			for (i=0;i<screenWidth-xOffset*2;i++) {		
					xScaled=usedMult*i;
					xFloor=(unsigned int)xScaled;
					if (xScaled - (float)xFloor > 0.5) xFloor++;
					offsets[i]=xFloor*3;
			}

			for (j=0;j<=yLimit;j++) {

				yF=usedMult*j; 
				
				if ((yF - (float)(cinfo.output_scanline - 1) > 0.5) && 
					(cinfo.output_scanline < cinfo.output_height))
							jpeg_read_scanlines(&cinfo, row, 1);
					
					for (i=0;i<screenWidth-xOffset*2;i++) {		
							red=buffer[offsets[i]]>>3; 
							green=buffer[offsets[i]+1]>>3;
							blue=buffer[offsets[i]+2]>>3;
							//blue gets the 6 low bits, green the next 5, and red the high 5 bits
						
							dataLine[i+xOffset]=0;  				
							dataLine[i+xOffset]|=blue;
							dataLine[i+xOffset]|=green<<6;
							dataLine[i+xOffset]|=red<<11;
							dataLine[i+xOffset]=ByteSwap16(dataLine[i+xOffset]);
				   }
					//don't have to byte swap because we never byte swapped it in the first place
					dmArgs.dest=userData->ftrMemory;
					dmArgs.offset=ByteSwap32(outputLineSize*(j+yOffset));
					dmArgs.src=ByteSwap32(dataLine);
					dmArgs.bytes=ByteSwap32(outputLineSize);
					(call68KFuncP)(emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,16);
			
				if (cinfo.output_scanline < cinfo.output_height) 
				jpeg_read_scanlines(&cinfo, row, 1);
				
			}

			while (cinfo.output_scanline < cinfo.output_height) {
				jpeg_read_scanlines(&cinfo, row, 1);
			}

			//free(offsets);
			myPtrFree=ByteSwap32(userData->myPtrFree);
			offsets=ByteSwap32(offsets);
			(call68KFuncP)(emulStateP,myPtrFree,&offsets,4);
		}

		
		
		jpeg_finish_decompress(&cinfo);
		
		jpeg_destroy_decompress(&cinfo);

		userData->xOffset=ByteSwap16(xOffset);
		userData->yOffset=ByteSwap16(yOffset);
		fclose(fpI);
		fclose(log);
	



		myPtrFree=ByteSwap32(userData->myPtrFree);
		//so you need the address of the function pointer in ARMish
	    dataLine=ByteSwap32(dataLine);
		(call68KFuncP)(emulStateP,myPtrFree,&dataLine,4);
		//note that we always need the address of the function arguments, so in this case the address of a pointer (address of address)

	return (unsigned long)0;
}
