/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: NativeCallTestApp.c
 *
 * Release: Palm OS 5 SDK (68K) R2.
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <PceNativeCall.h>

#include "StarterRsc.h"
#include "example_data_type.h"
#include <VFSMgr.h>
void myPtrFree(void *);
void myFileReader(void *buf,unsigned long buflength, unsigned long *read);
void myAlerter(void);
/***********************************************************************
 *
 *	Entry Points
 *
 ***********************************************************************/


/***********************************************************************
 *
 *	Internal Structures
 *
 ***********************************************************************/
typedef struct 
	{
	UInt8 replaceme;
	} StarterPreferenceType;

typedef struct 
	{
	UInt8 replaceme;
	} StarterAppInfoType;

typedef StarterAppInfoType* StarterAppInfoPtr;


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
//static Boolean HideSecretRecords;
FileRef fp;


/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'STRT'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

// Define the minimum OS version we support (2.0 for now).
#define ourMinVersion	sysMakeROMVersion(2,0,0,sysROMStageRelease,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr /*frmP*/)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutStarterApp:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}

static UInt32 PceNativeResourceCall(DmResType resType, DmResID resID, char* DLLEntryPointP, void *userDataP)
{
	UInt32    processorType;
	MemHandle armH;
	MemPtr    armP;
	UInt32    result;

	// get the processor type
	FtrGet(sysFileCSystem, sysFtrNumProcessorID, &processorType);
	
	if (sysFtrNumProcessorIsARM(processorType))
		{
			// running on ARM; call the actual ARM resource
			armH = DmGetResource(resType, resID);
			armP = MemHandleLock(armH);
	
			result = PceNativeCall(armP, userDataP);
	
			MemHandleUnlock(armH);
			DmReleaseResource(armH);
		}
	else if (processorType == sysFtrNumProcessorx86)
		{
			// running on Simulator; call the DLL
			result = PceNativeCall( (NativeFuncType*)DLLEntryPointP, userDataP);
		}
	else
		{
			// some other processor; fail gracefully
			ErrNonFatalDisplay("unsupported processor type");
			result = -1;
		}
	
	return result;
}

void myPtrFree(void *ptr) {

	MemPtrFree(ptr);
	return;
	
}
void myFileReader(void *buf,unsigned long buflength, unsigned long *read) { 

	VFSFileRead(fp, buflength, buf,read);
	
	//note that fp is a global
}
void myAlerter(void) {
	//FrmAlert(RomIncompatibleAlert);

}

/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	FormPtr frmP;
	UInt32  result;
	
	typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileReader;
		void *alerter;
	}	MyUserData;
	
	MyUserData myUserData;
	
	
	Char msg[100];
	//UInt32 version,romVersion, size;
	
	BitmapType *bmpP; 
	Err error; 
//	RectangleType onScreenRect; 
//	UInt16 i,j;
//	RGBColorType color, old;
	BitmapTypeV3 *bmp3;
	UInt16 *bitmapData;// *dataLine;
//	UInt32 lineSize;
	UInt32 w, h;
//	void *ptr;
	Err err;
	UInt16 volRefNum;
	UInt32 volIterator=vfsIteratorStart;
	UInt32 processor;
	
	switch (eventP->eType) 
		{
		case ctlSelectEvent:
			switch (eventP->data.ctlSelect.controlID)
				{
					case MainTestButton:
						
						h=320;
						w=320;		
						
						WinPushDrawState();
				  		WinSetCoordinateSystem(kCoordinatesDouble);
				  		bmpP = BmpCreate(w, h, 16, NULL, &error); 
				  		
				  		//Open the VFS file for reading
				  		
				  		err=VFSVolumeEnumerate(&volRefNum, &volIterator);
				  		if (err!=errNone) FrmCustomAlert(DebugAlert,"Unable to get volume reference",NULL,NULL);
				  		
				  		err=VFSFileOpen(volRefNum,"/DCIM/testphoto.jpg",vfsModeRead,&fp);
				  		if (err) FrmCustomAlert(DebugAlert,"Unable to open file",NULL,NULL);
				  	
				  		
				  		
				  		//allocate feature memory, where we will put the 
				  		//decoded image. But this will have to be done
				  		//from the armlet because we won't know the size 
				  		//ahead of time
				  		error=FtrPtrNew(appFileCreator,0,w*h*sizeof(UInt16), (void **)&bitmapData);
				  		myUserData.myPtrFree=&myPtrFree;
				  		myUserData.myFileReader=&myFileReader;
				  		myUserData.ftrMemory=bitmapData;
				  		myUserData.alerter=myAlerter;
				  		
						FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

				  		if (sysFtrNumProcessorIsARM(processor))
						{
							MemHandle mh = DmGetResource('ARMC', 1);
							NativeFuncType *armlet = (NativeFuncType *)MemHandleLock(mh);

							UInt32 result = PceNativeCall(armlet, &myUserData);
							
							MemHandleUnlock(mh);
							DmReleaseResource(mh);
						}
						else {
							  		result = PceNativeResourceCall(
							'ARMC',                     // ARMC is a good
							1000, 
							"c:\\ARMlet.dll\0NativeFunction", // default dll path is the location of PalmSim.exe
							&myUserData);
					    }
				  	
				  		VFSFileClose(fp);
				 
						/*
				  		lineSize=w*sizeof(UInt16);
				  		dataLine=(UInt16 *)MemPtrNew(lineSize);
				  		
				  		
				  		for (j=0;j<h;j++) {
				  			
				  			for (i=0;i<w;i++) {
				  				
				  				blue=0;
				  				green=0;
				  				red=31;  				
				  				//blue gets the 6 low bits, green the next 5, and red the high 5 bits
				  				
				  				dataLine[i]=0;  				
				  				dataLine[i]|=blue;
				  				dataLine[i]|=green<<6;
				  				dataLine[i]|=red<<11;
				  				
				  			}
				  			DmWrite(bitmapData,lineSize*j,dataLine,lineSize);
				  			
				  		}
				  		
				  		
				  		MemPtrFree(dataLine);
				  		*/
				  		
				  		bmp3=BmpCreateBitmapV3(bmpP,kDensityDouble,(const void *)bitmapData,NULL);
				  		
				  		
				  		
						if (bmp3) { 
					 		
					  		WinDrawBitmap((BitmapType *)bmp3,0,0);
					  		
					  		BmpDelete((BitmapType *)bmp3);
					  		BmpDelete(bmpP);
					  		FtrPtrFree(appFileCreator,0);
				  		
				  		}
				  		
				  		WinPopDrawState();
						
						
						
						
						
						handled = true;
						break;
					
					default:
						break;
				}
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);
			handled = true;
			break;
			
		case frmUpdateEvent:
			// To do any custom drawing here, first call FrmDrawForm(), then do your
			// drawing, and then set handled to true.
			break;

		default:
			break;
		
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	StarterPreferenceType prefs;
	UInt16 prefsSize;

	// Read the saved preferences / saved-state information.
	prefsSize = sizeof(StarterPreferenceType);
	if (PrefGetAppPreferences(appFileCreator, appPrefID, &prefs, &prefsSize, true) != 
		noPreferenceFound)
		{
		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	StarterPreferenceType prefs;

	// Write the saved preferences / saved-state information.  This data 
	// will saved during a HotSync backup.
	PrefSetAppPreferences (appFileCreator, appPrefID, appPrefVersionNum, 
		&prefs, sizeof (prefs), true);
		
	// Close all the open forms.
	FrmCloseAllForms ();
}


/***********************************************************************
 *
 * FUNCTION:    StarterPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;

	error = RomVersionCompatible (ourMinVersion, launchFlags);
	if (error) return (error);

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return StarterPalmMain(cmd, cmdPBP, launchFlags);
}
