/******************************************************************************
 *
 * Copyright (c) 1995-2002 PalmSource, Inc. All rights reserved.
 *
 * File: armlet-simple.c
 *
 * Release: Palm OS 5 SDK (68K) R2.
 *
 * Description:
 *    This is an example of a most trivial armlet; it simply returns the 
 *    same pointer it receives.  
 *
 *    PACE byte-swaps userData68KP (but not what it points to!) so it's ready 
 *    to be dereferenced.  PACE also byte-swaps the 4-byte return value, so the 
 *    calling function receives back the same pointer it passed in.
 *
 *    The armlet entry point needs to be the first function in the file.
 *
 *****************************************************************************/

#include "PceNativeCall.h"
#ifdef WIN32
	#include "SimNative.h"
#endif
#include "endianutils.h"
#include "CoreTraps.h"
#include "stdio.h"
#include "jpeglib.h"


unsigned long NativeFunction(const void *emulStateP, void *userData68KP, Call68KFuncType *call68KFuncP)
{


		unsigned int i, offset, j;
		unsigned short blue, red, green, *ftrPtr, pixel, w, h;
		struct jpeg_compress_struct cinfo;
		struct jpeg_error_mgr jerr;
		JSAMPROW row[1];
		unsigned char buffer[2000];
		int z=0;
				
		MyUserData *userData;		
		//jpeg lib test
		
	
		userData=(MyUserData *)userData68KP;
		cinfo.myUserData=userData;
		cinfo.emulStateP=emulStateP;
		cinfo.call68KFuncP=call68KFuncP;

		cinfo.err = jpeg_std_error(&jerr);

		cinfo.dct_method=JDCT_IFAST;

		jpeg_create_compress(&cinfo);
	
	
	    //reassign all this stuff because jpeg_create_compress;
		//zero's out the structure
		//have to fix this

		cinfo.myUserData=userData;
		cinfo.emulStateP=emulStateP;
		cinfo.call68KFuncP=call68KFuncP;
	
		jpeg_stdio_dest(&cinfo,NULL);
		h=ByteSwap16(userData->height);
		w=ByteSwap16(userData->width);
		
		cinfo.image_width = w; 	
		cinfo.image_height = h;
		cinfo.input_components = 3;	/* # of color components per pixel */

		if ( ByteSwap16(userData->RGB)==typeRGB )
			cinfo.in_color_space = JCS_RGB; /* colorspace of input image */
		else
			cinfo.in_color_space = JCS_YCbCr;

		jpeg_set_defaults(&cinfo);

		jpeg_start_compress(&cinfo, TRUE);

		row[0]=buffer;
		
		ftrPtr=(unsigned short *)ByteSwap32(userData->ftrMemory);

	
		j=0;
		while (cinfo.next_scanline < cinfo.image_height) {
			for (i=0;i<w;i++) {
				pixel=ByteSwap16(ftrPtr[j*w+i]);
				offset=i*3;
				red=(pixel & REDMASK)>>8;
				green=(pixel & GREENMASK)>>3;
				blue=(pixel & BLUEMASK)<<3;

				buffer[offset]=red; 
				buffer[offset+1]=green;
				buffer[offset+2]=blue;	
				
			}
		
			jpeg_write_scanlines(&cinfo, row, 1);
			j++;

		}

		jpeg_finish_compress(&cinfo);

		jpeg_destroy_compress(&cinfo);



	
		return (unsigned long)0;

	
}
