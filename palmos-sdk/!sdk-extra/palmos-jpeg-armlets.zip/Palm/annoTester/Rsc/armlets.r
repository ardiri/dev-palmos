read 'ARMC' (9000) "ARMC0001.bin";
read 'ARMC' (9001) "ARMC0002.bin";