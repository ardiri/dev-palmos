#include "PACEInterface.h"
#include <size_t.h>
#include <cstddef>
#include <stdio.h>
#include <string.h>
extern "C" {
#include "jpeglib.h" 
}
class ARMlet : public PACEInterface
{
public:
	void *m_userData68KP;
	
    //note that we have made m_userData68KP in our class
    //whereas m_emulStateP and m_call68KFuncP are inherited from
    //PACEInterface
    
	ARMlet(
		const void *emulStateP, 
		Call68KFuncType *call68KFuncP) :
		PACEInterface(emulStateP, call68KFuncP)
		{ 
		
		
		}

	unsigned long Run();
};

unsigned long ARMlet::Run()
{
		
		unsigned  i, offset, j;
		unsigned long size;
		unsigned short blue, red, green, *ftrPtr, pixel, w, h;
		struct jpeg_compress_struct cinfo;
		struct jpeg_error_mgr jerr;
		JSAMPROW row[1];
		unsigned char buffer[2000];
	
		
		void *myPtrFree;
		
		MyUserData *userData;		
		//jpeg lib test
	
		
	
	
		userData=(MyUserData *)m_userData68KP;
		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;

		cinfo.err = jpeg_std_error(&jerr);

		jpeg_create_compress(&cinfo);
		
		cinfo.dct_method=JDCT_IFAST;

	
	    //reassign all this stuff because jpeg_create_compress;
		//zero's out the structure
		//have to fix this

		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;
	
		jpeg_stdio_dest(&cinfo,NULL);
		
		h=ByteSwap16(userData->height);
		w=ByteSwap16(userData->width);

		cinfo.image_width = w; 	
		cinfo.image_height = h;
		cinfo.input_components = 3;	/* # of color components per pixel */
	
		if ( ByteSwap16(userData->RGB)==typeRGB )
			cinfo.in_color_space = JCS_RGB; /* colorspace of input image */
		else
			cinfo.in_color_space = JCS_YCbCr;


		jpeg_set_defaults(&cinfo);

		jpeg_start_compress(&cinfo, TRUE);

		row[0]=buffer;

		
		ftrPtr=(unsigned short *)ByteSwap32(userData->ftrMemory);

		j=0;
		while (cinfo.next_scanline < cinfo.image_height) {
			
			for (i=0;i<w;i++) {
				pixel=ByteSwap16(ftrPtr[j*w+i]);
				offset=i*3;
				red=(pixel & REDMASK)>>8;
				green=(pixel & GREENMASK)>>3;
				blue=(pixel & BLUEMASK)<<3;
				buffer[offset]=red; 
				buffer[offset+1]=green;
				buffer[offset+2]=blue;	
				
			}
		
			jpeg_write_scanlines(&cinfo, row, 1);
			j++;

		}

		jpeg_finish_compress(&cinfo);

		jpeg_destroy_compress(&cinfo);


	
		
		/*	
		unsigned int w=320, h=320, lineSize, i, j, offset, numMsg;	 	
		unsigned short *dataLine;
		unsigned long size;
		unsigned short blue, red, green;
		DmWriteArgsType dmArgs;
	
		void *myPtrFree;
		
		MyUserData *userData;		
		//jpeg lib test
		struct jpeg_decompress_struct cinfo;
		struct jpeg_error_mgr jerr;
		JSAMPROW row[1];
		unsigned char buffer[2000];
		char *msg;
		
	    
		
		userData=(MyUserData *)m_userData68KP;
		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;
	 
	 
		
		
		
		cinfo.err = jpeg_std_error(&jerr);
		
		
		jpeg_create_decompress(&cinfo);
	
		
  		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;

		jpeg_stdio_src(&cinfo, NULL);
        
        
		jpeg_read_header(&cinfo, TRUE);
		//set parameters here
			
		
		cinfo.scale_denom=2;
		cinfo.out_color_space=JCS_RGB;
		cinfo.quantize_colors=false;
		cinfo.dct_method=JDCT_ISLOW;
		
		jpeg_start_decompress(&cinfo);
		row[0]=buffer;

		
		lineSize=w*sizeof(unsigned short);
		size=ByteSwap32(lineSize);
		dataLine=(unsigned short *)((m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
			4 | kPceNativeWantA0));
		
		//note that w and h here are screen width & height
		
		for (j=0;j<cinfo.output_height;j++) {						
			jpeg_read_scanlines(&cinfo, row, 1);
			
			for (i=0;i<w;i++) {			
				
				if (i>cinfo.output_width) break;
				
			
				offset=i*3;
				red=buffer[offset]>>3; 
				green=buffer[offset+1]>>3;
				blue=buffer[offset+2]>>3;
				//blue gets the 6 low bits, green the next 5, and red the high 5 bits
							
				dataLine[i]=0;  				
				dataLine[i]|=blue;
				dataLine[i]|=green<<6;
				dataLine[i]|=red<<11;
				dataLine[i]=ByteSwap16(dataLine[i]);
				
			}
			
			
			
			
			//don't have to byte swap because we never byte swapped it in the first place
			dmArgs.dest=userData->ftrMemory;
			dmArgs.offset=ByteSwap32(lineSize*j);
			dmArgs.src=(unsigned short *)ByteSwap32(dataLine);
			dmArgs.bytes=ByteSwap32(lineSize);
			(m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,
			16);
			
			
		}
	
	    //just fill in the bottom now with black 
	    
		red=0;
		blue=0;
		green=0;
		
		for (i=0;i<w;i++) {												
			dataLine[i]=0;  				
			dataLine[i]|=blue;
			dataLine[i]|=green<<6;
			dataLine[i]|=red<<11;
			dataLine[i]=ByteSwap16(dataLine[i]);				
		}
		
	    for (j=cinfo.output_height;j<h; j++) {						

			dmArgs.dest=userData->ftrMemory;
			dmArgs.offset=ByteSwap32(lineSize*j);
			dmArgs.src=(unsigned short *)ByteSwap32(dataLine);
			dmArgs.bytes=ByteSwap32(lineSize);
			(m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,
			16);
			
			
	   }
			
		jpeg_finish_decompress(&cinfo);
		
		jpeg_destroy_decompress(&cinfo);
		
		
	

		

		myPtrFree=(void *)ByteSwap32(userData->myPtrFree);
		//so you need the address of the function pointer in ARMish
	    dataLine=(unsigned short *)ByteSwap32(dataLine);
		(m_call68KFuncP)(m_emulStateP,(unsigned long)myPtrFree,&dataLine,4);
		//note that we always need the address of the function arguments, so in this case the address of a pointer (address of address)
    	
    	*/
    /* 
	// draw randomly-colored pixels on the screen
	for (Coord y = 16; y < 160; ++y)
	{
		for (Coord x = 0; x < 160; ++x)
		{
			RGBColorType RGB, prevRGB;
			RGB.index = 0;
			RGB.r = SysRandom(0) % 256;
			RGB.g = SysRandom(0) % 256;
			RGB.b = SysRandom(0) % 256;

			WinSetForeColorRGB(&RGB, &prevRGB);
			WinDrawPixel(x, y);
		}
	}
	*/
	return 0;
}

// ------------------------

extern "C"
unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP);

unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP)
{
	ARMlet armlet(emulStateP, call68KFuncP);
	armlet.m_userData68KP=userData68KP;
	return armlet.Run();
}
