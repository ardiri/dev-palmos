/******************************************************************************
 *
 * File: Starter.cpp
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <PCENativeCall.h>
#include "StarterRsc.h"
#include <VFSMgr.h>

void myPtrFree(void *);
void myFileWriter(void *buf,unsigned long buflength, unsigned long *read);
void errorMessager(char *);
/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'STRT'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

// Define the minimum OS version we support (2.0 for now).
#define kOurMinVersion	sysMakeROMVersion(2,0,0,sysROMStageRelease,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/
FileRef fp;
void myPtrFree(void *ptr) {

	MemPtrFree(ptr);
	return;
	
}
void myFileWriter(void *buf,unsigned long buflength, unsigned long *written) { 

	VFSFileWrite(fp, buflength, buf, written);
	//note that fp is a global
}
void errorMessager(char *msg) {
	SysFatalAlert(msg);
}

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr /*frmP*/)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutStarterApp:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	FormPtr frmP;
	UInt32 processor;
	
	typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileWriter;
		void *myFileReader;
		void *errorMessager;
		UInt16 width;
		UInt16 height;
		UInt16 xOffset;
		UInt16 yOffset;
		UInt16 RGB;
	} MyUserData;
	#define typeRGB 1;
	#define typeYUV 0;
	
	MyUserData *myUserData;
	
	Err error; 
	UInt32 w, h;
	Err err;
	UInt16 volRefNum, red, blue, green, *dataLine, val, *valP;
	UInt32 volIterator=vfsIteratorStart;
	UInt32  result, lineSize, i, j, k;
	void *bitmapData;
	Char msg[100];
	

	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);
			break;
			
		case frmCloseEvent:	
			FtrPtrFree(appFileCreator,0);
	  		break;
	 
		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);

	
			w=640;
			h=480;		
			
			
		 	//Open the VFS file for reading
	  		
	  		err=VFSVolumeEnumerate(&volRefNum, &volIterator);
	  		if (err) DbgMessage("no volume reference");
	  			  		
	  		err=VFSFileOpen(volRefNum,"/DCIM/testpht.jpg",vfsModeWrite | vfsModeCreate ,&fp);
	  		if (err) DbgMessage("Can't open file");
	 	
	  		
	  		error=FtrPtrNew(appFileCreator,0,w*h*sizeof(UInt16), (void **)&bitmapData);
	  		
	  		
	  		
	  		lineSize=w*sizeof(UInt16);
	  	
	  		
	  		dataLine=(UInt16 *)MemPtrNew(lineSize);
	  		
	  		for (i=0;i<w;i++) {			
				
				blue=0;
				red=31;
				green=0;
				
				dataLine[i]=0;  				
				dataLine[i]|=blue;
				dataLine[i]|=green<<6;
				dataLine[i]|=red<<11;
			}
			
	  		for (j=0;j<h;j++) 	{
	    		DmWrite(bitmapData,lineSize*j,dataLine,lineSize);
	    	}	
	    	
	    	
	  		MemPtrFree(dataLine);
	  		
	  		
	  		myUserData=(MyUserData *)MemPtrNew(sizeof(MyUserData));
	  		myUserData->myPtrFree=&myPtrFree;
	  		myUserData->myFileWriter=&myFileWriter;
	  		myUserData->ftrMemory=bitmapData;
	  		myUserData->errorMessager=&errorMessager;
	  		myUserData->width=w;
	  		myUserData->height=h;
	  		myUserData->RGB=typeRGB;
			

			// call the ARMlet
			FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

			if (sysFtrNumProcessorIsARM(processor))
			{
				MemHandle mh;
				NativeFuncType *armlet;
				UInt32 result;
				
				mh = DmGetResource('ARMC', 2);
				*armlet = (NativeFuncType *)MemHandleLock(mh);

				result = PceNativeCall(armlet, myUserData);
				
				MemHandleUnlock(mh);
				DmReleaseResource(mh);
				MemPtrFree(myUserData);
			}
			else if (sysFtrNumProcessorx86) {
				result = PceNativeCall(
				(NativeFuncType*)"c:\\ARMletC.dll\0NativeFunction", // default dll path is the location of PalmSim.exe
				myUserData);
				MemPtrFree(myUserData);
			}
			
			
			VFSFileClose(fp);
			
		
						
			handled = true;
			break;
			
		case frmUpdateEvent:
			// To do any custom drawing here, first call FrmDrawForm(), then do your
			// drawing, and then set handled to true.
			break;

		default:
			break;
		
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	// Close all the open forms.
	FrmCloseAllForms ();
}


/***********************************************************************
 *
 * FUNCTION:    StarterPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;

	error = RomVersionCompatible (kOurMinVersion, launchFlags);
	if (error) return (error);

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return StarterPalmMain(cmd, cmdPBP, launchFlags);
}
