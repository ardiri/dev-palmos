/***********************************************************************
 *
 * Copyright (c) 2002 Palm Computing, Inc. or its subsidiaries.
 * All rights reserved.
 *
 ***********************************************************************/

/***********************************************************************
 *
 * File:
 *	CamerSample.c
 *
 * Description:
 *	Sample code for the camera API
 *
 *	Version 1.0 	- Initial Revision (03/12/03)
 *
 ***********************************************************************/
 
#include <PalmOS.h>
#include "PalmChars.h"
#include "CameraSample.h"
#include "CameraSample_Rsc.h"
#include "CameraUtils.h"
#include "CameraSliderUtils.h"
#include <VFSMgr.h>
#include <PCENativeCall.h>

typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileWriter;
		void *myFileReader;
		void *errorMessager;
		UInt16 width;
		UInt16 height;
		UInt16 xOffset;
		UInt16 yOffset;
		UInt16 RGB;
	} MyUserData;
#define typeRGB 1;
#define typeYUV 0;
/*********************************************************************
 * Internal Constants
 *********************************************************************/

#define ourMinVersion    sysMakeROMVersion(5,0,0,sysROMStageDevelopment,0)
#define kPalmOS20Version sysMakeROMVersion(2,0,0,sysROMStageDevelopment,0)

#define kSliderNotificationPriority		(sysNotifyNormalPriority - 32)

/*********************************************************************
 * Internal globals
 *********************************************************************/
static FileRef fp, log;
static UInt32 gTotal=0;
static void *bitmapData;
static Boolean writeAble=true;
	

static UInt16	gCameraRefNum		= 0;
static Boolean 	gIsSliderRegistered = false;
static Boolean	gCameraIsOn			= false;
static Boolean	gPreviewIsOn		= false;
static UInt32	gPreviousDepth		= 0;

static RectangleType gPreviewQVGARectangle = { { 0, 0 }, { 160, 120 } };
static RectangleType gPreviewQQVGARectangle = { { 40, 30 }, { 80, 60 } };
static RectangleType *gPreviewRectangle = &gPreviewQQVGARectangle;
static CamLibImageSizeType gCurrentPreviewSize = { kCamLibImageSizeQQVGA };
static CamLibImageSizeType gVGAImage = { kCamLibImageSizeVGA };
static CamLibSettingType gRGB = { kCamLibCaptureDataFormatRGB565 };

/***********************************************************************
 *
 * FUNCTION:    SetScreenDepth
 *
 * DESCRIPTION: Changes the screen depth
 *
 * PARAMETERS:	depth	- Screen depth e.g. 1, 2, 4, 8, 16
 *
 * RETURNED:	Err
 *
 ***********************************************************************/
void myPtrFree(void *);
void myFileWriter(void *buf,unsigned long buflength, unsigned long *read);
void errorMessager(char *);

void myPtrFree(void *ptr) {

	MemPtrFree(ptr);
	return;
	
}
void myFileWriter(void *buf,unsigned long buflength, unsigned long *written) { 

	VFSFileWrite(fp, buflength, buf, written);
	//note that fp is a global
}
void errorMessager(char *msg) {
	SysFatalAlert(msg);
}

static Err SetScreenDepth(UInt32 depth)
{
	Boolean color = true;
	WinScreenMode(winScreenModeSet, 0, 0, &depth, &color);
	FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
	return errNone;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    SliderNotifyProc
 *
 * DESCRIPTION: Notification handler for the camera slider.
 *				We assume globals are always available here.
 *
 * PARAMETERS:	notifyParamsP	- Pointer to the notifiaction parameter
 *
 * RETURNED:	Err
 *
 ***********************************************************************/

static Err SliderNotifyProc(SysNotifyParamType *notifyParamsP)
{
	Err err = errNone;
	Boolean isSliderOpened = false;
	
	// Is it the expected notification
	if(notifyParamsP->notifyType != kCamSliderNotifyEvent)
		goto Done;

	// Is it handled? We are in a cooperative mode
	if(notifyParamsP->handled)
		goto Done;

	// Check the camera slider
	if(IsCameraSliderOpen())
	{
		if(!gCameraIsOn)
		{
			// Turn the camer on
			err = TurnCameraOn(gCameraRefNum);
			if(err)
				goto Done;
								
			gCameraIsOn = true;
			
			// Set the capture size
			err = SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
			if(err)
				goto Done;
			
			// Set the preview size
			err = SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
			if(err)
				goto Done;
			
			// Set the preview rectangle
			err = SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
			if(err)
				goto Done;
			
			// Start the preview
			err = StartCameraPreview(gCameraRefNum);
			if(err)
				goto Done;
				
			gPreviewIsOn = true;
		}
	}
	else
	{
		// Stop the preview
		if( gPreviewIsOn )
		{
			err = StopCameraPreview(gCameraRefNum);
			if(err)
				goto Done;
			
			gPreviewIsOn = false;
		}
		
		// Turn the camera off		
		if( gCameraIsOn )
		{
			err = TurnCameraOff(gCameraRefNum);
			if(err)
				goto Done;
				
			gCameraIsOn = false;
		}
		
		// Refresh the current form
		FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
	}
	
	// I have handheld the notification and don't want any other app to do so
	notifyParamsP->handled = true;
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:	CameraLibCaptureCallback
 *
 * DESCRIPTION:	This routine capture the image in a callback
 *
 * PARAMETERS:	None
 *
 * RETURNED:	Err
 *
 ***********************************************************************/
typedef struct
{
	MemHandle bmpH;
	UInt32 size;
} MyCallbackDataType;

static Err MyCaptureCallback(void* bufP, UInt32 size, void* userDataP)
{
	//
	// Write your capture code here
	//
	static Char  *msg;
	Err err;
	MyUserData *myUserData;
	UInt32 processor, result;
	
	
	if (!writeAble) return errNone;

		
	msg=(Char *)MemPtrNew(100);
	StrPrintF(msg, "size %lu total %lu byte %u\r\n", size, gTotal+size, ((unsigned short *)bufP)[0]);
	
	VFSFileWrite(log, StrLen(msg), msg, NULL); 
	//VFSFileWrite(log, size, bufP, NULL);
	
	err=DmWrite(bitmapData,gTotal,bufP,size);
	
	/*
	if (err==dmErrWriteOutOfBounds) {
		StrPrintF(msg, "Out of Bounds\r\n");
		VFSFileWrite(log, StrLen(msg), msg, NULL);
	}
	*/
	
	gTotal+=size;
	
	if (gTotal==614400L) {
		myUserData=(MyUserData *)MemPtrNew(sizeof(MyUserData));
		myUserData->myPtrFree=&myPtrFree;
		myUserData->myFileWriter=&myFileWriter;
		myUserData->ftrMemory=bitmapData;
		myUserData->errorMessager=&errorMessager;
		myUserData->width=640;
		myUserData->height=480;
		myUserData->RGB=typeRGB;
		

		// call the ARMlet
		FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

		if (sysFtrNumProcessorIsARM(processor))
		{
			MemHandle mh;
			NativeFuncType *armlet;
			UInt32 result;
			
			mh = DmGetResource('ARMC', 2);
			*armlet = (NativeFuncType *)MemHandleLock(mh);

			result = PceNativeCall(armlet, myUserData);
			
			MemHandleUnlock(mh);
			DmReleaseResource(mh);
			MemPtrFree(myUserData);
		}
		else if (sysFtrNumProcessorx86) {
			result = PceNativeCall(
			(NativeFuncType*)"c:\\ARMletC.dll\0NativeFunction", // default dll path is the location of PalmSim.exe
			myUserData);
			MemPtrFree(myUserData);
		}
			
	}
	// Simulate a long capture time
	//SysTaskDelay(sysTicksPerSecond / 2);
	
	MemPtrFree(msg);
	return errNone;
}

static Err CameraLibCaptureCallback()
{
	MyCallbackDataType data;
	CamLibCaptureType capture;
	Err err 	= errNone;
	data.bmpH 	= 0;
	
	if (gCameraRefNum == sysInvalidRefNum)
		return kCamLibErrNotOpen;

	capture.userDataP = &data;
	capture.callbackP = MyCaptureCallback;
	err = CamLibControl(gCameraRefNum, kCamLibCtrlCapture, &capture);
	if (err == errNone)
	{
		if (data.bmpH)
			MemHandleFree(data.bmpH);
	}
	return err;
}

#if 0
#pragma mark -
#endif

/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: Form event handler.
 *				Note: You should handle all the events that bring a UI
 *				up while in preview mode because the proview rectangle
 *				will overwrite anything. For example, if you try to bring
 *				the Find dialog, you'll see the preview drawn on top of 
 *				part of it. This is a sample code.
 *
 * PARAMETERS:	eventP		- Pointer to an event
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/

static Boolean MainFormHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormType *frmP = FrmGetActiveForm();
	UInt16 volRefNum;
	UInt32 volIterator=vfsIteratorStart;
	Err err;
	Char msg[100];
	UInt32 w=640, h=480;


	switch(eventP->eType)
	{
		case frmCloseEvent:
			VFSFileClose(log);
			VFSFileClose(fp);			
			FtrPtrFree(appFileCreator,0);

			
			break;
	
		case frmOpenEvent:
			FrmDrawForm(frmP);	
			handled = true;
	
			err=VFSVolumeEnumerate(&volRefNum, &volIterator);
	  		
	  		err=VFSFileOpen(volRefNum,"/DCIM/log.txt",vfsModeWrite | vfsModeCreate ,&log);
	 	  	err=VFSFileOpen(volRefNum,"/DCIM/picTest.jpg",vfsModeWrite | vfsModeCreate ,&fp);

			err=FtrPtrNew(appFileCreator,0,614400L/*w*h*sizeof(UInt16)*/, (void **)&bitmapData);

			if (err) FrmAlert(RomIncompatibleAlert);
			break;
		
		//
		// Handle control select events
		//	
		case ctlSelectEvent:
			switch(eventP->data.ctlSelect.controlID)
			{
			case Options:
				ShowSettingsDialog(gCameraRefNum);
				handled = true;
				break;
			}
			break;
		
		//
		// Handle the key dowm events
		//		
		case keyDownEvent:
			
			if( EvtKeydownIsVirtual(eventP) && (eventP->data.keyDown.chr == vchrCameraShutter ) )
			{
				CamLibControl(gCameraRefNum, kCamLibCtrlCaptureFormatSet,(void *)&gRGB );
				if (gTotal>0) writeAble=false;
				VFSFileWrite(log, StrLen("KEY PRESS\r\n"), "KEY PRESS\r\n", NULL); 
				gTotal=0;
				StopCameraPreview(gCameraRefNum);
				SetCaptureSize(gCameraRefNum, &gVGAImage);
				CameraLibCaptureCallback();	
				SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
				StartCameraPreview(gCameraRefNum);
				handled = true;
			}
			break;
			
		//
		// Handle the pop-up trigger event
		//	
		case popSelectEvent:
			switch(eventP->data.popSelect.controlID)
			{
			case PreviewSize:
				if( gPreviewIsOn ) {
					StopCameraPreview(gCameraRefNum);
					FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
				}
				if( eventP->data.popSelect.selection == 0 )
				{
					gCurrentPreviewSize.type = kCamLibImageSizeQQVGA;
					gPreviewRectangle = &gPreviewQQVGARectangle;
				}
				else
				{
					gCurrentPreviewSize.type = kCamLibImageSizeQVGA;
					gPreviewRectangle = &gPreviewQVGARectangle;
				}
				
				SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
				SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
				SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
				
				if( gPreviewIsOn )
					StartCameraPreview(gCameraRefNum);
				break;
				
			default:
				break;
			}
			break;
			
		default:
			break;
	}
	
	return handled;
}

/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: Main application event handler.
 *
 * PARAMETERS:	eventP		- Pointer to an event.
 *
 * RETURNED:	True if event was handled.
 *
 ***********************************************************************/
 
static Boolean AppHandleEvent(EventType *eventP)
{
	UInt16 formId = 0;
	FormType *frmP = NULL;
	
	if(eventP->eType == frmLoadEvent)
	{
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);
		
		switch (formId)
		{
		case MainForm:
			FrmSetEventHandler(frmP, MainFormHandleEvent);
			break;
			
		default:
			break;
		}
		return true;
	}
	
	return false;
}

/***********************************************************************
 *
 * FUNCTION:    ApplEventLoop
 *
 * DESCRIPTION: Main Application event loop.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/
 
static void AppEventLoop(void)
{
	Err error = errNone;
	EventType event;
	
	do
	{
		EvtGetEvent(&event, evtWaitForever);
				
		if(!SysHandleEvent(&event))
		{
			if (! MenuHandleEvent(0, &event, &error))
			{
				if(!AppHandleEvent(&event))
				{
					FrmDispatchEvent(&event);
				}
			}
		}
	} while(event.eType != appStopEvent);
}

/***********************************************************************
 *
 * FUNCTION:    AppStart
 *
 * DESCRIPTION: Called when the application starts
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err AppStart(void)
{	
	Err err = errNone;
	
	// Load the camera library
	err = LoadCameraLib(&gCameraRefNum);
	if( err )
		goto Done;
	
	// Check if the slider is available
	if( IsCameraSliderAvailable() )
	{
		// Register for slider notification
		err = RegisterCameraSlider(kSliderNotificationPriority, SliderNotifyProc, NULL);
		if( err == errNone )
			gIsSliderRegistered = true;
	}
	
	// Save current screen color depth
	WinScreenMode(winScreenModeGet, 0, 0, &gPreviousDepth, 0);
	
	// Switch to 16bit color
	err = SetScreenDepth(16);
	
	// Check the current slider status
	if( IsCameraSliderAvailable() && IsCameraSliderOpen() )
	{
		// Turn the camera on
		err = TurnCameraOn(gCameraRefNum);
		if(err)
			goto Done;
							
		gCameraIsOn = true;
		
		// Set the capture size
		err = SetCaptureSize(gCameraRefNum, &gCurrentPreviewSize);
		if(err)
			goto Done;
		
		// Set the preview size	
		err = SetPreviewSize(gCameraRefNum, &gCurrentPreviewSize);
		if(err)
			goto Done;
		
		// Set the preview rectangle
		err = SetPreviewRectangle(gCameraRefNum, gPreviewRectangle);
		if(err)
			goto Done;
		
		// Start the preview
		err = StartCameraPreview(gCameraRefNum);
		if(err)
			goto Done;
			
		
			
		gPreviewIsOn = true;
	}
	
Done:
	return err;
}

/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Called when the application exits
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static void AppStop(void)
{
	// Stop the preview
	if( gPreviewIsOn )
	{
		StopCameraPreview(gCameraRefNum);
		gPreviewIsOn = false;
	}

	// Turn the camera off	
	if( gCameraIsOn )
	{
		TurnCameraOff(gCameraRefNum);
		gCameraIsOn = false;
	}
	
	// Unregister the slider notification
	if( gIsSliderRegistered )
	{
		UnregisterCameraSlider(kSliderNotificationPriority);
	}
	
	// Restore the previous color depth
	if( gPreviousDepth )
		SetScreenDepth(gPreviousDepth);
	
	// Close all the forms
	FrmCloseAllForms();
}

/* all code from here to end of file should use no global variables */
#pragma warn_a5_access on

/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check the if the ROM is compatible with the application
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
    UInt32 romVersion;

    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion < requiredVersion)
    {
        if ((launchFlags & 
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
        {
            FrmAlert (RomIncompatibleAlert);

             if (romVersion < kPalmOS20Version)
            {
                AppLaunchWithCommand(
                    sysFileCDefaultApp, 
                    sysAppLaunchCmdNormalLaunch, NULL);
            }
        }

        return sysErrRomIncompatible;
    }

    return errNone;
}

/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: Main entry point for the application.
 *
 * PARAMETERS:	-
 *
 * RETURNED:	-
 *
 ***********************************************************************/

UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
    Err error;

    error = RomVersionCompatible (ourMinVersion, launchFlags);
    if (error) return (error);

    switch (cmd)
    {
    case sysAppLaunchCmdNormalLaunch:
        error = AppStart();
        if (error) 
            return error;

        FrmGotoForm(MainForm);
        AppEventLoop();
        
        AppStop();
        break;

    default:
        break;
    }

    return errNone;
}

/* turn a5 warning off to prevent it being set off by C++
 * static initializer code generation */
#pragma warn_a5_access reset
