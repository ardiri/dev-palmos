	//we can use this include file to hold
	//all the typedef structs that we need for
	//call68KFunc

#ifndef ARMLET_H
#define ARMLET_H

	typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileWriter;
		void *myFileReader;
		void *errorMessager;
		unsigned short width;
		unsigned short height;
		unsigned short xOffset;
		unsigned short yOffset;
		unsigned short RGB;
	} MyUserData;	
	

	typedef struct _MyFileWriteData {
		void *buf;
		unsigned int buflength;
		unsigned int *written;
	} MyFileWriteData;

	typedef struct _MyMemSetData {
		void *ptr;
		unsigned int numBytes;
		char value;
	} MyMemSetData;
	
	typedef struct _MyMemMoveData {
		void *dest;
		void *src;
		unsigned long numBytes;
	} MyMemMoveData;

	typedef struct _MyStrPrintFDataS {
		char *buffer;
		char *msg;
		char *str;
	} MyStrPrintFDataS;

	typedef struct _MyStrPrintFDataN {
		char *buffer;
		char *msg;
		int i0;
		int i1;
		int i2;
		int i3;
		int i4;
		int i5;
		int i6;
		int i7;
	} MyStrPrintFDataN;

 #define JPEG_NATURAL_ORDER_DEFINITION const int jpeg_natural_order[DCTSIZE2+16] = {\
  0,  1,  8, 16,  9,  2,  3, 10,\
 17, 24, 32, 25, 18, 11,  4,  5,\
 12, 19, 26, 33, 40, 48, 41, 34,\
 27, 20, 13,  6,  7, 14, 21, 28,\
 35, 42, 49, 56, 57, 50, 43, 36,\
 29, 22, 15, 23, 30, 37, 44, 51,\
 58, 59, 52, 45, 38, 31, 39, 46,\
 53, 60, 61, 54, 47, 55, 62, 63,\
 63, 63, 63, 63, 63, 63, 63, 63,\
 63, 63, 63, 63, 63, 63, 63, 63\
};

#define BLUEMASK 0x001F //0000000000011111
#define GREENMASK  0x07C0 //0000011111000000
#define REDMASK 0xF800 //1111100000000000

#define typeRGB 1
#define typeYUV 0

	
	#endif