	//we can use this include file to hold
	//all the typedef structs that we need for
	//call68KFunc

#ifndef ARMLET_H
#define ARMLET_H

	typedef struct _DmWriteArgsType {
		void *dest;
		unsigned  int offset;
		void *src;
		unsigned int bytes;
	} DmWriteArgsType;

	typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileWriter;
		void *myFileReader;
		void *errorMessager;
		unsigned short width;
		unsigned short height;
		unsigned short xOffset;
		unsigned short yOffset;
		unsigned short RGB;
	} MyUserData;
	
	typedef struct _MyFileReadData {
		void *buf;
		unsigned int buflength;
		unsigned int *read;
	} MyFileReadData;

	
	typedef struct _MyMemSetData {
		void *ptr;
		unsigned int numBytes;
		char value;
	} MyMemSetData;

	typedef struct _MyMemMoveData {
		void *dest;
		void *src;
		unsigned long numBytes;
	} MyMemMoveData;

	typedef struct _MyStrPrintFDataS {
		char *buffer;
		char *msg;
		char *str;
	} MyStrPrintFDataS;

	typedef struct _MyStrPrintFDataN {
		char *buffer;
		char *msg;
		int i0;
		int i1;
		int i2;
		int i3;
		int i4;
		int i5;
		int i6;
		int i7;
	} MyStrPrintFDataN;

#define JPEG_NATURAL_ORDER_DEFINITION const int jpeg_natural_order[DCTSIZE2+16] = {\
  0,  1,  8, 16,  9,  2,  3, 10,\
 17, 24, 32, 25, 18, 11,  4,  5,\
 12, 19, 26, 33, 40, 48, 41, 34,\
 27, 20, 13,  6,  7, 14, 21, 28,\
 35, 42, 49, 56, 57, 50, 43, 36,\
 29, 22, 15, 23, 30, 37, 44, 51,\
 58, 59, 52, 45, 38, 31, 39, 46,\
 53, 60, 61, 54, 47, 55, 62, 63,\
 63, 63, 63, 63, 63, 63, 63, 63,\
 63, 63, 63, 63, 63, 63, 63, 63\
};

#define EXTEND_TEST_DEFINITION  const int extend_test[16] =  \
  { 0, 0x0001, 0x0002, 0x0004, 0x0008, 0x0010, 0x0020, 0x0040, 0x0080,\
    0x0100, 0x0200, 0x0400, 0x0800, 0x1000, 0x2000, 0x4000 };

#define EXTEND_OFFSET_DEFINITION const int extend_offset[16] = \
  { 0, ((-1)<<1) + 1, ((-1)<<2) + 1, ((-1)<<3) + 1, ((-1)<<4) + 1,\
    ((-1)<<5) + 1, ((-1)<<6) + 1, ((-1)<<7) + 1, ((-1)<<8) + 1,\
    ((-1)<<9) + 1, ((-1)<<10) + 1, ((-1)<<11) + 1, ((-1)<<12) + 1,\
    ((-1)<<13) + 1, ((-1)<<14) + 1, ((-1)<<15) + 1 };


	
#endif
