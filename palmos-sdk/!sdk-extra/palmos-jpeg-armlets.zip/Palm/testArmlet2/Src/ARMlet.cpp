#include "PACEInterface.h"
#include <size_t.h>
#include <cstddef>
#include <stdio.h>
#include <string.h>
extern "C" {
#include "jpeglib.h" 
}
class ARMlet : public PACEInterface
{
public:
	void *m_userData68KP;
	
    //note that we have made m_userData68KP in our class
    //whereas m_emulStateP and m_call68KFuncP are inherited from
    //PACEInterface
    
	ARMlet(
		const void *emulStateP, 
		Call68KFuncType *call68KFuncP) :
		PACEInterface(emulStateP, call68KFuncP)
		{ 
		
		
		}

	unsigned long Run();
};

unsigned long ARMlet::Run()
{
			
		unsigned int w=320, h=320, lineSize, i, j, offset, numMsg;	 	
		unsigned short *dataLine, yLimit;
		unsigned long size;
		unsigned short blue, red, green;
		DmWriteArgsType dmArgs;
		void *myPtrFree;
		MyUserData *userData;		
		//jpeg lib test
		struct jpeg_decompress_struct cinfo;
		struct jpeg_error_mgr jerr;
		JSAMPROW row[1];
		unsigned char buffer[2000];
		float scale, hRatio, wRatio;
		unsigned short screenWidth, screenHeight, yOffset, *offsets; 
		unsigned int outputLineSize, xOffset, xFloor, scanWidth;
		float xMult, yMult, usedMult, yF, xScaled;
		
		char *msg;
			    
		
		userData=(MyUserData *)m_userData68KP;
		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;
	 		
		
		cinfo.err = jpeg_std_error(&jerr);
		
		
		jpeg_create_decompress(&cinfo);
	
		
  		cinfo.myUserData=userData;
		cinfo.emulStateP=m_emulStateP;
		cinfo.call68KFuncP=m_call68KFuncP;

		jpeg_stdio_src(&cinfo, NULL);
        
        
		jpeg_read_header(&cinfo, TRUE);
		//set parameters here
						
		screenWidth=ByteSwap16(userData->width);
		screenHeight=ByteSwap16(userData->height);

		hRatio=(float)cinfo.image_height/(float)screenHeight;
		wRatio=(float)cinfo.image_width/(float)screenWidth;
	
		if (hRatio>wRatio) scale=hRatio;
		else scale=wRatio;
		if (scale<1) scale=1;
		
		cinfo.scale_denom=(int)(scale+0.5);

		if (cinfo.scale_denom == 3) cinfo.scale_denom=4;
		if (cinfo.scale_denom > 4 && cinfo.scale_denom < 8)
			cinfo.scale_denom=8;
	
		cinfo.out_color_space=JCS_RGB;

		row[0]=buffer;

		xOffset=0;
		yOffset=0;
		
		cinfo.do_fancy_upsampling=FALSE;
	    cinfo.dct_method=JDCT_IFAST;
		
		

		if ( scale - (float)((int)scale)<0.001 ) {
		//no interpolation
		
			jpeg_start_decompress(&cinfo);
			
			xOffset=(screenWidth-cinfo.output_width)/2;
			yOffset=(screenHeight-cinfo.output_height)/2;


			userData->width=ByteSwap16(cinfo.output_width);
			userData->height=ByteSwap16(cinfo.output_height);
		
			lineSize=screenWidth*sizeof(unsigned short);
			size=ByteSwap32(lineSize);
			dataLine=(unsigned short *)((m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));
			for (j=0;j<screenWidth;j++) dataLine[j]=0;


			for (j=0;j<cinfo.output_height;j++) {
				if (cinfo.output_scanline < cinfo.output_height) 
						jpeg_read_scanlines(&cinfo, row, 1);
				
				for (i=0;i<screenWidth-xOffset*2;i++) {			
					offset=i*3;
					
					red=buffer[offset]>>3; 
					green=buffer[offset+1]>>3;
					blue=buffer[offset+2]>>3;
					//blue gets the 6 low bits, green the next 5, and red the high 5 bits					
					dataLine[i+xOffset]=0;  				
					dataLine[i+xOffset]|=blue;
					dataLine[i+xOffset]|=green<<6;
					dataLine[i+xOffset]|=red<<11;
					dataLine[i+xOffset]=ByteSwap16(dataLine[i+xOffset]);
					
					
				}
				dmArgs.dest=userData->ftrMemory;
				dmArgs.offset=ByteSwap32(lineSize*(j+yOffset));
				dmArgs.src=(unsigned short *)ByteSwap32(dataLine);
				dmArgs.bytes=ByteSwap32(lineSize);
				(m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,
				16);			
				
			}
		}
		else {
		//nearest neighbor interpolation
			
			cinfo.scale_denom/=2;

			jpeg_start_decompress(&cinfo);

			lineSize=cinfo.output_width*sizeof(unsigned short);
			outputLineSize=screenWidth*sizeof(unsigned short);
			size=ByteSwap32(lineSize);
			dataLine=(unsigned short *)((m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));
			
			for (j=0;j<cinfo.output_width;j++) dataLine[j]=0;
			
			xMult=(float)cinfo.output_width/(float)screenWidth;
			yMult=(float)cinfo.output_height/(float)screenHeight;
			if (yMult > xMult) {
				usedMult=yMult;
				xOffset=(screenWidth - (int)(cinfo.output_width/yMult+0.5))/2;
				userData->width=ByteSwap16(screenWidth-xOffset*2);
				userData->height=ByteSwap16(screenHeight);

			}
			else  {			
				usedMult=xMult;
				userData->width=ByteSwap16((int)(cinfo.output_height/xMult + 0.5));
				userData->height=ByteSwap16(screenHeight);
				yOffset=(screenHeight - (int)(cinfo.output_height/xMult+0.5))/2;

			}
			
			scanWidth=screenWidth-xOffset*2;
			size=ByteSwap32( scanWidth*sizeof(unsigned short));
			offsets=(unsigned short *)((m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapMemPtrNew),&size,
				4 | kPceNativeWantA0));
			for (i=0;i<scanWidth;i++) {		
					xScaled=usedMult*i;
					xFloor=(unsigned int)xScaled;
					if (xScaled - (float)xFloor > 0.5) xFloor++;
					offsets[i]=xFloor*3;
			}
			
			yLimit=(int)(cinfo.output_height/usedMult);
			if (yLimit > screenHeight - 1) yLimit=screenHeight-1;	
			
			jpeg_read_scanlines(&cinfo, row, 1);
			
			for (j=0;j<=yLimit;j++) {

				
				yF=usedMult*j; 
				
				if ((yF - (float)(cinfo.output_scanline - 1) > 0.5) && 
					(cinfo.output_scanline < cinfo.output_height))
							jpeg_read_scanlines(&cinfo, row, 1);
					
				for (i=0;i<scanWidth;i++) {		
						
						red=buffer[offsets[i]]>>3; 
						green=buffer[offsets[i]+1]>>3;
						blue=buffer[offsets[i]+2]>>3;
					//blue gets the 6 low bits, green the next 5, and red the high 5 bits
					
						dataLine[i+xOffset]=0;  				
						dataLine[i+xOffset]|=blue;
						dataLine[i+xOffset]|=green<<6;
						dataLine[i+xOffset]|=red<<11;
						dataLine[i+xOffset]=ByteSwap16(dataLine[i+xOffset]);
						
					
				
				}
				//don't have to byte swap because we never byte swapped it in the first place
				dmArgs.dest=userData->ftrMemory;
				dmArgs.offset=ByteSwap32(outputLineSize*(j+yOffset));
				dmArgs.src=(unsigned short *)ByteSwap32(dataLine);
				dmArgs.bytes=ByteSwap32(outputLineSize);
				(m_call68KFuncP)(m_emulStateP,PceNativeTrapNo(sysTrapDmWrite),&dmArgs,16);
			
				if (cinfo.output_scanline < cinfo.output_height) 
					jpeg_read_scanlines(&cinfo, row, 1);
				
			}

			while (cinfo.output_scanline < cinfo.output_height) {
				jpeg_read_scanlines(&cinfo, row, 1);
			}
			
			//free(offsets);
			myPtrFree=(void *)ByteSwap32(userData->myPtrFree);
			offsets=(unsigned short *)ByteSwap32(offsets);
			(m_call68KFuncP)(m_emulStateP,(unsigned long)myPtrFree,&offsets,4);
			
		}

		
		jpeg_finish_decompress(&cinfo);
		
		jpeg_destroy_decompress(&cinfo);
		
		userData->xOffset=ByteSwap16(xOffset);
		userData->yOffset=ByteSwap16(yOffset);


		myPtrFree=(void *)ByteSwap32(userData->myPtrFree);
		//so you need the address of the function pointer in ARMish
	    dataLine=(unsigned short *)ByteSwap32(dataLine);
		(m_call68KFuncP)(m_emulStateP,(unsigned long)myPtrFree,&dataLine,4);
		//note that we always need the address of the function arguments, so in this case the address of a pointer (address of address)
    	
    	
    
	return 0;
}

// ------------------------

extern "C"
unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP);

unsigned long ARMlet_Main(
	const void *emulStateP, 
	void *userData68KP, 
	Call68KFuncType *call68KFuncP)
{
	ARMlet armlet(emulStateP, call68KFuncP);
	armlet.m_userData68KP=userData68KP;
	return armlet.Run();
}
