/******************************************************************************
 *
 * File: Starter.cpp
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <PCENativeCall.h>
#include "StarterRsc.h"
#include "JpegRsc.h"
#include <VFSMgr.h>

typedef struct _Point { int x; int y; struct _Point *next; } Point;
void myPtrFree(void *);
void myFileReader(void *buf,unsigned long buflength, unsigned long *read);
void errorMessager(char *);
void drawline(Point ** point, int x0, int y0, int x1, int y1);
/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'STRT'	// register your own at http://www.palmos.com/dev/creatorid/
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01

// Define the minimum OS version we support (2.0 for now).
#define kOurMinVersion	sysMakeROMVersion(2,0,0,sysROMStageRelease,0)
#define kPalmOS10Version	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)


/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/
FileRef fp;
void myPtrFree(void *ptr) {

	MemPtrFree(ptr);
	return;
	
}
void myFileReader(void *buf,unsigned long buflength, unsigned long *read) { 

	VFSFileRead(fp, buflength, buf,read);
	
	//note that fp is a global
}

void errorMessager(char *msg) {
	SysFatalAlert(msg);
}
/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion <= kPalmOS10Version)
				{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return sysErrRomIncompatible;
		}

	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    void *
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void * GetObjectPtr(UInt16 objectID)
{
	FormPtr frmP;

	frmP = FrmGetActiveForm();
	return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr /*frmP*/)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;
	FormPtr frmP;

	switch (command)
		{
		case MainOptionsAboutStarterApp:
			MenuEraseStatus(0);					// Clear the menu status from the display.
			frmP = FrmInitForm (AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			break;

		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
	Boolean handled = false;
	FormPtr frmP;
	UInt32 processor;
	
	typedef struct _MyUserData {
		void *ftrMemory;
		void *myPtrFree;
		void *myFileWriter;
		void *myFileReader;
		void *errorMessager;
		UInt16 width;
		UInt16 height;
		UInt16 xOffset;
		UInt16 yOffset;
		UInt16 RGB;
	} MyUserData;
	
	MyUserData *myUserData;
	
	BitmapType *bmpP; 
	Err error; 
	BitmapTypeV3 *bmp3;
	static UInt16 *bitmapData;
	UInt16 static oldX, oldY;
	static UInt32 w, h;
	Err err;
	UInt16 volRefNum;
	static UInt16 blueShort, whiteShort;
	UInt32 volIterator=vfsIteratorStart;
	UInt32  result, screenDepth=16, supportedDepths;
	static RGBColorType blue, white, oldFore, oldBack;
//	static boolean usingWhite;
	PointType p;
	Point *oldPoint, *newPoint;
	
	char msg[100];
	
	
	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);
			break;
			
		case frmCloseEvent:	
			FtrPtrFree(appFileCreator,0);
	  		break;
	  		
	  		
		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);
			
			blue.b=255;
			blue.g=0;
			blue.r=0;
			white.b=255;
			white.g=255;
			white.r=255;
			blueShort=0;
			blueShort|=31;
			whiteShort=0;
	
			h=320;
			w=320;		
			
			
			
	  		//Open the VFS file for reading
	  		
	  		err=VFSVolumeEnumerate(&volRefNum, &volIterator);
	  		if (err!=errNone) FrmCustomAlert(JpegError,"Unable to get volume reference",NULL,NULL);
	  		
	  		err=VFSFileOpen(volRefNum,"/DCIM/testphoto1.jpg",vfsModeRead,&fp);
	  		if (err) FrmCustomAlert(JpegError,"Unable to open file",NULL,NULL);
	  	
	  		
	  		
	  		//allocate feature memory, where we will put the 
	  		//decoded image. But this will have to be done
	  		//from the armlet because we won't know the size 
	  		//ahead of time
	  		error=FtrPtrNew(appFileCreator,0,w*h*sizeof(UInt16), (void **)&bitmapData);
	  		DmSet(bitmapData, 0, w*h*sizeof(UInt16), 0);
	  		
	  		myUserData=(MyUserData *)MemPtrNew(sizeof(MyUserData));
	  		myUserData->myPtrFree=&myPtrFree;
	  		myUserData->myFileReader=&myFileReader;
	  		myUserData->ftrMemory=bitmapData;
	  		myUserData->errorMessager=&errorMessager;
	  		myUserData->width=w;
	  		myUserData->height=h;

			// call the ARMlet
			FtrGet(sysFtrCreator, sysFtrNumProcessorID, &processor);

			if (sysFtrNumProcessorIsARM(processor))
			{
				MemHandle mh;
				NativeFuncType *armlet;
				UInt32 result;
				
				mh = DmGetResource('ARMC', 1);
				*armlet = (NativeFuncType *)MemHandleLock(mh);

				result = PceNativeCall(armlet, myUserData);
				
				MemHandleUnlock(mh);
				DmReleaseResource(mh);
				MemPtrFree(myUserData);
			}
			else if (sysFtrNumProcessorx86) {
				result = PceNativeCall(
				(NativeFuncType*)"c:\\ARMlet.dll\0NativeFunction", // default dll path is the location of PalmSim.exe
				myUserData);
				MemPtrFree(myUserData);
			}
			
			VFSFileClose(fp);
			
			
			//WinPushDrawState();
	  		//WinSetCoordinateSystem(kCoordinatesDouble);
	  		
	  		//WinScreenMode(winScreenModeGet, NULL, NULL, &supportedDepths, NULL);
	  		//if (0x8000 & supportedDepths) //if 16 bit supported, change to it
	  		 
	  		 WinScreenMode(winScreenModeSet,NULL, NULL, &screenDepth, NULL);
	  		//else 
	  		//	DbgMessage("help!\n");
	  		
	  		
	  		bmpP = BmpCreate(w, h, 16, NULL, &error); 
	  		
			bmp3=BmpCreateBitmapV3(bmpP,kDensityDouble,(const void *)bitmapData,NULL);
				  		
				  		
				  		
			if (bmp3) { 
		 		
		  		WinDrawBitmap((BitmapType *)bmp3,0,0);  		
		  		BmpDelete((BitmapType *)bmp3);
		  		BmpDelete(bmpP);
		  		
	  		}
	  		
	  		//WinPopDrawState();
			
			
						
			handled = true;
			break;
			
		case frmUpdateEvent:
			// To do any custom drawing here, first call FrmDrawForm(), then do your
			// drawing, and then set handled to true.
			break;


		case penDownEvent:
			
			WinSetForeColorRGB(&blue, &oldFore);
			WinSetBackColorRGB(&white, &oldBack);
		
			oldX=eventP->screenX;
			oldY=eventP->screenY;
			
			//WinDrawPixel(eventP->screenX, eventP->screenY);
			break;
		
		case penUpEvent:
			
			if (oldX==0 && oldY==0) return;
			WinDrawGrayLine(oldX, oldY, eventP->screenX, eventP->screenY);
			
			//need to multiply by 2
			drawline(&newPoint, 2*oldX, 2*oldY, 2*eventP->screenX, 2*eventP->screenY);
	 		while (newPoint != NULL) {
	 			//StrPrintF(msg, "x %d y %d\n", newPoint->x, newPoint->y);
				//DbgMessage(msg);
				DmWrite(bitmapData, w*newPoint->y+newPoint->x, &blueShort, 2); 

          		oldPoint=newPoint;
	   			newPoint=newPoint->next;
	   			MemPtrFree(oldPoint);
	 		}
			
			WinSetForeColorRGB(&oldFore, &blue);
			WinSetBackColorRGB(&oldBack, &white);

			break;
			
		case penMoveEvent:
			
			WinDrawGrayLine(oldX, oldY, eventP->screenX, eventP->screenY);
			
		    drawline(&newPoint, 2*oldX, 2*oldY, 2*eventP->screenX, 2*eventP->screenY);
	 		while (newPoint != NULL) {
	 			//StrPrintF(msg, "x %d y %d\n", newPoint->x, newPoint->y);
				//DbgMessage(msg);
				DmWrite(bitmapData, w*newPoint->y+newPoint->x, &blueShort, 2); 
		
          		oldPoint=newPoint;
	   			newPoint=newPoint->next;
	   			MemPtrFree(oldPoint);
	 		}
	 		
			oldX=eventP->screenX;
			oldY=eventP->screenY;
		
			break;
		
		default:
			break;
		
		}
	
	return handled;
}

//this is the Bresnahan line drawing algorithm
void
drawline (Point ** point, int x0, int y0, int x1, int y1)
{
  int dx, dy, incrE, incrNE, d, x, y, x2;
  float slope;
  Point *nextpoint, *lastpoint, *basepoint = NULL;


  if ((x0 == x1) && (y0 == y1))
    {
      nextpoint = (Point *) MemPtrNew (sizeof (Point));
      nextpoint->next = NULL;
      nextpoint->x = x0;
      nextpoint->y = y0;
      *point = nextpoint;
      return;
    }


  slope = (float) (y1 - y0) / ((float) (x1 - x0) + 0.00000001);


  if ((slope >= 0.0) && (slope <= 1.0))
    {
      if (x0 < x1)
	{
	  dx = x1 - x0;
	  dy = y1 - y0;
	  d = 2 * dy - dx;
	  incrE = 2 * dy;
	  incrNE = 2 * (dy - dx);
	  x = x0;
	  y = y0;
	  while (x < x1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  x++;
		}
	      else
		{
		  d += incrNE;
		  x++;
		  y++;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
      if (x1 < x0)
	{
	  dx = x0 - x1;
	  dy = y0 - y1;
	  d = 2 * dy - dx;
	  incrE = 2 * dy;
	  incrNE = 2 * (dy - dx);
	  x = x0;
	  y = y0;
	  while (x > x1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  x--;
		}
	      else
		{
		  d += incrNE;
		  x--;
		  y--;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
    }

  if (slope > 1.0)
    {
      if (y0 <= y1)
	{
	  dx = x1 - x0;
	  dy = y1 - y0;
	  d = 2 * dx - dy;
	  incrE = 2 * dx;
	  incrNE = 2 * (dx - dy);
	  x = x0;
	  y = y0;
	  while (y < y1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  y++;
		}
	      else
		{
		  d += incrNE;
		  x++;
		  y++;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
      if (y1 < y0)
	{
	  dx = x0 - x1;
	  dy = y0 - y1;
	  d = 2 * dx - dy;
	  incrE = 2 * dx;
	  incrNE = 2 * (dx - dy);
	  x = x0;
	  y = y0;
	  while (y > y1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  y--;
		}
	      else
		{
		  d += incrNE;
		  x--;
		  y--;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
    }


  if ((slope < 0) && (slope >= -1))
    {
      if (x0 <= x1)
	{
	  dx = x1 - x0;
	  dy = y0 - y1;
	  d = 2 * dy - dx;
	  incrE = 2 * dy;
	  incrNE = 2 * (dy - dx);
	  x = x0;
	  y = y0;
	  while (x < x1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  x++;
		}
	      else
		{
		  d += incrNE;
		  x++;
		  y--;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
      if (x0 > x1)
	{
	  dx = x0 - x1;
	  dy = y1 - y0;
	  d = 2 * dy - dx;
	  incrE = 2 * dy;
	  incrNE = 2 * (dy - dx);
	  x = x0;
	  y = y0;
	  while (x > x1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  x--;
		}
	      else
		{
		  d += incrNE;
		  x--;
		  y++;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
    }
  if (slope < -1.0)
    {
      if (y1 <= y0)
	{
	  dx = x1 - x0;
	  dy = y0 - y1;
	  d = 2 * dx - dy;
	  incrE = 2 * dx;
	  incrNE = 2 * (dx - dy);
	  x = x0;
	  y = y0;
	  while (y > y1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  y--;
		}
	      else
		{
		  d += incrNE;
		  x++;
		  y--;
		}
	      nextpoint = (Point *) MemPtrNew (sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
      if (y1 > y0)
	{
	  dx = x0 - x1;
	  dy = y1 - y0;
	  d = 2 * dx - dy;
	  incrE = 2 * dx;
	  incrNE = 2 * (dx - dy);
	  x = x0;
	  y = y0;
	  while (y < y1)
	    {
	      if (d <= 0)
		{
		  d += incrE;
		  y++;
		}
	      else
		{
		  d += incrNE;
		  x--;
		  y++;
		}

	      nextpoint = (Point *) MemPtrNew(sizeof (Point));
	      nextpoint->next = NULL;
	      nextpoint->x = x;
	      nextpoint->y = y;
	      if (basepoint == NULL)
		basepoint = nextpoint;
	      else
		lastpoint->next = nextpoint;
	      lastpoint = nextpoint;
	    }
	}
    }

  *point = basepoint;


}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent(EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;

	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;

	do {
		EvtGetEvent(&event, evtWaitForever);

		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
	// Close all the open forms.
	FrmCloseAllForms ();
}


/***********************************************************************
 *
 * FUNCTION:    StarterPalmMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPalmMain(UInt16 cmd, MemPtr /*cmdPBP*/, UInt16 launchFlags)
{
	Err error;

	error = RomVersionCompatible (kOurMinVersion, launchFlags);
	if (error) return (error);

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return errNone;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
	return StarterPalmMain(cmd, cmdPBP, launchFlags);
}
