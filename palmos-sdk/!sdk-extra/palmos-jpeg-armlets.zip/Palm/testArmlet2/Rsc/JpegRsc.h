/* pilrc generated file.  Do not edit!*/
#define JpegError 9998
