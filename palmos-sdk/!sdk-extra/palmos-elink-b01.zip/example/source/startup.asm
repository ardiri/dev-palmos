; Arm PalmOs Startup
; Entry point for arm programs


;  __text      offset to text section
;  __text_sz   size of text section
;  __rodata    offset to rodata section
;  __rodata_sz size of rodata section
;  __data      offset to data section
;  __data_sz   size of data section
;  __bss       offset to where bss section should start
;  __bss_sz    size of bss section
;  __got_x     offset to the got section (same as _GLOBAL_OFFSET_TABLE_)

;  __got_xsz   entire size of the got section

;  __got_bsz   entire size of the bss got section
;              should be the same as __bss_sz        

; __entry      start location after "startup/crt0" has finished

	SECTION .text
		
	global	_startup

	extern  __entry
			
	_startup:
		; Save the base start address into r0
		sub r0, pc, #8

		; Save all important information onto the stack		
		mov     ip, sp
	    stmdb   sp!, {sl, fp, ip, lr, pc}
        sub     fp, ip, #4      ; 0x4

		; allocate the .bss section onto the stack
		ldr     r3, [got_bsz]
		add     r3, r3, 12


		; Save R0..R2 on to the stack
        sub     sp, sp, r3
        str     r0, [fp, #-20] ; R0 is already corrupted by the time it gets here.
        str     r1, [fp, #-24]
        str     r2, [fp, #-28]	        	


		; Set the .got pointer
		ldr     sl, [got_x]
		add     sl, sl, r0
        	        		        	        		        							
		; correct the .got section
		mov r1, 0
		ldr r2, [got_xsz] ; number of words that need to be corrected
		
		
		; Handle the relocation
		bl  _relocation				
		
			
		; Allocate a new stack pointer here
		; Add code here

		
		; Call the defined entry point
        ldr     r0, [fp, #-20]
        ldr     r1, [fp, #-24]
        ldr     r2, [fp, #-28]	        	
		bl      __entry	
		
		; restore the old stack pointer and return to calling code
		ldmdb	fp, {sl, fp, sp, pc}
		

	_relocation:	
		; Check to see if the relocation is done
		cmp   r1, r2
		moveq pc, lr
		
		; Load the next offset into R3
		ldr   r3, [sl, r1]
		
		; Determine type of relocation (.bbs vs .rodata/.data)
		tst   r3, #0x80000000
		addeq r3, r3, r0  ; .rodata/.data

		; .bss relocation
		ldrne r5, [clr]   ; remove the .bss mask (0x80000000)		
		andne r3, r3, r5
		subne r3, fp, r3
		subne r3, r3, #32
		movne r5, 0
		strne r5, [r3]
		
		; Save the offset in r3 back to the .got table
		str   r3, [sl, r1]
				
        ; increase index and loop again				
		add   r1, r1, #4
		b     _relocation																																						

	clr:
		dcd   0xffffff7f  ; This comes out as 0x7fffffff

	got_x:
		extern _GLOBAL_OFFSET_TABLE_
	 	dcd    _GLOBAL_OFFSET_TABLE_	

   got_xsz:
		extern __got_xsz
	 	dcd    __got_xsz
			
	got_bsz:
		extern __got_bsz
	 	dcd    __got_bsz	 			