#pragma once

typedef int (*interface_proc)     (int iIndex, char *argv[], void *pData);

struct Rule
   {
   TCHAR *pToken;          // Pointer to token
   TCHAR *pDescription;    // Pointer to description for token

   void  *pData;

   DWORD  dwSize;

   interface_proc pHandle; // Pointer to code to handle token
   };


DWORD check_option (int argc, char *argv[], TCHAR *pOption, int iStart = 1);
DWORD read_option  (int argc, char *argv[], TCHAR *pOption, TCHAR *pBuffer, int uType, int *pSize);
DWORD exec_option  (int argc, char *argv[], struct Rule *pRuleZ, int iRuleCnt, DWORD dwIndex = -1);

DWORD check_option (int argc, char *argv[], TCHAR *pOption, int iStart)
{
   if (argc == 1) 
      return 0; // Only 1 option (program name)

   for (int uIndex = iStart; uIndex < argc; uIndex++)
      {
      if (!argv[uIndex])
         continue;

      if (stricmp (pOption, argv[uIndex])) 
         continue;

      return uIndex;
      }

   return 0;
}

DWORD read_option  (int argc, char *argv[], TCHAR *pOption, TCHAR *pBuffer, int uType, int *pSize)
{
   if (argc == 1) 
      return 0; // Only 1 option (vault)

   // Force pSize to correct size
   switch (uType)
      {
      case 1 : *pSize = 1; break; // Char
      case 2 : *pSize = 2; break; // Short
      case 3 : *pSize = 4; break; // Integer
      }

   memset (pBuffer, 0, *pSize);

   int uIndex = 0;
   if (!(uIndex = check_option (argc, argv, pOption)))
      return 0;

   if (uIndex+1 >= argc)
      return 0;

   if (argv[uIndex+1][0] == '-')
      return 0;
      
   if (!uType)
      {
      *pSize = min (*pSize, (int) strlen (argv[uIndex+1]));
      memcpy (pBuffer, argv[uIndex+1], *pSize);
      }
   else
      {
      UINT uValue;
      uValue = strtoul (argv[uIndex+1], NULL, 0);

      memcpy (pBuffer, &uValue, *pSize);
      }

   return uIndex;
}

DWORD exec_option  (int argc, char *argv[], struct Rule *pRuleZ, int iRuleCnt, DWORD dwIndex)
{
   for (int uIndex = 0; uIndex < iRuleCnt; uIndex++)
      {
      if (uIndex == dwIndex)
         continue;

      int iOption = 0;
      while ((iOption = check_option (argc, argv, pRuleZ[uIndex].pToken, ++iOption)))
         {         
         if (pRuleZ[uIndex].pHandle)
            pRuleZ[uIndex].pHandle (iOption, argv, pRuleZ[uIndex].pData);

         DWORD dwSize = pRuleZ[uIndex].dwSize;
         while (dwSize--)
            argv[iOption++] = NULL;
         }      
      }

   if (!(dwIndex != -1) || (!pRuleZ[dwIndex].pHandle)) 
      return 1;
  
   for (uIndex = 1; uIndex < argc; uIndex++)
      {
      if (!argv[uIndex]) 
         continue;

       pRuleZ[dwIndex].pHandle (uIndex, argv, pRuleZ[uIndex].pData);
      }

   return 1;
}