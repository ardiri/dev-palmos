bool check_option (int argc, char *argv[], TCHAR *pOption)
{
   if (argc == 1) 
      return 0; // Only 1 option (vault)

   for (int uIndex = 1; uIndex < argc; uIndex++)
      {
      if (argv[uIndex][0] != '-')
         continue;

      if (stricmp (pOption, argv[uIndex])) 
         continue;

      return 1;
      }

   return 0;
}


bool read_option  (int argc, char *argv[], TCHAR *pOption, TCHAR *pBuffer, int uType, int *pSize)
{
   if (argc == 1) 
      return 0; // Only 1 option (vault)

   // Force pSize to correct size
   switch (uType)
      {
      case 1 : *pSize = 1; break; // Char
      case 2 : *pSize = 2; break; // Short
      case 3 : *pSize = 4; break; // Integer
      }

   memset (pBuffer, 0, *pSize);

   for (int uIndex = 1; uIndex < argc; uIndex++)
      {
      if (argv[uIndex][0] != '-')
         continue;

      if (stricmp (pOption, argv[uIndex])) 
         continue;

      if (uIndex+1 >= argc)
         return 0;

      if (argv[uIndex+1][0] == '-')
         return 0;
      

      if (!uType)
         {
         *pSize = min (*pSize, (int) strlen (argv[uIndex+1]));
         memcpy (pBuffer, argv[uIndex+1], *pSize);
         return 1;
         }

      UINT uValue;
      uValue = strtoul (argv[uIndex+1], NULL, 10);
      if (argv[uIndex][0] == '0' && (argv[uIndex][1] == 'x' || argv[uIndex][1] == 'X'))
         uValue = strtoul (&argv[uIndex+1][2], NULL, 16);      

      memcpy (pBuffer, &uValue, *pSize);

      return 1;
      }

   return 0;
}
