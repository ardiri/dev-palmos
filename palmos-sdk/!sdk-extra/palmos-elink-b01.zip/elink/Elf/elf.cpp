#include "stdafx.h"

#include "..\ObjectFile.h"
#include "Elf.h"


CElf::CElf ()
{   
   TCHAR tcIdent[] = {ELFMAG0, ELFMAG1, ELFMAG2, ELFMAG3, ELFCLASS32, ELFDATA2LSB, EV_CURRENT, ELFOSABI_ARM, 0, 0, 0, 0, 0, 0, 0, 0}; 

   // Magic number and other info
   memcpy (m_Header.e_ident, tcIdent, sizeof (m_Header.e_ident));

   m_Header.e_type      = ET_EXEC;    // Object file type 
   m_Header.e_machine   = EM_ARM;     // Architecture 
   m_Header.e_version   = EV_CURRENT; // Object file version 
   m_Header.e_entry     = 0; // Entry point virtual address 
   m_Header.e_phoff     = 0; // Program header table file offset 
   m_Header.e_shoff     = 0; // Section header table file offset 
   m_Header.e_flags     = 0; // Processor-specific flags 
   m_Header.e_ehsize    = 0; // ELF header size in bytes
   m_Header.e_phentsize = 0; // Program header entry size
   m_Header.e_phnum     = 0; // Program header entry count
   m_Header.e_shentsize = sizeof (Elf32_Shdr);
   m_Header.e_shstrndx  = 8; // Section header stringtable index
   m_Header.e_shnum     = 10;

   DWORD dwSize = sizeof (struct Sections) * m_Header.e_shentsize;

   m_pSections = (struct Sections *) malloc (dwSize);
   memset (m_pSections, 0, dwSize);     

   // Create the ".strtab" section at index m_Header.e_shstrndx
   SectionAdd (_T(".strtab") , SHT_STRTAB  , 0x0, 0, m_Header.e_shstrndx);

   SectionAdd (_T(".symtab") , SHT_SYMTAB  , 0x0, sizeof (Elf32_Sym));
   SectionAdd (_T(".comment"), SHT_PROGBITS, 0x0, 0); // Holds the name of the tool set and linker
}


CElf::CElf (FILE *pFile, DWORD dwOffset) : CObjectFile(pFile, dwOffset)
{
   if (!IsValid ())
      return;

   m_dwOffset   = dwOffset;
   m_bBigEndian = 0;

   if (fread (&m_Header, sizeof (m_Header), 1, m_pFile) != 1)      
      {Secure (); return;}

   if (strncmp ((char *) m_Header.e_ident, ELFMAG, strlen (ELFMAG)))
      {Secure (); return;}

   if (m_Header.e_ident[EI_CLASS]   != ELFCLASS32) // Unsupported class
      {Secure (); return;}

   if (m_Header.e_ident[EI_VERSION] != EV_CURRENT)
      {Secure (); return;}

   if (m_Header.e_ident[EI_DATA]    == ELFDATA2MSB)
      m_bBigEndian = 1;

   Access();
}

CElf::~CElf (void)
{
   Secure ();

   for (UINT uIndex = 0; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (!m_pSections[uIndex].pData)
         continue;

      free (m_pSections[uIndex].pData);
      }

   delete (m_pSections);
}

BOOL CElf::Access (void)
{
   DWORD dwSize = sizeof (struct Sections) * m_Header.e_shnum;

   m_pSections = (struct Sections *) malloc (dwSize);
   memset (m_pSections, 0, dwSize);

   for (UINT uIndex = 0; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (fseek (m_pFile, (uIndex * m_Header.e_shentsize) + m_Header.e_shoff + m_dwOffset, SEEK_SET))
         break;

      if (!(fread (&m_pSections[uIndex].section, m_Header.e_shentsize, 1, m_pFile)))
         break;

      if (m_pSections[uIndex].section.sh_type == SHT_NOBITS)
         continue;

      if ((!m_pSections[uIndex].section.sh_size) || (!m_pSections[uIndex].section.sh_offset))
         continue;
      
      if (!(m_pSections[uIndex].pData = malloc (m_pSections[uIndex].section.sh_size)))
         continue;

      if (fseek (m_pFile, m_pSections[uIndex].section.sh_offset + m_dwOffset, SEEK_SET))
         break;
      
      if (!(fread (m_pSections[uIndex].pData, m_pSections[uIndex].section.sh_size, 1, m_pFile)))
         break;
      } 

   if (m_Header.e_shstrndx == SHN_UNDEF)
      return 1;

   // Repair all section names
   StrtabRepair (0);

   // Repair all symbols
   for (uIndex = 0; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (m_pSections[uIndex].section.sh_type != SHT_SYMTAB)
         continue;

      Elf32_Sym *_symbol, *_symbolx;

      for (UINT uOffset = m_pSections[uIndex].section.sh_entsize; uOffset < m_pSections[uIndex].section.sh_size; uOffset += m_pSections[uIndex].section.sh_entsize)
         {
         _symbol = (Elf32_Sym *) ((char *) m_pSections[uIndex].pData + uOffset);

         if ((_symbol->st_shndx == 0) || (_symbol->st_shndx > m_Header.e_shnum))
            continue;

         if (ELF32_ST_TYPE (_symbol->st_info) == STT_SECTION)
            continue;
   
         if (ELF32_ST_TYPE (_symbol->st_info) == STT_FILE   )
            continue;
         
         DWORD dwSize = m_pSections[_symbol->st_shndx].section.sh_size - _symbol->st_value;

         for (UINT uSearch = m_pSections[uIndex].section.sh_entsize; uSearch < m_pSections[uIndex].section.sh_size; uSearch += m_pSections[uIndex].section.sh_entsize)
            {
            _symbolx = (Elf32_Sym *) ((char *) m_pSections[uIndex].pData + uSearch);

            if (_symbolx->st_value == _symbol->st_value)
               continue;

            if (_symbol->st_shndx != _symbolx->st_shndx)
               continue;

            if (ELF32_ST_TYPE (_symbolx->st_info) == STT_SECTION)
               continue;
   
            if (ELF32_ST_TYPE (_symbolx->st_info) == STT_FILE   )
               continue;        

            if (_symbolx->st_value - _symbol->st_value < dwSize)
               dwSize = _symbolx->st_value - _symbol->st_value;  
            }

         _symbol->st_size = dwSize;
         }
      }
   

#if 1
//   printf ("Symbols:\n");

   for (uIndex = 0; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (m_pSections[uIndex].section.sh_type != SHT_SYMTAB)
         continue;

      DWORD dwStringTable = m_pSections[uIndex].section.sh_link;
      Elf32_Sym *_symbol;

      for (UINT uOffset = 0; uOffset < m_pSections[uIndex].section.sh_size; uOffset += m_pSections[uIndex].section.sh_entsize)
         {
         _symbol = (Elf32_Sym *) ((char *) m_pSections[uIndex].pData + uOffset);

         TCHAR *pName = ((TCHAR *) m_pSections[dwStringTable].pData + _symbol->st_name);

if (_symbol->st_shndx == 0xfff2)
   {
   DWORD dwSection = SectionFind (_T(".bss"));

   m_pSections[dwSection].section.sh_size += _symbol->st_size;

   _symbol->st_value = 0;
   _symbol->st_shndx = dwSection;
   }

//         printf ("0x%02x: %-30s 0x%08x 0x%04x 0x%02x %04x\n", uOffset / m_pSections[uIndex].section.sh_entsize, pName, _symbol->st_value, _symbol->st_size, _symbol->st_info, _symbol->st_shndx);
         }

      }
#endif

#if 0
   printf ("Relocations:\n");

   for (DWORD dwSection = 0; dwSection < m_Header.e_shnum; dwSection++)
      {
      if ((m_pSections[dwSection].section.sh_type != SHT_REL) && (m_pSections[dwSection].section.sh_type != SHT_RELA))
         continue;

      for (UINT uOffset = 0; uOffset < m_pSections[dwSection].section.sh_size; uOffset += m_pSections[dwSection].section.sh_entsize)
         {
         Elf32_Rel *_relocation;

         _relocation = (Elf32_Rel *) ((char *) m_pSections[dwSection].pData + uOffset);

         printf ("0x%02x: 0x%08x 0x%04x\n", uOffset / m_pSections[dwSection].section.sh_entsize, _relocation->r_offset, _relocation->r_info);
         }
      }
#endif

   return 1;
}

BOOL CElf::Secure (void)
{
   if (strlen (m_tcOutput))
      {
      FILE *pSave;
      if (!(pSave = (FILE *) fopen (m_tcOutput, "wb")))
         return 0;

      m_Header.e_shoff = sizeof (m_Header);

      if (!m_dwBinary)
         fwrite (&m_Header, sizeof (m_Header), 1, pSave);

      DWORD dwRelO = sizeof (m_Header) + (sizeof (Elf32_Shdr) * m_Header.e_shnum);

      // I need to repair all sections, do that now
      for (DWORD dwSection = 0; dwSection < m_Header.e_shnum; dwSection++)
         {
         m_pSections[dwSection].section.sh_info   = 0;
         m_pSections[dwSection].section.sh_offset = 0;

         if (m_pSections[dwSection].section.sh_size)
            {
            m_pSections[dwSection].section.sh_offset = dwRelO;
            dwRelO += m_pSections[dwSection].section.sh_size;
            }

         if (!m_dwBinary)
            fwrite (&m_pSections[dwSection].section, sizeof (Elf32_Shdr), 1, pSave);
         }

      for (DWORD dwSection = 0; dwSection < m_Header.e_shnum; dwSection++)
         {
         if (!m_pSections[dwSection].section.sh_size)
            continue;

         if ((!(m_pSections[dwSection].section.sh_flags & SHF_ALLOC)) && m_dwBinary)
            continue;

         fwrite (m_pSections[dwSection].pData, m_pSections[dwSection].section.sh_size, 1, pSave);
         }

      fclose (pSave);
      }

   return 1;
}

DWORD  CElf::StrtabAdd (TCHAR *pName)
{
   if (!pName || !strlen (pName))
      return 0;

   // Update the section name information
   DWORD dwOffset  = m_pSections[m_Header.e_shstrndx].section.sh_size+1;
   DWORD dwStrSize = dwOffset+strlen (pName)+2;

   TCHAR *tcData;
   if (tcData = (TCHAR *) malloc (dwStrSize))
      {
      memset  (tcData, 0, dwStrSize);

      if (m_pSections[m_Header.e_shstrndx].section.sh_size)
         memcpy  (tcData, m_pSections[m_Header.e_shstrndx].pData, dwOffset);

      if (m_pSections[m_Header.e_shstrndx].pData)
         free (m_pSections[m_Header.e_shstrndx].pData);            
      
      sprintf (&tcData[dwOffset], "%s", pName);

      m_pSections[m_Header.e_shstrndx].section.sh_size = dwStrSize;
      m_pSections[m_Header.e_shstrndx].pData = tcData;
      }         

   return dwOffset;
}

DWORD CElf::StrtabRepair (BOOL bDisplay)
{
   // Repair all section names
   for (UINT uIndex = 0; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (m_pSections[uIndex].section.sh_type == SHT_NULL)
         continue;

      m_pSections[uIndex].pName = ((TCHAR *) m_pSections[m_Header.e_shstrndx].pData) + m_pSections[uIndex].section.sh_name;     

      if (bDisplay)
         printf ("0x%02x: %-30s 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x\n", uIndex, m_pSections[uIndex].pName, m_pSections[uIndex].section.sh_flags, m_pSections[uIndex].section.sh_size, m_pSections[uIndex].section.sh_entsize, m_pSections[uIndex].section.sh_info, m_pSections[uIndex].section.sh_link);
      }

   return 1;
}

DWORD CElf::SectionType   (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].section.sh_type;
}

DWORD CElf::SectionAttr   (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].section.sh_flags;
}

DWORD CElf::SectionSize   (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].section.sh_size;
}

DWORD CElf::Reloc         (DWORD dwSection, DWORD dwSize)
{
   void *pReloc = NULL;

//   if (dwSize && (m_pSections[dwSection].section.sh_type != SHT_NOBITS))
   if (dwSize)
      {
      if (!(pReloc = malloc (dwSize)))
         return 0;

      memset (pReloc, 0, dwSize);

      if (m_pSections[dwSection].pData)
         {
         if (m_pSections[dwSection].section.sh_type != SHT_NOBITS)
            memcpy (pReloc, m_pSections[dwSection].pData, m_pSections[dwSection].section.sh_info);
  
         free (m_pSections[dwSection].pData);
         }
      }

   m_pSections[dwSection].section.sh_size = dwSize;
   m_pSections[dwSection].pData = pReloc;

   if (!(m_pSections[dwSection].section.sh_flags & SHF_ALLOC))
      return 1;

   DWORD dwRelO = m_pSections[dwSection].section.sh_offset + dwSize;

   for (dwSection++; dwSection < m_Header.e_shnum; dwSection++)
      {
      if (m_pSections[dwSection].section.sh_flags & SHF_ALLOC)
         {
         m_pSections[dwSection].section.sh_offset = dwRelO;

         dwRelO += m_pSections[dwSection].section.sh_size;
         }
      }

   return 1;
}

DWORD CElf::SectionSize   (DWORD dwSection, DWORD dwSize)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   // Allocate data for section
   return Reloc (dwSection, dwSize);
}

DWORD CElf::SectionInfo   (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].section.sh_info;
}

DWORD CElf::SectionAddr   (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].section.sh_offset;
}

DWORD CElf::SectionFind   (TCHAR *pName)
{
   for (DWORD dwSection = 1; dwSection < m_Header.e_shnum; dwSection++)
      {
      if (m_pSections[dwSection].section.sh_type == SHT_NULL)
         continue;

      if (strcmp (pName, m_pSections[dwSection].pName))
         continue;

      return dwSection;
      }

   return 0;
}

DWORD *CElf::SectionVal   (DWORD dwSection, DWORD dwOffset)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

//   dwOffset /= 4;
   
   return (DWORD *) ((TCHAR *) m_pSections[dwSection].pData + dwOffset);
}

DWORD CElf::SectionAdd    (TCHAR *pName, DWORD dwType, DWORD dwAttr, DWORD dwSize, DWORD dwIndex)
{
   DWORD dwRelO = 0;

   for (DWORD dwSection = dwIndex; dwSection < m_Header.e_shnum; dwSection++)
      {
      if ((dwAttr & SHF_ALLOC) && (m_pSections[dwSection].section.sh_flags & SHF_ALLOC))
         dwRelO += m_pSections[dwSection].section.sh_size;

      if (m_pSections[dwSection].section.sh_type == SHT_NULL)
         {         
         DWORD dwLink = 0;
         if (dwType == SHT_SYMTAB)
            dwLink = m_Header.e_shstrndx;

         DWORD dwEntSz = 0;
         if (dwType == SHT_SYMTAB || dwType == SHT_REL)
            dwEntSz = dwSize;

         // Allocate data for section
         if (dwSize && (dwType != SHT_NOBITS))
            {
            m_pSections[dwSection].pData = (void *) malloc (dwSize);
            memset (m_pSections[dwSection].pData, 0, dwSize);
            }

         // Section name (string tbl index)
         m_pSections[dwSection].section.sh_name      = StrtabAdd (pName);      

         m_pSections[dwSection].section.sh_type      = dwType; // Section type 
         m_pSections[dwSection].section.sh_flags     = dwAttr; // Section flags 
         m_pSections[dwSection].section.sh_addr      = 0;      // Section virtual addr at execution 
         m_pSections[dwSection].section.sh_offset    = dwRelO; // Section file offset 
         m_pSections[dwSection].section.sh_size      = dwSize; // Section size in bytes 
         m_pSections[dwSection].section.sh_link      = dwLink; // Link to another section 
         m_pSections[dwSection].section.sh_info      = 0;      // Additional section information 
         m_pSections[dwSection].section.sh_addralign = 1;      // Section alignment 
         m_pSections[dwSection].section.sh_entsize   = dwEntSz;// Entry size if section holds table          

         StrtabRepair (0);

         return dwSection;
         }
      }  

   return 0;
}

DWORD CElf::SectionLink    (DWORD dwSection)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   return m_pSections[dwSection].dwLink;
}

DWORD CElf::SectionLink    (DWORD dwSection, DWORD dwLink)
{
   if (dwSection < 0 || dwSection >  m_Header.e_shnum)
      return 0;

   m_pSections[dwSection].dwLink = dwLink;

   return m_pSections[dwSection].dwLink;
}

DWORD CElf::SymbolTbl     (DWORD dwStart)
{
   for (UINT uIndex = dwStart; uIndex < m_Header.e_shnum; uIndex++)
      {
      if (m_pSections[uIndex].section.sh_type != SHT_SYMTAB)
         continue;
      
      return uIndex;
      }

   return 0;
}

DWORD CElf::SymbolCnt (DWORD dwSymTable)
{
   return m_pSections[dwSymTable].section.sh_size / m_pSections[dwSymTable].section.sh_entsize;
}

DWORD CElf::SymbolAdd (DWORD dwSection, TCHAR *pName, TCHAR *pData, DWORD dwSize, DWORD dwInfo)
{
   DWORD dwSymSection;
   if (!(dwSymSection = SectionFind (_T(".symtab"))))
      return 0;

   DWORD dwSymSize = m_pSections[dwSymSection].section.sh_size + m_pSections[dwSymSection].section.sh_entsize;

   void *pUpdate;
   if (!(pUpdate = malloc (dwSymSize)))
      return 0;

   memset (pUpdate, 0, dwSymSize);

   memcpy (pUpdate, m_pSections[dwSymSection].pData, m_pSections[dwSymSection].section.sh_size);


   DWORD dwBase = m_pSections[dwSection].section.sh_info;

   if (dwBase + dwSize > m_pSections[dwSection].section.sh_size)
      Reloc (dwSection, dwBase + dwSize);

   // Move data into section
   if (m_pSections[dwSection].pData && pData)
      memcpy (((TCHAR *) m_pSections[dwSection].pData + dwBase), pData, dwSize);

   m_pSections[dwSection].section.sh_info += dwSize;
 
   // Update the symbol data to reflect the latest symbol

   Elf32_Sym _symbol;

   _symbol.st_name  = StrtabAdd (pName);         // Symbol name (string tbl index)
   StrtabRepair (0);

   _symbol.st_value = dwBase;		                // Symbol value
   _symbol.st_size  = dwSize;		                // Symbol size
   _symbol.st_info  = (unsigned char) dwInfo;    // Symbol type and binding
   _symbol.st_other = 0;		                   // Symbol visibility
   _symbol.st_shndx = (Elf32_Section) dwSection; // Section index   

   memcpy ( ((TCHAR *) pUpdate + m_pSections[dwSymSection].section.sh_size), &_symbol, sizeof (_symbol));
   
   if (m_pSections[dwSymSection].pData)
      free (m_pSections[dwSymSection].pData);

   m_pSections[dwSymSection].pData           = pUpdate;
   m_pSections[dwSymSection].section.sh_size = dwSymSize;


//   DWORD dwStringTable = m_pSections[dwSymSection].section.sh_link;
//   pName = ((TCHAR *) m_pSections[dwStringTable].pData + _symbol.st_name);
//   printf ("0x%02x: %-30s 0x%08x 0x%04x 0x%02x %04x\n", (dwSymSize / m_pSections[dwSymSection].section.sh_entsize) - 1, pName, _symbol.st_value, _symbol.st_size, _symbol.st_info, _symbol.st_shndx);

   return ((dwSymSize / m_pSections[dwSymSection].section.sh_entsize)-1) | (dwSymSection << 24);
}

DWORD CElf::SymbolRem (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   _symbol->st_name = 0;

   return 1;
}

DWORD CElf::SymbolDef (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   _symbol->st_shndx = m_Header.e_shnum + 1;

   return 1;
}

TCHAR *CElf::SymbolName (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   DWORD dwStringTable = m_pSections[dwSymTable].section.sh_link;

   return ((TCHAR *) m_pSections[dwStringTable].pData + _symbol->st_name);
}

TCHAR *CElf::SymbolData (DWORD dwSymTable, DWORD dwSymbol, DWORD *dwSize)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   if (dwSize)
      *dwSize = _symbol->st_size;

   if ((_symbol->st_shndx == 0) || (_symbol->st_shndx > m_Header.e_shnum))
      return NULL;

   return ((TCHAR *) m_pSections[_symbol->st_shndx].pData + _symbol->st_value);
}

DWORD CElf::SymbolSec  (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   return ((DWORD) _symbol->st_shndx);
}

DWORD CElf::SymbolSize  (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   return ((DWORD) _symbol->st_size);
}

DWORD CElf::SymbolInfo (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   return ((DWORD) _symbol->st_info);
}

DWORD CElf::SymbolVal (DWORD dwSymTable, DWORD dwSymbol)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   return ((DWORD) _symbol->st_value);
}

DWORD CElf::SymbolVal (DWORD dwSymTable, DWORD dwSymbol, DWORD dwValue)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   DWORD dwOffset  = dwSymbol * dwEntSize;

   _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + dwOffset);

   _symbol->st_value = dwValue;

   return ((DWORD) _symbol->st_value);
}

DWORD CElf::SymbolUnd (DWORD dwSymTable)
{
   Elf32_Sym *_symbol;

   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   for (UINT uOffset = dwEntSize; uOffset < m_pSections[dwSymTable].section.sh_size; uOffset += dwEntSize)
      {
      _symbol = (Elf32_Sym *) ((char *) m_pSections[dwSymTable].pData + uOffset);

//      if (ELF32_ST_TYPE (_symbol->st_info) != STT_NOTYPE)
//         continue;
      if (_symbol->st_shndx != SHN_UNDEF)
         continue;


      return (uOffset / dwEntSize);
      }

   return NULL;
}

DWORD CElf::SymbolFnd (DWORD dwSymTable, TCHAR *pSymbol)
{
   DWORD dwEntSize = m_pSections[dwSymTable].section.sh_entsize;

   for (UINT uOffset = dwEntSize; uOffset < m_pSections[dwSymTable].section.sh_size; uOffset += dwEntSize)
      {
      if (strcmp (pSymbol, SymbolName (dwSymTable, uOffset / dwEntSize)))
         continue;

      return (uOffset/dwEntSize);
      }

   return NULL;
}

DWORD CElf::RelocationCnt (DWORD dwRelTable)
{
   return m_pSections[dwRelTable].section.sh_size / m_pSections[dwRelTable].section.sh_entsize;
}

DWORD CElf::RelocationAddr (DWORD dwRelTable, DWORD dwRelocation)
{
   Elf32_Rel *_rel;

   DWORD dwEntSize = m_pSections[dwRelTable].section.sh_entsize;

   DWORD dwOffset  = dwRelocation * dwEntSize;

   _rel = (Elf32_Rel *) ((char *) m_pSections[dwRelTable].pData + dwOffset);

   return ((DWORD) _rel->r_offset);
}

DWORD CElf::RelocationInfo (DWORD dwRelTable, DWORD dwRelocation)
{
   Elf32_Rel *_rel;

   DWORD dwEntSize = m_pSections[dwRelTable].section.sh_entsize;

   DWORD dwOffset  = dwRelocation * dwEntSize;

   _rel = (Elf32_Rel *) ((char *) m_pSections[dwRelTable].pData + dwOffset);

   return ((DWORD) _rel->r_info);
}

TCHAR *CElf::RelocationName (DWORD dwRelTable, DWORD dwRelocation)
{
   DWORD dwEntSize = m_pSections[dwRelTable].section.sh_entsize;

   DWORD dwOffset  = dwRelocation * dwEntSize;

   Elf32_Rel *_rel;
   _rel = (Elf32_Rel *) ((char *) m_pSections[dwRelTable].pData + dwOffset);

   return SymbolName ( m_pSections[dwRelTable].section.sh_link, ELF32_R_SYM (_rel->r_info));
}
