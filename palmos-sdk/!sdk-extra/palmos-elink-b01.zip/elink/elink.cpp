// elink.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "elink.h"
#include "library.h"

#include "ObjectFile.h"
#include "object.h"

#include "Elf\Elf.h"

#include "z:\common\cmd_line.h"

//elink @input_file -lib libarmboot.a binary_1000.obj -o binary_1000.arm {PRC}? -e{entry_point}

#include "Shlwapi.h"

struct Rule RuleZ[] = 
{
   {_T("@")        , _T("Specify input file")        , NULL, 1, _nop}, 
   {_T("-lib_path"), _T("Add library to search path"), NULL, 2, _lib_path},
   {_T("-lib")     , _T("")                          , NULL, 2, _lib},
   {_T("-o")       , _T("")                          , NULL, 2, _set},
   {_T("-entry")   , _T("")                          , NULL, 2, _set},

   {_T("-binary")  , _T("Output format binary")      , NULL, 1, _bin},

   // Last Entry
   {_T("")         , _T("")                          , NULL, 1, _obj}
};

struct Library             *pLibHead = NULL, *pLibTail = NULL;
class  CObjectFile         *pObjHead = NULL, *pObjTail = NULL;
struct got                 *pGotHead = NULL, *pGotTail = NULL;

int _tmain(int argc, _TCHAR* argv[])
{
   // Expand the environment var for lib_path and append a "." to the front of it.
   TCHAR tcLibPath[0x2000] = _T(".;\0");
   GetEnvironmentVariable (_T("LIB_PATH"), &tcLibPath[2], sizeof (tcLibPath) - 2);

   TCHAR tcOutput [MAX_PATH] = _T("\0"), tcEntry[MAX_PATH] = _T("__startup");

   DWORD dwBinary = 0;

   RuleZ[1].pData = tcLibPath;
   RuleZ[2].pData = tcLibPath;
   RuleZ[3].pData = tcOutput;
   RuleZ[4].pData = tcEntry;
   RuleZ[5].pData = &dwBinary;

   DWORD dwSize = sizeof (RuleZ) / sizeof (struct Rule);

   exec_option (argc, argv, RuleZ, dwSize, dwSize - 1);

   if (!strlen (tcOutput))
      {
      // Error, no output file specified
      printf ("Error: no output file specified\n");
      }

   // Create the output object.
   CObjectFile *pOutput;
   if (!(pOutput = (CObjectFile *) new CElf()))
      exit (1);

   pOutput->SetOutput (tcOutput, dwBinary);

   // Create all sections, later I will set the section sizes
   DWORD dwSecT, dwSecG, dwSecR, dwSecD, dwSecB, dwSecL;
   dwSecT = pOutput->SectionAdd (_T(".text")  , SHT_PROGBITS, SHF_ALLOC|SHF_EXECINSTR, 0);   
   dwSecG = pOutput->SectionAdd (_T(".got")   , SHT_PROGBITS, SHF_ALLOC              , 0);
   dwSecR = pOutput->SectionAdd (_T(".rodata"), SHT_PROGBITS, SHF_ALLOC              , 0);
   dwSecD = pOutput->SectionAdd (_T(".data")  , SHT_PROGBITS, SHF_ALLOC|SHF_WRITE    , 0);
   dwSecB = pOutput->SectionAdd (_T(".bss")   , SHT_NOBITS  , SHF_ALLOC|SHF_WRITE    , 0);

   dwSecL = pOutput->SectionAdd (_T(".linker"), SHT_NOBITS  , 0x0                    , 0);

   // Add a symbol in for global_offset_table
   DWORD dwSymG;
   dwSymG = pOutput->SymbolAdd (dwSecG, _T("_GLOBAL_OFFSET_TABLE_"), NULL, 0x0, 0x11);

   // Entry point symbol
   DWORD dwSymE;
   dwSymE   = pOutput->SymbolAdd (dwSecL, _T("__entry")  , NULL, 0x0, 0x11);


   // Got table offset, size symbols
   DWORD dwSymX, dwSymXsz, dwSymXRsz, dwSymXDsz, dwSymXBsz;
  
   // Entire got table
   dwSymX   = pOutput->SymbolAdd (dwSecL, _T("__got_x")  , NULL, 0x0, 0x11);
   dwSymXsz = pOutput->SymbolAdd (dwSecL, _T("__got_xsz"), NULL, 0x0, 0x11);

   // Got table for .bss size
   dwSymXBsz= pOutput->SymbolAdd (dwSecL, _T("__got_bsz"), NULL, 0x0, 0x11);

   // Got table for .data size
   dwSymXDsz= pOutput->SymbolAdd (dwSecL, _T("__got_dsz"), NULL, 0x0, 0x11);

   // Got table for .rodata size
   dwSymXRsz= pOutput->SymbolAdd (dwSecL, _T("__got_rsz"), NULL, 0x0, 0x11);


   // Text, RoData, Data, Bss section symbols
   DWORD dwSymT, dwSymTsz, dwSymR, dwSymRsz, dwSymD, dwSymDsz, dwSymB, dwSymBsz;
   dwSymT   = pOutput->SymbolAdd (dwSecL, _T("__txt")      , NULL, 0x0, 0x11);
   dwSymTsz = pOutput->SymbolAdd (dwSecL, _T("__txt_sz")   , NULL, 0x0, 0x11);

   dwSymR   = pOutput->SymbolAdd (dwSecL, _T("__rodata")   , NULL, 0x0, 0x11);
   dwSymRsz = pOutput->SymbolAdd (dwSecL, _T("__rodata_sz"), NULL, 0x0, 0x11);

   dwSymD   = pOutput->SymbolAdd (dwSecL, _T("__data")     , NULL, 0x0, 0x11);
   dwSymDsz = pOutput->SymbolAdd (dwSecL, _T("__data_sz")  , NULL, 0x0, 0x11);

   dwSymB   = pOutput->SymbolAdd (dwSecL, _T("__bss")      , NULL, 0x0, 0x11);
   dwSymBsz = pOutput->SymbolAdd (dwSecL, _T("__bss_sz")   , NULL, 0x0, 0x11);


   // now, start at the head object and ask if there are any undefined symbols
   // If there are attempt to locate the undefined symbol
   symbols (pObjHead, pOutput);


   // So all symbols are found, determine the size of all sections.
   // Bss   : NOBITS  , ALLOC+WRITE
   // Data  : ProgBits, ALLOC+WRITE
   // Cons  : ProgBits, Alloc
   // text  : ProgBits, Alloc+Exec
   // got   : bss + data + cons

   DWORD bss, data, cons, text;
   text = size (pObjHead, SHT_PROGBITS, SHF_ALLOC|SHF_EXECINSTR); // text

   cons = size (pObjHead, SHT_PROGBITS, SHF_ALLOC              ); // Cons
   data = size (pObjHead, SHT_PROGBITS, SHF_ALLOC|SHF_WRITE    ); // Data
   bss  = size (pObjHead, SHT_NOBITS  , SHF_ALLOC|SHF_WRITE    ); // bss

   // Update the .text section
   pOutput->SectionSize (dwSecT, text);
   cpy (pObjHead, pOutput, _T(".text"));


   DWORD dwEntry = 0;
   locate_symbol_value (pOutput, tcEntry, &dwEntry);
   pOutput->SymbolVal ((dwSymE   >> 24) & 0x0000ff, (dwSymE   >> 00) & 0xffffff, dwEntry);


   // Update the .rodata section
   pOutput->SectionSize (dwSecR, cons);
   cons = cpy (pObjHead, pOutput, _T(".rodata")) * 4;


   // Update the .data section
   pOutput->SectionSize (dwSecD, data);
   data = cpy (pObjHead, pOutput, _T(".data"))   * 4;


   // Update the .bss section
   pOutput->SectionSize (dwSecB, bss );
   bss  =  cpy (pObjHead, pOutput, _T(".bss"))    * 4;
   
   // build the .got table correctly.
   // symbols from .rodata, .data, and .bss need to be copied over to
   // .got table, with a special value from each of them that increases by plus 4 each time   
   pOutput->SectionSize (dwSecG, got (pObjHead, pOutput) * 4);

   DWORD dwOffset = pOutput->SectionAddr (dwSecG);

   // Update the _global_offset_symbol_
   if (pOutput->SectionSize (dwSecG))
      {
      if (dwSymG)     
         pOutput->SymbolVal ((dwSymG   >> 24) & 0x0000ff, (dwSymG   >> 00) & 0xffffff, pOutput->SectionAddr (dwSecG));

      if (dwSymX && dwSymXsz)
         {
         pOutput->SymbolVal ((dwSymX   >> 24) & 0x0000ff, (dwSymX   >> 00) & 0xffffff, dwOffset);
         pOutput->SymbolVal ((dwSymXsz >> 24) & 0x0000ff, (dwSymXsz >> 00) & 0xffffff, pOutput->SectionSize (dwSecG));
         }

      if (dwSymXBsz)
         pOutput->SymbolVal ((dwSymXBsz >> 24) & 0x0000ff, (dwSymXBsz >> 00) & 0xffffff, bss);
      }

   
   // Repair all internal symbols
   if (pOutput->SectionSize (dwSecT) && dwSymT && dwSymTsz)
      {
      pOutput->SymbolVal ((dwSymT   >> 24) & 0x0000ff, (dwSymT   >> 00) & 0xffffff, pOutput->SectionAddr(dwSecT));
      pOutput->SymbolVal ((dwSymTsz >> 24) & 0x0000ff, (dwSymTsz >> 00) & 0xffffff, pOutput->SectionSize(dwSecT));
      }

   if (pOutput->SectionSize (dwSecR) && dwSymR && dwSymRsz)
      {
      pOutput->SymbolVal ((dwSymR   >> 24) & 0x0000ff, (dwSymR   >> 00) & 0xffffff, pOutput->SectionAddr(dwSecR));
      pOutput->SymbolVal ((dwSymRsz >> 24) & 0x0000ff, (dwSymRsz >> 00) & 0xffffff, pOutput->SectionSize(dwSecR));
      }

   if (pOutput->SectionSize (dwSecD) && dwSymD && dwSymDsz)
      {
      pOutput->SymbolVal ((dwSymD   >> 24) & 0x0000ff, (dwSymD   >> 00) & 0xffffff, pOutput->SectionAddr(dwSecD));
      pOutput->SymbolVal ((dwSymDsz >> 24) & 0x0000ff, (dwSymDsz >> 00) & 0xffffff, pOutput->SectionSize(dwSecD));
      }

   if (pOutput->SectionSize (dwSecB) && dwSymB && dwSymBsz)
      {
      pOutput->SymbolVal ((dwSymB   >> 24) & 0x0000ff, (dwSymB   >> 00) & 0xffffff, pOutput->SectionAddr(dwSecB));
      pOutput->SymbolVal ((dwSymBsz >> 24) & 0x0000ff, (dwSymBsz >> 00) & 0xffffff, pOutput->SectionSize(dwSecB));
      }  


   // Now, perform all relocations correctly. 
   rel  (pObjHead, pOutput, _T(".text"  ));
   rel  (pObjHead, pOutput, _T(".rodata"));
   rel  (pObjHead, pOutput, _T(".data"  ));
   rel  (pObjHead, pOutput, _T(".bss"   ));
      

   delete pOutput;

   struct Library *_library;
   for (_library = pLibHead; _library; _library = pLibHead)
      {
      pLibHead = _library->pNext;
      free (_library);
      }

   CObjectFile *_object;
   for (_object = pObjHead; _object; _object = pObjHead)
      {
      pObjHead = _object->m_pNext;
      delete (_object);
      }

	return 0;
}

int _nop (int iIndex, char *argv[], void *pData)
{
   return 0;
}

int _lib_path (int iIndex, char *argv[], void *pData)
{
   strcat ((char *) pData, argv[iIndex+1]);
   strcat ((char *) pData, ";");
   
   return 1;
}

int _set  (int iIndex, char *argv[], void *pData)
{
   sprintf ((char *) pData, "%s", argv[iIndex+1]);
   return 1;
}

int _obj (int iIndex, char *argv[], void *pData)
{
   return object (&pObjHead, &pObjTail, argv[iIndex], 0);
}

int _bin (int iIndex, char *argv[], void *pData)
{
   // Enable binary mode
   *((DWORD *) pData) = 1;

   return 1;   
}

int _lib (int iIndex, char *argv[], void *pData)
{
   // Open library specified in argv[]
   TCHAR tcLibrary[MAX_PATH];
   sprintf (tcLibrary, "%s", argv[iIndex+1]);

   // Using tcLibPath (pData) search for and attempt to locate the library 
   // Add code here

   FILE *pLib;
   if (!(pLib = (FILE *) fopen (tcLibrary, "rb")))
      return 0;

   library (&pLibHead, &pLibTail, tcLibrary, pLib);

   fclose (pLib);
  
   return 1;
}
