#pragma once

extern "C" int object  (CObjectFile* *pHead, CObjectFile* *pTail, TCHAR *pFile, DWORD dwOffset);

extern "C" int symbols (CObjectFile *pHead, CObjectFile *pDest);
extern "C" int size    (CObjectFile *pHead, DWORD dwType, DWORD dwAttr);

extern "C" int cpy     (CObjectFile *pHead, CObjectFile *pDest, TCHAR *pName);

extern "C" int got     (CObjectFile *pHead, CObjectFile *pDest);
extern "C" int rel     (CObjectFile *pHead, CObjectFile *pDest, TCHAR *pName);

extern "C" DWORD locate_symbol_value (CObjectFile *_object, TCHAR *pSymbol, DWORD *pAddr);
