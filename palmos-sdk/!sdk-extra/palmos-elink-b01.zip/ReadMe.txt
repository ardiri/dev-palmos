First I have no make files.  In my spare time I am working on a develovment environment, that I have use to build and actual
palmos prc files with.  Maybe by xmas I can release a beta of it, but right now I think it's too rough.  Sorry.

Any bug reports, suggestions please e-mail me at beebeb@comcast.net.  Thanks.


elink:
	Includes all of the source code for the linker, and a visual studio .net project files.  

m68k_source:
	This directory contains the source code for the 68k side.  All it does it launches the arm code every time you tap 
the screen.  I can not see any reason why the arm code would ever have to return, but hay, it just a test case.  You will need to 
copy the "PceNativeCall.h" file into this direcory.


example:
	includes the two object files "binary_1000.obj" and "startup.obj", the source code for both these files are in the "source"
directory below the example directory.	It also includes a dos executable "elink.exe", this is the actual linker.

	In order to use the example code you are going to need "libarmboot.a" from Igor Nesterov at [i_nesterov@hotmail.com].  I 
think his libraries are great. Copy the libarmboot.a into the example directory.  Then execute the instruction contained below.

	cd {path}\example
	elink -lib libarmboot.a -o binary.arm startup.obj binary_1000.o -entry NativeFunction

	That's it.  If everything worked you should have an elf object file called binary.arm sitting in the directory.

	elink options:
		@ 		- Specify input file instead of all the command line options (Not Implemented yet, only a beta release)
					(Just one of the reasons for making my own linker, I could not get cygwin to work with pipes.)

		-lib_path	- Add library to search path.  	(Not Implemented yet, only a beta release)

		-lib		- Input library.  
		
		-entry		- Entry point for your code.  If you use the startup.obj file provoded after it get's done this
				  is the address it will jump to.

		-o		- output filename.

		-binary		- output in binary format (not an elf object file).
				
		Any item not proceeded by an option are considered an input file.

		The linker does not care about order of libaray files or object files, except for the known bug listed below.
			(Yet another reason why I wanted my own linker, I could never get the cygwin linker to be order independant)


	Predefined elink symbols:
		__text      offset to text section
		__text_sz   size of text section
		__rodata    offset to rodata section
		__rodata_sz size of rodata section
		__data      offset to data section
		__data_sz   size of data section
		__bss       offset to where bss section should start
		__bss_sz    size of bss section
		__got_x     offset to the got section (same as _GLOBAL_OFFSET_TABLE_)

		__got_xsz   entire size of the got section

		__got_bsz   entire size of the bss got section
		            should be the same as __bss_sz        

		__entry     start location after "startup/crt0" has finished


	

	Known bugs:
		The very first object file must be a compatable startup.obj file.  The startup file patches the .got table so it
will work, and then jumps to the defined entry point.  It's up to you if you use your own startup file or mine.  But it must be the
first object.  I hope to have it fixed when I fix the "@" and "-lib_path" options.

		
	Thumb code
		If your program is all thumbs, then it should be ok.  If you are mixing arm/thumb code then it might not work.  
I have added it to my to do list.  I compiled the binary_1000.c as thumb code, it appears it thumb is calling arm code the gcc 
compiler wants functions called "call_via_r0 .. call_via_lr(pc)".  So I would like to put there functions into a library and it 
will take a couple of days.


example/source:

	binary_1000:	Example test program I put togather, requires "libarmboot.a" to work.

	startup.arm:	Current startup code being used.  I used "narm" as the assembler for it.