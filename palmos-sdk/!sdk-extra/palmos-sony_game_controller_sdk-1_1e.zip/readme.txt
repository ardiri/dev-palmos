Guide to Game Controller Software Development Kit

This document explains the file information included in the Software Development Kit for Game Controller "PEGA-GC10".
For the detailed information of this tool, please see "Game Controller Development Guide".

This development tool include the following files:
- readme.txt                     This file.

- Documentation\GC10Guide.pdf    "Game Controller Development Guide"
                                 shows the information of this tool.

- Driver\GameConE.prc            Game Controller Driver Ver.1.11
                                 used for PalmOS 4.x only.

- Driver\US EULA.pdf             End-User License Agreement
         EU EULA.pdf             append in re-distributing the driver.

- Inc\SonyKeyMgr.h               header file for extended button
                                 replaces with the header file of SonySDK 3.0.

-----
(c) 2002 Sony Electronics, Inc. / Sony Corporation
