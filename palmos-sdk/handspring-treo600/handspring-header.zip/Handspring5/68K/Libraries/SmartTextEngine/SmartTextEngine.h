
#ifndef __SMARTTEXTENGINE68K_H__
#define	__SMARTTEXTENGINE68K_H__

#include <PalmTypes.h>
#include <LibTraps.h>

#include "../../../Common/Libraries/SmartTextEngine/SmartTextEngineTraps.h"
#include "../../../Common/Libraries/SmartTextEngine/SmartTextEngineDef.h"
#include "../../../Common/Libraries/SmartTextEngine/SmartTextEngineErrors.h"


#ifdef __cplusplus
extern "C" {
#endif


// Standard library open routine.
// Library should always be loaded with SysLibLoad()(not SysLibFind())
// before calling STEOpen(). See note at top of file.
// 
// @param refnum          IN  Library reference number
// @retval STEErr                Library error code
extern STEErr STEOpen(UInt16 refNum)
    SYS_TRAP(sysLibTrapOpen);

// Standard library close routine.
// Library shuold always be unloaded with SysLibRemove() after
// STEClose() is caled. See note at top of file.
// 
// @param refnum          IN  Library reference number
// @retval STEErr                Library error code
extern STEErr STEClose(UInt16 refNum)
    SYS_TRAP(sysLibTrapClose);


// Get Library API Version number.
// 
// @param refnum          IN  Library reference number
// @param majVerP         OUT Major version number
// @param minVerP         OUT Minor version number
// @retval STEErr         Styled Text Engine error code
extern STEErr STEGetAPIVersion(UInt16 refNum, UInt32* majVerP, UInt32* minVerP)
    SYS_TRAP(STETrapGetAPIVersion);



// Styled Text Engine initialization functions
extern STEErr STEInitializeEngine(UInt16 refNum, UInt16* engineRefNum, RectangleType* listBounds, UInt16 scrollBarID, UInt32 flags, 
                                  UInt8 phoneNumberColor, UInt8 urlColor, UInt8 emailColor)
	SYS_TRAP(STETrapInitializeEngine);

extern STEErr STEResetEngine(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapResetEngine);

extern STEErr STEReinitializeEngine(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapReinitializeEngine);


// Styled Text Engine main functions
extern void STEAppendTextToEngine(UInt16 refNum, UInt16 engineRefNum, char* textP, Boolean renderImmediate)
	SYS_TRAP(STETrapAppendTextToEngine);

extern void STERemoveLastRecordFromEngine(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapRemoveLastRecordFromEngine);

extern void STERenderList(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapRenderList);

extern void STERerenderList(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapRerenderList);


// event handlers
extern Boolean STEHandleEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandleEvent);

extern Boolean STEHandleSclRepeatEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandleSclRepeatEvent);

extern Boolean STEHandlePenDownEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandlePenDownEvent);

extern Boolean STEHandlePenMoveEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandlePenMoveEvent);

extern Boolean STEHandlePenUpEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandlePenUpEvent);

extern Boolean STEHandleKeyDownEvent(UInt16 refNum, UInt16 engineRefNum, EventPtr eventP)
	SYS_TRAP(STETrapHandleKeyDownEvent);


// Accessor functions
extern UInt16 STEGetScroll(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetScroll);

extern void STESetScroll(UInt16 refNum, UInt16 engineRefNum, UInt16 scrollValue)
	SYS_TRAP(STETrapSetScroll);

extern UInt16 STEGetScrollPct(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetScrollPct);

extern void STESetScrollPct(UInt16 refNum, UInt16 engineRefNum, UInt16 scrollPct)
	SYS_TRAP(STETrapSetScrollPct);

extern void STESetScrollToRecordNum(UInt16 refNum, UInt16 engineRefNum, UInt16 recordNum)
	SYS_TRAP(STETrapSetScrollToRecordNum);

extern void STESetFlags(UInt16 refNum, UInt16 engineRefNum, UInt32 flagsToSet, UInt32 flagsToClear)
	SYS_TRAP(STETrapSetFlags);

extern UInt32 STEGetFlags(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetFlags);

extern UInt16 STEGetNumLines(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetNumLines);

extern UInt16 STEGetNumRecords(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetNumRecords);

extern Boolean STEHasHotRectSelection(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapHasHotRectSelection);

extern Boolean STEHasTextSelection(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapHasTextSelection);

extern void STEClearCurrentSelection(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapClearCurrentSelection);

extern UInt16 STESetCurrentTextSelection(UInt16 refNum, UInt16 engineRefNum, UInt16 messageNumber, UInt32 startLocation, UInt32 selectionLength)
	SYS_TRAP(STETrapSetCurrentTextSelection);

extern void STEGetCurrentTextSelection(UInt16 refNum, UInt16 engineRefNum, UInt16* messageNumber, UInt16* startLocation, UInt16* selectionLength)
	SYS_TRAP(STETrapGetCurrentTextSelection);

extern char* STEGetSelectedText(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapGetSelectedText);

extern void STECopySelectionToClipboard(UInt16 refNum, UInt16 engineRefNum)
	SYS_TRAP(STETrapCopySelectionToClipboard);

extern void STEGetLastTapInfo(UInt16 refNum, UInt16 engineRefNum, UInt16* messageNumber, UInt16* tapLocation)
	SYS_TRAP(STETrapGetLastTapInfo);

extern void STESetCustomHyperlinkCallback(UInt16 refNum, UInt16 engineRefNum, STECallbackType callback, Boolean armCallback)
	SYS_TRAP(STETrapSetCustomHyperlinkCallback);


// Cool helper function that does not require the engine to be initialized
extern void STEQuickRender(UInt16 refNum, RectangleType* listBounds, UInt32 flags,
                           UInt8 phoneNumberColor, UInt8 urlColor, UInt8 emailColor, char* msgP)
	SYS_TRAP(STETrapQuickRender);



// These are parsing functions that do not require the engine to be initialized
extern ParsedInfoList* STEGetParsedInformation(UInt16 refNum, char* textP, UInt16 msgNumber, Boolean replaceLineFeeds, UInt32 flags)
	SYS_TRAP(STETrapGetParsedInformation);

extern void STEAppendParsedInfo(UInt16 refNum, MemHandle destParsedInfoH, ParsedInfoList* sourceParsedInfoP)
	SYS_TRAP(STETrapAppendParsedInfo);



#ifdef __cplusplus 
}
#endif




#endif 	//__SMARTTEXTENGINE68K_H__
