/**
 * Project:
 *    Carrier Customization Library
 *
 * @file CarrierCustomizationLibraryPrv.h
 * This file contains private data types
 *
 * All the modem manager functions that are patched with custom calls are
 * exported in this header file
 *
 * @license
 *    Copyright (c) 2002 Handspring Inc., All Rights Reserved
 *
 * History:
 *    17-Dec-2002   dla   Created
 *
 * $Id:$
 *
 *****************************************************************************/

#ifndef __CARRIER_CUSTOMIZATION_LIBRARY_PRV_H__
#define __CARRIER_CUSTOMIZATION_LIBRARY_PRV_H__


// to get the settings structures
#include <68K/Libraries/CarrierCustomLib/CarrierCustomLib.h>


#if 0
#pragma mark -------- Constants -------- 
#endif

// Values for the display flag (bit fields)
//
#define kCCSMDisplayFlagServiceDeleteable             0x00000001
#define kCCSMDisplayFlagServiceDuplicatable           0x00000002
#define kCCSMDisplayFlagServiceEditableWithWarning    0x00000004
#define kCCSMDisplayFlagServiceEditableWithoutWarning 0x00000008
#define kCCSMDisplayFlagServiceRenameable             0x00000010
#define kCCSMDisplayFlagUsernameDisplay               0x00000020
#define kCCSMDisplayFlagPasswordDisplay               0x00000040
#define kCCSMDisplayFlagPhoneNumberAPNDisplay         0x00000080
#define kCCSMDisplayFlagDetailsDisplay                0x00000100
#define kCCSMDisplayFlagAdvancedDisplay               0x00000200
#define kCCSMDisplayFlagFallBackDisplay               0x00000400
#define kCCSMDisplayFlagIPDisplay                     0x00000800
#define kCCSMDisplayFlagDNSDisplay                    0x00001000
#define kCCSMDisplayFlagConnectionMedium              0x00002000


// This is the binding indices used to link the profiles stored in
// net prefs with the profile for the carrier.
// Since only the primary Home profile is stored, there is no
// actual index to the roaming profiles... these are not currently
// stored in net prefs, but a place holder will be specified for them.

enum
{
  kCCSMProfileLocaleHome = 0,
  kCCSMProfileLocaleRoam
};
typedef UInt8 CCSMProfileLocale;


/**
 * These serve as both the index to which profile to retrieve
 * as well as the binding index that is associated with the profile
 * stored in the Network Preference panel.
 */
enum
{
  //                                         <Data type returned> description
  // Data profiles
  kCCSMSettingsProfile1,  /**< <CCSMCarrierHandle> Profile 1 */
  kCCSMSettingsProfile2,  /**< <CCSMCarrierHandle> Profile 2 */
  kCCSMSettingsProfile3,  /**< <CCSMCarrierHandle> Profile 3 */
  kCCSMSettingsProfile4,  /**< <CCSMCarrierHandle> Profile 4 */
  kCCSMSettingsProfile5,  /**< <CCSMCarrierHandle> Profile 5 */
  kCCSMSettingsProfile6,  /**< <CCSMCarrierHandle> Profile 6 */

  // MMS Data profiles
  kCCSMSettingsMMSProfile1,  /**< <CCSMCarrierHandle> MMS profile 1 */
  kCCSMSettingsMMSProfile2,  /**< <CCSMCarrierHandle> MMS profile 2 */
};
typedef UInt16 CCSMProfileBindingIndex;


// mappings to the profile
enum
{
  kCCSMHomeProfile1,     /**< Home 1 */
  kCCSMRoamProfile1,     /**< Roam 1 */
  kCCSMHomeProfile2,     /**< Home 2 */
  kCCSMRoamProfile2,     /**< Roam 2 */
  kCCSMHomeProfile3,     /**< Home 3 */
  kCCSMRoamProfile3,     /**< Roam 3 */
  kCCSMHomeProfile4,     /**< Home 4 */
  kCCSMRoamProfile4,     /**< Roam 4 */
  kCCSMHomeProfile5,     /**< Home 5 */
  kCCSMRoamProfile5,     /**< Roam 5 */
  kCCSMHomeProfile6,     /**< Home 6 */
  kCCSMRoamProfile6,     /**< Roam 6 */
  kCCSMMMSHomeProfile1,  /**< Primary MMS home profile */
  kCCSMMMSRoamProfile1,  /**< Primary MMS roam profile */
  kCCSMMMSHomeProfile2,  /**< Secondary MMS home profile */
  kCCSMMMSRoamProfile2   /**< Secondary MMS roam profile */
};

/**
 *
 */
typedef enum
{
  kCCSMProfileSettingsRegionalName,           /**< <char *>  profile name  */
  kCCSMProfileSettingsUsername,               /**< <char *>  username */
  kCCSMProfileSettingsPassword,               /**< <char *>  password */
  kCCSMProfileSettingsDialNumber,             /**< <char *>  phone number */
  kCCSMProfileSettingsInitString,             /**< <char *>  modem init string */
  kCCSMProfileSettingsIsDynamicIP,            /**< <Boolean> get dynamic IP address */
  kCCSMProfileSettingsStaticIPAddr,           /**< <UInt32>  static IP addr (if above is false) */
  kCCSMProfileSettingsIsAutoDNS,              /**< <Boolean> system sets DNS */
  kCCSMProfileSettingsPrimaryDNS,             /**< <UInt32>  primary DNS */
  kCCSMProfileSettingsSecondaryDNS,           /**< <UInt32>  secondary DNS */
  kCCSMProfileSettingsIsDynamicGateway,       /**< <Boolean> use dynamic gateway */
  kCCSMProfileSettingsStaticGatewayIPAddr,    /**< <UInt32>  static gateway IP address */
  kCCSMProfileSettingsConnectionMedium,       /**< <UInt8>   connection medium flag */
  kCCSMProfileSettingsAPN,                    /**< <char *>  APN setting */
  kCCSMProfileSettingsConnectionType,         /**< <UInt32>  connection type */
  kCCSMProfileSettingsReqQOSPrecedence,       /**< <UInt8>   requested precedence */
  kCCSMProfileSettingsReqQOSDelay,            /**< <UInt8>   requested delay */
  kCCSMProfileSettingsReqQOSReliability,      /**< <UInt8>   requested reliability */
  kCCSMProfileSettingsReqQOSPeakThroughput,   /**< <UInt8>   requested mean throughput */
  kCCSMProfileSettingsReqQOSMeanThroughput,   /**< <UInt8>   requested min. throughput */
  kCCSMProfileSettingsMinQOSPrecedence,       /**< <UInt8>   minimum precedence */
  kCCSMProfileSettingsMinQOSDelay,            /**< <UInt8>   minimum delay */
  kCCSMProfileSettingsMinQOSReliability,      /**< <UInt8>   minimum reliability */
  kCCSMProfileSettingsMinQOSPeakThroughput,   /**< <UInt8>   minimum mean throughput */
  kCCSMProfileSettingsMinQOSMeanThroughput,   /**< <UInt8>   minimum min. throughput */
  kCCSMProfileSettingsPDPDataCompression,     /**< <Boolean> use data compression */
  kCCSMProfileSettingsPDPHeaderCompression,   /**< <Boolean> use header compression */
  kCCSMProfileSettingsIdleTimeout,            /**< <UInt32>  timeout value */
  kCCSMProfileSettingsDisplayFlags            /**< <UInt32>  field display settings */
}
profileSettingsTypeEnum;
typedef Int8 CCSMProfileSettingsType;


/** enumeration for network settings flags
 *
 */
typedef UInt32 CCSMNetworkFlagsType;
typedef enum
{
  kCCSMNetworkSettingsCarrierISP     = 0x00000001,  /**< is the Carrier an ISP */
  kCCSMNetworkSettingsGPRSAutoAttach = 0x00000002   /**< allow Auto attach for GPRS */
}
CCSMNetworkFlagsEnum;


// Connection Medium values (used with connMediumField)
typedef UInt32 CCSMConnectionMediumType;
typedef enum
{
  kCCSMConnMediumUnknown  = 0,
  kCCSMConnMediumCSD      = 1,
  kCCSMConnMediumISDN     = 2,
  kCCSMConnMediumGPRS     = 3,
  kCCSMConnMediumDynamic  = 4,
}
ConnectionMediumEnum;


// Connection Type values (used with connectionTypeField)
typedef UInt32 CCSMConnectionType;
typedef enum
{
  kCCSMConnTypeInternet       = 0x00000001,
  kCCSMConnTypeWAP            = 0x00000002,
  kCCSMConnTypeMMS            = 0x00000004,

  // Combinations
  kCCSMConnTypeInternetAndWAP = kCCSMConnTypeInternet | kCCSMConnTypeWAP,
  kCCSMConnTypeInternetAndMMS = kCCSMConnTypeInternet | kCCSMConnTypeMMS,
  kCCSMConnTypeWAPAndMMS      = kCCSMConnTypeWAP | kCCSMConnTypeMMS,
  kCCSMConnTypeAll            = 0xFFFF,
}
ConnectionTypeEnum;


// Special Idle Timeout values (used with idleTimeoutField)
typedef UInt32   CCSMConnectionIdleTimeoutType;
typedef enum
{
  kCCSMConnIdleTimeoutWirelessOff    = -1,
  kCCSMConnIdleTimeoutPowerOff		= 0,
  // positive values are in minutes
}
ConnectionIdleTimeoutEnum;


// Range of values for the QOS Class fields
typedef UInt8 CCSMQOSClassType;
typedef enum
{
  kCCSMQOSClassNetworkSelect  = 0,
  kCCSMQOSClassUserPref1      = 1,
  kCCSMQOSClassUserPref2      = 2,
  kCCSMQOSClassUserPref3      = 3,

  // Minimum and Maximum Class values for validation
  kCCSMQOSClassMin  = kCCSMQOSClassNetworkSelect,
  kCCSMQOSClassMax  = kCCSMQOSClassUserPref3,
}
QOSClassEnum;


#if 0
#pragma mark -------- Structs -------- 
#endif


/** network settings
 *
 */
typedef struct tagNetworkSettings
{
  CCSMNetworkFlagsType flags;   /**< app flags -- see CCSMNetworkFlagsEnum */

  // connection profiles to install on device (currently GPRS only)
  char *home1P;                       /**< connection profile ID */
  char *home2P;                       /**< connection profile ID */
  char *roam1P;                       /**< connection profile ID */
  char *roam2P;                       /**< connection profile ID */
  char *home3P;                       /**< connection profile ID */
  char *home4P;                       /**< connection profile ID */
  char *roam3P;                       /**< connection profile ID */
  char *roam4P;                       /**< connection profile ID */
  char *home5P;                       /**< connection profile ID */
  char *home6P;                       /**< connection profile ID */
  char *roam5P;                       /**< connection profile ID */
  char *roam6P;                       /**< connection profile ID */

  // mms connection profiles
  char *mmsHome1P;                    /**< connection profile ID */
  char *mmsHome2P;                    /**< connection profile ID */
  char *mmsRoam1P;                    /**< connection profile ID */
  char *mmsRoam2P;                    /**< connection profile ID */
}
CCSMNetworkSettingsType;


/** CCSMGPRSQOSType -- GPRS Quality Of Service (QOS) info
 *  Structure describing the QOS settings of a GPRS profile.
 *
 *  This was taken from the structure Vitaly uses in NetPrefs,
 *  but does not necessarily have to follow any changes he makes.
 */
typedef struct tagGPRSQOS
{
  CCSMQOSClassType reqPrecedenceClass;  /**< requiredPrecedenceClassField - see QOSClassEnum */
  CCSMQOSClassType reqDelayClass;       /**< requiredDelayClassField - see QOSClassEnum */
  CCSMQOSClassType reqReliabilityClass; /**< requiredReliabilityClassField - see QOSClassEnum */
  CCSMQOSClassType reqPeakThruClass;    /**< requiredPeakThroughputClassField - see QOSClassEnum */
  CCSMQOSClassType reqMeanThruClass;    /**< requiredMeanThroughputClassField - see QOSClassEnum */
  CCSMQOSClassType minPrecedenceClass;  /**< minimumPrecedenceClassField - see QOSClassEnum */
  CCSMQOSClassType minDelayClass;       /**< minimumDelayClassField - see QOSClassEnum */
  CCSMQOSClassType minReliabilityClass; /**< minimumReliabilityClassField - see QOSClassEnum */
  CCSMQOSClassType minPeakThruClass;    /**< minimumPeakThroughputClassField - see QOSClassEnum */
  CCSMQOSClassType minMeanThruClass;    /**< minimumMeanThroughputClassField - see QOSClassEnum */
  Boolean      pdpDataCompression;      /**< pdpDataCompressionField - compress data? */
  Boolean      pdpHeaderCompression;    /**< pdpHeaderCompressionField - compress headers? */

  UInt32    reserved[4];               /**< Reserved by Handspring -- undefined */
}
CCSMGPRSQOSType;


/* struct coming from the carrier connection profile */
typedef struct tagCarrierProfile
{
  UInt32 displayFlags;                    /**< displayFlagsField - undefined */
  UInt32 fieldSetFlags;					  /**< bitfield showing if the field was actually set or not */

  char *regionalNameP;                    /**< regionalNameField - Service name in network panel */
  char *userNameP;                        /**< usernameField - username */
  char *passwordP;                        /**< passwordField - password */
  char *phoneNumP;                        /**< phoneNumberField - number to dial */
  char *initStrP;                         /**< modemInitStringField - init string to use for dialing */
  char *apnNameP;                         /**< apnField - APN for profile */

  Boolean   isDynamicIP;                  /**< isDynamicIPField       - dynamic or static IP */
  UInt32    staticIPAddr;                 /**< staticIPField          - static IP (not valid if above is true) */
  Boolean   isDynamicDNS;                 /**< isAutoDNSField         - query for DNS? */
  UInt32    staticDNS1Addr;               /**< dns1Field              - primary DNS */
  UInt32    staticDNS2Addr;               /**< dns1Field              - secondary DNS */
  Boolean   isDynamicGateway;             /**< isDynamicGatewayField  - dynamic or static gateway? */
  UInt32    staticGatewayAddr;            /**< staticGatewayField     - gateway address */

  CCSMConnectionMediumType      connMedium;   /**< connMediumField    - see ConnectionMediumEnum */
  CCSMConnectionType     connType;     /**< connTypeField      - see ConnectionTypeEnum */
  CCSMConnectionIdleTimeoutType idleTimeout;  /**< idleTimeoutField   - see ConnectionIdleTimeoutType */
  CCSMGPRSQOSType     qos;          /**< Quality of service - see CCSMGPRSQOSType */

  UInt32 reserved[4];                     /**< reserved -- undefined */
  UInt8  reserved1;                       /**< byte alignment reserved -- undefined */
}
CCSMCarrierProfileType;



#if 0
#pragma mark -------- Exported Functions -------- 
#endif


/**
 * Returns the carrier DB code for the carrier on the SIM
 * Copies the DB code in the the buffer passed in.
 *
 * Parameters:
 * @param refNum		    IN  CCustomLib reference number
 *                          or SysLibLoad)
 * @param dataP         OUT pointer to the settings. Undefined on error
 * @return errNone on success
extern Err
CCustomLibGetCarrierDBCode(UInt16 refNum, char *dataP);
 */



/**
 * Returns the carrier DB code for the registered network
 * Copies the DB code in the the buffer passed in.
 *
 * Parameters:
 * @param refNum		    IN  CCustomLib reference number
 *                          or SysLibLoad)
 * @param dataP         OUT pointer to the settings. Undefined on error
 * @return errNone on success
extern Err
CCustomLibGetRegisteredCarrierDBCode(UInt16 refNum, char *dataP);
 */


// CCustomLibGetCarrierProfile
/**
 * Returns the specified profile, based on locale and bindingIndex
 *
 * Parameters:
 * @param refNum		  IN      CCustomLib reference number (from SysLibFind
 *								  or SysLibLoad)
 * @param locale		  IN	  ProfileLocal settings (profileLocaleRoam/profileLocaleHome)
 * @param bindingIndex	  IN	  index of the profile to retrieve (profile1-6 or mms profile 1-2)
 * @param dataP			  OUT     pointer to store the carrierhandle
 * @return errNone on success
 */
extern Err
CCustomLibGetCarrierProfile(UInt16 refNum, CCSMProfileLocale locale, CCSMProfileBindingIndex bindingIndex, CCSMCarrierHandle *profileP)
  CCUSTOM_LIB_TRAP(CCustomLibTrapGetCarrierProfile);


// CCustomLibReleaseCarrierProfile
/**
 * Frees the memory associated with the given object.
 * Deallocates the memory for the object.  Do not call for
 * objects that reside on the stack.
 *
 * @param refNum		      IN      CCustomLib reference number
 * @param dataP           IN      pointer of object to free
 * @return errNone on success
 */
extern Err
CCustomLibReleaseCarrierProfile(UInt16 refNum, CCSMCarrierHandle carrierProfileH)
  CCUSTOM_LIB_TRAP(CCustomLibTrapReleaseCarrierProfile);


// CCustomLibRefresh
/**
 * Refreshes the cached carrier data.
 *
 * @param refNum		  IN      CCustomLib reference number
 * @return errNone on success
 */
extern Err
CCustomLibRefresh(UInt16 refNum)
  CCUSTOM_LIB_TRAP(CCustomLibTrapRefresh);


// CCustomLibGetProfileSetting
/**
 * Returns a field from the specified carrier handle
 * Returns the settings for the given profile.
 * Any memory allocation must be freed by the calling application.
 * Currently, only string types are allocated.
 *
 * Parameters:
 * @param refNum          IN    CCustomLib reference number
 *                              or SysLibLoad)
 * @param carrierHandle   IN    handle to carrier profile
 * @param cpSetting       IN    setting to retrieve ( see profileSettingsTypeEnum )
 * @param dataP         IN/OUT  type depends on setting requested.
 *
 * @return errNone on success
 */
extern Err
CCustomLibGetProfileSetting(UInt16 refNum, CCSMCarrierHandle cProfileH, CCSMProfileSettingsType cpSetting, void *dataP)
  CCUSTOM_LIB_TRAP(CCustomLibTrapGetProfileSetting);


// CCustomLibRetrieveNVSetting
/**
 * Returns an NV parameter.
 * Returns the settings for the given NV setting.
 * Any memory allocation must be freed by the calling application, currently, only strings allocate memory
 * This is only valid for CDMA devices.
 *
 * Parameters:
 * @param refNum          IN    CCustomLib reference number
 *                              or SysLibLoad)
 * @param iotaItemType    IN    NV parameter setting
 * @param paramLen        IN    length of the parameter in bytes
 * @param paramDataP      IN    pointer to the data submitted.
 * @param index           IN    index for items which require an index
 *
 * @return errNone on success
 */
extern Err
CCustomLibRetrieveNVSetting(UInt16 refNum, UInt16 iotaItemType, UInt8 *paramLen, UInt8 **paramDataP, UInt8 index)
  CCUSTOM_LIB_TRAP(CCustomLibTrapRetrieveNVSetting);


#if 0
#pragma mark -------- Exported Globals -------- 
#endif

// Declare after the network settings structure
/** globals structure
 *  Holds the carrier specific settings.
 */
typedef struct tagCCustomLibGlobals
{
  Boolean supported;      /**< flag if the detected carrier is supported or not */
  Boolean reserved;       /**< reserved... byte alignment */

  Int16 refCount;         /**< number of times this library is opened */

//  UInt16 refNum;          /**< ref num for the ourselves */
  UInt16 phnLibRefNum;    /**< ref num for the Phone Library */

  char *mccmncP;          /**< carrier ID */

  // @todo
  //   This may be removed when the databases get changed.
//  char *networkKey;       /**< key used for the carrier settings database */
  char *appSettingsKeyP;   /**< key into the branding database */

  CCSMSystemSettingsType     systemSettings;      /**< cached system settings  <NULL if not set> */
  CCSMPhoneSettingsType      phoneSettings;       /**< cached phone settings   <NULL if not set> */
  CCSMNetworkSettingsType    networkSettings;     /**< cached network settings <NULL if not set> */
  CCSMMessengingSettingsType messengingSettings;  /**< cached email settings   <NULL if not set> */
  CCSMBrowserSettingsType    browserSettings;     /**< cached browser settings <NULL if not set> */
}
CCSMGlobalsType;


#endif // __CARRIER_CUSTOMIZATION_LIBRARY_PRV_H__
