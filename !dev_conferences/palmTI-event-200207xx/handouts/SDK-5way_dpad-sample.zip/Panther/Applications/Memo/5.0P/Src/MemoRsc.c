/******************************************************************************
 *
 * Copyright (c) 1995-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: MemoRsc.c
 *
 * Release: Palm OS Updated Application Samples 5.0 (74361)
 *
 * Description:
 *	  The list of resources are stored here.
 *
 * History:
 *		June 9, 1995	Created by Roger Flores
 *
 *****************************************************************************/

#include <BuildDefaults.h>

// RESOURCE_FILE_PREFIX is now defined in :Incs:BuildDefaults.h based on LANGUAGE.

const char *AppResourceList[] = { "MemoMerge"LOCALE_SUFFIX".rsrc", "" };
