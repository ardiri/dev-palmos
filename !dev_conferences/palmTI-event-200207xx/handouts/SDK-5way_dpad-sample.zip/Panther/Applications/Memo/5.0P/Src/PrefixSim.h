/******************************************************************************
 *
 * Copyright (c) 1995-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: PrefixSim.h
 *
 * Description:
 *	  This is the prefix file for the simulator target.
 *
 * History:
 *		March 7, 2002	Created by Peter Epstein
 *
 *****************************************************************************/

// Set up the old Mac simulator so that it can find the system resources even though the
// application resides in Applications:Memo:5.0P while the simulator library resides
// in Steinberg:Libraries:Simulator. Note that this assumes we're using Steinberg as the
// base OS. This is appropriate because it's got high res support and is a full OS that
// has a working Mac simulator.

#define SIMULATOR_SYSTRES_DIR			":::::Steinberg:Libraries:Simulator:Obj:"
#define SIMULATOR_SYSRESOURCE_NAME	":::::Steinberg:Libraries:Simulator:Obj:PalmOSSim.rsrc"
