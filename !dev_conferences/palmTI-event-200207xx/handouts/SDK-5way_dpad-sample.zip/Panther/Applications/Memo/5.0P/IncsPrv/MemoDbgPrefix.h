/******************************************************************************
 *
 * Copyright (c) 2002 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: MemoDbgPrefix.h
 *
 * Release: 
 *
 *****************************************************************************/

#ifndef MEMODBGPREFIX_H
#define MEMODBGPREFIX_H

#include <BuildDefines.h>

#define ERROR_CHECK_LEVEL	ERROR_CHECK_FULL
#define TRACE_OUTPUT		TRACE_OUTPUT_ON
#define MEMO_DEBUG			1

#endif // ADDRDBGPREFIX_H