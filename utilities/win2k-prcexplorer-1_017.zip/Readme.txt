PRCExplorer 1.0.17
------------------

This application is FREEWARE.

You are allowed to freely distribute it but only as the original package with all the original files. 
You are NOT allowed to sell it or make money with it in any way.
It is provided AS-IS without any warranty of any kind. Even if you use for professional purposes. You use it at your own risk.
It is NOT officially supported neither by me nor by Palm. However feel free to send questions/comments/feedback to regis.nicolas@corp.palm.com
The original distribution can be found at www.palmgear.com

Send any question to: <mailto:regis.nicolas@corp.palm.com>

What's new in 1.0.9:
--------------------
- New Zooming functionality: works for Bitmaps, Icons, Forms, Alerts, Fonts
- Improved Font viewer showing each char bitmap individually (with zoom)
- Code viewer displaying Assembly language (with trap names) in applications and extensions
- An helper DLL supporting Fonts, Palettes and Data dump has been created for viewer developers and is used.
- It's now possible to display Talt using the Form Viewer (Hold down 'Alt' while opening the Talt)
- Drawing lines when zooming beyond a value (8)
- Save/Copy bitmaps
- Dynamic sizing of viewers + support for viewers developers

What's new in 1.0.10:
---------------------
- Renamed to PRCExplorer (abandoned the idea of dumping PDB files)
- Bug fix when dropping several files
- Bug fix when a form uses Application defined font
- List resources in their type alphabetical order
- Added support for 16bit uncompressed bitmaps
- F5: refresh, Shift F5: refresh in dump mode
- Added support for 'ovly' resources
- Added binary display of database headers (plus additional fields)
- It's now possible to save a displayed PRC. That opens the door to modifying them.
- It's now possible to remove resources from a database.

What's new in 1.0.11:
---------------------
- Corrected a bug in displaying Tbsb resources (and added CRC validation)
- Fixed a bug when moving the split bar: resize of the right pane was not happening
- Improved bitmaps and forms plugin zoom
- Added staticData to plugins and changed the plugin entry point to return the plugin version which is checked.
- Added support for PackBits bitmap (de)compression
- Added support for Japanese fonts. However since MBAR viewer uses native Windows Menu, Japanese fonts do not work for them.
- Added support for graphical buttons
- Added version field in database viewer
- Moved standard Palm viewers to Palm68KViewers.dll and changed loading order

What's new in 1.0.12:
---------------------
- Added PackBits support for 16 bits bitmaps
- Fixed a bug in PackBits decompressor (4 bpp)
- Added support for High Density bitmaps and icons
- Limited the minimum size of the main window
- Fixed a bug where the scroller did not appear when switching to a bigger bitmap

What's new in 1.0.13:
---------------------
- Help Icon now shows up in the Controls list so it's possible to know which text will be displayed
- Disassembly is not limited anymore on NT, 2000, XP, ...
- Default buttons now show up with a gray background
- Clicking on a graphical button toggles the bitmap between normal and selected mode
- Sliders display their frame if bitmaps are not found in the same prc
- Form viewer improved to display form attributes and other information
- Added support for High Density fonts
- Improved Font viewer: zoom/density persistence when switching fonts
- Removed unused toolbar icons and menus

- 1.0.13 is the first PUBLIC release of PRCExplorer...


What's new in 1.0.14:
---------------------
- Added "File/Save Source" feature: It is now possible to save the rcp generated from the prc
- Added a new "Source" tab in the form viewer
- Added color support in form viewer
- Clicking on a resource while holding down 'Alt' key displays a dialog allowing to choose the viewer to use. 
  This allows to use a different viewer than the registered one for this resource or to use a viewer when none is registered.
- Improved font viewer to display the missing char

- Reorganized form viewer a little bit
- Form viewer now remembers the current tab when changing forms (useful for source)
- PRC is now the default extension in Open File dialogs
- Associated the 'libr' resource type (which are code) with the code viewer
- Displaying graphical control bounds when no bitmap is associated

- BUGFIX: Eliminated one assert when refreshing (F5)
- BUGFIX: Removed a couple of memory leaks
- BUGFIX: '\n' are not displayed as a missing char anymore
- BUGFIX: Last PRC name removed from title when closed
- BUGFIX: Lists display was showing junk
- BUGFIX: Menu viewer was displaying junk if item was finishing with '...'


What's new in 1.0.15:
---------------------
- Added support for ScanLine compressed 16 bpp bitmaps (Packbits was already supported. RLE is not).

- BUGFIX: In some case when using Drag'n'drop, the explorer was not setting the current dir as I thought it would.
  This was leading PRCExplorer not to find the viewers. Now the application directory is explicitly searched.
- BUGFIX: Fixed crash when Saving/Copying bitmaps on Win98.
- BUGFIX: Pressing Esc while on Default Res or PRC viewers was hiding them...


What's new in 1.0.16:
---------------------
- FEATURE: PRCExplorer now comes with a mini-SDK which allows you to implement your own viewers!!!
  There is no documentation yet but a Sample Viewer with it. Feel free to copy/paste :-)

- FEATURE: Save source now saves bitmaps using PilRC2.9p5 (BITMAP|ICON)FAMILYEX new keyword.
- FEATURE: It's now possible to invoke PRCExplorer from the command line to perform PRC->RCP operation.
  The syntax is: PRCExplorer filename.prc -o source.rcp [-q]
  You can convert only one file at a time. 
  -q is used so PRCExplorer does not popup an error dialog if the conversion fails.
  ERRORLEVEL is set to:
    - 0 if everything went OK, 
	- 1 if the command line parameters are invalid or misused,
	- 2 if loading or parsing the prc generated an error,
	- 3 if it was not possible to save the rcp file
- FEATURE: User defined fonts are now supported in the Form viewer for fonts defined in the same PRC
- FEATURE: Added a "Bitmap Size" field in the bitmap viewer for the currently displayed bitmap
- FEATURE: Added 'pref' and 'xprf' viewers

- BUGFIX: Fixed several problems with v3 bitmaps (especially HiRes)
- BUGFIX: Saved 16bpp bitmaps were causing some external apps to crash or hang. Fixed.
- BUGFIX: Ctrl+A, Ctrl+C now works in edit fields


What's new in 1.0.17:
---------------------
- FEATURE: Density added in the bitmap list of a bitmap family.
- FEATURE: Reload (F6): reloads the same PRC from disk and updates the display.
- FEATURE: Added support for color tables in 1, 2, 4 and 8 bpp bitmaps.
- FEATURE: Save source now saves fonts.

- BUGFIX: 16 bpp bitmaps display and transparency fixed.
- BUGFIX: The form viewer was sometimes displaying the HiRes version of some embedded bitmaps.
- BUGFIX: The bitmap viewer was displaying junk below and on the right of the image when scrolling in zoomed mode.
- BUGFIX: When switching between bitmaps families, it remembers the previously displayed bpp. Now, it also remembers the density.
