/* $Id: resize.c,v 1.4 2004/04/24 19:58:21 arpruss Exp $ */
/*******************************************************************************
    Copyright (c) 2004, Alexander R. Pruss
    All rights reserved.

    Redistribution and use in source and binary forms, with or without modification,
    are permitted provided that the following conditions are met:

        Redistributions of source code must retain the above copyright notice, this
        list of conditions and the following disclaimer.

        Redistributions in binary form must reproduce the above copyright notice, this
        list of conditions and the following disclaimer in the documentation and/or
        other materials provided with the distribution.

        Neither the name of the PalmResize Project nor the names of its
        contributors may be used to endorse or promote products derived from this
        software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/

#include <PalmOS.h>
#include "util.h"
#include "DIA.h"

#define DebugInfo(s) /* { char ss[500];StrPrintF(ss,"%s(%d) ",s,activeFormID);\
        ClipboardAppendItem(clipboardText,ss,StrLen(ss)); } */

static DIAFormEntryType* formList = NULL;
static DIAStateType*     bins;
static UInt16            numBins;
static UInt16            formCount = 0;
static UInt16            activeFormID;
static FormType*         activeFormPtr;
static UInt16            activeIndex;
static UInt16            activeFlags;
static DIAFormEntryType* activeEntry;
static Boolean           haveWinDisplayChangedEvent = false;
static Boolean           forceRedraw = false;



/* Update form, but only once */
void UniqueUpdateForm( UInt16 formID, UInt16 code )
{
    EventType e;
    MemSet( &e, sizeof(EventType), 0 );
    e.eType                     = frmUpdateEvent;
    e.data.frmUpdate.formID     = formID;
    e.data.frmUpdate.updateCode = code;
    EvtAddUniqueEventToQueue( &e, 0, true );
}



/* Same as FrmGetObjectIndex() but works with GSI_OBJECT_ID, too */
static UInt16 MyFrmGetObjectIndex( FormPtr formPtr, UInt16 id )
{
    UInt16 i;
    if ( id != GSI_OBJECT_ID )
        return FrmGetObjectIndex( formPtr, id );
    for ( i = FrmGetNumberOfObjects( formPtr ) - 1 ; 0 < i ; i -- ) {
        if ( FrmGetObjectType( formPtr, i ) == frmGraffitiStateObj ) {
            return i;
        }
    }
    return 0;
}



void WinGlueGetBounds( WinHandle winH, RectangleType* rect )
{
    Err     err;
    UInt32  version;
    err = FtrGet( sysFtrCreator, sysFtrNumROMVersion, &version );
    if ( err == errNone && 0x04003000 <= version ) {
        WinGetBounds( winH, rect );
    }
    else {
        WinHandle oldH;
        oldH = WinSetDrawWindow( winH );
        WinGetDrawWindowBounds( rect );
        WinSetDrawWindow( oldH );
    }
}



static void AddForm( UInt16 indexInList, MemHandle handle, UInt16 formID )
{
    UInt16         numObjects;
    DIAConfigType* config;

    formList[ indexInList ].configHandle = handle;
    if ( handle == NULL ) {
        return;
    }

    config          = MemHandleLock( handle );
    numObjects      = ( ( config->sizeInWords + 1 ) * sizeof( UInt16 ) -
                        sizeof( DIAConfigType ) ) /
                          sizeof( DIAConfigEntryType );

    formList[ indexInList ].formID         = formID;
    formList[ indexInList ].config         = config;
    formList[ indexInList ].numObjects     = numObjects;
    formList[ indexInList ].open           = false;

    if ( config->flags & DIA_FORM_USE_BIN &&
         numBins < 1 + config->bin )
        numBins = 1 + config->bin;
}



/* This sets up the original bounds array as needed */
static void InitialSetupForm( UInt16 indexInList )
{
    RectangleType* originalBounds;
    FormType*      formPtr;
    UInt16         numObjects;
    UInt16         i;

    numObjects = formList[ indexInList ].numObjects;
    if ( numObjects == 0 )
        return;
    if ( formList[ indexInList ].originalBounds != NULL )
        return;
    formPtr = FrmGetFormPtr( formList[ indexInList ].formID );
    if ( formPtr == NULL )
        return;

    originalBounds = SafeMemPtrNew( numObjects * sizeof( RectangleType ) );
    formList[ indexInList ].originalBounds = originalBounds;

    /* First object is the form itself */
    WinGlueGetBounds( FrmGetWindowHandle( formPtr ), &( originalBounds[ 0 ] ) );

    /* Now on to the other objects */
    for ( i = 1 ; i < numObjects ; i++ ) {
         UInt16 objectIndex;
         objectIndex = MyFrmGetObjectIndex( formPtr,
                     formList[ indexInList ].config->objectList[ i ].objectID );
         FrmGetObjectBounds( formPtr, objectIndex, &( originalBounds[ i ] ) );
    }
}



/* Adjust one coordinate */
static Coord Adjust
    (
    Coord value,            /* old value to adjust */
    Coord oldObjectExtent,  /* old extent if relevant */
    Coord newObjectExtent,  /* already adjusted extent if relevant */
    Coord oldExtent,        /* old form/screen extent */
    Coord newExtent,        /* new form/screen extent */
    UInt16 shiftedFlag      /* adjustment flag, shifted down as needed */
    )
{
    Coord delta;
    
    delta = newExtent - oldExtent;

    switch ( shiftedFlag ) {
        case DIA_X_FIX >> DIA_SHIFT_X:
            return value;
        case DIA_X_RATIO >> DIA_SHIFT_X:
            return value * ( Int32 )newExtent / oldExtent;
        case DIA_X_RIGHT >> DIA_SHIFT_X:
            return newExtent - ( oldExtent - value - oldObjectExtent ) - newObjectExtent;
        case DIA_X_PLUS_DW >> DIA_SHIFT_X:
            return value + delta;
        case DIA_X_PLUS_1_2_DW >> DIA_SHIFT_X:
            return value + delta / 2;
        case DIA_X_PLUS_1_3_DW >> DIA_SHIFT_X:
            return value + delta / 3;
        case DIA_X_PLUS_2_3_DW >> DIA_SHIFT_X:
            return value + 2 * delta / 3;
        case DIA_X_PLUS_1_4_DW >> DIA_SHIFT_X:
            return value + delta / 4;
        case DIA_X_PLUS_3_4_DW >> DIA_SHIFT_X:
            return value + 3 * delta / 4;
        default: /* should not happen */
            return value;
    }
}



/* Get new bounds for an object, adjusted for DIA */
static void GetNewBounds( UInt16 displayExtentX, UInt16 displayExtentY,
    UInt16 stdFormExtentX, UInt16 stdFormExtentY,
    RectangleType* oldBounds, RectangleType* newBounds,
    DIAConfigEntryType* configEntry )
{
    UInt16 flags;
    flags = configEntry->flags;

    newBounds->extent.x  = Adjust( oldBounds->extent.x, 0, 0, stdFormExtentX,
                               displayExtentX,
                               ( flags & DIA_MASK_W ) >> DIA_SHIFT_W );
    newBounds->extent.y  = Adjust( oldBounds->extent.y, 0, 0, stdFormExtentY,
                               displayExtentY,
                               ( flags & DIA_MASK_H ) >> DIA_SHIFT_H );
    newBounds->topLeft.x = Adjust( oldBounds->topLeft.x, oldBounds->extent.x,
                               newBounds->extent.x,
                               stdFormExtentX, displayExtentX,
                               ( flags & DIA_MASK_X ) >> DIA_SHIFT_X );
    newBounds->topLeft.y = Adjust( oldBounds->topLeft.y, oldBounds->extent.y,
                               newBounds->extent.y,
                               stdFormExtentY, displayExtentY,
                               ( flags & DIA_MASK_Y ) >> DIA_SHIFT_Y );
}



/* This compares two rectangles.  If sonyDoubleSecond is set and the first
   bounds are exactly double the size of the first and DIA hardware is
   DIA_HARDWARE_SONY1, then they also match. */
static Boolean SameBounds( RectangleType* a, RectangleType* b,
    Boolean sonyDoubleSecond )
{
    Boolean compare;
    compare = ( a->extent.y == b->extent.y && a->extent.x == b->extent.x &&
                a->topLeft.y == b->topLeft.y && a->topLeft.x == b->topLeft.x );
#ifdef SUPPORT_DIA_SONY
    if ( ! compare && GetDIAHardware() == DIA_HARDWARE_SONY1 ) {
        return a->extent.y == 2 * b->extent.y &&
               a->extent.x == 2 * b->extent.x &&
               a->topLeft.y == 2 * b->topLeft.y &&
               a->topLeft.x == 2 * b->topLeft.x;
    }
#endif
    return compare;
}



/* Returns true if there is moving done */
static Boolean MoveObjectsInForm( UInt16 indexInList )
{
    Coord     extentX;
    Coord     extentY;
    UInt16    i;
    FormType* formPtr;
    RectangleType  newBounds;
    RectangleType  curBounds;

    formPtr = FrmGetFormPtr( formList[ indexInList ].formID );
    if ( formPtr == NULL )
        return false;
    InitialSetupForm( indexInList );
    WinGetDisplayExtent( &extentX, &extentY );

    /* First object is the form itself */
    GetNewBounds( extentX, extentY, STD_EXTENT_X, STD_EXTENT_Y,
         &( formList[ indexInList ].originalBounds[ 0 ] ),
         &newBounds, &( formList[ indexInList ].config->objectList[ 0 ] ) );
    WinGlueGetBounds( FrmGetWindowHandle( formPtr ), &curBounds );

    if ( SameBounds( &curBounds, &newBounds, true ) ||
         ( formList[ indexInList ].open &&
           SameBounds( &newBounds, &( formList[ indexInList ].lastBounds ), false ) ) )
        return false;

    formList[ indexInList ].lastBounds = newBounds;
    WinSetBounds( FrmGetWindowHandle(formPtr), &newBounds );

    /* The rest is resized relative to the form itself */
    extentX = newBounds.extent.x;
    extentY = newBounds.extent.y;

    for ( i = 1 ; i < formList[ indexInList ].numObjects ; i++ ) {
         UInt16         objectIndex;
         objectIndex = MyFrmGetObjectIndex( formPtr,
                     formList[ indexInList ].config->objectList[ i ].objectID );
         GetNewBounds( extentX, extentY,
             formList[ indexInList ].originalBounds[ 0 ].extent.x,
             formList[ indexInList ].originalBounds[ 0 ].extent.y,
             &( formList[ indexInList ].originalBounds[ i ] ),
             &newBounds, &( formList[ indexInList ].config->objectList[ i ] ) );
         FrmGetObjectBounds( formPtr, objectIndex, &curBounds );
         if ( ! SameBounds( &curBounds, &newBounds, false ) ) {
             FrmSetObjectBounds( formPtr, objectIndex, &newBounds );
             switch ( FrmGetObjectType( formPtr, objectIndex ) ) {
                 case frmFieldObj:
    /*             case frmScrollBarObj: */
                 {
                     FieldType* field;
                     field = ( FieldType* ) FrmGetObjectPtr( formPtr, objectIndex );
                     FldRecalculateField( field, false );
                     break;
                 }
                 default:
                     break;
             }
         }
    }
    return true;
}



void InitializeResizeSupport( UInt16 formMapId )
{
    MemHandle     indexHandle;
    DIAIndexType* index;
    UInt16        i;

    if ( formList != NULL )
        return;
    indexHandle = DmGetResource( WORD_LIST_TYPE, formMapId );
    if ( indexHandle == NULL )
        return;

    if ( DIA_HARDWARE_NONE == InitializeDIA() )
        return;

    index     = MemHandleLock( indexHandle );
    numBins   = 0;
    formCount = index->count * sizeof( UInt16 ) /
                    sizeof( DIAIndexEntryType );

    if ( formCount == 0 ) {
        numBins = 0;
        return;
    }

    formList  = SafeMemPtrNew( formCount * sizeof( DIAFormEntryType ) );
    MemSet( formList, formCount * sizeof( DIAFormEntryType ), 0 );

    for ( i = 0 ; i < formCount ; i++ ) {
         AddForm( i, DmGetResource( WORD_LIST_TYPE, index->mapList[ i ].to ),
             index->mapList[ i ].from );
    }

    MemHandleUnlock( indexHandle );
    DmReleaseResource( indexHandle );

    if ( 0 < numBins ) {
        bins = SafeMemPtrNew( numBins * sizeof( DIAStateType ) );
        for ( i = 0 ; i < numBins ; i++ )
             bins[ i ] = DIA_STATE_UNDEFINED;
    }
}




void TerminateResizeSupport( void )
{
     UInt16  i;

     if ( formList == NULL )
         return;
     TerminateDIA();
     for ( i = 0 ; i < formCount ; i++ ) {
          if ( NULL != formList[ i ].configHandle ) {
              MemHandleUnlock( formList[ i ].configHandle );
              DmReleaseResource( formList[ i ].configHandle );
              if ( formList[ i ].originalBounds != NULL )
                  SafeMemPtrFree( formList[ i ].originalBounds );
          }
     }
     SafeMemPtrFree( formList );
     formCount = 0;
     if ( 0 < numBins ) {
         SafeMemPtrFree( bins );
     }
}




void LoadResizePrefs( UInt32 appID, UInt16 prefID )
{
    UInt16 size;

    size = 0;

    if ( formList == NULL || numBins == 0 ||
         noPreferenceFound ==
             PrefGetAppPreferences( appID, prefID, NULL, &size, true ) ) {
        return;
    }

    if ( numBins * sizeof( UInt16 ) < size ) {
        size = numBins * sizeof( UInt16 );
    }

    PrefGetAppPreferences( appID, prefID, bins, &size, true );
}



void SaveResizePrefs( UInt32 appID, UInt16 prefID, Int16 version )
{
    if ( formList == NULL || numBins == 0 )
        return;

    PrefSetAppPreferences( appID, prefID, version, bins,
        numBins * sizeof( UInt16 ), true );
}



static UInt16 GetFormIndex( formID )
{
    UInt16 i;

    if ( formList == NULL )
        return 0;

    for ( i = 0 ; i < formCount ; i++ )
        if ( formList[ i ].formID == formID )
            break;

    return i;
}



void SetResizePolicy( UInt16 formID )
{
    if ( GetFormIndex( formID ) < formCount )
        SetCustomDIAPolicy( formID );
}



static Boolean GetFormInfo( void )
{
    activeFormID  = FrmGetActiveFormID();
    activeFormPtr = FrmGetActiveForm();
    activeIndex   = GetFormIndex( activeFormID );

    if ( activeIndex < formCount ) {
        activeEntry = &( formList[ activeIndex ] );
        activeFlags = activeEntry->config->flags;
        return true;
    }
    else {
        return false;
    }
}





static Boolean PrepareForm( void )
{
    if ( activeIndex == formCount ) {
        SetDIAState( DIA_STATE_MAX );
        SetDIAAllowResize( false );
        return false;
    }

    return MoveObjectsInForm( activeIndex );
}



static void SaveDIAState( void )
{
    if ( activeIndex == formCount )
        return;

    if ( activeEntry->config->flags & DIA_FORM_USE_BIN ) {
        bins[ activeEntry->config->bin ] = GetDIAState();
    }
}




static Boolean FormStartup( void )
{
    DIAStateType newState;
    Boolean   big;
    Boolean   allowBig;
    Boolean   changed;

    if ( activeIndex == formCount ) {
        SetDIAState( DIA_STATE_MAX );
        SetDIAAllowResize( false );
        SetDIAConstraints( FrmGetWindowHandle( activeFormPtr ), false, false );
        return false;
    }

    newState = GetDIAState();

    if ( ( activeFlags & DIA_FORM_USE_BIN ) &&
         ( bins[ activeEntry->config->bin ] != DIA_STATE_UNDEFINED ) ) {
        newState = bins[ activeEntry->config->bin ];
/*        if ( newState == DIA_STATE_MIN ) DebugInfo("bin = min");
        if ( newState == DIA_STATE_MAX ) DebugInfo("bin = max"); */
    }
    else if ( ! ( activeFlags & DIA_FORM_KEEP_LAST ) ) {
        newState = activeEntry->config->preferredState;
    }

    if ( activeFlags & DIA_FORM_NO_RESIZE ) {
        SetDIAAllowResize( false );
        allowBig = false;
    }
    else {
        SetDIAAllowResize( true );
        allowBig = true;
    }

    big      = ( newState == DIA_STATE_MIN || newState == DIA_STATE_NO_STATUS_BAR );
    allowBig = allowBig || big;

    SetDIAConstraints( FrmGetWindowHandle( activeFormPtr ), big, allowBig );

    SetDIAState( newState );

    changed = PrepareForm();

/*    if ( changed ) DebugInfo("Changed in FormStartup"); */

    SaveDIAState();

    return changed;
}


Boolean ResizeHandleFrmOpenEvent( void )
{
    GetFormInfo();
    if ( activeIndex < formCount ) {
        MemSet( &( activeEntry->lastBounds ), sizeof( RectangleType ), 0 );
    }
    DebugInfo("FrmOpen");
    PushCoordinateSystemToStandard();
    FormStartup();
    if ( activeIndex < formCount ) {
        activeEntry->open = true;
    }
    PopCoordinateSystem();
    forceRedraw                = false;
    haveWinDisplayChangedEvent = false;
    return true;
}



Boolean ResizeHandleFrmCloseEvent( void )
{
    if ( GetFormInfo() ) {
        DebugInfo("FrmClose");
        activeEntry->open        = false;
        SaveDIAState();
    }
    return true;
}



Boolean ResizeHandleWinDisplayChangedEvent( void )
{
    haveWinDisplayChangedEvent = false;
    if ( ! GetFormInfo() )
        return true;

    PushCoordinateSystemToStandard();

    DebugInfo("WinDisplayChanged");
    if ( PrepareForm() || forceRedraw )
        UniqueUpdateForm( activeFormID, frmRedrawUpdateCode );
    forceRedraw = false;
    SaveDIAState();

    PopCoordinateSystem();

    return true;
}



Boolean ResizeHandleWinExitEvent( void )
{
    DebugInfo("WinExit");
    SaveDIAState();
    return true;
}



Boolean ResizeHandleWinEnterEvent( void )
{
    DIAStateType  initialState;

    GetFormInfo();
    DebugInfo("WinEnter");
    if ( activeIndex == formCount )
        return true;

    PushCoordinateSystemToStandard();

    initialState = GetDIAState();

    if ( activeEntry->open && ( FormStartup() ||
             0 < CompareDIAState( initialState, GetDIAState() ) ) ) {
        /* typically triggered on re-entry after modal */
        DebugInfo("WinEnter: Update");
        UniqueUpdateForm( activeFormID, frmRedrawUpdateCode );
        SaveDIAState();
        forceRedraw = false;
    }
    else if ( activeEntry->open && haveWinDisplayChangedEvent ) {
        EventType e;
        DebugInfo("WinEnter: Possibly missed winDisplayChangedEvent");
        MemSet( &e, sizeof( EventType ), 0 );
        e.eType = winDisplayChangedEvent;
        EvtAddUniqueEventToQueue( &e, 0, true );
        forceRedraw = true;
        DebugInfo("Queuing display change");
    }
    haveWinDisplayChangedEvent = false;

    PopCoordinateSystem();

    return true;
}




void SetHaveWinDisplayChangedEvent( Boolean value )
{
    haveWinDisplayChangedEvent = value;
}




void ResizeRefreshCurrentForm( void )
{
    GetFormInfo();
    if ( activeIndex == formCount )
        return;

    PushCoordinateSystemToStandard();

    FormStartup();
    SaveDIAState();
    UniqueUpdateForm( activeFormID, frmRedrawUpdateCode );

    PopCoordinateSystem();
}

