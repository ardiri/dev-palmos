/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     SoundMgr.c
 * AUTHOR:	 Vitaly Kruglikov: Apr 11, 1995
 *
 * DECLARER: System
 *
 * ROUTINES:
 *		
 * DESCRIPTION:
 *	  This file contains the Sound Manager routines.
 *
 **********************************************************************/

#include <SysAll.h>
#include <SoundMgr.h>

#if EMULATION_LEVEL != EMULATION_NONE
	#include <EmuStubs.h>
#endif // EMULATION_LEVEL != EMULATION_NONE


#define NON_PORTABLE

#if EMULATION_LEVEL == EMULATION_NONE
	#include <Hardware.h>
	#include <M68328Hwr.h>
	#include <HardwarePrv.h>
#endif // EMULATION_LEVEL == EMULATION_NONE

#include <Globals.h>
#include <SoundPrv.h>


//-------------------------------------------------------------------
//		Private constants used only by this module
//-------------------------------------------------------------------

//-------------------------------------------------------------------
//		Private routines used only by this module
//-------------------------------------------------------------------
static void	PrvDoFreqDurationAmp(SndCommandPtr cmdP);
static void	PrvPlayAlarmSound(void);
static void PrvSoundKillTimerProc(Long timerID, Long param);

//-------------------------------------------------------------------
//		Macros used only by this module
//-------------------------------------------------------------------


// Macros for starting and stopping the "sound off" countdown.
// On the device, we rely on the timer tick interrupt handler (AmxHardwareTD1.c)
// to handle the "sound off" operation.  In emulation, we're using a "system timer".
//
#if EMULATION_LEVEL == EMULATION_NONE

	#define prvStartSoundOffCountdown(gP, dwTicks)						\
		(GSndOffTicks = (dwTicks))

	#define prvStopSoundOffCountdown(gP)									\
		(GSndOffTicks = 0)

#else		// EMULATION_LEVEL != EMULATION_NONE

	#define prvStartSoundOffCountdown(gP, dwTicks)						\
		(gP->timerID ? SysTimerWrite(gP->timerID, dwTicks) : 0)

	#define prvStopSoundOffCountdown(gP)									\
		(gP->timerID ? SysTimerWrite(gP->timerID, 0) : 0)

#endif


//-------------------------------------------------------------------
//		Sound Manager Initialization routines
//-------------------------------------------------------------------



/*********************************************************************************
 *  FUNCTION: SndInit
 *
 *  DESCRIPTION: Initializes the sound manager.
 *
 *		Allocate the sound globals and the shared channel in the dynamic
 *		heap.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if successful; otherwise: sndErrMemory
 *
 *  CREATED: 4/12/95
 *
 *  BY: Vitaly Kruglikov
 *
 *		vmk	9/3/97	Added a call to ISndMidiInit
 *
 *********************************************************************************/
Err SndInit(void)
{
	Err				err = 0;
	SndGlobalsPtr	gP = 0;

// timer used only under emulation
#if EMULATION_LEVEL != EMULATION_NONE
	DWord				timerTag = 'sndt';				
#endif

#if EMULATION_LEVEL == EMULATION_NONE
	DWord				smID = 0;
	DWord				tag = 'SndM';
#endif // EMULATION_LEVEL == EMULATION_NONE


	// We shouldn't be called more than once without being freed in between
	ErrFatalDisplayIf( GSndGlobalsP, "already initialized" );
	
	// Allocate and initialize the Sound Manager globals
	gP = (SndGlobalsPtr)MemPtrNew( sizeof(SndGlobalsType) );
	if ( !gP ) goto ErrorMem;
	MemSet( gP, sizeof(SndGlobalsType), 0 );	// initialize

	gP->defAmp = sndDefaultAmp;					// initialize default amplitude

#if EMULATION_LEVEL == EMULATION_NONE
	// Allocate the Sound Manager semaphore
	// We use a semaphore to protect data integrity during task switching
	err = SysSemaphoreCreate(&smID, &tag, 1/*initValue*/);
	if ( err ) goto ErrorMem;
	gP->smID = smID;
#endif // EMULATION_LEVEL == EMULATION_NONE

	// Load the sound preferences
	gP->sysAmp = PrefGetPreference(prefSysSoundVolume);
	gP->alarmAmp = PrefGetPreference(prefAlarmSoundVolume);
	
// timer used only under emulation
#if EMULATION_LEVEL != EMULATION_NONE
	// Create the "sound kill" timer
	err = SysTimerCreate(&gP->timerID, &timerTag, 
							PrvSoundKillTimerProc, 0/*periodicDelay*/,
							(Long)gP);
	ErrFatalDisplayIf(err, "unable to create sound-kill timer");
#endif
	
	// Initialize the MIDI engine
	ISndMidiInit(gP);
						
	// Link system globals to sound globals
	GSndGlobalsP = (Ptr)gP;
	
	// Make sure sound is off at reset
	ISndSoundOff();
	
	return( err );

ErrorMem:
	// Free anything allocated here
	if ( gP )
		MemPtrFree( gP );
	
#if EMULATION_LEVEL == EMULATION_NONE
	if ( smID )
		SysSemaphoreDelete( smID );
#endif // EMULATION_LEVEL == EMULATION_NONE
		
	return( sndErrMemory );
}



//-------------------------------------------------------------------
//		Sound Manager API routines
//-------------------------------------------------------------------



/***********************************************************************
 *
 * FUNCTION:    SndCompareMidiNames
 *
 * DESCRIPTION: Compare one midi record name to another (for sorting purposes).
 *
 * PARAMETERS:	 SndMidiListItemType *a, *b - the items to compare
 *					 other - not used in the comparison
 *
 * RETURNED:	 if a < b return -1
 *					 if a==b return 0
 *					 if a > b return -1
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/5/96	Initial Revision
 *
 ***********************************************************************/
static Int SndCompareMidiNames (void *a, void *b, Long other)
{
	return StrCompare(((SndMidiListItemType *)a)->name, ((SndMidiListItemType *)b)->name);
}


/************************************************************
 * API
 *-----------------------------------------------------------
 *
 *  FUNCTION: SndCreateMidiList
 *
 *  DESCRIPTION: Generate a list of midi samples found in midi databases.
 *
 *  PARAMETERS:	creator		-- creator of the MIDI database(s); pass zero for wildcard
 *						multipleDBs	-- pass true to look for multiples midi databases
 *						wCountP		-- pointer to contain count of matching databases
 *						entHP			-- pointer to handle allocated to contain the MIDI list
 *
 *  RETURNS:	FALSE when no entries are returned;
 *					*wCountP is set to the number of matches
 *					*entHP is set to the list of matches
 *
 *  CREATED: 8/1/97
 *
 *  BY: Roger Flores
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	???		Initial version
 *			vmk	???		Debugged
 *			vmk	10/21/97	Added creator and multipleDBs args
 *			vmk	12/15/97	Fixed to not realloc to zero size
 *
 *************************************************************/
extern Boolean SndCreateMidiList(ULong creator, Boolean multipleDBs, WordPtr wCountP,
		Handle *entHP)
{
	Int						midiIndex;		// UInt results in a bug
	
	UInt 						cardNo;
	LocalID					dbID;
	DmOpenRef 				dbP;
	
	DmSearchStateType		searchState;
	Boolean					newSearch = true;
	UInt						maxItems = 16;
	
	SndMidiListItemType	*midiListP;
	SndMidiListItemType	*midiItemP;
	Err						err=0;
	UInt						index;
	Handle					recordH;
	SndMidiRecType*		recP;
	UInt						recordsInDatabase;
	
	
	
	// Allocate a minimum size SndMidiListItemType array to hold
	//  list of midi records.
	*entHP = MemHandleNew(maxItems * sizeof(SndMidiListItemType));
	if (!*entHP)
		return false;
	midiListP = MemHandleLock(*entHP);

	
	// Create a list of matching databases.  We do not care about the order
	// or multiple versions yet.  The assumption is that there won't be many 
	// multiple versions.
	// �(n)
	midiIndex = 0;
	while (true) 
		{
		// Seach for the next MIDI database
		err = DmGetNextDatabaseByTypeCreator(newSearch, &searchState, 
					sysFileTMidi, creator, false, &cardNo, &dbID);
		if (err)
			break;
		newSearch = false;


		dbP = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
		recordsInDatabase = DmNumRecords(dbP);
		for (index = 0; index < recordsInDatabase; index++)
			{
			if ((recordH = DmQueryRecord(dbP, index)) != 0)
				{
				// See if we need to grow our SndMidiListItemType array
				if (midiIndex >= maxItems)
					{
					MemPtrUnlock(midiListP);
					midiListP = 0;
					maxItems += 4;
					err = MemHandleResize(*entHP, maxItems * sizeof(SndMidiListItemType));
					midiListP = MemHandleLock(*entHP);
					if (err) 
						{
						maxItems -= 4;
						break;
						}
					}
				
				
								
				// Save the info on this db
				midiItemP = &midiListP[midiIndex];
				recP = (SndMidiRecType*) MemHandleLock(recordH);
				ErrNonFatalDisplayIf(recP->hdr.signature != sndMidiRecSignature,
					"invalid MIDI record");
				if ( recP->hdr.signature == sndMidiRecSignature )
					{
					StrNCopy(midiItemP->name, recP->name, sndMidiNameLength);
					midiItemP->dbID = dbID;
					midiItemP->cardNo = cardNo;
					
					// Get the unique record ID of the MIDI record
					DmRecordInfo(dbP, index, NULL, &midiItemP->uniqueRecID, NULL);
									
					midiIndex++;
					}
				MemPtrUnlock(recP);
				}
			
			}
		DmCloseDatabase(dbP);
		
		if ( !multipleDBs )
			break;
		}
		

	// Sort the midi records by name.  �(n log n)
	SysQSort (midiListP, midiIndex, sizeof(SndMidiListItemType), SndCompareMidiNames, 0);
	
	
	// We might want to shrink the database list to conserve memory.
	// Extra may have been allocated.
	// � (1)
	if (midiIndex < maxItems && midiIndex > 0) 
		{
		MemPtrUnlock(midiListP);
		midiListP = 0;
		err = MemHandleResize(*entHP, midiIndex * sizeof(SndMidiListItemType));
		midiListP = MemHandleLock(*entHP);
		}
		
	
	
	// Record how many matches were found
	*wCountP = midiIndex;
	
Exit:
	if (midiListP)
		MemPtrUnlock(midiListP);
	
	// If nothing was found, remove the memory allocated.	
	if (*wCountP == 0)
		{
		MemHandleFree(*entHP);
		*entHP = 0;
		return false;
		}
		
	return true;
}



/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: SndSetDefaultVolume
 *
 * DESCRIPTION: Sets the default sound volume levels
 *
 *					Any pointer arguments may be passed as NULL
 *
 * PARAMETERS:	alarmAmpP	-- ptr to alarm amplitude(0-sndMaxAmp)
 *					sysAmpP		-- ptr to system sound amplitude(0-sndMaxAmp)
 *					defAmpP		-- ptr to default amplitude for other sounds(0-sndMaxAmp)
 *
 * RETURNS: void
 *
 * CREATED: 4/14/95
 *
 * BY: Vitaly Kruglikov
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/21/95	Added parametes for alarm and system sounds
 *************************************************************/
void SndSetDefaultVolume(UIntPtr alarmAmpP, UIntPtr sysAmpP, UIntPtr defAmpP)
{
	SndGlobalsPtr		gP = (SndGlobalsPtr)GSndGlobalsP;
	
	
	// By this time, we should have been initialized
	ErrFatalDisplayIf( !gP, "not initialized" );

	if ( alarmAmpP )
		{
		ErrNonFatalDisplayIf( *alarmAmpP > sndMaxAmp, "bad alarm amp param" );
		gP->alarmAmp = min(*alarmAmpP, sndMaxAmp);
		}

	if ( sysAmpP )
		{
		ErrNonFatalDisplayIf( *sysAmpP > sndMaxAmp, "bad sys amp param" );
		gP->sysAmp = min(*sysAmpP, sndMaxAmp);
		}

	if ( defAmpP )
		{
		ErrNonFatalDisplayIf( *defAmpP > sndMaxAmp, "bad other amp param" );
		gP->defAmp = min(*defAmpP, sndMaxAmp);
		}

}


/************************************************************
 * API
 *-----------------------------------------------------------
 *
 *  FUNCTION: SndGetDefaultVolume
 *
 *  DESCRIPTION: Returns default sound volume levels
 *
 *					Any pointer arguments may be passed as NULL
 *
 * PARAMETERS:	alarmAmpP	-- ptr to alarm amplitude(0-sndMaxAmp)
 *					sysAmpP		-- ptr to system sound amplitude(0-sndMaxAmp)
 *					defAmpP		-- ptr to default amplitude for other sounds(0-sndMaxAmp)
 *
 *  RETURNS: void
 *
 *  CREATED: 4/11/95
 *
 *  BY: Vitaly Kruglikov
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/21/95	Added parametes for alarm and system sounds
 *************************************************************/
void SndGetDefaultVolume(UIntPtr alarmAmpP, UIntPtr sysAmpP, UIntPtr defAmpP)
{
	SndGlobalsPtr	gP = (SndGlobalsPtr)GSndGlobalsP;
	
	
	// By this time, we should have been initialized
	ErrFatalDisplayIf( !gP, "not initialized" );

	if ( alarmAmpP )
		*alarmAmpP = gP->alarmAmp;

	if ( sysAmpP )
		*sysAmpP = gP->sysAmp;

	if ( defAmpP )
		*defAmpP = gP->defAmp;
}



/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: SndDoCmd
 *
 * DESCRIPTION: Sends a Sound Manager command to a sound channel.
 *
 *				NOTE: Passing nil for the channel pointer causes the
 *				command to be sent to the shared sound channel.
 *
 *				Presently, we do not support multiple channels.
 *
 * PARAMETERS:
 *		chanP			-- sound channel pointer, or nil for the shared channel;
 *		cmdP			-- ptr to sound command structure;
 *		noWait			-- 0 = await completion, !0 = immediate return;
 *
 * RETURNS: 0 if successful; otherwise:	sndErrBadParam
 *											sndErrBadChannel
 *											sndErrQFull
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			vmk	8/28/95	Initial version
 *			tlw	2/4/98	If client asks for sound and dwTicks == 0, use 1
 *
 *************************************************************/
Err SndDoCmd(VoidPtr chanP, SndCommandPtr cmdP, Boolean noWait)
{
	Err				err = 0;
	SndGlobalsPtr	gP = (SndGlobalsPtr)GSndGlobalsP;
	ULong				dwTicks;
	Boolean			soundOn;


	// By this time, we should have been initialized
	ErrFatalDisplayIf( !gP, "not initialized" );
	// We only support the shared channel for now
	ErrFatalDisplayIf( chanP, "bad channel ptr" );

	// Get exclusive access to channel
	SysSemaphoreWait( gP->smID, 0, 0 );
	
	// Process the command
	switch ( cmdP->cmd )
		{			
		case sndCmdFreqDurationAmp:
			PrvDoFreqDurationAmp( cmdP );
			break;

		case sndCmdNoteOn:
		case sndCmdFrqOn:
			// Compute max duration in system ticks
			dwTicks = sndMilliSecToPilotTicks(cmdP->param2);
	
			// If user wanted some sound then give them the minimum (vs no sound)
			if (cmdP->param2 && !dwTicks)
				dwTicks = 1;
			
			// Stop the sound-kill timer
			prvStopSoundOffCountdown(gP);
			
			// Start the sound
			if ( cmdP->cmd == sndCmdNoteOn )
				err = ISndMidiNoteOn(gP, (Byte)cmdP->param1, (Byte)cmdP->param3, sndMaxAmp, &soundOn);
			else
				soundOn = ISndFrqOn(cmdP->param1, cmdP->param3);
				
			// If max duration is non-zero, start the sound-kill timer
			if ( dwTicks && soundOn )
				{
				prvStartSoundOffCountdown(gP, dwTicks);
				}

			// otherwise, kill the sound immediately
			else
				{
				ISndSoundOff();
				}
				
			break;

		case sndCmdQuiet:
			ISndSoundOff();
			break;
		
		default:		// unhandled command
			ErrNonFatalDisplayIf(true, "unknown sound cmd" );
			err = sndErrBadParam;
			break;
		}

	// Release exclusive access to channel
	SysSemaphoreSignal( gP->smID );

	return( err );
}



/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: SndPlaySystemSound
 *
 * DESCRIPTION: Plays a standard system sound
 *
 *	THOUGHTS: The system beeps should be played immediately,
 *			replacing the command in progress, but without flushing the
 *			shared channel's queue.
 *
 * PARAMETERS: beep id - one of sndBeep... constants.
 *
 * RETURNS: void
 *
 * CREATED: 4/17/95
 *
 * BY: Vitaly Kruglikov
 *
 *************************************************************/
void SndPlaySystemSound(SndSysBeepType beepID)
{
	SndGlobalsPtr		gP = (SndGlobalsPtr)GSndGlobalsP;
	SndCommandType		sndCmd;

	// By this time, we should have been initialized
	ErrFatalDisplayIf( !gP, "snd mgr not init" );


	if ( beepID == sndAlarm )
		{
		PrvPlayAlarmSound();
		return;
		}

	// Set up common parameters
	sndCmd.cmd = sndCmdFrqOn;
	sndCmd.param3 = gP->sysAmp;		// default to system sound amplitude
	
	switch ( beepID )
		{
		case sndClick:
			sndCmd.param1 = sndClickFreq;
			sndCmd.param2 = sndClickDurationMSec;
			break;

		case sndInfo:
			sndCmd.param1 = sndInfoFreq;
			sndCmd.param2 = sndBeepDurationMSec;
			break;

		case sndWarning:
			sndCmd.param1 = sndWarningFreq;
			sndCmd.param2 = sndBeepDurationMSec;
			break;

		case sndError:
			sndCmd.param1 = sndErrorFreq;
			sndCmd.param2 = sndBeepDurationMSec;
			break;

		case sndStartUp:
			sndCmd.param1 = sndStartUpFreq;
			sndCmd.param2 = sndBeepDurationMSec;
			break;

		case sndConfirmation:
			sndCmd.param1 = sndConfirmationFreq;
			sndCmd.param2 = sndConfirmationDurationMSec;
			break;

		default:							// unhandled beep ID
			ErrNonFatalDisplayIf(true, "bad sys sound id" );
			break;
		}
	
	SndDoCmd( 0, &sndCmd, true/*noWait*/ );
}



//-------------------------------------------------------------------
//		Sound Manager private routines
//-------------------------------------------------------------------


/************************************************************
 * FUNCTION: PrvPlayAlarmSound
 *
 * DESCRIPTION: Plays the alaram sound
 *
 * PARAMETERS:	none
 *
 * RETURNS:		nothing
 *
 * CREATED: 9/19/95
 *
 * BY: Vitaly Kruglikov
 *
 *************************************************************/
static void PrvPlayAlarmSound(void)
{
	SndGlobalsPtr		gP = (SndGlobalsPtr)GSndGlobalsP;
	SndCommandType		sndCmd;
	UInt					i;
	
	// DOLATER... define the real alarm sound

	// Initialize once
	sndCmd.param3 = gP->alarmAmp;
	sndCmd.cmd = sndCmdFreqDurationAmp;


	i = 0;
	do {
		sndCmd.param1 = 2400;	// Hz
		sndCmd.param2 = 100;		// msec
		SndDoCmd( 0, &sndCmd, true/*noWait*/ );
	
		sndCmd.param1 = 2000;	// Hz
		sndCmd.param2 = 400;		// msec
		SndDoCmd( 0, &sndCmd, true/*noWait*/ );
		
		if ( i > 1 )
			break;
			
		SysTaskDelay( (ULong)150 * sysTicksPerSecond / 1000 );
		
		i++;
		}
	while( true );
}

/*********************************************************************************
 *  FUNCTION: PrvAmpMappings
 *
 *  DESCRIPTION:	Amplitude mappings for native sound generation.  Maps values 0-64
 *
 *  PARAMETERS:	none
 *
 *  RETURNS: 		nothing
 *
 *  CREATED: 2/1/98
 *
 *  BY: Vitaly Kruglikov
 *
 *
 *********************************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
static void asm PrvAmpMappings(void)
{
DC.B	0
DC.B	1, 1, 1, 1, 1, 1, 1, 1
DC.B	1, 1, 1, 1, 2, 2, 2, 2
DC.B	2, 2, 2, 2, 3, 3, 3, 3
DC.B	3, 3, 3, 3, 4, 4, 4, 4
DC.B	5, 5, 5, 5, 6, 6, 6, 6
DC.B	16, 16, 16, 16, 16, 16, 16, 16
DC.B	32, 32, 32, 32, 32, 32, 32, 32
DC.B	48, 48, 48, 48, 64, 64, 64, 64
}
#endif

/*********************************************************************************
 *  FUNCTION: ISndFrqOn
 *
 *  DESCRIPTION:	Internal low-level routine to turns on a sound of the given frequency and
 *						relative amplitude.
 *
 *  PARAMETERS:	dwFrq			-- desired frequency in Hz
 *						wAmp			-- amplitude (0 - sndMaxAmp)
 *
 *  RETURNS: true if the sound is being played; false if the sound is off (amplitude = 0)
 *
 *  CREATED: 8/6/97
 *
 *  BY: Vitaly Kruglikov
 *
 *		vmk	9/4/97	Fixed to prevent period overflow at lower frequencies and disabled
 *							halving the period
 *
 *********************************************************************************/
#define prvFirstRangeSysClockDivider				256
#define prvFirstRangePWMControlDivSelector		hwr328PWMControlDivBy256

#define prvSecondRangeStartFrq						200L		// in hz
#define prvSecondRangeSysClockDivider				4
#define prvSecondRangePWMControlDivSelector		hwr328PWMControlDivBy4

Boolean ISndFrqOn(DWord dwFrq, Word wAmp)
{
	SndGlobalsPtr		gP = (SndGlobalsPtr)GSndGlobalsP;
	register DWord		dwAmpProduct;

	#if EMULATION_LEVEL == EMULATION_NONE
		register HwrDBallPtr		baseP = (HwrDBallPtr)hwr68328Base;
		Word							period;
		Word							wWidth;
		DWord							dwClkDivider;
		Word							wPWMDivSelector;
		BytePtr						ampMappings	= (BytePtr)PrvAmpMappings;		// Amplitude mappings
	#endif

	ErrNonFatalDisplayIf( !gP, "snd mgr not init" );

		
		
	// Compute product of the master and relative amplitudes (we will need it later)
	#if EMULATION_LEVEL == EMULATION_NONE
	dwAmpProduct = (DWord)gP->defAmp * ampMappings[wAmp];
	#else
	dwAmpProduct = (DWord)gP->defAmp * wAmp;
	#endif
		
	// If the amplitude product is zero or the frequency is zero,
	// turn off current sound and return
	if ( !dwAmpProduct || !dwFrq )
		{
		ISndSoundOff();
		return false;
		}
		
		
	#if EMULATION_LEVEL == EMULATION_NONE
		
		// Initialize the sound state
		
		// Select a PWM prescaler divider based on the passed frequency
		// At our current CPU clock speed of 16,580,608, we need a divider
		// of at least 256 for very low frequencies to prevent period overflow.
		// However, for larger frequencies, we get better resolution with
		// a smaller divider
		if ( dwFrq < prvSecondRangeStartFrq )
			{
			dwClkDivider = prvFirstRangeSysClockDivider;
			wPWMDivSelector = prvFirstRangePWMControlDivSelector;
			}
		else
			{
			dwClkDivider = prvSecondRangeSysClockDivider;
			wPWMDivSelector = prvSecondRangePWMControlDivSelector;
			}
		
		// Compute the PWM period -- this is the clock input to the PWM
		// divided by the desired output frequency.
		period = GSysClockFreq / (dwClkDivider * dwFrq);
		
		// This was a bug fix for earlier versions of the Dragonball (68328) processor
		// DOLATER... we probably need to make this conditional for upgrade card support
		// vmk 9/3/97 - commented out
		period >>= 1;			// SCL: Re-enabled 1/19/98, so 3.0 sounds like 2.0
		

		//
		// Initialize and start the PWM
		//

		// Mask the PWM interrupt: we will be using the polling method
		baseP->intMaskLo |= hwr328IntLoPWM;

		// Set the prescaler to divide by 2
		baseP->pwmControl = wPWMDivSelector;
		
		// Set the period register
		baseP->pwmPeriod = period;
		
		// Set the width register: scale one half period by the system
		// default and passed amplitudes
		wWidth = (Word)(((ULong)period * dwAmpProduct) /
				(sndMaxAmp * sndMaxAmp * 2L));
		
		// Adjust width for spike frequencies.
		// DOLATER... this is a hack for now -- will need something
		// more intelligent 12/8/97
		if ( dwAmpProduct < ((DWord)sndMaxAmp * (DWord)sndMaxAmp) )
			{
			if ( dwFrq > 630 && dwFrq < 670 )
				wWidth -= (Word)(wWidth / 10);						// decrease by 10 %
			else
			if ( dwFrq > 930 && dwFrq < 970 )
				wWidth -= (Word)((DWord)wWidth * 9 / 100);		// decrease by 9 %
			else
			if ( dwFrq > 1400 && dwFrq < 1610 )
				wWidth -= (Word)((DWord)wWidth * 9 / 100);		// decrease by 9 %
			else
			if ( dwFrq > 3100 && dwFrq < 3300 )
				wWidth -= (Word)((DWord)wWidth * 8 / 100);		// decrease by 8 %
			else
			if ( dwFrq > 3600 && dwFrq < 4800 )
				wWidth -= (Word)((DWord)wWidth * 15 / 100);		// decrease by 15 %
			}

		if ( wWidth == 0 )					// make sure it is non-zero
			wWidth = 1;
		
		baseP->pwmWidth = wWidth;
		
		// Force the width and period reigisters to be loaded now
		baseP->pwmControl |= hwr328PWMControlLoad;
		
		// Enable the PWM -- this starts a new cycle and immediately generates
		// an interrupt( if we're in interrupt mode) so that the next sample can be loaded
		baseP->pwmControl |= hwr328PWMControlEnable;
		

		// WORK AROUND A HARDWARE BUG WHICH
		// PREVENTS THE ROLLOVER IRQ FROM BEING SET
		// MORE THAN ONCE.
		// ***SINCE WE'RE NOT COUNTING ROLLOVER IRQ'S IN THIS IMPLEMENTATION,
		// WE DON'T NEED THIS WORKAROUND***
		//baseP->pwmControl &= ~hwr328PWMControlLoad;
		
		return true;
		
	#else		// EMULATION_LEVEL != EMULATION_NONE

		StubSndCommand(0/*channelP*/, 0,
						stubSndCmdFrqOn, dwFrq,
						0, dwAmpProduct / sndMaxAmp, false);

		return true;

	#endif	// EMULATION_LEVEL == EMULATION_NONE
	
}


/*********************************************************************************
 *  FUNCTION: ISndSoundOff
 *
 *  DESCRIPTION:	Internal low-level routine to turn off sound
 *
 *		***IMPORTANT***
 *
 *			***This function is called from a timer proc, and is not allowed to block
 *			***directly or indirectly.
 *
 *  PARAMETERS:	none
 *
 *  RETURNS: nothing
 *
 *  CREATED: 8/6/97
 *
 *  BY: Vitaly Kruglikov
 *
 *********************************************************************************/
void ISndSoundOff(void)
{
	#if EMULATION_LEVEL == EMULATION_NONE
		register HwrDBallPtr		baseP = (HwrDBallPtr)hwr68328Base;
		
		// Disable the PWM
		baseP->pwmControl &= ~hwr328PWMControlEnable;
	#else		// EMULATION_LEVEL != EMULATION_NONE
		StubSndCommand(0/*channelP*/, 0,
						stubSndCmdQuiet, 0,
						0, 0, false);
	#endif	// EMULATION_LEVEL == EMULATION_NONE

	// Disable the "sound off" countdown
	prvStopSoundOffCountdown(((SndGlobalsPtr)GSndGlobalsP));

}



/*********************************************************************************
 *  FUNCTION: PrvDoFreqDurationAmp
 *
 *  DESCRIPTION:	Plays a sound of the given frequency, amplitude, and duration.
 *
 *  PARAMETERS:	param1		-- desired frequency in Hz
 *						param2		-- duration in milliseconds
 *						param3		-- amplitude (0 - sndMaxAmp)
 *
 *  RETURNS: nothing
 *
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			vmk	8/28/95	Initial version
 *			tlw	2/4/98	If client asks for sound and waitTicks == 0, use 1
 *
 *********************************************************************************/
static void PrvDoFreqDurationAmp(SndCommandPtr cmdP)
{
	ULong				waitTicks;


	// Stop the "sound kill" countdown to make sure our sound will not be
	// killed before it is finished
	prvStopSoundOffCountdown(((SndGlobalsPtr)GSndGlobalsP));					
	
	
	// Turn on the sound
	if ( !ISndFrqOn(cmdP->param1, cmdP->param3) )
		return;													// return immediately if the sound is off
	
	// Compute the sound duration in ticks
	waitTicks = sndMilliSecToPilotTicks(cmdP->param2);
	
	// If user wanted some sound then give them the minimum (vs no sound)
	if (cmdP->param2 && !waitTicks)
		waitTicks = 1;

	// Wait while sound plays
	if ( waitTicks )
		SysTaskDelay( waitTicks );
	
	// Disable the PWM
	ISndSoundOff();
}





// timer used only under emulation
#if EMULATION_LEVEL != EMULATION_NONE
/***********************************************************************
 *
 * FUNCTION:    PrvSoundKillTimerProc
 *
 * DESCRIPTION:	Turns off the current sound.
 *
 *						This timer procedure gets called by AMX when the 
 *						Tickle timer expires. Because timer procedures run in
 *						their own context, we can not call any blocking routines
 *						from here.
 *
 *
 * CALLED BY:	 AMX when timer expires (used under emulation mode only)
 *						
 *
 * PARAMETERS:  timerID - id of timer
 *					 param 	- sound manager globals (SndGlobalsPtr)
 *
 * RETURNED:    nothing
 *
 * COMMENTS:	This timer is used under emulation mode on.  On the handheld,
 *		this functionality is accomplished from the timer tick interrupt handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			vmk	8/13/97	Initial version
 *
 ***********************************************************************/
static void PrvSoundKillTimerProc(Long timerID, Long param) 
{
	// Turn sound off
	ISndSoundOff();
}
#endif // EMULATION_LEVEL != EMULATION_NONE
