/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------  
 * FileName:
 *		SysEvtMgr.c
 *
 * Description:
 *		Low-Level System Event Manager Routines
 *
 * History:
 *   	3/22/95  RM - Created by Ron Marianetti
 *
 *******************************************************************/  


#include <Pilot.h>
#include <SysEvtMgr.h>
#include <EmuStubs.h>
#include <PenMgr.h>
#include <Graffiti.h>
#include <ScrDriver.h>

#define	NON_PORTABLE
#include <SystemPrv.h>
#include <KeyPrv.h>
#include <Hardware.h>
#include <SysEvtPrv.h>
#include <TimePrv.h>
#include <SystemPkt.h>

#include <ExgLib.h>


/************************************************************
 * Private routines used only in this module
 *************************************************************/
static Err		PrvEnqueueKeyBytes(KeyQueuePtr keyQP, BytePtr dataP, UInt size);
static Err		PrvPeekStrokeStart(PointType* startPtP);
static Err 		PrvSendGremlinsIdle (void);
static Boolean PrvHandleExchangeEvents();


/************************************************************
 *
 *  FUNCTION: EvtSysInit
 *
 *  DESCRIPTION: Initializes the system event manager
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nothing
 * 
 *  CALLED BY: System startup code
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	EvtSysInit(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	BytePtr				cP;
	Ptr					p;
	Err					err;
	Int					i;
	DWord					tag = 'EvtM';
	UInt					timeout;
	DWord					autoOffDuration;
	
	//----------------------------------------------------------------------
	// Allocate the globals  and initialize them
	//----------------------------------------------------------------------
	if (gP) MemPtrFree(gP);
	GSysEvtMgrGlobalsP = MemPtrNew(sizeof(SysEvtMgrGlobalsType));
	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	if (!gP) {
		ErrDisplay("Couldn't alloc event mgr globals");
		return memErrNotEnoughSpace;
		}
	
	// Initialize them to 0
	cP = (BytePtr)gP;
	for (i=0; i<sizeof(SysEvtMgrGlobalsType); i++) {
		*cP++ = 0;
		}
		
	// Initialize them	
	gP->enableGraffiti = true;
	gP->enableSoftKeys = true;
	
	RctSetRectangle(&gP->writingR, hwrGraffitiLeft, hwrGraffitiTop, 
							hwrGraffitiWidth, hwrGraffitiHeight);  
	gP->appAreaBottom = hwrDisplayHeight;

	
	//----------------------------------------------------------------------
	// Create the Event Group. This event group serves a dual purpose. Bit
	//  sysRefnumStd (0) is used to block on hardware events like pen
	//  and keyboard. Other bits (1->15 and 17-31) are used to implement
	//  the SysSelect() call for use by applications that want to pend on
	//  socket activity in the Net Library. 
	//----------------------------------------------------------------------
	err = SysEvGroupCreate(&GSysEvGroupID, &tag, 0);
	if (err) DbgBreak();
	
	
	//----------------------------------------------------------------------
	// Allocate the default pen and keyboard queues
	//----------------------------------------------------------------------
	p = MemPtrNew(evtDefaultPenQSize);
	ErrFatalDisplayIf(!p, "Couldn't alloc pen q");
	MemSet(p, evtDefaultPenQSize, 0);
	err = EvtSetPenQueuePtr(p, evtDefaultPenQSize);
	ErrFatalDisplayIf(err, "Err setting pen q ptr");
	
	p = MemPtrNew(evtDefaultKeyQSize);
	ErrFatalDisplayIf(!p, "Couldn't alloc key q");
	MemSet(p, evtDefaultKeyQSize, 0);
	err = EvtSetKeyQueuePtr(p, evtDefaultKeyQSize);
	ErrFatalDisplayIf(err, "Err setting key q ptr");
	
	
	//----------------------------------------------------------------------
	// Init the auto-off timeout in seconds. Get this from the
	//  Preferences database
	//----------------------------------------------------------------------
	autoOffDuration = PrefGetPreference(prefAutoOffDuration);
	
	// Validate the timeout stored in preferences. A timeout of forever is
	//  encoded as 0xFF in the preferences database.
	if (autoOffDuration == 0xFF) timeout = 0;
	else timeout = autoOffDuration * 60;
	SysSetAutoOffTime(timeout);


	return err;
}


/************************************************************
 *
 *  FUNCTION: EvtGetSysEvent
 *
 *  DESCRIPTION: Checks for low level system events and fills in
 *		event record pointer with event information if an event is
 *		available. If no events are available, this routine will put
 *		the system to sleep and not return until an event is available.
 *
 *		Low level system events are events that are caused by hardware
 *		 - like key presses or pen strokes on the digitizer.
 *
 *		If the event is a pen-up in the Graffiti area, this routine will
 *		pass the stroke to the Graffiti recognizer and return a key event
 *		to the caller. 
 *
 *		If the event is pen-up in a hard icon, this routine will determine
 *		which hard icon was pressed and return a key event with the appropriate
 *		virtual key code.
 *
 *		If none of the above and the pen is still down, this routine will
 *		return a pen down event with the current pen location.
 *
 *		If none of the above, this routine will put the processor to sleep.
 *
 *  PARAMETERS: 
 *		eventP	 	- pointer to event record to fill in
 *		timeout 		- max time to put processor to sleep. -1 means wait forever.
 *
 *  RETURNS: nothing
 * 
 *  CALLED BY: 
 *
 *  CREATED: 3/22/95
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	6/29/95	added timeout parameter to StubProcessMacEvents
 *			vmk	9/11/95	added a call to AlmDisplayAlarm()
 *			vmk	9/12/95	added emulator timer alarm simulation logic
 *			gmp   1/31/98	added exchange manager event handling
 *
 *************************************************************/
void	EvtGetSysEvent(EventPtr eventP, Long timeout)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	PenQueuePtr				penQP;
	PointType				startPt, endPt; 
	Boolean					sendPenUpToApp = false;
	Boolean					returnNullEvt=false;
	PointType				rawPen;
	Err 						err;


	//------------------------------------------------------------------
	// If Running under the emulator, give the host system software a chance
	//  to post keyboard and pen events -- the MAC wants the timeout ticks
	//  with same semantics as passed to EvtGetSysEvent() -- so we make
	//  this call before the timeout conversion.
	//
	// Note that this is done even if data exists on the pen or key queue.
	//--------------------------------------------------------------------
	#if EMULATION_LEVEL != EMULATION_NONE
	StubProcessMacEvents(timeout);
	#endif


	// If timeout is infinite, the kernel wants 0
	// If timeout is none (0) the kernel wants -1
	if (timeout < 0) timeout = 0;
	else if (timeout == 0) timeout = -1;
	
	
	//------------------------------------------------------------------------
	// See if we need to remove the top stroke from the pen queue. This is
	//  necessary when we have previously returned a pen-up event to the
	//  application. We remove the stroke for the application if it didn't
	//  do so itself.
	//----------------------------------------------------------------------
	penQP = gP->penQP;
	if (gP->removeTopStroke) {
		if (gP->penQStrokesRemoved == penQP->strokesRemoved)
			EvtFlushNextPenStroke();
		gP->removeTopStroke = false;
		}
		
	
	//------------------------------------------------------------------------
	// Assume there is no low level event by clearing the stdin event flag.
	//  If there really is one pending, we'll find out in our while loop which
	//  looks at both the Key and Pen queues to see if they have anything in
	//  them. 
	// If a low level event occurs soon after we're done checking the pen and
	//  key queues, the  appropriate ISR will set the event flag for us and 
	//  we'll return immediately from SysEvWait().
	//------------------------------------------------------------------------
	SysEvGroupSignal(GSysEvGroupID, 
				sysEvtGroupMask(sysFileDescStdIn,false),		// mask
				0,														// value
				sysEvGroupSignalConstant);						// type



	while (1) {
	
		//------------------------------------------------------------------------
		// Check for and handle any exhange manager events
		//------------------------------------------------------------------------
		PrvHandleExchangeEvents();
		
		//------------------------------------------------------------------------
		// Do we need to send the dirty area of the screen to the host?
		//------------------------------------------------------------------------
		if (gP->needRemoteScrUpdate) {
			gP->needRemoteScrUpdate = false;
			ScrSendUpdateArea(false);
			}


		//------------------------------------------------------------------------
		// Is there a pending key event to return? If so, return it
		//------------------------------------------------------------------------
		if (!EvtDequeueKeyEvent(eventP, false)) goto Exit;
	
		
		//------------------------------------------------------------------------
		// Is there anything in the pen queue? If so we need to return a 
		//  penDown, penUp, or penMoved event.
		//----------------------------------------------------------------------
		if (penQP->end != penQP->start) {
		
			// Capture the current pen condition.
			rawPen.x = gP->penX;
			rawPen.y = gP->penY;
			eventP->penDown = gP->penDown;
			
			//------------------------------------------------------------------------
			// Did we return the penDown event yet? If not, return it even if the pen
			//  is not currently down. This is so we still get the correct event flow
			//  if the pen is rapidly brought down and up again.
			//----------------------------------------------------------------------
			if (!penQP->returnedPenDown) {
				eventP->eType = penDownEvent;
				
				// get the location of the pen down and return the pen-down event
				PrvPeekStrokeStart(&rawPen);
				eventP->penDown = true;
				penQP->returnedPenDown = true;
				goto ExitWithPenInfo;
				}
	
	
			//------------------------------------------------------------------------
			// Is there a complete stroke available???
			// If so, get the end points into the event record and return a pen-up
			//   event to the app.
			//----------------------------------------------------------------------
			else if (penQP->strokeCount) {
			
				// Get the stroke info
				EvtDequeuePenStrokeInfo(&startPt, &endPt);
				
				// Save it in event record
				eventP->data.penUp.start = startPt;
				eventP->data.penUp.end = endPt;
				eventP->eType = penUpEvent;
				
				// Save the current value of the number of strokes removed from the
				//  pen queue so that we can detect whether or not the application removed
				//  the stroke from the queue itself.
				gP->penQStrokesRemoved = penQP->strokesRemoved;
				gP->removeTopStroke = true;
				penQP->returnedPenDown = false;
				goto ExitWithPenInfo;
				}

			//------------------------------------------------------------------------
			// Is the pen down? If so and the coordinates have changed, 
			//  return a pen moved event with the current coordinates of the pen
			//
			// If the pen hasn't moved, fall through and go to sleep
			//------------------------------------------------------------------------
			else if (eventP->penDown && gP->lastPenDown) {
				eventP->eType = penMoveEvent;
				if ((rawPen.x != gP->lastPenX) || (rawPen.y != gP->lastPenY)) 
					goto ExitWithPenInfo;
				}
					
			}
			

		//------------------------------------------------------------------------
		// Call the Alarm Manager to process any alarms which have expired and reschedule
		// new alarms, but do not display them at this time.  Alarms will be displayed
		// after the UI is notified via the alarmChr virtual key event.
		//------------------------------------------------------------------------
		AlmDisplayAlarm( false/*displayOnly*/ );
		
		
		
			
		//------------------------------------------------------------------------
		// If we got to here, there's nothing to do, so pend on our event group for
		//   a "stdin" event (pen or key).
		//------------------------------------------------------------------------
		
		// This stuff only necessary for the Emulator
		#if EMULATION_LEVEL != EMULATION_NONE
			// Simulate time manager's alarm functionality for the emulator.
			// vmk 9/12/95	11:39am
			TimHandleInterrupt( false/*periodicUpdate*/);

			// Give time to the Key Manager so that it can simulate a hardware keyUp
			// if necessary
			KeyHandleInterrupt(true, 0);


			// Notify the emulator in case it wants to substitue an event for the nil event.
			// If the emulator wants to send a pen or key event it will enqueue it and
			// return true.  We must then continue in this while loop to pull the data 
			// off whatever queue it was added to and send it as an event
			{
				register StubNilEventIsPendingResults result;
				
				result = StubNilEventIsPending();
				if (result == emuSendPenOrKeyEvent)
					// When the loop continues the event posted will be pulled off one
					// of the two queues and sent on it's way
					continue;
				else if (result == emuSendNilEvent)
					{
					// set the event to a nilEvent and leave with it
					eventP->eType = nilEvent;
					goto Exit;
					}
					
				// At this point neither gremlins or the script playback code posted
				// an event. SysEvGroupWait is free to block the emulator until input
				// if it so wants.

			}
				

		#endif	
		
		
		// Wait for a key or pen event to set our event group flag
		//  This flag will be set after a hardware event is detected by an interrupt 
		//  routine. 
		gP->idle = true;
		err = SysEvGroupWait(GSysEvGroupID, 
					sysEvtGroupMask(sysFileDescStdIn,false),		// mask
					sysEvtGroupMask(sysFileDescStdIn,false),		// value
					sysEvGroupWaitOR,									// match type
					timeout);
		gP->idle = false;
		
		
		// We'll assume the error is a timeout, in which case we just need to return
		//   a null event.
		if (err) {
			eventP->eType = nilEvent;
			goto Exit;
			}

		
		
		//------------------------------------------------------------------------
		// Are we supposed to send a null event as requested by EvtWakeup??
		//------------------------------------------------------------------------
		if (gP->sendNullEvent) {
			gP->sendNullEvent = 0;
			eventP->eType = nilEvent;
			goto Exit;
			}
			

		} // while(1);
	
	

	//------------------------------------------------------------------------
	// Fill in current pen info and exit with event record.
	//------------------------------------------------------------------------
Exit:
		// Capture the current pen condition.
		rawPen.x = gP->penX;
		rawPen.y = gP->penY;
		eventP->penDown = gP->penDown;
			
ExitWithPenInfo:
		// Save last pen position so we can detect penMove events next time we're called
		gP->lastPenDown = eventP->penDown;
		gP->lastPenX = rawPen.x;
		gP->lastPenY = rawPen.y;
		
		// Convert raw digitizer location to screen coordinates
		PenRawToScreen(&rawPen);
		eventP->screenX = rawPen.x;
		eventP->screenY = rawPen.y;
		
	return;
}



/************************************************************
 *
 *  FUNCTION: EvtSysEventAvail
 *
 *  DESCRIPTION: Returns true if a low level system event like a
 *		pen or key event is available.
 *   
 *  PARAMETERS: 
 *		ignorePenUps - if true, this routine will ignore pen-up events
 *			when determining if there are any system events available.
 *		
 *  RETURNS: true if event available
 * 
 *  CALLED BY: EvtEventAvail if no high level software events are 
 *			available.
 *
 *  CREATED: 4/29/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean				EvtSysEventAvail(Boolean ignorePenUps)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	PenQueuePtr				penQP;
	KeyQueuePtr				keyQP;
	
	
	// Are there any keys in the queue???
	keyQP = gP->keyQP;
	if (keyQP->start != keyQP->end) return true;
	
	
	// If we are ignore pen-ups, the logic to determine if there is a
	//  pen event is more complicated...
	penQP = gP->penQP;
	if (ignorePenUps) {
		// If there's data in the queue and we haven't returned a pen down yet,
		//  we definitely have an event
		if (penQP->end != penQP->start && !penQP->returnedPenDown) return true;
		
		// OR, If there's at least 2 stroke starts in the queue, we have a pen
		// down event to return still. This is a case where returnedPenDown can
		//  be true (which gets past the above test) if we haven't finished
		//  returning the first stroke to the app yet. 
		if (penQP->strokesAdded > penQP->strokesRemoved+1) return true;
		}
		
		// Any pen events available? 
	else if (penQP->end != penQP->start) {
		 return true;
		}
	else 	// check for exchange manager events
		if (GSysMiscFlags & sysMiscFlagExgEvent) {
		return true;
		}
	
	return false;
}






/************************************************************
 *
 *  FUNCTION: EvtProcessSoftKeyStroke()
 *
 *  DESCRIPTION: Translate a stroke in the system area of the digitizer
 *		and enqueue the appropriate key events into the key queue.
 *
 *  PARAMETERS: 
 *		*startPtP - start point of stroke
 *		*endPtP	 - end point of stroke
 *
 *  RETURNS: 0 if recognized
 * 
 *  CALLED BY: EvtGetSysEvent
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err EvtProcessSoftKeyStroke(PointType* startPtP, PointType* endPtP)
{
	PenBtnInfoPtr			infoP;
	UInt						i, numButtons;
	Err						err = -1;

	// Check for hit in one of the silk screen buttons
	infoP = EvtGetPenBtnList(&numButtons);
	
	for (i=0; i<numButtons; i++) {
		if (RctPtInRectangle(startPtP->x, startPtP->y, &infoP->boundsR)) {
			if (RctPtInRectangle(endPtP->x, endPtP->y, &infoP->boundsR)) {
				EvtEnqueueKey(infoP->asciiCode, infoP->keyCode, infoP->modifiers);
				err = 0;
				break;
				}
			}
		
		infoP++;
		}
		
	// Flush the stroke out 
	EvtFlushNextPenStroke();
		
	return err;
}


/************************************************************
 *
 *  FUNCTION: EvtPenBtnList
 *
 *  DESCRIPTION: Returns pointer to the silk screen button 
 *   array. This array contains the bounds of each silk screen
 *	  button and the ascii code and modifiers byte to generate
 *	  for each button.
 *
 *  PARAMETERS: none
 *
 *  RETURNS: pointer to array, # of elements
 * 
 *  CALLED BY: 
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *  COMMENTS: This info should probably go into a resource....
 *
 *************************************************************/
PenBtnInfoPtr	asm EvtGetPenBtnList(UIntPtr numButtons) 
{
		fralloc+
	
		MOVE.L	numButtons, A0
		MOVE.W	#4, (A0)					// return numButtons
		
		LEA		@List, A0				// return list
		frfree
		RTS
		
@List:
		// Menu Button
		DC.W		hwrMenuBtnLeft, hwrMenuBtnTop				// left, top, 
		DC.W		hwrMenuBtnWidth, hwrMenuBtnHeight		//	width, height
		DC.W		menuChr											// ascii code
		DC.W		0													// virtual key code (not used yet)
		DC.W		commandKeyMask									// modifiers
		
		// Launch Button
		DC.W		hwrLaunchBtnLeft, hwrLaunchBtnTop		// left, top, 
		DC.W		hwrLaunchBtnWidth, hwrLaunchBtnHeight	//	width, height		
		DC.W		launchChr										// ascii code
		DC.W		0													// virtual key code (not used yet)
		DC.W		commandKeyMask									// modifiers
		
		// Calculator Button
		DC.W		hwrCalcBtnLeft, hwrCalcBtnTop				// left, top, 
		DC.W		hwrCalcBtnWidth, hwrCalcBtnHeight		//	width, height		
		DC.W		calcChr											// ascii code
		DC.W		0													// virtual key code (not used yet)
		DC.W		commandKeyMask									// modifiers
		
		// Find Button
		DC.W		hwrFindBtnLeft, hwrFindBtnTop				// left, top, 
		DC.W		hwrFindBtnWidth, hwrFindBtnHeight		//	width, height	
		DC.W		findChr											// ascii code
		DC.W		0													// virtual key code (not used yet)
		DC.W		commandKeyMask									// modifiers
		
}




/************************************************************
 *
 *  FUNCTION: EvtSetPenQueuePtr
 *
 *  DESCRIPTION: Replaces the current pen queue with another
 *		and initializes it.
 *
 *  PARAMETERS: 
 *		penQueueP 	- pointer to new area of memory to use as pen queue
 *		size 			- size of area in bytes.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Applications that wish to install a larger or smaller pen
 *		queue.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtSetPenQueuePtr(Ptr qSpaceP, ULong size)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	Word						status;


	// Check for a minimum size
	if (size < sizeof(PenQueueType) + 10)
		return sysErrParamErr;
		

	// Interrupts off while we replace the queue
	status = SysDisableInts();
	
	
	// Now, get rid of the old one and plug in the new one
	if (gP->penQP) {
		MemPtrFree(gP->penQP);
		gP->penQP = 0;
		}
	
	// Plug in the new one - the only field we need to initialize is the size
	gP->penQP = (PenQueuePtr)qSpaceP;
	gP->penQP->size = size - sizeof(PenQueueType);
	
	// Init the new queue
	EvtFlushPenQueue();
	
	// Restore interrupts
	SysRestoreStatus(status);
	
	return 0;
}



/************************************************************
 *
 *  FUNCTION: EvtFlushPenQueue
 *
 *  DESCRIPTION: Flushes all points out of the pen queue
 *
 *  PARAMETERS: 
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Hopefully nobody
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtFlushPenQueue(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	PenQueuePtr				penQP = gP->penQP;
	Word						status;

	
	// Interrupts off while we muck with the queue header
	status = SysDisableInts();
	
	
	// Initialize the queue
	penQP->start = 0;
	penQP->end = 0;
	
	penQP->strokeCount = 0;
	penQP->returnedPenDown = false;

	penQP->addLast.x = -1;
	penQP->addLast.y = -1;
	penQP->addStrokeStart = -1;
	
	penQP->strokesRemoved = 0;
	penQP->strokesAdded = 0;
	penQP->rmvStrokeStage = -1;
	
	
	// Update main globals
	gP->removeTopStroke = false;


	// Restore interrupts
	SysRestoreStatus(status);
	
#if EMULATION_LEVEL != EMULATION_NONE
	//	This will wipe out the events in the Mac event queue, which would 
	//	otherwise be fed back into the TD pen queue, and hence, the TD
	//	event queue.
	StubFlushEvents ();
#endif	// EMULATION_LEVEL != EMULATION_NONE
	
	return 0;
}




/************************************************************
 *
 *  FUNCTION: EvtPenQueueSize
 *
 *  DESCRIPTION: Returns the size of the current pen queue in bytes. 
 *
 *  PARAMETERS: none
 *
 *  RETURNS: size of queue in bytes
 * 
 *  CALLED BY: Applications that wish to see how large the current pen queue is.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
ULong				EvtPenQueueSize(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
		
	// Get the size
	return (gP->penQP->size + sizeof(PenQueueType));
}




/************************************************************
 *
 *  FUNCTION: EvtEnqueuePenPoint
 *
 *  DESCRIPTION: Called by the digitizer interrupt routine to enqueue
 *   a pen coordinate into the pen queue. The data in the pen queue is
 *   stored in compressed format as follows:
 *
 *    Stroke start point x (2 bytes)
 *    Stroke start point y (2 bytes)
 *    Stroke end point x   (2 bytes)
 *    Stroke end point y   (2 bytes)
 *		StrokePoints 			(variable size bytes)
 *    
 *  The StrokePoints (which is always terminated with the byte 0x00), are 
 *		stored as follows. Note that the  start and end points of the stroke
 *    are NOT included in the StrokePoints array. The StrokePoints array
 *    can contain no points in which case it will contain only the terminator 
 *    byte (0x00).
 *
 *		if (-3 >= dx <= 3)  && (-7 >= dy <= 7)
 *        0XXXYYYY				<- single byte where XXX is dx and YYY is dy
 *
 *    else if (-63 >= dx <= 63) && (-127 >= dy <= 127)
 *        1XXXXXXX  YYYYYYYY  <- 2 bytes where XXXXXXX is dx and YYYYYYYY is dy
 *
 *		else
 *			 11000000  XXXXXXXX XXXXXXXX YYYYYYYY YYYYYYYY
 *										<- 5 bytes where XXXXXXX XXXXXXX is the x coordinate
 *											and YYYYYYYY YYYYYYYY is the y coordinate.
 *	   else
 *        00000000  end of StrokePoints.
 *
 *
 *  PARAMETERS: 
 *		x - x coordinate of penpoint, or -1 for pen-up
 *		
 *
 *  RETURNS: size of queue in bytes
 * 
 *  CALLED BY: Applications that wish to see how large the current pen queue is.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtEnqueuePenPoint(PointType* ptParmP)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register PenQueuePtr	penQP = gP->penQP;
	register BytePtr		dataP;
	Int						roomLeft;
	register Int			size;
	Int						dx, dy, absDx, absDy;
	Int						end, max;
	register PointType*	ptP;
	
	
	// Make sure we've been initialized
	if (!gP) return evtErrParamErr;
	
	// Check for nil pen queue
	penQP = gP->penQP;
	if (!penQP) return evtErrParamErr;
	ptP = ptParmP;
	
	
	// Check for out of bounds...
	#if EMULATION_LEVEL != EMULATION_NONE
	if (	ptP->x < -1 || 
			ptP->x > 1000 || 
			ptP->y < -1 || 
			ptP->y > 1000)
		ErrDisplay("Invalid Point passed");
	#endif
	
	
	// Save current pen coordinates in SysEvtMgr globals
	if (ptP->x >= 0) {
		gP->penX = ptP->x;
		gP->penY = ptP->y;
		gP->penDown = true;
		}
	else
		gP->penDown = false;
	
	
	// If this point is the same as the last one, ignore it. This will
	//  catch the cases of multiple pen-ups in a row also.
	if (ptP->x == penQP->addLast.x && ptP->y == penQP->addLast.y) return 0;
	
	
	// Reset the key manager double-tap detection
	KeyResetDoubleTap();
	
	
	// Set up queue local variables
	dataP = penQP->data + penQP->end;
	size = penQP->size;
	
		
	// Handle pen-up
	if (ptP->x < 0) {
		if (penQP->addStrokeStart < 0) return 0;		// ignore if no stroke in process
		
		// Terminate the stroke
		*dataP++ = 0;
		if (++penQP->end == size) penQP->end = 0;
		

		// Save last point in stroke info header
		end = penQP->addStrokeStart + 4;
		if (end >= size)  end -= size; 
		dataP = penQP->data + end;
		
		*dataP++ = penQP->addLast.x >> 8;
		if (++end == size) { end = 0; dataP = penQP->data; }
		*dataP++ = penQP->addLast.x;
		if (++end == size) { end = 0; dataP = penQP->data; }
		
		*dataP++ = penQP->addLast.y >> 8;
		if (++end == size) { end = 0; dataP = penQP->data; }
		*dataP++ = penQP->addLast.y;
		if (++end == size) { end = 0; dataP = penQP->data; }
		
		
		// Add 1 to the stroke count and clear the strokeStart.
		penQP->strokeCount++;
		penQP->addStrokeStart = -1;
		penQP->addLast = *ptP;
		
		// Set the Event flag for stdin
		SysEvGroupSignal(GSysEvGroupID, 
					sysEvtGroupMask(sysFileDescStdIn,false),		// mask
					sysEvtGroupMask(sysFileDescStdIn,false),		// value
					sysEvGroupSignalConstant);						// type
		return 0;
		}
	
	
	// Make sure there's room in the queue for the worst case point size of
	//  5 bytes + terminator (possible on next call) + buffer byte
	roomLeft = penQP->start - penQP->end;
	if (roomLeft <= 0) roomLeft += penQP->size;
	if (roomLeft < 7) {
		//ErrNonFatalDisplayIf(1, "QueueFull");
		
		// Set the event flag to wake up the event manager
		SysEvGroupSignal(GSysEvGroupID, 
					sysEvtGroupMask(sysFileDescStdIn,false),		// mask
					sysEvtGroupMask(sysFileDescStdIn,false),		// value
					sysEvGroupSignalConstant);						// type

		
		return evtErrQueueFull;
		}
	
	
	// If this is the start of a stroke, setup the stroke info
	if (penQP->addStrokeStart < 0) {
	
		penQP->addStrokeStart = penQP->end;
		penQP->strokesAdded++;
		
		*dataP++ = ptP->x >> 8;
		if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
		*dataP++ = ptP->x;
		if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
		
		*dataP++ = ptP->y >> 8;
		if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
		*dataP++ = ptP->y;
		if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
		
		dataP += 4;
		penQP->end += 4;
		if (penQP->end >= size)  penQP->end -= size; 
		}
	
	
	// Else, get the delta from the last point and save that in the queue
	else {
		dx = ptP->x - penQP->addLast.x;
		absDx = (dx < 0 ? -dx : dx);
		
		dy = ptP->y - penQP->addLast.y;
		absDy = (dy < 0 ? -dy : dy);
		
		max = absDx | (absDy >> 1);
		
		// 1 byte encoding...
		if ((max & 0xFFFC) == 0 ) {
			*dataP = ((dx << 4) | (dy & 0x0F)) & 0x7F;
			if (++penQP->end == size) { penQP->end = 0; }
			}
			
		// 2 byte encoding...
		else if ((max & 0xFFC0) == 0) {
			*dataP++ = dx | 0x80;
			if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
			*dataP++ = dy;
			if (++penQP->end == size) { penQP->end = 0;}
			}
		
		// 5 byte encoding....
		else {
			*dataP++ = 0xC0;
			if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
			*dataP++ = ptP->x >> 8;
			if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
			*dataP++ = ptP->x;
			if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
			*dataP++ = ptP->y >> 8;
			if (++penQP->end == size) { penQP->end = 0; dataP = penQP->data; }
			*dataP++ = ptP->y;
			if (++penQP->end == size) { penQP->end = 0; }
			}
		}
	
	
	// Save last X and Y
	penQP->addLast = *ptP;
	
	// Record this event to support auto-off 
	GSysAutoOffEvtTicks = GHwrCurTicks;
	
	// Set the Event flag to wake up event manager
	SysEvGroupSignal(GSysEvGroupID, 
				sysEvtGroupMask(sysFileDescStdIn,false),		// mask
				sysEvtGroupMask(sysFileDescStdIn,false),		// value
				sysEvGroupSignalConstant);						// type
	return 0;
}




/************************************************************
 *
 *  FUNCTION: EvtDequeueStrokeInfo
 *
 *  DESCRIPTION: Called to initiate the extraction of a stroke from the
 *   pen queue. This routine MUST be called before calling EvtDequeuePenPoint.
 *   It will return the start and end points of the stroke.
 *
 *   Subsequent calls to EvtDequeuePenPoint will return points starting
 *   at the start point in the stroke and including the end point. After
 *   the end point is returned, the next call to EvtDequeuePenPoint will return
 *   the point -1,-1.
 *   
 *   Refer to the comments on EvtEnqueuePenPoint for a description of how
 *   pen points are compressed in the pen queue.
 *
 *  PARAMETERS: 
 *		*startPtP	- start point returned here
 *		*startPtP	- end point returned here
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: EvtGetSysEvent
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtDequeuePenStrokeInfo(PointType* startPtP, PointType* endPtP)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register PenQueuePtr	penQP;
	register BytePtr		dataP;
	register Int			size;
	
	
	// Set up the queue variables
	penQP = gP->penQP;
	dataP = penQP->data + penQP->start;
	size = penQP->size;
	
	
	// Make sure we're at the start of a stroke extraction
	ErrFatalDisplayIf(penQP->rmvStrokeStage >= 0, "Pen q out of sync");
	ErrFatalDisplayIf(penQP->strokeCount == 0, "Pen q out of sync");
	
	
	// The start point is in the first 4 bytes
	startPtP->x = *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	startPtP->x = (startPtP->x << 8) | *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	
	startPtP->y = *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	startPtP->y = (startPtP->y << 8) | *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	


	// The end point is the next 4 bytes
	endPtP->x = *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	endPtP->x = (endPtP->x << 8) | *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	
	endPtP->y = *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; dataP = penQP->data;}
	endPtP->y = (endPtP->y << 8) | *dataP++;
	if (++(penQP->start) == size) {penQP->start = 0; }
	
	
	// Set stage of removal
	penQP->rmvStrokeStage = 0;
	penQP->strokeCount--;
	
	
	// Save the start point in the pen queue header for the next call to
	//  EvtDequeuPenPoint since it must return the start point first.
	penQP->rmvStartPt = *startPtP;
		
		
	// Convert to screen coordinates before returning
	PenRawToScreen(startPtP);
	PenRawToScreen(endPtP);
	
	
	return 0;
}
		




/************************************************************
 *
 *  FUNCTION: PrvPeekStrokeStart, private
 *
 *  DESCRIPTION: Called to peek at the starting point for the next
 *		stroke to be extracted from the pen queue.
 *
 *   This is called by EvtGetSysEvent when it returns a pen-down event
 *		in order to get the starting point of the stroke. By doing this
 *		we return the correct starting position even if the pen has
 *		subsequently moved or been lifted.
 *
 *  PARAMETERS: 
 *		*startPtP	- start point returned here in RAW COORDINATES!!!!!
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: EvtGetSysEvent
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err			PrvPeekStrokeStart(PointType* startPtP)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register PenQueuePtr	penQP;
	register BytePtr		dataP;
	register Int			size;
	UInt						start;
	
	
	// Set up the queue variables
	penQP = gP->penQP;
	start = penQP->start;
	dataP = penQP->data + start;
	size = penQP->size;
	
	
	// Make sure we have points in the queue
	ErrFatalDisplayIf(penQP->end == start, "Pen q out of sync");

	
	// The start point is in the first 4 bytes
	startPtP->x = *dataP++;
	if (++start == size) {start = 0; dataP = penQP->data;}
	startPtP->x = (startPtP->x << 8) | *dataP++;
	if (++start == size) {start = 0; dataP = penQP->data;}
	
	startPtP->y = *dataP++;
	if (++start == size) {start = 0; dataP = penQP->data;}
	startPtP->y = (startPtP->y << 8) | *dataP++;
	if (++start == size) {start = 0; dataP = penQP->data;}
	

	return 0;
}
		





/************************************************************
 *
 *  FUNCTION: EvtDequeuePenPoint
 *
 *  DESCRIPTION: Called by the recognizers to get the next pen point
 *    out of the pen queue. Will return the point (-1,-1) at the end
 *    of a stroke.
 *   
 *    Refer to the comments on EvtEnqueuePenPoint for a description of how
 *    pen points are compressed in the pen queue.
 *
 *  PARAMETERS: 
 *		*retP	- return point.
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Recognizers that wish to extract the points of a stroke
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtDequeuePenPoint(PointType* retP)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register PenQueuePtr	penQP;
	register BytePtr		dataP;
	register Int			size;
	Byte						byte;
	register SWord			dx, dy;
	SByte						sbyte;
	
	
	// Get pointer to pen queue
	penQP = gP->penQP;
	
	
	// Check for Errors
	ErrFatalDisplayIf(penQP->rmvStrokeStage<0, "Pen q out of sync");
	
	
	// If this is the first call, it's for the start point which was
	//  already extracted in the call to EvtDequeueStrokeInfo and saved
	//  in the queue header
	if (penQP->rmvStrokeStage == 0) {
		*retP = penQP->rmvStartPt;
		penQP->rmvLast = *retP;
		penQP->rmvStrokeStage = 1;
		PenRawToScreen(retP);
		return 0;
		}
		
	
	// Else, we're getting a mid point so set up the queue variables
	dataP = penQP->data + penQP->start;
	size = penQP->size;


	// If this is a mid point or the end point, extract it
	byte = *dataP++;
	if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
	
	
	// If no more points in the stroke...
	if (byte == 0)	{								// end point
		retP->x = -1;
		retP->y = -1;
		penQP->rmvStrokeStage = -1;
		penQP->strokesRemoved++;
		return 0;
		}
		
	// 1 byte encoding...
	else if ((byte & 0x80) == 0) {
		dx = byte >> 4;
		if (dx & 0x04) dx |= 0xFFF8;
		dy = byte & 0x0F;
		if (dy & 0x08) dy |= 0xFFF0;
		
		retP->x = penQP->rmvLast.x = penQP->rmvLast.x + dx;
		retP->y = penQP->rmvLast.y = penQP->rmvLast.y + dy;
		}
		
		
	// 2 byte encoding...
	else if (byte != 0xC0) {
		dx = byte & 0x7F;
		if (dx & 0x40) dx |= 0xFF80;
		
		sbyte = *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		dy = (SWord)sbyte;
		
		retP->x = penQP->rmvLast.x = penQP->rmvLast.x + dx;
		retP->y = penQP->rmvLast.y = penQP->rmvLast.y + dy;
		}
		
		
	// 5 byte encoding...
	else {
		retP->x = *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		
		retP->x = (retP->x << 8) + *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		
		retP->y = *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		
		retP->y = (retP->y << 8) + *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		
		penQP->rmvLast = *retP;
		}
		
		
	// Scale the point before returning it
	PenRawToScreen(retP);
	return 0;
}
		




/************************************************************
 *
 *  FUNCTION: EvtFlushNextPenStroke
 *
 *  DESCRIPTION: Flushes the next stroke out of the pen queue. If 
 *   a stroke has already been partially dequeued, by calling 
 *	  EvtDequeuePenStrokeInfo, this routine will finish the stroke
 *   dequeueing. Otherwise, this routine will dequeue the next
 *   stroke in the queue.
 *
 *  PARAMETERS: 
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Recognizers that only need the start and end points of
 *   a stroke.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtFlushNextPenStroke(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register PenQueuePtr	penQP;

	register BytePtr		dataP;
	register Int			size;
	
	Byte						byte;



	// Setup queue variables
	penQP = gP->penQP;
	dataP = penQP->data + penQP->start;
	size = penQP->size;
	
	// Return if no pen data 
	if (penQP->strokesRemoved == penQP->strokesAdded) return 0;
	
	
	// Have we gotten the stroke info yet? If not, flush that out first
	if (penQP->rmvStrokeStage < 0) {
		penQP->start += 8;									// size of stroke info
		if (penQP->start >= size)  penQP->start -= size;
		dataP = penQP->data + penQP->start;
		}

	
	// Flush points till we get to the null terminator
	while(1) {
		byte = *dataP++;
		if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
		
		if (byte == 0) break;
		
		// 1 byte encoding...
		if (byte < 128) continue;
		
		// 2 byte encoding...
		else if (byte != 0xC0) {
			dataP++;
			if (++penQP->start == size) {penQP->start = 0; dataP = penQP->data;}
			}
			
		// 5 byte encoding...
		else {
			dataP += 4;
			penQP->start += 4;
			if (penQP->start >= size) penQP->start -= size;
			dataP = penQP->data + penQP->start;
			}
		}
		
	// Stroke flushed
	penQP->rmvStrokeStage = -1;
	penQP->strokesRemoved++;
	return 0;
}



/************************************************************
 *
 *  FUNCTION: EvtGetPen
 *
 *  DESCRIPTION: Return the current status of the pen
 *
 *  PARAMETERS: 
 *		*pScreenX - x location relative to current window
 *    *pScreenY - y location relative to current window
 *    *pPenDown - true or false
 *
 *  RETURNS: nothing
 * 
 *  CALLED BY: Various UI routines
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void EvtGetPen(SWord *pScreenX, SWord *pScreenY, Boolean *pPenDown)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	PointType	screenPen;
	
	#if EMULATION_LEVEL != EMULATION_NONE

	StubEnqueuePenPosition();
			
	#else
	
	// Wait for 1 tick, or a pen change, whichever comes sooner
	gP->idle = true;
	SysEvGroupWait(GSysEvGroupID, 
			sysEvtGroupMask(sysFileDescStdIn,false),		// mask
			sysEvtGroupMask(sysFileDescStdIn,false),		// value
			sysEvGroupWaitOR,									// match type
			1);

	gP->idle = false;


	//------------------------------------------------------------------------
	// Update the screen always here. This makes clicking on Buttons seem
	//  faster.
	//------------------------------------------------------------------------
	ScrSendUpdateArea(true);
	#endif
	
		
	// Convert raw digitizer location to screen coordinates
	screenPen.x = gP->penX;
	screenPen.y = gP->penY;
	PenRawToScreen(&screenPen);

	*pScreenX = screenPen.x;
	*pScreenY = screenPen.y;
	*pPenDown = gP->penDown;
	WinDisplayToWindowPt(pScreenX, pScreenY);
}


/************************************************************
 *
 *  FUNCTION: EvtSetKeyQueuePtr
 *
 *  DESCRIPTION: Replaces the current key queue with another
 *		and initializes it.
 *
 *  PARAMETERS: 
 *		keyQueueP 	- pointer to new area of memory to use as pen queue
 *		size 			- size of area in bytes.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Applications that wish to install a larger or smaller key
 *		queue.
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtSetKeyQueuePtr(Ptr qSpaceP, ULong size)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	Word						status;


	// Check for a minimum size
	if (size < sizeof(KeyQueueType) + 5)
		return sysErrParamErr;
		

	// Interrupts off while we replace the queue
	status = SysDisableInts();
	
	
	// Now, get rid of the old one and plug in the new one
	if (gP->keyQP) {
		MemPtrFree(gP->keyQP);
		gP->keyQP = 0;
		}
	
	// Plug in the new one - the only field we need to initialize is the size
	gP->keyQP = (KeyQueuePtr)qSpaceP;
	gP->keyQP->size = size - sizeof(KeyQueueType);
	
	// Init the new queue
	EvtFlushKeyQueue();
	
	// Restore interrupts
	SysRestoreStatus(status);
	
	return 0;
}



/************************************************************
 *
 *  FUNCTION: EvtKeyQueueSize
 *
 *  DESCRIPTION: Returns the size of the current key queue in bytes. 
 *
 *  PARAMETERS: none
 *
 *  RETURNS: size of queue in bytes
 * 
 *  CALLED BY: Applications that wish to see how large the current key queue is.
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
ULong				EvtKeyQueueSize(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
		
	// Get the size
	return (gP->keyQP->size + sizeof(KeyQueueType));
}




/************************************************************
 *
 *  FUNCTION: EvtFlushKeyQueue
 *
 *  DESCRIPTION: Flushes all points out of the Key queue
 *
 *  PARAMETERS: 
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Hopefully nobody
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtFlushKeyQueue(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	KeyQueuePtr				keyQP = gP->keyQP;
	Word						status;

	
	// Interrupts off while we much with the queue header
	status = SysDisableInts();
	
	// Initialize the queue
	keyQP->start = 0;
	keyQP->end = 0;

	// Restore interrupts
	SysRestoreStatus(status);
	
	return 0;
}



/************************************************************
 *
 *  FUNCTION: EvtEnqueueKey
 *
 *  DESCRIPTION: Called by the keyboard interrupt routine and the Graffiti
 *   and SoftKeys recognizers to place keys into the key queue. Note that
 *   because both interrupt non-interrupt level code can post keys into 
 *   the queue, this routine will disable interrupts while the queue header
 *   is being modified.
 *
 *
 *   Most keys in the queue take only 1 byte - if they have no modifiers and
 *    no virtual key code, and are 8 bit ascii. If a key event in the queue
 *    has modifiers or  is a non-standard ascii code, it will take up 6 bytes 
 *    of storage and will have the following format:
 *
 *		  evtKeyStringEscape  - 1 byte
 *		  ascii code          - 2 bytes
 *      virtual key code    - 2 bytes
 *      modifiers           - 2 bytes
 *
 *
 *  PARAMETERS: 
 *		ascii 		- ascii code of key
 *    keycode 		- virtual key code of key
 *    modifiers   - modifiers for key event
 *		
 *
 *  RETURNS: size of queue in bytes
 * 
 *  CALLED BY: Applications that wish to see how large the current pen queue is.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtEnqueueKey(UInt ascii, UInt keycode, UInt modifiers)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register KeyQueuePtr	keyQP;
	Byte						byte;
	Byte						byteArray[10];
	Err						err;
	
	// Check for nil globals, this could happen if the user holds down
	//  a key during boot and we get a key interrupt before we have a chance
	//  to init the SysEvtMgr.
	if (!gP) return evtErrParamErr;
	
	
	// Check for nil key queue
	keyQP = gP->keyQP;
	if (!keyQP) return evtErrParamErr;
	
	
	// See if we can use 1 byte encoding...
	if (!keycode && !modifiers && (ascii < 256) && (ascii != evtKeyStringEscape)) {
		byte = ascii;
		err = PrvEnqueueKeyBytes(keyQP, &byte, 1);
		}


	// 7 byte encoding
	else {
		byteArray[0] = evtKeyStringEscape;
		byteArray[1] = ascii >> 8;
		byteArray[2] = ascii;
		byteArray[3] = keycode >> 8;
		byteArray[4] = keycode;
		byteArray[5] = modifiers >> 8;
		byteArray[6] = modifiers;
		err = PrvEnqueueKeyBytes(keyQP, byteArray, 7);
		}
		
		
	// Wake up event manager and return result code
	SysEvGroupSignal(GSysEvGroupID, 
				sysEvtGroupMask(sysFileDescStdIn,false),		// mask
				sysEvtGroupMask(sysFileDescStdIn,false),		// value
				sysEvGroupSignalConstant);						// type

	return err;
}


/************************************************************
 *
 *  FUNCTION: EvtKeyQueueEmpty
 *
 *  DESCRIPTION: Returns true if the key queue is currently empty.
 *   
 *  PARAMETERS: 
 *		void
 *		
 *  RETURNS: true if empty
 * 
 *  CALLED BY: KeyManager to determine if it should enqueue auto-repeat
 *		keys.
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean				EvtKeyQueueEmpty(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register KeyQueuePtr	keyQP;
	
	// Set up key queue pointer
	keyQP = gP->keyQP;
	
	// Are there any keys in the queue???
	if (keyQP->start == keyQP->end) return true;
	return false;
}



/************************************************************
 *
 *  FUNCTION: EvtDequeueKeyEvent
 *
 *  DESCRIPTION: Called by EvtGetSysEvent to get the next key out
 *   of the key queue in the form of a key event. We're only
 *   called from one place so we don't have to disable interrupts during
 *   this call.
 *   
 *    Refer to the comments on EvtEnqueueKey for a description of how
 *    keys are stored in the key queue
 *
 *  PARAMETERS: 
 *		*eventP	- event record.
 *		peek		- if true, leave key in key queue.
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: EvtGetSysEvent
 *
 *  CREATED: 3/24/95
 *
 *  BY: Ron Marianetti
 *
 *  MODIFICATIONS:
 *		7/3/96	RM		Added peek parameter to allow peeking at the next key without
 *								removing it. I'm assuming (hopefully correctly) that no apps
 *								are using this call yet and that adding the peek parameter will
 *								not cause incompatibilities. <ROM2.0>
 *
 *************************************************************/
Err				EvtDequeueKeyEvent(EventPtr eventP, Word peek)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	register KeyQueuePtr	keyQP;
	
	register BytePtr		dataP;
	register Int			size;
	Byte						byte;
	register	UInt			start;
	
	// Set up key queue pointer
	keyQP = gP->keyQP;
	
	
	// Are there any keys in the queue???
	start = keyQP->start;
	if (start == keyQP->end) return evtErrQueueEmpty;
	

	// Set up queue locals
	dataP = keyQP->data + start;
	size = keyQP->size;
	eventP->eType = keyDownEvent;


	// Extract the next byte
	byte = *dataP++;
	if (++start == size) {start = 0; dataP = keyQP->data;}
	
	// Is it an escape sequence?? If so, extract 6 more bytes
	if (byte == evtKeyStringEscape) {
		eventP->data.keyDown.chr = *dataP++;
		if (++start == size) {start = 0; dataP = keyQP->data;}
		eventP->data.keyDown.chr = (eventP->data.keyDown.chr << 8) | *dataP++;
		if (++start == size) {start = 0; dataP = keyQP->data;}
	
		eventP->data.keyDown.keyCode = *dataP++;
		if (++start == size) {start = 0; dataP = keyQP->data;}
		eventP->data.keyDown.keyCode = (eventP->data.keyDown.keyCode << 8) | *dataP++;
		if (++start == size) {start = 0; dataP = keyQP->data;}
	
		eventP->data.keyDown.modifiers = *dataP++;
		if (++start == size) {start = 0; dataP = keyQP->data;}
		eventP->data.keyDown.modifiers = (eventP->data.keyDown.modifiers << 8) | *dataP++;
		if (++start == size) {start = 0;}
		}
	
	
	// If not, its a simple case
	else {
		eventP->data.keyDown.chr = byte;
		eventP->data.generic.data2 = 0;
		eventP->data.generic.data3 = 0;
		}
	
	
	// If we're not just peeking, update the start variable in the queue to reflect
	//  the key we just dequeued
	if (!peek)
		keyQP->start = start;

	return 0;
}



/************************************************************
 *
 *  FUNCTION: EvtWakeup
 *
 *  DESCRIPTION: Can be called by interrupt routines in order to
 *    force the Event Manager to wake-up and send a null event to
 *    the current app.
 *
 *  PARAMETERS: 
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: Interrupt routines, like the Sound Manager and Alarm Manager
 *
 *  CREATED: 5/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtWakeup(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	
	// Set boolean to force Event Manager to return a null event if there are no
	//   other events available
	gP->sendNullEvent = true;
	
	// Set the event flag to wakeup event manager
	SysEvGroupSignal(GSysEvGroupID, 
				sysEvtGroupMask(sysFileDescStdIn,false),		// mask
				sysEvtGroupMask(sysFileDescStdIn,false),		// value
				sysEvGroupSignalConstant);							// type
				

	return 0;
}




/************************************************************
 *
 *  FUNCTION: EvtResetAutoOffTimer
 *
 *  DESCRIPTION: Can be called periodically by other managers to
 *    reset the auto-off timer in order to assure that the device 
 *		doesn't automatically power off  during a long operation that 
 *		doesn't have user input (like a lot of serial port activity, for example). 
 *
 *  PARAMETERS: 
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: SerialLinkMgr, possibly other IO managers
 *
 *  CREATED: 8/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err				EvtResetAutoOffTimer(void)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	
	// Capture the current ticks 
	GSysAutoOffEvtTicks = GHwrCurTicks;
	
	return 0;
}


/************************************************************
 * PRIVATE
 *------------------------------------------------------------------------
 *  FUNCTION: PrvEnqueueKeyByte, private
 *
 *  DESCRIPTION: Because both interrupt non-interrupt level code can post keys into 
 *   the queue, this routine must be used to post bytes into the key queue.
 *   It will disable interrupts while it adds the specified bytes to the queue.
 *
 *
 *  PARAMETERS: 
 *		ascii 		- ascii code of key
 *    keycode 		- virtual key code of key
 *    modifiers   - modifiers for key event
 *		
 *
 *  RETURNS: size of queue in bytes
 * 
 *  CALLED BY: Applications that wish to see how large the current pen queue is.
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		asm	PrvEnqueueKeyBytes(KeyQueuePtr keyQP, BytePtr dataP, UInt size)
{
			fralloc +
			MOVEM.L	A2/D3, -(SP)								// save work registers
			
			MOVE.W	SR, -(SP)									// save status register
			ORI.W		#0x0700, SR									// interrupts off
			
		// Setup register variables
			MOVE.L	keyQP, A2									// queue ptr
			MOVE.L	dataP, A0									// data to enqueue
			MOVE.W	struct(KeyQueueType.end)(A2), D2		// end of queue
			MOVE.W	struct(KeyQueueType.size)(A2), D3	// size of queue
			LEA		struct(KeyQueueType.data)(A2), A1	// start of data
			ADD.W		D2, A1										// where new data goes
			MOVE.W	size, D1										// # of bytes to enqueue
			
			
		// Make sure there's room for the data
			MOVE.W	struct(KeyQueueType.start)(A2), D0	// start
			SUB.W		D2, D0										// start - end
			BGT.S		@NoWrap										// no wrap-->
			ADD.W		D3, D0										// wrap around
@NoWrap:
			CMP.W		D1, D0										// enough room for these bytes?
			BGT.S		@PutInQueue									// yes -->
			MOVE.W	#evtErrQueueFull, D0						// error code
			BRA.S		@Exit
			
			
		// Loop putting bytes in
@PutInQueue:
			SUBQ.W	#1, D1										// 0 base # of bytes
		
@NextByte:
			MOVE.B	(A0)+, (A1)+								// put byte in
			ADDQ.W	#1, D2										// bump end
			CMP.W		D2, D3										// wrap?
			BNE.S		@DoneByte									// no -->
			
			CLR.W		D2												// wrap to 0
			LEA		struct(KeyQueueType.data)(A2), A1	// start of data
			
@DoneByte:
			DBRA		D1, @NextByte								// more?
			
			
		// Put the new end in the queue header
			MOVE.W	D2, struct(KeyQueueType.end)(A2)		// write out new end of queue
			CLR.W		D0												// no error
			
			
		// Exit
@Exit:	MOVE.W	(SP)+, SR
			MOVEM.L	(SP)+, A2/D3
			frfree
			RTS
}






/***********************************************************************
 *
 *  FUNCTION:     PrvSendGremlinsIdle
 *
 *  DESCRIPTION:  Sends a text string to the console
 *
 *  PARAMETERS:   string pointer
 *
 *  RETURNS:      0 if no err  
 *
 *  CALLED BY:    
 *
 *  CREATED:      2/8/95
 *
 *  BY:           Ron Marianetti
 *
 ***********************************************************************/
static Err PrvSendGremlinsIdle (void)
{
	Err							err;
	SlkWriteDataType			writeList[sysPktMaxBodyChunks];
	SysPktGremlinsCmdType	body;
	SlkPktHeaderType			header;
	SysEvtMgrGlobalsPtr		gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;

	if ((gP->gremlinsFlags & (grmGremlinsOn | grmGremlinsIdle)) !=
		 (grmGremlinsOn | grmGremlinsIdle))
		 return 0;
		 
	//------------------------------------------------------------------------
	// Send a 0 length message packet notifying the host that we've entered
	//------------------------------------------------------------------------
	header.type = slkPktTypeSystem;
	header.src = slkSocketConsole;
	header.dest = slkSocketConsole;
	header.transId = 0;
	
	// Fill in the body
	body.command = sysPktGremlinsCmd;
	body.action = sysPktGremlinsIdle;
	
	// Create the writeList
	writeList[0].dataP = (BytePtr)&body;
	writeList[0].size = sizeof(SysPktGremlinsCmdType);
	writeList[1].size = 0;									// Terminator
	
	// Send it
	err = SlkSendPacket(&header, writeList);
	if (! err)
		gP->gremlinsFlags &= ~grmGremlinsIdle;
		
	return err;	
}

/***********************************************************************
 *
 *  FUNCTION:     PrvHandleExchangeEvents
 *
 *  DESCRIPTION:  Checks flag set at interrupt level to send an event
 *						to an exchange manager library (irLib uses this)
 *
 *  PARAMETERS:   none
 *
 *  RETURNS:      true if an event was handled 
 *
 *  CALLED BY:    
 *
 *  CREATED:      1/31/98
 *
 *  BY:          Gavin Peacock
 *
 ***********************************************************************/
static Boolean PrvHandleExchangeEvents()
{		
	// Exchange library interface for handling high priorty interrupt info
	// sends a special key event to the active library

	Boolean exgEvent = false;
	// atomic test and set so that we don't miss any events
	Word sr = SysDisableInts();
	if (GSysMiscFlags & sysMiscFlagExgEvent)
		{
		GSysMiscFlags &= ~sysMiscFlagExgEvent;
		exgEvent = true;
		}
	SysRestoreStatus(sr);
		
	if (exgEvent && GExgActiveLib)
		{
		EventType evt;
		evt.eType = keyDownEvent;
		evt.data.keyDown.modifiers = libEvtHookKeyMask;
		evt.data.keyDown.keyCode = GExgActiveLib;
		evt.data.keyDown.chr = exgIntDataChr;
		ExgLibHandleEvent(GExgActiveLib,&evt);
		}
	return exgEvent;
}

/************************************************************
 *
 *  FUNCTION: EvtEnableGraffiti
 *
 *  DESCRIPTION:  Set Graffiti enabled or disabled
 *
 *  PARAMETERS: true to enable Graffiti
 *
 *  RETURNS: nothing
 * 
 *  CALLED BY: 
 *
 *  CREATED: 11/8/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/
void	EvtEnableGraffiti(Boolean enable)
{
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	
	gP->enableGraffiti = enable;
}

