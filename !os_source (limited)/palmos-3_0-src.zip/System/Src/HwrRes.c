/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Res.c
 * AUTHOR:	 Art Lamb: January 29, 1995
 *
 * DECLARER: Emulator
 *
 * ROUTINES:
 *     ResLoadForm
 *     ResLoadMenu
 *		
 * DESCRIPTION:
 *	  This file contains routines that convert Macintosh resources to
 *   Pilot resources.
 *
 **********************************************************************/

#include <Pilot.h>



/***********************************************************************
 *
 *		Internal structures and functions
 *
 ***********************************************************************/
#define FormRscType 					'tFRM'



/***********************************************************************
 *
 * FUNCTION: 	 ResLoadForm
 *
 * DESCRIPTION: This routine copies and initializes a form resource.  The
 *					 structures are complete except pointers updating.
 *					 Pointers are stored as offsets from the beginning of the
 *					 form.
 *
 * PARAMETERS:	 rscID	the resource id of the form.
 *					
 * RETURNED:	 The handle of the memory block that the form is in,  since 
 *              the form structure begins with the WindowType structure this
 *              is also a WindowHandle.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	5/5/95	Initial Revision
 *			art	2/19/96	Added scroll bar
 *
 ***********************************************************************/
VoidPtr ResLoadForm (Word rscID)
{
	Handle					formROMHandle;		// form in ROM
	Handle					formHandle;			// copy of form
	FormPtr 					frm, frmROM;
	int						i, j;
	char *					ptr;
	Int						frmSize;
	

	// The form is in ROM.  We want to write to it to set it's pointers.
	// Copy it to RAM so we can do this.
	formROMHandle = DmGetResource(FormRscType, rscID);
#if ERROR_CHECK_LEVEL != ERROR_CHECK_NONE
	if (formROMHandle == NULL)
		{
		char message[60];
		
		StrPrintF(message, "Resource for %s form %hu not found", 
			rscID >= 10000 ? "system" : "app",
			rscID);
		ErrDisplay(message);
		}
#endif
	
		
	frmROM = (FormPtr) MemHandleLock (formROMHandle);
	frmSize = MemPtrSize(frmROM);
	
	formHandle = MemHandleNew(frmSize);
	frm = (FormPtr) MemHandleLock (formHandle);

	MemMove(frm, frmROM, frmSize);
	MemHandleUnlock (formROMHandle);
	
	
	// Update all of the pointers within the form object
	frm->objects = (FormObjListType *) ((char *) frm + sizeof (FormType));


	// Loop through each object used by the form and update each one.
	for (i = 0; i < frm->numObjects; i++)
		{
		frm->objects[i].object.ptr = ((char *) frm) + (int) frm->objects[i].object.ptr;
		switch (frm->objects[i].objectType)
			{
			case frmListObj:
				// The array of list items needs to be updated.  The format in the
				// resource of the list is the ListType structure followed
				// by a ragged array of list item strings.  The array of pointers
				// is stored before the sequence of item strings.
				
				// Update itemsText to point to the ragged array of list items.
				frm->objects[i].object.list->itemsText = (char **) 
					(frm->objects[i].object.list + 1);
					
				// Now build the array of pointers by walking through the strings
				ptr = (CharPtr) frm->objects[i].object.list + sizeof (ListType) + 
					frm->objects[i].object.list->numItems * sizeof (CharPtr);
				for (j = 0; j < frm->objects[i].object.list->numItems; j++)
					{
					frm->objects[i].object.list->itemsText[j] = ptr;
					ptr = ptr + (StrLen(ptr) + 1);
					}
				break;

			case frmControlObj:
				// Update the control to point to the label provided.
				frm->objects[i].object.control->text = (CharPtr) frm->objects[i].object.control + 
					sizeof (ControlType);
				break;

			case frmFieldObj:
				break;


			case frmTableObj:
				ptr = (CharPtr) frm->objects[i].object.table;
				frm->objects[i].object.table->columnAttrs = (TableColumnAttrType *) (ptr + 
					sizeof (TableType));

				frm->objects[i].object.table->rowAttrs = (TableRowAttrType *) (ptr + 
					sizeof (TableType) +
					sizeof (TableColumnAttrType) * frm->objects[i].object.table->numColumns);
		
				frm->objects[i].object.table->items = (TableItemPtr) (ptr + 
					sizeof (TableType) +
					sizeof (TableColumnAttrType) * frm->objects[i].object.table->numColumns +
					sizeof (TableRowAttrType) * frm->objects[i].object.table->numRows); 
	
				break;

			case frmPopupObj:
				break;

			case frmTitleObj:
				frm->objects[i].object.title->text = (CharPtr) frm->objects[i].object.title + 
					sizeof (FormTitleType);
				break;

			case frmLabelObj:
				frm->objects[i].object.label->text = (CharPtr) frm->objects[i].object.label + 
					sizeof (FormLabelType);
				break;

			case frmBitmapObj:
				break;

			case frmGraffitiStateObj:
				break;

			case frmGadgetObj:
				break;

			case frmScrollBarObj:
				break;

			default:
				ErrDisplay ("Unknown rsrc type");
			}
		}
	
	return (frm);
}

/***********************************************************************
 *
 * FUNCTION: 	 ResLoadMenu
 *
 * DESCRIPTION: This routine copies and initializes a menu resource.  The
 *					 structures are complete except pointers updating.
 *					 Pointers are stored as offsets from the beginning of the
 *					 menu.
 *
 * PARAMETERS:	 rscID	the resource id of the menu.
 *					
 * RETURNED:	 The handle of the memory block that the form is in,  since 
 *              the form structure begins with the WindowType structure this
 *              is also a WindowHandle.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	5/5/95	Initial Revision
 *
 ***********************************************************************/
VoidPtr ResLoadMenu (Word rscID)
{
	Handle					menuROMHandle;		// menu in ROM
	Handle					menuHandle;			// copy of menu
	MenuBarPtr 				menuBar, menuBarROM;
	Int i, j;
	Int menuBarSize;
	
	
	// The menu is in ROM.  We want to write to it to set it's pointers.
	// Copy it to RAM so we can do this.
	menuROMHandle = DmGetResource(MenuRscType, rscID);
	ErrFatalDisplayIf(menuROMHandle==NULL, "Menu rsrc not found");
	
	menuBarROM = (MenuBarPtr) MemHandleLock (menuROMHandle);
	menuBarSize = MemPtrSize(menuBarROM);
	
	menuHandle = MemHandleNew(menuBarSize);
	menuBar = (MenuBarPtr) MemHandleLock (menuHandle);

	MemMove(menuBar, menuBarROM, menuBarSize);
	MemHandleUnlock (menuROMHandle);
	
	
	
	// Fixup the pointers to the menus
	menuBar->menus = (MenuPullDownPtr) (menuBar+1);


	// Fixup the pointers to the items in each pulldown menu.
	for (i = 0; i < menuBar->numMenus; i++)
		{
		menuBar->menus[i].title = 
			(((char *) menuBar) + (Long) menuBar->menus[i].title);


		// Pointer to an array of items
		menuBar->menus[i].items = (MenuItemType *) 
			((char *) menuBar + (Long) menuBar->menus[i].items);


		// Fixup the pointers in each menu item			
		for (j = 0; j < menuBar->menus[i].numItems; j++)
			{
			menuBar->menus[i].items[j].itemStr = 
				(((char *) menuBar) + (Long) menuBar->menus[i].items[j].itemStr);
			}
			
		}
				
		

	return menuBar;
}

