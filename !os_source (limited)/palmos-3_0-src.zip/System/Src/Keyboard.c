/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Keyboard.c
 * AUTHOR:	 Roger Flores: March 29, 1995
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain routines to handle the onscreen keyboard.
 * Included are the keyboard object and the keyboard form.
 *
 **********************************************************************/

#include <Pilot.h>
#include <Keyboard.h>
#include <Graffiti.h>
#include <SysEvtMgr.h>
#include <SystemPrv.h>

#define kbdNoKeyPtr		NULL
#define noItemSelection kbdNoKeyPtr
#define noLabel			0

#define keyboardRows		4
#define numKeyboards		3	// alpha, punc/number, and int'l

#define keyboardFont			stdFont
#define keyboardLargeFont	largeFont



// These two structures also exist in MakeKbd.c
typedef unsigned short Offset;			// offset from the start of the resource

typedef struct {
	char		shiftedKey;		// key to use if shift is on
	char		capsKey;			// key to use if caps lock is on
	char		unshiftedKey;
	Byte		width;			// the width of the key.  The text is drawn centered.
	Offset	labelOffset;	// if there is a label display it instead
									// of a key (all modes)
} KeyboardKey;

typedef struct keyboardlayout{
	RectangleType	bounds;
	Byte rowHeight;
	FontID font;
	Offset keys;
	Byte keysPerRow[keyboardRows];
	Byte shiftKey;				// can be kbdNoKey
	Byte capsKey;				// can be kbdNoKey
	Boolean lastLayoutInKeyboard;
} KeyboardLayout;

typedef struct {
	Boolean	shiftOn;
	Boolean	capsOn;
	BytePtr kbdResource;
	KeyboardLayout *layout[numKeyboards];
	FieldPtr originalFieldP;
	UInt originalFieldOffset;
	UInt originalFieldBlockSize;
	UInt originalHeight;
	Byte currentKeyboard;
} KeyboardStatus;



// These are form constants
#define KeyboardDoneButton		10302
#define KeyboardTextField		10303
#define KeyboardAbcPushBtn		10305
#define Keyboard123PushBtn		10306
#define KeyboardIntlPushBtn	10307
#define KeyboardUpButton		10308
#define KeyboardDownButton		10309

#define linesInKeyboardField	4



/***********************************************************************
 *
 * FUNCTION: 	 ProcessKey
 *
 * DESCRIPTION: Return the key for the passed selection considering 
 *		the shift and caps lock statuses.
 *
 * PARAMETERS:  KeyboardStatus	- pointer to keyboard status
 *					 newSelection		- the key selected
 *
 * RETURNED:	 a character for the selected key
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	3/30/95	Initial Revision
 *
 ***********************************************************************/
static char ProcessKey(KeyboardStatus *ks, KeyboardKey *newSelection)
	{
	if (ks->shiftOn)
		// shift and caps cancel each other on some keys!
		if (ks->capsOn && ((newSelection->unshiftedKey != newSelection->capsKey)))
			return newSelection->unshiftedKey;
		else
			return newSelection->shiftedKey;
			
	else if (ks->capsOn)
		return newSelection->capsKey;

	return newSelection->unshiftedKey;		
	}


/***********************************************************************
 *
 * FUNCTION: 	 MapPointToItem
 *
 * DESCRIPTION: Return return the KeyboardKey at x, y.
 *
 * PARAMETERS:  x, y - coordinate
 *					 ks - the KeyboardStatus in use
 *              passedKeyBounds - pointer to get the bounds of the key at x, y
 *
 * RETURNED:	 KeyboardKey pointer containing x,y or NULL
 *					if (passedKeyBounds != NULL) it gets the key's bounds
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	3/30/95	Initial Revision
 *
 ***********************************************************************/

static KeyboardKey * MapPointToItem (short x, short y, KeyboardStatus *ks,
	RectangleType *passedKeyBounds)
	{
	RectangleType	keyBounds;
	KeyboardLayout *k;
	KeyboardKey *kkPtr;
	UInt		row;
	UInt		key;

	
	
	k = ks->layout[ks->currentKeyboard];
	while (true)
		{
		// setup row information for the loop
		keyBounds.topLeft.y = k->bounds.topLeft.y - k->rowHeight;
		keyBounds.extent.y = k->rowHeight;

		// if the point is above or to the left of this layout check the next one!
		if (y < keyBounds.topLeft.y || x < k->bounds.topLeft.x)
			{
			// Stop if this is the last layout in the keyboard			
			if (k->lastLayoutInKeyboard)
				break;
			else
				k++;
				continue;
			}
			

		kkPtr = (KeyboardKey *) (ks->kbdResource + k->keys);
		for (row = 0; row < keyboardRows; row++)
			{
			// skip empty rows
			if (k->keysPerRow[row] == 0)
				continue;
				
			keyBounds.topLeft.y = keyBounds.topLeft.y + keyBounds.extent.y;
//			keyBounds.extent.y = k->rowHeight;
			keyBounds.topLeft.x = k->bounds.topLeft.x;

			// skip this row if the point is below it (below the bottom line)
			if (y > keyBounds.topLeft.y + keyBounds.extent.y)
				{
				kkPtr += k->keysPerRow[row];
				continue;
				}
				
			for (key = 0; key < k->keysPerRow[row]; key++, kkPtr++)
				{
				keyBounds.extent.x = kkPtr->width;
			
				// if x is to the left of the right side of the key then this is the key!
				if (x < keyBounds.topLeft.x + keyBounds.extent.x)
					{
					if (passedKeyBounds != NULL)
						{
						passedKeyBounds->topLeft.x = keyBounds.topLeft.x;
						passedKeyBounds->topLeft.y = keyBounds.topLeft.y;
						passedKeyBounds->extent.x = keyBounds.extent.x;
						passedKeyBounds->extent.y = keyBounds.extent.y + 1;
						}
					return kkPtr;
					}
				
				// advance to the new key
				keyBounds.topLeft.x += keyBounds.extent.x;
				}
			}
			
			
		// Stop if this is the last layout in the keyboard			
		if (k->lastLayoutInKeyboard)
			break;
		else
			k++;
		}	

	return NULL;
	}


/***********************************************************************
 *
 * FUNCTION: 	 GetFieldHeight
 *
 * DESCRIPTION: This routine returns the height of the specified text
 *              if shown in the original field.
 *
 * PARAMETERS:  systemKeyboard - the keyboard status info
 *              textP          - string to calculate height of
 *
 * RETURNED:	 number of line needed to display the string
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/13/95	Initial Revision
 *
 ***********************************************************************/
static Word GetFieldHeight (KeyboardStatus *systemKeyboard, CharPtr textP)
{
	Word height;
	FontID curFont;
	RectangleType bounds;

	FldGetBounds (systemKeyboard->originalFieldP, &bounds);
	curFont = FntSetFont (FldGetFont (systemKeyboard->originalFieldP));
	height = FldCalcFieldHeight (textP, bounds.extent.x);
	FntSetFont (curFont);
	
	return (height);
}



/***********************************************************************
 *
 * FUNCTION: 	 InvertItem
 *
 * DESCRIPTION: Invert a key.  
 *
 * PARAMETERS:  ks     - pointer to KeyboardStatus in use
 *              invertKey    - KeyboardKey to invert
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	3/30/95	Initial Revision
 *
 ***********************************************************************/

static void InvertItem (const KeyboardStatus *ks, KeyboardKey *invertKey)
{
	RectangleType	keyBounds;
	KeyboardLayout *k;
	UInt		row;
	UInt		key;
	KeyboardKey *kkPtr;

	
	if (invertKey == NULL)
		return;
		
	k = ks->layout[ks->currentKeyboard];
	while (true)
		{
		// setup row information for the loop
		keyBounds.topLeft.y = k->bounds.topLeft.y - k->rowHeight;
		keyBounds.extent.y = k->rowHeight;

	
		kkPtr = (KeyboardKey *) (ks->kbdResource + k->keys);
		for (row = 0; row < keyboardRows; row++)
			{
			// skip empty rows
			if (k->keysPerRow[row] == 0)
				continue;
				
			keyBounds.topLeft.y = keyBounds.topLeft.y + keyBounds.extent.y;
			keyBounds.extent.y = k->rowHeight;
			keyBounds.topLeft.x = k->bounds.topLeft.x;

			// skip this row if the key isn't in the row
			if (invertKey > (kkPtr + k->keysPerRow[row] - 1))
				{
				kkPtr += k->keysPerRow[row];
				continue;
				}
				
			for (key = 0; key < k->keysPerRow[row]; key++, kkPtr++)
				{
				keyBounds.extent.x = kkPtr->width;
			
				// if this is the key invert it and exit
				if (invertKey == kkPtr)
					{
					keyBounds.topLeft.x++;
					keyBounds.topLeft.y++;
					keyBounds.extent.x--;
					keyBounds.extent.y--;
					WinInvertRectangle (&keyBounds, 0);
					return;
					}
				
				// advance to the new key
				keyBounds.topLeft.x += keyBounds.extent.x;
				}
			}
			
		// Stop if this is the last layout in the keyboard			
		if (k->lastLayoutInKeyboard)
			break;
		else
			k++;
		}	

}


/***********************************************************************
 *
 * FUNCTION: 	 KbdDraw
 *
 * DESCRIPTION: Draw the keyboard.
 *
 * Currently
 *
 * PARAMETERS:  KeyboardStatus   - pointer to keyboard status
 *					 keyTopsOnly		- true if only the key tops need drawing
 *											  Used when shift is pressed.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	3/30/95	Initial Revision
 *
 ***********************************************************************/
static void KbdDraw (KeyboardStatus *ks, Boolean keyTopsOnly)
	{
	RectangleType	keyBounds;
	RectangleType	eraseBounds;		// Bounds of key top to erase
	KeyboardLayout *k;
	CharPtr	keyChars;
	Word		keyCharsLen;
	UInt		keyCharsX;
	UInt		keyCharsY;
	char		keyChar;
	UInt		row;
	UInt		key;
	FontID	currFont;
	Handle	bitmapH;
	BitmapPtr keytopBitmapP;
	KeyboardKey *kkPtr;

	
	currFont = FntSetFont (stdFont);	//boldFont
	k = ks->layout[ks->currentKeyboard];
	while (true)
		{
		if (!keyTopsOnly)
			WinEraseRectangle (&k->bounds, 0);
		FntSetFont (k->font);
		
		// setup row information for the loop
		keyBounds.topLeft.y = k->bounds.topLeft.y - k->rowHeight;
		keyBounds.extent.y = k->rowHeight;

	
		kkPtr = (KeyboardKey *) (ks->kbdResource + k->keys);
		for (row = 0; row < keyboardRows; row++)
			{
			// Skip empty rows
			if (k->keysPerRow[row] == 0)
				continue;
				
			keyBounds.topLeft.y = keyBounds.topLeft.y + keyBounds.extent.y;
			keyBounds.extent.y = k->rowHeight;
			keyBounds.topLeft.x = k->bounds.topLeft.x;
			keyCharsY = keyBounds.topLeft.y + (keyBounds.extent.y - FntLineHeight() + 1) / 2;

			// draw the line above this row
			if (!keyTopsOnly)
				WinDrawLine(k->bounds.topLeft.x + 1, keyBounds.topLeft.y, 
					k->bounds.topLeft.x + k->bounds.extent.x - 2, keyBounds.topLeft.y);
			
			for (key = 0; key < k->keysPerRow[row]; key++)
				{
				keyBounds.extent.x = kkPtr->width;
			
				// Draw the line on the right side of the key
				if (!keyTopsOnly)
					WinDrawLine(keyBounds.topLeft.x + keyBounds.extent.x, keyBounds.topLeft.y, 
						keyBounds.topLeft.x + keyBounds.extent.x, keyBounds.topLeft.y + keyBounds.extent.y - 1);

				// If the key has a label or bitmap display it; otherwise display the 
				// proper character considering the keyboard mode
				if (kkPtr->labelOffset != noLabel)
					{
					bitmapH = NULL;
					if (kkPtr->labelOffset == kbdBackspaceKey)
						bitmapH = DmGetResource (bitmapRsc, keyboardBackspaceBitmap);
					else if (kkPtr->labelOffset == kbdTabKey)
						bitmapH = DmGetResource (bitmapRsc, keyboardTabBitmap);
					else if (kkPtr->labelOffset == kbdReturnKey)
						bitmapH = DmGetResource (bitmapRsc, keyboardReturnBitmap);
					else if (kkPtr->labelOffset == kbdShiftKey)
						bitmapH = DmGetResource (bitmapRsc, keyboardShiftBitmap);
					else if (kkPtr->labelOffset == kbdCapsKey)
						bitmapH = DmGetResource (bitmapRsc, keyboardCapBitmap);
					if (bitmapH != NULL)
						{
						// Erase the entire key top because these may be inverted.
						if (kkPtr->labelOffset == kbdShiftKey ||
							kkPtr->labelOffset == kbdCapsKey)
							{
							// Erase the key top
							eraseBounds.topLeft.x = keyBounds.topLeft.x + 1;
							eraseBounds.topLeft.y = keyBounds.topLeft.y + 1;
							eraseBounds.extent.x = keyBounds.extent.x - 1;
							eraseBounds.extent.y = keyBounds.extent.y - 1;
							WinEraseRectangle(&eraseBounds, 0);
							}
						
						keytopBitmapP = MemHandleLock(bitmapH);
						// Draw the bitmap centered within the key's bounds
						WinDrawBitmap (keytopBitmapP, 
							keyBounds.topLeft.x + (keyBounds.extent.x - keytopBitmapP->width) / 2,
							keyBounds.topLeft.y + (keyBounds.extent.y + 1 - keytopBitmapP->height) / 2);
						MemPtrUnlock(keytopBitmapP);
						keyChars = NULL;
						}
					else
						{
						keyChars = (CharPtr) (ks->kbdResource + kkPtr->labelOffset);
						keyCharsLen = StrLen(keyChars);
						// center the label within the key (don't count right line!)
						keyCharsX = keyBounds.topLeft.x + (keyBounds.extent.x - 1 - 
							(FntCharsWidth(keyChars, keyCharsLen) - 1) + 1) / 2;
						}
					}
				else
					{
					keyChar = ProcessKey(ks, kkPtr);
					keyChars = &keyChar;
					keyCharsLen = 1;
					// center the character within the key
					keyCharsX = keyBounds.topLeft.x + (keyBounds.extent.x - 1 - 
						(FntCharWidth(keyChar) - 1) + 1) / 2 + 1;
					}
					
				if (keyChars != NULL && keyCharsLen > 0)
					{
					// Erase the key top
					eraseBounds.topLeft.x = keyBounds.topLeft.x + 1;
					eraseBounds.topLeft.y = keyBounds.topLeft.y + 1;
					eraseBounds.extent.x = keyBounds.extent.x - 1;
					eraseBounds.extent.y = keyBounds.extent.y - 1;
					WinEraseRectangle(&eraseBounds, 0);
					
					WinDrawChars(keyChars, keyCharsLen, keyCharsX, keyCharsY);
					}
				
				// advance to the new key
				kkPtr++;
				keyBounds.topLeft.x += keyBounds.extent.x;
				}
			}
		// Draw a line at the bottom of the keyboard (each row had a line drawn above it).
		if (!keyTopsOnly)
			WinDrawLine(k->bounds.topLeft.x + 1, keyBounds.topLeft.y + keyBounds.extent.y, 
				k->bounds.topLeft.x + k->bounds.extent.x - 2, keyBounds.topLeft.y + keyBounds.extent.y);

		// Draw a line for the left edge of the keyboard
		if (!keyTopsOnly)
			WinDrawLine(k->bounds.topLeft.x, k->bounds.topLeft.y + 1, 
				k->bounds.topLeft.x, keyBounds.topLeft.y + keyBounds.extent.y - 1);
		
		// Erase a pixel at the top right corner of the keyboard.  It's filled in when the
		// right edge of top right key is drawn.
		if (!keyTopsOnly)
			WinEraseLine(k->bounds.topLeft.x + k->bounds.extent.x - 1, k->bounds.topLeft.y, 
				k->bounds.topLeft.x + k->bounds.extent.x - 1, k->bounds.topLeft.y);

		// Now that the keys are drawn highlit the shift or caps key if the mode is on
		kkPtr = (KeyboardKey *) (ks->kbdResource + k->keys);
		if (ks->shiftOn && k->shiftKey != kbdNoKey)
			InvertItem(ks, kkPtr + k->shiftKey);
			
		if (ks->capsOn && k->capsKey != kbdNoKey)
			InvertItem(ks, kkPtr + k->capsKey);
			

		// Stop if this is the last layout in the keyboard			
		if (k->lastLayoutInKeyboard)
			break;
		else
			k++;
		}	

	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    KbdHandleEvent
 *
 * DESCRIPTION: Handle penDownEvents for the kbd object.  Typical
 *		work performed is the point to key mapping, inversion of
 *		the key, tracking of the point, and enqueing the key if 
 *		it's selected.
 *
 * PARAMETERS:	 ks - pointer to control object (ControlType)
 *              pEvent    - pointer to an EventType structure.
 *
 * RETURNED:	true if the event was handle or false if it was not.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	3/30/95	Initial Revision
 *
 ***********************************************************************/

static Boolean KbdHandleEvent (KeyboardStatus *ks, EventPtr pEvent)
	{
	Boolean		penDown;
	Boolean		inverted;
	short			x, y;
	KeyboardKey       *newSelection, *proposedSelection;
	RectangleType	keyBounds;
	KeyboardLayout *k;
	char			processedKey;
	

	if (pEvent->eType != penDownEvent)
		return false;


	// check the layout to see if the point is within any of the keyboards
	k = ks->layout[ks->currentKeyboard];
	while (true)
		{
		if (RctPtInRectangle (pEvent->screenX, pEvent->screenY, &k->bounds))
			break;
			
		// if the point isn't within a keyboard then return false
		if (k->lastLayoutInKeyboard)
			return false;
		else
			k++;
		}	

		
	newSelection = kbdNoKeyPtr;
	proposedSelection = MapPointToItem (pEvent->screenX, pEvent->screenY, ks, &keyBounds);
	if (newSelection != proposedSelection)
		{
		InvertItem(ks, newSelection);
		newSelection = proposedSelection;
		InvertItem(ks, newSelection);
		inverted	= true;
		}


	penDown = true;

	do
		{
		PenGetPoint (&x, &y, &penDown);

		if (RctPtInRectangle (x, y, &keyBounds))
			{
			proposedSelection = MapPointToItem (x, y, ks, NULL);
			if (penDown)
				{
				if (newSelection != proposedSelection)
					{
					if (inverted)
						InvertItem(ks, newSelection);
					newSelection = proposedSelection;
					InvertItem(ks, newSelection);
					inverted = true;
					}
				}
			}
		else     //moved out of bounds
			{
			if (inverted)
				{
				InvertItem(ks, newSelection);
				inverted = false;
				}
			newSelection = noItemSelection;
			}
		} while (penDown);


	// Uninvert the character unless it's the shift or caps lock key.  These
	// should stay inverted (reduces flashing).
	if (inverted && 
		newSelection->unshiftedKey != kbdCapsKey && 
		newSelection->unshiftedKey != kbdShiftKey)
		{
		InvertItem(ks, newSelection);
		inverted = false;
		}


	if (newSelection == noItemSelection)
		return true;


	// Send a keypress
	processedKey = ProcessKey(ks, newSelection);
	SndPlaySystemSound(sndClick);
	if (processedKey == kbdShiftKey)
		{
		ks->shiftOn = !ks->shiftOn;
		KbdDraw(ks, true);		// Draw the changed key tops and lit shift key
		GrfSetState(ks->capsOn, false, ks->shiftOn);
		return true;
		}
	else if (processedKey == kbdCapsKey)
		{
		ks->capsOn = !ks->capsOn;
		if (ks->shiftOn)			// Turn shift off when case is on
		   ks->shiftOn = false;
		KbdDraw(ks, true);		// Draw the changed key tops and lit caps key
		GrfSetState(ks->capsOn, false, ks->shiftOn);
		return true;
		}

	if (ks->shiftOn)
		{
		ks->shiftOn = false;
		KbdDraw(ks, true);		// Draw the changed key tops and unlit shift key
		GrfSetState(ks->capsOn, false, ks->shiftOn);
		}
		
	EvtEnqueueKey(processedKey, 0, 0);
	return true;
	}


 
/***********************************************************************
 *
 * FUNCTION:    KeyboardUpdateScrollers
 *
 * DESCRIPTION: This routine draws or erases the scroll arrow
 *              buttons.
 *
 * PARAMETERS:  frm - pointer to the Edit View form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	7/31/95	Initial Revision
 *
 ***********************************************************************/
static void KeyboardUpdateScrollers (FormPtr frm)
{
	FieldPtr fld;
	Word upIndex;
	Word downIndex;
	Boolean scrollableUp;
	Boolean scrollableDown;
		
	
	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardTextField));

	scrollableUp = FldScrollable (fld, up);
	scrollableDown = FldScrollable (fld, down);


	// Update the scroll button.
	upIndex = FrmGetObjectIndex (frm, KeyboardUpButton);
	downIndex = FrmGetObjectIndex (frm, KeyboardDownButton);
	FrmUpdateScrollers (frm, upIndex, downIndex, scrollableUp, scrollableDown);
}


/***********************************************************************
 *
 * FUNCTION:    KeyboardScroll
 *
 * DESCRIPTION: This routine scrolls the keyboard field a page or a 
 *              line at a time.
 *
 * PARAMETERS:  direction - up or dowm
 *              oneLine   - true if scrolling a single line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/30/95	Initial Revision
 *
 ***********************************************************************/
static void KeyboardScroll (DirectionType direction, Boolean oneLine)
{
	Word linesToScroll;
	FieldPtr fld;
	FormPtr frm;
	
	
	frm = FrmGetActiveForm ();
	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardTextField));
	if (FldScrollable (fld, direction))
		{
		if (oneLine)
			linesToScroll = 1;
		else
			linesToScroll = FldGetVisibleLines (fld) - 1;
		FldScrollField (fld, linesToScroll, direction);
		KeyboardUpdateScrollers (frm);
		}
}


/***********************************************************************
 *
 * FUNCTION:    KeyboardFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 * 				 The keyboard menu cannot be the system edit menu
 *					 because that has shortcuts which can have the keyboard
 *					 which would result in a recursive situation.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/26/95	Initial Revision
 *
 ***********************************************************************/
static Boolean KeyboardFormDoCommand (Word command)
{	
	FieldPtr fld;
	FormPtr frm;
	Word focus;


	frm = FrmGetActiveForm ();
	focus = FrmGetFocus (frm);
	if (focus == noFocus) return true;

	fld = FrmGetObjectPtr (frm, focus);
	if (! fld) return false;

	switch (command)
		{
		case sysKeyboardEditUndoCmd:
			FldUndo (fld);
			KeyboardUpdateScrollers (FrmGetActiveForm ());
			return true;

		case sysKeyboardEditCutCmd:
			FldCut (fld);
			KeyboardUpdateScrollers (FrmGetActiveForm ());
			return true;
		
		case sysKeyboardEditCopyCmd:
			FldCopy (fld);
			return true;
		
		case sysKeyboardEditPasteCmd:
			FldPaste (fld);
			KeyboardUpdateScrollers (FrmGetActiveForm ());
			return true;
		
		case sysKeyboardEditSelectAllCmd:
			FldSetSelection (fld, 0, FldGetTextLength (fld));
			return true;
		}
		
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    KeyboardFormInit
 *
 * DESCRIPTION: Initialize the keyboard form.
 *
 * PARAMETERS:  systemKeyboard - the keyboard status info
 *
 * RETURNED:    frm - pointer to the Keyboard form.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/30/95	Initial Revision
 *
 ***********************************************************************/
static FormPtr KeyboardFormInit (UInt formID, KeyboardStatus *systemKeyboard)
{
	FormPtr originalForm, frm;
	Word focusObj;
	FieldAttrType attr;
	Handle textH;
	FieldPtr textFieldP;
	ControlPtr	pControl;
	Word scrollPosition;
	Word insPtPosition;
	Word startPosition;
	Word endPosition;

	
	originalForm =  FrmGetActiveForm();
	focusObj = FrmGetFocus(originalForm);
	if (FrmGetObjectType(originalForm, focusObj) == frmFieldObj)
		{
		systemKeyboard->originalFieldP = 
			FrmGetObjectPtr(originalForm, focusObj);
		}
	else
		{
		// A table has the focus.  Find it's field object.
		// The keyboard checks for a field in it before appearing.
		ErrFatalDisplayIf(FrmGetObjectType(originalForm, focusObj) != 
			frmTableObj, "An unhandled type of object has the focus.");
		systemKeyboard->originalFieldP = TblGetCurrentField(
			FrmGetObjectPtr(originalForm, focusObj));
		}
		
	frm = FrmInitForm (formID);
	
	// Now set the keyboard's text field to use the original text field
	textFieldP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardTextField));
	FldSetMaxChars(textFieldP, 
		FldGetMaxChars(systemKeyboard->originalFieldP));
	FldGetAttributes(systemKeyboard->originalFieldP, &attr);
	attr.visible = false;
	attr.hasFocus = false;
	attr.dynamicSize = false;
	FldSetAttributes(textFieldP, &attr);
	FldSetFont(textFieldP, FldGetFont(systemKeyboard->originalFieldP));
	
	// Save these while the field has data
	scrollPosition = FldGetScrollPosition (systemKeyboard->originalFieldP);
	insPtPosition = FldGetInsPtPosition (systemKeyboard->originalFieldP);
	FldGetSelection(systemKeyboard->originalFieldP, &startPosition, &endPosition);
	FldSetSelection(systemKeyboard->originalFieldP, 0, 0);

	// Get the current height of the field, so that we can check later if the 
	// height has changed.
	systemKeyboard->originalHeight = GetFieldHeight (systemKeyboard, 
		FldGetTextPtr (systemKeyboard->originalFieldP));


	textH = FldGetTextHandle(systemKeyboard->originalFieldP);
	if (textH)
		{
		systemKeyboard->originalFieldOffset = (UInt) (FldGetTextPtr(systemKeyboard->originalFieldP)
			- (CharPtr) MemHandleLock(textH) );
		MemHandleUnlock(textH);
		systemKeyboard->originalFieldBlockSize = FldGetTextAllocatedSize (
			systemKeyboard->originalFieldP);
		}
	else
		{
		systemKeyboard->originalFieldOffset = 0;
		systemKeyboard->originalFieldBlockSize = 0;
		}
	
	// Remove the text field from the original field so it
	// unlocks it and set the new field to use the text.
	FldSetTextHandle(systemKeyboard->originalFieldP, 0);
	FldSetText(textFieldP, textH, systemKeyboard->originalFieldOffset, 
		systemKeyboard->originalFieldBlockSize);
		
	// Setting the text of a field will clear its dirty attribute,  so we have to
	// reset it.
	FldSetDirty (textFieldP, (attr.dirty == true));

	// Set the scroll position and insertion point to the same place
	// as in the edited field.
	FldSetScrollPosition(textFieldP, scrollPosition);
	if (startPosition == endPosition)
		FldSetInsPtPosition(textFieldP, insPtPosition);
	else
		FldSetSelection(textFieldP, startPosition, endPosition);
	

	FrmSetFocus(frm, FrmGetObjectIndex (frm, KeyboardTextField));


	// Set the highlight the pushbutton of the keyboard in use		
	pControl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardAbcPushBtn) + 
		systemKeyboard->currentKeyboard);
	CtlSetValue(pControl, true);

	KeyboardUpdateScrollers(frm);


	return frm;			// return the keyboard form
}


/***********************************************************************
 *
 * FUNCTION:    KeyboardFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the Keyboard Form
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *					 systemKeyboard - the keyboard status info
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	3/29/95	Initial Revision
 *
 ***********************************************************************/
 
static Boolean KeyboardFormHandleEvent (EventPtr event)
{
	FormPtr frm;
	Boolean handled = false;
	KeyboardLayout *k;
	FieldPtr textFieldP;
	EventType newEvent;
	KeyboardStatus *systemKeyboard;


	frm = FrmGetActiveForm ();
	systemKeyboard = FrmGetGadgetData (frm, FrmGetObjectIndex (frm, 
		KeyboardGadget));

	if (KbdHandleEvent (systemKeyboard, event))
		return true;
		
		
	else if (event->eType == ctlRepeatEvent)
		{		
		switch (event->data.ctlRepeat.controlID)
			{
			case KeyboardUpButton:
				KeyboardScroll (up, true);
				// leave unhandled so the buttons can repeat
				break;
				
			case KeyboardDownButton:
				KeyboardScroll (down, true);
				// leave unhandled so the buttons can repeat
				break;
			}
		}


	else if (event->eType == ctlSelectEvent)
		{
		if (event->data.ctlSelect.controlID == KeyboardDoneButton)
			{
			// Set the event to close so the parent routine closes
			// the dialog.			
			MemSet (&newEvent, sizeof(EventType), 0);
			newEvent.eType = frmCloseEvent;
			newEvent.data.frmOpen.formID = KeyboardForm;
			EvtAddEventToQueue (&newEvent);
			return true;
			}
				
		systemKeyboard->shiftOn = false;
		systemKeyboard->capsOn = false;
			
		// erase the existing keyboard
		k = systemKeyboard->layout[systemKeyboard->currentKeyboard];
		while (true)
			{
			WinEraseRectangle (&k->bounds, 0);
			if (k->lastLayoutInKeyboard)
				break;
			else
				k++;
			}

		switch (event->data.ctlSelect.controlID)
			{
			case KeyboardAbcPushBtn:
				systemKeyboard->currentKeyboard = kbdAlpha;				
				break;
				
			case Keyboard123PushBtn:
				systemKeyboard->currentKeyboard = kbdNumbersAndPunc;
				break;
				
			case KeyboardIntlPushBtn:
				systemKeyboard->currentKeyboard = kbdAccent;
				break;	
			}
		// draw the current keyboard.
		KbdDraw(systemKeyboard, false);
		}


	else if (event->eType == keyDownEvent)
		{
		frm = FrmGetActiveForm();
		textFieldP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardTextField));
		switch (event->data.keyDown.chr)
			{
			case pageUpChr:
				KeyboardScroll (up, false);

				handled = true;
				break;
				
			case pageDownChr:
				KeyboardScroll (down, false);

				handled = true;
				break;

			default:
				frm = FrmGetActiveForm ();
				FrmHandleEvent (frm, event);

				KeyboardUpdateScrollers(frm);
				handled = true;
			}
		}


	else if (event->eType == menuEvent)
		{
		return KeyboardFormDoCommand (event->data.menu.itemID);
		}

		
	else if (event->eType == frmCloseEvent)
		{
		return true;
		}
		
	else if (event->eType == frmOpenEvent)
		{
		frm = FrmGetActiveForm ();
		FrmDrawForm (frm);
		KbdDraw(systemKeyboard, false);
		FrmSetFocus(frm, FrmGetObjectIndex (frm, KeyboardTextField));
		handled = true;
		}
		
	else if (event->eType == frmUpdateEvent)
		{
		FrmDrawForm (frm);
		KbdDraw(systemKeyboard, false);
		handled = true;
		}
		
	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:    SysKeyboardDialogV10
 *
 * DESCRIPTION: This routine pops up the system keyboard if there
 * 	is a field object with the focus.  The field object's text
 *		chunk is edited directly.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    The field's text chunk is changed.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	4/27/95	Initial Revision
 *			rsf	6/25/96	Changed to call new version
 *
 ***********************************************************************/
 
extern void SysKeyboardDialogV10 ()
{
	SysKeyboardDialog(kbdAlpha);
}




/************************************************************
 *
 *  FUNCTION: PrvLaunchGraffitiDemo()
 *
 *  DESCRIPTION: Launches the Graffiti Demo App
 *
 *  PARAMETERS: 
 *
 *  RETURNS: void
 * 
 *  CALLED BY: GrfProcessStroke
 *
 *  CREATED: 1/7/97
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void		PrvLaunchGraffitiDemo(void)
{
	DmSearchStateType	state;
	Err					err;
	UInt					cardNo;
	LocalID				dbID;
	
	err = DmGetNextDatabaseByTypeCreator(true, &state, 
		sysFileTApplication, sysFileCGraffitiDemo, true, &cardNo, &dbID);
		
	// If not found, return;
	if (err)  return;

	// Otherwise, try and switch apps.
	if (dbID) 
		SysUIAppSwitch(cardNo, dbID, 0, 0);
}



/***********************************************************************
 *
 * FUNCTION:    SysKeyboardDialog
 *
 * DESCRIPTION: This routine pops up the system keyboard if there
 * 	is a field object with the focus.  The field object's text
 *		chunk is edited directly.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    The field's text chunk is changed.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	4/27/95	Initial Revision
 *
 ***********************************************************************/
 
extern void SysKeyboardDialog (KeyboardType kbdType)
{
	EventType event;
	FormPtr frm, originalForm;
	WinHandle winH;
	Boolean insPtState;
	Handle textFieldH;
	FieldPtr textFieldP;
	FieldAttrType attr;
	Word focusObj;
	Boolean textFieldDirty;
	KeyboardLayout *layout;
	KeyboardStatus systemKeyboard;
	Handle keyboardResourceH;
	Word tempShift;		// graffiti temp shift state
	Word newScrollPosition, newInsPtPosition;
	CharPtr textP;
	Short newHeight;
	Boolean numLockMode;
	Word error;
	Boolean junk;
	Word startPosition;
	Word endPosition;
	

	if (GSysMiscFlags & sysMiscFlagGrfDisable) {
		if (!(GSysMiscFlags & sysMiscFlagInDemoAlert)) {
			GSysMiscFlags |= sysMiscFlagInDemoAlert;
			if (FrmAlert(DemoUnitAlert) == 0)  	// Go To Graffiti app
				PrvLaunchGraffitiDemo();
			GSysMiscFlags &= ~sysMiscFlagInDemoAlert;
			}
		return;
		}

	// Compare the active form's window to the active window
	// This should prevent
	originalForm =  FrmGetActiveForm();
	winH = WinGetActiveWindow();
	if (winH != WinGetWindowHandle(originalForm))
		{
		SndPlaySystemSound(sndError);
		return;
		}
		
	// If there isn't a text field with the focus set then leave
	focusObj = FrmGetFocus(originalForm);
	if (focusObj == noFocus)
		{
		SndPlaySystemSound(sndError);
		return;
		}
		
	// If the table doesn't have a field then leave
	if (FrmGetObjectType(originalForm, focusObj) == frmTableObj)
		{
		textFieldP = TblGetCurrentField(FrmGetObjectPtr(originalForm, focusObj));
		if (textFieldP == NULL)
			{
			SndPlaySystemSound(sndError);
			return;
			}
		}
	else
		textFieldP = FrmGetObjectPtr(originalForm, focusObj);
	
	// Now make sure that the field is editable.
	FldGetAttributes(textFieldP, &attr);
	if (!attr.editable || !attr.usable)
		{
		SndPlaySystemSound(sndError);
		return;
		}
	
	
	
	// The the text field has passed our checks that editting it is valid.
	
	// Turn off Graffiti while the keyboard is active
	EvtEnableGraffiti(false);

	// Turn off the blinking insertion point
	insPtState = InsPtEnabled();
	InsPtEnable (false);


	// Set up the onscreen keyboard
	GrfGetState(&systemKeyboard.capsOn, &numLockMode, &tempShift, &junk);
	if (kbdType == kbdDefault)
		{
		if (attr.numeric || numLockMode)
			systemKeyboard.currentKeyboard = 1;		// use the number keyboard
		else
			systemKeyboard.currentKeyboard = 0;		// use the alpha keyboard
		}
	else
		systemKeyboard.currentKeyboard = kbdType;

	systemKeyboard.shiftOn = (tempShift == grfTempShiftUpper) ||
		(tempShift == grfTempShiftLower);
	systemKeyboard.originalFieldP = NULL;
	keyboardResourceH = DmGetResource (kbdRscType, SystemKeyboardID);
	ErrFatalDisplayIf(!keyboardResourceH, 
		"Missing system keyboard resource (Keyboard.rsrc).");
	systemKeyboard.kbdResource = MemHandleLock(keyboardResourceH);

	layout = (KeyboardLayout *) systemKeyboard.kbdResource;
	systemKeyboard.layout[0] = layout;
	
	// Advance through the layouts to the next keyboard
	while (!layout->lastLayoutInKeyboard)
		layout++;
	layout++;
	systemKeyboard.layout[1] = layout;
	
	// Advance through the layouts to the next keyboard
	while (!layout->lastLayoutInKeyboard)
		layout++;
	layout++;
	systemKeyboard.layout[2] = layout;
	
	
	frm = KeyboardFormInit (KeyboardForm, &systemKeyboard);
	FrmSetActiveForm (frm);

	// Store the keyboard info in the keyboard gadget.
	FrmSetGadgetData (frm, FrmGetObjectIndex (frm, KeyboardGadget), 
		&systemKeyboard);

	// Set the event handler.
	FrmSetEventHandler (frm, KeyboardFormHandleEvent);
	
	// make a frmOpenEvent for the keyboard form.
	MemSet (&event, sizeof(EventType), 0);
	event.eType = frmOpenEvent;
	event.data.frmOpen.formID = KeyboardForm;
	EvtAddEventToQueue (&event);


	// Event loop for the system keyboard form
	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		
		if (!(event.eType == keyDownEvent && 
			(event.data.keyDown.chr == keyboardChr ||
			event.data.keyDown.chr == keyboardAlphaChr ||
			event.data.keyDown.chr == keyboardNumericChr)))
			if (!SysHandleEvent(&event))
				if (! MenuHandleEvent (0, &event, &error))
					FrmDispatchEvent (&event); 
				
		if ((event.eType == frmCloseEvent && 
			event.data.frmClose.formID == KeyboardForm))
			break;
			
		if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}


	// Remove the keyboard form.  The user may have pressed the Ok button or
	// they may be switching to another application.
	frm = FrmGetActiveForm();
	
	// Get the data from the keyboard's text field before the from is deleted
	textFieldP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, KeyboardTextField));
	textFieldH  = FldGetTextHandle(textFieldP);
	textFieldDirty = FldDirty(textFieldP);
	newScrollPosition = FldGetScrollPosition(textFieldP);
	newInsPtPosition = FldGetInsPtPosition(textFieldP);
	FldGetSelection(textFieldP, &startPosition, &endPosition);
	systemKeyboard.originalFieldBlockSize = FldGetTextAllocatedSize (textFieldP);
	FldSetTextHandle(textFieldP, 0);		// Unlocks the text string handle
	
	FrmEraseForm (frm);
	FrmDeleteForm (frm);


	// First set the original text object to match how
	// the user has modified the keyboard's text object
	FldSetText(systemKeyboard.originalFieldP, textFieldH,
		systemKeyboard.originalFieldOffset, 
		systemKeyboard.originalFieldBlockSize);
	FldSetDirty(systemKeyboard.originalFieldP, textFieldDirty);


	FrmSetActiveForm (originalForm);

		
	// Check if the height if the field has changed,  if it has then send a fldHeightChange
	// event,  if is has not changed then send a fldChange event.
	textP = FldGetTextPtr (systemKeyboard.originalFieldP);
	newHeight = GetFieldHeight (&systemKeyboard, textP);
	FldGetAttributes(systemKeyboard.originalFieldP, &attr);
	if (attr.singleLine || (! attr.dynamicSize) || systemKeyboard.originalHeight == newHeight)
		{
		FldSetScrollPosition (systemKeyboard.originalFieldP, newScrollPosition);
		if (startPosition == endPosition)
			FldSetInsPtPosition (systemKeyboard.originalFieldP, newInsPtPosition);
		else
			InsPtEnable(false);
		FldDrawField (systemKeyboard.originalFieldP);
		FldSendChangeNotification (systemKeyboard.originalFieldP);
		}
	else
		{
		FldRecalculateField (systemKeyboard.originalFieldP, true);
		FldSendHeightChangeNotification (systemKeyboard.originalFieldP, 
			newInsPtPosition, newHeight);
		}
	FldSetSelection(systemKeyboard.originalFieldP, startPosition, endPosition);


	MemHandleUnlock(keyboardResourceH);
	EvtEnableGraffiti(true);
}

