/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------  
 * FileName:
 *		DataMgr.c
 *
 * Description:
 *		Data Management routines
 *
 * History:
 *   	11/14/94  RM - Created by Ron Marianetti
 *
 *******************************************************************/


#include <SysAll.h>
#include <FeatureMgr.h>
#include <AlarmMgr.h>


// Set this to get to private database defines
#define	NON_PORTABLE
#include <SystemPrv.h>
#include <DataPrv.h>

/************************************************************
 * Private routines used only in this module
 *************************************************************/
static void  				PrvSetUniqueID(DatabaseHdrPtr hdrP, RecordEntryPtr recordP);

static LocalID				PrvFindDatabaseInStore(UInt cardNo, UInt storeNum,
									const Char * const nameP);
		
static RecordEntryPtr	PrvRecordEntryPtr(DmOpenInfoPtr openP, UInt index, 
									RecordEntryPtr	prevRecordP);

static RsrcEntryPtr		PrvRsrcEntryPtr(DmOpenInfoPtr openP, UInt index,
									RsrcEntryPtr	prevRsrcP);
		
static Err					PrvShiftEntriesUp(DmOpenRef dbR, UInt startIndex, 
									UInt shiftSize, Boolean adjustSize);

static Err					PrvShiftEntriesDown(DmOpenRef dbR, UInt startIndex, 
									UInt shiftSize, Boolean adjustSize);

static RecordListPtr		PrvPrevRecordList(DmOpenInfoPtr openP, RecordListPtr currentP);
		
static Err					PrvMergeFree(Word	cardNo, DWord reqSize);

static Handle				PrvDmHandleRealloc(DmOpenRef dbR, Handle oldH, 
										Handle newH, DWord size);

/************************************************************
 *
 *  FUNCTION: DmInit
 *
 *  DESCRIPTION: Initializes the data manager. Currently,
 *   the only thing we do is free all records in the Storage
 *		heaps which have been orphaned. A chunk is orphaned if it
 *    was detached from a database or created and never attached.
 *   Orphaned records have a unique owner ID of dmOrphanOwnerID.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 8/1/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmInit()
{
	UInt	card;
	UInt	i, heapID, numHeaps;
	
	
	//------------------------------------------------------------
	// Go through and free all orphaned Data Manager chunks.
	//------------------------------------------------------------
	for (card=0; card < MemNumCards(); card++) {
		
		numHeaps = MemNumRAMHeaps(card);  
		for (i=0; i<numHeaps; i++) {
			heapID = MemHeapID(card, i);
			if (MemHeapDynamic(heapID)) continue;
			MemHeapFreeByOwnerID(heapID, dmOrphanOwnerID);
			}
			
		}


	return 0;

}



/************************************************************
 *
 *  FUNCTION: DmCreateDatabase
 *
 *  DESCRIPTION: Creates a new database on the specified card with
 *		the given name, creator, and type
 *
 *  PARAMETERS: card number, name of database, creator, type
 *
 *  RETURNS: 0 if successful, errorcode if not
 *
 *  CREATED: 11/14/94 
 *
 *  BY: Ron Marianetti
 *		kcr		9/27/95		seed record ID's with semi-random number
 *		kcr		12/7/95		check for NULL database name; initialize version
 *									to 0.
 *		vmk		12/2/96		Added name length check
 *		vmk		12/22/97		Removed explicit compaction and free space check(perf optimization)
 *
 *************************************************************/
Err	DmCreateDatabase(UInt cardNo, const Char * const nameP, 
				ULong creator, ULong type, Boolean resDB)
{
	//ULong				freeBytes, maxChunk;
	//ULong				maxFree;

	UInt				heapID, theHeap, numHeaps, numEntries;
	DatabaseHdrPtr	headerP=0, *headerH=0;
	LocalID			headerID=0, dirID;
	Err 				err = dmErrMemError;
	Int				i;
	DatabaseDirPtr	dirP=0, *dirH;
	ULong				reqSize, actSize;


	// Grab the semaphore for exclusive access
	MemSemaphoreReserve(true);
	

	// Make sure this database doesn't already exist in the RAM store
	// or has an invalid name
	if ((! *nameP) || StrLen(nameP) >= dmDBNameLength)
		{
		err = dmErrInvalidDatabaseName;
		goto Exit;
		}
	if (PrvFindDatabaseInStore(cardNo, 1, nameP)) {
		err = dmErrAlreadyExists;
		goto Exit;
		}


	//------------------------------------------------------------
	// Allocate the database header in the heap with the most free space
	//------------------------------------------------------------

	#if 0		// REMOVED TO OPTIMIZE FOR PERFORMANCE -- heap compaction and free byte
				// checking takes TOO long in the current memory manager
		numHeaps = MemNumRAMHeaps(cardNo);
		theHeap = 0;
		maxFree = 0;
		for (i=0; i < numHeaps; i++) {
			heapID = MemHeapID(cardNo, i);
			
			// Don't allocate in the dynamic heap
			if (MemHeapDynamic(heapID))
				continue;

			MemHeapCompact(heapID);
			MemHeapFreeBytes(heapID, &freeBytes, &maxChunk);
			if (maxChunk > maxFree) {
				theHeap = heapID;
				maxFree = maxChunk;
				}
			}
		if (theHeap) 
			headerH = MemChunkNew(theHeap, sizeof(DatabaseHdrType), dmMgrOwnerID);
		else
			headerH = 0;
	#endif	// REMOVED TO OPTIMIZE FOR PERFORMANCE


	//#if 0
		// Allocate the database header
		//
		// allocate from the first storage heap with sufficient free space;
		// this works partucularly well on cards with only 1 storage heap,
		// as is the case now with the new large heap memory model
		// DOLATER... need to re-examine when we have enough RAM store to necessitate
		// multiple storage heaps again
		numHeaps = MemNumRAMHeaps(cardNo);
		theHeap = 0xFFFF;
		headerH = 0;
		for (i=0; i < numHeaps; i++) {
			heapID = MemHeapID(cardNo, i);
			
			// Don't allocate in the dynamic heap
			if (MemHeapDynamic(heapID))
				continue;
			
			// attempt to allocate from this storage heap
			headerH = MemChunkNew(heapID, sizeof(DatabaseHdrType), dmMgrOwnerID);
			if ( headerH ) {
				theHeap = heapID;
				break;
				}
			}
	//#endif
	
	if (!headerH)
		goto Exit;



	//------------------------------------------------------------
	// Fill in the header
	//------------------------------------------------------------
	headerP = MemHandleLock(headerH);

	StrCopy((CharPtr)headerP->name, nameP);
	headerP->attributes = 0;
	if (resDB) headerP->attributes |= dmHdrAttrResDB;
	headerP->version = 0;
	headerP->creationDate = TimGetSeconds();
	headerP->modificationDate = TimGetSeconds();
	headerP->lastBackupDate = 0;
	headerP->modificationNumber = 0;
	headerP->appInfoID = 0;
	headerP->sortInfoID = 0;
	headerP->type = type;
	headerP->creator = creator;

	//	High order bits of uniqueID are seeded with 12
	//	low-order bits of system tick count.
	// TimeGetTicks is reset after a soft or hard reset.
	// TimGetSeconds is reset after a hard reset only if it's value is out 
	//  of range.  This happens when the batteries fail.
	// SysRandom is initialized by xoring part of the store memory before
	//  it is wiped during a hard reset.  The result is a somewhat random word.
	// The values for the high bits 0 and 1 are reserved. 
	//  0 is reserved for default records copied from default databases.
	do
		{
		headerP->uniqueIDSeed = TimGetSeconds () ^ TimGetTicks () ^ SysRandom(0);
		} while (headerP->uniqueIDSeed <= dmRecordIDReservedRange);
		
	headerP->uniqueIDSeed = headerP->uniqueIDSeed << 12;
	headerP->uniqueIDSeed &= 0x00FFF000;		//	Isolate 12 seed bits.

	headerP->recordList.nextRecordListID = 0;
	headerP->recordList.numRecords = 0;


	//------------------------------------------------------------
	// Add the new database to the directory
	//------------------------------------------------------------
	// Get the database directory ID for the RAM area
	err = MemStoreInfo(cardNo, 1, 
				0, 0, 0, 
				0, 0, 
				0, 0, 
				0, &dirID);
	if (err)
		goto Exit;

	
	// If no directory yet, add one
	// DOLATER... this area is troublesome if new fails when there are
	// multiple storage heaps -- it does not try to allocate from another
	if (!dirID) {
		dirH = MemChunkNew(theHeap, sizeof(DatabaseDirType), dmMgrOwnerID);
		if (!dirH)
			goto Exit;
		dirID = MemHandleToLocalID(dirH);
		err = MemStoreSetInfo(cardNo, 1,
				0, 0, 0, 
				0, 0,
				0, 0,
				0, &dirID);
		if (err)
			goto Exit;
		dirP = MemHandleLock(dirH);
		dirP->numDatabases = 0;
		dirP->nextDatabaseListID = 0;
		}
	else {
		dirH = MemLocalIDToGlobal(dirID, cardNo);
		dirP = MemHandleLock(dirH);
		}

	
	// Resize the directory chunk if necessary
	// DOLATER... this area is troublesome if new fails when there are
	// multiple storage heaps -- it does not try to reallocate from another
	numEntries = dirP->numDatabases + 1;
	actSize = MemHandleSize(dirH);
	reqSize = sizeof(DatabaseDirType) + numEntries * sizeof(LocalID);
	if (reqSize > actSize) {
		MemHandleUnlock(dirH);
		err = MemHandleResize(dirH, reqSize);
		dirP = MemHandleLock(dirH);
		if (err)
			goto Exit;
		}


	// Add the database to the directory
	dirP->numDatabases = numEntries;
	dirP->databaseID[numEntries-1] = MemHandleToLocalID(headerH);
	err = 0;


Exit:
	if (headerP)
		MemPtrUnlock(headerP);
	if (dirP)
		MemPtrUnlock(dirP);
	
	if (err) {
		if (headerH)
			MemHandleFree(headerH);
		}

	MemSemaphoreRelease(true);
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmCreateDatabaseFromImage
 *
 *  DESCRIPTION: Can be called to create an entire database
 *			from a single resource that contains in image of the database. 
 *			Usually, this would be called from an app's reset action code during
 *			boot.
 *
 *  PARAMETERS: 
 *			bufferP - pointer to locked resource containing image of the database
 *
 *  RETURNS: void
 *
 *  CREATED: 3/13/95
 *
 *  BY: Ron Marianetti
 *
 *		vmk	12/29/97	Fixed to return non-zero error code in case of failure
 *
 *************************************************************/
Err	DmCreateDatabaseFromImage(Ptr bufferP)
{
	ULong				size;
	LocalID			dbID=0;
	DmOpenRef		dbP=0;
	Err				err = 0;
	BytePtr			srcP;
	BytePtr			dstP;
	DatabaseHdrPtr	hdrP = (DatabaseHdrPtr)bufferP;
	UInt				i;
	DWord				uniqueIDSeed;
		
		
	// Get the size and create it
	size = MemPtrSize(hdrP);
	err = DmCreateDatabase(0, (CharPtr)hdrP->name, hdrP->creator, hdrP->type, 
						hdrP->attributes & dmHdrAttrResDB);
	if (err)
		goto Exit;
	
	
	
	// Set Database info
	dbID = DmFindDatabase(0, (CharPtr)hdrP->name);
	if (!dbID) {
		err = dmErrCantFind;
		goto Exit;
		}
	err = DmSetDatabaseInfo(0, dbID, 0,
				&hdrP->attributes, &hdrP->version, &hdrP->creationDate,
				&hdrP->modificationDate, &hdrP->lastBackupDate,
				&hdrP->modificationNumber, 0,
				0, &hdrP->type,
				&hdrP->creator);
	if (err)
		goto Exit;
	
	
	
	// Open the new database
	dbP = DmOpenDatabase(0, dbID, dmModeReadWrite);
	if (!dbP) {
		err = dmErrCantOpen;
		goto Exit;
		}

	
	// The new database has been created with a random number in it.
	// We don't want the records copied into the new database to have
	// different unique id's between each hard reset or else the records
	// with the same contents but with different unique id's will appear
	// distinct to HotSync and so will accumulate with hard resets and syncs.
	// To stop this behavior we always set the seed to a constant number,
	// copy the records into the new database, and then we restore the
	// random seed.
	MemSemaphoreReserve(true);
	uniqueIDSeed = ((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed;
	((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed = dmDefaultRecordsID << 12;
	MemSemaphoreRelease(true);
	

	//------------------------------------------------------------
	// If it's a resource database, Add the Resources
	//------------------------------------------------------------
	if (hdrP->attributes & dmHdrAttrResDB) {
		RsrcEntryPtr	rsrcP;
		ULong				resSize;
		Handle			newResH;

		// Pointer to first resource
		rsrcP  = (RsrcEntryPtr)(&hdrP->recordList.firstEntry);
		for (i=0; i<hdrP->recordList.numRecords; i++) {
		
			// Calculate the size of the resource
			if (i < hdrP->recordList.numRecords - 1) {
				resSize = (ULong)rsrcP[1].localChunkID;
				resSize -= (ULong)rsrcP[0].localChunkID;
				}
			else
				resSize = size - (ULong)rsrcP[0].localChunkID;
			

			// Allocate the new resource
			newResH = DmNewResource(dbP, rsrcP->type, rsrcP->id, resSize);
			if (!newResH) {
				err = dmErrMemError;
				goto Exit;
				}
	
			// Copy the data in
			srcP = (BytePtr)bufferP + (ULong)rsrcP->localChunkID;
			dstP = (BytePtr)MemHandleLock(newResH);
			DmWrite(dstP, 0, srcP, resSize);
			MemHandleUnlock(newResH);
	
			// Done with it
			DmReleaseResource(newResH);
	
			// next one
			rsrcP++;
			}
		}



	//------------------------------------------------------------
	// If it's a Record database, Add the Records
	//------------------------------------------------------------
	else {
		Handle			newRecH;
		RecordEntryPtr	recordP;
		ULong				recSize;
		LocalID			appInfoID;
		
		// Pointer to first record
		recordP  = (RecordEntryPtr)(&hdrP->recordList.firstEntry);
		

		// If there's an appInfo, add that
		if (hdrP->appInfoID) {
			if (hdrP->sortInfoID) recSize = (ULong)hdrP->sortInfoID - (ULong)hdrP->appInfoID;
			else recSize = (ULong)recordP[0].localChunkID - (ULong)hdrP->appInfoID;
			
			// Allocate the chunk
			newRecH = (Handle)DmNewHandle(dbP, recSize);
			if (!newRecH) {
				err = dmErrMemError;
				goto Exit;
				}
				
			// Copy the data in
			srcP = (BytePtr)bufferP + (ULong)hdrP->appInfoID;
			dstP = (BytePtr)MemHandleLock(newRecH);
			DmWrite(dstP, 0, srcP, recSize);
			MemHandleUnlock(newRecH);
			
			// Store it in the header
			appInfoID = MemHandleToLocalID(newRecH);
			DmSetDatabaseInfo(0, dbID, 0,
				0, 0, 0,
				0, 0,
				0, &appInfoID,
				0, 0, 
				0);
			}
			
			

		// Add Each of the records.
		for (i=0; i<hdrP->recordList.numRecords; i++) {
			UInt		index;
			UInt		attr;
			ULong		id;
			
			// Calculate the size of the record
			if (i < hdrP->recordList.numRecords - 1) {
				recSize = (ULong)recordP[1].localChunkID;
				recSize -= (ULong)recordP[0].localChunkID;
				}
			else
				recSize = size - (ULong)recordP[0].localChunkID;
			

			// Only add non-nil records. When the default databases are created
			//  they sometimes have nil records if the user had to delete a
			//  record they didn't want.
			if (recSize) {
				// Allocate the new record
				index = 0xFFFF;
				newRecH = (Handle)DmNewRecord(dbP, &index, recSize);
				if (!newRecH) {
				err = dmErrMemError;
				goto Exit;
				}
		
				// Copy the data in
				srcP = (BytePtr)bufferP + (ULong)recordP->localChunkID;
				dstP = (BytePtr)MemHandleLock(newRecH);
				DmWrite(dstP, 0, srcP, recSize);
				MemHandleUnlock(newRecH);
						
				// Set the attributes
				attr = recordP->attributes;
				id = recordP->uniqueID[0];
				id = (id << 8) | recordP->uniqueID[1];
				id = (id << 8) | recordP->uniqueID[2];
				DmSetRecordInfo(dbP, index, &attr, &id);
		
				// Done with it
				DmReleaseRecord(dbP, index, true);
				}
		
			// next one
			recordP++;
			}
		}
		
		
	// Fixup the modification # to match what was in the image.
	DmSetDatabaseInfo(0, dbID, 0,
				0, 0,0,
				0, 0,
				&hdrP->modificationNumber, 0,
				0, 0,
				0);

	
	// Restore the database's uniqueIDSeed to it's random value.
	MemSemaphoreReserve(true);
	((DmAccessPtr)dbP)->openP->hdrP->uniqueIDSeed = uniqueIDSeed;
	MemSemaphoreRelease(true);
	
	// If we got to here, no error 
	DmCloseDatabase(dbP);
	dbP = 0;
		

Exit:
	if (dbP) {
		DmCloseDatabase(dbP);
		if (dbID)
			DmDeleteDatabase(0, dbID);
		}
		
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmDeleteDatabase
 *
 *  DESCRIPTION: Deletes a database and all it's records
 *
 *  PARAMETERS: database ID
 *
 *  RETURNS: 0 if no error cj_kpcopyr
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	9/10/97	Added code to delete alarms that may be associated
 *							with the database being deleted.
 *
 *************************************************************/
Err	DmDeleteDatabase(UInt cardNo, LocalID dbID)
{
	DmAccessPtr			accessP=0;
	DmOpenInfoPtr		openP = 0;
	DatabaseDirPtr		dirP=0, *dirH = 0;
	LocalID				dirID = 0;
	UInt					i;
	Err					err = 0;
	ULong					reqSize;
	UInt					numRecords, index;
	DatabaseHdrHand	dbH;
	Handle				h;
	
	
	// If this is a ROM database, we can't delete it
	if (MemLocalIDKind(dbID) != memIDHandle) {
		return dmErrROMBased;
		}


	// Grab the semaphore 
	MemSemaphoreReserve(true);


	// Make sure this database is not open
	openP = (DmOpenInfoPtr)GDmOpenList;
	while(openP) {
		if (openP->hdrID == dbID && openP->cardNo == cardNo) break;
		openP = (DmOpenInfoPtr)openP->next;
		}

	// if it's open exit with error
	if (openP) { 
		openP = 0; 
		err = dmErrDatabaseOpen; 
		goto Exit;
		}


	// Make sure this database is not protected
	if (GDmProtectListH) {
		DmProtectEntryPtr	entryP;
		UInt					numEntries;
		
		// Lock down list of protected databases
		err = 0;
		entryP = MemHandleLock(GDmProtectListH);
		numEntries = MemPtrSize(entryP) / sizeof(DmProtectEntryType);
		
		// See if this database is one of the protected ones
		for (; numEntries; entryP++, numEntries--) {
			if (entryP->cardNo == cardNo && entryP->dbID == dbID) {
				err = dmErrDatabaseProtected;
				break;
				}
			}
		
		// Unlock list and exit if protected
		MemHandleUnlock(GDmProtectListH);
		if (err)
			goto Exit;
		}



	// First, delete all the records
	accessP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
	if (!accessP) {
		err = dmErrCantOpen;
		goto Exit;
		}

	if (accessP->openP->resDB) {
		numRecords = DmNumResources(accessP);
		while(numRecords--) {
			err = DmRemoveResource(accessP, numRecords);
			if (err)
				break;
			}
		}

	else {
		numRecords = DmNumRecords(accessP);
		while(numRecords--) {
			err = DmRemoveRecord(accessP, numRecords);
			if (err)
				break;
			}
		}

	if (err)
		goto Exit;
	
	
	
	// Delete the sortInfo and appInfo chunks, if allocated
	openP = accessP->openP;
	if (openP->hdrP->appInfoID) {
		h = MemLocalIDToGlobal(openP->hdrP->appInfoID, openP->cardNo);
		MemHandleFree(h);
		}
	if (openP->hdrP->sortInfoID) {
		h = MemLocalIDToGlobal(openP->hdrP->sortInfoID, openP->cardNo);
		MemHandleFree(h);
		}
		


	// Close the database
	DmCloseDatabase(accessP);
	accessP = 0;


	//----------------------------------------------------------------
	// Remove it from the directory
	//----------------------------------------------------------------
	err = MemStoreInfo(cardNo, 1, 
				0, 0, 0, 
				0, 0, 
				0, 0, 
				0, &dirID);
	if (err) {
		err = dmErrCantFind;
		goto Exit;
		}

	dirH = MemLocalIDToGlobal(dirID, cardNo);
	dirP = MemHandleLock(dirH);
	for (i=0; i<dirP->numDatabases; i++) {
		if (dirP->databaseID[i] == dbID)
			break;
		}
	if (i >= dirP->numDatabases) {
		err =  dmErrCantFind;
		goto Exit;
		}

	index = i;
	for (i=index; i<dirP->numDatabases-1; i++) 
		dirP->databaseID[i] = dirP->databaseID[i+1];

	dirP->numDatabases--;



	// Resize the directory chunk
	reqSize = sizeof(DatabaseDirType) + dirP->numDatabases * sizeof(LocalID);
	MemHandleUnlock(dirH);
	err = MemHandleResize(dirH, reqSize);
	dirP = MemHandleLock(dirH);


	// Free the database header chunk
	dbH = MemLocalIDToGlobal(dbID, cardNo);
	MemHandleFree(dbH);

	
Exit:
	if (dirP)
		MemPtrUnlock(dirP);
	
	if (accessP)
		DmCloseDatabase(accessP);
	
	MemSemaphoreRelease(true);
	
	//
	// Call the Alarm Manager to delete an alarm associated with
	// this databse, if any.  We're not concerned with the AlmSetAlarm
	// return value.	vmk	9/10/97
	//
	
	// Make sure the database was deleted (the database could have been open, locked, etc.)
	// and the Alarm Manager is initialized 
	if ( err == 0 && GAlmGlobalsP ) {
		AlmSetAlarm(cardNo, dbID, 0/*user ref value*/, 0/*zero clears alarm*/, true/*quiet*/);
		}
	return err;

}



/************************************************************
 *
 *  FUNCTION: DmNumDatabases
 *
 *  DESCRIPTION: Returns the number of databases on a card
 *
 *  PARAMETERS: card number
 *
 *  RETURNS: Number of databases found
 *
 *  CREATED: 11/14/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	DmNumDatabases(UInt cardNo)
{

	UInt				numEntries = 0;
	DatabaseDirPtr	dirP, *dirH;
	LocalID			dirID;
	Err				err;
	
	// Get semaphore
	MemSemaphoreReserve(false);


	// Get the database directory ID for the ROM area
	err = MemStoreInfo(cardNo, 0, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
	if (!err && dirID) {
		dirP = MemLocalIDToGlobal(dirID, cardNo);
		if (dirP)  {
			numEntries = dirP->numDatabases;
			}
		}

	// Get the database directory ID for the RAM area
	err = MemStoreInfo(cardNo, 1, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
	if (!err && dirID) {
		dirH = MemLocalIDToGlobal(dirID, cardNo);
		if (dirH)  {
			dirP = MemHandleLock(dirH);
			numEntries += dirP->numDatabases;
			MemPtrUnlock(dirP);
			}
		}

	// Release semaphore
	MemSemaphoreRelease(false);
	return numEntries;			 
}



/************************************************************
 *
 *  FUNCTION: DmGetDatabase
 *
 *  DESCRIPTION: Returns a database header ID by index and card number
 *
 *  PARAMETERS: card number, index
 *
 *  RETURNS: ChunkID of database header
 *
 *  CREATED: 11/14/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalID	DmGetDatabase(UInt cardNo, UInt index)
{
	UInt				numEntries = 0;
	DatabaseDirPtr	dirP=0, *dirH=0;
	LocalID			dirID, hdrID=0;
	Err				err;


	// Get semaphore
	MemSemaphoreReserve(false);
	
	// See how many ROM databases there are
	err = MemStoreInfo(cardNo, 0, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
	if (!err && dirID) {
		dirP = MemLocalIDToGlobal(dirID, cardNo);
		if (dirP)  
			numEntries = dirP->numDatabases;
		}

	// If the index is to a RAM database header, get that one instead
	if (index >= numEntries) {
		index -= numEntries;
		numEntries = 0;

		// Get the database directory ID for the RAM area
		err = MemStoreInfo(cardNo, 1, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
		if (!err && dirID) {
			dirP = MemLocalIDToLockedPtr(dirID, cardNo);
			if (dirP)  {
				numEntries = dirP->numDatabases;
				}
			}

		}


	// Get the database hdr ID by index
	if (index >= numEntries) {
		err =  dmErrIndexOutOfRange;
		goto Exit;
		}
	hdrID = dirP->databaseID[index];


Exit:
	if (dirP) MemPtrUnlock(dirP);
	
	MemSemaphoreRelease(false);
	if (err) return 0;
	else return hdrID;			 
}


/************************************************************
 *
 *  FUNCTION: DmGetNextDatabaseByTypeCreator
 *
 *  DESCRIPTION: Returns a database header ID and card number
 *   given the type and/or creator. This routine searches all
 *   memory cards for a match. 
 *
 *	  To start the search pass true for 'newSearch' 
 *   To continue a search where the previous on left off, pass false
 *		for 'newSearch'. When continuing a search stateInfoP MUST POINT
 *		to the same structure passed during the previous invocation!!!!!!
 *
 *   If the type parameter is missing, this routine can be called
 *   successively to return all databases of the given creator.
 *
 *   If the creator parameter is missing, this routine can be called
 *   successively to return all databases of the given type.
 *
 *   If the onlyLatestVers parameter is set, only the latest version
 *		of each database with a given creator/type pair is returned.
 *
 *	  If searching for the latest version and either type or creator 
 *    is a wildcard, this routine return the index of the next database
 *		which matches the search criteria which is not superseded by a newer
 *		version of that database with the same type and creator.
 *		Got That?????
 *
 *  PARAMETERS: 
 *		newSearch 		 -> true if starting a new search
 *		stateInfoP		 -> if 'newSearch' is false, THIS MUST POINT TO SAME DATA
 *									used for previous invocation. 
 *		type		 		 -> type of database to search for, pass 0 as a wildcard
 *		creator   		 -> creator of database to search for, pass 0 as a wildcard
 *    onlyLatestVers  -> if true, only the latest version of each database with
 *								  a given type and creator will be returned.
 *		*cardNoP 		<-  On exit, the cardNo of the found database. 
 *		*dbIDP   		<-  database LocalID of the found database.
 *			
 *
 *  RETURNS: 	0						- if no error
 *				  	dmErrCantFind 		- if no matches found
 *
 *  CREATED: 4/26/95
 *
 *  BY: Ron Marianetti
 *
 *		8/26/97	vmk	Fixed to allow the search to continue when a card only
 *							has one store.
 *
 *************************************************************/
Err	DmGetNextDatabaseByTypeCreator(Boolean newSearch, DmSearchStatePtr stateInfoP,
			 ULong	type, ULong creator, Boolean onlyLatestVers, 
			 UIntPtr cardNoP, LocalID* dbIDP)
{
	DatabaseHdrPtr		hdrP;
	LocalID				hdrID;
	Err					err;
	ULong					searchType=type, searchCreator=creator;
	DatabaseDirPtr 	dirP;
	
	DmPrvSearchStateType		foundState;
	DmPrvSearchStateType*	stateP = (DmPrvSearchStateType*)stateInfoP;
	
	DWord					foundVersion = 0;	// vmk 8/26/97 initialized to zero
	DWord					version;
	LocalID				foundHdrID=0;
	Boolean				found=false;
	Boolean				newStore;
	
	
	// Error Check
	if (sizeof(DmPrvSearchStateType) > sizeof(DmSearchStateType))
		ErrDisplay("DmSearchStateType too small");
	
	
	// Grab semaphore
	MemSemaphoreReserve(false);
	
	// For a new search, this gets us into the first for loop where the entire structure
	//   will then be initialized.
	if (newSearch) 
		stateP->cardNo = 0;
	else
		newStore = false;


	// Search through all cards
	for (; !found && (stateP->cardNo < GMemCardSlots); stateP->cardNo++) {
	
		// We must re-init our search state if starting a new search
		if (newSearch) {
			MemSet(stateP, sizeof(DmPrvSearchStateType), 0);
			newSearch = false;
			newStore = true;
			}
		
		if ( newStore )											// vmk 8/26/97
			stateP->storeNo = 1;
	
		//---------------------------------------------------------
		// Search both stores on each card, starting with the RAM store
		//---------------------------------------------------------
		for (; !found && (stateP->storeNo >= 0); stateP->storeNo--) {
			
			// If we're entering a new Store, get the info on it.
			if (newStore) {
				// Get the datbase directory for this store
				stateP->storeEntries = 0;
				err = MemStoreInfo(stateP->cardNo, stateP->storeNo, 0, 0, 0, 0, 0, 0, 0, 0, &stateP->dirID);
				if (err || (stateP->dirID==0))
					{
					newStore = true;								// vmk 8/26/97
					continue;
					}
	
				// Get the number of entries in its directory
				dirP = MemLocalIDToLockedPtr(stateP->dirID, stateP->cardNo);
				stateP->storeEntries = dirP->numDatabases;

				stateP->relIndex = stateP->index - stateP->storeStartIndex;
				}
			else
				dirP = MemLocalIDToLockedPtr(stateP->dirID, stateP->cardNo);
				
				
			//---------------------------------------------------------
			// Search all the databases in this store
			//---------------------------------------------------------
			for(; !found && (stateP->relIndex < stateP->storeEntries) 
					; stateP->relIndex++, stateP->index++ ) {
				
				// Get the database header for next database in this store 
				hdrID = dirP->databaseID[stateP->relIndex];
				hdrP = MemLocalIDToLockedPtr(hdrID, stateP->cardNo);
				
				//..................................................
				// See if it matches the search criteria
				//..................................................
				if ((!searchType || (searchType == hdrP->type)) && 
					 (!searchCreator || (searchCreator == hdrP->creator))) {
					 
					// Form a composite version which makes databases at lower indices
					// (card 0 before card 1, RAM store before ROM store) have precedence
					// when the database versions are the same.
					version = ((DWord)hdrP->version << 16) | ((~stateP->index) & 0xFFFF);
						 
					// If our proposed match (foundHdrID) is not the latest revision, 
					// with that type and creator and we're using a wildcard for 
					// type or creator, throw that match out and start the search
					// over again at the following index.
					if (foundHdrID && (version > foundVersion) && (!type || !creator)) {
						MemPtrUnlock(dirP);
						*stateP = foundState;
						foundHdrID = 0;
						searchType = type;
						searchCreator = creator;
						dirP = MemLocalIDToLockedPtr(stateP->dirID, stateP->cardNo);
						}

					// If our proposed match (foundHdrID) is not the latest revision, 
					// and we're searching for a specific type and creator, use this entry 
					// as our new proposed match.
					else if (!foundHdrID || (version > foundVersion)) {
					    
						// Save info on this match in case it's the one we'll return.
						foundState = *stateP;
						foundHdrID = hdrID;
						foundVersion = version;
						
						// If we have a wildcard for type or creator, and we're searching
						// only the latest version, we must save the type and creator of
						// our proposed match and look again in order to see if a later 
						// version exists.
						if (onlyLatestVers && (!type || !creator)) {
							searchType = hdrP->type;
							searchCreator = hdrP->creator;
							stateP->relIndex = stateP->storeEntries;		// so we fall out of this loop
							stateP->storeNo = -1;								// so we fall out of store loop
							stateP->cardNo = -1;									// so we start over cardNo loop
							stateP->index = -1;									// so we start over at index 0
							stateP->storeStartIndex = 0;						// Reset storeStartINdex
							newSearch = true;
							}
							
						if (!onlyLatestVers) found = true;
						}
						
					} //........ If (matches search criteria)........................
						
				MemPtrUnlock(hdrP);
				}//-------- for() loop for each database in a store--------------
				
				

			// Unlock the database directory for this store.
			MemPtrUnlock(dirP);
			
			// Bump the startIndex for the next store.
			stateP->storeStartIndex += stateP->storeEntries;
			
			// Set flag that says we're going to a new store
			newStore = true;
			} //-----for() loop for each store on a memory card-----------
			
		} // for() loop for each memory card
		
		
Exit:
	// Release semahpore
	MemSemaphoreRelease(false);

	// If we found a match, return the info
	if (foundHdrID) {
		*dbIDP = foundHdrID;
		*cardNoP = foundState.cardNo;
		*stateP = foundState;
		stateP->index++;
		stateP->relIndex++;
		return 0;
		}
		
	// If we got here without a match, the search was unsuccessful
	else {
		*dbIDP = 0;
		*cardNoP = 0;
		return dmErrCantFind;
		}
}






/************************************************************
 *
 *  FUNCTION: DmFindDatabase
 *
 *  DESCRIPTION: Searches for a database by name
 *
 *  PARAMETERS: card number, name pointer
 *
 *  RETURNS: ChunkID of database header
 *
 *  CREATED: 11/14/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalID	DmFindDatabase(UInt cardNo, const CharPtr nameP)
{
	LocalID			foundID=0;
	Err				err = dmErrCantFind;
	Int				storeNum;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	// Grab semaphore
	MemSemaphoreReserve(false);

	// Search each store
	for (storeNum=1; storeNum >=0 && !foundID; storeNum--) {
		foundID = PrvFindDatabaseInStore(cardNo, storeNum, nameP);
		if (foundID) err = 0;
		}

Exit:
	// Release semaphore
	MemSemaphoreRelease(false);
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = err;
	if (err) return 0;
	else return foundID;			 
}



/************************************************************
 *
 *  FUNCTION: PrvFindDatabaseInStore, private
 *
 *  DESCRIPTION: Searches for a database by name in either the
 *			ROM or RAM store.
 *
 *  PARAMETERS: card number, storenumber, name pointer
 *
 *  RETURNS: ChunkID of database header
 *
 *  CREATED: 11/14/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalID	PrvFindDatabaseInStore(UInt cardNo, UInt storeNum, const Char * const nameP)
{
	DatabaseDirPtr	dirP=0;
	LocalID			dirID, foundID=0;
	Err				err;
	Int				i;
	DatabaseHdrPtr	hdrP;


	// Get the directory ID for this store
	err = MemStoreInfo(cardNo, storeNum, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
	if (err || !dirID) return 0;

	// Get pointer to the directory info
	dirP = MemLocalIDToLockedPtr(dirID, cardNo);

	// Compare the name of each database
	for (i=0; i<dirP->numDatabases && !foundID; i++) {
		hdrP = MemLocalIDToLockedPtr(dirP->databaseID[i], cardNo);

		if (!StrCompare(nameP, (CharPtr)hdrP->name)) 
		  	foundID = dirP->databaseID[i];
		  	
		MemPtrUnlock(hdrP);
		}
		
	MemPtrUnlock(dirP);

Exit:
	if (err) return 0;
	else return foundID;			 
}





/************************************************************
 *
 *  FUNCTION: DmDatabaseInfo
 *
 *  DESCRIPTION: Retrieves database information
 *
 *  PARAMETERS: a ton of pointers, any number of them can be nil
 *
 *  RETURNS: 0 if successful
 *
 *  CREATED: 11/15/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		DmDatabaseInfo(UInt cardNo, LocalID	dbID, const CharPtr nameP,
					UIntPtr attributesP, UIntPtr versionP, ULongPtr crDateP,
					ULongPtr	modDateP, ULongPtr bckUpDateP,
					ULongPtr	modNumP, LocalID* appInfoIDP,
					LocalID* sortInfoIDP, ULongPtr typeP,
					ULongPtr creatorP)
{
	DatabaseHdrPtr	hdrP;

	// Get a pointer to the database header
	hdrP = MemLocalIDToLockedPtr(dbID, cardNo);
	if (!hdrP) return dmErrInvalidParam;

	if (nameP) 
		StrCopy(nameP, (CharPtr)hdrP->name);

	if (attributesP) 
		*attributesP = hdrP->attributes;

	if (versionP) 
		*versionP = hdrP->version;

	if (crDateP) 
		*crDateP = hdrP->creationDate;

	if (modDateP) 
		*modDateP = hdrP->modificationDate;

	if (bckUpDateP) 
		*bckUpDateP = hdrP->lastBackupDate;

	if (modNumP) 
		*modNumP = hdrP->modificationNumber;

	if (appInfoIDP) 
		*appInfoIDP = hdrP->appInfoID;

	if (sortInfoIDP) 
		*sortInfoIDP = hdrP->sortInfoID;

	if (typeP) 
		*typeP = hdrP->type;

	if (creatorP) 
		*creatorP = hdrP->creator;
		
	MemPtrUnlock(hdrP);

	return 0;
}


/************************************************************
 *
 *  FUNCTION: DmSetDatabaseInfo
 *
 *  DESCRIPTION: Sets database information.
 *					When appInfoID or sortInfoID are changed using
 *					 this call, the old chunkID (if any) will be marked as an orphan
 *					 chunk and the new chunk ID will be un-orphaned.
 *					Consequently, you shouldn't replace an existing appInfoID or
 *					 sortInfoID if that chunk has already been attached to another
 *              database.
 *
 *  PARAMETERS: a ton of pointers, any number of them can be nil
 *
 *  RETURNS: 0 if successful
 *
 *  CREATED: 11/15/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	9/18/97	Added check for name length and uniqueness
 *		vmk	10/31/97	Don't force modification number change for backup date change;
 *							and don't rev mod number if mod number is being set by the caller;
 *							if mod number is bumped up, update the modification date also
 *
 *************************************************************/
Err		DmSetDatabaseInfo(UInt cardNo, LocalID	dbID, const CharPtr nameP,
					UIntPtr attributesP, UIntPtr versionP, ULongPtr crDateP,
					ULongPtr	modDateP, ULongPtr bckUpDateP,
					ULongPtr	modNumP, LocalID* appInfoIDP,
					LocalID* sortInfoIDP, ULongPtr typeP,
					ULongPtr creatorP)
{
	DatabaseHdrPtr	hdrP = 0;
	Err		err=0;
	Boolean	updateModNum = false;
	Handle	h;
	UInt		len;

	// Enable writes
	MemSemaphoreReserve(true);

	// If changing the name, make sure a database with this name doesn't already exist in
	// the RAM store and the name is valid
	if ( nameP ) {
		// Validate name length
		len = StrLen(nameP);
		if ( len == 0 || len >= dmDBNameLength ) {
			err = dmErrInvalidDatabaseName;
			goto Exit;
			}
		
		// Check name for uniqueness in the RAM store
		if ( PrvFindDatabaseInStore(cardNo, 1, nameP) ) {
			err = dmErrAlreadyExists;
			goto Exit;
			}
		}

	// Get a pointer to the database header
	hdrP = MemLocalIDToLockedPtr(dbID, cardNo);
	if (!hdrP) {
		err= dmErrInvalidParam;
		goto Exit;
		}

	if (nameP) {
		StrCopy((CharPtr)hdrP->name, nameP);
		updateModNum = true;
		}

	if (attributesP) {
		hdrP->attributes = *attributesP;
		updateModNum = true;
		}

	if (versionP) {
		hdrP->version = *versionP;
		updateModNum = true;
		}

	if (crDateP) {
		hdrP->creationDate = *crDateP;
		updateModNum = true;
		}

	if (modDateP) {
		hdrP->modificationDate = *modDateP;
		// we're not changing updateModNum here -- if this is the only field being
		// changed, then by default the mod num will not be revved
		}

	if (bckUpDateP) {
		hdrP->lastBackupDate = *bckUpDateP;
		// we're not changing updateModNum here -- if this is the only field being
		// changed, then by default the mod num will not be revved
		}

	if (appInfoIDP) {
		// If there's an existing appInfo block, orphan it
		if (hdrP->appInfoID) {
			h = MemLocalIDToGlobal(hdrP->appInfoID, cardNo);
			MemHandleSetOwner(h, dmOrphanOwnerID);
			}
		// Give the new chunk a valid owner 
		hdrP->appInfoID = *appInfoIDP;
		if (*appInfoIDP) {
			h = MemLocalIDToGlobal(*appInfoIDP, cardNo);
			MemHandleSetOwner(h, dmRecOwnerID);
			}
		updateModNum = true;
		}

	if (sortInfoIDP) {
		// If there's an existing appInfo block, orphan it
		if (hdrP->sortInfoID) {
			h = MemLocalIDToGlobal(hdrP->sortInfoID, cardNo);
			MemHandleSetOwner(h, dmOrphanOwnerID);
			}
		// Give the new chunk a valid owner 
		hdrP->sortInfoID = *sortInfoIDP;
		if (*sortInfoIDP) {
			h = MemLocalIDToGlobal(*sortInfoIDP, cardNo);
			MemHandleSetOwner(h, dmRecOwnerID);
			}
		updateModNum = true;
		}

	if (typeP) {
		hdrP->type = *typeP;
		updateModNum = true;
		}

	if (creatorP) {
		hdrP->creator = *creatorP;
		updateModNum = true;
		}
	
	// This case MUST be last because of the special case (the mod number itself being set)
	if (modNumP) {
		hdrP->modificationNumber = *modNumP;
		updateModNum = false;		// don't rev modification number when setting the mod number
		}

	// Bump up the mod number and update the modification date
	if ( updateModNum ) {
		hdrP->modificationNumber++;
		
		if ( !modDateP )
			hdrP->modificationDate = TimGetSeconds();
		}
	
	MemPtrUnlock(hdrP);

Exit:
	// Restore  write-protection
	MemSemaphoreRelease(true);

	return err;
}

/************************************************************
 *
 *  FUNCTION: DmDatabaseProtect
 *
 *  DESCRIPTION:  
 *		 This routine can be used to prevent a database from being deleted (by passing
 *		 true for 'protect'). It will increment the protect count if 'protect' is true
 *		 and decrement it if 'protect' is false. This is used by code that wants to
 *		 keep a particular record or resource in a database locked down but doesn't
 *		 want to keep the database open. This information is keep in the dynamic heap so
 *		 all databases are "unprotected" at system reset. 
 *
 *  PARAMETERS: 
 *		cardNo 			- card number of database to protect/unprotect
 *		dbID				- LocalID of database to protect/unprotect
 *		protect			- if true, protect count will be incremented
 *							  if false, protect count will be decremented.
 *
 *  RETURNS: 0 if successful
 *
 *  CREATED: 7/23/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		DmDatabaseProtect(UInt cardNo, LocalID	dbID, Boolean protect)
{
	Err					err=0;
	DmProtectEntryPtr	listP=0, entryP;
	UInt					numEntries, entryNo;
	Boolean				found = false;
	
	// Make sure we have a list to work with
	if (!GDmProtectListH) {
		GDmProtectListH = MemHandleNew(sizeof(DmProtectEntryType));
		if (!GDmProtectListH) {err = memErrNotEnoughSpace; goto Exit;}
		MemHandleSetOwner(GDmProtectListH, 0);
		
		// Init it
		listP = MemHandleLock(GDmProtectListH);
		MemSet(listP, sizeof(DmProtectEntryType), 0);
		
		// Put this database in first entry
		listP->cardNo = cardNo;
		listP->dbID = dbID;

		MemPtrUnlock(listP);
		}
		
	// Get the size of the list
	listP = MemHandleLock(GDmProtectListH);
	numEntries = MemPtrSize(listP) / sizeof(DmProtectEntryType);
	
	// Look for an existing entry in the list
	for (entryP = listP, entryNo=0; entryNo<numEntries; entryNo++, entryP++) {
		if (entryP->cardNo ==  cardNo && entryP->dbID == dbID) {
			found = true;
			break;
			}
		}
		
	// if protecting, we must have an entry so grow the list
	if (protect && !found) {
		numEntries++;
		MemPtrUnlock(listP);
		listP = 0;
		
		err = MemHandleResize(GDmProtectListH, numEntries * sizeof(DmProtectEntryType));
		if (err) goto Exit;
		
		// Init new list
		listP = MemHandleLock(GDmProtectListH);
		
		// Point to new entry
		entryNo = numEntries-1;
		entryP = &listP[entryNo];
		entryP->cardNo = cardNo;
		entryP->dbID = dbID;
		entryP->protectCount = 0;
		}
	else if (!found) goto Exit;
		
	
	// modify protect count
	if (protect) entryP->protectCount++;
	else if (entryP->protectCount) entryP->protectCount--;
	
	
	// If protect count is now 0, get rid of this entry
	if (!entryP->protectCount) {
		MemMove(&listP[entryNo], &listP[entryNo+1], 
					(numEntries - entryNo - 1) * sizeof(DmProtectEntryType));
		numEntries--;
		if (numEntries)
			MemPtrResize(listP, numEntries * sizeof(DmProtectEntryType));
		else {
			MemHandleFree(GDmProtectListH);
			GDmProtectListH = 0;
			listP = 0;
			}
			
		}
		
	
Exit:
	if (listP) MemPtrUnlock(listP);
	
	ErrNonFatalDisplayIf(err, "err in DmDatabaseProtect");
	return err;
}


/************************************************************
 *
 *  FUNCTION: DmDatabaseSize
 *
 *  DESCRIPTION: Returns the size of bytes and the total number of
 *		records in a database. 
 *
 *  PARAMETERS: 
 *		cardNo			- card number of database
 *		dbID				- database ID
 *		*numRecordsP	- number of records returned here
 *		*totalBytesP	- total size returned here, including overhead
 *		*dataBytesP		- data size only, does not include overhead bytes.
 *
 *  RETURNS: 0 if no error
 *		 numRecordsP, totalBytesP, dataBytesP - set if not NULL
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *			roger	7/15/96	Made the results optional
 *
 *************************************************************/
Err	DmDatabaseSize(UInt cardNo, LocalID	dbID, ULongPtr numRecordsP,
				ULongPtr totalBytesP, ULongPtr dataBytesP)
{
	ULong					actSize=0, dataSize=0;
	UInt					totalRecords=0;
	DatabaseHdrPtr		hdrP;
	Int					i;
	Ptr					p;
	Boolean				resDB;
	BytePtr				entryP;
	UInt					entrySize;
	RecordListPtr		listP;
	LocalID				id;
	Boolean				ramBased;
	

	// Get the header ptr
	hdrP = MemLocalIDToLockedPtr(dbID, cardNo);
	if (!hdrP) return dmErrMemError;

	// Get the number of records and the resDB boolean
	resDB = hdrP->attributes & dmHdrAttrResDB;
	if (resDB) entrySize = sizeof(RsrcEntryType);
	else entrySize = sizeof(RecordEntryType);

	// Set boolean if it's RAM based or not
	if (MemLocalIDKind(dbID) == memIDHandle) 
		ramBased = true;
	else
		ramBased = false;


	// Accumulate the sizes of every chunk
	listP = &hdrP->recordList;
	while(1) {
	
		// Ptr to first entry
		entryP = (BytePtr)&listP->firstEntry;
	
		// Add sizes of every chunk in this list
		for (i=0; i<listP->numRecords; i++) {
			
			if (resDB) id = ((RsrcEntryPtr)entryP)->localChunkID;
			else id = ((RecordEntryPtr)entryP)->localChunkID;
			
			// We do it this way because it works for ROM based or RAM based records.
			if (id) {
				p = MemLocalIDToLockedPtr(id, cardNo);
				dataSize += MemPtrSize(p);
				MemPtrUnlock(p);
				}
			
			// next entry
			entryP += entrySize;
			}
			
		// On to the next list
		totalRecords += listP->numRecords;
		if (listP != &hdrP->recordList) {
			MemPtrUnlock(listP);
			
			// Add the overhead of the record list header
			actSize += sizeof(RecordListType);
			if (ramBased) actSize += sizeof(Handle);		// for record list handle
			}
			
		id = listP->nextRecordListID;
		if (!id) break;
		listP = MemLocalIDToLockedPtr(id, cardNo);
		}
	
	
	// Add the overhead to get the actual size
	actSize += dataSize + sizeof(DatabaseHdrType) +
				totalRecords * (sizeof(memChunkHeaderTypeName) + entrySize);
	
	// If it's RAM based, add the space used for master pointers
	if (ramBased)
		actSize += sizeof(Handle)									// for database header
					  + (totalRecords * sizeof(Handle));		// for each record

	// Return results
	MemPtrUnlock(hdrP);
	
	if (totalBytesP)
		*totalBytesP = actSize;
	if (dataBytesP)
		*dataBytesP = dataSize;
	if (numRecordsP)
		*numRecordsP = totalRecords;
	return 0;
}


/************************************************************
 *
 *  FUNCTION: DmOpenDatabaseByTypeCreator
 *
 *  DESCRIPTION: Opens up the most recent revision of a dabase with
 *		the given type and creator
 *
 *  PARAMETERS: 
 *		type - type of database
 *		creator - creator of database
 *		mode - open mode
 *
 *  RETURNS: DmOpenRef to open database, or 0 if unsuccessful.
 *
 *  CREATED: 9/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
DmOpenRef DmOpenDatabaseByTypeCreator(ULong type, ULong creator, UInt mode)
{
	DmSearchStateType	searchState;
	Err					err;
	UInt					cardNo;
	LocalID				dbID;
	DmOpenRef			dbR=0;
	SysAppInfoPtr		appInfoP;
	SysAppInfoPtr		unusedAppInfoP;
	
	// Grab semaphore
	MemSemaphoreReserve(true);


	// Find the database
	err = DmGetNextDatabaseByTypeCreator (true, &searchState, type, 
		creator, true, &cardNo, &dbID);
	if (err) {
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		appInfoP->dmLastErr = err;
		goto Exit;
		}
	

	// Open it.
	dbR = DmOpenDatabase(cardNo, dbID, mode);
	//ErrFatalDisplayIf(!dbR, "Err opening DB");


Exit:
	MemSemaphoreRelease(true);
	return dbR;
}



/************************************************************
 *
 *  FUNCTION: DmOpenDatabase
 *
 *  DESCRIPTION: Opens up a database and returns a reference to it.
 *
 *  PARAMETERS: card number, Database Header Chunk ID, mode
 *
 *  RETURNS: DmOpenRef to open database, or 0 if unsuccessful.
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *	Name	Date		Description
 *	----	----		-----------
 *	vmk	10/31/97	Save current modification number
 *	roger	12/12/97	Change to use SysCurAppInfo
 *
 *************************************************************/
DmOpenRef DmOpenDatabase(UInt cardNo, LocalID dbID, UInt mode)
{
	DmAccessPtr		accessP=0;
	DmOpenInfoPtr	openP=0;
	Err				err;
	DatabaseHdrPtr	hdrP, *hdrH;
	ULong				size;
	Ptr*				handleTableP=0;
	UInt				i;
	LocalID			localID;
	SysAppInfoPtr	appInfoP;
	ULong				taskID;
	RecordListPtr	listP;
	SysAppInfoPtr	unusedAppInfoP;


	
	// Grab semaphore
	MemSemaphoreReserve(true);
	
	
	// Error Check
	ErrFatalDisplayIf(!dbID, "Null dbID passed");
	if (!dbID) {err = dmErrInvalidParam; goto Exit;}
	
	
	// Get the SysAppInfoPtr for the current app
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	taskID = SysTaskID();


	// Allocate DmAccessType
	accessP = MemChunkNew(0, sizeof(DmAccessType), dmDynOwnerID | memNewChunkFlagNonMovable);
	if (!accessP)  {
		err = dmErrMemError;
		goto Exit;
		}
		
	// Link it in
	accessP->next = (DmAccessPtr)(appInfoP->dmAccessP);
	appInfoP->dmAccessP = (Ptr)accessP;
			
			
			
	// See if this database is already open
	openP = (DmOpenInfoPtr)GDmOpenList;
	while(openP) {
		if (openP->hdrID == dbID && openP->cardNo == cardNo) break;
		openP = (DmOpenInfoPtr)openP->next;
		}
	
	

	//--------------------------------------------------------------------------------
	// If it's already open, check for conflicts and just increment the 
	// open count and init the DmAccessType to reference the open information
	//--------------------------------------------------------------------------------
	if (openP) {
	
		// If it's already opened with exclusive access OR if we need exclusing access, error
		if (openP->exclusive || (mode & dmModeExclusive))  {
			err = dmErrDatabaseOpen;
			openP = 0;					// so it doesn't get freed on error
			goto Exit;
			}
			
		if (openP->writeAccess && (mode & dmModeWrite)) {
			err = dmErrAlreadyOpenForWrites;
			openP = 0;					// so it doesn't get freed on error
			goto Exit;
			}
			
		if (!openP->resDB && openP->ownerTaskID != taskID) {
			err = dmErrOpenedByAnotherTask;
			openP = 0;					// so it doesn't get freed on error
			goto Exit;
			}
			
		// Fill in the access ptr 
		accessP->mode = mode;
		accessP->openP = openP;
		err = 0;
			
		// Update open info
		openP->openCount++;
		if (mode & dmModeWrite) openP->writeAccess = true;
		if (mode & dmModeExclusive) openP->exclusive = true;
		
		openP = 0;
		err = 0;
		goto Exit;
		}
		
		
	// Else, we need to allocate the openInfo structure
	else {
		openP = MemChunkNew(0, sizeof(DmOpenInfoType), dmDynOwnerID | memNewChunkFlagNonMovable);
		if (!openP) {
			err = dmErrMemError;
			goto Exit;
			}
		MemSet(openP, sizeof(DmOpenInfoType), 0);

		// Fill in the access ptr
		accessP->mode = mode;
		accessP->openP = openP;
		}
	
	
	
	//--------------------------------------------------------------------------------
	// Lock the database header down if it's a movable chunk
	//--------------------------------------------------------------------------------
	if (MemLocalIDKind(dbID) == memIDHandle) {
		hdrH = MemLocalIDToGlobal(dbID, cardNo);
		hdrP = MemHandleLock(hdrH);
		openP->hdrH = hdrH;
		openP->hdrP = hdrP;
		
		// If this database is read only, make sure caller is not trying to get
		//  write access
		if ((hdrP->attributes & dmHdrAttrReadOnly) && (mode & dmModeWrite))
			{err = dmErrReadOnly; goto Exit;}
		}
		
	// If it's not movable (ROM-based), create a fake handle for it and allocate a block
	// for holding the master pointers to the ROM based records
	else {
		// Don't allow ROM based databases to be opened with write access.
		if (mode & dmModeWrite) {err = dmErrReadOnly; goto Exit;}
		hdrP = MemLocalIDToGlobal(dbID, cardNo);
		openP->hdrMasterP = (Ptr)hdrP;
		openP->hdrH = (DatabaseHdrHand)&openP->hdrMasterP;
		openP->hdrP = hdrP;
		}
		
		
	// Save current mod num for comparison at closing to determine if mod date will
	// need to be changed
	accessP->savedModNum = hdrP->modificationNumber;


	//--------------------------------------------------------------------------------
	// Fill in the Open info structure.
	//--------------------------------------------------------------------------------
	openP->next = 0;
	openP->openCount = 1;
	openP->ownerTaskID = taskID;
	if (mode & dmModeExclusive) openP->exclusive = true;
	if (mode & dmModeWrite) openP->writeAccess = true;
	openP->resDB = hdrP->attributes & dmHdrAttrResDB;
	openP->hdrID = dbID;
	openP->cardNo = cardNo;

		
	//--------------------------------------------------------------------------------
	// Go through and lock all the Record lists down and count the total
	//  number of records which we cache in the OpenInfo structure for
	//  better performance
	//--------------------------------------------------------------------------------
	listP = &hdrP->recordList;
	openP->numRecords = listP->numRecords;
	while(1) {
		localID = listP->nextRecordListID;
		if (!localID) break;
		
		// Lock this list down and add it's records
		listP = MemLocalIDToLockedPtr(localID, cardNo);
		openP->numRecords += listP->numRecords;
		}
		
		
	//--------------------------------------------------------------------------------
	// If this is a ROM based database, make master pointers for each record
	//--------------------------------------------------------------------------------
	if (openP->hdrMasterP) {

		// Make a handle table for ROM based databases.
		size = openP->numRecords * sizeof(Ptr);
		handleTableP = MemChunkNew(0, size, dmDynOwnerID | memNewChunkFlagNonMovable);
		if (!handleTableP) {
			err = dmErrMemError;
			goto Exit;
			}
		MemSet(handleTableP, size, 0);
		openP->handleTableP = handleTableP;
		
		
		// If resource database, fill in the handle table with master pointers to each resource
		if (openP->resDB) {
			RsrcEntryPtr	resourceP=0;
			for (i=0; i<openP->numRecords; i++) {
				resourceP = PrvRsrcEntryPtr(openP, i, resourceP);
				ErrFatalDisplayIf (!resourceP, "Logic Flaw");
				localID = resourceP->localChunkID;
				if (localID) 
					handleTableP[i] = MemLocalIDToGlobal(localID, cardNo);
				}
			}
				

		// else, if record database, fill in the handle table with master pointers
		//  to each resource
		else {
			RecordEntryPtr	recP=0;
			for (i=0; i<openP->numRecords; i++) {
				recP = PrvRecordEntryPtr(openP, i, recP);
				localID = recP->localChunkID;
				if (localID) 
					handleTableP[i] = MemLocalIDToGlobal(localID, cardNo);
				}
			}
				
		} // if (openP->hdrMasterP)


	//--------------------------------------------------------------------------------
	// Link in the OpenInfo structure to the linked list of open databases
	//--------------------------------------------------------------------------------
	openP->next = GDmOpenList;
	GDmOpenList = (Ptr)openP;
	err = 0;


	// If this database was not closed properly last time, clean up the
	// record states
	if (hdrP->attributes & dmHdrAttrOpen) 
		DmResetRecordStates(accessP);
		
		
	// Set the open bit in the header
	if (!handleTableP)
		hdrP->attributes |= dmHdrAttrOpen;
	
	

Exit:
	appInfoP->dmLastErr = err;
	if (err) {
		if (accessP) {
			appInfoP->dmAccessP = (Ptr)accessP->next;
			MemPtrFree(accessP);
			}
		if (openP) {
			if (openP->hdrP) MemPtrUnlock(openP->hdrP);
			if (openP->handleTableP) MemPtrFree(openP->handleTableP);
			MemPtrFree(openP);
			}
		accessP = 0;
		}
		
	// Release semaphore
	MemSemaphoreRelease(true);

	return accessP;
}	




/************************************************************
 *
 *  FUNCTION: DmResetRecordStates
 *
 *  DESCRIPTION: Unlocks all records and clears the busy bits 
 *
 *  PARAMETERS: database access pointer
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmResetRecordStates(DmOpenRef dbR)
{
	UInt				cardNo;
	UInt				i;
	LocalID			id;
	Ptr				p;
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr	openP = dbP->openP;
	
	
	// Can't do this for ROM databases
	if (openP->handleTableP)
		return dmErrROMBased;
		
		
	// Unlock all the records and clear the busy bits
	cardNo = openP->cardNo;

	if (openP->resDB) {
		RsrcEntryPtr	resourceP=0;
		for (i=0; i<openP->numRecords; i++) {
			resourceP = PrvRsrcEntryPtr(openP, i, resourceP);
			ErrFatalDisplayIf(!resourceP, "Logic flaw");
			p = MemLocalIDToLockedPtr(resourceP->localChunkID, cardNo);
			MemPtrResetLock(p);
			}
		}

	else {
		RecordEntryPtr recordP=0;
		for (i=0; i<openP->numRecords; i++) {
			recordP = PrvRecordEntryPtr(openP, i, recordP);
		 	recordP->attributes	&= ~dmRecAttrBusy;
		 	id = recordP->localChunkID;
		 	
		 	if (!id) continue;
			p = MemLocalIDToLockedPtr(id, cardNo);
			MemPtrResetLock(p);
			}
		}
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: DmGetLastErr
 *
 *  DESCRIPTION: Returns the error code from the last Data Manager call
 *
 *  PARAMETERS: none
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmGetLastErr(void)
{
	SysAppInfoPtr unusedAppInfoP;
	SysAppInfoPtr appInfoP;
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	return appInfoP->dmLastErr;
}



/************************************************************
 *
 *  FUNCTION: DmCloseDatabase
 *
 *  DESCRIPTION: Closes a Database
 *
 *  PARAMETERS: database access pointer
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *  MODIFICATIONS:
 *		7/2/96	RM		Update modification date on close.
 *		10/31/97	vmk	Don't update the modification date if mod num hasn't changed
 *
 *************************************************************/
Err	DmCloseDatabase(DmOpenRef dbR)
{
	DatabaseHdrPtr	hdrP;
	DmOpenInfoPtr	prevP = 0, openP, curP;
	Err				err = 0;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	curAppInfoP;
	DmAccessPtr		curAccessP, prevAccessP;
	DmAccessPtr*	accessHeadP;
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	RecordListPtr	listP;
	LocalID			localID;
	
	
	// Grab semaphore
	MemSemaphoreReserve(true);
	
	// Check params
	if (!dbP) {
		err = dmErrInvalidParam; goto Exit;}
	if (MemPtrSize(dbP) != sizeof(DmAccessType)) {
		err = dmErrInvalidParam; goto Exit;}
	
	// Get the ptr to the openInfo structure
	openP = dbP->openP;

	// Decrement the open count
	openP->openCount--;
	
	
	// Update the modification date accordingly <ROM2.0>
	// and only if mod number changed <ROM3.0>
	if ( (dbP->mode & dmModeWrite) && openP->hdrP->modificationNumber != dbP->savedModNum )
		openP->hdrP->modificationDate = TimGetSeconds();
		
	
	//----------------------------------------------------------------- 
	// If no one else has it open, release the openInfo structure 
	//----------------------------------------------------------------- 
	if (!openP->openCount) {

		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		// Find the entry in the access list
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		curP = (DmOpenInfoPtr)GDmOpenList;
		prevP  = 0;
		while(curP) {
			if (curP == openP) break;
			prevP = curP;
			curP = (DmOpenInfoPtr)curP->next;
			}
	
		// If not found, error
		if (!curP) {err = dmErrInvalidParam; goto Exit;}
	
		// Unlink it
		if (prevP)
			prevP->next = openP->next;
		else
			GDmOpenList = openP->next;
	
			

		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		// Go through and unlock all the Record lists.
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		listP = &openP->hdrP->recordList;
		localID = listP->nextRecordListID;
		while(localID) {
			// Get ptr to this list
			listP = MemLocalIDToGlobal(localID, openP->cardNo);
		
			// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
			if (!openP->handleTableP) 
				listP = (RecordListPtr)MemDeref((Handle)listP);

			// Get ID of next list
			localID = listP->nextRecordListID;
			
			// Unlock this list
			MemPtrUnlock(listP);
			}
		
		

		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		// Dispose of the handle table, if it's ROM based
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		if (openP->handleTableP) {
			MemPtrFree(openP->handleTableP);
			}
			
		// If RAM based, update the modification date, clear the open bit, and unlock 
		//  the header
		else {
			hdrP = MemHandleLock(openP->hdrH);
			
			// Clear the Open attribute bit
			hdrP->attributes &= ~dmHdrAttrOpen;
	
			// Unlock the database header
			MemPtrResetLock(hdrP);
			}
		
		
		// Release the memory used by the openInfo ptr
		MemPtrFree(openP);
		}
		
		
	//----------------------------------------------------------------- 
	// If it's still open by someone else, just update the status
	//----------------------------------------------------------------- 
	else {
		if (dbP->mode & dmModeWrite) openP->writeAccess = 0;
		}
		
	
	// Unlink and Release the dmAccess structure
	appInfoP = SysGetAppInfo(&appInfoP, &curAppInfoP);
	// <RM> 1-14-98, Use the current action code's appInfo if available
	accessHeadP = (DmAccessPtr*)&appInfoP->dmAccessP;
		
	curAccessP = *accessHeadP;
	prevAccessP  = 0;
	while(curAccessP) {
		if (curAccessP == dbP) break;
		prevAccessP = curAccessP;
		curAccessP = curAccessP->next;
		}

	// If not found, error
	if (!curAccessP) {err = dmErrInvalidParam; goto Exit;}

	// Unlink it
	if (prevAccessP)
		prevAccessP->next = dbP->next;
	else
		*accessHeadP = dbP->next;
	
	// Free it
	MemPtrFree(dbP);
	
	
Exit:
	ErrFatalDisplayIf(err, "Err closing DB");
	MemSemaphoreRelease(true);
	return err;
}


/************************************************************
 *
 *  FUNCTION: DmNextOpenDatabase
 *
 *  DESCRIPTION: Returns database access ptr to next open database
 *
 *  PARAMETERS: current database access ptr, or nil
 *
 *  RETURNS: access ptr, or nil if no more
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
DmOpenRef DmNextOpenDatabase(DmOpenRef currentP)
{
	SysAppInfoPtr	curAppInfoP;
	SysAppInfoPtr	appInfoP;
	
	if (!currentP) {
		// <RM> 1-14-98 
		// WAS:
		//		SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		//    return (DmAccessPtr)appInfoP->dmAccessP;		
		appInfoP = SysGetAppInfo(&appInfoP, &curAppInfoP);		
		
		return (DmAccessPtr)appInfoP->dmAccessP;
		}
		
	return ((DmAccessPtr)currentP)->next;
}


/************************************************************
 *
 *  FUNCTION: DmOpenDatabaseInfo
 *
 *  DESCRIPTION: Returns information about an open database
 *
 *  PARAMETERS: access ptr, ptrs to dbID, openCount, mode
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err DmOpenDatabaseInfo(DmOpenRef dbR, LocalID* dbIDP,
			UIntPtr openCountP, UIntPtr modeP, UIntPtr cardNoP,
			BooleanPtr resDBP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr	openP = dbP->openP;
	
	ErrFatalDisplayIf(!dbP, "Null DB ref");
	
	if (dbIDP) 			*dbIDP = openP->hdrID;
	if (openCountP)	*openCountP = openP->openCount;
	if (modeP) 			*modeP = dbP->mode;
	if (cardNoP) 		*cardNoP = openP->cardNo;
	if (resDBP) 		*resDBP = openP->resDB;
	return 0;
}



/************************************************************
 *
 *  FUNCTION: DmMoveOpenDBContext
 *
 *  DESCRIPTION: Used by SysAppStartup to move the DmAccess pointer of
 *   a database out of the current context and into another. For example,
 *		an open database can be moved from the app's open database list to the
 *		System list or vice versa.
 *
 *		As a special case, passing 0 for dstHeadP specifies that the database
 *		should be moved to the System Context. This is a special case because
 *		of the way DmAccessPtrs are linked together, the system list always
 *		appears tacked on to the end of the application list so this routine
 *		must not only update the system list but also update the link in
 *		the application's list to the system list. Got That????
 *
 *  PARAMETERS: 
 *		dstHeadP - Head pointer of destination list - or 0 for System context
 *		dbP	- DmAccessPtr of database we're moving out of ucfdrent list.
 *		
 *
 *  RETURNS: 0 if no err
 *
 *	 CALLED BY: SysAppLaunch in order to move an application database that it
 *		is launching out of the System list and into the application's list.
 *
 *  CREATED: 5/16/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err DmMoveOpenDBContext(DmAccessPtr* dstHeadP, DmAccessPtr dbP)
{
	DmAccessPtr		curAccessP, prevAccessP;
	DmAccessPtr*	oldHeadP;
	Err				err;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;
	Boolean			moveToSystem=false;
	DmAccessPtr*	linkP=0;

	// Grab semaphore
	MemSemaphoreReserve(false);
	
	
	// Get the head of the source context
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	oldHeadP = (DmAccessPtr*)(&appInfoP->dmAccessP);

	// If moving to the system context, get the ptr to the first System DmAccessType
	//  in dstHeaderP.
	if (!dstHeadP) {
		moveToSystem = true;
		dstHeadP = (DmAccessPtr*)&((SysAppInfoPtr)GSysAppInfoP)->dmAccessP;
		}

	//-------------------------------------------------------------
	// Unlink the access ptr from the current list
	//-------------------------------------------------------------
	curAccessP = *oldHeadP;
	prevAccessP  = 0;
	while(curAccessP) {
		if (curAccessP == dbP) break;
		prevAccessP = curAccessP;
		curAccessP = curAccessP->next;
		}

	// If not found, error
	if (!curAccessP) {err = dmErrInvalidParam; goto Exit;}

	// Unlink it
	if (prevAccessP)
		prevAccessP->next = dbP->next;
	else
		*oldHeadP = dbP->next;
	dbP->next = 0;
	
	
	//-------------------------------------------------------------
	// If we're moving it to the System Context, find the link in the app
	//    list that points to the start of the System list
	//-------------------------------------------------------------
	if (moveToSystem) {
		linkP = oldHeadP;
		
		// If there is an app list, look for the end
		if (*linkP) {
			while(*linkP) {
				if (*linkP == *dstHeadP) 
					break;
				linkP = (DmAccessPtr*)(*linkP);
				}
			if (!*linkP) {err = dmErrInvalidParam; goto Exit;}
			}
			
		// Else, we just use the head of the app list
		}
	
	
	//-------------------------------------------------------------
	// Link it into the new  list
	//-------------------------------------------------------------
	dbP->next = *dstHeadP;
	*dstHeadP = dbP;
	
	// If we moved to the system context, update the app's link to the system
	//  context
	if (moveToSystem)
		*linkP = dbP;
		
		
	err = 0;
	
		
Exit:
	ErrFatalDisplayIf(err, "Can't move open DB");
	
	MemSemaphoreRelease(false);
	return err;
			
}

/************************************************************
 *
 *  FUNCTION: DmGetAppInfoID
 *
 *  DESCRIPTION: Returns the local id of the application 
 *    info block.
 *
 *  PARAMETERS: database access ptr
 *
 *  RETURNS: local id of the application info block
 *
 *  CREATED: 6/19/95
 *
 *  BY: Art Lamb
 *
 *************************************************************/
LocalID DmGetAppInfoID (DmOpenRef dbR)
{
	DmAccessPtr				dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr			openP = dbP->openP;
	
	return openP->hdrP->appInfoID;
}


/************************************************************
 *
 *  FUNCTION: DmNumRecords
 *
 *  DESCRIPTION: Returns the number of records in a database
 *
 *  PARAMETERS: database access pointer
 *
 *  RETURNS: Number of records
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	DmNumRecords(DmOpenRef dbP)
{
	return ((DmAccessPtr)dbP)->openP->numRecords;
}


/************************************************************
 *
 *  FUNCTION: DmNumRecordsInCategory
 *
 *  DESCRIPTION: Returns the number of records in a database in the 
 *		specified category.
 *
 *  PARAMETERS: database access pointer, category
 *
 *  RETURNS: Number of records
 *
 *  CREATED: 3/13/95 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
UInt	DmNumRecordsInCategory(DmOpenRef dbR, UInt category)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				index;
	UInt 				count;
	UInt				numRecords = 0;
	Byte				attrMask, attrCmp;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;

	count = 	dbP->openP->numRecords;
	
	// Form the mask for comparing the attributes of each record
	if (category == dmAllCategories) {
		attrMask =  dmRecAttrDelete;
		attrCmp = 0;
		}
	else {
		attrMask =  dmRecAttrCategoryMask | dmRecAttrDelete;
		attrCmp = category;
		}
		
	if (!(dbP->mode & dmModeShowSecret))
		attrMask |= dmRecAttrSecret;
		
		
	// Go though and count all records that match our attribute criteria
	recordP = 0;
	for (index = 0; index < count; index++) {
		recordP = PrvRecordEntryPtr(openP, index, recordP);
		if ((recordP->attributes & attrMask) == attrCmp)
			numRecords++;
		}
		
	return numRecords;
}


/************************************************************
 *
 *  FUNCTION: DmRecordInfo
 *
 *  DESCRIPTION: Retreives the record information as stored in
 *		the database header.
 *
 *  PARAMETERS: db access ptr, record index, ptr to return attribute,
 *			ptr to return uniqueID
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmRecordInfo(DmOpenRef dbR, UInt index, 
				UIntPtr attrP, ULongPtr uniqueIDP, LocalID* chunkIDP)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	ULongPtr				lP;
	RecordEntryPtr		recordP;
	Err					err;


	// Get the entry ptr
	recordP = PrvRecordEntryPtr(dbP->openP, index, 0);
	if (!recordP) {err = dmErrIndexOutOfRange; goto Exit;}

	if (attrP) *attrP = recordP->attributes;
	if (uniqueIDP) {
		lP = (ULongPtr)&recordP->attributes;
		*uniqueIDP = (*lP)  & 0x00FFFFFF;
		}

	if (chunkIDP) 
		*chunkIDP = recordP->localChunkID;
		
	err = 0;
	
Exit:
	ErrFatalDisplayIf(err, "Err getting rec info");
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmSetRecordInfo
 *
 *  DESCRIPTION: Sets the record information stored in
 *		the database header.
 *
 *  PARAMETERS: db access ptr, record index, ptr to attribute,
 *			ptr to uniqueID
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmSetRecordInfo(DmOpenRef dbR, UInt index, 
				UIntPtr attrP, ULongPtr uniqueIDP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	ULongPtr			lP;
	ULong				temp;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err;
	RecordEntryPtr	recordP;



	// Enable writes
	MemSemaphoreReserve(true);

	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	// Get the record entry pointer
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) { err = dmErrIndexOutOfRange; goto Exit;}


	// Bump the mod number
	openP->hdrP->modificationNumber++;

	// Set the info
	if (attrP) recordP->attributes = *attrP;

	if (uniqueIDP) {
		lP = (ULongPtr)&recordP->attributes;
		temp = *lP;
		temp = (temp & 0xFF000000L) | (*uniqueIDP & 0x00FFFFFF);
		*lP = temp;
		}
		
	err = 0;
	
Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err setting rec info");
	return err;
}





/************************************************************
 *
 *  FUNCTION: DmRemoveSecretRecords
 *
 *  DESCRIPTION: Removes all secret records.
 *
 *  PARAMETERS: db access ptr
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/30/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err	DmRemoveSecretRecords(DmOpenRef dbR)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Int 				index;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err;
	RecordEntryPtr	recordP = 0;

	
	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
						
	
	// Remove all records with the secret bit set.
	for (index = openP->numRecords - 1; index >= 0; index--) {
		recordP = PrvRecordEntryPtr(openP, index, 0);
		if (recordP->attributes & dmRecAttrSecret) 
			 DmRemoveRecord(dbP, index);
		}
		
	err = 0;
	
Exit:
	MemSemaphoreRelease(true);
	ErrFatalDisplayIf(err, "Err Removing Secret Records");
	return err;
} 


/************************************************************
 *
 *  FUNCTION: DmAttachRecord
 *
 *  DESCRIPTION: Attaches a record as specified by a chunk handle to a database.
 *
 *					The function may be used to replace or insert a record:
 *
 *					if oldHP is non-null, then the operation is a replacement, and
 *					the handle of the old record at the given index will be returned;
 *					if oldHP is null, the operation is an insertion.	
 *
 *  PARAMETERS: 
 *		dbR 		- reference to open database
 *		*atP		- desired index to insert record at, actual index on return.
 *		newH		- handle of new record or NULL (if NULL, record's localChunkID
 *					  field will be set to zero in the record list)
 *		*oldHP	- handle of replaced record returned here (this record chunk
 *					  is orphaned - dmOrphanOwnerID).
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	11/18/97	Added header comment about dual role of oldHP
 *
 *************************************************************/
Err	DmAttachRecord(DmOpenRef dbR, UIntPtr atP, Handle newH,
				Handle*	oldHP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				numRecords, index;
	RecordEntryPtr	recordP;
	Err				err;
	LocalID			id;
	DmOpenInfoPtr	openP = dbP->openP;


	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
	
	
	// Make sure the record is in the right card
	if (newH) {
		if (MemHandleCardNo(newH) != openP->cardNo)
			{err =  dmErrRecordInWrongCard; goto Exit;}
		}


	// Range check if replacing
	numRecords = openP->numRecords;
	index = *atP;
	if (oldHP)
		if (index >= numRecords) {err = dmErrIndexOutOfRange; goto Exit;}


	// Adjust the at index given the number of records in the database
	if (index > openP->numRecords) {
		index = openP->numRecords;
		*atP = index;
		}



	// Grow the record entry table to add space for the new record if we're
	//  inserting
	if (!oldHP) {
		// If database is empty, make room for the first entry
		if (openP->numRecords == 0) {
			ULong		reqSize;
			
			// DOLATER... this can cause a failure in the multiple storage heap
			// model if there isn't enough space to grow the list in its current
			// heap, event if there is plenty of space in other heaps.  For multiple
			// heap support (since we can't just move the db header to a different heap
			// because that would invalidate its database id), we could fall back on leaving
			// the database header with zero record entries and shifting the new entry
			// as is done below for all other cases.  vmk 1/13/98
			
			reqSize = sizeof(DatabaseHdrType) + sizeof(RecordEntryType);
			MemPtrUnlock(openP->hdrP);
			err = MemHandleResize(openP->hdrH, reqSize);
			openP->hdrP = MemHandleLock(openP->hdrH);
			if (err) goto ExitNoErrCheck;
			openP->hdrP->recordList.numRecords = 1;
			}
			
		// Else shift existing records down to make room
		else {
			if (index == openP->numRecords)
				err = PrvShiftEntriesDown(dbR, index-1, 0, true);
			else
				err = PrvShiftEntriesDown(dbR, index, 0, true);
			}
		if (err) {
			if (err == dmErrMemError) goto ExitNoErrCheck;
			goto Exit;
			}
		
		// DOLATER... when appending a record at the end of the list (a fairly common case)
		// the call PrvShiftEntriesDown(dbR, index-1, 0, true) causes a bit of unnecessary work
		// to happen in PrvShiftEntriesDown -- a couple of loops and a fair amount of setup
		// code is executed to copy the next-to-last entry into the new record's entry in the list.
		// This common case can possibly be detected and optimized out.  Profiling will need to
		// be done to determine if this is worth it.  1/6/98 vmk
		
		// Bump the cached # of records and initialize the attributes and unique ID
		openP->numRecords++;
		recordP = PrvRecordEntryPtr(openP, index, 0);
		recordP->attributes = 0;
		PrvSetUniqueID(openP->hdrP, recordP);
		}


	// Return the old chunkID if replacing
	else  {
		recordP = PrvRecordEntryPtr(openP, index, 0);
		id =  recordP->localChunkID;
		*oldHP = MemLocalIDToGlobal(id, openP->cardNo);
		MemHandleSetOwner(*oldHP, dmOrphanOwnerID);
		}


	// Put the new one in the list
	if (newH) {
		recordP->localChunkID = MemHandleToLocalID(newH);
		MemHandleSetOwner(newH, dmRecOwnerID);
		}
	else
		recordP->localChunkID = 0;
	
	// Set the dirty bit
	recordP->attributes |= dmRecAttrDirty;

	// Bump the mod number
	openP->hdrP->modificationNumber++;


	err = 0;
	
Exit:
	ErrFatalDisplayIf(err, "Err Attaching rec");
	
ExitNoErrCheck:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	return err;
}


/************************************************************
 *
 *  FUNCTION: DmDetachRecord
 *
 *  DESCRIPTION: Detaches a record from a database but does not
 *    delete the record's chunk
 *
 *  PARAMETERS: 
 *			dbR 			- reference to open database
 *			index			- index of record to detach
 *			*oldHP		- handle of detached record returned here.
 *
 *  RETURNS: ChunkID of record that was detached
 *
 *  CREATED: 11/21/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmDetachRecord(DmOpenRef dbR, UInt index, Handle* oldHP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	LocalID			id;
	RecordEntryPtr	recordP;
	Err				err;
	DmOpenInfoPtr	openP = dbP->openP;
	
	
	// Enable writes
	MemSemaphoreReserve(true);
		
	
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}

	// Get the entry pointer for the record
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {err = dmErrIndexOutOfRange; goto Exit;}
	
	
	// Save the handle of the old record
	id = recordP->localChunkID;
	if (id) {
		*oldHP = MemLocalIDToGlobal(id, openP->cardNo);
		MemHandleSetOwner(*oldHP, dmOrphanOwnerID);
		}
	else
		*oldHP = 0;



	// Adjust the number of records and shift later ones up
	err = PrvShiftEntriesUp(dbR, index+1, 0, true);
	if (err) goto Exit;

	// Decrease cached copy of number of records.
	openP->numRecords--;
	
	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	// Restore Write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err Detaching Rec");
	return err;
}





/************************************************************
 *
 *  FUNCTION: DmMoveRecord
 *
 *  DESCRIPTION: Moves a record from one index to another
 *		Will insert the record at the 'to' index and move other
 *		records down.
 *
 *    The to position should be viewed as an insertion position. 
 *		 Note that this value may be one greater than the index of
 *		 the last record in the database.
 *
 *  PARAMETERS: database access ptr, src index and dst index
 *
 *  RETURNS: ChunkID of record that was detached
 *
 *  CREATED: 11/21/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmMoveRecord(DmOpenRef dbR, UInt from, UInt to)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	RecordEntryType	info;
	RecordEntryPtr		recordP;
	DmOpenInfoPtr		openP = dbP->openP;
	Err					err;
	
	
	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}

	// Check the range on the to indices
	if (to > openP->numRecords) 
		{err = dmErrIndexOutOfRange; goto Exit;}


	// Get the info on the record we're moving
	recordP = PrvRecordEntryPtr(openP, from, 0);
	if (!recordP) { err =  dmErrIndexOutOfRange; goto Exit;}
	info = *recordP;


	// Shift existing records around
	if (from > to) 
		err = PrvShiftEntriesDown(dbR, to, from-to, false);
	// When to is > from, to can actually be equal to numRecords.
	else if (to > from) {
		UInt count = to-from-1;
		if (count)
			err = PrvShiftEntriesUp(dbR, from+1, count, false);
		else
			err = 0;
		to--;
		}
	else
		err = 0;
		
		
	// Put the record in it's new place
	recordP = PrvRecordEntryPtr(openP, to, 0); 
	*recordP = info;

	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err Moving rec");
	return err;
}



/************************************************************
 *
 *  FUNCTION: PrvExchangeRecord
 *
 *  DESCRIPTION: Exchange two database records.
 *
 *  PARAMETERS: database access pointer, one record, another record
 *
 *  RETURNS: the records' positions are exchanged
 *
 *  CREATED: 1/30/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static void PrvExchangeRecord (DmOpenRef dbR, Int left, Int right)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	RecordEntryType	info;
	DmOpenInfoPtr		openP = dbP->openP;
	RecordEntryPtr		leftP, rightP;


	// Bump the mod number
	openP->hdrP->modificationNumber++;

	// Do the exchange
	leftP = PrvRecordEntryPtr(openP, left, 0);
	rightP = PrvRecordEntryPtr(openP, right, 0);
	info = *leftP;
	*leftP = *rightP;
	*rightP = info;
	
}


/************************************************************
 *
 *  FUNCTION: PrvFastLockRecord
 *
 *  DESCRIPTION: Return a pointer to a record or a 0 if deleted.
 *               All records are assumed to have been locked before.
 *					  ROM based records fail.
 *
 *	 CALLED BY:	  PrvInsertionSort, PrvQuickSort
 *  PARAMETERS: database access ptr, index
 *
 *  RETURNS: record ptr or 0 if deleted
 *
 *  CREATED: 11/21/94
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static VoidPtr PrvFastLockRecord(DmOpenInfoPtr openP, UInt index)
{
	LocalID id;
	Handle recordH=0;
	RecordEntryPtr recordP;
	
	
	// Get the entry ptr
	recordP = PrvRecordEntryPtr(openP, index, 0);
	
	
	// Check the attributes and make sure it's not marked for deletion
	if (recordP->attributes & dmRecAttrDelete)
		return 0;
	
	id = recordP->localChunkID;
	recordH = MemLocalIDToGlobal(id, openP->cardNo);

	return MemDeref(recordH);
}


/************************************************************
 *
 *  FUNCTION: PrvInsertionSort
 *
 *  DESCRIPTION: Sorts records in a database.  Deleted records 
 *  are placed last in any order.  All others are sorted 
 *  according to the passed comparison function.  Only records 
 *  which are out of order move.  Moved records are moved to the
 *  end of the range of equal records.  If a large amount of 
 *  records are being sorted try to use the quick sort.
 *
 *  This the insertion sort algorithm.  Starting with the second
 *  record, each record is compared to the preceeding record.
 *  Each record not greater than the last is inserted into 
 *  sorted position within those already sorted.  A binary insertion
 *  is performed.  A moved record is inserted after any other
 *  equal records.
 *
 *  PARAMETERS: base pointer to an array of records, number of records 
 *  to sort (must be at least 2), a record comparison function, 
 *  other data passed to the comparison function.
 *
 *  RETURNS: a sorted portion of the database
 *
 *  CREATED: 12/4/95		Copied from PrvSysInsertionSortHelp
 *
 *  BY: Roger Flores
 *
 *************************************************************/

// Compare records considering if they are deleted.  Does not
// call Fcmp if either record is deleted.  
// Returns results similar to Fcmp.
#define  compareRecords(left, right, leftEntryP, rightEntryP) 		\
		((!left && !right) ? 0 :												\
		 ((!left) ? 1 :															\
		 ((!right) ? -1 :															\
		 Fcmp ( left, right, other, 											\
		 (SortRecordInfoPtr)&leftEntryP->attributes, 					\
		 (SortRecordInfoPtr)&rightEntryP->attributes,					\
		 appInfoH))))

#define  derefRecord(openP, recordP)										\
		(recordP->attributes & dmRecAttrDelete) ? 0 :					\
		MemLocalIDToPtr (recordP->localChunkID, openP->cardNo)

 
// Keep separate from DmInsertionSort so PrvSysQuickSort
// doesn't have to pay a sys trap everytime is calls this routine.

// NOTE!  There is a differnce between this algorithm and the one
// embedded within the quick sort routine.   Only this one places
// identical records at the end of those already existing.

static void PrvInsertionSort (const DmAccessPtr dbP, Int base, 
	Int numOfElements, const DmComparF *Fcmp, Int other)
{
   Int      		result;
	Int 				pivot, left, right;
	Int				binaryLeft, binaryMiddle, binaryRight;
   Ptr				leftRecP=0, pivotRecP=0, middleRecP;
   RecordEntryPtr	leftEntryP;
   RecordEntryPtr	pivotEntryP;
   RecordEntryPtr	middleEntryP;
	DmOpenInfoPtr	openP = dbP->openP;
	VoidHand			appInfoH;


	// Nearly identical code is used in DmPrvQSortHelp.  Make any modification to it too.
	// The variable names are kept similar to those in DmPrvQSortHelp so that
	// changes made to one can be easily made to the other.
	
	if (openP->hdrP->appInfoID)
		appInfoH = MemLocalIDToGlobal (openP->hdrP->appInfoID, openP->cardNo);
	else
		appInfoH = 0;
	
	left = base;
	pivot = base + 1;
	right = base + numOfElements;	// pivot should never be used when >= right
											// Since right can be past the end of the DB

	leftEntryP = PrvRecordEntryPtr (openP, left, 0);
	leftRecP = derefRecord (openP, leftEntryP);
	
	// perform an insertion sort.  Scan from left to right.  For each item not
	// >= then the last binary insert it in place. O(n) = n log2 n comparisons but
	// still O(n) = n^2 data movements.
	while (pivot < right)
		{
		pivotEntryP = PrvRecordEntryPtr (openP, pivot, 0);
		pivotRecP = derefRecord (openP, pivotEntryP);

		// Is the next item >= then the last?
		if (compareRecords (leftRecP, pivotRecP, leftEntryP, pivotEntryP) > 0) 
			{
			// Binary insert into place.
			binaryLeft = base;
			binaryRight = left;
			
			
			while (binaryLeft < binaryRight)
				{
				binaryMiddle = (binaryLeft + binaryRight) / 2;
				
				// Get and compare the middle record
				middleEntryP = PrvRecordEntryPtr (openP, binaryMiddle, 0);
				middleRecP = derefRecord (openP, middleEntryP);
				result = compareRecords (pivotRecP, middleRecP,	pivotEntryP, middleEntryP);
				
				if (result < 0)
					{
					binaryRight = binaryMiddle - 1;
					}
				else
					{
					// result >= 0
					binaryLeft = binaryMiddle + 1;
					}
				}
			
			// The binaryLeft and binaryRight have converged to a position.
			// This position may not have been tested.  The record to insert
			// might belong after this position.  Check for this.
			if (binaryLeft >= binaryRight)
				{
				binaryMiddle = binaryLeft;
				middleEntryP = PrvRecordEntryPtr (openP, binaryMiddle, 0);
				middleRecP = derefRecord (openP, middleEntryP);
				result = compareRecords (pivotRecP, middleRecP, pivotEntryP, middleEntryP);
				if (result >= 0)
					binaryMiddle++;		// insert after 
				}
			
			// Move the record from pivot to binaryMiddle
			DmMoveRecord(dbP, pivot, binaryMiddle);
			
			// Advance
			left = pivot;
			leftEntryP = PrvRecordEntryPtr (openP, left, 0);
			leftRecP = derefRecord (openP, leftEntryP);
			pivot++;
			}
		else
			{
			// Advance
			left = pivot;
			leftRecP = pivotRecP;
			leftEntryP = pivotEntryP;
			pivot++;
			}
		}

}


/************************************************************
 *
 *  FUNCTION: DmInsertionSort
 *
 *  DESCRIPTION: Sorts records in a database.  Deleted records 
 *  are placed last in any order.  All others are sorted 
 *  according to the passed comparison function.  Only records 
 *  which are out of order move.  Moved records are moved to 
 *  the end of the range of equal records.  If a large amount 
 *  of records are being sorted try to use the quick sort.
 *
 *  This the insertion sort algorithm.  Starting with the second
 *  record, each record is compared to the preceeding record.
 *  Each record not greater than the last is inserted into 
 *  sorted position within those already sorted.  A binary insertion
 *  is performed.  A moved record is inserted after any other
 *  equal records.
 *
 *  PARAMETERS: database access pointer, comparison function, 
 *		other data passed to the comparison function.
 *
 *	 *fcmp, the comparison function, accepts two arguments, elem1
 *  and elem2, each a pointer to an entry in the table. The
 *  comparison function compares each of the pointed-to items
 *  (*elem1 and *elem2), and returns an integer based on the result
 *  of the comparison.
 * 
 *  If the items            fcmp returns
 *  *elem1 <  *elem2         an integer < 0
 *  *elem1 == *elem2         0
 *  *elem1 >  *elem2         an integer > 0
 * 
 *  RETURNS: a sorted database
 *
 *  CREATED: 11/30/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/

Err DmInsertionSort(const DmOpenRef dbR, DmComparF *compar, Int other)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr		openP = dbP->openP;
	Int					numOfRecords;
	Handle				recordH;


	// Check for errors
	if (!openP->writeAccess)
		return dmErrReadOnly; 

	// Only sort if 2 or more records need sorting.
	if (openP->numRecords < 2)
		return 0;
		
	// Enable writes to storage memory
	MemSemaphoreReserve(true);
		

	// Lock all the records
	numOfRecords = openP->numRecords;
	while (numOfRecords >= 0)
		{
		recordH = DmQueryRecord(dbR, numOfRecords);
		if (recordH) MemHandleLock(recordH);
		numOfRecords--;
		}


   PrvInsertionSort (dbP, 0, DmNumRecords(dbP), compar, other);


	// Unlock all the records
	numOfRecords = openP->numRecords;
	while (numOfRecords >= 0)
		{
		recordH = DmQueryRecord(dbR, numOfRecords);
		if (recordH) MemHandleUnlock(recordH);
		numOfRecords--;
		}


	// Restore write-protection
	MemSemaphoreRelease(true);
	
	return 0;
}


/************************************************************
 *
 *  FUNCTION: PrvQuickSort
 *
 *  DESCRIPTION: Sorts records in a database.  Deleted records 
 *  are placed last in any order.  All others are sorted 
 *  according to the passed comparison function.  Remember that
 *  equal records can be in any position relative to each other
 *  because a quick sort tends to scramble the ordering of records.
 *  All records are presumed to locked.
 *
 *  This the common quick sort algorithm.  The pivot point is picked
 *  by picking the middle of three records picked from around the 
 *  middle of the records to sort to take advantage of partially
 *  sorted data.  The routine contains it's own stack to limit
 *  uncontrolled recursion.  When the stack is full an insertion 
 *  sort is used instead because it doesn't require more stack 
 *  space.  An insertion sort is also used when the number of records
 *  is low.  This avoids the overhead of a quick sort which is
 *  noticeable for small numbers of records.  The last optimization
 *  is that if the records seem mostly sorted an insertion sort is 
 *  performed to move only those few records needing moving.
 *
 *  PARAMETERS: database access pointer, pivot record, number of
 *  records to sort (must be at least 2), comparison function, 
 *  other data passed to the comparison function.
 *
 *  RETURNS: a sorted portion of the database
 *
 *  CREATED: 1/30/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/
 
    		
typedef struct {
	Int	base;
	Int	numOfElements;
} SortStackType;

#define stackSpace		20		// On avg. the mose used should be about 12 for a 512K card.

#define insertionSortThreshold	12



static void PrvQuickSort (const DmAccessPtr dbP, Int base, Int numOfElements, 
	const DmComparF *Fcmp, Int other)
{
   Int      		result;
	Int 				pivot, pivotLocation;
	Int     			left=0, right=0, temp;
	Int				binaryLeft, binaryMiddle, binaryRight;
   UInt				movedRecords;
   Ptr				leftRecP=0, rightRecP=0, pivotRecP=0, middleRecP, tempRecP;
   RecordEntryPtr	leftEntryP;
   RecordEntryPtr rightEntryP;
   RecordEntryPtr	pivotEntryP;
   RecordEntryPtr	middleEntryP;
   RecordEntryPtr	tempEntryP;
	DmOpenInfoPtr	openP = dbP->openP;
	SortStackType	stack[stackSpace];
	SortStackType	*sp = stack;
	VoidHand			appInfoH;

	if (openP->hdrP->appInfoID)
		appInfoH = MemLocalIDToGlobal (openP->hdrP->appInfoID, openP->cardNo);
	else
		appInfoH = 0;
	
	while (true)
		{
		// base and numOfElements must be set for the range to sort
		
		
		// This is the first part of the quick sort algorithm.  It actually
		// is an insertion sort.  It is used when the number of elements is
		// low (quick sort has too much overhead) or when the function's stack
		// is out of space.
		if (numOfElements <= insertionSortThreshold || 
			sp >= &stack[stackSpace])
			{
doInsertionSort:
			left = base;
			pivot = base + 1;
			right = base + numOfElements;	// pivot should never be used when >= right
														// Since right can be past the end of the DB

			leftEntryP = PrvRecordEntryPtr (openP, left, 0);
			leftRecP = derefRecord (openP, leftEntryP);	
			
			// perform an insertion sort.  Scan from left to right.  For each item not
			// >= then the last binary insert it in place. O(n) = n log2 n comparisons but
			// still O(n) = n^2 data movements.
			while (pivot < right)
				{
				pivotEntryP = PrvRecordEntryPtr (openP, pivot, 0);
				pivotRecP = derefRecord (openP, pivotEntryP);

				// Is the next item >= then the last?
				if (compareRecords (leftRecP, pivotRecP, leftEntryP, pivotEntryP) > 0) 
					{
					// Binary insert into place.
					binaryLeft = base;
					binaryRight = left;
					
					
					while (binaryLeft < binaryRight)
						{
						binaryMiddle = (binaryLeft + binaryRight) / 2;
						
						// Get and compare the middle record
						middleEntryP = PrvRecordEntryPtr (openP, binaryMiddle, 0);
						middleRecP = derefRecord (openP, middleEntryP);
						result = compareRecords (pivotRecP, middleRecP, pivotEntryP, middleEntryP);
						
						if (result < 0)
							{
							binaryRight = binaryMiddle - 1;
							}
						else if (result > 0)
							{
							binaryLeft = binaryMiddle + 1;
							}
						else
							// Equal.  Just place the item here.
							break;
						}
					
					// The binaryLeft and binaryRight have converged to a position.
					// This position may not have been tested.  The record to insert
					// might belong after this position.  Check for this.
					if (binaryLeft >= binaryRight)
						{
						binaryMiddle = binaryLeft;
						middleEntryP = PrvRecordEntryPtr (openP, binaryMiddle, 0);
						middleRecP = derefRecord (openP, middleEntryP);
						result = compareRecords (pivotRecP, middleRecP, pivotEntryP, middleEntryP);
						if (result > 0)
							binaryMiddle++;		// insert after 
						}
					
					// Move the record from pivot to binaryMiddle
					DmMoveRecord(dbP, pivot, binaryMiddle);
					
					// Advance
					left = pivot;
					leftEntryP = PrvRecordEntryPtr (openP, left, 0);
					leftRecP = derefRecord (openP, leftEntryP);
					pivot++;
					}
				else
					{
					// Advance
					left = pivot;
					leftRecP = pivotRecP;
					leftEntryP = pivotEntryP;
					pivot++;
					}
				}

			
			// We are done with portion of the data.  Check the stack for
			// another portion to sort.  If there isn't any then we're done.
			if (sp != stack)
				{
				sp--;
				base = sp->base;
				numOfElements = sp->numOfElements;
				}
			else
				break;							// done with the sort.
			}
		else
			{
			// This is the second part of the quick sort.  Here is the sorting
			// performed is the real quick sort algorithm.  A record is picked
			// close to the middle of the sort order and the records are
			// separated in half to those less and those greater than the pivot.
			// One half is placed on the stack for later sorting.  The algorithm 
			// loops and then sorts the other half.
			
			
			// A good deal of the data we sort is already partially sorted.  Try
			// to pick the pivot from around the middle of the data.
			pivot = (numOfElements / 2) + base;
			left = pivot - ((numOfElements / 16) | 1);		// 1/16 offcenter - at least 1
			right = pivot + ((numOfElements / 16) | 1);		// 1/16 offcenter - at least 1
			
			leftEntryP = PrvRecordEntryPtr (openP, left, 0);
			leftRecP = derefRecord (openP, leftEntryP);

			rightEntryP = PrvRecordEntryPtr (openP, right, 0);
			rightRecP = derefRecord (openP, rightEntryP);

			pivotEntryP = PrvRecordEntryPtr (openP, pivot, 0);
			pivotRecP = derefRecord (openP, pivotEntryP);

			// Make pivot point to the middle most record of the three.
		   if (compareRecords(leftRecP, pivotRecP, leftEntryP, pivotEntryP) > 0) 
				{
				temp = left;
				tempRecP = leftRecP;
				tempEntryP = leftEntryP;
				left = pivot;
				leftRecP = pivotRecP;
				leftEntryP = pivotEntryP;
				pivot = temp;
				pivotRecP = tempRecP;
				pivotEntryP = tempEntryP;
				}

		   if (compareRecords(pivotRecP, rightRecP, pivotEntryP, rightEntryP) > 0) 
				{
				temp = pivot;
				tempRecP = pivotRecP;
				tempEntryP = pivotEntryP;
				pivot = right;
				pivotRecP = rightRecP;
				pivotEntryP = rightEntryP;
				right = temp;
				rightRecP = tempRecP;
				rightEntryP = tempEntryP;
				}

		   if (compareRecords(leftRecP, pivotRecP, leftEntryP, pivotEntryP) > 0) 
				{
				temp = left;
				tempRecP = leftRecP;
				tempEntryP = leftEntryP;
				left = pivot;
				leftRecP = pivotRecP;
				leftEntryP = pivotEntryP;
				pivot = temp;
				pivotRecP = tempRecP;
				pivotEntryP = tempEntryP;
				}
			
			
			// Move the pivot to the beginning so that it isn't overrun during the
			// swapping of elements.
			PrvExchangeRecord (dbP, base, pivot);
			pivotLocation = pivot;
			pivot = base;
			
			// Set the end points of the swap run
			left = base + 1;
			right = base + numOfElements - 1;

			leftEntryP = PrvRecordEntryPtr (openP, left, 0);
			leftRecP = derefRecord (openP, leftEntryP);

			rightEntryP = PrvRecordEntryPtr (openP, right, 0);
			rightRecP = derefRecord (openP, rightEntryP);

			pivotEntryP = PrvRecordEntryPtr (openP, pivot, 0);
			pivotRecP = derefRecord (openP, pivotEntryP);

			movedRecords = 0;
			
			// repetitively swap elements
			while (true)
				{
				// Scan from the left to the right for an element greater than the pivot
				while (compareRecords(leftRecP, pivotRecP, leftEntryP, pivotEntryP) < 0)
					{
					left++;
					leftEntryP = PrvRecordEntryPtr (openP, left, 0);
					leftRecP = derefRecord (openP, leftEntryP);					
					}
				
				// Scan from the right to the left for an element less than the pivot
				while (compareRecords(pivotRecP, rightRecP, pivotEntryP, rightEntryP) < 0)
					{
					right--;
					rightEntryP = PrvRecordEntryPtr (openP, right, 0);
					rightRecP = derefRecord (openP, rightEntryP);
					}
				
				// Check to see if left crossed right
				if (left > right)
					break;
				
				// Exchange the two records and scan again
				PrvExchangeRecord (dbP, left, right);
				left++;
				right--;

				leftEntryP = PrvRecordEntryPtr (openP, left, 0);
				leftRecP = derefRecord (openP, leftEntryP);
	
				rightEntryP = PrvRecordEntryPtr (openP, right, 0);
				rightRecP = derefRecord (openP, rightEntryP);

				
				movedRecords++;
				}
				
			// Done moving all the records.  Restore the pivot.
			// If the records seem ordered take extra care
			if (movedRecords > (numOfElements >> 2) )
				{
				PrvExchangeRecord (dbP, pivot, right);
				}
			else
				{
				// if pivot really was in middle (well sorted case)
				if (right == pivotLocation)
					{
					// Moves the first record back into place
					PrvExchangeRecord (dbP, pivot, right);	// safe to do
					}
				else
					{
					// Move the record from pivot to right.  The first
					// record isn't back in place - it's lost.  The move
					// does prevent a high position record from being swapped
					// from right to the first position.
					DmMoveRecord(dbP, pivot, right);
					}
				}


			// Check if the data was mostly sorted.
			// We could avoid the goto but it means slowing down the algorithm.
			// If less than four records were swapped out of at least 32 then 
			// just move those records into place.  (least orderly case)
			if ( (movedRecords - 1) < (numOfElements >> 5) )
				{
				goto doInsertionSort;
				}
			else
				{
				// Now sort the smaller of the two halves and place the larger
				// one on the stack for later.
				if ((right - base + 1) > ((base + numOfElements) - left))
					{
					// the left half is larger
					sp->numOfElements = right - base + 1;
					sp->base = base;
					numOfElements -= left - base;
					base = left;
					}
				else
					{
					// the right half is larger
					sp->numOfElements = (base + numOfElements) - left;
					sp->base = left;
					numOfElements = right - base + 1;
					}
				sp++;
				}
			}

		}
			

	// exit
}


/************************************************************
 *
 *  FUNCTION: DmQuickSort
 *
 *  DESCRIPTION: Sorts records in a database.  Deleted records 
 *  are placed last in any order.  All others are sorted 
 *  according to the passed comparison function.
 *
 *  PARAMETERS: database access pointer, comparison function, 
 *		other data passed to the comparison function.
 *
 *	 *fcmp, the comparison function, accepts two arguments, elem1
 *  and elem2, each a pointer to an entry in the table. The
 *  comparison function compares each of the pointed-to items
 *  (*elem1 and *elem2), and returns an integer based on the result
 *  of the comparison.
 * 
 *  If the items            fcmp returns
 *  *elem1 <  *elem2         an integer < 0
 *  *elem1 == *elem2         0
 *  *elem1 >  *elem2         an integer > 0
 * 
 *  RETURNS: a sorted database
 *
 *  CREATED: 1/30/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err DmQuickSort(const DmOpenRef dbR, DmComparF *compar, Int other)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr		openP = dbP->openP;
	Int					numOfRecords;
	Handle				recordH;


	// Check for errors
	if (!openP->writeAccess)
		return dmErrReadOnly; 

	// Only sort if 2 or more records need sorting.
	if (openP->numRecords < 2)
		return 0;
		
	// Enable writes to storage memory
	MemSemaphoreReserve(true);
		

	// Lock all the records
	numOfRecords = openP->numRecords;
	while (numOfRecords >= 0)
		{
		recordH = DmQueryRecord(dbR, numOfRecords);
		if (recordH) MemHandleLock(recordH);
		numOfRecords--;
		}


   PrvQuickSort (dbP, 0, DmNumRecords(dbP), compar, other);


	// Unlock all the records
	numOfRecords = openP->numRecords;
	while (numOfRecords >= 0)
		{
		recordH = DmQueryRecord(dbR, numOfRecords);
		if (recordH) MemHandleUnlock(recordH);
		numOfRecords--;
		}


	// Restore write-protection
	MemSemaphoreRelease(true);
	
	return 0;
}


/************************************************************
 *
 *  FUNCTION: DmFindSortPosition
 *
 *  DESCRIPTION: Return where a record is or should be.
 *		Useful to find or find where to insert a record.
 *    Uses a binary search.
 *
 *  PARAMETERS: database access pointer, record ptr, 
 *		comparison function pointer, other info for comparison
 *
 *  RETURNS: the position where the record should be inserted.
 *    The position should be viewed as between the record returned
 *    and the record before it.  Note that the return value may
 *    be one greater than the number of records.
 *
 *  CREATED: 6/16/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
UInt DmFindSortPosition(DmOpenRef dbR, VoidPtr newRecord, SortRecordInfoPtr newRecordInfo,
	DmComparF *compar, Int other)
{
	DmAccessPtr			dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr		openP = dbP->openP;
	
	Int 					numOfRecords;
	Handle				recordH;
	RecordEntryPtr		recordP;
	VoidPtr				*r;
	UInt 					kmin, probe, i;			// all positions in the database.
	Int 					result;						// result of comparing two records
	Boolean 				binarySearch = true;
	VoidHand				appInfoH;
	

	result = -1;		// for the case when there aren't any records
	kmin = probe = 0;
	numOfRecords = openP->numRecords;
	recordH = 0;
	
	if (openP->hdrP->appInfoID)
		appInfoH = MemLocalIDToGlobal (openP->hdrP->appInfoID, openP->cardNo);
	else
		appInfoH = 0;
	
	while (numOfRecords > 0)
		{
		i = numOfRecords / 2;
		probe = kmin + i;


		// Compare the two records.  Treat deleted records as greater.
		// If the records are equal look at the following position.
		do {
			if (recordH) MemHandleUnlock(recordH);

			recordH = DmQueryRecord(dbP, probe);
			if (recordH == 0) 
				{
				if (binarySearch)
					{
					result = -1;		// Delete record is greater
					break;
					}
				else
					// Handle incremental search past the end of 
					// normal data (into deleted records or off end
					// of the database).  Return position after last
					// normal record.
					return probe;
				}
			else
				{
				r = MemHandleLock(recordH);
				ErrFatalDisplayIf(r == 0, "DmFindSortPosition: data somehow missing");

				recordP = PrvRecordEntryPtr(openP, probe, 0);
				result = compar(newRecord, r, other, newRecordInfo, 
					(SortRecordInfoPtr) &recordP->attributes, appInfoH);
					
				// If equal look at the following position
				if (result == 0)
					{
					binarySearch = false;
					probe++;
					}
				else
					{
					// If we've stopped binary searching then we've found 
					// our position.
					if (!binarySearch)
						{
						MemHandleUnlock(recordH);
						return probe;
						}
					break;
					}
				}
			} while (true);

		ErrFatalDisplayIf(result == 0, "Impossible bsearch state");
		
		// More likely than < 0 because of deleted records
		if (result > 0)
			{
			kmin = probe + 1;
			numOfRecords = numOfRecords - i - 1;
			}
		else
			numOfRecords = i;
		}

	if (recordH)
		MemHandleUnlock(recordH);
	return (result < 0) ? probe : probe + 1;
}


/************************************************************
 *
 *  FUNCTION: DmFindSortPositionV10
 *
 *  DESCRIPTION: Return where a record is or should be.
 *		Useful to find or find where to insert a record.
 *    Uses a binary search.
 *
 *  PARAMETERS: database access pointer, record ptr, 
 *		comparison function pointer, other info for comparison
 *
 *  RETURNS: the position where the record should be inserted.
 *    The position should be viewed as between the record returned
 *    and the record before it.  Note that the return value may
 *    be one greater than the number of records.
 *
 *  CREATED: 6/16/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
UInt DmFindSortPositionV10 (DmOpenRef dbR, VoidPtr newRecord, 
	DmComparF *compar, Int other)
{
	return (DmFindSortPosition (dbR, newRecord, NULL,	compar, other));
}


/************************************************************
 *
 *  FUNCTION: DmNewRecord
 *
 *  DESCRIPTION: Returns a handle to a new record in 
 *    the database and marks the record busy
 *
 *  PARAMETERS: database access pointer, record index ptr, 
 *		desired size.
 *
 *  RETURNS: ptr to record data
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	DmNewRecord(DmOpenRef dbR, UIntPtr atP, ULong size)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Err				err=0;
	Handle			recordH=0;
	DmOpenInfoPtr	openP = dbP->openP;
	RecordEntryPtr	recordP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;


	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	if (openP->resDB) 
		{err = dmErrNotRecordDB; goto Exit;}
		
	// First, try and allocate a new chunk of the desired size in the
	//  same card as the database header
	recordH = DmNewHandle(dbP, size);
	if (!recordH) {err = dmErrMemError; goto ExitNoErrCheck; }
	

	// Now, attach it to the database
	err = DmAttachRecord(dbP, atP, recordH, 0);
	if (err) {
		if (err == memErrNotEnoughSpace || err == dmErrMemError) goto ExitNoErrCheck;
		else goto Exit;
		}


	// Mark busy and dirty
	recordP = PrvRecordEntryPtr(openP, *atP, 0);
	recordP->attributes |= (dmRecAttrBusy | dmRecAttrDirty);

	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	ErrFatalDisplayIf(err, "Err creating new rec");

ExitNoErrCheck:

	// Restore write-protection
	MemSemaphoreRelease(true);
		
	if (err) {
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		appInfoP->dmLastErr = err;
		if (recordH) MemHandleFree(recordH);
		recordH = 0;
		}

	return recordH;
}



/************************************************************
 *
 *  FUNCTION: DmRemoveRecord
 *
 *  DESCRIPTION: Detaches and deletes a record without a trace
 *
 *  PARAMETERS: database access pointer, record index
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmRemoveRecord(DmOpenRef dbR, UInt index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Err				err;
	Handle			h;
	DmOpenInfoPtr	openP = dbP->openP;

	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}

	// First, detach it
	err = DmDetachRecord(dbP, index, &h);
	if (err) goto Exit;

	// Now, free the memory used by the record
	if (h) err = MemHandleFree(h);
	
	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err Removing rec");
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmDeleteRecord
 *
 *  DESCRIPTION: Deletes a record's chunk from a database but
 *		leaves the record entry in the header and sets the delete bit
 *		for the next sync.
 *
 *  PARAMETERS: database access pointer, record index
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	11/18/97		Mark the record dirty
 *
 *************************************************************/
Err	DmDeleteRecord(DmOpenRef dbR, UInt index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Err				err;
	LocalID			id;
	Handle			h;
	DmOpenInfoPtr	openP = dbP->openP;
	RecordEntryPtr	recordP;

	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	// Set the delete bit
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {
		err = dmErrIndexOutOfRange;
		goto Exit;
		}
		
	recordP->attributes |= (dmRecAttrDelete | dmRecAttrDirty);

	// Now, delete the chunk and set the chunkID to nil
	id = recordP->localChunkID;
	if (id) {
		h = MemLocalIDToGlobal(id, openP->cardNo);
		err =  MemHandleFree(h);
		}
	
	recordP->localChunkID = 0;


	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		

	ErrFatalDisplayIf(err, "Err Deleting rec");
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmArchiveRecord
 *
 *  DESCRIPTION: Marks a record as archived by
 *		leaving the record's chunk around and setting the delete bit
 *		for the next sync.
 *
 *  PARAMETERS: database access pointer, record index
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	11/18/97		Mark the record dirty
 *
 *************************************************************/
Err	DmArchiveRecord(DmOpenRef dbR, UInt index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err;
	RecordEntryPtr	recordP;

	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	// Set the delete bit
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {
		err = dmErrIndexOutOfRange;
		goto Exit;
		}
	recordP->attributes |= (dmRecAttrDelete | dmRecAttrDirty);
	err = 0;
	
	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err Archiving rec");
	return err;
}


/************************************************************
 *
 *  FUNCTION: DmFindRecordByID
 *
 *  DESCRIPTION: Returns the index of the record with the given unique ID
 *
 *  PARAMETERS: 
 *			dbP - database access ptr
 *			uniqueID - unique ID to search for
 *			*indexP - return index
 *
 *  RETURNS: 0 if found.
 *
 *  CREATED: 6/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmFindRecordByID (DmOpenRef dbR, ULong uniqueID, UIntPtr indexP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				index;
	UInt 				count;
	RecordEntryPtr	recordP=0;
	DmOpenInfoPtr	openP = dbP->openP;
	register ULong	mask;
	BytePtr			idP;
	
	
	// Error check
	ErrFatalDisplayIf(uniqueID & 0xFF000000, "Invalid uniqueID passed");

	// Get total number of records
	count = 	openP->numRecords;

	// Form mask
	mask = 0x00FFFFFF;

	// Walk through till we find a record that has the right uniqueID
	for (index = 0; index < count; index++) {
	
		// Get entry ptr
		recordP = PrvRecordEntryPtr(openP, index, recordP);
		idP = (BytePtr)(&recordP->uniqueID) - 1;
		
		// See if unique ID matches
		if ((*((ULongPtr)idP) & mask) == uniqueID) {
			*indexP = index;
			return 0;
			}
		}
		
	return dmErrUniqueIDNotFound;
}



/************************************************************
 *
 *  FUNCTION: DmQueryRecord
 *
 *  DESCRIPTION: Returns a handle to a record for reading only 
 *		(does not set the busy bit).
 *		If the record is ROM based (pointer accessed) this routine
 *		will return the fake handle to it.
 *
 *  PARAMETERS: database access ptr, index
 *
 *  RETURNS: record handle
 *
 *  CREATED: 11/21/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	DmQueryRecord(DmOpenRef dbR, UInt index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	LocalID 			id;
	Handle			recordH=0;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;
 
	// Range Check, or else we might get an error message from PrvRecordEntryPtr
 	if (index >= openP->numRecords) 
 		{err = dmErrIndexOutOfRange; goto ExitNoCheck;}

	// Get the entry ptr
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {err = dmErrIndexOutOfRange; goto Exit;}
	
	// Check the attributes and make sure it's not marked for deletion
	if (recordP->attributes & dmRecAttrDelete) {
		appInfoP->dmLastErr = dmErrRecordDeleted;
		return 0;
		}

	// If it's pointer based, Get the handle out of our handle table
	if (openP->handleTableP) 
		recordH = &(openP->handleTableP[index]);
		
	else {
		id = recordP->localChunkID;
		recordH = MemLocalIDToGlobal(id, openP->cardNo);
		}
	
	err = 0;
	
Exit:
	ErrFatalDisplayIf(err, "Err Querying rec");
ExitNoCheck:
	appInfoP->dmLastErr = err;
	return recordH;
}



/************************************************************
 *
 *  FUNCTION: DmGetRecord
 *
 *  DESCRIPTION: Returns a handle to a record and sets the busy bit for
 *		the record. If the record is ROM based (pointer accessed) this routine
 *		will make a fake handle to it and store this handle in the
 *		DmAccessType structure.
 *
 *  PARAMETERS: database access ptr, index
 *
 *  RETURNS: record handle
 *
 *  CREATED: 11/21/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	DmGetRecord(DmOpenRef dbR, UInt index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	LocalID 			id;
	Handle			recordH=0;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	
	// Enable writes
	MemSemaphoreReserve(true);
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	
	// Get record entry ptr
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {err = dmErrIndexOutOfRange; goto Exit;}

	// Make sure it's not marked for deletion
	if (recordP->attributes & dmRecAttrDelete) {
		appInfoP->dmLastErr =  dmErrRecordDeleted;
		err=0;
		goto Exit;
		}

	// Make sure it's not busy
	if (recordP->attributes & dmRecAttrBusy) {
		err = dmErrRecordBusy;
		goto Exit;
		}
	
	// Set the busy bit
	recordP->attributes |= dmRecAttrBusy;


	// If it's pointer based, Get the handle out of our handle table
	if (openP->handleTableP) 
		recordH = &(openP->handleTableP[index]);
		
	else {
		id = recordP->localChunkID;
		recordH = MemLocalIDToGlobal(id, openP->cardNo);
		}
	
	err = 0;

Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	ErrFatalDisplayIf(err, "Err Getting rec");
	appInfoP->dmLastErr = err;
	return recordH;
}



/************************************************************
 *
 *  FUNCTION: DmQueryNextInCategory
 *
 *  DESCRIPTION: Returns a handle to the next record in the specified 
 *    category for reading only (does not set the busy bit).
 *		If the record is ROM based (pointer accessed) this routine
 *		will make a fake handle to it and store this handle in the
 *		DmAccessType structure.
 *
 *  PARAMETERS: database access ptr, index, category
 *
 *  RETURNS: record handle, index
 *
 *  CREATED: 3/6/96 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
VoidHand	DmQueryNextInCategory (DmOpenRef dbR, UIntPtr indexP, UInt category)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				index;
	UInt 				count;
	Handle			recordH = 0;
	Byte				attrMask, attrCmp;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;

	count = 	openP->numRecords;

	// Form the mask for comparing the attributes of each record
	if (category == dmAllCategories) {
		attrMask =  dmRecAttrDelete;
		attrCmp = 0;
		}
	else {
		attrMask =  dmRecAttrCategoryMask | dmRecAttrDelete;
		attrCmp = category;
		}
		
	if (!(dbP->mode & dmModeShowSecret))
		attrMask |= dmRecAttrSecret;
		
		

	// Walk through till we find a record that has the right attributes
	index = *indexP;
	recordP = 0;
	for (; index < count; index++) {
		// Get ptr to next record
		recordP = PrvRecordEntryPtr(openP, index, recordP);

		if ((recordP->attributes & attrMask) == attrCmp) {
			// If it's pointer based, Get the handle out of our handle table
			if (openP->handleTableP) 
				recordH = &(openP->handleTableP[index]);	
			else 
				recordH = MemLocalIDToGlobal(recordP->localChunkID, openP->cardNo);
				
			*indexP = index;
			return recordH;
			}
			
		}
		
	appInfoP->dmLastErr = dmErrIndexOutOfRange;
	return 0;
}

/************************************************************
 *
 *  FUNCTION: DmPositionInCategory
 *
 *  DESCRIPTION: Returns a position of a record in the specified 
 *    category.  
 *
 *  PARAMETERS: database access ptr, index, category
 *
 *  RETURNS: position (zero-based)
 *
 *  CREATED: 3/13/96 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
UInt	DmPositionInCategory (DmOpenRef dbR, UInt index, UInt category)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				i;
	UInt				pos = 0;
	Byte				attrMask, attrCmp;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;

	// Check for parameter error
	if (index >= openP->numRecords) {
		appInfoP->dmLastErr = dmErrIndexOutOfRange;
		ErrDisplay("Err Getting position");
		return 0;
		}
		
	// Form the mask for comparing the attributes of each record
	if (category == dmAllCategories) {
		attrMask =  dmRecAttrDelete;
		attrCmp = 0;
		}
	else {
		attrMask =  dmRecAttrCategoryMask | dmRecAttrDelete;
		attrCmp = category;
		}
		
	if (!(dbP->mode & dmModeShowSecret))
		attrMask |= dmRecAttrSecret;
		


	// Get the position within category
	recordP = 0;
	for (i=0; i<= index; i++) {
		recordP = PrvRecordEntryPtr(openP, i, recordP);
		if ((recordP->attributes & attrMask) == attrCmp)
			pos++;
		}
	
	if (pos) pos--;
	
	return (pos);
}


/************************************************************
 *
 *  FUNCTION: DmSeekRecordInCategory
 *
 *  DESCRIPTION: Return the index of the record at the offset from
 *		the passed record index.  The offset parameter indicates the 
 *		number of records to move forewards or backwards (negitive  
 *		value for backwards).
 *
 *  PARAMETERS: database access ptr, index, offset, direction, category
 *
 *              direction is dmSeekForward or dmSeekBackward
 *
 *  RETURNS: record index
 *
 *  CREATED: 3/14/96 
 *
 *  BY: Art Lamb
 *
 *************************************************************/
Err	DmSeekRecordInCategory (DmOpenRef dbR, UIntPtr indexP, Int offset,
	Int direction, UInt category)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Err				err;
	UInt				index;
	UInt				count;
	Byte				attrMask, attrCmp;
	RecordEntryPtr	recordP;
	DmOpenInfoPtr	openP = dbP->openP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	ErrFatalDisplayIf ( (direction != dmSeekForward) && (direction != dmSeekBackward), 
		"Bad Param");

	ErrFatalDisplayIf ( (offset < 0), "Bad param"); 
	
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;
	index = *indexP;

	if (index >= openP->numRecords) {
		if (direction == dmSeekForward)	{ 
			appInfoP->dmLastErr = dmErrIndexOutOfRange;
			return dmErrIndexOutOfRange;
			}
		else {
			index = openP->numRecords - 1;
			}
		}


	// Form the mask for comparing the attributes of each record
	if (category == dmAllCategories) {
		attrMask =  dmRecAttrDelete;
		attrCmp = 0;
		}
	else {
		attrMask =  dmRecAttrCategoryMask | dmRecAttrDelete;
		attrCmp = category;
		}
		
	if (!(dbP->mode & dmModeShowSecret))
		attrMask |= dmRecAttrSecret;
		


	// Moving forward?
	if (direction == dmSeekForward )
		count = openP->numRecords - index;
	else
		count = index + 1;
		
		
	// Loop through the records
	while(count--) {
		// get entry ptr
		recordP = PrvRecordEntryPtr(openP, index, 0);

		if ((recordP->attributes & attrMask) == attrCmp) {
			*indexP = index;
			if (offset == 0) return 0;
			offset--;
			}
			
		index += direction;
		}

	appInfoP->dmLastErr = dmErrSeekFailed;
	return dmErrSeekFailed;
			

Exit:
	ErrFatalDisplayIf(err, "Err seeking rec");
	appInfoP->dmLastErr = err;

	return err;
}


/************************************************************
 *
 *  FUNCTION: DmMoveCategory
 *
 *  DESCRIPTION: Move all record in a category to another category.
 *
 *		If the "dirty" argument is TRUE, the moved records will be marked dirty.
 *
 *  PARAMETERS: database access ptr, from category, to category, dirty boolean
 *
 *  RETURNS: nothing
 *
 *  CREATED: 3/17/96 
 *
 *  BY: Art Lamb
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	11/27/95	Added the "dirty" argument.
 *
 *************************************************************/
Err	DmMoveCategory (DmOpenRef dbR, UInt toCategory, UInt fromCategory, Boolean dirty)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt 				index;
	UInt 				count;
	Byte 				attr;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err=0;
	RecordEntryPtr	recordP=0;
	
	
	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	count = openP->numRecords;
	for (index = 0; index < count; index++)
		{
		recordP = PrvRecordEntryPtr(openP, index, recordP);
		
		// Check if the record's category matches the from category
		// and that the record is not marked for deletion.
		attr = recordP->attributes;
		if (((attr & dmRecAttrCategoryMask) == fromCategory) && 
			 (!(attr & dmRecAttrDelete))) {
			// Change the category of a record.
			attr &= ~dmRecAttrCategoryMask;
			attr |= toCategory;
			
			// Mark the record dirty so the PC moves it's record.  We could have
			// had the PC mark it's records dirty instead of the device, but it's
			// faster for the device to go to the next record and if dirty make the
			// PC search for it's copy rather than have the PC make the device
			// search for the matching record ID.  ### THIS IS NOT ENTIRELY
			// ACCURATE: 1. We're changing the record's category and so should mark it dirty.
			// 2. HotSync Manager on the PC gets to find out about this change by
			// having the dirty flag set for the record on Pilot.
			if ( dirty )
				attr |= dmRecAttrDirty;
			
			recordP->attributes = attr;
			}
		}
		
	// Bump the mod number
	openP->hdrP->modificationNumber++;

Exit:
	// Display err
	ErrFatalDisplayIf(err, "Err moving category");
	
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	return err;
	
}


/************************************************************
 *
 *  FUNCTION: DmDeleteCategory
 *
 *  DESCRIPTION: Delete all records in a category.  The category
 *  name is not changed.
 *
 *  PARAMETERS: dbR - database access ptr
 *					 categoryNum - category of records to delete
 *
 *  RETURNS: 0 if there is no error, an error code otherwise
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	4/18/96	Initial version
 *			vmk	11/18/97	Mark the record dirty
 *
 *************************************************************/
Err	DmDeleteCategory (DmOpenRef dbR, UInt categoryNum)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt 				index;
	UInt 				count;
	Byte 				attr;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err=0;
	RecordEntryPtr	recordP=0;
	LocalID			id;
	Handle			h;
	
	
	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		
	count = openP->numRecords;
	for (index = 0; index < count; index++)
		{
		recordP = PrvRecordEntryPtr(openP, index, recordP);
		
		// Check if the record's category matches the from category
		// and that the record is not marked for deletion.
		attr = recordP->attributes;
		if (((attr & dmRecAttrCategoryMask) == categoryNum) && 
			 (!(attr & dmRecAttrDelete))) 
			{
			// Set the delete bit
			recordP->attributes |= (dmRecAttrDelete | dmRecAttrDirty);
		
			// Now, delete the chunk and set the chunkID to nil
			id = recordP->localChunkID;
			if (id) {
				h = MemLocalIDToGlobal(id, openP->cardNo);
				err =  MemHandleFree(h);
				}
			
			recordP->localChunkID = 0;
			}
		}
		
	// Bump the mod number
	openP->hdrP->modificationNumber++;

Exit:
	// Display err
	ErrFatalDisplayIf(err, "Err deleting category");
	
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	return err;
	
}


/************************************************************
 *
 *  FUNCTION: DmResizeRecord
 *
 *  DESCRIPTION: Resizes a record and returns new handle. This
 *		routine will automatically allocate the record in another heap
 *		if the current heap is too full.
 *
 *  PARAMETERS: resource ptr, new size
 *
 *  RETURNS: Pointer to resized resource, or 0 if error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand DmResizeRecord(DmOpenRef dbR, UInt index, ULong newSize)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Handle			newH=0, oldH;
	WordPtr			srcP=0, dstP=0;
	Err				err;
	ULong				count;
	LocalID			id;
	DmOpenInfoPtr	openP = dbP->openP;
	RecordEntryPtr	recordP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;


	// Enable writes
	MemSemaphoreReserve(true);
		
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}

	// Check the type of the database
	ErrFatalDisplayIf(openP->resDB, "Not Record DB");
	
	
	// Get the record entry ptr
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) { err = dmErrIndexOutOfRange; goto Exit;}
	
	// Bump the mod number
	openP->hdrP->modificationNumber++;

	// Get the ID
	id = recordP->localChunkID;
	oldH = MemLocalIDToGlobal(id, openP->cardNo);

	// Resize it
	err = MemHandleResize(oldH, newSize);

	// If we couldn't resize it because it's locked, return error
	if (err == memErrChunkLocked) goto Exit;

	// If we couldn't resize it, try and reallocate it in another heap
	if (err) {
		newH = DmNewHandle(dbP, newSize);
		if (!newH) goto ExitNoErrCheck;

		srcP = (WordPtr)MemHandleLock(oldH);
		dstP = (WordPtr)MemHandleLock(newH);
		count = MemHandleSize(oldH);
		
		MemMove(dstP, srcP, count);

		MemHandleFree(oldH);
		MemPtrUnlock(dstP);
		recordP->localChunkID = MemHandleToLocalID(newH);
		MemHandleSetOwner(newH, dmRecOwnerID);
		err = 0;
		}
	else
		newH = oldH;


Exit:
	ErrFatalDisplayIf(err, "Resizing record");
	
ExitNoErrCheck:
	// Restore write-protection
	MemSemaphoreRelease(true);

	if (err) {
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		appInfoP->dmLastErr = err;
		if (newH) MemHandleFree(newH);
		return 0;
		}

	return newH;
}




/************************************************************
 *
 *  FUNCTION: DmReleaseRecord
 *
 *  DESCRIPTION: Clears the busy bit on a record and sets the dirty
 *		bit if dirty is true.
 *
 *  PARAMETERS: database access ptr, record index, dirty boolean
 *
 *  RETURNS:
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmReleaseRecord(DmOpenRef dbR, UInt index, Boolean dirty)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err=0;
	RecordEntryPtr	recordP;
	
	// Enable writes
	MemSemaphoreReserve(true);
		
	// Get the entry ptr
	recordP = PrvRecordEntryPtr(openP, index, 0);
	if (!recordP) {err = dmErrIndexOutOfRange; goto Exit;}
	
	// Clear the busy bit
	recordP->attributes &= ~dmRecAttrBusy;

	// Set the dirty bit
	if (dirty)
		recordP->attributes |= dmRecAttrDirty;


	// Bump the mod number of the database
	if (dirty) 
		openP->hdrP->modificationNumber++;

Exit:
	// Display message
	ErrFatalDisplayIf(err, "Err Releasing rec");
	
	// Restore write-protection
	MemSemaphoreRelease(true);
		
	return err;
}




/************************************************************
 *
 *  FUNCTION: DmFindRecordByHandle
 *
 *  DESCRIPTION: Finds a record by by handle if it is non-nil.
 *
 *  PARAMETERS: database access ptr, record handle
 *
 *  RETURNS: Index of resource, or -1 if not found
 *
 *  CREATED: 11/27/95
 *
 *  BY: Art Lamb
 *
 *************************************************************/
static Int	DmFindRecordByHandle(DmOpenRef dbR, VoidHand findRecH)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				numRecords;
	Int				i;
	RecordEntryPtr	recordP=0;
	LocalID			id;
	Handle			recH;
	DmOpenInfoPtr	openP = dbP->openP;
	

	// Cache the number of resources
	numRecords = openP->numRecords;


	// Search by handle
	for (i=0; i<numRecords; i++) {
		recordP = PrvRecordEntryPtr(openP, i, recordP);
		id = recordP->localChunkID;
		if (! id) continue;
		
		// If it's pointer based, Get the handle out of our handle table
		if (openP->handleTableP) 
			recH = &(openP->handleTableP[i]);
			
		else 
			recH = MemLocalIDToGlobal(id, openP->cardNo);
		
		if (recH == findRecH) break;
		}


	// Return result
	if (i < numRecords)
		return i;
	else
		return -1;
}




/************************************************************
 *
 *  FUNCTION: DmSearchRecord
 *
 *  DESCRIPTION: Searches all open resource databases for a record
 *		with the handle passed.
 *
 *  PARAMETERS: record handle
 *
 *  RETURNS: Index of record and database access ptr
 *
 *  CREATED: 11/27/95
 *
 *  BY: Art Lamb
 *
 *************************************************************/
Int	DmSearchRecord(VoidHand recH, DmOpenRef* dbPP)
{
	DmAccessPtr		dbP;
	Int				index = -1;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	// Grab semaphore
	MemSemaphoreReserve(false);
	
	// Assume err
	*dbPP = 0;

	// Loop through each open database
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	dbP = (DmAccessPtr)appInfoP->dmAccessP;

	while(dbP) {

		// Search for next non-resource database
		while(dbP) {
			if (! dbP->openP->resDB) break;
			dbP = (DmAccessPtr)dbP->next;
			}
		if (!dbP) break;

		// Look for the resource in this database
		index = DmFindRecordByHandle(dbP, recH);
		if (index >= 0) {
			*dbPP = dbP;
			goto Exit;
			}

		dbP = dbP->next;
		}


	// Return result
Exit:
	MemSemaphoreRelease(false);
	return index;
}



/************************************************************
 *
 *  FUNCTION: PrvSetUniqueID
 *
 *  DESCRIPTION: Fills in the unique ID field of a record index entry
 *		with a unique ID
 *
 *  PARAMETERS: ptr to record entry structure
 *
 *  RETURNS: void
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *		roger		11/12/96		moved code to prevent uniqueID's of zero
 *
 *************************************************************/
void  PrvSetUniqueID(DatabaseHdrPtr hdrP, RecordEntryPtr recordP)
{
	BytePtr	seedP;

	// Enable writes
	MemSemaphoreReserve(true);

	// Bump the seed to prevent a uniqueIDSeed of 0 which represents
	// an unassigned uniqueID.
	hdrP->uniqueIDSeed++;

	// Check for wrap around - remember - we are only using the low
	//	three bytes of uniqueIDSeed.
	if (hdrP->uniqueIDSeed & 0xFF000000)
		hdrP->uniqueIDSeed = 1;

	// Copy the unique ID seed from the header into the new record
	seedP = (BytePtr)(&hdrP->uniqueIDSeed);
	recordP->uniqueID[0] = seedP[1];
	recordP->uniqueID[1] = seedP[2];
	recordP->uniqueID[2] = seedP[3];

	// Restore write-protection
	MemSemaphoreRelease(true);

}
	

/************************************************************
 *
 *  FUNCTION: DmWriteCheck
 *
 *  DESCRIPTION: Can be used to check the parameters of a write operation
 *    to a data storage chunk before actually performing the write.
 *
 *  PARAMETERS: 
 *		recordP			- locked pointer to 'recordH'.
 *    offset			- offset into record to start writing
 *		bytes				- number of bytes to write
 *
 *  RETURNS: 0 if no err
 *
 *  CALLED BY: DmWrite before updating a record
 *					Fields package before editing a field in a data storage heap.
 *
 *  CREATED: 5/8/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	 DmWriteCheck(VoidPtr recordP, ULong offset, ULong bytes)
{
	memChunkHeaderTypeName*		chunkP;
	Err								err;
	Handle							h;
	ULong								size;
	
	
	// Get the chunk pointer for this record and assume err
	chunkP = (memChunkHeaderTypeName*)((DWord)recordP - sizeof(memChunkHeaderTypeName));
	err = dmErrNotValidRecord;
	
	// Check the validity of the size
	if (chunkP->size == 0) goto Exit;
	if (chunkP->size & 0x01) goto Exit;
	
	// Check the validity of the flags
	if (memChunkFlags(chunkP))  goto Exit;  //DEBUG!!!!!- test this!!
	
	// Check the validity of the hOffset field
	if (!chunkP->hOffset) goto Exit;
	h = (Handle)( (BytePtr)chunkP - ((Long)chunkP->hOffset * 2) );
	if ((DWord)(*h)  !=  (DWord)recordP) goto Exit;
	
	// Check the bounds of the write operation
#if 	MEMORY_VERSION == MEMORY_VERSION_2 
	size = chunkP->size - (chunkP->sizeAdj) - sizeof(MemChunkHeaderType);
#else
	size = chunkP->size - (chunkP->flags & 0x0F) - sizeof(ChunkHeaderType);
#endif
	if (offset+bytes > size) {
		err = dmErrWriteOutOfBounds;
		goto Exit;
		}

	// Must be OK....
	err = 0;
	
Exit:
	ErrFatalDisplayIf(err, "DmWriteCheck failed");
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmStrCopy
 *
 *  DESCRIPTION: Must be used to write to Data Manager records
 *    because the Data Storage area is write-protected. This routine
 *    will check the validity of the chunk pointer for the record
 *    and make sure that the write will not exceed the chunk bounds.
 *
 *  PARAMETERS: 
 *		recordP			- pointer to Data Record (chunk pointer)
 *		offset			- offset within record to start writing
 *		srcP				- pointer to 0 terminated string
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	 DmStrCopy(VoidPtr recordP, ULong offset, const Char * const srcP)
{
	ULong				len;
	const Char *	p;
	Err				err;
	
	// Get the length of the string
	len = 1;
	p = srcP;
	while(*p++)
		len++;

	err = DmWrite(recordP, offset, srcP, len);
	
	ErrFatalDisplayIf(err, "DmStrCopy failed");
	return err;
}


/************************************************************
 *
 *  FUNCTION: DmWrite
 *
 *  DESCRIPTION: Must be used to write to Data Manager records
 *    because the Data Storage area is write-protected. This routine
 *    will check the validity of the chunk pointer for the record
 *    and make sure that the write will not exceed the chunk bounds.
 *
 *  PARAMETERS: 
 *		recordP			- Pointer to locked data record (chunk pointer)
 *		offset			- offset within record to start writing
 *		srcP				- pointer to data to copy into record
 *		bytes				- number of bytes to write
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	 DmWrite(VoidPtr recordP, ULong offset, const void * const srcP, ULong bytes)
{
	Err					err;
	
	
	// Prepare for writing
	MemSemaphoreReserve(true);
	
	// Check the validity
	err = DmWriteCheck(recordP, offset, bytes);
	if (err) {
		ErrDisplay("Write to invalid rec");
		err = DmGetLastErr();
		goto Exit;
		}
	else err = 0;
	
	// do the write....
	MemMove(((BytePtr)recordP)+offset, srcP, bytes);
	
Exit:
	MemSemaphoreRelease(true);
	return err;
}




/************************************************************
 *
 *  FUNCTION: DmSet
 *
 *  DESCRIPTION: Must be used to write to Data Manager records
 *    because the Data Storage area is write-protected. This routine
 *    will check the validity of the chunk pointer for the record
 *    and make sure that the write will not exceed the chunk bounds.
 *
 *  PARAMETERS: 
 *		recordP			- Pointer to locked data record (chunk pointer)
 *		offset			- offset within record to start writing
 *		bytes				- number of bytes to write
 *    value				- byte value to write
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	 DmSet(VoidPtr recordP, ULong offset, ULong bytes, Byte value)
{
	Err					err;
	
	
	// Prepare for writing
	MemSemaphoreReserve(true);
	
	// Check the validity
	err = DmWriteCheck(recordP, offset, bytes);
	if (err) {
		ErrDisplay("Write to invalid rec");
		err = DmGetLastErr();
		goto Exit;
		}
	else err = 0;
	
	// do the set....
	MemSet(((BytePtr)recordP)+offset, bytes, value);
	
Exit:
	MemSemaphoreRelease(true);
	return err;
}



/************************************************************
 *
 *  FUNCTION: DmNewHandle 
 *
 *  DESCRIPTION: Allocates a new chunk in the same heap or card
 *		as a database header
 *
 *  PARAMETERS:	dbR		--	database reference(if not null, allocation
 *										will be made from the card containing
 *										the database header; otherwise, allocation will
 *										be made from any card with sufficient free space)
 *										
 *						size		--	desired size
 *
 *  RETURNS: chunk handle of new chunk
 *
 *  CREATED: 11/21/94 
 *
 *  BY: Ron Marianetti
 *
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/10/96	Enable allocation given null database reference
 *			vmk	12/22/97	Assert zero size allocations and return immediately
 *			vmk	12/22/97	Optimize by suppressing unnecessary comapctions and
 *								free space computations
 *
 *************************************************************/
VoidHand	 DmNewHandle(DmOpenRef dbR, ULong size)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				numHeaps, i, heapID;
	Handle			h = 0;
	//DmOpenInfoPtr	openP;
	UInt				cardNo;
	//ULong				free, max, freeMax;
	//UInt				maxFreeHeapID = 0xFFFF;
	UInt				numStorageHeaps;
	Err				err;


	//ErrNonFatalDisplayIf(size == 0, "DmNewHandle with size=0 not allowed");
	if ( !size )
		return 0;
		

	// If passed a non-null database reference, allocate the chunk on the same
	// card as the database header
	if ( dbP ) {
		//openP = dbP->openP;
		cardNo = dbP->openP->cardNo;
		
		#if 0		// REMOVED FOR PERFORMANCE OPTIMIZATION -- MemHeapFreeBytes takes too
					// long in the current memory manager because it walks the entire heap
			// First, try to allocate the new handle from the same heap as the database
			// header if there is enough free space
			heapID = MemHandleHeapID(openP->hdrH);		// get the heap ID of the header
			MemHeapFreeBytes(heapID, &free, &max);
			if ((Long)free - (Long)size > 0x1000) {
				h = MemChunkNew(heapID, size, dmOrphanOwnerID);
				if (h)
					goto Exit;
				}
		#endif	// REMOVED FOR PERFORMANCE OPTIMIZATION
		}
	else {
		// We were passed a null database reference -- assume card number 0
		//openP = 0;
		cardNo = 0;
		}


	#if 0		// REMOVED FOR PERFORMANCE OPTIMIZATION -- calls to MemHeapFreeBytes take
				// too long because the current memory manager has to walk the entire heap
				// to calculate this value

		// Try in all the other heaps of the same card and look for the one with
		//  the most free bytes
		numHeaps = MemNumRAMHeaps(cardNo);
		freeMax = 0;
		for (i=0; i<numHeaps; i++) {
			heapID = MemHeapID(cardNo, i);
			if (MemHeapDynamic(heapID))
				continue;

			MemHeapFreeBytes(heapID, &free, &max);
			if (free > freeMax || (maxFreeHeapID == 0xFFFF)) {
				freeMax = free;
				maxFreeHeapID = heapID;
				} 

			}

		// Allocate in the heap with the most free space
		h = MemChunkNew(maxFreeHeapID, size, dmOrphanOwnerID);
		if (h)
			goto Exit;

	#endif	// REMOVED FOR PERFORMANCE OPTIMIZATION


	// As a last resort, try and allocate in any heap
	numHeaps = MemNumRAMHeaps(cardNo);
	numStorageHeaps = 0;
	for (i=0; i < numHeaps; i++) {
		heapID = MemHeapID(cardNo, i);
		if (MemHeapDynamic(heapID))
			continue;
			
		numStorageHeaps++;											// count storage heaps
		
		h = MemChunkNew(heapID, size, dmOrphanOwnerID);
		if (h)
			goto Exit;
		}


	// If we still failed, try and re-arrange chunks in the heaps until
	//  a free chunk big enough gets formed
	if ( numStorageHeaps > 1 ) {	// this only makes sense if there is more than one storage heap
		err = PrvMergeFree(cardNo, size);
		if (err)
			goto Exit;
		
		for (i=0; i<numHeaps; i++) {
			heapID = MemHeapID(cardNo, i);
			if (MemHeapDynamic(heapID))
				continue;

			h = MemChunkNew(heapID, size, dmOrphanOwnerID);
			if (h)
				goto Exit;
			}
		}

Exit:
	return h;
}




/************************************************************
 *
 *  FUNCTION: DmGetResource
 *
 *  DESCRIPTION: Returns a handle to the resource. Searches
 *		all open resource databases for the resource.
 *
 *  PARAMETERS: resource type, resource id
 *
 *  RETURNS: Handle to resource
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	DmGetResource(ULong type, Int id)
{
	Int				index;
	DmAccessPtr		dbP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;
	
	
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;
	
	// First, search for the resource by type and id
	index = DmSearchResource(type, id, 0, &dbP);
	if (index<0) {
		appInfoP->dmLastErr = dmErrResourceNotFound;
		return 0;
		}

	// Now, Get the handle
	return DmGetResourceIndex(dbP, index);
}



/************************************************************
 *
 *  FUNCTION: DmGet1Resource
 *
 *  DESCRIPTION: Returns a handle to the resource. Searches
 *		only the top (most recently opened) resource file.
 *
 *  PARAMETERS: resource type, resource id
 *
 *  RETURNS: Handle to resource
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand DmGet1Resource(ULong type, Int id)
{
	Int				index;
	DmAccessPtr		dbP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;

	// First, search for the resource
	dbP = DmNextOpenResDatabase(0);
	if (!dbP) {
		appInfoP->dmLastErr = dmErrNoOpenDatabase;
		return 0;
		}
	
	index = DmFindResource(dbP, type, id, 0);
	if (index<0) 	if (index<0) {
		appInfoP->dmLastErr = dmErrResourceNotFound;
		return 0;
		}
	
	return DmGetResourceIndex(dbP, index);	
}



/************************************************************
 *
 *  FUNCTION: DmResizeResource
 *
 *  DESCRIPTION: Unlocks a resource, resizes it,
 *		locks it again, and returns new pointer
 *
 *  PARAMETERS: resource ptr, new size
 *
 *  RETURNS: Pointer to resized resource, or 0 if error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand DmResizeResource(VoidHand resourceH, ULong newSize)
{
	Int				index;
	DmAccessPtr		dbP;
	Handle			newH=0;
	WordPtr			srcP=0, dstP=0;
	Err				err;
	ULong				count;
	DmOpenInfoPtr	openP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	appInfoP->dmLastErr = 0;
	
	// Enable writes
	MemSemaphoreReserve(true);

	// Get the database access ptr and index of this resource
	index = DmSearchResource(0, 0, resourceH, &dbP);
	if (index < 0) {
		err = dmErrCantFind;
		goto Exit;
		}

	// Get the open references
	openP = dbP->openP;
	
	// Check for errors
	if (!openP->writeAccess)
		{err = dmErrReadOnly; goto Exit;}
		

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Resource DB");
	
	
	// Check the index
	if (index >= openP->numRecords) { 
		err = dmErrIndexOutOfRange;
		goto Exit;
		}


	// Resize it
	err = MemHandleResize(resourceH, newSize);

	// If we couldn't resize it because it's locked, return error
	if (err == memErrChunkLocked) {
		goto Exit;
		}

	// If we couldn't resize it, try and reallocate it in another heap
	if (err) {
		RsrcEntryPtr	resourceP;
		
		newH = DmNewHandle(dbP, newSize);
		if (!newH) goto ExitNoErrCheck;

		srcP = (WordPtr)MemHandleLock(resourceH);
		dstP = (WordPtr)MemHandleLock(newH);
		count = MemHandleSize(resourceH);
		
		MemMove(dstP, srcP, count);

		MemHandleFree(resourceH);
		MemPtrUnlock(dstP);
		resourceP = PrvRsrcEntryPtr(openP, index, 0);
		resourceP->localChunkID = MemHandleToLocalID(newH);
		resourceH = newH;
		err = 0;
		}
		

	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	ErrFatalDisplayIf(err, "Err resizing rsrc");
	
ExitNoErrCheck:
	// Restore write-protection
	MemSemaphoreRelease(true);

	if (err) {
		appInfoP->dmLastErr = err;
		if (newH) MemHandleFree(newH);
		return 0;
		}

	return resourceH;
}



/************************************************************
 *
 *  FUNCTION: DmReleaseResource
 *
 *  DESCRIPTION: Does nothing for now....
 *
 *  PARAMETERS: resource handle
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmReleaseResource(VoidHand resourceH)
{
	//return MemHandleResetLock(resourceH);
	return 0;
}




/************************************************************
 *
 *  FUNCTION: DmNextOpenResDatabase
 *
 *  DESCRIPTION: Returns the DmOpenRef to the top open resource
 *		Database.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: DmOpenRef
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
DmOpenRef	DmNextOpenResDatabase(DmOpenRef dbR)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;
	
	
	// Get semaphore
	MemSemaphoreReserve(false);
	
	if (!dbP)  {
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		dbP = (DmAccessPtr)appInfoP->dmAccessP;
		}
	else
		dbP = dbP->next;
		
		
	while(dbP) {
		if (dbP->openP->resDB) break;
		dbP = dbP->next;
		}


	// Release semaphore
	MemSemaphoreRelease(false);
	
	return dbP;
}



/************************************************************
 *
 *  FUNCTION: FindResourceType
 *
 *  DESCRIPTION: Returns index of a resource given the type and
 *		the type index.
 *
 *  PARAMETERS: database access ptr, resource type, resource type index
 *
 *  RETURNS: resource index, or -1 if not found 
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Int	DmFindResourceType(DmOpenRef dbR, ULong resType, Int typeIndex)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				numResources;
	UInt				whichTypeIndex;
	Int				i;
	RsrcEntryPtr	resourceP=0;
	DmOpenInfoPtr	openP = dbP->openP;


	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Search for this type	
	numResources = openP->numRecords;
	whichTypeIndex = 0;
	for (i=0; i<numResources; i++) {
		resourceP = PrvRsrcEntryPtr(openP, i, resourceP);
		
		if (resourceP->type != resType) continue;
		if (typeIndex == whichTypeIndex) break;
		whichTypeIndex++;
		}


	// Return the index of the resource
	if (i < numResources)
		return i;
	else
		return -1;
}



/************************************************************
 *
 *  FUNCTION: DmFindResource
 *
 *  DESCRIPTION: Finds a resource by type and ID, OR by handle if
 *		it is non-nil.
 *
 *  PARAMETERS: database access ptr, resource type, resouce id, 
 *		resource pointer (optional)
 *
 *  RETURNS: Index of resource, or -1 if not found
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Int	DmFindResource(DmOpenRef dbR, ULong resType, Int resID,
			VoidHand findResH)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	UInt				numResources;
	Int				i;
	RsrcEntryPtr	resourceP=0;
	LocalID			id;
	Handle			resH;
	DmOpenInfoPtr	openP = dbP->openP;
	

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Cache the number of resources
	numResources = openP->numRecords;


	// If handle not specified, search by type and id
	if (!findResH) {
		for (i=0; i<numResources; i++) {
			resourceP = PrvRsrcEntryPtr(openP, i, resourceP);
			if (resourceP->type == resType && resourceP->id == resID) break;
			}

		}

	// If handle specified, search by handle
	else {
		for (i=0; i<numResources; i++) {
			resourceP = PrvRsrcEntryPtr(openP, i, resourceP);
			id = resourceP->localChunkID;
			
			// If it's pointer based, Get the handle out of our handle table
			if (openP->handleTableP) 
				resH = &(openP->handleTableP[i]);
				
			else 
				resH = MemLocalIDToGlobal(id, openP->cardNo);
			
			if (resH == findResH) break;
			}
		}


	// Return result
	if (i < numResources)
		return i;
	else
		return -1;
}




/************************************************************
 *
 *  FUNCTION: DmSearchResource
 *
 *  DESCRIPTION: Searches all open resource databases for a resource
 *		by type and id, OR by pointer
 *
 *  PARAMETERS: resource type, resource id, resource ptr (optional)
 *
 *  RETURNS: Index of resource and database access ptr
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Int	DmSearchResource(ULong resType, Int resID, VoidHand resH,
			DmOpenRef* dbPP)
{
	DmAccessPtr		dbP;
	Int				index = -1;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;

	// Grab semaphore
	MemSemaphoreReserve(false);
	
	// Assume err
	*dbPP = 0;

	// Loop through each open resource database
	appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	dbP = (DmAccessPtr)appInfoP->dmAccessP;

	while(dbP) {

		// Search for next resource database
		while(dbP) {
			if (dbP->openP->resDB) break;
			dbP = (DmAccessPtr)dbP->next;
			}
		if (!dbP) break;

		// Look for the resource in this database
		index = DmFindResource(dbP, resType, resID, resH);
		if (index >= 0) {
			*dbPP = dbP;
			goto Exit;
			}

		dbP = dbP->next;
		}


	// Return result
Exit:
	MemSemaphoreRelease(false);
	return index;
}






/************************************************************
 *
 *  FUNCTION: DmNumResources
 *
 *  DESCRIPTION: Returns the number of resources in a database
 *
 *  PARAMETERS: database access ptr
 *
 *  RETURNS: Number of resources
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	DmNumResources(DmOpenRef dbP)
{
	// Check the type of the database
	ErrFatalDisplayIf(!((DmAccessPtr)dbP)->openP->resDB, "Not Rsrc DB");
	
	return ((DmAccessPtr)dbP)->openP->numRecords;
}





/************************************************************
 *
 *  FUNCTION: DmResourceInfo
 *
 *  DESCRIPTION: Returns info out of the database header for a
 *		resource by index
 *
 *  PARAMETERS: database access ptr, index of resource,
 *		pointers to return variables
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	DmResourceInfo(DmOpenRef dbR, Int index,
			ULongPtr	resTypeP, IntPtr resIDP,
			 LocalID* chunkLocalIDP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	RsrcEntryPtr	resourceP;
	DmOpenInfoPtr	openP = dbP->openP;

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	resourceP = PrvRsrcEntryPtr(openP, index, 0);
	if (!resourceP) return dmErrIndexOutOfRange;

	// return info
	if (resTypeP) 	*resTypeP = resourceP->type;
	if (resIDP) 	*resIDP = resourceP->id;
	if (chunkLocalIDP) 
		*chunkLocalIDP = resourceP->localChunkID;

	return 0;
}



/************************************************************
 *
 *  FUNCTION: DmSetResourceInfo
 *
 *  DESCRIPTION: Sets info in the database header for a
 *		resource by index
 *
 *  PARAMETERS: database access ptr, index of resource,
 *		pointers to new variables
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	2/6/98	Added non-fatal checks for null dbR
 *************************************************************/
Err	DmSetResourceInfo(DmOpenRef dbR, Int index,
			ULongPtr	resTypeP, IntPtr resIDP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	RsrcEntryPtr	resourceP;
	DmOpenInfoPtr	openP = dbP->openP;
	Err				err=0;
	
	
	// Validate args
	ErrNonFatalDisplayIf(!dbR, "null DmOpenRef");

	// Enable writes
	MemSemaphoreReserve(true);

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Make sure we have write access
	if (!(dbP->mode & dmModeWrite)) {err= dmErrReadOnly; goto Exit;}
	
	// Check boundary conditions
	if (index >= openP->numRecords) {err = dmErrIndexOutOfRange; goto Exit;}

	// Bump the mod number
	openP->hdrP->modificationNumber++;


	resourceP = PrvRsrcEntryPtr(openP, index, 0);

	// set info
	if (resTypeP)	 	resourceP->type = *resTypeP;
	if (resIDP) 		resourceP->id = *resIDP;


Exit:
	// Restore write-protection
	MemSemaphoreRelease(true);

	return err;
}




/************************************************************
 *
 *  FUNCTION: DmAttachResource
 *
 *  DESCRIPTION: Adds a chunk as a new resource to a database
 *
 *  PARAMETERS: database access ptr, chunk ID of new resource,
 *		new resource type and id
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err DmAttachResource(DmOpenRef dbR, VoidHand newH, ULong resType,
		Int resID)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Err				err;
	RsrcEntryPtr	resourceP;
	DmOpenInfoPtr	openP = dbP->openP;


	// Enable writes
	MemSemaphoreReserve(true);

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Make sure we have write access
	if (!(dbP->mode & dmModeWrite)) {err = dmErrReadOnly; goto Exit;}


	// Make sure the new resource is in the same card as the header
	if (MemHandleCardNo(newH) != openP->cardNo) 
		{err = dmErrRecordInWrongCard; goto Exit;}


	// If this database is empty, make room for the first record
	if (openP->numRecords == 0) {
		ULong		reqSize;
		
		reqSize = sizeof(DatabaseHdrType) + sizeof(RsrcEntryType);
		MemPtrUnlock(openP->hdrP);
		err = MemHandleResize(openP->hdrH, reqSize);
		openP->hdrP = MemHandleLock(openP->hdrH);
		if (err) goto ExitNoErrCheck;
		openP->hdrP->recordList.numRecords = 1;
		}
		
	// Else, Grow the resource entry table to add space for the new resource 
	else {
		err = PrvShiftEntriesDown(dbR, openP->numRecords-1, 0, true);
		if (err) {
			if (err == dmErrMemError) goto ExitNoErrCheck;
			goto Exit;
			}
		}
	openP->numRecords++;
	

	// Initialize info
	resourceP = PrvRsrcEntryPtr(openP, openP->numRecords-1, 0);
	resourceP->type = resType;
	resourceP->id = 	resID;
	resourceP->localChunkID = MemHandleToLocalID(newH);
	
	// Set the owner of the chunk so that it's not an orphan anymore
	MemHandleSetOwner(newH, dmRecOwnerID);

	// Bump the mod number
	openP->hdrP->modificationNumber++;


Exit:
	ErrFatalDisplayIf(err, "Err adding rsrc");
	
ExitNoErrCheck:

	// Restore write protection
	MemSemaphoreRelease(true);

	return err;

}




/************************************************************
 *
 *  FUNCTION: DmDetachResource
 *
 *  DESCRIPTION: Removes the entry in the database header for
 *		a resource and returns the ChunkID of the resource.
 *
 *  PARAMETERS: database access ptr, resource index, ptr to return
 *		chunk ID
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	2/6/98	Added non-fatal checks for null dbR
 *************************************************************/
Err	DmDetachResource(DmOpenRef dbR, Int index, VoidHand* oldHP)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	LocalID			id;
	RsrcEntryPtr	resourceP;
	Err				err=0;
	DmOpenInfoPtr	openP = dbP->openP;


	// Validate args
	ErrNonFatalDisplayIf(!dbR, "null DmOpenRef");

	// Enable writes
	MemSemaphoreReserve(true);

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Make sure we have write access
	if (!(dbP->mode & dmModeWrite)) {err= dmErrReadOnly; goto Exit;}

	// Make sure the index is in range
	if (index >= openP->numRecords) {err = dmErrIndexOutOfRange; goto Exit;}

	// Get the chunkID of the resource we're removing
	resourceP = PrvRsrcEntryPtr(openP, index, 0);
	id = resourceP->localChunkID;
	if (!id) {err = dmErrCorruptDatabase; goto Exit;}


	// return the handle of the record
	if (id) 
		*oldHP = MemLocalIDToGlobal(id, openP->cardNo);
	else
		*oldHP = 0;



	// Adjust the number of records and shift later ones up
	err = PrvShiftEntriesUp(dbR, index+1, 0, true);
	if (err) goto Exit;
	
	openP->numRecords--;
	
	// Bump the mod number
	openP->hdrP->modificationNumber++;


	
Exit:
	ErrFatalDisplayIf(err, "Err detaching rsrc");

	// Restore write-protection
	MemSemaphoreRelease(true);


	return err;
}




/************************************************************
 *
 *  FUNCTION: DmNewResource
 *
 *  DESCRIPTION: Creates a new chunk for a resource and adds
 *		an entry to the database header for the new resource
 *
 *  PARAMETERS: database access ptr, resource type, resource id,
 *		resource size
 *
 *  RETURNS: Pointer to new locked resource
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	DmNewResource(DmOpenRef dbR, ULong resType, Int resID,
				ULong size)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	Handle			newH=0;
	Err				err;
	DmOpenInfoPtr	openP = dbP->openP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;


	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	// Make sure we have write access
	if (!(dbP->mode & dmModeWrite)) {
		err = dmErrReadOnly;
		goto Exit;
		}

	if (!openP->resDB) 
		{err = dmErrNotResourceDB; goto Exit;}
		

	// First, try and allocate a new chunk of the desired size in the
	//  same card as the database header
	newH = DmNewHandle(dbP, size);
	if (!newH) {err = dmErrMemError; goto Exit; }

	// Now, attach it to the database
	err = DmAttachResource(dbP, newH, resType, resID);

Exit:
	if (err) {
		if (newH) MemHandleFree(newH);
		newH = 0;
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		appInfoP->dmLastErr = err;
		}

	return newH;
}



/************************************************************
 *
 *  FUNCTION: DmRemoveResource
 *
 *  DESCRIPTION: Deletes a resource's chunk and removes its entry
 *		from the database header
 *
 *  PARAMETERS: database access ptr, index to resource
 *
 *  RETURNS:
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err DmRemoveResource(DmOpenRef dbR, Int index)
{
	Err			err;
	Handle		h;
	DmAccessPtr		dbP = (DmAccessPtr)dbR;


	// Check the type of the database
	ErrFatalDisplayIf(!dbP->openP->resDB, "Not Rsrc DB");
	
	// Make sure we have write access
	if (!(dbP->mode & dmModeWrite)) 
		return (dmErrReadOnly);

	// First, detach it
	err = DmDetachResource(dbP, index, &h);
	if (err) return err;

	// Now, delete the resource
	return MemHandleFree(h);
}



/************************************************************
 *
 *  FUNCTION: DmGetResourceIndex
 *
 *  DESCRIPTION: Looks up a resource by index and returns handle to it
 *
 *  PARAMETERS: database access ptr, index of resource
 *
 *  RETURNS: handle to resource
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	2/6/98	Added non-fatal checks for null dbR
 *************************************************************/
VoidHand	DmGetResourceIndex(DmOpenRef dbR, Int index)
{
	DmAccessPtr		dbP = (DmAccessPtr)dbR;
	LocalID 			id;
	Handle			resH;
	DmOpenInfoPtr	openP = dbP->openP;
	RsrcEntryPtr	resourceP;
	SysAppInfoPtr	appInfoP;
	SysAppInfoPtr	unusedAppInfoP;


	// Validate args
	ErrNonFatalDisplayIf(!dbR, "null DmOpenRef");

	// Check the type of the database
	ErrFatalDisplayIf(!openP->resDB, "Not Rsrc DB");
	
	if (index >= openP->numRecords) {
		appInfoP = SysGetAppInfo(&appInfoP, &unusedAppInfoP);
		appInfoP->dmLastErr = dmErrIndexOutOfRange;
		return 0;
		}


	// If it's pointer based, Get the handle out of our handle table
	if (openP->handleTableP) 
		resH = &(openP->handleTableP[index]);
		
	else {
		resourceP = PrvRsrcEntryPtr(openP, index, 0);
		id = resourceP->localChunkID;
		resH = MemLocalIDToGlobal(id, openP->cardNo);
		}
	
	return resH;
}





/************************************************************
 *
 *  FUNCTION: PrvRecordEntryPtr, private
 *
 *  DESCRIPTION: Returns a pointer to the Nth record entry in the
 *		Database header. This routine supports databases that have
 *		multiple RecordLists stored in multiple Memory chunks.
 *
 *		It assumes that all record list chunks have been locked
 *		as a result of opening the database.
 *
 *		If prevRecordP is non-nil IT MUST BE A POINTER TO THE RECORD
 *		at index-1. If provided by the caller, it allows this routine
 *		to find the desired record entry faster (by avoiding a multiply).
 *
 *  PARAMETERS: 
 *			openP 			-	DmOpenInfoPtr of open database
 *			index			 	-  index of desired record
 *			prevRecordP 	- 	pointer to previous record entry, or nil		
 *
 *  RETURNS: pointer to record entry
 *
 *  CREATED: 8/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static RecordEntryPtr	PrvRecordEntryPtr(DmOpenInfoPtr openP, UInt index, 
			RecordEntryPtr	prevRecordP)
{
	RecordListPtr	listP;
	LocalID			id;
	UInt				cumIndex;
	RecordEntryPtr	recordP;
	
	// Point to the first list (part of the header)
	listP = &openP->hdrP->recordList;

	// Optimize for the first record list
	if (index < listP->numRecords) {
	
		// If the previous record ptr was passed, take shorcut.
		if (prevRecordP) {
			#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				recordP = (RecordEntryPtr)&listP->firstEntry;
				if (prevRecordP != &(recordP[index-1])) 
					ErrDisplay("Invalid previous rec ptr");
			#endif
			return prevRecordP+1;
			}
			
		// Else, do a multiply
		recordP = (RecordEntryPtr)&listP->firstEntry;
		return &(recordP[index]);
		}
		
	// Handle the case where the requested index is not in the first record list
	cumIndex = listP->numRecords;
	while(listP) {
		if (!(id = listP->nextRecordListID)) goto ExitErr;
		listP = MemLocalIDToGlobal(id, openP->cardNo);
		
		// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
		if (!openP->handleTableP) 
			listP = (RecordListPtr)MemDeref((Handle)listP);
		
		// If the record is in list list, return ptr to it's entry
		if (index < cumIndex + listP->numRecords) {
			UInt	relIndex = index - cumIndex;

			// If the previous record ptr was passed, take shorcut.
			if (prevRecordP && index > cumIndex) {
				#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
					recordP = (RecordEntryPtr)&listP->firstEntry;
					if (prevRecordP != &(recordP[relIndex-1]))
						ErrDisplay("Invalid previous rec ptr");
				#endif
				return prevRecordP+1;
				}
				
			// Else, do a multiply
			recordP = (RecordEntryPtr)&listP->firstEntry;
			return &(recordP[relIndex]);
			}
			
		// On to the next list
		cumIndex += listP->numRecords;
		}
		
		
ExitErr:
	// If we got here, the index is invalid
	ErrDisplay("Index out of range");
	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvRsrcEntryPtr, private
 *
 *  DESCRIPTION: Returns a pointer to the Nth resource entry in the
 *		Database header. This routine supports databases that have
 *		multiple RecordLists stored in multiple Memory chunks.
 *
 *		It assumes that all record list chunks have been locked
 *		as a result of opening the database.
 *
 *		If prevRsrcP is non-nil IT MUST BE A POINTER TO THE RESOURCE
 *		at index-1. If provided by the caller, it allows this routine
 *		to find the desired record entry faster (by avoiding a multiply).
 *
 *  PARAMETERS:  
 *			openP 			-	DmOpenInfoPtr of open database
 *			index			 	-  index of desired resource
 *			prevRsrcP 	- 	pointer to previous resource entry, or nil		
 *
 *  RETURNS: pointer to resource entry
 *
 *  CREATED: 8/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static RsrcEntryPtr	PrvRsrcEntryPtr(DmOpenInfoPtr openP, UInt index,
			RsrcEntryPtr	prevRsrcP)
{
	RecordListPtr	listP;
	LocalID			id;
	UInt				cumIndex;
	RsrcEntryPtr	rsrcP;
	
	// Point to the first list (part of the header)
	listP = &openP->hdrP->recordList;



	// Optimize for the first record list
	if (index < listP->numRecords) {
	
		// If the previous resource ptr was passed, take shortcut.
		if (prevRsrcP) {
			#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				rsrcP = (RsrcEntryPtr)&listP->firstEntry;
				if (prevRsrcP != &(rsrcP[index-1])) 
					ErrDisplay("Invalid previous rsrc ptr");
			#endif
			return prevRsrcP+1;
			}
			
		// Else, do a multiply
		rsrcP = (RsrcEntryPtr)&listP->firstEntry;
		return &(rsrcP[index]);
		}
		
		
		
	// Handle the case where the requested index is not in the first record list
	cumIndex = listP->numRecords;
	while(listP) {
		if (!(id = listP->nextRecordListID)) goto ExitErr;
		listP = MemLocalIDToGlobal(id, openP->cardNo);
		
		// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
		if (!openP->handleTableP) 
			listP = (RecordListPtr)MemDeref((Handle)listP);
		
		// If the record is in list list, return ptr to it's entry
		if (index < cumIndex + listP->numRecords) {
			UInt	relIndex = index - cumIndex;
			
			// If the previous resource ptr was passed, take shortcut.
			if (index > cumIndex && prevRsrcP) {
				#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
					rsrcP = (RsrcEntryPtr)&listP->firstEntry;
					if (prevRsrcP != &(rsrcP[relIndex-1])) 
						ErrDisplay("Invalid previous rsrc ptr");
				#endif
				return prevRsrcP+1;
				}
				
			// Else, do a multiply
			rsrcP = (RsrcEntryPtr)&listP->firstEntry;
			return &(rsrcP[relIndex]);
			}
			
		// On to the next list
		cumIndex += listP->numRecords;
		}
		
		
ExitErr:
	// If we got here, the index is invalid
	ErrDisplay("Index out of range");
	return 0;
}





/************************************************************
 *
 *  FUNCTION: PrvShiftEntriesUp, private
 *
 *  DESCRIPTION: Shifts a range of database entries up by 1. It will shift 
 *		entry N into entry N-1, and proceed till it moves 'shiftSize' records.
 *		Note that the starting index N must be greater than 0.
 *
 *		The number of records to shift is passed in shiftSize, or 0 can
 *		be passed to shift all records from startIndex to the end.
 *
 *		If adjustSize is true, and shiftSize is 0 (moving all records from
 *		startIndex to the end), the last recordList's size will be decresed
 *		by one record.
 *		
 *		As a special case, in order to support the deletion of the last
 *		record in a database, N can be equal to the index of the last record+1
 *		as long as adjustSize is true and shiftSize is 0.
 *		
 *
 *  PARAMETERS: 
 *			openP 			-	DmOpenInfoPtr of open database
 *			startIndex		-  index of first entry to shift
 *			shiftSize		-  # of entries to shift, or 0 to shift all entries
 *								  from startIndex to the end of the Database
 *			adjustSize		- if true, the necessary changes will be made to the
 *									Database to record the fact that a record was
 *									deleted.
 *									NOTE: if adjustSize is true, shiftSize MUST BE 0.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 8/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvShiftEntriesUp(DmOpenRef dbR, UInt startIndex, 
			UInt shiftSize, Boolean adjustSize)
{
	DmOpenInfoPtr	openP = ((DmAccessPtr)dbR)->openP;
	RecordListPtr	listP;
	LocalID			id;
	UInt				cumIndex;
	BytePtr			entryP, prevEntryP;
	Err				err = dmErrIndexOutOfRange;
	UInt				i, moveRecords;
	Boolean			movedRecords=false;
	ULong				entrySize;
	Boolean			done  = false;
	Boolean			deleteLast = false;
	
	
	// Determine the size of each entry, depending on whether this is a 
	//  record or resource database
	if (openP->resDB) entrySize = sizeof(RsrcEntryType);
	else entrySize = sizeof(RecordEntryType);
	
	// Point to the first list (part of the header)
	listP = &openP->hdrP->recordList;
	cumIndex = 0;
	
	
	// Error check
	ErrFatalDisplayIf(adjustSize && shiftSize, "Shiftsize must be 0 if adjustSize is true");
	
	
	//-----------------------------------------------------------------------------
	// If we're shifting up, we start from the beginning and work our way to
	//  the end. We put the record at index N into the space at index N-1.
	//-----------------------------------------------------------------------------

	// Error check start index, can't be less than 1.
	ErrFatalDisplayIf(startIndex < 1, "Invalid start index");
	
	// If the index is equal to the lastIndex+1, we're deleting the last record
	if (startIndex == openP->numRecords) deleteLast = true;

	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Loop through each record list and shift the entries in each one accordingly.
	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	while(1) {
	
		// Get pointer to first entry in list.
		entryP = (BytePtr)&listP->firstEntry;
		
		//.................................................................
		// Shift all records in this list up if it is in the active area
		//.................................................................
		if (startIndex < cumIndex + listP->numRecords) {
		
			// Assume we need to move all records in this list
			moveRecords = listP->numRecords;
			
			// If we need to start partway through this list, adjust the starting
			//  record pointer, previous record pointer, and # of records to move
			if (startIndex > cumIndex)  {
				i = startIndex - cumIndex;
				moveRecords -= i;
				prevEntryP = entryP + (i-1)*entrySize;
				entryP = prevEntryP + entrySize;
				}
				
			// Clip the # of records we need to move to shiftSize, if it was specified.
			if (shiftSize && shiftSize < moveRecords) 
				moveRecords = shiftSize;
				
			// Decrement the remaining # of records we need to move in the other lists.
			if (shiftSize) {
				shiftSize -= moveRecords;
				if (!shiftSize) done = true;
				}

			// Move the records
			// The compiler generates more efficent code with these types of while loops.
			if (moveRecords) {
				movedRecords = true;
				// Resource entries
				if (openP->resDB) {
					RsrcEntryPtr	resP = (RsrcEntryPtr)entryP;
					RsrcEntryPtr	prevResP = (RsrcEntryPtr)prevEntryP;
					do {
						*prevResP = *resP;
						prevResP = resP;
						resP++;
						} while(--moveRecords);
					prevEntryP = (BytePtr)prevResP;
					}
					
				else {
					RecordEntryPtr	recP = (RecordEntryPtr)entryP;
					RecordEntryPtr	prevRecP = (RecordEntryPtr)prevEntryP;
					do {
						*prevRecP = *recP;
						prevRecP = recP;
						recP++;
						} while(--moveRecords);
					prevEntryP = (BytePtr)prevRecP;
					}
				}
				
			// Exit if we're done
			if (done) break;
			}
		// Save pointer to last entry in this list in case we have a case where
		//  we're shifting a record from one list to the previous list.
		else 
			prevEntryP = entryP + (listP->numRecords-1)*entrySize;
		
		
		//.................................................................
		// Calculate start index of the next list
		//.................................................................
		cumIndex += listP->numRecords;
		id = listP->nextRecordListID;
		if (!id) break;

		listP = MemLocalIDToGlobal(id, openP->cardNo);
		
		// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
		if (!openP->handleTableP)
			listP = (RecordListPtr)MemDeref((Handle)listP);
			
		} // while(1)
		
		
	// If we did move all the requested records, no err
	if (movedRecords && !shiftSize) err = 0;
	
	// Or, if we're deleting the last record, no err
	if (deleteLast) err = 0;
	
	
	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// We've finished shifting the necessary records. Now, if adjustSize was true,
	//  we need to decrease the size of the recordList that contains the last record we moved.
	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	if (adjustSize && !err) {
		ULong	reqSize;
		listP->numRecords--;
		
		// If it's the first record list, it's part of the header. We can resize it
		//  without unlocking it because we're making it smaller.
		if (listP == &(openP->hdrP->recordList)) {
			reqSize = sizeof(DatabaseHdrType) + listP->numRecords * entrySize;
			err = MemPtrResize(openP->hdrP, reqSize);
			ErrFatalDisplayIf(err, "Err resizing header");
			}					
			
		// Else, it's a separate chunk
		else {
			if (listP->numRecords) {
				reqSize  = sizeof(RecordListType) + listP->numRecords * entrySize;
				err = MemPtrResize(listP, reqSize);						
				ErrFatalDisplayIf(err, "Err resizing record list");
				}
			// If no more records in this list, get rid of it
			else {
				RecordListPtr	prevListP;
				prevListP = PrvPrevRecordList(openP, listP);
				prevListP->nextRecordListID = 0;
				MemPtrFree(listP);
				}
			}
		}
		
		
		
	// Return error code
	ErrFatalDisplayIf(err, "Err shifting records in DB");
	return err;
}





/************************************************************
 *
 *  FUNCTION: PrvShiftEntriesDown, private
 *
 *  DESCRIPTION: Shifts a range of database entries down by 1. It will shift 
 *		entry N into entry N+1, and proceed till it reaches entry N+shiftSize.
 *
 *		The number of records to shift is passed in shiftSize, or 0 can
 *		be passed to shift all records from startIndex to the end.
 *
 *		If adjustSize is true, and shiftSize is 0 (moving all records from
 *		startIndex to the end), the last recordList's size will be increased
 *		by one record.
 *		
 *		
 *
 *  PARAMETERS: 
 *			openP 			-	DmOpenInfoPtr of open database
 *			startIndex		-  index of first entry to shift
 *			shiftSize		-  # of entries to shift, or 0 to shift all entries
 *								  from startIndex to the end of the Database
 *			adjustSize		- if true, the necessary changes will be made to the
 *									Database to record the fact that a record was
 *									inserted.
 *									NOTE: if adjustSize is true, shiftSize MUST BE 0.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 8/23/95
 *
 *  BY: Ron Marianetti
 *		vmk	1/13/98	Prevented incrementing record count before successful realloc
 *************************************************************/
static Err	PrvShiftEntriesDown(DmOpenRef dbR, UInt startIndex, 
			UInt shiftSize, Boolean adjustSize)
{
	DmOpenInfoPtr	openP = ((DmAccessPtr)dbR)->openP;
	RecordListPtr	listP, prevListP=0;
	LocalID			id;
	UInt				cumIndex;
	BytePtr			entryP, nextEntryP;
	Err				err = dmErrIndexOutOfRange;
	UInt				moveRecords;
	UInt				lastIndex;
	ULong				entrySize;
	
	
	// Determine the size of each entry, depending on whether this is a 
	//  record or resource database
	if (openP->resDB) entrySize = sizeof(RsrcEntryType);
	else entrySize = sizeof(RecordEntryType);
	
	
	// Point to the first list (part of the header)
	listP = &openP->hdrP->recordList;
	cumIndex = 0;
	
	
	// Error check - Shiftsize must be 0 if adjustSize is true
	ErrFatalDisplayIf(adjustSize && shiftSize, "Bad Params");
	
	
	//-----------------------------------------------------------------------------
	// Since we're shifting down, we need to start from the end and work our way to
	//  the beginning. We put the record at index N into the space at index N+1.
	// Look through the record lists till we get to the list that contains the
	//  first destination slot (N+1).
	//-----------------------------------------------------------------------------
	lastIndex = startIndex + shiftSize - 1;
	while(1) {
		
		// Get the ID of the next recordList
		id = listP->nextRecordListID;	

		// See if this recordList is the one that will hold the first record we move
		if (shiftSize) {
			if (lastIndex+1 < listP->numRecords + cumIndex) break;
			}
		else 
			if (id == 0) break;
			
		// Next list
		cumIndex += listP->numRecords;
		
		// We should only go past the end if the caller intends to grow the Database 
		//  (shiftSize==0)
		if (id == 0) {		 
			ErrDisplay("Invalid startIndex or shiftSize");
			shiftSize = 0;
			break;
			}
		prevListP = listP;
		listP = MemLocalIDToGlobal(id, openP->cardNo);
		
		// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
		if (!openP->handleTableP)
			listP = (RecordListPtr)MemDeref((Handle)listP);
		}
		
	// Calculate the actual shiftSize if the user passed 0
	if (!shiftSize)
		shiftSize = cumIndex + listP->numRecords - startIndex;
		
		
		
	//-----------------------------------------------------------------------------
	// Grow the last record list chunk by 1 entry if adjustSize is true.
	//  After this section, we must be sure to keep listP pointing to the
	//  list that has the destination slot of the first record we're going to move.
	//-----------------------------------------------------------------------------
	
	// DOLATER... the code presently attempts to keep each list segment as large as possible,
	// causing resizing and moves of possibly large amounts of data each time a new record is
	// added to a database with large number of records.  It may be worthwhile to investigate
	// further the effect of limiting the size of each record sub-list.  1/6/98 vmk
	
	if (adjustSize) {
		RecordListPtr*		listH;
		ULong					reqSize;
		
		// There was a huge window for breaking the database's integrity here
		// because the count was incremented before the reallocation.  So if the reallocation
		// forces a comapction that takes a very long time (several minutes is possible with
		// large heaps), the user can interpret that as a system hang and reset the unit.
		// If this happens, numRecords will indicate one more entry than there really are
		// in the list, causing the database integrity to be broken. -- FIXED vmk 1/6/98
		
		//listP->numRecords++;		// !!!don't want to pre-increment in case user resets during reasizing
		
		err = dmErrIndexOutOfRange;			// assume error
			
		// If it's the first list, it's part of the header
		if (!prevListP) {
			reqSize = sizeof(DatabaseHdrType) + ((listP->numRecords + 1) * entrySize);
			MemPtrUnlock(openP->hdrP);
			
			// Resize it
			err = MemHandleResize(openP->hdrH, reqSize);
			
			openP->hdrP = MemHandleLock(openP->hdrH);
			listP = &openP->hdrP->recordList;
			}
			
		// Else, it's a separate chunk
		else {
			reqSize = sizeof(RecordListType) + ((listP->numRecords + 1) * entrySize);
			listH = MemPtrRecoverHandle(listP);
			MemPtrUnlock(listP);
			
			// Resize it
			err = MemHandleResize(listH, reqSize);

			listP = MemHandleLock(listH);
			}
			
		// If resize succeeded, just increment count
		if ( !err ) {
			listP->numRecords++;
			}
			
		// Else, if we encountered an error resizing the chunk, we have to allocate another
		else {
			Handle	newH;
			
			#if 0		// CASTRATION -- we eliminated the over-increment above so don't need to fix up
				// Back off the increase in # of records on the list we couldn't grow
				listP->numRecords--;								// Back out the increase in size
			#endif
			
			// Allocate new record list
			reqSize = sizeof(RecordListType) + 1 * entrySize;
			newH = DmNewHandle(dbR, reqSize);
			if (!newH) {
				err = dmErrMemError; 
				goto ExitNoErrDisplay;
				}
			else err = 0;
			
			// Set the owner ID of the new list record chunk 
			MemHandleSetOwner(newH, dmMgrOwnerID);

			// Link this new list into the previous list and ajust
			//  cumIndex for the new list.
			listP->nextRecordListID = MemHandleToLocalID(newH);
			cumIndex += listP->numRecords;
			prevListP = listP;

			// Intialize and lock the new recordlist
			listP = MemHandleLock(newH);
			MemSet(listP, reqSize, 0);
			listP->numRecords = 1;
			}
		}
		
		
		

	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	// Loop through each record list and shift the entries in each one accordingly.
	// On entry here, listP points to the recordList that contains the destination slot of the
	//  first record we need to move (since we're copying from the end to the front,
	//  this turns out being the last record in the selected area).
	//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	err = dmErrIndexOutOfRange;					// assume error
	while(1) {
		Int	firstRelIndex;
	
		// Get pointer to first record in list.
		entryP = (BytePtr)&listP->firstEntry;
		

		// Calculate the index of the first record we need to move, relative to the
		//  current list.
		firstRelIndex = startIndex + shiftSize - cumIndex - 1;
		
		
		//..........................................................................
		// If it's in this list, do the necessary moves to this list. The only time this
		// will not be true is when we have just added a new chunk to hold an additional
		//  record.
		//..........................................................................
		if (firstRelIndex >= 0) {
		
			// Point to the first entry we need to move
			entryP = entryP + firstRelIndex*entrySize;

			// If we need to start before the end of this list, adjust the 
			// next record pointer to point to the following entry. Otherwise,
			//  keep it pointing to the first entry in the list we just came from.
			if (firstRelIndex  < listP->numRecords - 1)  
				nextEntryP = entryP + entrySize;
				
			// Calculate how many records to move in this list
			moveRecords = firstRelIndex + 1;
			if (moveRecords > shiftSize) moveRecords = shiftSize;
			
			// Decrement the remaining # of records we need to move in the other lists.
			shiftSize -= moveRecords;
	
			// Move Resource based entries
			if (openP->resDB) {
				RsrcEntryPtr	resP = (RsrcEntryPtr)entryP;
				RsrcEntryPtr	nextResP = (RsrcEntryPtr)nextEntryP;
				do {
					*nextResP = *resP;
					nextResP = resP;
					resP--;
					} while(--moveRecords);
				nextEntryP = (BytePtr)nextResP;
				}
				
			// Move Record based entries
			else {
				RecordEntryPtr	recP = (RecordEntryPtr)entryP;
				RecordEntryPtr	nextRecP = (RecordEntryPtr)nextEntryP;
				do {
					*nextRecP = *recP;
					nextRecP = recP;
					recP--;
					} while(--moveRecords);
				nextEntryP = (BytePtr)nextRecP;
				}
					
				
			// Break out if we're done
			if (shiftSize == 0) {err = 0; break;}
			}
			
		// the first index we need to move is not in this list, so just record a reference to
		//  the first slot in this list in the variable nextRecordP because it will hold the
		//  next record we move from the previous list.
		else 
			nextEntryP = entryP;
			
			
		//.................................................................
		// Get pointer to the previous list to this one
		//.................................................................
		listP = PrvPrevRecordList(openP, listP);
		ErrFatalDisplayIf(!listP, "Logic flaw");
		cumIndex -= listP->numRecords;

		} // while(1)
		
Exit:
	// Return error code
	ErrFatalDisplayIf(err, "Err shifting records in DB");
	
ExitNoErrDisplay:
	return err;

}







/************************************************************
 *
 *  FUNCTION: PrvPrevRecordList, private
 *
 *  DESCRIPTION: Returns pointer to the previous record list in a
 *		Database given a record list pointer.
 *
 *		This routine has to start from the top (the database header)
 *		and walk through each record list in order to find the previous one.
 *		
 *
 *  PARAMETERS: 
 *			openP 			-	DmOpenInfoPtr of open database
 *			listP				-  pointer to current record list
 *			
 *
 *  RETURNS: 
 *			RecordListPtr of previous recordList, or 0 if no previous list.
 *
 *	 CALLED BY: 
 *			PrvShiftRecordsDown
 *
 *  CREATED: 8/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static RecordListPtr	PrvPrevRecordList(DmOpenInfoPtr openP, RecordListPtr currentP)
{
	RecordListPtr	listP, prevListP=0;
	LocalID			id;
	
	// Point to the first list (part of the header)
	listP = &openP->hdrP->recordList;

	// If we're at the header, return 0
	if (currentP == listP) return 0;

	// Walk through till we get to the current list
	while(1) {
		prevListP = listP;
		id = listP->nextRecordListID;
		ErrFatalDisplayIf(!id, "Can't find previous list");
		
		// Convert the LocalID to a pointer
		listP = MemLocalIDToGlobal(id, openP->cardNo);
		
		// If it's not ROM based, we actually get a handle from MemLocalIDToGlobal
		if (!openP->handleTableP)
			listP = (RecordListPtr)MemDeref((Handle)listP);
			
		if (listP == currentP) return prevListP;
		} 
		
	// Should never get here...
	ErrDisplay("Error in logic");
	return 0;
}



 
/************************************************************
 *
 *  FUNCTION: PrvMergeFree
 *
 *  DESCRIPTION: This routine gets called when DmNewHandle is unsuccessful
 *		finding a free chunk large enough. This routine will attempt to
 *		re-arrange chunks in the heaps until it can make a free chunk that
 *		is reqSize in bytes.
 *
 *		It works by walking through all un-opened and un-protected databases
 *		and moving any records or resources they own out of the target heap.
 *		
 *		Initially, the target heap is the first storage heap. But, if the first
 *		pass through all the databases is unsuccessful, this algorithm will
 *		try successively higher target heaps. 
 *		
 *		
 *
 *  PARAMETERS: 
 *			reqSize		- desired amount of free space to form.
 *			
 *  RETURNS: 
 *			0 if enough free space has been formed to allocate a chunk of
 *		reqSize bytes. 
 *
 *	 CALLED BY: 
 *			DmNewHandle
 *
 *  CREATED: 9/26/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvMergeFree(Word	cardNo, DWord reqSize)
{
	Err				err = dmErrMemError;
	Word				dbIndex, targetHeapIndex, numRAMHeaps, newHeapIndex;
	Word				targetHeapID, newHeapID;
	Handle			recordH;
	DatabaseDirPtr	dirP=0, *dirH=0;
	Word				firstDBIndex, numDBs;
	LocalID			dbID;
	DmOpenInfoPtr	openP=0;
	Boolean			v20=false;
	DWord				romVersion;
	LocalID			dirID;
	DmOpenRef		dbR=0;
	Word				attributes;
	Word				recHeapID;
	Word				numRecords;
	Long				recIndex;
	Handle			newRecordH;
	DWord				recSize;
	DWord				resType;
	SWord				resID;
	LocalID			recLocalID;
	Boolean			movedSome = false;
	Word				recAttr;
	DWord				recUniqueID;
	Word				index;
	DWord				free, max;
	
	
	// DOLATER... this algorithm ignores the lock information and moves locked records/resources

	// Enable writes to memory
	MemSemaphoreReserve(true);


	// See if we're on version 2.0 of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion >= 0x02000000) v20 = true;
	
	
	// Get the index of the first RAM based database
	err = MemStoreInfo(cardNo, 0, 0, 0, 0, 0, 0, 0, 0, 0, &dirID);
	if (err == memErrRAMOnlyCard) {err = 0; dirID = 0;}
	if (err) goto Exit;
	if (dirID) {
		dirP = MemLocalIDToGlobal(dirID, cardNo);
		firstDBIndex = dirP->numDatabases;
		}
	else firstDBIndex = 0;
	numDBs = DmNumDatabases(cardNo);
	
	
	//===================================================================
	// Start trying to make free space in the first storage heap
	// and if that fails, try each successive heap till we reach the
	//  end
	//===================================================================
	numRAMHeaps = MemNumRAMHeaps(cardNo);
	for (targetHeapIndex = 0; targetHeapIndex < numRAMHeaps; targetHeapIndex++) {
		targetHeapID = MemHeapID(cardNo, targetHeapIndex);
		if (MemHeapDynamic(targetHeapID)) continue;
		
	
		//-----------------------------------------------------------------
		// Walk through each of the databases and re-allocate records
		// out of the target heap
		//-----------------------------------------------------------------
		for (dbIndex = firstDBIndex; dbIndex < numDBs; dbIndex++) {

			movedSome = false;
		
			// Get the localID of the database
			dbID = DmGetDatabase(cardNo, dbIndex);
			if (!dbID) {err = dmErrMemError; goto Exit;}
			
			
			// See if this database is open. If so, skip it
			openP = (DmOpenInfoPtr)GDmOpenList;
			while(openP) {
				if (openP->hdrID == dbID && openP->cardNo == cardNo) break;
				openP = (DmOpenInfoPtr)openP->next;
				}
			if (openP) continue;
			
			// On V2.0 and later versions of the ROM, make sure this 
			//  database is not protected
			if (v20 && GDmProtectListH) {
				DmProtectEntryPtr	entryP;
				UInt					numEntries;
				
				// Lock down list of protected databases
				err = 0;
				entryP = MemHandleLock(GDmProtectListH);
				numEntries = MemPtrSize(entryP) / sizeof(DmProtectEntryType);
				
				// See if this database is one of the protected ones
				for (; numEntries; entryP++, numEntries--) {
					if (entryP->cardNo == cardNo && entryP->dbID == dbID) {
						err = dmErrDatabaseProtected;
						break;
						}
					}
				
				// Unlock list and skip it if protected
				MemHandleUnlock(GDmProtectListH);
				if (err) continue;
				}


			// This database is neither open nor protected, so it's safe to
			//  move it's records around (i.e. no one has one of its record handles
			//  cached away somewhere). Open it and move any records it has in the
			//  target heap to other heaps
			dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
			if (!dbR) continue;
			
			// Records or resources?
			DmDatabaseInfo(cardNo, dbID, 0,
					&attributes, 0, 0,
					0, 0, 0, 0, 0, 0, 0);
					
					
			//---------------------------------------------------------------
			// Resource database
			//---------------------------------------------------------------
			if (attributes & dmHdrAttrResDB) {
				numRecords = DmNumResources(dbR);
				
				// Loop through each of the resources in the database.
				for (recIndex = (Long)numRecords-1; recIndex >= 0; recIndex--) {
					recordH = DmGetResourceIndex(dbR, recIndex);
					if (!recordH) continue;
					
					// See which heap this record is in.
					recHeapID = MemHandleHeapID(recordH);
					
					// If it's not in the target heap, skip it
					if (recHeapID != targetHeapID) continue;
					
					// Since it's in the target heap, move it out
					recSize = MemHandleSize(recordH);
					for (newHeapIndex=0; newHeapIndex < numRAMHeaps; newHeapIndex++) {
						newHeapID = MemHeapID(cardNo, newHeapIndex);
						if (MemHeapDynamic(newHeapID)) continue;
						if (newHeapID == targetHeapID) continue;

						// Don't completely fill the heaps. Especially in the case where
						//  a brand new database header is in the heap and will need to
						//  be resized in order to add the first record. 
						MemHeapFreeBytes(newHeapID, &free, &max);
						if (free < recSize + 0x200) continue;

						// Try and allocate a new record here.
						newRecordH = MemChunkNew(newHeapID, recSize, dmOrphanOwnerID);
						if (!newRecordH) continue;
						
						// Move the record contents to the new location
						DmResourceInfo(dbR, recIndex, &resType, &resID, &recLocalID);

						// Detach the old handle and attach the new one.
						err = DmDetachResource(dbR, recIndex, &recordH);
						if (err) { MemHandleFree(newRecordH); break; }
						err = DmAttachResource(dbR, newRecordH, resType, resID);
						if (err) {
							err = DmAttachResource(dbR, recordH, resType, resID);
							ErrFatalDisplayIf(err, "Corrupted database");
							MemHandleFree(newRecordH);
							break;
							}
							
						// Copy the contents from the old handle to the new one
						PrvDmHandleRealloc(dbR, recordH, newRecordH, 0);
						movedSome = true;
						break;
						}
					}
				}
				
				
			//---------------------------------------------------------------
			// Record database
			//---------------------------------------------------------------
			else {

				numRecords = DmNumRecords(dbR);
				
				// Loop through each of the records in the database.
				for (recIndex = (Long)numRecords-1; recIndex >= 0; recIndex--) {
				
					// Use this call so we can move deleted records too.
					err = DmRecordInfo(dbR, recIndex, &recAttr, &recUniqueID, &recLocalID);
					if (err || !recLocalID) continue;
					recordH = MemLocalIDToGlobal(recLocalID, cardNo);
					if (!recordH) continue;
					
					// See which heap this record is in.
					recHeapID = MemHandleHeapID(recordH);
					
					// If it's not in the target heap, skip it
					if (recHeapID != targetHeapID) continue;
					
					// Since it's in the target heap, move it out
					recSize = MemHandleSize(recordH);
					for (newHeapIndex=0; newHeapIndex < numRAMHeaps; newHeapIndex++) {
						newHeapID = MemHeapID(cardNo, newHeapIndex);
						if (MemHeapDynamic(newHeapID)) continue;
						if (newHeapID == targetHeapID) continue;

						// Don't completely fill the heaps. Especially in the case where
						//  a brand new database header is in the heap and will need to
						//  be resized in order to add the first record. 
						MemHeapFreeBytes(newHeapID, &free, &max);
						if (free < recSize + 0x200) continue;

						// Try and allocate the new record here
						newRecordH = MemChunkNew(newHeapID, recSize, dmOrphanOwnerID);
						if (!newRecordH) continue;
						

						// Detach the old handle and attach the new one.
						err = DmDetachRecord(dbR, recIndex, &recordH);
						if (err) { MemHandleFree(newRecordH); break; }
						index = recIndex;
						err = DmAttachRecord(dbR, &index, newRecordH, 0);
						if (err) {
							index = recIndex;
							err = DmAttachRecord(dbR, &index, recordH, 0);
							ErrFatalDisplayIf(err, "Corrupted database");
							MemHandleFree(newRecordH);
							break;
							}
						DmSetRecordInfo(dbR, index, &recAttr, &recUniqueID);
							
						// Copy the contents from the old handle to the new one
						PrvDmHandleRealloc(dbR, recordH, newRecordH, 0);
						movedSome = true;
						break;
						}
					}
				}
				
				
			// Close it
			DmCloseDatabase(dbR);
			dbR = 0;
			
			// If we've moved some data out of the target heap, see if we can
			// allocate a chunk now
			if (movedSome) {
				recordH = MemChunkNew(targetHeapID, reqSize, dmOrphanOwnerID);
				if (recordH) {
					MemHandleFree(recordH);
					err = 0;
					goto Exit;
					}
				}

			} // for (dbIndex = firstDBIndex; dbIndex < numDBs; dbIndex++) 
			
		} //for (heapIndex = 0; heapIndex < numHeaps; heapIndex++) 
	
	// If we fell out of the loop, we were unsuccessful
	err = dmErrMemError;
	
	
Exit:
	if (dbR) DmCloseDatabase(dbR);

	// Restore write-protection
	MemSemaphoreRelease(true);

	return err;
}


			
/************************************************************
 *
 *  FUNCTION: PrvDmHandleRealloc
 *
 *  DESCRIPTION: This routine will re-allocate a data manager
 *		handle in another heap, copy the contents over, and
 *		release the original handle.
 *		
 *  PARAMETERS: 
 *			dbR  - 		open ref of database this handle goes with
 *			oldH - 		original handle
 *			newH - 		new handle if already allocated
 *			size - 		new size (ignored if newH is non-nil)
 *			
 *  RETURNS: 
 *			new handle
 *
 *	 CALLED BY: 
 *			PrvMergeFree
 *
 *  CREATED: 9/26/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Handle	PrvDmHandleRealloc(DmOpenRef dbR, Handle oldH, 
						Handle newH, DWord size)
{
	BytePtr	srcP, dstP;
	DWord		oldSize;
	
	oldSize = MemHandleSize(oldH);
	
	// If we don't have a new handle yet, make one
	if (!newH) {
		newH = DmNewHandle(dbR, size);
		if (!newH) return 0;
		
		// Set the owner ID
		MemHandleSetOwner(newH, MemHandleOwner(oldH));
		}

	// Copy  the contents over
	srcP = MemHandleLock(oldH);
	dstP = MemHandleLock(newH);
	MemMove(dstP, srcP, oldSize);
	MemPtrUnlock(dstP);
	MemPtrUnlock(srcP);
	MemHandleFree(oldH);
	return newH;
}



/************************************************************
 *
 *  FUNCTION: PrvEnsureAllRecordsUnlocked
 *
 *  DESCRIPTION: This routine checks if there are any locked records/resources
 *						in the databases, and if so, puts up a fatal error alert in
 *						the debug build.
 *		
 *  PARAMETERS: 
 *			dbR  - 		open ref of record or resource database this handle goes with
 *			
 *  RETURNS: 
 *			new handle
 *
 *	 CALLED BY: 
 *			PrvMergeFree
 *
 *  CREATED: 9/26/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void PrvEnsureAllRecordsUnlocked(DmOpenRef dbR)
{
	volatile 	UInt		i = 0;
	volatile 	VoidHand	h = 0;
	volatile 	UInt		lockCount = 0;
	volatile		Boolean	isResDB = false;
	
	
	if ( !dbR )
		return;
	
	// Find out whether it is a resource or record database
	DmOpenDatabaseInfo(dbR, NULL, NULL, NULL, NULL, &isResDB);
	
	for (i=0; /*empty*/; i++)
		{
		if ( isResDB )
			h = DmGetResourceIndex(dbR, (Int)i);
		else
			h = DmQueryRecord(dbR, i);
		if ( h )
			{
			lockCount = MemHandleLockCount(h);
			if ( lockCount )
				{
				lockCount = lockCount;		// for having a place to set a breakpoint
				ErrNonFatalDisplayIf(true, "***NOT ALL RECORDS UNLOCKED***");
				}
			}
		else
		if ( DmGetLastErr() == dmErrIndexOutOfRange )
			break;
		}
}
