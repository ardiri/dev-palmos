/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		StringMgr.c
 *
 * Description:
 *		String manipulation functions
 *
 * History:
 *   	11/09/94  RM - Created by Ron Marianetti
 *
 *******************************************************************/

#include <SysAll.h>
#include <CharAttr.h>
#include <StdArg.h>



/************************************************************
 *
 *  FUNCTION: StrCopy
 *
 *  DESCRIPTION: Copies 1 string to another
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: pointer to dest string
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
CharPtr StrCopy(CharPtr dst, const Char* src)
{
	CharPtr	tmp = dst;

	// Check for err
	ErrFatalDisplayIf(dst == NULL || src == NULL, "NULL string passed");
	
	while(*src)
		*tmp++ = *src++;
	*tmp = 0;
	return dst;
}



/************************************************************
 *
 *  FUNCTION: StrNCopy strncpy
 *
 *  DESCRIPTION: Copies up to N characters from src string to dst string
 *						0 Terminates dst string at index N-1 if src string
 *						length was N-1 or less.
 *
 *  PARAMETERS: dst - destination string
 *					 src - source string
 *					 n   - max # of bytes to copy from src string
 *
 *  RETURNS: pointer to dest string
 *
 *  CREATED: 5/6/96
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Fill all of dest
 *			vmk	12/18/96	Removed ec code -- it was trashing data during
 *								"copy in place" operations
 *			adamh	8/12/97	Modified test for null termination to comply with
 *								ANSI specifications.
 *************************************************************/
CharPtr StrNCopy(CharPtr dstP, const Char * srcP, Word n)
{
	CharPtr	tmp = dstP;
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	CharPtr	endDestP = dstP + n;
#endif		
	
	
	// Check for err
	ErrFatalDisplayIf(dstP == NULL || srcP == NULL, "NULL string passed");
	
		
	// Copy N characters from src string
	while (*srcP && n > 0)
		{
		*tmp++ = *srcP++;
		--n;
		}
	
	
	// Terminate dest string if there's space.
	if (n > 0) 
		{
		*tmp = 0;
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		tmp++;
#endif
		}
	
	
	// Fill up the unused dest buffer with bytes to reveal errors.
	// Only copy over the remaining unused bytes.  This works correctly when
	// the src and dest overlap.
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	if (tmp < endDestP)
		{
		// Fill up the destination as much as allowed with a value to reveal errors.
		MemSet(tmp, endDestP - tmp, 0xfe);
		}
#endif
	
	
	return dstP;
}



/************************************************************
 *
 *  FUNCTION: StrCat
 *
 *  DESCRIPTION: Concatenates 1 string to another
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: pointer to dest string
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
CharPtr StrCat(CharPtr dst, const Char* src)
{
	CharPtr	tmp = dst;

	// Check for err
	ErrNonFatalDisplayIf(dst == NULL || src == NULL, "NULL string passed");
	ErrNonFatalDisplayIf(dst == src, "dest and source can't be the same");
	
	tmp += StrLen(dst);

	while(*src)
		*tmp++ = *src++;
	*tmp = 0;
	return dst;
}




/************************************************************
 *
 *  FUNCTION: StrNCat	(Palm OS Version 2)
 *
 *  DESCRIPTION: Concatenates 1 string to another clipping the
 *		destination string to a max of N characters (including null
 *    at end).
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: pointer to dest string
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Added ec code
 *			vmk	12/18/96	Removed ec code -- it was trashing data during
 *								"copy in place" operations
 *
 *************************************************************/
CharPtr StrNCat(CharPtr dstP, const Char* srcP, Word n)
{
	CharPtr	tmp = dstP;
	UInt		len;
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	CharPtr	endDestP = dstP + n;
#endif		
	
	
	// Check for err
	ErrFatalDisplayIf(dstP == NULL || srcP == NULL, "NULL string passed");
	ErrNonFatalDisplayIf(dstP == srcP, "dest and source can't be the same");
	
	len = StrLen(dstP);
	tmp += len;


	// Do the cat
	while(*srcP && len < n-1) {
		*tmp++ = *srcP++;
		len++;
		}
	
	// Null terminate the string if there's room
	if (len < n)
		{
		*tmp = 0;
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		tmp++;
#endif
		}
	
	
	// Fill up the unused dest buffer with bytes to reveal errors.
	// Only copy over the remaining unused bytes.  This works correctly when
	// the src and dest overlap.
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	if (tmp < endDestP)
		{
		// Fill up the destination as much as allowed with a value to reveal errors.
		MemSet(tmp, endDestP - tmp, 0xfe);
		}
#endif
	
		
	return dstP;
}


/************************************************************
 *
 *  FUNCTION: StrLen
 *
 *  DESCRIPTION: Computes the length of a string
 *
 *  PARAMETERS: string pointer
 *
 *  RETURNS: length of string
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt StrLen(const Char* str)
{
	UInt	i=0;

	// Check for err
	ErrNonFatalDisplayIf(str == NULL, "NULL string passed");
	
	while(*str++)
		i++;

	return i;
}


/************************************************************
 *
 *  FUNCTION: StrCompare
 *
 *  DESCRIPTION: Compares two strings.  This should be used
 *  to sort strings but not find them.
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: 0 if they match, non-zero if not
 *				 + if s1 > s2
 *				 - if s1 < s2
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *		  Roger Flores
 *
 *************************************************************/
Int StrCompare(const Char* s1, const Char* s2)
{
	Byte		c1, c2;
	Int 		result;
	BytePtr	tableP;


	// Check for err
	ErrNonFatalDisplayIf(s1 == NULL || s2 == NULL, "NULL string passed");
	
	// Get pointer to translation table
	tableP = GetCharSortValue();
	
	do {
		c1 = *s1++;
		c2 = *s2++;
		result = tableP[c1] - tableP[c2];
		if (result) return result;
		} while (c1 != '\0');
		
	return 0;		// equal strings
}


/************************************************************
 *
 *  FUNCTION: StrNCompare
 *
 *  DESCRIPTION: Compares two strings out to N characters.
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: 0 if they match, non-zero if not
 *				 + if s1 > s2
 *				 - if s1 < s2
 *
 *  CREATED: 7/18/96
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Int StrNCompare(const Char* s1, const Char* s2, DWord n)
{
	Byte		c1, c2;
	Int 		result;
	BytePtr	tableP;


	// Check for err
	ErrNonFatalDisplayIf(s1 == NULL || s2 == NULL, "NULL string passed");
	
	// Get pointer to translation table
	tableP = GetCharSortValue();
	
	while (n--)
		{
		c1 = *s1++;
		c2 = *s2++;
		result = tableP[c1] - tableP[c2];
		if (result) return result;
		if (c1 == '\0') return 0;
		}
		
	return 0;		// equal strings
}


/************************************************************
 *
 *  FUNCTION: StrCaselessCompare
 *
 *  DESCRIPTION: Compares two strings with case and accent insensitivity.  
 *  This should be used to find strings but not sort them because it ignores 
 *  case and accents.
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: 0 if they match, non-zero if not
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Int StrCaselessCompare(const Char* s1, const Char* s2)
{
	Byte	c1, c2;
	Int result;
	BytePtr	tableP;

	// Check for err
	ErrNonFatalDisplayIf(s1 == NULL || s2 == NULL, "NULL string passed");
	
	// Get pointer to translation table
	tableP = GetCharCaselessValue();
	
	do {
		c1 = *s1++;
		c2 = *s2++;
		result = tableP[c1] - tableP[c2];
		if (result) return result;
		} while (c1 != '\0');
		
	return 0;		// equal strings
}


/************************************************************
 *
 *  FUNCTION: StrNCaselessCompare
 *
 *  DESCRIPTION: Compares two strings out to N characters
 *  with case and accent insensitivity.
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: 0 if they match, non-zero if not
 *				 + if s1 > s2
 *				 - if s1 < s2
 *
 *  CREATED: 8/13/96
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Int StrNCaselessCompare(const Char* s1, const Char* s2, DWord n)
{
	Byte		c1, c2;
	Int 		result;
	BytePtr	tableP;


	// Check for err
	ErrNonFatalDisplayIf(s1 == NULL || s2 == NULL, "NULL string passed");
	
	// Get pointer to translation table
	tableP = GetCharCaselessValue();
	
	while (n--)
		{
		c1 = *s1++;
		c2 = *s2++;
		result = tableP[c1] - tableP[c2];
		if (result) return result;
		if (c1 == '\0') return 0;
		}
		
	return 0;		// equal strings
}


/************************************************************
 *
 *  FUNCTION: StrIToA
 *
 *  DESCRIPTION: convert an integer to ascii
 *
 *  PARAMETERS: Integer to convert and string pointer to store results
 *
 *  RETURNS: s
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Roger Flores
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	4/2/96	Handle negative numbers
 *
 *************************************************************/
CharPtr StrIToA(CharPtr s, Long i)
{
	CharPtr 	s1, s2;
	Char		c1, c2;


	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");

	
	// Handle negative numbers
	if (i < 0)
		{
		*s = '-';
		i = -i;
		
		s1 = s + 1;	// place numbers after the negative sign we put
		}
	else
		{
		s1 = s;		// place numbers after the start
		}
		
		
	// output the string in reverse order
	s2 = s1;
	do {
		*s2++ = i % 10 + '0';
		i /= 10;								// CSE should reuse the above division
	} while (i > 0);
	*s2 = '\0';
	s2--;
	
	
	// Reverse the string
	while(s1 < s2) 
		{
		c1 = *s1;
		c2 = *s2;
		
		*s1++ = c2;
		*s2-- = c1;
		}

	return s;
}


/************************************************************
 *
 *  FUNCTION: StrIToH
 *
 *  DESCRIPTION: convert an integer to hexadecimal ascii
 *
 *  PARAMETERS: Integer to convert and string pointer to store results
 *
 *  RETURNS: s
 *
 *  CREATED: 7/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
CharPtr StrIToH(CharPtr s, ULong i)
{
	DWord		mask;
	DWord		digit;
	UInt		j;
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");
	
	mask = 0xF0000000;
	for (j=0; j<8; j++) {
		digit = (i & mask) >> 28;
		if (digit <= 9) 
			s[j] = digit + '0';
		else
			s[j] = digit - 10 + 'A';
			
		i <<= 4;
		}
	s[j] = 0;

	return s;
}


/************************************************************
 *
 *  FUNCTION: StrLocalizeNumber
 *
 *  DESCRIPTION: Localize a number by converting from US number
 *  notation to a localized version by replacing any thousand
 *  or decimal separators.
 *
 *  PARAMETERS: s - number asci string to localize
 *					 thousandSeparator - the localized thousand separator
 *					 decimalSeparator - the localized decimal separator
 *
 *  RETURNS: s
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/28/96	Initial version
 *
 *************************************************************/
CharPtr StrLocalizeNumber(CharPtr s, Char thousandSeparator, Char decimalSeparator)
{
	CharPtr 	str = s;
	
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");

	
	while (*str != '\0')
		{
		// Check for thousandSeparator
		if (*str == ',') 
			*str = thousandSeparator;
		
		// Check for decimalSeparator
		if (*str == '.') 
			*str = decimalSeparator;
		
		// Look at the next char.
		str++;
		};
		
		
	return s;
}


/************************************************************
 *
 *  FUNCTION: StrDelocalizeNumber
 *
 *  DESCRIPTION: Delocalize a number by converting from a 
 *  localized number notation to a US version by replacing 
 *  any thousand or decimal separators.
 *
 *  PARAMETERS: s - number asci string to localize
 *					 thousandSeparator - the localized thousand separator
 *					 decimalSeparator - the localized decimal separator
 *
 *  RETURNS: s
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/28/96	Initial version
 *			adamh	8/12/97	Corrected Functionality
 *
 *************************************************************/
CharPtr StrDelocalizeNumber(CharPtr s, Char thousandSeparator, Char decimalSeparator)
{
	CharPtr 	str = s;
	
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");

	
	while (*str != '\0')
		{
		// Check for thousandSeparator
		if (*str == thousandSeparator)
			*str = ',';
		
		// Check for decimalSeparator
		if (*str == decimalSeparator) 
			*str = '.';
		
		// Look at the next char.
		str++;
		};
		
		
	return s;
}


/***********************************************************************
 *
 * FUNCTION:    StrChr
 *
 * DESCRIPTION: This routine looks for a character within a string. It behaves
 *						the same as the standard C library function strchr. Because
 *						of a bug in the Metrowerks libraries however, we can't link
 *						with the strstr() function in the library when compiling
 *						for the device.
 *
 * PARAMETERS:  str  - string to search strchr
 *              chr  - the character to search for
 *
 * RETURNED:    pointer to the first occurance of character in str, or null
 *						if not found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			ron	8/18/95	Initial Revision
 *			roger	5/7/96	Fixed to handle searching for '\0'
 *			roger	10/24/96	Check chr
 *			adamh	8/12/97	Revised Algorithm
 *
 ***********************************************************************/
CharPtr StrChr (const Char* str, Int chr)
{
	Char	c = (Char)chr;
	
	// Check for err
	ErrNonFatalDisplayIf(str == NULL, "NULL string passed");
	ErrNonFatalDisplayIf(chr > 0xFF, "bad chr passed");
	
	// Be sure to handle chr == '\0' correctly
	do
	{
		if(*str==c)
			return(CharPtr)str;
	}
	while(*str++ !=0);
	return NULL;
}



/***********************************************************************
 *
 * FUNCTION:    StrStr
 *
 * DESCRIPTION: This routine looks for a substring within a string. It behaves
 *						the same as the standard C library function strstr. Because
 *						of a bug in the Metrowerks libraries however, we can't link
 *						with the strstr() function in the library when compiling
 *						for the device.
 *
 * PARAMETERS:  str    - string to search
 *              token  - the string to search for
 *
 * RETURNED:    pointer to the first occurance of token in str, or null
 *						if not found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			ron	8/18/95	Initial Revision
 *
 ***********************************************************************/
CharPtr StrStr (const Char* str, const Char* token)
{
	const Char*	tP;
	const Char* sP;
	
	// Check for err
	ErrNonFatalDisplayIf(str == NULL || token == NULL, "NULL string passed");
	
	// Return null if token is null
	if (!token[0]) return 0;
	
	while(*str) {
		tP = token;
		sP = str;
		do {
			if (*tP != *sP) break;
			tP++; sP++;
			} while(*tP);
		if (*tP == 0) return(CharPtr) str;
		
		str++;
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    StrAToI
 *
 * DESCRIPTION: This routine converts a string to an integer.  It behaves
 *						the same as the standard C library function atoi. Because
 *						of a bug in the Metrowerks libraries however, we can't link
 *						with the atoi() function in the library when compiling
 *						for the device.
 *
 * PARAMETERS:  str    - string to convert
 *
 * RETURNED:    converted integer
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			ron	8/18/95	Initial Revision
 *			adamh	8/12/97	Added a for Max Long Int when Error Check Level == Full
 *			art	9/15/97	Fix error checking code.
 *			vmk	1/15/98	Disabled error checking code because it modified function's behavior
 *								and interfered with normal user input testing on debug builds
 *								(with agreement from Ron, Roger)
 *
 ***********************************************************************/
Long StrAToI (const Char* str)
{
	Long result=0;
	Int	sign = 1;
	Char	c;
	
	// DOLATER... what is needed here, is a way to signal an overrun error to the caller. vmk 1/15/98

#if 0		// CASTRATION
	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		Long MaxInt=0x7FFFFFFF;
		Long Divisor=1000000000;
		Boolean Risk=0;
		Int N=0;
		Int MaxDigits=10;
	#endif
#endif
	
	// Check for err
	ErrNonFatalDisplayIf(str == NULL, "NULL string ptr passed");
	
	// First character can be a sign
	c = *str++;
	if (!c) return 0;
	if (c == '+') {sign = 1; c = *str++;}
	else if (c == '-') {sign = -1; c = *str++;}
	
	// Accumulate digits will we reach the end of the string
	while(c)
	   {
		if (c < '0' || c > '9') break;
		result = result * 10 + c -'0';
		c = *str++;
		
#if 0		// CASTRATION
	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
			if (N++ == MaxDigits)	// ***THIS IS POOR ERROR-CHECKING CODE BECAUSE IT MODIFIES BEHAVIOR	vmk 1/15/98
				break;

			if(MaxInt / Divisor < result)		//If the current number were brought out to maximum length
				Risk = true;						//would it go over maximum size for a Long Int.
			Divisor /= 10;
	#endif
#endif
		}		

#if 0		// CASTRATION
	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		ErrNonFatalDisplayIf((Risk && N >=MaxDigits) || result < 0,"Number exceeds maximum value for a long integer");
	#endif
#endif

	return result * sign;
}



/************************************************************
 *
 *  FUNCTION: StrToLower
 *
 *  DESCRIPTION: Converts a string to a lower case one.  This
 *	 DOESN'T convert accented characters!
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: pointer to dest string
 *
 *  CREATED: 11/08/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
CharPtr StrToLower(CharPtr dst, const Char* src)
{
	CharPtr	tmp = dst;
	Byte c;

	// Check for err
	ErrNonFatalDisplayIf(dst == NULL || src == NULL, "NULL string passed");
	
	while(*src)
		{
		c = *src++;
		if ('A' <= c && c <= 'Z')
			c = c + ('a' - 'A');
		*tmp++ = c;
		}
	*tmp = 0;
	return dst;
}


/******************************************************************************
 *  FUNCTION: PrvAddPadding		<Internal>
 *
 *  DESCRIPTION: Support function vsprintf.  Adds padding to the string that
 *	is passed in.
 *
 *
 *
 *  PARAMETERS: 
 *			
 *
 *  RETURNS: CharPtr with padding 
 *
 *  CREATED: 7/2/97
 *
 *  BY: Adam Hampson
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *
 *****************************************************************************/


static CharPtr PrvAddPadding(const CharPtr startOfBlock,CharPtr dstP, const minimumSize,
	const Boolean leftJustify, Boolean zeroPad)
{
	
	Int stringSize = StrLen(startOfBlock);
	
	if (leftJustify && stringSize < minimumSize)		//Left Justified
		{
		MemSet(dstP, minimumSize - stringSize, ' ');
		dstP += minimumSize - stringSize;
		*dstP = '\0';
		}
	else if (!leftJustify && stringSize < minimumSize)	//Right Justified
		{
		MemMove(startOfBlock + minimumSize - stringSize, startOfBlock, stringSize);
		MemSet(startOfBlock, minimumSize - stringSize, zeroPad ? '0' : ' ');
		dstP += minimumSize - stringSize;
		*dstP = '\0';
		}
	return dstP;
}



/************************************************************
 *
 *  FUNCTION: PrvStrIToA			<internal>
 *
 *  DESCRIPTION: convert an integer to ascii
 *
 *  PARAMETERS: Integer to convert and string pointer to store results
 *
 *  RETURNS: s
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Roger Flores
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	4/2/96	Handle negative numbers
 *			adamh 7/31/97	Modified to return the end of string to work with
 *								StrVPrintF
 *
 *************************************************************/
static CharPtr PrvConvertIToA(CharPtr s, Long i)
{
	CharPtr 	s1, s2;
	Char		c1, c2;


	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");

	
	// Handle negative numbers
	if (i < 0)
		{
		*s++ = '-';
		i = -i;
		
		s1 = s;	// place numbers after the negative sign we put
		}
	else
		{
		s1 = s;		// place numbers after the start
		}
		
		
	// output the string in reverse order
	s2 = s1;
	do {
		*s++ = i % 10 + '0';
		i /= 10;								// CSE should reuse the above division
	} while (i > 0);
	*s = '\0';
	s2=s;
	s2--;
	
	
	// Reverse the string
	while(s1 < s2) 
		{
		c1 = *s1;
		c2 = *s2;
		
		*s1++ = c2;
		*s2-- = c1;
		}

	return s;
}


/************************************************************
 *
 *  FUNCTION: PrvConvertIToH	<internal>
 *
 *  DESCRIPTION: convert an integer to hexadecimal ascii
 *
 *  PARAMETERS: Integer to convert and string pointer to store results
 *
 *  RETURNS: s
 *
 *  CREATED: 7/4/95
 *
 *  BY: Ron Marianetti
 *  
 *  REVISION HISTORY:
 *         Name     Date      Description
 *         ----     ----      -----------
 *			  AdamH	  7/31/97   Modified to return the end of the string to work with
 *										StrVPrintF.
 *
 *************************************************************/
static CharPtr PrvConvertIToH(CharPtr s, ULong i)
{
	DWord		mask;
	DWord		digit;
	UInt		j;
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL, "NULL string passed");
	
	mask = 0xF0000000;
	for (j=0; j<8; j++) {
		digit = (i & mask) >> 28;
		if (digit <= 9) 
			*s++ = digit + '0';
		else
			*s++ = digit - 10 + 'A';
			
		i <<= 4;
		}
	*s = '\0';

	return s;
}


/******************************************************************************
 *  FUNCTION: StrVPrintF
 *
 *  DESCRIPTION: Implements a subset of the ANSI C vsprintf() call.
 *						Currently, only %d, %i, %u, %x and %s are implemented
 *						and don't accept field length or format specifications
 *						except for the l (long) modifier.
 *
 * 	Here's an example of how to use this call:
 *
 * #include <stdarg.h>
 * void MyPrintF(CharPtr s, CharPtr formatStr, ...)
 * {
 * 	va_list	args;
 *		Char		text[0x100];
 * 	
 * 	va_start(args, formatStr);
 * 	StrVPrintF(text, formatStr, args);
 * 	va_end(args);
 * 	
 *		MyPutS(text);
 * }
 *
 *
 *  PARAMETERS: s 			- destination string
 *					 formatStr 	- format string
 *					 argParam	- pointer to argument list
 *
 *  RETURNS: # of characters written to destination string
 *
 *  CREATED: 6/18/96
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Added NULL checks
 *			adamh	8/12/97		Added '+', ' ','-','h',minimum field width, argument based 
 *								field width.
 *							
 *****************************************************************************/


SWord StrVPrintF(CharPtr s, const Char* formatStr,const VoidPtr argParam)
{
	CharPtr		curFormatP;
	CharPtr		startOfBlockP;
	CharPtr		dstP;
	const Char* formatP;
	Long		   numberToConvert;
	CharPtr	   strP;
	Int		   minimumSize = 0;
	Char		   signFlag=0;
	Boolean     leftJustify = false;
	Boolean     zeroPad = false;
	va_list     arg = (va_list) argParam;
	enum sizeModifierType
		{
		sizeShort,
		sizeLong,
		sizeInt
		} sizeModifier;
	
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL || formatStr == NULL, "NULL string passed");
	
	// Init vars.
	formatP = formatStr;
	dstP=s;													//Save the front of the string
	
	// Look for next format specification
	while(*formatP) {
		// If no more %'s, print the rest
		curFormatP = StrChr(formatP, '%');
		if (!curFormatP)
		 	{
			StrCopy(dstP, formatP); //Move the rest of the format string into the destination string.
			break;
			}
			
		// If there is another %, print everything up to it
		//Move all the characters before the % sign into the destination string
		StrNCopy(dstP, formatP, curFormatP - formatP);
		dstP += curFormatP - formatP;
		*dstP = '\0';
		
		// point to format character
		formatP = curFormatP+1;




		/********* Flags ************
			'+'  Flag will cause a plus or a minus sign to be printed ahead of the number 
			Example:
				printf("%+d  %+d",4,-5);
			Outputs:
					+4  -5
			' '  Flag will cause a space or a minus sign to be printed ahead of the number
			Example:
				printf("% d  % d",4,-5);
			Output:
				 4  -5
			'-'  Flag will cause the result of the conversion to be left justified
			Example:
				printf("%5d%-5d%d",6,9,8);
			Output:
				    69    8
		*/
		while(formatP[0] == '+' || formatP[0] == ' ' || formatP[0] == '-')	
			{
			if(formatP[0] =='+')
				{	
				signFlag = '+';
				formatP++;
				}
			if(formatP[0] ==' ')
				{
				if(signFlag != '+')
					signFlag =' ';
				formatP++;
				}
			if(formatP[0] =='-')
				{
				leftJustify = true;
				formatP++;	
				}

			}



		/********** Minimum Field Width **************
			'*' modifier will casue the next argument on the list to be taken in and used as
			 the field width.
			 Example:
			 	printf("%*d%d",4,8,5);
			 Output:
			 	8   5
			 Placing a number between the % and the conversion will cause at least that number of 
			 spaces to be placed in the result string for that conversion
			 Example:
			 	printf("%d%5d",4,3);
			 Output:
			 	4    3		
		*/
	   if (formatP[0] == '*')						// Handle variable length padding
			{
			minimumSize = va_arg(arg,int);
			formatP++;
			}
		else
			{
			if (formatP[0] == '0')
				{
				zeroPad = true;
				formatP++;
				}
			
		   while(formatP[0] <='9' && formatP[0] >= '0')  // Handle fixed padding
		   	{
		      minimumSize = minimumSize * 10 + formatP[0] - '0';
				formatP++;
				}
			}



		/*********** Type Modifiers *************
			'l','L' modifiers will allow a Long Int to be passed through the converison
			Example:
				printf("%ld",999999999);
			Output:
				999999999
			'h' modifiers will allow a Short Int to be passed through the conversion
			Example:
				printf("%hd",401);
			Output:
				401
		*/
		if (formatP[0] == 'l' || formatP[0] == 'L') 
			{
			sizeModifier = sizeLong;
			formatP++;
			}
		else if (formatP[0] == 'h') 
			{
			sizeModifier = sizeShort;
			formatP++;
			}
		else
			sizeModifier = sizeInt;
	
		/************ Conversions ******************
			Each of the following conversions will convert a variable into a string and insert it 
			into the result string
		
	
		*/
		startOfBlockP=dstP;	//Keep a pointer to the start of the block for when we add the padding.
		switch(formatP[0])
		  {
		  
		  /********	Unsigned Integer Conversion *********
				This will convert to a string representation of an unsigned integer and place it on
				the destination string.
				
				Example:
					printf("%u   %u",4,-4);
				Output:
				4   65532
		   */
			
			case 'u':								
				switch(sizeModifier)
			   {
				case sizeLong:
				   numberToConvert = va_arg(arg, unsigned long);
				   break;
				case sizeShort: 
				   numberToConvert = va_arg(arg, unsigned short);
				   break;
				case sizeInt:
				   numberToConvert = va_arg(arg, unsigned int);
				   break;
				}
				if (signFlag == '+' || signFlag == ' ')
					*dstP++ = signFlag;
				dstP = PrvConvertIToA(dstP, numberToConvert);
				dstP = PrvAddPadding(startOfBlockP, dstP, minimumSize, leftJustify, zeroPad);
				signFlag = 0;
				formatP++;
				break;
				
				
			/********* Integer Conversion **********
				This will convert to a string representation of a signed integer andplace it on the
				destination string.
				
				Example:
					printf("%d   %d",4,-4);
				Output:
				4   -4	
			*/	
			
			case 'd':
			case 'i':								
				switch(sizeModifier) 
					{
					case sizeLong:
						numberToConvert = va_arg(arg, long);
						break;
					case sizeShort:
					   numberToConvert = va_arg(arg, short);
						break;
					case sizeInt:
						numberToConvert = va_arg(arg, int);
						break;
					}
				if((signFlag == '+' || signFlag == ' ') && numberToConvert >= 0) 
					*dstP++ = signFlag;
				dstP = PrvConvertIToA(dstP, numberToConvert);
				dstP = PrvAddPadding(startOfBlockP, dstP, minimumSize, leftJustify, zeroPad);
				signFlag = 0;
				formatP++;
				break;
				
				
			/********** Hexadecimal Conversion ***********
				Converts integer variables into strings of hexadecimal values
				
				Example:
					printf("%x",125);
				Output:
					0000007D
				
			*/
			case 'X':
			case 'x':								
				switch(sizeModifier)
					{
					case sizeLong:
						numberToConvert = va_arg(arg, long);
						break;
					case sizeShort: 
						numberToConvert = va_arg(arg, short);
						break;
					case sizeInt:
						numberToConvert = va_arg(arg, int);
					break;
				}
				dstP = PrvConvertIToH(dstP, numberToConvert);
				dstP = PrvAddPadding(startOfBlockP, dstP, minimumSize, leftJustify, zeroPad);
				formatP++;
				break;
				
				
			/*********** String Conversion *************
				Will copy a string onto the end of the destination string.
				
				Example:
					printf("United %s","States");
				Output:
					United States
			*/
			
			case 's':							
				strP = va_arg(arg, char *);
				StrCopy(dstP, strP);
				dstP += StrLen(startOfBlockP);
				dstP = PrvAddPadding(startOfBlockP, dstP, minimumSize, leftJustify, zeroPad);
				formatP++;
				break;
				
				
			/********** Character Conversion *************
				Will copy a single character to the end of the destination string.
				
				Example:
					printf("Telephone%c",'s');;
				Output:
					Telephones
			*/	
			
			case 'c':				
				*dstP++ = va_arg(arg, int);	//Read the character from the variable argument list into the destination string.
				*dstP = '\0';
				dstP = PrvAddPadding(startOfBlockP, dstP, minimumSize, leftJustify, zeroPad);
				formatP++;
				break;
				
				
			/********** %% Case **************
				This case allows the user to print out a % sign
				
				Example:
					printf("%%");
				Output:
					%
			*/
			
			case '%':							
				*dstP++ = '%';
				*dstP ='\0';
				formatP++;
				break;
				
		
			default:
				ErrNonFatalDisplayIf(true, "Unsupported");
				break;
			}
		minimumSize = 0;
		leftJustify = false;
		}
	
	va_end(arg);
	return StrLen(s);
}




/******************************************************************************
 *  FUNCTION: StrPrintF
 *
 *  DESCRIPTION: Implements a subset of the ANSI C sprintf() call.
 *  
 *  The following is implemented:
 *
 *  Conversions:	%u - unsigned int
 *						%d, %i - signed int
 *						%x, %x - hexadecimal
 *						%s - string
 *						%c - char
 *						%% - '%'
 *
 *  Type Modifier:l,L - long int (%ld)
 *						h - short int (%hd)
 *
 *  Field Width:	number - right justify result in field of width number (%5d)
 *
 *  Flags:			+ - cause a plus or minus sign to preceed the number (%+d)
 *						' ' - cause a space or minus sign to preceed the number (% d)
 *						'-' - cause the result to be left justified (%-5d)
 *						* - use the next argument for the field with (%*d)
 *
 *
 *  PARAMETERS: s 			- destination string
 *					 formatStr 	- format string
 *					 ...			- arguments for format string.
 *
 *  RETURNS: # of characters written to destination string
 *
 *  CREATED: 6/18/96
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Added NULL checks
 *****************************************************************************/
SWord StrPrintF(CharPtr s, const Char* formatStr, ...)
{
	va_list	args;
	SWord		result;
	
	// Check for err
	ErrNonFatalDisplayIf(s == NULL || formatStr == NULL, "NULL string passed");
	
	va_start(args, formatStr);
	result = StrVPrintF(s, formatStr, args);
	va_end(args);
	
	return result;
}



