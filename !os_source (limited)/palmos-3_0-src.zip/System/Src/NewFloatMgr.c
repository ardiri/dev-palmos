/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------  
 * FileName:
 *		NewFloatMgr.c
 *
 * Description:
 *		New Floating point routines, provided by new IEEE arithmetic
 *		68K software floating point emulator (sfpe) code.
 *
 * History:
 *    9/23/96 - Created by Steve Lemke
 *   10/16/96 - Fixed rounding problem in PrvFConvert (use div not mul)
 *   11/26/96 - Added FlpCorrectedAdd and FlpCorrectedSub routines
 *   12/30/96 - Added FlpVersion and FlpSelectorErrPrv routines
 *   12/10/97 - Added ThisShouldGenerateALinkError code to make sure
 *						flpSoftFPSCR doesn't move without our knowing about it!
 *   12/10/97 - FlpBase10Info now returns _positive_ zero, not _negative_
 *   12/18/97 - flpSoftFPSCR validation is now only done on ROM builds 
 *
 *******************************************************************/  

#include <SysAll.h>
#include <NewFloatMgr.h>

#define NON_PORTABLE 1
#include <Globals.h>		// for LowMemHdrType

#define kPowerBase 				99
#define kMaxSignificantDigits	7


/************************************************************************
 * New Floating point TenPowers array (private)
 ***********************************************************************/
typedef FlpDouble FlpTenPowersArray[200];
typedef FlpTenPowersArray* FlpTenPowersPtr;


/************************************************************************
 * Private Routines
 ***********************************************************************/
static Err					PrvFConvert(FlpDouble a, SWord* exp, DWord* iRes);
static FlpTenPowersPtr	PrvFGetTenPowersPtr(void);

void ThisShouldGenerateALinkError(void);



/***********************************************************************
 *
 * FUNCTION: 	 FlpBase10Info
 *
 * DESCRIPTION: Extract detailed information on the base 10 form of a floating point
 *              number : the base 10 mantissa, exponent, and sign.
 *              The mantissa will be normalized such that it contains at least 
 *              kMaxSignificantDigits significant digits when printed as an integer value.
 *
 * PARAMETERS:  a - the floating point number
 *              *mantissaP - will contain the base 10 mantissa
 *              *exponentP - will contain the base 10 exponent
 *              *signP - will contain the sign bit, 0 or 1; NOT 1 or -1
 *
 * RETURNED:	 error code, 0 = no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			SCL	12/10/97	v3.0: if a is zero, signP now returns zero instead of one
 *
 ***********************************************************************/
Err FlpBase10Info(FlpDouble a, DWord* mantissaP, SWord* exponentP, SWord* signP)
{
	SWord			exp;
	DWord			iRes;
	Err			error;
	
	// Make sure our floating point global didn't move!!
	// If the following fails, it means that "flpSoftFPSCR" (in <Globals.h>)
	// moved.  This is very bad, unless the corresponding assembly language
	// equate is fixed in Pilot:Libraries:NewFloatMgr:mc68ksfpe.s!!!
	// Of course, this is not necessary when building the simulator (it fails!).
#if EMULATION_LEVEL == EMULATION_NONE
	if ( (Word)(&(((LowMemHdrType*)PilotGlobalsP)->globals.flpSoftFPSCR)) != 0x0298)
		ThisShouldGenerateALinkError();
#endif


	// Check for 0
	if ( FlpIsZero(a) ) {
		*mantissaP = 0;
		*exponentP = 1;
		*signP = 0;
		return 0;
		}
	
	// convert the number to something usable, and check its validity
	error = PrvFConvert(a, &exp, &iRes);
	if (error) return error;
	
	// set results
	*mantissaP = iRes;
	*exponentP = exp - kMaxSignificantDigits;
	*signP = FlpGetSign(a);
	return 0;
}


/***********************************************************************
 *
 * FUNCTION: 	 FplFToA
 *
 * DESCRIPTION: Convert a floating point number to a zero terminated ascii string 
 *              in exponential format : [-]x.yyyyyyyye[-]zz
 *
 * PARAMETERS:  a - the floating point number
 *              s - pointer to buffer to contain the ascii string
 *                  presumed to be long enough!
 *
 * RETURNED:	 error code, 0 = no error
 *
 ***********************************************************************/
Err FlpFToA(FlpDouble a, Char* s)
{
	SWord			exp;
	DWord			iRes;
	Char*			s1;
	Char*			s2;
	Err			error;
	Char			c1, c2;
	
	// Check for 0
	if ( FlpIsZero(a) ) {
		s[0] = '0';
		s[1] = 0;
		return 0;
		}

	// convert the number to something usable, and check its validity
	error = PrvFConvert(a, &exp, &iRes);
	if (error) return error;
	
	// construct the decimal portion in reverse order
	s1 = s;
	s2 = s;
	do {
		if (iRes < 10) *s2++ = '.';
		
		*s2++ = iRes % 10 + '0';
		iRes = iRes / 10;
		} while (iRes > 0);
		
	// add minus sign if necessary
	if ( FlpGetSign(a) ) *s2++ = '-';
	
	// add zero terminator and reset s2 to point to 
	// the end of the reversed string
	*s2 = 0;
	s2--;
	
	// Reverse the string, in place
	while (s1 < s2) {
		c1 = *s1;
		c2 = *s2;
		
		*s1++ = c2;
		*s2-- = c1;
		}
		
	// find the end of the existing string
	s1 = s;
	while(*s1) s1++;
	
	// construct the exponent at the end of the existing string
	// add the 'e' and a minus sign if necessary
	*s1++ = 'e';
	if (exp < 0) {
		exp = -exp;
		*s1++ = '-';
		}
		
	// add the exp value and zero terminator
	s1[1] = exp % 10 + '0';
	exp = exp / 10;
	s1[0] = exp + '0';
	s1[2] = 0;
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION: 	 FlpAToF
 *
 * DESCRIPTION: Convert a zero terminated ascii string to a floating point number.
 *              The string must be in the format : [-]x[.]yyyyyyyy[e[-]zz]
 *
 * PARAMETERS:  s - pointer to the ascii string
 *
 * RETURNED:	 the floating point number
 *
 ***********************************************************************/
FlpDouble FlpAToF(Char* s)
{
	FlpTenPowersPtr gP = PrvFGetTenPowersPtr();
	FlpDouble		f;
	DWord				man;
	SWord				decPlaces, decExp;
	Boolean			negative = false;
	Char				c;
	
	// Get the sign
	if (s[0] == '-') {
		s++;
		negative = true;
		}

	// Init
	decPlaces = -1;
	man = 0;
	
	// Get the mantissa portion
	while(*s) {
		c = *s;
		if (c >= '0' && c<= '9') {
			man = man * 10 + (c - '0');
			if (decPlaces >= 0) decPlaces++;
			}
		else if (c == '.') 
			decPlaces = 0;
		else break;
		s++;
		}
	if (decPlaces < 0) decPlaces = 0;

	f = _d_utod (man);			// set the mantissa
	if (negative) {
		f = _d_neg (f);				// negate it
		negative = false;					// reset negative flag
	}

	// Get the exponent
	decExp = 0;
	if (*s == 'e') {
		s++;
		if (*s == '-') {
			negative = true;
			s++;
			}
			
		if (*s >= '0' && *s <= '9') {
			decExp = *s - '0';
			s++;
			if (*s >= '0' && *s <= '9') 
				decExp = (decExp * 10) + (*s - '0');
			}
		if (negative)
			decExp = -decExp;
		}
	
	// Scale by the decPlace in powers of ten
	decExp -= decPlaces;
	f = _d_mul(f, (*gP)[decExp + kPowerBase]);
	return f;	
}


/***********************************************************************
 *
 * FUNCTION: 	 PrvFConvert
 *
 * DESCRIPTION: Convert a floating point number to an integer number.
 *
 * PARAMETERS:  a - the floating point number
 *              *exp - exponent for the integer number
 *              *iRes - the integer number
 *
 * RETURNED:	 error if the floating point number is out of range.
 *
 ***********************************************************************/
static Err PrvFConvert(FlpDouble a, SWord* exp, DWord* iRes)
{
	FlpTenPowersPtr gP = PrvFGetTenPowersPtr();
	DWord			tmpIRes;
	FlpDouble	tmpRes;
	SWord			tmpExp, startExp;
	DWord			fpErr;

	_fp_set_fpscr(0);

	// Force it to positive since we don't (YET?) handle negative numbers
	FlpSetPositive(a);

	// We can make an educated guess where to start, based on the exponent and this info:
	//		1.0e-99 has a base 2 exponent of 0x2B6 ( #694)
	//		1.0e100 has a base 2 exponent of 0x54B (#1355)
	//		So, -330 < FlpGetExponent(a) < 331

	startExp = (FlpGetExponent(a));				// -330 <= startExp <= 331
	startExp /= 3;										// -110 <= startExp <= 110
	startExp += 11;									//  -99 <= startExp <= 121
	startExp = (startExp>99) ? 99 : startExp;	//  -99 <= startExp <= 99

	// Keep dividing by successively decreasing powers of 10 till we get a >1 result
	for (tmpExp = startExp; tmpExp >= -99; tmpExp--) {

		// Divide by the next smaller power of 10
		tmpRes = _d_div(a, (*gP)[tmpExp + kPowerBase]);

		// Try to convert the result to an integer
		tmpIRes = _d_dtou(tmpRes);
		if (tmpIRes > 0)
			break;
	}

	// If tmpIRes is > 10 or the exponent got smaller than -99 
	// we have a number too large to print (the base 10 power is greater than 99)
	if (tmpIRes > 10 || tmpExp > 98 || (tmpExp - (kMaxSignificantDigits+1) + kPowerBase) < 0)
		return flpErrOutOfRange;

	// We got the exponent (X), now divide by 10e(X-sigDigits) to get a sigDigits
	//  digit integer we can print easily.
	// We want tmpRes*10 (for rounding), so add one to kMaxSignificantDigits

	tmpRes = _d_div(a, (*gP)[tmpExp - (kMaxSignificantDigits+1) + kPowerBase]);	// was *res
	
	// Did the last divide go over the limit?
	fpErr = _fp_get_fpscr();
	_fp_set_fpscr(0);
	
	if (fpErr & flpOverflow ) {
		return flpErrOutOfRange;		// DOLATER - is this ok?
	}

	// Set results for the caller
	*exp = tmpExp;
	*iRes = _d_dtou(tmpRes);		// was *res

	// THEORY:  At this point, we should have a decimal number in the
	// range of 100,000,000 to 999,999,999 -- essentially eight digits, plus
	// an extra so we can round properly.  Sometimes, we will end up
	// dividing by the wrong power of ten and will end up with a number
	// that is (most likely) 1,000,000,000.  This number was really supposed
	// to be 100,000,000 and the exponent was supposed to be one lower.
	// So, we divide by ten, bump the exponent, and then fall through to
	// our normal rounding code.
	// BUGFIX SCL 2/9/98: Check for >= 999,999,995, not >= 999,999,999!
	// This fixes the case where (in 2.0) 99,999,999 + .5 displays 10,000,000.
	
	if (*iRes >= 999999995UL) {	// was it supposed to be 100,000,000?
		*iRes /= 10;					// trim the extra digit
		*exp += 1;						// and bump the exponent
	}
	*iRes += 5;					// round now before we trim the last digit
	*iRes /= 10;				// trim the last (extra) digit
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    DoCorrectedAddSub
 *
 * DESCRIPTION: Perform desired calculation based on the last result value and the 
 *              provided parameter.  The calculation result is returned
 *
 *	COMMENTS:	 In order to fix the "0.3 - 0.1 = = =" small-but-not-zero bug
 *					 (aka "1.0 - 0.1 = = = = = = = = = ="), in 2.0b2 we introduce
 *					 new code which compares the exponents of the operands to the
 *					 exponent of the result and forces the result to zero if appropriate.
 *					 
 *					 Adding or subtracting a big number and a small number produces a
 *					 result similar in magnitude to the big number.  But two numbers
 *					 that are similar in magnitude MAY produce (depending on their
 *					 signs) a result with a very small exponent (i.e. a large, but
 *					 negative exponent).  If the difference between the result's
 *					 exponent and that of the operands is very large (i.e. close
 *					 to the number of significant bits expressable by the mantissa)
 *					 then it is quite possible that the result should in fact be zero.
 *					 
 *					 Apple's Calculator DA doesn't seem to do anything special to
 *					 handle these cases, though it appears that the Windows95
 *					 Calculator does. The HP-15c and other hand-held calculators
 *					 don't seem to "remember" any digits past the ones they display.
 *					 
 *					 Besides the problem cases above, there exist cases where it
 *					 may be useful to retain accuracy in the low-order bits of
 *					 the mantissa, e.g.: 99999999 + 0.00000001 - 99999999.  However,
 *					 unless the fractional part is an exact (negative) power of two,
 *					 it is doubtful that what few bits of mantissa that are available
 *					 will be enough to properly represent the fractional value.  In
 *					 this example, the 99999999 requires 26 bits, leaving 26 bits for
 *					 the .00000001, which guarantees inaccuracy after the subtraction.
 *					 
 *					 The problem comes from the difficulty in representing decimal
 *					 fractions in binary (like 0.1).  After about three successive
 *					 additions or subtractions, errors begin to appear in the least
 *					 significant bits of the mantissa.  Then when the value represented
 *					 by the most significant bits of the mantissa is subtracted away,
 *					 the lsb's error is normalized and becomes the actual result when
 *					 in fact the result should've been zero.
 *					 
 *					 Deciding where to draw the line between when to force the result
 *					 to zero and when not to is, however, an interesting dilemma...
 *					 
 *					 0.3 - .1 = = = yields (minExp-tempExp) of -4 - -55 or 51
 *					 1.0 - .1 = = = = = = = = = =    yields -4 - -53 or 49
 *					 
 *					 99999999 + .00000001 - 99999999 yields 26 - -26 or 52
 *					 99999999 + .0000001  - 99999999 yields 26 - -24 or 50
 *					 99999999 + .000001   - 99999999 yields 26 - -20 or 46 (*)
 *					  (*)  when not "corrected", this result appears as 9.9837780e-07
 *					 99999999 + .00001    - 99999999 yields 26 - -17 or 43 (**)
 *					  (**) when not "corrected", this result appears as 9.9986792e-06
 *					 99999999 + .1        - 99999999 yields 26 - -4  or 30 (***)
 *					  (**) when not "corrected", this result appears as 9.9999994e-02
 *					 
 *					 Thus, acting on a difference of 49 or higher will catch the two
 *					 widely known problem cases described above.  However, starting with
 *					 a higher initial value (such as 2.0) will not get "corrected".
 *					 In addition, we start to lose accuracy (which admittedly, other
 *					 calculators don't seem to have) in the second set of examples.
 *					 
 *					 We could use a value as low as 30, which should eliminate
 *					 all potential problem cases, but will also sacrifice
 *					 our accuracy in digits "remembered" but not "displayed".
 *					 We have a default "accuracy" (kDefaultAccuracy), but we also
 *					 allow the programmer to override the default if desired.
 *					 
 *					 Incidentally, this is *only* an issue for addition and subtraction.
 *
 * PARAMETERS:  Two operands for the calculation, and the desired accuracy
 *
 * RETURNED:    The result of the calculation
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			steve	11/26/96	initial version
 *
 ***********************************************************************/
#define kDefaultAccuracy 48			// default accuracy if not specified

FlpDouble FlpCorrectedAdd (FlpDouble firstOperand, FlpDouble secondOperand,
												SWord howAccurate)
{
	FlpDouble	result;
	SWord			minExp, tempExp;		// to keep track of the smallest exponent

	// get the signed (base two) exponents for each operand
	tempExp = FlpIsZero(firstOperand) ? 0 : FlpGetExponent(firstOperand);
	minExp = FlpIsZero(secondOperand) ? 0 : FlpGetExponent(secondOperand);

	// set minExp to be the lesser of the two
	if (tempExp < minExp) {
		minExp = tempExp;
		}

	// perform the addition
	result = _d_add(firstOperand, secondOperand);

	// get the exponent of the result, if the result is non-zero
	if ( !FlpIsZero(result) ) {

		tempExp = FlpGetExponent(result);

		// see if the result is significantly smaller than the smallest
		if (howAccurate == 0) {
			howAccurate = kDefaultAccuracy;		// default accuracy
			}

		if (minExp - tempExp > howAccurate) {	// higher values should be
			(*(FlpCompDouble*)&result).d = 0.0;		// forced to zero
			}

		}

	return(result);
}


/***********************************************************************
 *
 * FUNCTION: 	 FlpCorrectedSub
 *
 * DESCRIPTION: Same as FlpCorrectedAdd, above, but for subtraction
 *
 ***********************************************************************/
FlpDouble FlpCorrectedSub (FlpDouble firstOperand, FlpDouble secondOperand,
												SWord howAccurate)
{
	FlpDouble	result;
	SWord			minExp, tempExp;		// to keep track of the smallest exponent

	// get the signed (base two) exponents for each operand
	tempExp = FlpIsZero(firstOperand) ? 0 : FlpGetExponent(firstOperand);
	minExp = FlpIsZero(secondOperand) ? 0 : FlpGetExponent(secondOperand);

	// set minExp to be the lesser of the two
	if (tempExp < minExp) {
		minExp = tempExp;
		}

	// perform the subtraction
	result = _d_sub(firstOperand, secondOperand);

	// get the exponent of the result, if the result is non-zero
	if ( !FlpIsZero(result) ) {
		tempExp = FlpGetExponent(result);

		// see if the result is significantly smaller than the smallest
		if (howAccurate == 0) {
			howAccurate = 48;							// default accuracy
			}

		if (minExp - tempExp > howAccurate) {	// higher values should be
			(*(FlpCompDouble*)&result).d = 0.0;		// forced to zero
			}

		}

	return(result);
}


/***********************************************************************
 *
 * FUNCTION: 	 FlpVersion
 *
 * DESCRIPTION: Returns version of NewFloatMgr
 *
 ***********************************************************************/
DWord FlpVersion (void)
{
	return(flpVersion);
}


/***********************************************************************
 *
 * FUNCTION: 	 FlpSelectorErrPrv
 *
 * DESCRIPTION: Displays error if bad selector is passed to NewFloatDispatch
 *					 Should this use ErrDisplayFileLineMsg instead?
 *					 It's a pretty fatal error...
 *
 ***********************************************************************/
void FlpSelectorErrPrv (Word flpSelector)
{
	char	text[256];
	char	str[10];
	
	// Form the error message
	StrCopy(text, "Unsupported NewFloatMgr call: ");
	StrIToA(str, flpSelector);
	StrCat(text, str);
	ErrDisplay(text);
}


/***********************************************************************
 *
 * FUNCTION: 	 PrvFGetTenPowersPtr
 *
 * DESCRIPTION: Return pointer to FlpGlobalsType (array of tenPowers, etc.)
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	 pointer to FlpGlobalsType
 *
 ***********************************************************************/
static asm FlpTenPowersPtr PrvFGetTenPowersPtr()
{
	lea @theFlpGlobals, A0
	rts
@theFlpGlobals:
    // Generated by Steve's nifty tenPowers expander, DoubleDump...
    dc.w 0x2B61,0x7F7D,0x4ED8,0xC33E,   0x2B95,0xDF5C,0xA28E,0xF40D,    0x2BCB,0x5733,0xCB32,0xB111,    0x2C01,0x1680,0x5EFF,0xAEAA // 1.0e-99...1.0e-96
    dc.w 0x2C35,0x5C20,0x76BF,0x9A55,   0x2C6A,0xB328,0x946F,0x80EA,    0x2CA0,0xAFF9,0x5CC5,0xB092,    0x2CD4,0xDBF7,0xB3F7,0x1CB7 // 1.0e-95...1.0e-92
    dc.w 0x2D0A,0x12F5,0xA0F4,0xE3E5,   0x2D40,0x4BD9,0x8499,0x0E6F,    0x2D74,0x5ECF,0xE5BF,0x520B,    0x2DA9,0x7683,0xDF2F,0x268D // 1.0e-91...1.0e-88
    dc.w 0x2DDF,0xD424,0xD6FA,0xF031,   0x2E13,0xE497,0x065C,0xD61F,    0x2E48,0xDDBC,0xC7F4,0x0BA6,    0x2E7F,0x152B,0xF9F1,0x0E90 // 1.0e-87...1.0e-84
    dc.w 0x2EB3,0x6D3B,0x7C36,0xA91A,   0x2EE8,0x488A,0x5B44,0x5360,    0x2F1E,0x5AAC,0xF215,0x6838,    0x2F52,0xF8AC,0x174D,0x6123 // 1.0e-83...1.0e-80
    dc.w 0x2F87,0xB6D7,0x1D20,0xB96C,   0x2FBD,0xA48C,0xE468,0xE7C7,    0x2FF2,0x86D8,0x0EC1,0x90DC,    0x3027,0x288E,0x1271,0xF513 // 1.0e-79...1.0e-76
    dc.w 0x305C,0xF2B1,0x970E,0x7258,   0x3092,0x17AE,0xFE69,0x0777,    0x30C6,0x9D9A,0xBE03,0x4955,    0x30FC,0x4501,0x6D84,0x1BAA // 1.0e-75...1.0e-72
    dc.w 0x3131,0xAB20,0xE472,0x914A,   0x3166,0x15E9,0x1D8F,0x359D,    0x319B,0x9B63,0x64F3,0x0304,    0x31D1,0x411E,0x1F17,0xE1E3 // 1.0e-71...1.0e-68
    dc.w 0x3205,0x9165,0xA6DD,0xDA5B,   0x323A,0xF5BF,0x1095,0x50F2,    0x3270,0xD997,0x6A5D,0x5297,    0x32A5,0x0FFD,0x44F4,0xA73D // 1.0e-67...1.0e-64
    dc.w 0x32DA,0x53FC,0x9631,0xD10D,   0x3310,0x747D,0xDDDF,0x22A8,    0x3344,0x919D,0x5556,0xEB52,    0x3379,0xB604,0xAAAC,0xA626 // 1.0e-63...1.0e-60
    dc.w 0x33B0,0x11C2,0xEAAB,0xE7D8,   0x33E4,0x1633,0xA556,0xE1CE,    0x3419,0x1BC0,0x8EAC,0x9A41,    0x344F,0x62B0,0xB257,0xC0D2 // 1.0e-59...1.0e-56
    dc.w 0x3483,0x9DAE,0x6F76,0xD883,   0x34B8,0x851A,0x0B54,0x8EA4,    0x34EE,0xA660,0x8E29,0xB24D,    0x3523,0x27FC,0x58DA,0x0F70 // 1.0e-55...1.0e-52
    dc.w 0x3557,0xF1FB,0x6F10,0x934C,   0x358D,0xEE7A,0x4AD4,0xB81F,    0x35C2,0xB50C,0x6EC4,0xF313,    0x35F7,0x624F,0x8A76,0x2FD8 // 1.0e-51...1.0e-48
    dc.w 0x362D,0x3AE3,0x6D13,0xBBCE,   0x3662,0x44CE,0x242C,0x5561,    0x3696,0xD601,0xAD37,0x6AB9,    0x36CC,0x8B82,0x1885,0x4567 // 1.0e-47...1.0e-44
    dc.w 0x3701,0xD731,0x4F53,0x4B61,   0x3736,0x4CFD,0xA328,0x1E39,    0x376B,0xE03D,0x0BF2,0x25C7,    0x37A1,0x6C26,0x2777,0x579C // 1.0e-43...1.0e-40
    dc.w 0x37D5,0xC72F,0xB155,0x2D83,   0x380B,0x38FB,0x9DAA,0x78E4,    0x3841,0x039D,0x428A,0x8B8F,    0x3875,0x4484,0x932D,0x2E72 // 1.0e-39...1.0e-36
    dc.w 0x38AA,0x95A5,0xB7F8,0x7A0F,   0x38E0,0x9D87,0x92FB,0x4C49,    0x3914,0xC4E9,0x77BA,0x1F5C,    0x3949,0xF623,0xD5A8,0xA733 // 1.0e-35...1.0e-32
    dc.w 0x3980,0x39D6,0x6589,0x6880,   0x39B4,0x484B,0xFEEB,0xC2A0,    0x39E9,0x5A5E,0xFEA6,0xB347,    0x3A1F,0xB0F6,0xBE50,0x6019 // 1.0e-31...1.0e-28
    dc.w 0x3A53,0xCE9A,0x36F2,0x3C10,   0x3A88,0xC240,0xC4AE,0xCB14,    0x3ABE,0xF2D0,0xF5DA,0x7DD9,    0x3AF3,0x57C2,0x99A8,0x8EA7 // 1.0e-27...1.0e-24
    dc.w 0x3B28,0x2DB3,0x4012,0xB251,   0x3B5E,0x3920,0x1017,0x5EE6,    0x3B92,0xE3B4,0x0A0E,0x9B4F,    0x3BC7,0x9CA1,0x0C92,0x4223 // 1.0e-23...1.0e-20
    dc.w 0x3BFD,0x83C9,0x4FB6,0xD2AC,   0x3C32,0x725D,0xD1D2,0x43AC,    0x3C67,0x0EF5,0x4646,0xD497,    0x3C9C,0xD2B2,0x97D8,0x89BC // 1.0e-19...1.0e-16
    dc.w 0x3CD2,0x03AF,0x9EE7,0x5616,   0x3D06,0x849B,0x86A1,0x2B9B,    0x3D3C,0x25C2,0x6849,0x7682,    0x3D71,0x9799,0x812D,0xEA11 // 1.0e-15...1.0e-12
    dc.w 0x3DA5,0xFD7F,0xE179,0x6495,   0x3DDB,0x7CDF,0xD9D7,0xBDBB,    0x3E11,0x2E0B,0xE826,0xD695,    0x3E45,0x798E,0xE230,0x8C3A // 1.0e-11...1.0e-8
    dc.w 0x3E7A,0xD7F2,0x9ABC,0xAF48,   0x3EB0,0xC6F7,0xA0B5,0xED8D,    0x3EE4,0xF8B5,0x88E3,0x68F1,    0x3F1A,0x36E2,0xEB1C,0x432D // 1.0e-7...1.0e-4
    dc.w 0x3F50,0x624D,0xD2F1,0xA9FC,   0x3F84,0x7AE1,0x47AE,0x147B,    0x3FB9,0x9999,0x9999,0x999A,    0x3FF0,0x0000,0x0000,0x0000 // 1.0e-3...1.0e 0
    dc.w 0x4024,0x0000,0x0000,0x0000,   0x4059,0x0000,0x0000,0x0000,    0x408F,0x4000,0x0000,0x0000,    0x40C3,0x8800,0x0000,0x0000 // 1.0e 1...1.0e 4
    dc.w 0x40F8,0x6A00,0x0000,0x0000,   0x412E,0x8480,0x0000,0x0000,    0x4163,0x12D0,0x0000,0x0000,    0x4197,0xD784,0x0000,0x0000 // 1.0e 5...1.0e 8
    dc.w 0x41CD,0xCD65,0x0000,0x0000,   0x4202,0xA05F,0x2000,0x0000,    0x4237,0x4876,0xE800,0x0000,    0x426D,0x1A94,0xA200,0x0000 // 1.0e 9...1.0e12
    dc.w 0x42A2,0x309C,0xE540,0x0000,   0x42D6,0xBCC4,0x1E90,0x0000,    0x430C,0x6BF5,0x2634,0x0000,    0x4341,0xC379,0x37E0,0x8000 // 1.0e13...1.0e16
    dc.w 0x4376,0x3457,0x85D8,0xA000,   0x43AB,0xC16D,0x674E,0xC800,    0x43E1,0x58E4,0x6091,0x3D00,    0x4415,0xAF1D,0x78B5,0x8C40 // 1.0e17...1.0e20
    dc.w 0x444B,0x1AE4,0xD6E2,0xEF50,   0x4480,0xF0CF,0x064D,0xD592,    0x44B5,0x2D02,0xC7E1,0x4AF6,    0x44EA,0x7843,0x79D9,0x9DB4 // 1.0e21...1.0e24
    dc.w 0x4520,0x8B2A,0x2C28,0x0291,   0x4554,0xADF4,0xB732,0x0335,    0x4589,0xD971,0xE4FE,0x8402,    0x45C0,0x27E7,0x2F1F,0x1281 // 1.0e25...1.0e28
    dc.w 0x45F4,0x31E0,0xFAE6,0xD721,   0x4629,0x3E59,0x39A0,0x8CEA,    0x465F,0x8DEF,0x8808,0xB024,    0x4693,0xB8B5,0xB505,0x6E17 // 1.0e29...1.0e32
    dc.w 0x46C8,0xA6E3,0x2246,0xC99C,   0x46FE,0xD09B,0xEAD8,0x7C03,    0x4733,0x4261,0x72C7,0x4D82,    0x4768,0x12F9,0xCF79,0x20E3 // 1.0e33...1.0e36
    dc.w 0x479E,0x17B8,0x4357,0x691B,   0x47D2,0xCED3,0x2A16,0xA1B1,    0x4807,0x8287,0xF49C,0x4A1D,    0x483D,0x6329,0xF1C3,0x5CA5 // 1.0e37...1.0e40
    dc.w 0x4872,0x5DFA,0x371A,0x19E7,   0x48A6,0xF578,0xC4E0,0xA061,    0x48DC,0xB2D6,0xF618,0xC879,    0x4911,0xEFC6,0x59CF,0x7D4C // 1.0e41...1.0e44
    dc.w 0x4946,0x6BB7,0xF043,0x5C9E,   0x497C,0x06A5,0xEC54,0x33C6,    0x49B1,0x8427,0xB3B4,0xA05C,    0x49E5,0xE531,0xA0A1,0xC873 // 1.0e45...1.0e48
    dc.w 0x4A1B,0x5E7E,0x08CA,0x3A8F,   0x4A51,0x1B0E,0xC57E,0x649A,    0x4A85,0x61D2,0x76DD,0xFDC0,    0x4ABA,0xBA47,0x1495,0x7D30 // 1.0e49...1.0e52
    dc.w 0x4AF0,0xB46C,0x6CDD,0x6E3E,   0x4B24,0xE187,0x8814,0xC9CE,    0x4B5A,0x19E9,0x6A19,0xFC41,    0x4B90,0x5031,0xE250,0x3DA9 // 1.0e53...1.0e56
    dc.w 0x4BC4,0x643E,0x5AE4,0x4D13,   0x4BF9,0x7D4D,0xF19D,0x6057,    0x4C2F,0xDCA1,0x6E04,0xB86D,    0x4C63,0xE9E4,0xE4C2,0xF344 // 1.0e57...1.0e60
    dc.w 0x4C98,0xE45E,0x1DF3,0xB015,   0x4CCF,0x1D75,0xA570,0x9C1B,    0x4D03,0x7269,0x8766,0x6191,    0x4D38,0x4F03,0xE93F,0xF9F5 // 1.0e61...1.0e64
    dc.w 0x4D6E,0x62C4,0xE38F,0xF872,   0x4DA2,0xFDBB,0x0E39,0xFB47,    0x4DD7,0xBD29,0xD1C8,0x7A19,    0x4E0D,0xAC74,0x463A,0x989F // 1.0e65...1.0e68
    dc.w 0x4E42,0x8BC8,0xABE4,0x9F64,   0x4E77,0x2EBA,0xD6DD,0xC73D,    0x4EAC,0xFA69,0x8C95,0x390C,    0x4EE2,0x1C81,0xF7DD,0x43A7 // 1.0e69...1.0e72
    dc.w 0x4F16,0xA3A2,0x75D4,0x9491,   0x4F4C,0x4C8B,0x1349,0xB9B5,    0x4F81,0xAFD6,0xEC0E,0x1411,    0x4FB6,0x1BCC,0xA711,0x9916 // 1.0e73...1.0e76
    dc.w 0x4FEB,0xA2BF,0xD0D5,0xFF5B,   0x5021,0x45B7,0xE285,0xBF99,    0x5055,0x9725,0xDB27,0x2F7F,    0x508A,0xFCEF,0x51F0,0xFB5F // 1.0e77...1.0e80
    dc.w 0x50C0,0xDE15,0x9336,0x9D1B,   0x50F5,0x159A,0xF804,0x4462,    0x512A,0x5B01,0xB605,0x557B,    0x5160,0x78E1,0x11C3,0x556D // 1.0e81...1.0e84
    dc.w 0x5194,0x9719,0x5634,0x2AC8,   0x51C9,0xBCDF,0xABC1,0x357A,    0x5200,0x160B,0xCB58,0xC16C,    0x5234,0x1B8E,0xBE2E,0xF1C7 // 1.0e85...1.0e88
    dc.w 0x5269,0x2272,0x6DBA,0xAE39,   0x529F,0x6B0F,0x0929,0x59C7,    0x52D3,0xA2E9,0x65B9,0xD81D,    0x5308,0x8BA3,0xBF28,0x4E24 // 1.0e89...1.0e92
    dc.w 0x533E,0xAE8C,0xAEF2,0x61AD,   0x5373,0x2D17,0xED57,0x7D0C,    0x53A7,0xF85D,0xE8AD,0x5C4F,    0x53DD,0xF675,0x62D8,0xB363 // 1.0e93...1.0e96
    dc.w 0x5412,0xBA09,0x5DC7,0x701E,   0x5447,0x688B,0xB539,0x4C25,    0x547D,0x42AE,0xA287,0x9F2E,    0x54B2,0x49AD,0x2594,0xC37D // 1.0e97...1.0e100
//  dc.w 0x0000,0x0000,0x0000,0x0000    // (double) 0
}
/***********************************************************************
 *
 * FUNCTION: 	 DoubleDump
 *
 * DESCRIPTION: Print out lots of dc.w lines with hex values for tenPowers
 *						To build this, paste it over the HelloWorld.c code in
 *						the "MW Hello World" project.  Then copy/paste the
 *						resulting dc.w lines into PrvFGetTenPowersPtr, above.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	 nothing
 *
 ***********************************************************************/
/*
#include <stdio.h>
void main(void)
{	
	double	tenPowers[200] = {
		1.0e-99, 1.0e-98, 1.0e-97, 1.0e-96, 1.0e-95, 1.0e-94, 1.0e-93, 1.0e-92, 1.0e-91, 1.0e-90,
		1.0e-89, 1.0e-88, 1.0e-87, 1.0e-86, 1.0e-85, 1.0e-84, 1.0e-83, 1.0e-82, 1.0e-81, 1.0e-80,
		1.0e-79, 1.0e-78, 1.0e-77, 1.0e-76, 1.0e-75, 1.0e-74, 1.0e-73, 1.0e-72, 1.0e-71, 1.0e-70,
		1.0e-69, 1.0e-68, 1.0e-67, 1.0e-66, 1.0e-65, 1.0e-64, 1.0e-63, 1.0e-62, 1.0e-61, 1.0e-60,
		1.0e-59, 1.0e-58, 1.0e-57, 1.0e-56, 1.0e-55, 1.0e-54, 1.0e-53, 1.0e-52, 1.0e-51, 1.0e-50,
		1.0e-49, 1.0e-48, 1.0e-47, 1.0e-46, 1.0e-45, 1.0e-44, 1.0e-43, 1.0e-42, 1.0e-41, 1.0e-40,
		1.0e-39, 1.0e-38, 1.0e-37, 1.0e-36, 1.0e-35, 1.0e-34, 1.0e-33, 1.0e-32, 1.0e-31, 1.0e-30,
		1.0e-29, 1.0e-28, 1.0e-27, 1.0e-26, 1.0e-25, 1.0e-24, 1.0e-23, 1.0e-22, 1.0e-21, 1.0e-20,
		1.0e-19, 1.0e-18, 1.0e-17, 1.0e-16, 1.0e-15, 1.0e-14, 1.0e-13, 1.0e-12, 1.0e-11, 1.0e-10,
		1.0e-9,  1.0e-8,  1.0e-7,  1.0e-6,  1.0e-5,  1.0e-4,  1.0e-3,  1.0e-2,  1.0e-1,  1.0e0,
		1.0e1,   1.0e2,   1.0e3,   1.0e4,   1.0e5,   1.0e6,   1.0e7,   1.0e8,   1.0e9,   1.0e10,
		1.0e11,  1.0e12,  1.0e13,  1.0e14,  1.0e15,  1.0e16,  1.0e17,  1.0e18,  1.0e19,  1.0e20,
		1.0e21,  1.0e22,  1.0e23,  1.0e24,  1.0e25,  1.0e26,  1.0e27,  1.0e28,  1.0e29,  1.0e30,
		1.0e31,  1.0e32,  1.0e33,  1.0e34,  1.0e35,  1.0e36,  1.0e37,  1.0e38,  1.0e39,  1.0e40,
		1.0e41,  1.0e42,  1.0e43,  1.0e44,  1.0e45,  1.0e46,  1.0e47,  1.0e48,  1.0e49,  1.0e50,
		1.0e51,  1.0e52,  1.0e53,  1.0e54,  1.0e55,  1.0e56,  1.0e57,  1.0e58,  1.0e59,  1.0e60,
		1.0e61,  1.0e62,  1.0e63,  1.0e64,  1.0e65,  1.0e66,  1.0e67,  1.0e68,  1.0e69,  1.0e70,
		1.0e71,  1.0e72,  1.0e73,  1.0e74,  1.0e75,  1.0e76,  1.0e77,  1.0e78,  1.0e79,  1.0e80,
		1.0e81,  1.0e82,  1.0e83,  1.0e84,  1.0e85,  1.0e86,  1.0e87,  1.0e88,  1.0e89,  1.0e90,
		1.0e91,  1.0e92,  1.0e93,  1.0e94,  1.0e95,  1.0e96,  1.0e97,  1.0e98,  1.0e99,  1.0e100,
//		0,0,0,0	// note that FlpGlobalsType used to include a double 'zero' after tenPowers
		};
	short i;
	short curExp = -99;
	unsigned short *shortPtr;

	printf("\t// Generated by Steve's nifty tenPowers expander, DoubleDump...\n");

	shortPtr = (unsigned short *) &tenPowers[0];
	for (i=0; i<(200/4); i++) {
		printf("\tdc.w 0x%.4X,0x%.4X,0x%.4X,0x%.4X", *shortPtr, *(shortPtr+1), *(shortPtr+2), *(shortPtr+3));
		shortPtr += 4;
		printf(",\t0x%.4X,0x%.4X,0x%.4X,0x%.4X", *shortPtr, *(shortPtr+1), *(shortPtr+2), *(shortPtr+3));
		shortPtr += 4;
		printf(",\t0x%.4X,0x%.4X,0x%.4X,0x%.4X", *shortPtr, *(shortPtr+1), *(shortPtr+2), *(shortPtr+3));
		shortPtr += 4;
		printf(",\t0x%.4X,0x%.4X,0x%.4X,0x%.4X", *shortPtr, *(shortPtr+1), *(shortPtr+2), *(shortPtr+3));
		shortPtr += 4;
		printf("\t// 1.0e%2d...1.0e%2d\n",curExp,curExp+3);
		curExp += 4;
	}
//	printf("\tdc.w 0x%.4X,0x%.4X,0x%.4X,0x%.4X", *shortPtr, *(shortPtr+1), *(shortPtr+2), *(shortPtr+3));
//	shortPtr += 4;
//	printf("\t// (double) 0\n");
}
*/