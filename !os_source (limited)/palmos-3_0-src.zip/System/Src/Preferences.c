/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Preferences.c
 * AUTHOR:	 Roger Flores: Feb 31, 1995
 *
 * DECLARER: System
 *
 * ROUTINES:
 *     
 *		
 * DESCRIPTION:
 *	  This file contains the system preference access routines.  There
 * are two preference files depending on whether the data should be
 * automatically backuped during a synch and get restored if missing or
 * if the data shouldn't be backupped because it either doesn't make
 * sense, or the application's conduit wants to backup the data itself.
 *
 **********************************************************************/

#include <SysAll.h>
#include <UICommon.h>
#include <Preferences.h>
#include <Chars.h>
#include <FeatureMgr.h>		// for FtrSet

#define NON_PORTABLE
#include <SystemPrv.h>

/***********************************************************************
 *
 * FUNCTION: 	 GetPreferenceDBName
 *
 * DESCRIPTION: Returns a pointer to the name the the preference database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	null-terminated name to the preference database.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *
 ***********************************************************************/
 
static asm CharPtr GetPreferenceDBName (void)
{

	lea	@dbName, a0
	rts
	
@dbName: dc.b	"Unsaved Preferences", 0	// distinct from Prefernce app
}


/***********************************************************************
 *
 * FUNCTION: 	 GetPreferenceDBName
 *
 * DESCRIPTION: Returns a pointer to the name the the preference database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	null-terminated name to the saved preference database.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/17/96	Initial Revision
 *
 ***********************************************************************/
 
static asm CharPtr GetSavedPreferenceDBName (void)
{

	lea	@dbName, a0
	rts
	
@dbName: dc.b	"Saved Preferences", 0
}


/***********************************************************************
 *
 * FUNCTION: 	 PrefOpenPreferenceDBV10
 *
 * DESCRIPTION: Returns a handle to the preference database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	handle or 0 on error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *       art   3/21/95  Initial Revision
 *
 ***********************************************************************/
 
extern DmOpenRef PrefOpenPreferenceDBV10 (void)
	{
	Err	err;
	LocalID	dbID;
	DmOpenRef	dbP;
	CharPtr dbName;

	dbName = GetPreferenceDBName ();
	dbID = DmFindDatabase (0, dbName);

	if (!dbID)
		{
		err = DmCreateDatabase (0, dbName, sysFileCSystem, 
			sysFileTSavedPreferences, dmHdrAttrResDB);
		if (err) return 0;
		dbID = DmFindDatabase(0, dbName);
		}

	dbP = DmOpenDatabase(0, dbID, dmModeReadWrite);

	return dbP;
	}


/***********************************************************************
 *
 * FUNCTION: 	 PrefOpenPreferenceDB
 *
 * DESCRIPTION: Returns a handle to the preference database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	handle or 0 on error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *       art   3/21/95  Initial Revision
 *       roger	6/17/96  Revised to handle saved and unsaved preferences
 *       roger	6/18/96  Revised to lookup by creator and type
 *
 ***********************************************************************/
 
extern DmOpenRef PrefOpenPreferenceDB (Boolean saved)
{
	Err err;
	DmOpenRef dbP;
	CharPtr dbName;
	ULong type;
	UInt cardNo;
	LocalID dbID;
	UInt attributes;
	

	type = saved ? sysFileTSavedPreferences : sysFileTPreferences;
	
	// Open the database.  Create it if it doesn't exist.
	dbP = DmOpenDatabaseByTypeCreator (type, sysFileCSystem, dmModeReadWrite);
	if (! dbP)
		{
		// Insure that the err was because the database doesn't exist as opposed
		// to it being already open for writing.
		err = DmGetLastErr();
		ErrFatalDisplayIf(err && err != dmErrCantFind, "Pref DB Open Error");
		
		if (saved)
			dbName = GetSavedPreferenceDBName ();
		else
			dbName = GetPreferenceDBName ();

		err = DmCreateDatabase (0, dbName, sysFileCSystem, type, dmHdrAttrResDB);
		if (err) return 0;
		
		dbP = DmOpenDatabaseByTypeCreator (type, sysFileCSystem, dmModeReadWrite);
		
		// Set the backup bit for the conduit to backup the saved database.
		if (saved)
			{
			DmOpenDatabaseInfo(dbP, &dbID, NULL, NULL, &cardNo, NULL);

			DmDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL, 
				NULL, NULL, NULL, NULL, NULL, NULL, NULL);
			attributes |= dmHdrAttrBackup;
			DmSetDatabaseInfo(cardNo, dbID, NULL, &attributes, NULL, NULL, 
				NULL, NULL, NULL, NULL, NULL, NULL, NULL);
			}
		}


	return dbP;
}


/***********************************************************************
 *
 * FUNCTION: 	 GetPreferenceResource
 *
 * DESCRIPTION: Returns a handle to the preference resource or 0 on error
 *
 * The goal is to quickly return the resource if it is the correct version.
 * If it's an older version, read it in and add data from each newer version
 * to it.  This preserves user's older preferences while updating to the newest
 * settings.  NOTE:  If the pref structure changes, THE VERSION SHOULD TOO!!
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	handle or 0 on error
 *					prefDB = dbP of open database if success
 *								else 0 (meaning the database has been closed)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *			scl	3/7/97	Added initialization of sysFtrNumCountry
 *			scl	6/16/97	Added initialization of sysFtrNumLanguage
 *			roger	8/13/97	Rearranged to update older preferences
 *			scl	1/22/98	No longer resize invalid prefs in debug build
 *			scl	1/22/98	Fixed overlocking bug if we found "newer" prefs
 *			scl	1/26/98	Fixed pref resizing code (when version is different)
 *
 ***********************************************************************/
 
static VoidHand GetPreferenceResource (DmOpenRef *prefDB, Boolean saved)
	{
	DmOpenRef					dbP;
	Handle						preferencesH;
	SystemPreferencesPtr 	preferencesP;
	SystemPreferencesType	preferences;
	Handle countryPreferencesH;
	CountryPreferencesType *countryPreferencesP;
	CountryType countrySelection;
	ULong							oldPrefSize, ourPrefSize;

// BUMMER - most callers of this routine don't bother checking for zero return values!
//	DOLATER - we should probably enable the following line for failed cases...
//	*prefDB = 0;

	dbP = PrefOpenPreferenceDB (saved);
	if (! dbP) return 0;
	
	preferencesH = (Handle) DmGetResource(sysResTSysPref, sysResIDSysPrefMain);
	if (preferencesH)
		{
		preferencesP = (SystemPreferencesPtr) MemHandleLock(preferencesH);
		
		// If the preferences are the correct version quickly return them.
		// They BETTER be the right size.  Change prefs?  Bump the version!!
		if (preferencesP->version == preferenceDataVersion)
			{
			// During development, let's flag if we find prefs that are the wrong size!
			#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				if (MemPtrSize(preferencesP) != sizeof(SystemPreferencesType))
					{
					ErrNonFatalDisplayIf(true, "System Prefs changed size but not version!");
					}
			#endif

			MemHandleUnlock(preferencesH);
			*prefDB = dbP;
			return preferencesH;
			}
		
		// Defend against NEWER or OLDER prefs running on our version of the OS:
		// We assume that prefs will only be added to the end.  It would be
		// bad for future prefs versions to change existing pref definitions.
		
		oldPrefSize = MemHandleSize(preferencesH);
		ourPrefSize = sizeof(SystemPreferencesType);
		
		// If the prefs are the wrong size, unlock, resize, and re-lock them.
		if (oldPrefSize != ourPrefSize)
			{
			MemHandleUnlock(preferencesH);
			if (MemHandleResize(preferencesH, ourPrefSize) != 0)
				{
				DmCloseDatabase(dbP);
				return 0;
				}
			preferencesP = (SystemPreferencesPtr) MemHandleLock(preferencesH);

			// Initialize our local copy of the preference data.
			MemSet(&preferences, ourPrefSize, 0);
			}

		// The (wrong version) prefs are now the correct size.

		// Read in the saved preferences.  We will add values to these.
		// If the old prefs were smaller, we only read in what was there.
		// If the old prefs were bigger, we only read in what we support.
		MemMove(&preferences, preferencesP, 
			(oldPrefSize < ourPrefSize) ? oldPrefSize : ourPrefSize);

		// Fall through to the pref-tweaking code below.

		}
	else
		{
		// Create a preference resource.
		preferencesH = (Handle) DmNewResource(dbP, sysResTSysPref, sysResIDSysPrefMain, 
			sizeof (SystemPreferencesType));
		
		// Return an error if we couldn't make the resource.
		if (!preferencesH)
			{
			DmCloseDatabase(dbP);
			return 0;
			}

		preferencesP = (SystemPreferencesPtr) MemHandleLock(preferencesH);
		
		// Initialize our local copy of the preference data.
		// The settings will get filled in below.
		MemSet(&preferences, sizeof(preferences), 0);
		}
		
	
	// Version 1 and version 2 preferences are written together because they 
	// were intermixed.
	if (preferences.version < 2)
		{
		preferences.version = 2;
		preferences.autoOffDuration = defaultAutoOffDuration;
		preferences.sysSoundLevelV20 = defaultSysSoundLevel;
		preferences.gameSoundLevelV20 = defaultGameSoundLevel;
		preferences.alarmSoundLevelV20 = defaultAlarmSoundLevel;
		preferences.hideSecretRecords = false;
		preferences.deviceLocked = false;
		preferences.localSyncRequiresPassword = false;
		preferences.remoteSyncRequiresPassword = false;
		preferences.animationLevel = alEventsOnly;
		preferences.sysPrefFlags = 0;
		
		// ButtonPanel.c must match these for when the user resets to defaults.
		preferences.ronamaticChar = graffitiReferenceChr;		// popup keyboard in default mode
		preferences.hard1CharAppCreator = sysFileCDatebook;	// default app
		preferences.hard2CharAppCreator = sysFileCAddress;		// default app
		preferences.hard3CharAppCreator = sysFileCToDo;			// default app
		preferences.hard4CharAppCreator = sysFileCMemo;			// default app
		preferences.calcCharAppCreator = sysFileCCalculator;	// default app
		preferences.hardCradleCharAppCreator = sysFileCSync;	// default app
		preferences.hardCradle2CharAppCreator = sysFileCSync;	// default app
		preferences.launcherCharAppCreator = sysFileCLauncher;// default app


#if COUNTRY == COUNTRY_FRANCE
		preferences.country = cFrance;
		
#elif COUNTRY == COUNTRY_GERMANY
		preferences.country = cGermany;

#elif COUNTRY == COUNTRY_ITALY
		preferences.country = cItaly;

#elif COUNTRY == COUNTRY_SPAIN
		preferences.country = cSpain;
		
#else	// COUNTRY_UNITED_STATES
		preferences.country = cUnitedStates;

#endif

		// In 2.0, we didn't set sysFtrNumCountry for COUNTRY_UNITED_STATES.
		// Starting with 3.0, we set sysFtrNumCountry for all builds.
		FtrSet(sysFtrCreator, sysFtrNumCountry, preferences.country);

		// In 2.0, we only set sysFtrNumLanguage for LANGUAGE_WORKPAD.
		// Starting with 3.0, we set sysFtrNumLanguage for all builds.
		FtrSet(sysFtrCreator, sysFtrNumLanguage, LANGUAGE);

		// Set the country preferences based on the country compiled in above.
		countryPreferencesH = (Handle) DmGetResource (sysResTCountries, sysResIDCountries);
		countryPreferencesP = MemHandleLock(countryPreferencesH);
		
		countrySelection = preferences.country;
		preferences.dateFormat = countryPreferencesP[countrySelection].dateFormat;
		preferences.longDateFormat = countryPreferencesP[countrySelection].longDateFormat;
		preferences.weekStartDay = countryPreferencesP[countrySelection].weekStartDay;
		preferences.timeFormat = countryPreferencesP[countrySelection].timeFormat;
		preferences.numberFormat = countryPreferencesP[countrySelection].numberFormat;
		preferences.daylightSavings = countryPreferencesP[countrySelection].daylightSavings;
		preferences.minutesWestOfGMT = countryPreferencesP[countrySelection].minutesWestOfGMT;
		
		MemPtrUnlock(countryPreferencesP);
		DmReleaseResource (countryPreferencesH);
		}
	
	
	if (preferences.version < 3)
		{
		preferences.version = 3;
		preferences.sysSoundVolume = defaultSysSoundVolume;
		preferences.gameSoundVolume = defaultGameSoundVolume;
		preferences.alarmSoundVolume = defaultAlarmSoundVolume;
		preferences.beamReceive = true;
// <SCL 1/26/98> Always force digitizer pref to false.  This disables the digitizer
//						panel on soft reset since nobody seemed to like it...
//						For the record, I STILL think we should force it.  Bummer.
		preferences.calibrateDigitizerAtReset = false;
		
		// Upgrade some of the older data
		if (preferences.launcherCharAppCreator == sysFileCNullApp)
			preferences.launcherCharAppCreator = sysFileCLauncher;
		}
	
	
	if (preferences.version < 4)
		{
		preferences.version = 4;
		preferences.systemKeyboardID = SystemKeyboardID;
		preferences.defSerialPlugIn = sysFileCUart328;
		}
	
	
	
	// Add new versions of preferences here
/*	if (preferences.version < 5)
		{
		preferences.version = 5;
		}
*/	
	

	
	// Are the saved preferences a NEWER version?
	if (preferences.version > preferenceDataVersion)
		{
		// Downgrade the pref version to OUR version.
		preferences.version = preferenceDataVersion;
		}

	// Now that the preferences are set (and locked) write to the resource
	DmWrite(preferencesP, 0, &preferences, sizeof(preferences));

	MemHandleUnlock(preferencesH);
	*prefDB = dbP;
	return preferencesH;
	}


	
/***********************************************************************
 *
 * FUNCTION: 	 PrefGetPreferences
 *
 * DESCRIPTION: Return a copy of the system preferences
 *
 * THIS IS AN OUTDATED FUNCTION CALL.  USE PrefGetPreference INSTEAD.
 *
 * PARAMETERS:  system preferences
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *
 ***********************************************************************/
 
void PrefGetPreferences(SystemPreferencesPtr p)
	{
	VoidHand prefResource;
	DmOpenRef	prefDB;
	
	prefResource = GetPreferenceResource(&prefDB, true);
	MemMove(p, MemHandleLock(prefResource), sizeof (SystemPreferencesTypeV10));
	MemHandleUnlock(prefResource);
	DmReleaseResource(prefResource);
	DmCloseDatabase(prefDB);
	}
	
	
/***********************************************************************
 *
 * FUNCTION: 	 PrefSetPreferences
 *
 * DESCRIPTION: Set the system preferences
 *
 * THIS IS AN OUTDATED FUNCTION CALL.  USE PrefSetPreference INSTEAD.
 *
 * PARAMETERS:  system preferences
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *
 ***********************************************************************/
 
void PrefSetPreferences(SystemPreferencesPtr p)
	{
	VoidHand		 	prefResourceH;
	DmOpenRef		prefDB;
	VoidPtr			prefResourceP;
	
	prefResourceH = GetPreferenceResource(&prefDB, true);
	
	prefResourceP = MemHandleLock(prefResourceH);
	DmWrite(prefResourceP, 0, p, sizeof(SystemPreferencesTypeV10));
	MemPtrUnlock(prefResourceP);

	DmReleaseResource(prefResourceH);
	DmCloseDatabase(prefDB);
	}



/***********************************************************************
 *
 * FUNCTION: 	 PrefGetPreference
 *
 * DESCRIPTION: Return a system preference.
 *
 * PARAMETERS:  system preference choice
 *
 * RETURNED:	 the system preference
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *			roger	5/7/95	Rewrote to return a single preference
 *
 ***********************************************************************/
 
DWord PrefGetPreference(SystemPreferencesChoice choice)
	{
	VoidHand prefResource;
	DmOpenRef	prefDB;
	SystemPreferencesPtr prefP;
	DWord result;
	
	
	prefResource = GetPreferenceResource(&prefDB, true);
	prefP = MemHandleLock(prefResource);
	
	// Now get the choice
	switch (choice)
		{
		case prefVersion:
			result = prefP->version;
			break;
			
		case prefCountry:
			result = prefP->country;
			break;
			
		case prefDateFormat:
			result = prefP->dateFormat;
			break;
			
		case prefLongDateFormat:
			result = prefP->longDateFormat;
			break;
			
		case prefWeekStartDay:
			result = prefP->weekStartDay;
			break;
			
		case prefTimeFormat:
			result = prefP->timeFormat;
			break;
			
		case prefNumberFormat:
			result = prefP->numberFormat;
			break;
			
		case prefAutoOffDuration:
			result = prefP->autoOffDuration;
			break;
			
		case prefSysSoundLevelV20:
			if (prefP->sysSoundVolume > 0)
				result = slOn;
			else
				result = slOff;
			break;
			
		case prefGameSoundLevelV20:
			if (prefP->gameSoundVolume > 0)
				result = slOn;
			else
				result = slOff;
			break;
			
		case prefAlarmSoundLevelV20:
			if (prefP->alarmSoundVolume > 0)
				result = slOn;
			else
				result = slOff;
			break;
			
		case prefHidePrivateRecords:
			result = prefP->hideSecretRecords;
			break;
			
		case prefDeviceLocked:
			result = prefP->deviceLocked;
			break;
			
		case prefLocalSyncRequiresPassword:
			result = prefP->localSyncRequiresPassword;
			break;
			
		case prefRemoteSyncRequiresPassword:
			result = prefP->remoteSyncRequiresPassword;
			break;
			
		case prefSysBatteryKind:
			result = prefP->sysBatteryKind;
			break;
			
		case prefAllowEasterEggs:
			result = prefP->sysPrefFlags & sysPrefFlagEnableEasterEggs;
			break;
			
		case prefMinutesWestOfGMT:
			result = prefP->minutesWestOfGMT;
			break;
			
		case prefDaylightSavings:
			result = prefP->daylightSavings;
			break;
			
		case prefAnimationLevel:
			result = prefP->animationLevel;
			break;
			
		case prefRonamaticChar:
			result = prefP->ronamaticChar;
			break;
			
		case prefHard1CharAppCreator:
			result = prefP->hard1CharAppCreator;
			break;
			
		case prefHard2CharAppCreator:
			result = prefP->hard2CharAppCreator;
			break;
			
		case prefHard3CharAppCreator:
			result = prefP->hard3CharAppCreator;
			break;
			
		case prefHard4CharAppCreator:
			result = prefP->hard4CharAppCreator;
			break;
			
		case prefCalcCharAppCreator:
			result = prefP->calcCharAppCreator;
			break;
			
		case prefHardCradleCharAppCreator:
			result = prefP->hardCradleCharAppCreator;
			break;
			
		case prefHardCradle2CharAppCreator:
			result = prefP->hardCradle2CharAppCreator;
			break;
			
		case prefLauncherAppCreator:
			result = prefP->launcherCharAppCreator;
			break;
			
		case prefSysPrefFlags:
			result = prefP->sysPrefFlags;
			break;
			
		case prefSysSoundVolume:
			result = prefP->sysSoundVolume;
			break;
			
		case prefGameSoundVolume:
			result = prefP->gameSoundVolume;
			break;
			
		case prefAlarmSoundVolume:
			result = prefP->alarmSoundVolume;
			break;
			
		case prefBeamReceive:
			result = prefP->beamReceive;
			break;
			
		case prefCalibrateDigitizerAtReset:
			result = prefP->calibrateDigitizerAtReset;
			break;
			
		case prefSystemKeyboardID:
			result = prefP->systemKeyboardID;
			break;
			
		case prefDefSerialPlugIn:
			result = prefP->defSerialPlugIn;
			break;
			
		default:
  			ErrNonFatalDisplayIf(true, "Getting unknown system preference");
			result = 0;
			break;
		}
			
	MemHandleUnlock(prefResource);
	DmReleaseResource(prefResource);
	DmCloseDatabase(prefDB);
	
	return result;
}
	
	
/***********************************************************************
 *
 * FUNCTION: 	 PrefSetPreference
 *
 * DESCRIPTION: Set a system preference
 *
 * PARAMETERS:  system preferences
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *			roger	5/7/95	Rewrote to set a single preference
 *			tlw	2/11/98	Save sound setting(s) into V20 equivalents, too.
 *
 ***********************************************************************/
 
void PrefSetPreference(SystemPreferencesChoice choice, DWord value)
	{
	VoidHand		 	prefResourceH;
	DmOpenRef		prefDB;
	VoidPtr			prefResourceP;
	SystemPreferencesType pref;
	
	
	prefResourceH = GetPreferenceResource(&prefDB, true);
	
	prefResourceP = MemHandleLock(prefResourceH);
	MemMove(&pref, prefResourceP, sizeof (SystemPreferencesType));
	
	// Now get the choice
	switch (choice)
		{
		case prefVersion:
			pref.version = value;
			break;
			
		case prefCountry:
			pref.country = (CountryType) value;
			break;
			
		case prefDateFormat:
			pref.dateFormat = (DateFormatType) value;
			break;
			
		case prefLongDateFormat:
			pref.longDateFormat = (DateFormatType) value;
			break;
			
		case prefWeekStartDay:
			pref.weekStartDay = value;
			break;
			
		case prefTimeFormat:
			pref.timeFormat = (TimeFormatType) value;
			break;
			
		case prefNumberFormat:
			pref.numberFormat = (NumberFormatType) value;
			break;
			
		case prefAutoOffDuration:
			pref.autoOffDuration = value;
			break;
			
		case prefSysSoundLevelV20:
			if ((SoundLevelTypeV20) value == slOn)
				pref.sysSoundVolume = sndMaxAmp;
			else
				pref.sysSoundVolume = 0;
			break;
			
		case prefGameSoundLevelV20:
			if ((SoundLevelTypeV20) value == slOn)
				pref.gameSoundVolume = sndMaxAmp;
			else
				pref.gameSoundVolume = 0;
			break;
			
		case prefAlarmSoundLevelV20:
			if ((SoundLevelTypeV20) value == slOn)
				pref.alarmSoundVolume = sndMaxAmp;
			else
				pref.alarmSoundVolume = 0;
			break;
			
		case prefHidePrivateRecords:
			pref.hideSecretRecords = value;
			break;
			
		case prefDeviceLocked:
			pref.deviceLocked = value;
			break;
			
		case prefSysBatteryKind:
			pref.sysBatteryKind = (SysBatteryKind) value;
			break;
			
		case prefAllowEasterEggs:
			pref.sysPrefFlags &= ~sysPrefFlagEnableEasterEggs;
			if (value)
				pref.sysPrefFlags |= sysPrefFlagEnableEasterEggs;
			GSysPrefFlags = pref.sysPrefFlags;
			break;
			
		case prefMinutesWestOfGMT:
			pref.minutesWestOfGMT = value;
			break;
			
		case prefDaylightSavings:
			pref.daylightSavings = (DaylightSavingsTypes) value;
			break;
			
		case prefAnimationLevel:
			pref.animationLevel = (AnimationLevelType) value;
			break;
			
		case prefRonamaticChar:
			pref.ronamaticChar = value;
			break;
			
		case prefHard1CharAppCreator:
			pref.hard1CharAppCreator = value;
			break;
			
		case prefHard2CharAppCreator:
			pref.hard2CharAppCreator = value;
			break;
			
		case prefHard3CharAppCreator:
			pref.hard3CharAppCreator = value;
			break;
			
		case prefHard4CharAppCreator:
			pref.hard4CharAppCreator = value;
			break;
			
		case prefCalcCharAppCreator:
			pref.calcCharAppCreator = value;
			break;
			
		case prefHardCradleCharAppCreator:
			pref.hardCradleCharAppCreator = value;
			break;
			
		case prefHardCradle2CharAppCreator:
			pref.hardCradle2CharAppCreator = value;
			break;
			
		case prefLauncherAppCreator:
			pref.launcherCharAppCreator = value;
			break;
			
		case prefSysSoundVolume:
			pref.sysSoundVolume = value;
			pref.sysSoundLevelV20 = value ? slOn : slOff;
			break;
			
		case prefGameSoundVolume:
			pref.gameSoundVolume = value;
			pref.gameSoundLevelV20 = value ? slOn : slOff;
			break;
			
		case prefAlarmSoundVolume:
			pref.alarmSoundVolume = value;
			pref.alarmSoundLevelV20 = value ? slOn : slOff;
			break;
			
		case prefBeamReceive:
			pref.beamReceive = value;
			break;
			
		case prefCalibrateDigitizerAtReset:
			pref.calibrateDigitizerAtReset = value;
			break;
			
		case prefSystemKeyboardID:
			pref.systemKeyboardID = value;
			break;
			
		case prefDefSerialPlugIn:
			pref.defSerialPlugIn = value;
			break;
			
		default:
  			ErrNonFatalDisplayIf(true, "Setting unknown system preference");
			break;
		}
			

	DmWrite(prefResourceP, 0, &pref, sizeof(SystemPreferencesType));
	MemPtrUnlock(prefResourceP);

	DmReleaseResource(prefResourceH);
	DmCloseDatabase(prefDB);
	}



/***********************************************************************
 *
 * FUNCTION: 	 PrefGetAppPreferencesV10
 *
 * DESCRIPTION: Return a copy of an application's preferences
 *
 * PARAMETERS:  type        - application creator type
 *              version     - version number of the application
 *              prefs       - pointer to a buffer to hold preferences
 *              prefsSize   - size the the buffer passed
 *
 * RETURNED:	false if the preference resource was not found or the 
 *             preference resource contains the wrong version number.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *
 ***********************************************************************/
 
Boolean PrefGetAppPreferencesV10 (DWord type, SWord version, VoidPtr prefs,
	Word prefsSize)
{
	Boolean found = false;
	DmOpenRef	dbP;
	Handle	resourceH;
	Ptr resourceP;	

	dbP = PrefOpenPreferenceDB (true);
	if (! dbP) return false;
	
	resourceH = (Handle) DmGetResource (type, 0);
	if (resourceH)
		{
		// Check that the version numbers match.
		resourceP = MemHandleLock(resourceH);
		if (*((IntPtr)resourceP) == version)
			{
			if (MemPtrSize (resourceP) == prefsSize + sizeof (Int))
				{
				resourceP += sizeof (Int);			// skip the version number
				MemMove (prefs, resourceP, prefsSize);
				found = true;
				}
			}
		MemHandleUnlock(resourceH);
		DmReleaseResource (resourceH);
		}

	DmCloseDatabase (dbP);
	return found;
}


/***********************************************************************
 *
 * FUNCTION: 	 PrefSetAppPreferencesV10
 *
 * DESCRIPTION: Save an application's preferences in the preferences 
 *              database.
 *
 * PARAMETERS:  creator     - application creator type
 *              version     - version number of the application
 *              prefs       - pointer to a buffer that holds preferences
 *              prefsSize   - size the the buffer passed
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *
 ***********************************************************************/
void PrefSetAppPreferencesV10 (DWord creator, SWord version, VoidPtr prefs,
	Word prefsSize)
{
	PrefSetAppPreferences (creator, 0, version, prefs, prefsSize, true);
}


/***********************************************************************
 *
 * FUNCTION: 	 PrefGetAppPreferences
 *
 * DESCRIPTION: Return a copy of an application's preferences.
 *
 * Sometimes, for variable length resources, this routine is called twice.
 * Once with a NULL pointer and size of zero to find out how many bytes 
 * need to be read, and then a second time with a buffer allocated with
 * the correct size.
 *
 * PARAMETERS:  creator     - application creator type
 *              prefs       - pointer to a buffer to hold preferences
 *              prefsSize   - pointer to size the the buffer passed
 *
 * RETURNED:	noPreferenceFound if the preference resource was not found or  
 *             the version number if found
 *
 *					prefsSize is set to the size of the preference found.  If it 
 *					greater than the size passed then some bytes were not retrieved. 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *			roger	5/17/96	Rewrote to return any version of app preferences saved.
 *
 ***********************************************************************/
 
SWord PrefGetAppPreferences (DWord creator, Word id, VoidPtr prefs, 
	Word *prefsSize, Boolean saved)
{
	DmOpenRef	dbP;
	Handle	resourceH;
	Ptr resourceP;
	SWord version = noPreferenceFound;
	Word prefsSizeToCopy;
	Word resourceSize;
	

	dbP = PrefOpenPreferenceDB (saved);
	if (! dbP) return version;
	
	resourceH = (Handle) DmGetResource (creator, id);
	if (resourceH)
		{
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		// Fill up the buffer as much as allowed with a value to reveal errors.
		// Only do this if there are bytes to set.  Otherwise this routine fails
		// when called to find the resource's size.
		if (*prefsSize > 0)
			{
			MemSet(prefs, *prefsSize, 0xfe);	
			}
#endif

		// Check that the version numbers match.
		resourceP = MemHandleLock(resourceH);
		
		// Get the version number.
		version = *((IntPtr)resourceP);
		
		
		// Copy the preference resource into the buffer provided.  Do not copy
		// more bytes than the size of the resource or than will fit in the buffer.
		resourceSize = MemPtrSize (resourceP) - sizeof (Int);
		prefsSizeToCopy = min(*prefsSize, resourceSize);
		resourceP += sizeof (Int);			// skip the version number
		if (prefsSizeToCopy > 0)
			{
			MemMove (prefs, resourceP, prefsSizeToCopy);
			}
		
		*prefsSize = resourceSize;

		MemHandleUnlock(resourceH);
		DmReleaseResource (resourceH);
		}

	DmCloseDatabase (dbP);
	return version;
}


/***********************************************************************
 *
 * FUNCTION: 	 PrefSetAppPreferences
 *
 * DESCRIPTION: Save an application's preferences in the preferences 
 *              database.
 *
 * PARAMETERS:  creator     - application creator type
 *              id			 - resource id (usually 0)
 *              version     - version number of the application
 *              prefs       - pointer to a buffer that holds preferences
 *              prefsSize   - size the the buffer passed
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *			roger	5/17/96	Added a resource id so apps may store multiple resources.
 *
 ***********************************************************************/
void PrefSetAppPreferences (DWord creator, Word id, SWord version, 
	VoidPtr prefs, Word prefsSize, Boolean saved)
{
	DmOpenRef	dbP;
	Handle 		resourceH;
	Ptr			resourceP;
	ULong 		resourceSize;
	Int			resourceIndex;
	

	dbP = PrefOpenPreferenceDB (saved);
	if (! dbP) return;
	
	// The user might want to delete the resource.  Do this if they pass
	// no data as indicated by zero bytes or a NULL pointer.
	if (prefsSize == 0 ||
		prefs == NULL)
		{
		resourceIndex = DmFindResource(dbP, creator, id, 0);
		// Remove the resource if it exists.
		if (resourceIndex != -1)
			DmRemoveResource(dbP, resourceIndex);
		
		DmCloseDatabase(dbP);
		return;
		}

	resourceSize = prefsSize + sizeof (Int);	// Make room for version number

	resourceH = (Handle) DmGetResource (creator, id);
	if (resourceH)
		{
		// Make sure the resource is the right size.
		resourceH = DmResizeResource (resourceH, resourceSize);
		}
	else
		{
		// Create a new resouce.
		resourceH = (Handle) DmNewResource (dbP, creator, id, resourceSize);
		}

	if (! resourceH)
		{
		DmCloseDatabase(dbP);
		return;
		}

	// Store the application's version at the beginning the the 
	// preference resource.
	resourceP = MemHandleLock(resourceH);
	DmWrite(resourceP, 0, &version, sizeof(version));

	// Copy the preference to the resource.
	DmWrite(resourceP, sizeof(Int), prefs, prefsSize);

	MemPtrUnlock(resourceP);
	DmReleaseResource (resourceH);
	DmCloseDatabase (dbP);
}


