/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		MacStubs.c
 *
 * Description:
 *		stubs for use when running on top of the Macintosh OS. The routines
 *		in this module are used by some Pilot Managers when they must
 *		emulation on top of the Mac or PC OS. 
 *
 *		By using the routines in this module, none of the Pilot modules
 *		have to include Mac or PC header files. That is because all of
 *		the Stub routines are declared using generic C types.
 *
 * History:
 *   	10/25/94  RM	- Created by Ron Marianetti
 *		8/18/97	vmk	- turned off 8-byte doubles for this module
 *
 *******************************************************************/
//****IMPORTANT****
//
// We disable IEEEdoubles (8-byte doubles) in this module because some routines
// in this module use the Macintosh standard 10-byte doubles.  Documentation advises
// to place this pragma at the beginning of the module before any header file inclusion.
// Since the intention of this file is to contain Macintosh-only code, this pragma should
// not cause any conflict.  This setting is reset at the end of the module with
// "#pragma IEEEdoubles off".  vmk 8/18/97
#pragma IEEEdoubles off

//#include <MacHeaders68K>

#include <Types.h>
#include <Sound.h>			// Mac sound defines
#include <Strings.h>
#include <Events.h>
#include <OSUtils.h>
#include <Resources.h>
#include <Math.h>
#include <Quickdraw.h>

#include <string.h>

#include <stdio.h>
#include <Gestalt.h>

#include <EmuStubs.h>


/************************************************************
 *
 *  Internal routines used only by this module
 *
 *************************************************************/
static short PrvIsPressed(unsigned short k );


/************************************************************
 *
 *  Globals used only under Emulation Mode
 *
 *************************************************************/
char*				PilotGlobalsP=0;					// pointer to Memory Card 0 where is where
														// Globals are stored
static long		DateTimeDifference;			// date/time difference between the Mac
														// and the emulator environments (in seconds)

static SndChannelPtr GMacSndChanP	 = NULL;	// pointer to current Macintosh sound channel

/************************************************************
 *
 *  FUNCTION: StubDbgSrcBreak
 *
 *  DESCRIPTION: Break into Source Level Debugger
 *
 *  PARAMETERS: void
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void StubDbgSrcBreak(void)
{
	long response;
	

	Gestalt(gestaltSysArchitecture, &response);
	if (response == gestalt68k)
		{
		SysBreak();					// Print message to Debugger
		}
	else
		{
		Debugger();					// Print message to Debugger
		}
}



/************************************************************
 *
 *  FUNCTION: StubDbgSrcMessage
 *
 *  DESCRIPTION: Display a Message to the source level debugger
 *
 *  PARAMETERS: C string
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void StubDbgSrcMessage(char* cstring)
{
	char	text[256];
	long response;
	
	strcpy(text, cstring);
	c2pstr(text);


	Gestalt(gestaltSysArchitecture, &response);
	if (response == gestalt68k)
		{
		SysBreakStr((ConstStr255Param)(text));					// Print message to Debugger
		}
	else
		{
		DebugStr((ConstStr255Param)(text));					// Print message to Debugger
		}
}



/************************************************************
 *
 *  FUNCTION: StubDbgBreak
 *
 *  DESCRIPTION: Break into Assembly level  Debugger
 *
 *  PARAMETERS: void
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void StubDbgBreak(void)
{
	long response;
	

	Gestalt(gestaltSysArchitecture, &response);
	if (response == gestalt68k)
		{
		Debugger();					// Print message to Debugger
		}
	else
		{
		SysBreak();					// Print message to Debugger
		}
}



/************************************************************
 *
 *  FUNCTION: StubDbgMessage
 *
 *  DESCRIPTION: Display a Message to the Assembly level debugger
 *
 *  PARAMETERS: C string
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void StubDbgMessage(char* cstring)
{
	char	text[256];
	long response;
	
	strcpy(text, cstring);
	c2pstr(text);


	Gestalt(gestaltSysArchitecture, &response);
	if (response == gestalt68k)
		{
		DebugStr((ConstStr255Param)(text));					// Print message to Debugger
		}
	else
		{
		SysBreakStr((ConstStr255Param)(text));					// Print message to Debugger
		}
}



/************************************************************
 *
 *  FUNCTION: StubConPutS
 *
 *  DESCRIPTION: Display string to the "console"
 *
 *  PARAMETERS: C string
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
int StubConPutS(char* cstring)
{
	puts(cstring);
	return 0;
}


/************************************************************
 *
 *  FUNCTION: StubConGetS
 *
 *  DESCRIPTION: Gets a string from the console
 *
 *  PARAMETERS: C string
 *
 *  RETURNS: void
 *
 *  CREATED: 1/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
int StubConGetS(char* cstring)
{
	gets(cstring);
	return 0;
}


/************************************************************
 *
 *  FUNCTION:		StubFlushEvents
 *
 *  DESCRIPTION:	Flushes the Mac's event queue
 *
 *  PARAMETERS:	nothing
 *
 *  RETURNS:		nothing
 *
 *  CREATED:		9/15/95
 *
 *  BY: Christopher Raff
 *
 *************************************************************/
void StubFlushEvents(void)
{
	FlushEvents (everyEvent, 0);
}


/************************************************************
 *
 *  FUNCTION: StubTimGetTicks
 *
 *  DESCRIPTION: Returns TickCount on the Mac
 *
 *  PARAMETERS: void
 *
 *  RETURNS: long tickcount
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
unsigned long StubTimGetTicks(void)
{
	return TickCount();
}


/************************************************************
 *
 *  FUNCTION: StubTimGetSeconds
 *
 *  DESCRIPTION: Returns Seconds on the Mac
 *
 *  PARAMETERS: void
 *
 *  RETURNS: long seconds
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/13/95	Added "time difference" logic
 *************************************************************/
unsigned long StubTimGetSeconds(void)
{
	unsigned long	macSeconds;

	GetDateTime(&macSeconds);
	return (macSeconds + DateTimeDifference);
}


/************************************************************
 *
 *  FUNCTION: StubTimSetSeconds
 *
 *  DESCRIPTION: Sets Seconds on the Mac
 *
 *  PARAMETERS: void
 *
 *  RETURNS: long seconds
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/13/95	Added "time difference" logic
 *************************************************************/
void StubTimSetSeconds(unsigned long seconds)
{
	unsigned long	macSeconds;

	//SetDateTime(seconds);

	GetDateTime(&macSeconds);
	DateTimeDifference = seconds - macSeconds;
}



/************************************************************
 *
 *  FUNCTION: StubInitCTable
 *
 *  DESCRIPTION: Initializes a Macintosh Color Table structure to
 *		match the default Pilot color table. 
 *
 *  PARAMETERS: depth - bits/pixel
 *
 *  RETURNS: void
 *
 *  CREATED: 12/31/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void StubInitCTable(void* cTableParamP, unsigned int depth)
{
	CTabPtr	cTableP = (CTabPtr)cTableParamP;
	
	cTableP->ctSeed = GetCTSeed();
	
	switch (depth) {
		case 1:
			cTableP->ctSize = 0;
			cTableP->ctTable[0].value = 0;
			cTableP->ctTable[0].rgb.red = 0xFFFF;
			cTableP->ctTable[0].rgb.green = 0xFFFF;
			cTableP->ctTable[0].rgb.blue = 0xFFFF;
			cTableP->ctTable[1].value = 1;
			cTableP->ctTable[1].rgb.red = 0;
			cTableP->ctTable[1].rgb.green = 0;
			cTableP->ctTable[1].rgb.blue = 0;
			break;
			
		case 2:
			cTableP->ctSize = 3;
			cTableP->ctTable[0].value = 0;
			cTableP->ctTable[0].rgb.red = 0xFFFF;
			cTableP->ctTable[0].rgb.green = 0xFFFF;
			cTableP->ctTable[0].rgb.blue = 0xFFFF;
			cTableP->ctTable[1].value = 1;
			cTableP->ctTable[1].rgb.red = 0xAAAA;
			cTableP->ctTable[1].rgb.green = 0xAAAA;
			cTableP->ctTable[1].rgb.blue = 0xAAAA;
			cTableP->ctTable[2].value = 2;
			cTableP->ctTable[2].rgb.red = 0x5555;
			cTableP->ctTable[2].rgb.green = 0x5555;
			cTableP->ctTable[2].rgb.blue = 0x5555;
			cTableP->ctTable[3].value = 3;
			cTableP->ctTable[3].rgb.red = 0;
			cTableP->ctTable[3].rgb.green = 0;
			cTableP->ctTable[3].rgb.blue = 0;
			break;
			
		default:
			StubDbgSrcMessage("Unsupported depth");
			break;
		}
}

/************************************************************
 *
 *  FUNCTION: StubErrDisplayFileLineMsg
 *
 *  DESCRIPTION: Displays a non-exitable dialog with an error message
 *		Does not allow user to continue
 *
 *  PARAMETERS: filename, line number, message
 *
 *  RETURNS: never returns
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/ 
void StubErrDisplayFileLineMsg(const char * const filename, unsigned int lineNo, 
	const char * const msg)
{
	char	text[1024];
	
	
	sprintf(text, "File: %s, Line: %d, %s", filename, lineNo, msg);
	
	StubDbgSrcMessage(text);
}






/************************************************************
 *
 *  Sound Manager stubs
 *
 *************************************************************/

static SndChannelPtr PrvMakeSoundChannel(void)
{
	OSErr			osErr;
	SndChannelPtr	chanP = NULL;
	
	if ( GMacSndChanP )
		return GMacSndChanP;
	
	osErr = SndNewChannel( &chanP, squareWaveSynth, 0, nil );
	if ( osErr )
		return( NULL );
	
	GMacSndChanP = chanP;
	
	return chanP;
}

static void PrvFreeSoundChannel(void)
{
	OSErr			osErr;
	
	// Free the sound channel
	if ( GMacSndChanP )
		osErr = SndDisposeChannel( GMacSndChanP, false /*quietNow*/ );
	
	GMacSndChanP = NULL;
	
	return;
}

/************************************************************
 *
 *  FUNCTION: StubSndCommand
 *
 *  DESCRIPTION: Sends a Sound Manager command to the sound channel.
 *
 *  PARAMETERS:
 *		channelP		-- sound channel pointer, or nil for the shared channel;
 *		defAmp			-- default sound manager amplitude(0-64)
 *		cmd				-- sound command: one of stubSndCmd... constants;
 *		param1			-- command parameter #1;
 *		param2			-- command parameter #2;
 *		param3			-- command parameter #3;
 *		noWait			-- 0 = await completion, !0 = immediate return;
 *
 *  RETURNS: 0 if successful; otherwise: stubSndErrBadParam,
 *			stubSndErrBadChannel;
 *
 *  CREATED: 4/13/95
 *
 *  BY: Vitaly Kruglikov
 *
 *************************************************************/
#define prvTwelfthRootOfTwo		1.059463094

#define prvFrqToMidiKey(frq)	\
	((long)(log10(frq) / log10(prvTwelfthRootOfTwo) - 36.37))

short StubSndCommand(void* channelP, unsigned short defAmp,
		unsigned short cmd, unsigned long param1, unsigned short param2,
		unsigned short param3, char noWait)
{
	short			err = 0;
	SndCommand	sndCmd;
	OSErr			osErr;
	short			wKeyIndex;


	switch( cmd )
		{
		case stubSndCmdFreqDurationAmp:
			// Create the sound channel
			PrvMakeSoundChannel();
			if ( !GMacSndChanP )
				return( stubSndErrBadChannel );
					
			// Set the channel volume
			sndCmd.cmd = ampCmd;
			sndCmd.param1 = (short)((255 * param3 / 64) & 0x0ff);	// 0 - 255
			sndCmd.param2 = 0;
			osErr = SndDoCommand( GMacSndChanP, &sndCmd, false/*noWait*/ );
			
			// Play the sound			
			sndCmd.cmd = freqDurationCmd;
			// Set duration: 0 - 32,767 1/2 msec)
			sndCmd.param1 = (short)((param2 * 2) & 0x03fff);
			// Convert the frequency in Hz to the Mac's sound index.
			// (some woodoo going on here)
			sndCmd.param2 = prvFrqToMidiKey(param1);				// MIDI key # 0-127 units
			osErr = SndDoCommand( GMacSndChanP, &sndCmd, false/*noWait*/ );
			
			// Free the sound channel
			PrvFreeSoundChannel();
			break;

		case stubSndCmdMakeGlobalChannel:
			// Create the global sound channel
			PrvMakeSoundChannel();
			if ( !GMacSndChanP )
				err = ( stubSndErrBadChannel );
			break;
					
			
		case stubSndCmdFreeGlobalChannel:
			// Free the global sound channel
			PrvFreeSoundChannel();
			break;

		case stubSndCmdNoteOn:
		case stubSndCmdFrqOn:
			PrvMakeSoundChannel();
			if ( !GMacSndChanP )
				err = ( stubSndErrBadChannel );
			else
				{
				if ( cmd == stubSndCmdNoteOn )
					wKeyIndex = (short)(param1);
				else
					wKeyIndex = prvFrqToMidiKey(param1);
					
				// Start the note			
				sndCmd.cmd = freqCmd;
				sndCmd.param1 = 0;
				// Set MIDI key #
				sndCmd.param2 = (short)(wKeyIndex);
				osErr = SndDoCommand( GMacSndChanP, &sndCmd, false/*noWait*/ );
				}
			break;
			
		case stubSndCmdQuiet:
			if ( GMacSndChanP )
				{
				// Turn off sound			
				sndCmd.cmd = quietCmd;
				sndCmd.param1 = 0;
				sndCmd.param2 = 0;
				osErr = SndDoCommand( GMacSndChanP, &sndCmd, false/*noWait*/ );
				PrvFreeSoundChannel();
				}
			break;
		
		default:
			// Unhandled command
			err = stubSndErrBadParam;			// bad param
			StubDbgSrcMessage( "Unhandled sound command" );
			break;
		}
		
	return( err );
}



/************************************************************
 *
 *  FUNCTION: StubGet1Resource
 *
 *  DESCRIPTION: Gets a resource using the Macintosh resource
 *		manager.
 *
 *  PARAMETERS:
 *		resType	- resource type
 *		resID		- resource ID
 *
 *  RETURNS: handle
 *
 *  CREATED: 8/17/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void** StubGet1Resource(unsigned long resType, int resID)
{
	return (void**)Get1Resource(resType, resID);
}




/************************************************************
 *
 *  FUNCTION: StubRandom
 *
 *  DESCRIPTION: Returns a random number
 *
 *  PARAMETERS:
 *
 *  RETURNS: random number
 *
 *  CREATED: 8/17/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
unsigned int	StubRandom(void)
{
	return Random();
}


/************************************************************
 *
 *  Key Manager stubs
 *
 *************************************************************/

/***********************************************************************
 *
 *  FUNCTION:     PrvIsPressed
 *
 *  DESCRIPTION:  Tests if the given key is pressed
 *
 *  PARAMETERS:    k			-- scan code in the range 0-127 decimal
 *
 *  RETURNS:      non-zero if pressed
 *
 *  CALLED BY:    StubKeyCurrentState()
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	10/11/95	Initial version
 *
 ***********************************************************************/
static short PrvIsPressed(unsigned short k)
// k =  any keyboard scan code, 0-127
{
	KeyMap	keyMap;
	unsigned char* km = (unsigned char*)keyMap;

	GetKeys( keyMap);
	
	return ( ( km[k>>3] >> (k & 7) ) & 1);
}


/***********************************************************************
 *
 *  FUNCTION:     StubKeyCurrentState
 *
 *  DESCRIPTION:  Returns bitfield with bits set for each key that is
 *							currently depressed.
 *
 *  PARAMETERS:    void
 *
 *  RETURNS:      DWord with bits set for keys that are depressed.
 *
 *  CALLED BY:    KeyCurrentState()
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	10/11/95	Initial version
 *
 ***********************************************************************/
#define macScanCodeF9			0x65			// --> Pilot hard1Chr
#define macScanCodeF10			0x6D			// --> Pilot hard2Chr
#define macScanCodeF11			0x67			// --> Pilot hard3Chr
#define macScanCodeF12			0x6F			// --> Pilot hard4Chr
#define macScanCodePageUp		0x74			// --> Pilot page-up
#define macScanCodePageDown	0x79			// --> Pilot page-down

#define macScanPeriod			0x2F			// --> Mac . key
#define macScanCmd				0x37			// --> Mac Cmd key

unsigned long StubKeyCurrentState(void)
{
	unsigned long	state = 0;
	
	if ( PrvIsPressed(macScanCodeF9) )
		state |= stubKeyBitHard1;
	
	if ( PrvIsPressed(macScanCodeF10) )
		state |= stubKeyBitHard2;
	
	if ( PrvIsPressed(macScanCodeF11) )
		state |= stubKeyBitHard3;
	
	if ( PrvIsPressed(macScanCodeF12) )
		state |= stubKeyBitHard4;
	
	if ( PrvIsPressed(macScanCodePageUp) )
		state |= stubKeyBitPageUp;
	
	if ( PrvIsPressed(macScanCodePageDown) )
		state |= stubKeyBitPageDown;
	
	return( state );
}



/***********************************************************************
 *
 *  FUNCTION:     StubCancelKey
 *
 *  DESCRIPTION:  Returns true if ESC key is held down on keyboard
 *
 *  PARAMETERS:    void
 *
 *  RETURNS:      DWord with bits set for keys that are depressed.
 *
 *  CALLED BY:    Multi-tasking simulator to prematurely cancel out of of
 *							timeout loop.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	10/11/95	Initial version
 *
 ***********************************************************************/
char	StubCancelKey(void)
{
	
	return PrvIsPressed(	macScanPeriod) && PrvIsPressed(macScanCmd) ;
	
}



#pragma IEEEdoubles reset

