/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     FatalAlert.c
 * AUTHOR:	 Art Lamb: Sept 19, 1995
 *
 * DECLARER: Sysyem
 *
 * DESCRIPTION:
 *	  This file contains routines that display the fatal alart dialog.
 *
 **********************************************************************/

//#define	PILOT_PRECOMPILED_HEADERS_OFF

#include <Pilot.h>
#include <FatalAlert.h>
#include <EmuStubs.h>
#include <KeyMgr.h>



/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/

#define fatalCtlHeight		12

// Only show the "Debugger" button if Error checking is on full.
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

	#define fatalNumCtls				2

	#define resetControlIndex		0
	#define debuggerControlIndex	1
#else
	#define fatalNumCtls				1

	#define resetControlIndex		0
#endif

#define fatalMsgMarginX		8
#define fatalMsgMarginY		8

// Fatal error dialog's strings

#if LANGUAGE == LANGUAGE_FRENCH

	#define fatalTitle			"Erreur fatale"
	#define fatalButton0Label	"R�initialiser"	// box is � in Pilot code page
	#define fatalButton1Label	"Debugger"
	#define fatalCtlWidth		72

#elif LANGUAGE == LANGUAGE_GERMAN

	#define fatalTitle			"Schwerwiegender Fehler"
	#define fatalButton0Label	"Reset"
	#define fatalButton1Label	"Debugger"
	#define fatalCtlWidth		50

#else

	#define fatalTitle			"Fatal Error"
	#define fatalButton0Label	"Reset"
	#define fatalButton1Label	"Debugger"
	#define fatalCtlWidth		50

#endif

/***********************************************************************
 *
 * FUNCTION: 	 SelectButton
 *
 * DESCRIPTION: This routine will track the pen until it is released
 *              within the bounds of one of the rectangles passed.
 *
 * PARAMETERS:	 table - pointer to a table object
 *              r     - pointer to the bounds of an item
 *					
 * RETURNED:	 fatalReset, fatalEnterDebugger, or fatalDoNothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/11/95	Initial Revision
 *			vmk	1/20/98	Added code to enable HotSync cradle button to
 *								cause the debugger to be entered while we're
 *								in FatalAlert
 *
 ***********************************************************************/
static UInt SelectButton (RectanglePtr ctlR)
{
	Int i;
	Short x, y;
	Boolean penDown = false;
	Boolean lastPenDown = false;
	Boolean selected = false;
	RectanglePtr r;
	FrameBitsType frame;
	
	frame.word = roundFrame;
	
	
	while (true)
		{
		#if EMULATION_LEVEL != EMULATION_NONE
		StubProcessMacEvents(-1);
		#endif
		
		// Check if the HotSync cradle button was pressed - if it has,
		// signal to enter the debugger
		#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		if ( KeyCurrentState() & keyBitCradle )
			return fatalEnterDebugger;
		#endif
		

		PenGetPoint (&x, &y, &penDown);
		if (penDown && (! lastPenDown))
			{
			for (i = 0; i < fatalNumCtls; i++)
				{
				if (RctPtInRectangle (x, y, &ctlR[i]))
					{
					r = &ctlR[i];
					WinInvertRectangle (r, frame.bits.cornerDiam);
					selected = true;
					do 
						{
						PenGetPoint (&x, &y, &penDown);
					
						if (RctPtInRectangle (x, y, r))
							{
							if (! selected)
								{
								WinInvertRectangle (r, frame.bits.cornerDiam);
								selected = true;
								}
							}
					
						else if (selected)
							{
							WinInvertRectangle (r, frame.bits.cornerDiam);
							selected = false;
							}
					
						} while (penDown);

					if (selected)
						return (i);
					}
				}
			}
		lastPenDown = penDown;
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 SysFatalAlert
 *
 * DESCRIPTION: This routine a dispay a fatal alert until a button in the 
 *              alart is pressed.
 *
 * PARAMETERS:	 msg      - message to display in the dialog
 *					
 * RETURNED:	 fatalReset, fatalEnterDebugger, or fatalDoNothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/19/95	Initial Revision
 *
 ***********************************************************************/
UInt SysFatalAlert (CharPtr msg)
{
	Int i;
	UInt length;
	Short x, y;
	Short displayWidth;
	Short displayHeight;
	Short maxWidth;
	Short margin;
	CharPtr ptr;
	CharPtr title = fatalTitle;
	CharPtr ctlLabel [fatalNumCtls];
	RectangleType dialogR;
	RectangleType ctlR [fatalNumCtls];
	RectangleType titleR;
	
	
	// Init control label array
	ctlLabel[0] = fatalButton0Label;
	if (fatalNumCtls > 1)
		ctlLabel[1] = fatalButton1Label;

	WinSetDrawWindow (WinGetDisplayWindow());
	
	// Calculate the bounds of the dialog.
	WinGetDisplayExtent (&displayWidth, &displayHeight);
	dialogR.topLeft.x = 0;
	dialogR.topLeft.y = displayHeight / 3;
	dialogR.extent.x = displayWidth - dialogR.topLeft.x;
	dialogR.extent.y = displayHeight - dialogR.topLeft.y;

	// Draw the dialog's frame.
	WinEraseRectangle (&dialogR, 0);
	RctInsetRectangle (&dialogR, 2);
	WinDrawRectangleFrame (dialogFrame , &dialogR);

	// Draw the title.
	FntSetFont (boldFont);
	titleR.topLeft.x = dialogR.topLeft.x;
	titleR.topLeft.y = dialogR.topLeft.y;
	titleR.extent.x = dialogR.extent.x;
	titleR.extent.y = FntLineHeight ();
	x  = (dialogR.extent.x - FntCharsWidth (title, StrLen (title)) + 1) >> 1;
	WinDrawLine (titleR.topLeft.x+1, titleR.topLeft.y, 
		titleR.extent.x-2, titleR.topLeft.y);
	WinDrawRectangle (&titleR, 0);
	WinInvertChars (title, StrLen (title), x, titleR.topLeft.y - 1);


	// Draw the message.
	ptr = msg;
	x = dialogR.topLeft.x + fatalMsgMarginX;
	y = dialogR.topLeft.y + fatalMsgMarginY + titleR.extent.y;
	maxWidth = dialogR.extent.x - (fatalMsgMarginX * 2);
	while (true)
		{
		length = FldWordWrap  (ptr, maxWidth);
		if (! length) break;
		WinDrawChars (ptr, length, x, y);
		ptr += length;
		y += FntLineHeight();
		}


	// Calculate the bounds of the buttons and draw them.
	for (i = 0; i < fatalNumCtls; i++)
		{
		margin = (dialogR.extent.x - (fatalNumCtls * fatalCtlWidth)) / 
			(fatalNumCtls + 1);
		ctlR[i].topLeft.x = (margin * (i + 1)) + (fatalCtlWidth * i);
		ctlR[i].topLeft.y = dialogR.topLeft.y + dialogR.extent.y - 
			fatalCtlHeight - 5;
		ctlR[i].extent.x = fatalCtlWidth;
		ctlR[i].extent.y = fatalCtlHeight;
		
		WinDrawRectangleFrame (roundFrame , &ctlR[i]);
		x  = ctlR[i].topLeft.x + ((fatalCtlWidth - 
			FntCharsWidth (ctlLabel[i], StrLen (ctlLabel[i])) + 1) >> 1);
		y = ctlR[i].topLeft.y + ((ctlR[i].extent.y - FntLineHeight()) / 2);
		WinDrawChars (ctlLabel[i], StrLen (ctlLabel[i]), x, y);
		}

	return (SelectButton (ctlR));
}


