// =============================================================================
// Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
// All rights reserved.
// File:	ExgDB.c
//
// Type:	Edge (Palm OS)
//
// Status:	Beta
//
// Format:	Monospaced, 4 spaces per tab
//
// Description:
// ------------
// This module supports transfer of Pilot database files ONLY and is not
// guaranteed to be compatible in the future if the format of Pilot
// Databases changes!!! Notice that it includes <DataPrv.h> which is a
// NON_PORTABLE header file. Future versions of PalmOS might change the
// definitions in this header.
//
// Revisions:
// ----------
// 970922	Original, based on CmdFTP.c (Marco Frigino)
// =============================================================================

// =============================================================================
// ================================== Includes =================================
// =============================================================================

#ifndef __SYSALL_H__
#include <SysAll.h>
#endif
#include <UIAll.h>
#define	NON_PORTABLE
#include <DataPrv.h>
#undef NON_PORTABLE

#include <ExgMgr.h>
// =============================================================================
// ================================== Macros ===================================
// =============================================================================

#define	GOTO_WITH_ERR(label, value) \
			err = (value); goto label;

#define	GOTO_IF_NULL(label, val) \
			if (val == 0) goto label;

#define	GOTO_IF_ERR(label) \
			if (err != 0) goto label;

#define	GOTO_IF_NULL_SET_ERR(label, value, errVal) \
			if (value == NULL) {err = errVal; goto label;}

#define	GOTO_IF_NULL_SET_DM_LAST_ERR(label, value) \
			GOTO_IF_NULL_SET_ERR(label, value, DmGetLastErr())

// =============================================================================
// ================================= Typedefs ==================================
// =============================================================================

// -----------------------------------------------------------------------------
//	CountRecordListsInfo
// -----------------------------------------------------------------------------
typedef struct {
	ULong					numOfEntries;
	ULong					firstUsableOffset;
	UShort					numOfRecordLists;
} CountRecordListsInfo, *CountRecordListsInfoPtr;


// -----------------------------------------------------------------------------
//	ResizeHandleProcPtr
// -----------------------------------------------------------------------------
typedef Err (*ResizeHandleProcPtr)(
	Handle*					dataHP,
	void*					resizeInfoP,
	ULong					newSize);


// -----------------------------------------------------------------------------
//	ResizeHandleInfo
// -----------------------------------------------------------------------------
typedef struct {
	DmOpenRef				dbRef;
} ResizeHandleInfo, *ResizeHandleInfoPtr;


// -----------------------------------------------------------------------------
//	ResizeRecordInfo
// -----------------------------------------------------------------------------
typedef struct {
	DmOpenRef				dbRef;
	UShort					recIdx;
} ResizeRecordInfo, *ResizeRecordInfoPtr;


// -----------------------------------------------------------------------------
//	ReadListProcPtr
// -----------------------------------------------------------------------------
typedef Err (*ReadListProcPtr)(
	Word					numEntries,
	DatabaseHdrType*		hdrP,
	void*					userDataP);


// -----------------------------------------------------------------------------
//	ReadEntryInfo
// -----------------------------------------------------------------------------
typedef struct {
	ExgDBReadProcPtr		readProcP;
	void*					userDataP;
	ULong*					readCountP;
	ULong					prevEntryDataOffset;
	ULong					firstEntryDataOffset;
	UInt					nextEntryIdx;
	UShort					totalEntries;
	DmOpenRef				dbRef;
	Int						cardNo;
} ReadEntryInfo, *ReadEntryInfoPtr;


// -----------------------------------------------------------------------------
//	WriteListProcPtr
// -----------------------------------------------------------------------------
typedef Err (*WriteListProcPtr)(
	const RecordListType*	recListP,
	const DatabaseHdrType*	hdrP,
	void*					userDataP);


// -----------------------------------------------------------------------------
//	WriteEntryInfo
// -----------------------------------------------------------------------------
typedef struct {
	ExgDBWriteProcPtr		writeProcP;
//	ExgDBProgressProcPtr	progressProcP;
	void*					userDataP;
	ULong*					writeCountP;
	ULong					nextEntryDataOffset;
	ULong					nextEntryUniqueID;
	Int						cardNo;
} WriteEntryInfo, *WriteEntryInfoPtr;

// =============================================================================
// ================================= Constants =================================
// =============================================================================

// Change the size of this buffer to optimize read speed
#define		kReadBufSize  1024

// =============================================================================
// ================================= Prototypes ================================
// =============================================================================

static Err			GetRecordHandle(
							Handle*					recHP,
							ULong*					uniqueIDP,
							UInt*					attrP,
							DmOpenRef				dbRef,
							UInt					recNum);

static void			GetChunkSize(
							LocalID					chunkID,
							ULong*					sizeP,
							Int						cardNo);

static Err			ResizeHandle(
							DmOpenRef				dbRef,
							Handle*					dataHP,
							ULong					newSize);

static Err			ResizeHandleCallback(
							Handle*					dataHP,
							void*					resizeInfoP,
							ULong					newSize);

static Err			ResizeResourceCallback(
							Handle*					dataHP,
							void*					resizeInfoP,
							ULong					newSize);

static Err			ResizeRecordCallback(
							Handle*					dataHP,
							void*					resizeInfoP,
							ULong					newSize);

static inline Err	ReadHandleData(
							ExgDBReadProcPtr		readProcP,
							void*					userDataP,
							BytePtr					readBufP,
							ULong*					readCountP,
							VoidHand				dataH);

static Err			ReadHandleUntilEnd(
							ExgDBReadProcPtr		readProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							BytePtr					readBufP,
							ULong*					readCountP,
							ResizeHandleProcPtr		resizeProcP,
							void*					resizeInfoP,
							Handle*					dataHP);

static Err			ReadDmData(
							ExgDBReadProcPtr		readProcP,
							void*					userDataP,
							BytePtr					readBufP,
							void*					dataP,
							ULong					dataSize,
							ULong*					readCountP);

static inline Err	ReadData(
							ExgDBReadProcPtr		readProcP,
							void*					userDataP,
							void*					dataP,
							ULong					dataSize,
							ULong*					readCountP);

static Err			ReadEntryData(
							ExgDBReadProcPtr		readProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							BytePtr					readBufP,
							DatabaseHdrType*		hdrP,
							ULong*					readCountP,
							ReadEntryInfoPtr		infoP,
							DmOpenRef				dbRef);

static Err			DoForEachReadEntryList(
							ReadListProcPtr			procP,
							DatabaseHdrType*		hdrP,
							void*					userDataP);

static inline Err	CreateRecordEntry(
							DmOpenRef				dbRef,
							RecordEntryPtr			recEntryP,
							ULong					entrySize,
							UInt*					nextEntryIdxP);

static inline Err	CreateResourceEntry(
							DmOpenRef				dbRef,
							RsrcEntryPtr			resEntryP,
							ULong					entrySize);

static Err			ReadListCallback(
							Word					numEntries,
							DatabaseHdrType*		hdrP,
							void*					userDataP);

static Err			ReadInfoHandleData(
							ExgDBReadProcPtr		readProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							BytePtr					readBufP,
							ULong*					readCountP,
							DmOpenRef				dbRef,
							VoidHand*				infoHP,
							ReadEntryInfoPtr		infoP,
							ULong					infoOffset);

static inline Err	ReadEntryLists(
							ExgDBReadProcPtr		readProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							DatabaseHdrType*		hdrP,
							ULong*					readCountP,
							ReadEntryInfoPtr		infoP,
							DmOpenRef				dbRef,
							UInt					cardNo);

static Err			ReadDatabase(
							ExgDBReadProcPtr		readProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							BytePtr					readBufP,
							DatabaseHdrType*		hdrP,
							ULong*					readCountP,
							DmOpenRef				dbRef,
							LocalID					dbID,
							UInt					cardNo);

static Err			DoForEachWriteEntryList(
							const WriteListProcPtr	procP,
							const DatabaseHdrType*	hdrP,
							void*					userDataP,
							UInt					cardNo);

static Err			CountEntriesCallback(
							const RecordListType*	listP,
							const DatabaseHdrType*	hdrP,
							void*					userDataP);

static inline Err	CalcEntryInfo(
							const DatabaseHdrType*	hdrP,
							CountRecordListsInfoPtr	infoP,
							UInt					cardNo);

static inline Err	WriteData(
							ExgDBWriteProcPtr		writeProcP,
							void*					userDataP,
							const void*				dataP,
							ULong					dataSize,
							ULong*					writeCountP);

static Err			WriteChunkData(
							ExgDBWriteProcPtr		writeProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							ULong*					writeCountP,
							LocalID					chunkID,
							Int						cardNo);

static inline Err	WriteEntryLists(
							ExgDBWriteProcPtr		writeProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							const DatabaseHdrType*	hdrP,
							ULong*					writeCountP,
							ULong					firstEntryDataOffset,
							UInt					cardNo);

static Err			WriteListCallback(
							const RecordListType*	listP,
							const DatabaseHdrType*	hdrP,
							void*					userDataP);

static Err			WriteDatabase(
							ExgDBWriteProcPtr		writeProcP,
//							ExgDBProgressProcPtr	progressProcP,
							void*					userDataP,
							const DatabaseHdrType*	hdrP,
							ULong*					writeCountP,
							DmOpenRef				dbRef,
							Int						cardNo);


// =============================================================================
// ================================= Functions =================================
// =============================================================================

// -----------------------------------------------------------------------------
//	GetRecordHandle
// -----------------------------------------------------------------------------
Err GetRecordHandle(
	Handle*					recHP,
	ULong*					uniqueIDP,
	UInt*					attrP,
	DmOpenRef				dbRef,
	UInt					recNum)
{
	LocalID					recChunkID;
	Err						err = 0;

	// Try to get the record info
	err = DmRecordInfo(dbRef, recNum, attrP, uniqueIDP, &recChunkID);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// If the record is marked as deleted, temporarily un-delete it so
	// that we can get the handle to it's data, if any
	if (((*attrP & dmRecAttrDelete) != 0) && (recChunkID != 0))
		{
		// Mask out delete bit
		*attrP &= ~dmRecAttrDelete;
		// Try to set record info
		err = DmSetRecordInfo(dbRef, recNum, attrP, 0);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Get record handle
		*recHP = DmQueryRecord(dbRef, recNum);
		// Set delete bit
		*attrP |= dmRecAttrDelete;
		// Try to set record info
		err = DmSetRecordInfo(dbRef, recNum, attrP, 0);
		// Exit if error
		GOTO_IF_ERR(Exit);
		}
	else
		{
		// Get record handle
		*recHP = DmQueryRecord(dbRef, recNum);
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	GetChunkSize
// -----------------------------------------------------------------------------
void GetChunkSize(
	LocalID					chunkID,
	ULong*					sizeP,
	Int						cardNo)
{
	// If info ID valid
	if (chunkID != NULL)
		{
		// Get locked ptr to chunk
		Ptr	chunkP = MemLocalIDToLockedPtr(chunkID, cardNo);
		// Get chunk size
		*sizeP = MemPtrSize(chunkP);
		// Unlock chunk
		MemPtrUnlock(chunkP);
		}
	else
		{
		// Clear size
		*sizeP = 0;
		}
}


#pragma mark ---------------------------
// -----------------------------------------------------------------------------
//	ResizeHandle
// -----------------------------------------------------------------------------
static Err ResizeHandle(
	DmOpenRef				dbRef,
	Handle*					dataHP,
	ULong					newSize)
{
	Handle					newH;
	WordPtr					srcP;
	WordPtr					newP;
	Err						err;

	// Try to resize handle
	err = MemHandleResize(*dataHP, newSize);
	// If failed
	if (err != 0)
		{
		// Try to reallocate it in another heap
		newH = DmNewHandle((DmAccessPtr)dbRef, newSize);
		// Exit if reallocation failed
		// DOLATER: Calling DmGetLastErr is invalid here
		// because the lastErr is not set by DmNewHandle.
		GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, newH);
		// Get ptr to src handle
		srcP = (WordPtr)MemHandleLock(*dataHP);
		// Get ptr to dst handle
		newP = (WordPtr)MemHandleLock(newH);
		// Move data to new handle
		err = DmWrite(newP, 0, srcP, MemHandleSize(*dataHP));
		// Unlock new handle
		MemHandleUnlock(newH);
		// Free given handle
		MemHandleFree(*dataHP);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Delete old handle
		MemHandleFree(*dataHP);
		// Save new handle
		*dataHP = newH;
		// Clear error
		err = 0;
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ResizeHandleCallback
// -----------------------------------------------------------------------------
static Err ResizeHandleCallback(
	Handle*					dataHP,
	void*					resizeInfoP,
	ULong					newSize)
{
	ResizeHandleInfoPtr		infoP = (ResizeHandleInfoPtr)resizeInfoP;

	// Try to resize given handle and return error
	return ResizeHandle(infoP->dbRef, dataHP, newSize);
}


// -----------------------------------------------------------------------------
//	ResizeResourceCallback
// -----------------------------------------------------------------------------
static Err ResizeResourceCallback(
	Handle*					dataHP,
	void*					resizeInfoP,
	ULong					newSize)
{
	// Try to resize resource handle
	*dataHP = DmResizeResource(*dataHP, newSize);
	// Return error code
	return DmGetLastErr();
}


// -----------------------------------------------------------------------------
//	ResizeRecordCallback
// -----------------------------------------------------------------------------
static Err ResizeRecordCallback(
	Handle*					dataHP,
	void*					resizeInfoP,
	ULong					newSize)
{
	ResizeRecordInfoPtr		infoP = (ResizeRecordInfoPtr)resizeInfoP;

	// Try to resize record handle
	*dataHP = DmResizeRecord(infoP->dbRef, infoP->recIdx, newSize);
	// Return error code
	return DmGetLastErr();
}


// -----------------------------------------------------------------------------
//	ReadHandleData
// -----------------------------------------------------------------------------
// Reads exactly the number of bytes that fit in the given handle
static inline Err ReadHandleData(
	ExgDBReadProcPtr		readProcP,
	void*					userDataP,
	BytePtr					readBufP,
	ULong*					readCountP,
	VoidHand				dataH)
{
	BytePtr					dataP;
	Err						err;

	// Get ptr to locked entry data
	dataP = MemHandleLock(dataH);
	// Try to read data into protected memory
	err = ReadDmData(readProcP, userDataP, readBufP, dataP, MemHandleSize(dataH),
					readCountP);
	// Unlock entry data
	MemHandleUnlock(dataH);
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadHandleUntilEnd
// -----------------------------------------------------------------------------
// We don't know how much to read, so we keep reading
// until we read less bytes than a whole buffer
static Err ReadHandleUntilEnd(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	BytePtr					readBufP,
	ULong*					readCountP,
	ResizeHandleProcPtr		resizeProcP,
	void*					resizeInfoP,
	Handle*					dataHP)
{
	BytePtr					dstP;
	ULong					readSize;
	ULong					dataSize;
	Err						err = 0;

	// Init previous and current handle size
	dataSize = 0;
	// Read an entire buffer until no more data or error
	while (true)
		{
		// Reset read size
		readSize = 0;
		// Try to read a whole buffer of data
		err = ReadData(readProcP, userDataP, readBufP, kReadBufSize, &readSize);
		// Add bytes actually read to total
		*readCountP += readSize;
		// Exit without error maybe if no data was read this time
		GOTO_IF_NULL(Exit, readSize);
		// Try to resize handle to hold new data
		err = (*resizeProcP)(dataHP, resizeInfoP, dataSize + readSize);
		// Exit if resizing failed
		GOTO_IF_ERR(Exit);
		// Get ptr to locked data
		dstP = (BytePtr)MemHandleLock(*dataHP);
		// Write into data from buffer at last offset
		err = DmWrite(dstP, dataSize, readBufP, readSize);
		// Exit if error writing
		GOTO_IF_ERR(Exit);
		// Advance offset for next write by the bytes read
		dataSize += readSize;
		// Unlock data
		MemHandleUnlock(*dataHP);
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadDmData
// -----------------------------------------------------------------------------
static Err ReadDmData(
	ExgDBReadProcPtr		readProcP,
	void*					userDataP,
	BytePtr					readBufP,
	void*					dataP,
	ULong					dataSize,
	ULong*					readCountP)
{
	Err						err = 0;

	// If data to read is > buffer, read it in pieces
	if (dataSize > kReadBufSize)
		{
		ULong	bytesToRead = dataSize;
		ULong	bytesRead = 0;

		while (err == 0 && bytesToRead > 0)
			{
			// Split into kReadBufSize bytes or less
			if (bytesToRead > kReadBufSize)
				bytesToRead = kReadBufSize;
			// Read a piece
			err = (*readProcP)(readBufP, &bytesToRead, userDataP);
			GOTO_IF_ERR(Exit);
			// Transfer data to protected memory
			err = DmWrite(dataP, bytesRead, readBufP, bytesToRead);
			GOTO_IF_ERR(Exit);
			// Adjust bytes read
			bytesRead += bytesToRead;
			// Calc bytes left to read
			bytesToRead = dataSize - bytesRead;
			}
		// Return total read
		*readCountP = bytesRead;
		}
	else
		{
		// Read all data
		err = (*readProcP)(readBufP, &dataSize, userDataP);
		GOTO_IF_ERR(Exit);
		// Transfer data to dm memory
		err = DmWrite(dataP, 0, readBufP, dataSize);
		GOTO_IF_ERR(Exit);
		// Return total read
		*readCountP = dataSize;
		}

Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadData
// -----------------------------------------------------------------------------
static inline Err ReadData(
	ExgDBReadProcPtr		readProcP,
	void*					userDataP,
	void*					dataP,
	ULong					dataSize,
	ULong*					readCountP)
{
	ULong					readCount;
	Err						err;

	// Init read count from given data size
	readCount = dataSize;
	// Try to read data
	err = (*readProcP)(dataP, &readCount, userDataP);
	// Add read data to count, regardless of error
	*readCountP += readCount;
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadEntryData
// -----------------------------------------------------------------------------
static Err ReadEntryData(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	BytePtr					readBufP,
	DatabaseHdrType*		hdrP,
	ULong*					readCountP,
	ReadEntryInfoPtr		infoP,
	DmOpenRef				dbRef)
{
	Handle					dataH;
	ULong					uniqueID;
	ULong					offset = 0;
	UInt					attr;
	Int						i;
	Err						err;
	Boolean					resDB;

	// Determine if db is a record or resource db
	resDB = ((hdrP->attributes & dmHdrAttrResDB) != 0);

	// Read data for each entry
	for (i = 0; i < infoP->totalEntries; i++)
		{
		// If db has resources
		if (resDB)
			{
			// Try to get resource handle
			dataH = DmGetResourceIndex(dbRef, i);
			// Exit if handle fetch failed
			GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, dataH);
			}
		else
			{
			// Try to get record data handle
			err = GetRecordHandle(&dataH, &uniqueID, &attr, dbRef, i);
			// Exit if error
			GOTO_IF_ERR(Exit);
			}

		// If handle has no data skip it
		if (dataH == NULL)
			continue;
		// If this isnt the last entry
		if (i < infoP->totalEntries - 1)
			{
			// Try to read data to fill handle
			err = ReadHandleData(readProcP, userDataP, readBufP, readCountP, dataH);
			// Exit if error
			GOTO_IF_ERR(Exit);

			// Call progress proc
//			if (progressProcP != NULL)
//				(*progressProcP)(totalExpectedBytes, totalBytes, userDataP);
			}
		else
			{
			// This is the last record
			// If db has resources
			if (resDB)
				// Read resource data until EOF
				err = ReadHandleUntilEnd(readProcP, userDataP, readBufP, readCountP,
									ResizeResourceCallback, NULL, &dataH);
			else
				{
				// Read record data until EOF
				ResizeRecordInfo	info;
				info.dbRef = dbRef;
				info.recIdx = i;
				err = ReadHandleUntilEnd(readProcP, userDataP, readBufP, readCountP,
									ResizeRecordCallback, &info, &dataH);
				}
			// Exit if error
			GOTO_IF_ERR(Exit);
			}
		// If db has resources
		if (resDB)
			{
			// Release resource
			DmReleaseResource(dataH);
			// Last resource was released
			dataH = NULL;
			}
		}
Exit:
	// If db has resources and last res was not released
	if (resDB && (dataH != NULL))
		{
		// Release resource
		DmReleaseResource(dataH);
		}
	// Call progress proc
//	if (progressProcP != NULL)
//		(*progressProcP)(totalExpectedBytes, totalBytes, userDataP);

	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	DoForEachReadEntryList
// -----------------------------------------------------------------------------
static Err DoForEachReadEntryList(
	ReadListProcPtr			procP,
	DatabaseHdrType*		hdrP,
	void*					userDataP)
{
	ReadEntryInfoPtr		infoP;
	RecordListType			list;
	Err						err;

	// Get read info ptr
	infoP = (ReadEntryInfoPtr)userDataP;
	// Reset number of entries
	infoP->totalEntries = 0;
	// Process each entry in the list
	do
		{
		// Try to read an entry list header
		err = ReadData(infoP->readProcP, infoP->userDataP, &list,
			(sizeof(RecordListType) - sizeof(((RecordListPtr)(NULL))->firstEntry)),
			infoP->readCountP);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Add number of entries to total entries
		infoP->totalEntries += list.numRecords;
		// Call callback proc with this entry list header
		if (procP != NULL)
			err = (*procP)(list.numRecords, hdrP, userDataP);
		}
	while (err == 0 && list.nextRecordListID != 0);
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	CreateRecordEntry
// -----------------------------------------------------------------------------
static inline Err CreateRecordEntry(
	DmOpenRef				dbRef,
	RecordEntryPtr			recEntryP,
	ULong					entrySize,
	UInt*					nextEntryIdxP)
{
	Handle					newEntryH;
	ULong					id;
	UInt					attr;
	Err						err = 0;

	// If the record is 0 size
	if (entrySize == 0)
		{
		// Attach a nil handle to it
		err = DmAttachRecord(dbRef, nextEntryIdxP, NULL, 0);
		// Exit if error
		GOTO_IF_ERR(Exit);
		}
	else
		{
		// Try to allocate exact size record handle
		newEntryH = (Handle)DmNewRecord(dbRef, nextEntryIdxP, entrySize);
		// Exit if allocation failed
		GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, newEntryH);
		}
	// Set record attributes
	attr = recEntryP->attributes;
	id = recEntryP->uniqueID[0];
	id = (id << 8) | recEntryP->uniqueID[1];
	id = (id << 8) | recEntryP->uniqueID[2];
	//  Set attributes in record info
	err = DmSetRecordInfo(dbRef, *nextEntryIdxP, &attr, &id);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Release new record
	err = DmReleaseRecord(dbRef, *nextEntryIdxP, false);
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	CreateResourceEntry
// -----------------------------------------------------------------------------
static inline Err CreateResourceEntry(
	DmOpenRef				dbRef,
	RsrcEntryPtr			resEntryP,
	ULong					entrySize)
{
	Handle					newEntryH;
	Err						err = 0;

	// Try to allocate new resource space
	newEntryH = DmNewResource(dbRef, resEntryP->type,
							resEntryP->id, entrySize);
	// Exit if allocation failed
	GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, newEntryH);
	// Release new resource
	err = DmReleaseResource(newEntryH);
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadListCallback
// -----------------------------------------------------------------------------
static Err ReadListCallback(
	Word					numEntries,
	DatabaseHdrType*		hdrP,
	void*					userDataP)
{
	ReadEntryInfoPtr		infoP;
	RsrcEntryType			prevResEntry;
	RsrcEntryType			curResEntry;
	RecordEntryType			prevRecEntry;
	RecordEntryType			curRecEntry;
	ULong					curEntryDataOffset;
	ULong					prevEntryDataSize;
	short					idx;
	Err						err = 0;
	Boolean					resDB;

	// Exit if no entries
	GOTO_IF_NULL(Exit, numEntries);

	// Determine if db is a record or resource db
	resDB = ((hdrP->attributes & dmHdrAttrResDB) != 0);
	// Get info ptr
	infoP = (ReadEntryInfoPtr)userDataP;

	// Read first entry

	// If db has resources
	if (resDB)
		{
		// Read a resource entry
		err = ReadData(infoP->readProcP, infoP->userDataP, &prevResEntry,
						sizeof(prevResEntry), infoP->readCountP);
		// Get entry data offset
		curEntryDataOffset = prevResEntry.localChunkID;
		}
	else
		{
		// Read a record entry
		err = ReadData(infoP->readProcP, infoP->userDataP, &prevRecEntry,
						sizeof(prevRecEntry), infoP->readCountP);
		// Get entry data offset
		curEntryDataOffset = prevRecEntry.localChunkID;
		}
	// Exit if error
	GOTO_IF_ERR(Exit);

	// Save first entry data offset
	infoP->firstEntryDataOffset = curEntryDataOffset;
	// Save current entry data offset into prev entry data offset
	infoP->prevEntryDataOffset = curEntryDataOffset;

	// Read remaining entries

	// For each remaining entry in entry list
	for (idx = 1; idx < numEntries; idx++)
		{
		// If db has resources
		if (resDB)
			{
			// Read a resource entry
			err = ReadData(infoP->readProcP, infoP->userDataP, &curResEntry,
							sizeof(curResEntry), infoP->readCountP);
			// Get entry data offset
			curEntryDataOffset = curResEntry.localChunkID;
			}
		else
			{
			// Read a record entry
			err = ReadData(infoP->readProcP, infoP->userDataP, &curRecEntry,
							sizeof(curRecEntry), infoP->readCountP);
			// Get entry data offset
			curEntryDataOffset = curRecEntry.localChunkID;
			}
		// Exit if error
		GOTO_IF_ERR(Exit);

		// Calc previous entry data size
		prevEntryDataSize = curEntryDataOffset - infoP->prevEntryDataOffset;
		// If db has resources
		if (resDB)
			{
			// Try to create previous resource entry
			err = CreateResourceEntry(infoP->dbRef, &prevResEntry,
									prevEntryDataSize);
			// Save current entry into previous entry
			prevResEntry = curResEntry;
			}
		else
			{
			// Try to create previous record entry
			err = CreateRecordEntry(infoP->dbRef, &prevRecEntry,
									prevEntryDataSize, &infoP->nextEntryIdx);
			// Save current entry into previous entry
			prevRecEntry = curRecEntry;
			// Advance next entry index
			++infoP->nextEntryIdx;
			}
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Save current entry data offset into previous entry data offset
		infoP->prevEntryDataOffset = curEntryDataOffset;
		}

		// Create last entry (or possibly first and only one) with a
		// bogus size of 1

		// If db has resources
		if (resDB)
			{
			// Try to create previous resource entry
			err = CreateResourceEntry(infoP->dbRef, &prevResEntry, 1);
			}
		else
			{
			// Try to create previous record entry
			err = CreateRecordEntry(infoP->dbRef, &prevRecEntry,
									1, &infoP->nextEntryIdx);
			}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadEntryLists
// -----------------------------------------------------------------------------
//	Reads the list entries
static inline Err ReadEntryLists(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	DatabaseHdrType*		hdrP,
	ULong*					readCountP,
	ReadEntryInfoPtr		infoP,
	DmOpenRef				dbRef,
	UInt					cardNo)
{
	// Init info
	infoP->readProcP = readProcP;
//	infoP->progressProcP = progressProcP;
	infoP->userDataP = userDataP;
	infoP->readCountP = readCountP;
	infoP->nextEntryIdx = 0;
	infoP->dbRef = dbRef;
	infoP->cardNo = cardNo;

	// Read each list in db and return error
	return DoForEachReadEntryList(ReadListCallback, hdrP, infoP);
}


// -----------------------------------------------------------------------------
//	ReadInfoHandleData
// -----------------------------------------------------------------------------
static Err ReadInfoHandleData(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	BytePtr					readBufP,
	ULong*					readCountP,
	DmOpenRef				dbRef,
	VoidHand*				infoHP,
	ReadEntryInfoPtr		infoP,
	ULong					infoOffset)
{
	UShort					recSize;
	Err						err;

	// If db has at least one entry
	if (infoP->totalEntries > 0)
		{
		// Use first entry to calc info size
		recSize = infoP->firstEntryDataOffset - infoOffset;
		// Try to allocate proper size info block
		*infoHP = DmNewHandle(dbRef, recSize);
		// Exit if allocation failed
		// DOLATER: Calling DmGetLastErr is invalid here
		// because the lastErr is not set by DmNewHandle.
		GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, *infoHP);
		// Try to read exact handle data
		err = ReadHandleData(readProcP, userDataP, readBufP, readCountP, *infoHP);
		}
	else
		{
		// Try to allocate info block
		ResizeHandleInfo	info;
		// Setup resize handle callback info
		info.dbRef = dbRef;
		// Create new stub handle
		*infoHP = DmNewHandle(dbRef, 1);
		// Exit if allocation failed
		// DOLATER: Calling DmGetLastErr is invalid here
		// because the lastErr is not set by DmNewHandle.
		GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, *infoHP);
		// Read info until EOF
		err = ReadHandleUntilEnd(readProcP, userDataP, readBufP, readCountP,
							ResizeHandleCallback, infoP, infoHP);
		}

	// Free new handle if error
	if (err != 0 && *infoHP != NULL)
		{
		MemHandleFree(*infoHP);
		*infoHP = NULL;
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ReadDatabase
// -----------------------------------------------------------------------------
static Err ReadDatabase(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	BytePtr					readBufP,
	DatabaseHdrType*		hdrP,
	ULong*					readCountP,
	DmOpenRef				dbRef,
	LocalID					dbID,
	UInt					cardNo)
{
	ReadEntryInfo			info;
	Handle					newRecH = NULL;
	LocalID					appInfoID;
	LocalID					sortInfoID;
	UShort					recSize;
	UShort					filler;
	Err						err;

	// Try to read entry lists
//	err = ReadEntryLists(readProcP, progressProcP, userDataP, hdrP,
	err = ReadEntryLists(readProcP, userDataP, hdrP,
						readCountP, &info, dbRef, cardNo);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Try to read filler bytes
	err = ReadData(readProcP, userDataP, &filler, sizeof(filler), readCountP);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Read app info if present in db 
	if (hdrP->appInfoID != 0)
		{
		// If db also has sort info
		if (hdrP->sortInfoID != 0)
			{
			// Calc app info size as delta from sort info offset
			recSize = (ULong)hdrP->sortInfoID - (ULong)hdrP->appInfoID;
			// Try to allocate proper app info block
			newRecH = DmNewHandle(dbRef, recSize);
			// Exit if allocation failed
			GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, newRecH);
			// Try to read exact handle data
			err = ReadHandleData(readProcP, userDataP, readBufP, readCountP, newRecH);
			}
		else
			{
			// Try to read app info data
//			err = ReadInfoHandleData(readProcP, progressProcP, userDataP, readBufP,
			err = ReadInfoHandleData(readProcP, userDataP, readBufP,
					readCountP, dbRef, &newRecH, &info, hdrP->appInfoID);
			}
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Set app info id from handle id
		appInfoID = MemHandleToLocalID(newRecH);
		// Store app info id in db header
		DmSetDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0,
						&appInfoID, 0, 0, 0);
		// Handle belongs to db now
		newRecH = NULL;
		}

	// Read sort info if present in db 
	if (hdrP->sortInfoID != 0)
		{
		// Try to read sort info data
//		err = ReadInfoHandleData(readProcP, progressProcP, userDataP, readBufP,
		err = ReadInfoHandleData(readProcP, userDataP, readBufP,
				readCountP, dbRef, &newRecH, &info, hdrP->sortInfoID);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Set sort info id from handle id
		sortInfoID = MemHandleToLocalID(newRecH);
		// Store sort info id in db header
		DmSetDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0,
						&sortInfoID, 0, 0);
		// Handle belongs to db now
		newRecH = NULL;
		}

	// Try to read all record/resource entry data
//	err = ReadEntryData(readProcP, progressProcP, userDataP, readBufP, hdrP,
	err = ReadEntryData(readProcP, userDataP, readBufP, hdrP,
					readCountP, &info, dbRef);
Exit:
	// Free lingering new handle if present
	if (newRecH != NULL)
		MemHandleFree(newRecH);
	// Call progress proc
//	if (progressProcP != NULL)
//		(*progressProcP)(totalExpectedBytes, totalBytes, userDataP);
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ExgDBRead
// -----------------------------------------------------------------------------
//	PARAMETERS:
//		readProcP		- Write callback proc ptr
//		progressProcP	- Progress callback proc ptr
//		userDataP		- User data ptr send to callback procs
//		cardNo			- Card number of database
//		keepDates		- True to preserve dates of db being read
//	RETURNED:
//		0 if no err
Err ExgDBRead(
	ExgDBReadProcPtr		readProcP,
//	ExgDBProgressProcPtr	progressProcP,
	ExgDBDeleteProcPtr		deleteProcP,
	void*					userDataP,
	LocalID*				dbIDP,
	Int						cardNo,
	Boolean*				needResetP,
	Boolean					keepDates)
{
	DmOpenRef				dbRef = NULL;
	DatabaseHdrType			hdr;
	BytePtr					readBufP;
	ULong					totalBytes = 0;
	LocalID					dbID = 0;
	Err						err;

	// Try to allocate a buffer for reading
	readBufP = MemPtrNew(kReadBufSize);
	// Exit if error
	GOTO_IF_NULL_SET_ERR(Exit, readBufP, memErrNotEnoughSpace);

	// Try to read header data
	err = ReadData(readProcP, userDataP, &hdr,
					sizeof(hdr) - sizeof(hdr.recordList), &totalBytes);
	// Exit if error
	GOTO_IF_ERR(Exit);

	// Verify as much header data as possible now

	// Check name. Must be <= 32 chars including terminator
	if ((StrChr((char*)hdr.name, '\0') - (char*)hdr.name) >= dmDBNameLength)
		{
		// Name is too long. Exit with error
		GOTO_WITH_ERR(Exit, dmErrCorruptDatabase);
		}

	// Verification passed

	// Try to find old db with same name
	dbID = DmFindDatabase(cardNo, (char*)hdr.name);

	// If duplicate found
	if (dbID != 0)
		{
		// If delete proc given
		if (deleteProcP != NULL)
			{
			// If caller doesnt delete existing db, exit without error
			if (!(*deleteProcP)((const char*)hdr.name, hdr.version,
									cardNo, dbID, userDataP))
				{
				// Dont need to reset since nothing read
				if (needResetP != NULL)
					*needResetP = false;
				// Clear db id. This implies that no db was read.
				*dbIDP = NULL;
				// Return with no error. Since no db was read, this
				// will be taken to imply the user cancelled, otherwise
				// there would have been an error.
				return 0;
				}
			}
		else
			{
			// Try to delete duplicate db
			err = DmDeleteDatabase(cardNo, dbID);
			// Exit if error
			GOTO_IF_ERR(Exit);
			}
		}

	// Try to create new db
	err = DmCreateDatabase(cardNo, (char*)hdr.name, hdr.creator, hdr.type, 
				hdr.attributes & dmHdrAttrResDB);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Try to get new db id
	dbID = DmFindDatabase(cardNo, (char*)hdr.name);
	// Exit if db id fetch failed
	GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, dbID);

	// If not preserving dates, clear them
	if (!keepDates)
		hdr.creationDate = hdr.modificationDate = hdr.lastBackupDate = 0;
	// Try to set db info
	err = DmSetDatabaseInfo(cardNo, dbID, 0, &hdr.attributes, &hdr.version,
				&hdr.creationDate, &hdr.modificationDate, &hdr.lastBackupDate,
				&hdr.modificationNumber, 0, 0, &hdr.type, &hdr.creator);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Try to open db for read/write
	dbRef = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
	// Exit if db open failed
	GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, dbRef);
	// Try to read rest of db
//	err = ReadDatabase(readProcP, progressProcP, userDataP, readBufP,
	err = ReadDatabase(readProcP, userDataP, readBufP,
						&hdr, &totalBytes, dbRef, dbID, cardNo);
Exit:
	// Close db if open
	if (dbRef != NULL)
		DmCloseDatabase(dbRef);
	// Delete db if error
	if (err != 0)
		{
		if (dbID != 0)
			{
			// Kill new db and clear id
			DmDeleteDatabase(cardNo, dbID);
			dbID = 0;
			}
		}

	// Return db id
	*dbIDP = dbID;

	// Determine if db needs reset after reading
	if (needResetP != NULL)
		*needResetP = (hdr.attributes & dmHdrAttrResetAfterInstall) != 0;

	// Free read buffer
	if (readBufP != NULL)
		MemPtrFree(readBufP);

	// Return error code
	return err;
}


#pragma mark ---------------------------
// -----------------------------------------------------------------------------
//	DoForEachWriteEntryList
// -----------------------------------------------------------------------------
static Err DoForEachWriteEntryList(
	WriteListProcPtr		procP,
	const DatabaseHdrType*	hdrP,
	void*					userDataP,
	UInt					cardNo)
{
	const RecordListType*	listP;
	LocalID					id;
	Err						err = 0;

	// Accumulate the sizes of every chunk
	listP = &hdrP->recordList;
	while (true) {
		// Call callback proc with this record list
		if (procP != NULL)
			err = (*procP)(listP, hdrP, userDataP);
		// Unlock this record list if it's not in the db header
		if (listP != &hdrP->recordList)
			MemPtrUnlock((RecordListType*)listP);
		// Get next record list id
		id = listP->nextRecordListID;
		// Exit loop if error or last list
		if (err != 0 || id == NULL)
			break;
		// Get ptr to next record list
		listP = MemLocalIDToLockedPtr(id, cardNo);
		}
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	CountEntriesCallback
// -----------------------------------------------------------------------------
static Err CountEntriesCallback(
	const RecordListType*	listP,
	const DatabaseHdrType*	hdrP,
	void*					userDataP)
{
	CountRecordListsInfoPtr	infoP = (CountRecordListsInfoPtr)userDataP;

	// Add this record list to num of record lists found
	++(infoP->numOfRecordLists);
	// Add number of entries to total
	infoP->numOfEntries += listP->numRecords;
	// Return no error
	return 0;
}


// -----------------------------------------------------------------------------
//	CalcEntryInfo
// -----------------------------------------------------------------------------
static Err CalcEntryInfo(
	const DatabaseHdrType*	hdrP,
	CountRecordListsInfoPtr	infoP,
	UInt					cardNo)
{
	UShort					entrySize;
	UShort					filler = 0;
	Err						err;

	// Init info
	infoP->numOfRecordLists = 0;
	infoP->numOfEntries = 0;
	// Count record lists in db
	err = DoForEachWriteEntryList(CountEntriesCallback, hdrP, infoP, cardNo);
	// Exit if error
	GOTO_IF_ERR(Exit);
	// Add size of each record list to total size
	infoP->firstUsableOffset = infoP->numOfRecordLists *
		(sizeof(RecordListType) - sizeof(((RecordListPtr)(NULL))->firstEntry));
	// Determine whether to use record or resource entry size
	entrySize = ((hdrP->attributes & dmHdrAttrResDB) != 0) ?
				sizeof(RsrcEntryType) : sizeof(RecordEntryType);
	// Add size of each entry
	infoP->firstUsableOffset += infoP->numOfEntries * entrySize;
	// Add db header (minus first record list) size to offset
	infoP->firstUsableOffset += sizeof(DatabaseHdrType) - sizeof(RecordListType);
	// Add filler size to offset
	infoP->firstUsableOffset += sizeof(filler);

Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	WriteData
// -----------------------------------------------------------------------------
static inline Err WriteData(
	ExgDBWriteProcPtr		writeProcP,
	void*					userDataP,
	const void*				dataP,
	ULong					dataSize,
	ULong*					writeCountP)
{
	ULong					writeCount;
	Err						err;

	// Init write count from given data size
	writeCount = dataSize;
	// Try to write data
	err = (*writeProcP)(dataP, &writeCount, userDataP);
	// Add written data to count, regardless of error
	*writeCountP += writeCount;
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	WriteChunkData
// -----------------------------------------------------------------------------
static Err WriteChunkData(
	ExgDBWriteProcPtr		writeProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	ULong*					writeCountP,
	LocalID					chunkID,
	Int						cardNo)
{
	Ptr						chunkP;
	ULong					chunkSize;
	Err						err = 0;

	// If chunk ID valid
	if (chunkID != NULL)
		{
		chunkP = MemLocalIDToLockedPtr(chunkID, cardNo);
		// Get chunk size
		chunkSize = MemPtrSize(chunkP);
		// Try to write data
		err = (*writeProcP)(chunkP, &chunkSize, userDataP);
		// Add bytes written to total
		*writeCountP += chunkSize;
		// Unlock chunk
		MemPtrUnlock(chunkP);
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	WriteListCallback
// -----------------------------------------------------------------------------
static Err WriteListCallback(
	const RecordListType*	listP,
	const DatabaseHdrType*	hdrP,
	void*					userDataP)
{
	RsrcEntryType			resEntry;
	RecordEntryType			recEntry;
	const RsrcEntryType*	resEntryP;
	const RecordEntryType*	recEntryP;
	WriteEntryInfoPtr		infoP;
	ULong					entrySize;
	short					idx;
	Err						err;
	Boolean					resDB;

	// Determine if db is a record or resource db
	resDB = ((hdrP->attributes & dmHdrAttrResDB) != 0);

	// Get info ptr
	infoP = (WriteEntryInfoPtr)userDataP;

	// Try to write entry list header
	err = WriteData(infoP->writeProcP, infoP->userDataP, listP,
	(sizeof(RecordListType) - sizeof(((RecordListPtr)(NULL))->firstEntry)),
		infoP->writeCountP);
	// Exit if error
	GOTO_IF_ERR(Exit);

	if (resDB)
		{
		// Get ptr to first resource entry
		resEntryP = (const RsrcEntryType*)&listP->firstEntry;
		// For each resource entry in the resource list
		for (idx = 0; idx < listP->numRecords; idx++)
			{
			// Make a copy of record entry
			resEntry = *resEntryP;
			// Get size of entry's record
			GetChunkSize(resEntry.localChunkID, &entrySize, infoP->cardNo);
			// Adjust record entry fields
			resEntry.localChunkID = infoP->nextEntryDataOffset;
			// Try to write record entry
			err = WriteData(infoP->writeProcP, infoP->userDataP, &resEntry,
							sizeof(resEntry), infoP->writeCountP);
			// Exit if error
			GOTO_IF_ERR(Exit);
			// Advance next record offset by size of this record
			infoP->nextEntryDataOffset += entrySize;
			// Advance resource entry ptr
			++resEntryP;
			}
		}
	else
		{
		// Get ptr to first record entry
		recEntryP = (const RecordEntryType*)&listP->firstEntry;
		// For each record entry in the record list
		for (idx = 0; idx < listP->numRecords; idx++)
			{
			// Make a copy of record entry
			recEntry = *recEntryP;
			// Get size of entry's record
			GetChunkSize(recEntry.localChunkID, &entrySize, infoP->cardNo);
			// Adjust record entry fields
			recEntry.localChunkID = infoP->nextEntryDataOffset;
			recEntry.uniqueID[0] = (infoP->nextEntryUniqueID >> 16) & 0x00FF;
			recEntry.uniqueID[1] = (infoP->nextEntryUniqueID >> 8) & 0x00FF;
			recEntry.uniqueID[2] = infoP->nextEntryUniqueID & 0x00FF;
			// Try to write record entry
			err = WriteData(infoP->writeProcP, infoP->userDataP, &recEntry,
							sizeof(recEntry), infoP->writeCountP);
			// Exit if error
			GOTO_IF_ERR(Exit);
			// Advance next unique id
			++infoP->nextEntryUniqueID;
			// Advance next record offset by size of this record
			infoP->nextEntryDataOffset += entrySize;
			// Advance record entry ptr
			++recEntryP;
			}
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	WriteEntryLists
// -----------------------------------------------------------------------------
//	Writes the list entries
static inline Err WriteEntryLists(
	ExgDBWriteProcPtr		writeProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	const DatabaseHdrType*	hdrP,
	ULong*					writeCountP,
	ULong					firstEntryDataOffset,
	UInt					cardNo)
{
	WriteEntryInfo			info;

	// Init info
	info.writeProcP = writeProcP;
//	info.progressProcP = progressProcP;
	info.userDataP = userDataP;
	info.writeCountP = writeCountP;
	info.nextEntryDataOffset = firstEntryDataOffset;
	info.nextEntryUniqueID = 1;
	info.cardNo = cardNo;

	// Write each resource list in db and return error
 	return DoForEachWriteEntryList(WriteListCallback, hdrP, &info, cardNo);
}


// -----------------------------------------------------------------------------
//	WriteDatabase
// -----------------------------------------------------------------------------
static Err WriteDatabase(
	ExgDBWriteProcPtr		writeProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	const DatabaseHdrType*	hdrP,
	ULong*					writeCountP,
	DmOpenRef				dbRef,
	Int						cardNo)
{
	DatabaseHdrType			hdr;
	CountRecordListsInfo	info;
	LocalID					chunkID;
	Int						i;
	UShort					filler = 0;
	Err						err;
	Boolean					resDB;

	// Determine if db is a record or resource db
	resDB = ((hdrP->attributes & dmHdrAttrResDB) != 0);

	// Try to calc db entry list info
	err = CalcEntryInfo(hdrP, &info, cardNo);

	// Make a copy of the header
	hdr = *hdrP;
	// Clear unique id seed
	hdr.uniqueIDSeed = 0;
	// Clear db open attribute bit
	hdr.attributes &= ~dmHdrAttrOpen;

	if (resDB)
		{
		// Clear app info ID
		hdr.appInfoID = 0;
		// Clear sort info ID
		hdr.sortInfoID = 0;
		}
	else
		{
		ULong		appInfoSize;
		ULong		sortInfoSize;
		// Try to get app info size
		GetChunkSize(hdr.appInfoID, &appInfoSize, cardNo);
		// Try to get sort info size
		GetChunkSize(hdr.sortInfoID, &sortInfoSize, cardNo);
		// Convert app info ID to offset
		if (hdr.appInfoID != NULL)
			hdr.appInfoID = info.firstUsableOffset;
		// Add app info size to offset
		info.firstUsableOffset += appInfoSize;
		// Convert sort info ID to offset
		if (hdr.sortInfoID != NULL)
			hdr.sortInfoID = hdr.appInfoID + appInfoSize;
		// Add sort info size to offset
		info.firstUsableOffset += sortInfoSize;
		}
	
	// Try to write db header minus first record list entry
	err = WriteData(writeProcP, userDataP, &hdr,
					sizeof(hdr) - sizeof(hdr.recordList), writeCountP);
	// Exit if error
	GOTO_IF_ERR(Exit);

	// Try to write entry lists
//	err = WriteEntryLists(writeProcP, progressProcP, userDataP,
	err = WriteEntryLists(writeProcP, userDataP,
							hdrP, writeCountP, info.firstUsableOffset, cardNo);
	// Exit if error
	GOTO_IF_ERR(Exit);

	// Try to write filler data
	err = WriteData(writeProcP, userDataP, &filler,
					sizeof(filler), writeCountP);
	// Exit if error
	GOTO_IF_ERR(Exit);

	if (!resDB)
		{
		// Write app Info if present
//		err = WriteChunkData(writeProcP, progressProcP, userDataP,
		err = WriteChunkData(writeProcP, userDataP,
							writeCountP, hdrP->appInfoID, cardNo);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Write sort Info if present
//		err = WriteChunkData(writeProcP, progressProcP, userDataP,
		err = WriteChunkData(writeProcP, userDataP,
							writeCountP, hdrP->sortInfoID, cardNo);
		// Exit if error
		GOTO_IF_ERR(Exit);
		}

	// Write each entry's data
	for (i = 0; i < info.numOfEntries; i++)
		{
		// Try to get resource or record info
		if (resDB)
			err = DmResourceInfo(dbRef, i, NULL, NULL, &chunkID);
		else
			err = DmRecordInfo(dbRef, i, NULL, NULL, &chunkID);
		// Exit if error
		GOTO_IF_ERR(Exit);
		// Try to write record data
//		err = WriteChunkData(writeProcP, progressProcP, userDataP,
		err = WriteChunkData(writeProcP, userDataP,
							writeCountP, chunkID, cardNo);
		// Exit if error
		GOTO_IF_ERR(Exit);
		}
Exit:
	// Return error code
	return err;
}


// -----------------------------------------------------------------------------
//	ExgDBWrite
// -----------------------------------------------------------------------------
//	Writes a given Pilot db in its internal format using the given callbacks.
//	If a db ID is not given, the given name will be used to search for it.
//
//	PARAMETERS:
//		writeProcP		- Write callback proc ptr
//		progressProcP	- Progress callback proc ptr
//		userDataP		- User data ptr send to callback procs
//		nameP			- Name of database to send
//		dbID			- ID of database to write
//		cardNo			- Card number of database
//	RETURNED:
//		0 if no err
Err ExgDBWrite(
	ExgDBWriteProcPtr		writeProcP,
//	ExgDBProgressProcPtr	progressProcP,
	void*					userDataP,
	const char*				nameP,
	LocalID					dbID,
	Int						cardNo)
{
	DatabaseHdrPtr			hdrP = NULL;
	DmOpenRef				dbRef = NULL;
	ULong					totalBytes = 0;
	Err						err = 0;

	// If db id not given
	if (dbID == 0)
		{
		// Try to find the db by name
		dbID = DmFindDatabase(cardNo, (char*)nameP);
		// Exit if error
		GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, dbID);
		}
	// Try to open db for read using db id
	dbRef = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
	// Exit if error
	GOTO_IF_NULL_SET_DM_LAST_ERR(Exit, dbRef);
	// Try to get ptr to locked db header
	hdrP = MemLocalIDToLockedPtr(dbID, cardNo);
	// Try to write the rest of the db
//	err = WriteDatabase(writeProcP, progressProcP, userDataP,
	err = WriteDatabase(writeProcP, userDataP,
					hdrP, &totalBytes, dbRef, cardNo);
Exit:
	// Unlock db header ptr if locked
	if (hdrP != NULL)
		MemPtrUnlock(hdrP);
	// Close db if opened
	if (dbRef != NULL)
		DmCloseDatabase(dbRef);
	// Return error code
	return err;
}
