/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------  
 * FileName:
 *		GraffitiGlue.c
 *
 * Description:
 *		Interface glue between System code and Graffiti engine.
 *
 * History:
 *   	6/30/95  RM - Created by Ron Marianetti
 *
 *******************************************************************/  


#include <Pilot.h>
#include <SysEvtMgr.h>
#include <Graffiti.h>

#define	NON_PORTABLE
#include <SystemPrv.h>
#include <GraffitiPrv.h>
#include <SysEvtPrv.h>
#include <Hardware.h>
#include <DataPrv.h>

#include	<DLServer.h>			//	Needed for user info (debugging macros)


// This is the character displayed when capturing a macro.
#define macroModeChr			shortcutStrokeChr


/************************************************************
 * Private routines used only in this module
 *************************************************************/
static Err		PrvEntry(GrfGlobalsPtr	gP);
static Err		PrvExit(GrfGlobalsPtr	gP);
static void		PrvFeedKeys(BytePtr dataP, UInt dataLen);
static Err		PrvTranslateError(Err	err);
static void		PrvUpdateIndicator (GrfGlobalsPtr gP);
static void		PrvResetMacro(void);
static Err		PrvFindShortcutsDB (UIntPtr cardNoP, LocalID* dbIDP);

#define	prvHexToAscii(x) \
				((x) > 9 ? (x)-10+'A' : (x)+'0')
#define	prvAsciiToHex(a) \
				((a) > '9' ? (a)-'A'+10 : (a)-'0')

/************************************************************
 *
 *  FUNCTION: GrfInit
 *
 *  DESCRIPTION: Initializes Graffiti and creates it's globals
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: System startup code
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *		kcr		9/26/95		turned on the 'backup' attribute for
 *									new graffiti macros databases.
 *		kcr		10/27/95		Added debugging macros for displaying &
 *									destroying user names & ID's.
 *		gavin		9/23/97		changed attributes from byte to Word
 *
 *************************************************************/
Err	GrfInit(void)
{
	GrfGlobalsPtr		gP = (GrfGlobalsPtr)GGrfGlobalsP;
	Err					err;
	TP3Configuration	config;
	TP3Size				globalsSize;
	UInt					cardNo;
	LocalID				dbID;
	CharPtr				dbNameP = "Graffiti ShortCuts";
	Boolean				newMacros = false;
	UInt					dbAttrs;
	
	
	// Allocate the root globals 
	if (gP) MemPtrFree(gP);
	GGrfGlobalsP = MemPtrNew(sizeof(GrfGlobalsType));
	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	if (!gP) {err = memErrNotEnoughSpace; goto Exit;}
		
	
	// Initialize them to 0
	MemSet(gP, sizeof(GrfGlobalsType), 0);
	
	
	
	// Allocate the engine globals
	config.maxPoints = 100;
	config.hDotsPerInch = 72;
	config.vDotsPerInch = 72;
	P3GetStorageSize(&globalsSize, &config);
	
	gP->globalsH = MemHandleNew(globalsSize);
	if (!gP->globalsH) {
		err = memErrNotEnoughSpace;
		goto Exit;
		}
		
		
	// Initialize our own fields
	gP->globalsSize = globalsSize;
	gP->glyphFlags = 0;
	gP->uncertain  = 0;
	gP->inMacro = false;
	gP->macroNameLen = 0;
	gP->macroName[0] = 0;
	
	gP->splitMode = true;
	
	
	// Get the template and dictionary
	gP->templateH = DmGetResource(sysResTGrfTemplate, sysResIDGrfTemplate);
	ErrFatalDisplayIf(!gP->templateH, "Graffiti Templ rsrc not found");
	
	gP->dictH = DmGetResource(sysResTGrfDictionary, sysResIDGrfDictionary);
	ErrFatalDisplayIf(!gP->dictH, "Graffiti Dict rsrc not found");
	
	
	//----------------------------------------------------------
	// Look for the shortcuts database
	//----------------------------------------------------------
	err = PrvFindShortcutsDB(&cardNo, &dbID);
	if (err) {
		ULong		modNum;
		Handle	resH=0;
		cardNo = 0;
		
		// Create Database from saved image in a resource in the System file
		if (GSysResetFlags & sysResetFlagCreateDefaultDBs) {
			resH = DmGetResource(sysResTDefaultDB, sysResIDGrfDefaultMacros);
			if (resH) {
				err = DmCreateDatabaseFromImage(MemHandleLock(resH));
				MemHandleUnlock(resH);
				DmReleaseResource(resH);
				if (err) resH = 0;
				}
			}
		if (!resH) {
			err = DmCreateDatabase(cardNo, dbNameP, sysFileCGraffiti, 
					sysFileTGraffitiMacros, true);
			}
		if (err) goto Exit;


		// Find the database.
		dbID = DmFindDatabase(cardNo, dbNameP);
		if (!dbID) {err = DmGetLastErr(); goto Exit;}
		

		//	When creating the graffiti macros database, set the 'backup'
		//	attribute on. Also, preserve the modification number because the
		// we guarantee that the default database has a modification number of 1
		// to inform the Sync app that this is default data and shouldn't be
		//  backed up if the user is restoring data to a hard resetted Pilot.
		err = DmDatabaseInfo(cardNo, dbID, NULL,
					&dbAttrs, NULL, NULL,
					NULL, NULL, 
					&modNum, NULL,
					NULL, NULL, NULL);
		if (err) goto Exit;

		dbAttrs |= dmHdrAttrBackup;
		dbAttrs |= dmHdrAttrOKToInstallNewer;
		err = DmSetDatabaseInfo(cardNo, dbID, NULL,
					&dbAttrs, NULL, NULL,
					NULL, NULL, 
					&modNum, NULL,
					NULL, NULL, NULL);
		if (err) goto Exit;
		}	
		
	// Open it
	gP->macrosDbP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite | dmModeLeaveOpen);
	if (!gP->macrosDbP) {err = -1; goto Exit;}
	
	// Move it into the System Context
	DmMoveOpenDBContext(0, gP->macrosDbP);
	
		
	// Get the macros resource
	gP->macrosH = DmGet1Resource(grfMacrosResT, grfMacrosResID);
	if (!gP->macrosH) {
		BytePtr	p;
		Byte		zero = 0;
		UInt		i;
		
		gP->macrosH = DmNewResource(gP->macrosDbP, grfMacrosResT,
								grfMacrosResID, grfMacrosMinSize);
		if (!gP->macrosH) {err = DmGetLastErr(); goto Exit;}
		p = MemHandleLock(gP->macrosH);
		for (i=0; i<grfMacrosMinSize; i++)
			DmWrite(p, i, &zero, 1);
		MemHandleUnlock(gP->macrosH);
		newMacros = true;
		}
	
	
	//----------------------------------------------------------
	// Init Graffiti and the dictionary state
	//----------------------------------------------------------
	PrvEntry(gP);
	P3Initialize(&gP->p3Data, &config);
	P3InitState(&gP->p3Data, &gP->state);
	PrvExit(gP);
	
	
	
	//----------------------------------------------------------
	// Add the Debugging macros
	//----------------------------------------------------------
	if (newMacros) {
		char		data[16];
		
		
		// Virtual key codes. These macro sequences always start with the
		//  virtual keycode escape byte followed by 4 character ascii code, 
		//  followed by 4 character key code, followed by 4 character modifiers code.
		// When the PrvFeedKeys() sees one of these sequences, it feeds it into
		//  the keyboard queue and then SysHandleEvent() will eventually process it
		data[0] = grfVirtualSequence; 				// escape code
		data[5] = prvHexToAscii(0);					// key code
		data[6] = prvHexToAscii(0);					// key code
		data[7] = prvHexToAscii(0);					// key code
		data[8] = prvHexToAscii(0);					// key code
		
		data[9] = prvHexToAscii((commandKeyMask >> 12) & 0x0F);	// modifiers
		data[10] = prvHexToAscii((commandKeyMask >> 8) & 0x0F);	// modifiers
		data[11] = prvHexToAscii((commandKeyMask >> 4) & 0x0F);	// modifiers
		data[12] = prvHexToAscii(commandKeyMask & 0x0F);			// modifiers
		
		data[1] = prvHexToAscii((enterDebuggerChr >> 12) & 0x0F);
		data[2] = prvHexToAscii((enterDebuggerChr >> 8) & 0x0F);
		data[3] = prvHexToAscii((enterDebuggerChr >> 4) & 0x0F);
		data[4] = prvHexToAscii(enterDebuggerChr & 0x0F);
		GrfAddMacro(".1", (BytePtr)data, 13);
		
		data[1] = prvHexToAscii((startConsoleChr >> 12) & 0x0F);
		data[2] = prvHexToAscii((startConsoleChr >> 8) & 0x0F);
		data[3] = prvHexToAscii((startConsoleChr >> 4) & 0x0F);
		data[4] = prvHexToAscii(startConsoleChr & 0x0F);
		GrfAddMacro(".2", (BytePtr)data, 13);


		// Special Sequences. These are interpreted directly by PrvFeedKeys()
		data[0] = grfSpecialSequence;
		data[1] = grfSpecialNoAutoOff;
		GrfAddMacro(".3", (BytePtr)data, 2);

		//	Display the current user information on the screen.
		data[0] = grfSpecialSequence;
		data[1] = grfSpecialShowUserInfo;
		GrfAddMacro(".4", (BytePtr)data, 2);

		//	Delete the current user information.
		data[0] = grfSpecialSequence;
		data[1] = grfSpecialDeleteUserInfo;
		GrfAddMacro(".5", (BytePtr)data, 2);

		//	Show the ROM Build date
		data[0] = grfSpecialSequence;
		data[1] = grfSpecialSystemBuildDate;
		GrfAddMacro(".6", (BytePtr)data, 2);

		//	Change the battery kind
		data[0] = grfSpecialSequence;
		data[1] = grfSpecialBatteryKind;
		GrfAddMacro(".7", (BytePtr)data, 2);
		}
	


Exit:
	if (err) {
		ErrDisplay("Err in GrfInit");
		GrfFree();
		}
	
	return err;
}



/************************************************************
 *
 *  FUNCTION: PrvFindShortcutsDB
 *
 *  DESCRIPTION: Called by GrfInit to locate the Shortcuts Database.
 *			When the PC restores the Graffiti shortcuts database to Pilot,
 *			it must save it under a new name since the existing database is
 *			always opened by Graffiti and can not be replaced "live". 
 *
 *			So, we always use the copy of the Graffiti shortcuts with the
 *			newest creation date and delete any older copies that we find.
 *
 *  PARAMETERS:  
 *		cardNoP - pointer to return card number
 *		dbIDP   - pointer to return database ID
 *
 *  RETURNS: 0 if found, non-0 if not found.
 * 
 *  CALLED BY: GrfInit()
 *
 *  CREATED: 12/14/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err PrvFindShortcutsDB (UIntPtr cardNoP, LocalID* dbIDP)
{
	UInt					cardNo;
	LocalID				dbID;
	DmSearchStateType	searchState;
	Err					err;
	ULong					crDate;
	Boolean				newSearch;
	UInt					version;
	
	UInt					latestCardNo=0;
	LocalID				latestDbID=0;
	ULong					latestCrDate=0;


	//---------------------------------------------------------------------------
	// Loop till we find the shortcuts database with the most recent creation date
	//---------------------------------------------------------------------------
	newSearch = true;
	while(1) {
		err = DmGetNextDatabaseByTypeCreator(newSearch, &searchState, 
					sysFileTGraffitiMacros, sysFileCGraffiti, false, 
					&cardNo, &dbID);
		if (err) break;
		newSearch = false;
		
		// Get info on this database
		err = DmDatabaseInfo(cardNo, dbID, 0,
							0, &version, &crDate,
							0, 0, 0, 0,
							0, 0, 0);
		if (err) continue;
		
		// If not the right version, skip it
		if (version != grfMacrosDBVersion) continue;
		
		// If latest creation date, save info
		if (crDate >= latestCrDate) {
			latestCrDate = crDate;
			latestCardNo = cardNo;
			latestDbID = dbID;
			}
		}
							
	//---------------------------------------------------------------------------
	// We found the most recent version, now delete any older versions that we
	//  no longer will use
	//---------------------------------------------------------------------------
	newSearch = true;
	while(1) {
		err = DmGetNextDatabaseByTypeCreator(newSearch, &searchState, 
					sysFileTGraffitiMacros, sysFileCGraffiti, false, 
					&cardNo, &dbID);
		if (err) break;
		newSearch = false;
		
		// Get info on this database
		err = DmDatabaseInfo(cardNo, dbID, 0,
							0, &version, 0,
							0, 0, 0, 0,
							0, 0, 0);
		if (err) continue;
		
		// If not the right version, skip it
		if (version != grfMacrosDBVersion) continue;
		
		// If this is the database we'll be using, skip it
		if (dbID == latestDbID  &&  cardNo == latestCardNo) continue;
		
		// Delete it!
		DmDeleteDatabase(cardNo, dbID);
		newSearch = true;			// start search over since list of databases has changed.
		}
		
		
	// Return info on found database
	if (latestDbID) {
		*cardNoP = latestCardNo;
		*dbIDP = latestDbID;
		return 0;
		}
	else
		return dmErrCantFind;
					
}



/************************************************************
 *
 *  FUNCTION: GrfFree
 *
 *  DESCRIPTION: Dispose of the Graffiti globals and close it down
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: System startup code
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfFree(void)
{
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Free the globals 
	if (gP) {
		if (gP->globalsH) 
			MemHandleFree(gP->globalsH);
			
		if (gP->templateH) 
			DmReleaseResource(gP->templateH);
			
		if (gP->dictH) 
			DmReleaseResource(gP->dictH);
			
		if (gP->macrosH) 
			DmReleaseResource(gP->macrosH);
			
		if (gP->macrosDbP) 
			DmCloseDatabase(gP->macrosDbP);
			
		MemPtrFree(gP);
		}
		
		
	GGrfGlobalsP = 0;

	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvLaunchGraffitiDemo()
 *
 *  DESCRIPTION: Launches the Graffiti Demo App
 *
 *  PARAMETERS: 
 *
 *  RETURNS: void
 * 
 *  CALLED BY: GrfProcessStroke
 *
 *  CREATED: 1/7/97
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void		PrvLaunchGraffitiDemo(void)
{
	DmSearchStateType	state;
	Err					err;
	UInt					cardNo;
	LocalID				dbID;
	
	err = DmGetNextDatabaseByTypeCreator(true, &state, 
		sysFileTApplication, sysFileCGraffitiDemo, true, &cardNo, &dbID);
		
	// If not found, return;
	if (err)  return;

	// Otherwise, try and switch apps.
	if (dbID) 
		SysUIAppSwitch(cardNo, dbID, 0, 0);
}




/************************************************************
 *
 *  FUNCTION: EvtProcessGraffitiStroke()
 *
 *  DESCRIPTION: Translate a stroke to keyboard events using
 *   Graffiti. This routine will recognize the stroke and send the
 *   recognized characters into the key queue. Flushes stroke
 *	  out of pen queue after recognition.
 *
 *  PARAMETERS: 
 *		*startPtP - start point of stroke
 *		*endPtP	 - end point of stroke
 *		upShift	 - set true to feed an artificial upshift into the engine.
 *
 *  RETURNS: 0 if recognized
 * 
 *  CALLED BY: EvtGetSysEvent when a pen-up is detected in the writing area
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		GrfProcessStroke(PointType* startPtP, PointType* endPtP,
					Boolean upShift)
{
	GrfGlobalsPtr		gP = (GrfGlobalsPtr)GGrfGlobalsP;
	PointType			sysPoint;
	TP3Point				p3Point;
	TP3MatchInfo		matchInfo;
	Err					err;
	Byte					data[grfMaxKeys];
	Word					flags;
	Word					dataLen = 0;
	Word					uncertainLen = 0;
	UInt					i;
	TP3DictState		saveState;
	UInt					left, right, top;
	Word					saveShiftState;
	Word					saveLockFlags;
	UInt					startY, numPts=0;
	
	
	// Don't allow Graffiti if the disable bit is set.
	if (GSysMiscFlags & sysMiscFlagGrfDisable) {
		if (!upShift) {
			if (!(GSysMiscFlags & sysMiscFlagInDemoAlert)) {
				GSysMiscFlags |= sysMiscFlagInDemoAlert;
				if (FrmAlert(DemoUnitAlert) == 0)  	// Go To Graffiti app
					PrvLaunchGraffitiDemo();
				GSysMiscFlags &= ~sysMiscFlagInDemoAlert;
				}
			}
		return 0;
		}

	// Lock down handles
	PrvEntry(gP);
	
	
	//---------------------------------------------------------------------------
	// save the current  the capsLock state, numLock state, and 
	// temporary shift state.
	//---------------------------------------------------------------------------
	saveLockFlags = gP->state.lockFlags;
	saveShiftState = gP->shiftState;
	

	//---------------------------------------------------------------------------
	// Add the points and capture the bounds so that we can determine if
	//  the user is writing in the letter or number side
	//---------------------------------------------------------------------------
	// Flush the point buffer
	P3FlushPoints(&gP->p3Data);
	left =  0x7FFF;
	right =  0;
	top =  0x7FFF;

	// If forcing temp upper shift...
	if (upShift) {
		p3Point.x = 100; p3Point.y = 100;
		P3AddPoint(&gP->p3Data, &p3Point);
		
		p3Point.x = 100; p3Point.y = 0;
		P3AddPoint(&gP->p3Data, &p3Point);
		}
		
	else {
		while(1) {
		
			// Get next point
			err = EvtDequeuePenPoint(&sysPoint);
			ErrFatalDisplayIf(err, "Err getting next point");
			
			// If it's (-1,-1) exit loop
			if (sysPoint.x < 0) break;
			
			// Add the point
			p3Point.x = sysPoint.x;
			p3Point.y = sysPoint.y;
			err = P3AddPoint(&gP->p3Data, &p3Point);
			if (err) {
				//ErrDisplay("Point overflow in Graffiti");
				break;
				}
				
			// Grow the bounds
			if (sysPoint.x < left) left = sysPoint.x;
			if (sysPoint.x > right) right = sysPoint.x;
			if (sysPoint.y < top) top = sysPoint.y;
			
			// Save the start point to help figure out if this is the stroke
			//  to bring up the keyboard
			if (numPts==0) startY = sysPoint.y;
			numPts++;
			}
			
			
		// See if this is the stroke to bring up the keyboard. We look for a vertical
		//  stroke starting in the Graffiti area and extending to the top 2/3 of
		//  the screen and having a width less than 1/4 of the height.
		if (startY > hwrSystemTop  &&  p3Point.y < ((hwrDisplayHeight * 2) / 3)) {
			if (numPts > 4 && (right-left < (p3Point.y - startY >> 2))) {
				EvtEnqueueKey(ronamaticChr, 0, commandKeyMask);
				err = 0;
				goto Exit;
				}
			}
		
		
		// Check to see if the stroke lies entirely in the bottom corner buttons
		// for the alpha and numeric keyboards.  If so, popup the keyboard.
		if (top > hwrKeyboardAlphaBtnTop) {
			if (right < hwrKeyboardAlphaBtnLeft + hwrKeyboardAlphaBtnWidth) {
				EvtEnqueueKey(keyboardAlphaChr, 0, commandKeyMask);
				err = 0;
				goto Exit;
				}
			else if (left > hwrKeyboardNumericBtnLeft) {
				EvtEnqueueKey(keyboardNumericChr, 0, commandKeyMask);
				err = 0;
				goto Exit;
				}

			}
		}		
		
	//---------------------------------------------------------------------------
	// If split-mode is on, set numLock on or off depending on the center of the stroke
	//---------------------------------------------------------------------------
	if (gP->splitMode) {
		Boolean	numOn = false;
		UInt		center;
		
		// Get the center of the stroke
		center = (left+right)>>1;
		
		// See if we want Numbers mode or not depending on the start point
		if ((center > hwrGraffitiSplit) && (startPtP->y > hwrGraffitiTop))
			numOn = true;
			
		if (numOn && !(gP->state.lockFlags & kP3DictFlagsNumLock)) {
		
			// Remember the capsLock state for next time we go back into alpha
			if (gP->state.lockFlags & kP3DictFlagsCapsLock)
				gP->restoreCaps = true;
			else
				gP->restoreCaps = false;
		
			// Remove temporary shift state and cancel uncertain text
			P3CleanState(&gP->p3Data, &gP->state);
			gP->uncertain = 0;
			gP->shiftState = 0;

			// Find the Numlock branch
			P3FindBranch(&gP->p3Data, kP3DictFlagsNumLock, &gP->state);
			}
			
		else if (!numOn && (gP->state.lockFlags & kP3DictFlagsNumLock)) {
			
			// Reset state and cancel uncertain text
			P3InitState(&gP->p3Data, &gP->state);
			gP->uncertain = 0;
			gP->shiftState = 0;

			// Find the CapsLock branch if we were in capsLock before.
			if (gP->restoreCaps)
				P3FindBranch(&gP->p3Data, kP3DictFlagsCapsLock, &gP->state);
			}
		}



	//---------------------------------------------------------------------------
	//  Recognize the stroke. If we're feeding in an up-stroke for auto-shifting
	//  record it's glyph ID so that we can ignore the next stroke if it's the same
	//  glyph ID.
	//---------------------------------------------------------------------------
	// Get the glyph for this stroke
	err = P3MatchGlyph(&gP->p3Data, &matchInfo, 4, 1);
	
	
	// Map it through the dictionary
	if (!err) {
	
		// Record Glyph ID for upstroke. Or if this is the stroke immediately following
		// an auto-shift and it is the up-stroke glyph, throw it out.
		if (upShift)
			gP->upShiftGlyphID = matchInfo.match[0].glyphID;
		else if (gP->wasAutoShifted && 
					matchInfo.match[0].glyphID == gP->upShiftGlyphID)
			goto Exit;
			
		// Assume we'll no longer be in a temp shift state. PrvFeedKeys will change this if
		//  it gets an appropriate temp shift sequence out of dictionary on this next stroke.
		gP->shiftState = 0;
	
		saveState = gP->state;
		dataLen = sizeof(data);
		err = P3GetGlyphMapping(&gP->p3Data, matchInfo.match[0].glyphID,
					&gP->state, &flags, data, &dataLen, &uncertainLen);
		}	
		
		
	//-----------------------------------------------------------------------	
	// If we're in split mode, don't allow any strokes to change the numLock mode
	//-----------------------------------------------------------------------	
	if (!err && gP->splitMode) {
		if ((gP->state.lockFlags & kP3DictFlagsNumLock) != (saveState.lockFlags & kP3DictFlagsNumLock)) {
			gP->state = saveState;
			goto Exit;
			}
			
		}


	//---------------------------------------------------------------------------
	// If there was an error from dictionary lookup do the following:
	//
	//  If (it was a branch that had kP3DictFlagsSearchPrev bit set)
	//     keep the uncertain text from last time because it was a real character that
	//      is only optionally followed by a modifier glyph
	//  else
	//     delete the uncertain text from last time because it was a pre-modifier
	//     glyph and not a real character
	//----------------------------------------------------------------------------
	if (err) {
		if (gP->glyphFlags & kP3DictFlagsSearchPrev)
			gP->uncertain = 0;
		else {
			if (gP->inMacro) gP->macroNameLen -= gP->uncertain;
			if (gP->macroNameLen < 0) gP->macroNameLen = 0;
			while(gP->uncertain > 0) {
				EvtEnqueueKey(8, 0, 0);
				gP->uncertain--;
				}
			}
		gP->glyphFlags = 0;
		err = 0;
		goto Exit;
		}
		
		
	//-----------------------------------------------------------------------	
	// Check for the special case of 1 uncertain followed by a character which
	// matches the lastCharacter. If we see this condition, skip the backspace
	// and repeat of the last character.
	//-----------------------------------------------------------------------	
	if ((gP->uncertain == 1) && (data[0] == gP->lastChar)) {
		gP->uncertain = 0;
		i = 1;
		}
	else 
		i = 0;
			
	// Remove the uncertain text from last time
	if (gP->inMacro) gP->macroNameLen -= gP->uncertain;
	if (gP->macroNameLen < 0) {
		gP->macroNameLen = 0;
		gP->inMacro = false;
		}
	while(gP->uncertain > 0) {
		EvtEnqueueKey(8, 0, 0);
		gP->uncertain--;
		
		// Nullify any backspace characters returned from recognition for every
		//  uncertain character we delete
		if (data[i] == 8) i++;
		}
	
	
	// Save the flags for error handling purposes, in case we get an error glyph next time
	gP->glyphFlags = flags;
	
	// Save the amount of uncertain text for next time
	gP->uncertain = uncertainLen;
	
	
	
	//-----------------------------------------------------------------------	
	// Feed the text into the event queue
	//-----------------------------------------------------------------------	
	PrvFeedKeys(data+i, dataLen-i);


	//-----------------------------------------------------------------------	
	// Handle Macro Processing
	//-----------------------------------------------------------------------	
	// If this is the start of a macro, prepare to capture it
	if (flags & kP3DictFlagsMacroStart) {
		gP->inMacro = true;
		gP->macroName[0] = 0;
		gP->macroNameLen = 0;
		EvtEnqueueKey(macroModeChr, 0, 0); 
		}
		
	// If we're doing a macro, see if we got a match yet
	if (gP->inMacro && gP->macroNameLen) {
		
		// Terminate the macro name
		gP->macroName[gP->macroNameLen] = 0;
		dataLen = sizeof(data) - 1;
		
		// Look up the name
		err = GrfGetAndExpandMacro((CharPtr) gP->macroName, data, &dataLen);
		
		// If we found it, output the macro data
		if (!err) {
		
			// Delete forming name from field
			PrvResetMacro();

			// output macro data
			PrvFeedKeys(data, dataLen);
			}
			
		// If fatal err, reset the macro stuff
		if (err &&  (err != grfErrMacroIncomplete)) 
			PrvResetMacro();
		err = 0;
		}
		


Exit:

	// Set boolean if we just auto-shifted
	gP->wasAutoShifted = upShift;

	//-----------------------------------------------------------------------	
	// Check if the capsLock state, numLock state, or temporary shift state
	// has been changed, if so update the graffiti shift state indicator.
	//-----------------------------------------------------------------------	
	if ( (saveShiftState != gP->shiftState) || (saveLockFlags != gP->state.lockFlags)) {
		PrvUpdateIndicator (gP);
		}


	ErrFatalDisplayIf(err, "Err recognizing Graffiti");
	PrvExit(gP);
	return err;
}


/************************************************************
 *
 *  FUNCTION: PrvResetMacro
 *
 *  DESCRIPTION: Clears any partially formed macro from the screen
 *     and resets the Graffiti state.
 *
 *  PARAMETERS: 
 *		void
 *
 *  RETURNS: void
 * 
 *  CALLED BY: GrfProcessStroke after recognizing a macro or
 *    cancelling one. PrvFeedKeys when it detects certain special
 *		keys.
 *
 *  CREATED: 12/1/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void		PrvResetMacro(void)
{
	GrfGlobalsPtr		gP = (GrfGlobalsPtr)GGrfGlobalsP;

	// Return immediately if we're not in a macro mode
	if (!gP->inMacro) return;
	
	// Delete the macro name
	while(gP->macroNameLen-- > 0) EvtEnqueueKey(8, 0, 0);
	
	// Delete the macro indicator character
	EvtEnqueueKey(8, 0, 0);
	
	// Reset state.
	gP->inMacro = false;
	P3CleanState(&gP->p3Data, &gP->state);
	gP->uncertain = 0;

}


/************************************************************
 *
 *  FUNCTION: PrvFeedKeys, private
 *
 *  DESCRIPTION: Feeds an array of keys into the Pilot keyboard queue.
 *		This routine correctly handles escaped sequences imbedded in the array
 *    for virtual key sequences and shift indicator sequences.
 *
 *  PARAMETERS: 
 *		void
 *
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: GrfProcessStroke for regular recognition and macro sequences.
 *
 *  CREATED: 8/1/95
 *
 *  BY: Ron Marianetti
 *
 *	kcr		9/19/95		removed calls to EvtEnqueueKeyString
 *	kcr		10/27/95		added macros to display and delete user info
 *	kcr		12/18/95		simplified user id deletion.
 *	roger		10/6/97		Fixed bug with new Word sized modifiers
 *
 *************************************************************/
static void		PrvFeedKeys(BytePtr dataP, UInt dataLen)
{
	GrfGlobalsPtr		gP = (GrfGlobalsPtr)GGrfGlobalsP;
	UInt					i;
	Byte					c;
	
	
	//-----------------------------------------------------------------------	
	// Feed the text into the event queue
	//-----------------------------------------------------------------------	
	for (i=0; i < dataLen; i++) {
	
		//------------------------------------------------------
		// Check for virtual key sequence indicators. These start with
		//  the byte value grfVirtualSequence followed by the ascii representation
		//  of the 2 byte ascii value, 2 byte keycode, 1 byte modifiers. We use
		//  ascii representation because we can't imbed 0's in the dictionary.
		//------------------------------------------------------
		if (dataP[i] == grfVirtualSequence) {
			UInt		ascii, keycode;
			UInt		modifiers;
			UInt		j;
			BytePtr	tmpP;
			
			// Get the ascii value
			tmpP = dataP + i;
			ascii = 0;
			for (j=1; j<=4; j++) 
				ascii = (ascii << 4) + prvAsciiToHex(tmpP[j]);
			
			// Get the keycode value
			keycode = 0;
			for (j=5; j<=8; j++) 
				keycode = (keycode << 4) + prvAsciiToHex(tmpP[j]);
				
			// Get the modifiers
			modifiers = 0;
			for (j=9; j<dataLen; j++)
				modifiers = (modifiers << 4) + prvAsciiToHex(tmpP[j]);
				
			// If this was the command key, reset any macro that might be in
			//  progress
			if (ascii == commandChr)
				PrvResetMacro();

			gP->lastChar = 0;
			EvtEnqueueKey(ascii, keycode, modifiers);
			i += (dataLen - i - 1);
			}
			
		// Check for shift sequence indicator 
		else if (dataP[i] == grfShiftSequence) {
			i++;
			gP->shiftState = dataP[i];
			gP->uncertain -= 2;
			if (gP->uncertain < 0) gP->uncertain = 0;
			}
			
		// Check for Special sequence indicators
		else if (dataP[i] == grfSpecialSequence) {
			i++;
			gP->lastChar = 0;
			switch (dataP[i]) {
				char*	strP;
				
				case grfSpecialToggleSplitMode:
					gP->splitMode = !gP->splitMode;
					gP->restoreCaps = false;
					break;
					
				// This sets Pilot to not auto-off. It can be reset by
				//  changing the timeout using Preferences again.
				case grfSpecialNoAutoOff:
					SysSetAutoOffTime(0);
					strP = "[No Auto-Off]";
					PrvFeedKeys((BytePtr)strP, StrLen(strP));
					break;
					
				//	Display the user's name & id
				case grfSpecialShowUserInfo:
					{
					char					id[10];
					DlkUserInfoPtr		infoP=0;
					DmOpenRef			dbP;
					FontID				origFont;
					Handle				resH=0;
					RectangleType		r;
					WinHandle			savedBits;
					Word					error;

					origFont = FntSetFont (boldFont);

					dbP = PrefOpenPreferenceDB(false);
					r.topLeft.x = 0;
					r.topLeft.y = 50;
					r.extent.x = hwrDisplayWidth;
					r.extent.y = 2*FntLineHeight ();
					savedBits = WinSaveBits (&r, &error);
					WinEraseRectangle (&r, 0);
					if (!dbP  ||
						 (resH = DmGet1Resource(sysResTSysPref, sysResIDDlkUserInfo)) == 0 ||
						 (infoP = (DlkUserInfoPtr)MemHandleLock( resH )) == 0)
						WinDrawChars ("no name available", 17,
										  30, 50);
					else
						{
						if (infoP->nameAndLog[0] == '\0')
							WinDrawChars ("no name available", 17,
											  30, 50);
						else
							WinDrawChars (infoP->nameAndLog,
											  infoP->header.userNameLen-1,
											  30, 50);
						StrIToA (id, infoP->header.userID);
						WinDrawChars (id,
										  StrLen (id),
										  30, 50+FntLineHeight());
						MemPtrUnlock(infoP);
						}
						
					// Delay for the user to see the info
					SysTaskDelay(sysTicksPerSecond*2);
					
					// Clean up before exiting
					if (resH) DmReleaseResource(resH);
					if (dbP) DmCloseDatabase(dbP);
					
					WinRestoreBits (savedBits, 0, 50);
					FntSetFont (origFont);
					break;
					}
					
				//	Reset the user's name & id
				case grfSpecialDeleteUserInfo:
					{
					DmOpenRef			dbP;
					int					index;
					
					dbP = PrefOpenPreferenceDB(false);
					if (dbP  &&
						 ((index = DmFindResource (dbP, sysResTSysPref, sysResIDDlkUserInfo, 0)) != -1))
						{
						DmRemoveResource (dbP, index);
						}
						
					// Clean up before exiting
					if (dbP) DmCloseDatabase(dbP);
					break;
					}
					
				// This displays the build date and time of the System resource file
				//  (essentially the ROM).
				case grfSpecialSystemBuildDate:
					{
					LocalID						dbID;
					ULong							crDate;
					DateTimeType				time;
					Char							str[16];
					
					// Get the database ID of the system file
					dbID = DmFindDatabase(0, "System");
					
					if (dbID) {
						// Get the creation time
						DmDatabaseInfo(0, dbID, 0,
							0, 0, &crDate,
							0, 0, 0, 0, 0, 0, 0);
						TimSecondsToDateTime(crDate, &time);
						
						// Print creation date
						DateToAscii(time.month, time.day, time.year, dfMDYWithSlashes,
							str);
						PrvFeedKeys((BytePtr)str, StrLen(str));
						PrvFeedKeys((BytePtr)", ", 2);
						
						// Print creation time
						TimeToAscii(time.hour, time.minute, tfColonAMPM, str);
						PrvFeedKeys((BytePtr)str, StrLen(str));
						}
					}
					break;
					
				// This Changes the battery kind in the System Preferences
				case grfSpecialBatteryKind:
					{
					SysBatteryKind				batteryKind;
					batteryKind = (SysBatteryKind)PrefGetPreference(prefSysBatteryKind);
					if (batteryKind == sysBatteryKindAlkaline) {
						batteryKind = sysBatteryKindNiCad;
						GSysBatteryKind = sysBatteryKindNiCad;
						PrvFeedKeys((BytePtr)"NiCad", 5);
						}
					else if (batteryKind == sysBatteryKindNiCad) {
						batteryKind = sysBatteryKindAlkaline;
						GSysBatteryKind = sysBatteryKindAlkaline;
						PrvFeedKeys((BytePtr)"Alkaline", 8);
						}
					PrefSetPreference(prefSysBatteryKind, batteryKind);
					}
					break;
					
				}
			}
			
			
		// Normal characters
		else {
			c = dataP[i];
			
			// Send the character into the keyboard queue
			gP->lastChar = c;
			EvtEnqueueKey(c, 0, 0);
			
			// Append the character to the current forming macro, if any
			if (gP->inMacro) {
				if (c == 8) {
					if (gP->macroNameLen > 0) gP->macroNameLen--;
					else gP->inMacro = false;
					}
				else {
					if (gP->macroNameLen < grfMaxMacroName-1)
						gP->macroName[gP->macroNameLen++] = c;
					else {
						PrvResetMacro();
						}
					}
				}// gP->inMacro
				
			} // else, Normal Characters
			
		} // for (; i<dataLen; i++)
		
}



/************************************************************
 *
 *  FUNCTION: GrfFieldChange
 *
 *  DESCRIPTION: Should be called by system whenever user changes the
 *		insertion point or switches fields. This tells Graffiti
 *		to cancel out of any temporary shift state and/or forming
 *		macro.
 *
 *  PARAMETERS: 
 *		void
 *
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: System when selection point changes or current text field changes.
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		GrfFieldChange (Boolean resetState, UIntPtr characterToDelete)
{
	Err				err=0;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Cancel out of macro, if any
	if (gP->inMacro) {
		*characterToDelete = gP->macroNameLen+1;
		gP->inMacro = false;
		}
	else
		*characterToDelete = 0;
		
	// Remove temporary shift state if we're showing uncertain chars
	if (gP->uncertain)
		P3CleanState(&gP->p3Data, &gP->state);

	// Cancel uncertain text.
	gP->uncertain = 0;
	

	// If auto-shifted reset the state.
	if (resetState && gP->wasAutoShifted)
		{
		GrfSetState(false, false, false);
		}


	// Unlock
	PrvExit(gP);

	return err;

}



/************************************************************
 *
 *  FUNCTION: GrfGetState
 *
 *  DESCRIPTION: Returns the current shift state of Graffiti.
 *
 *  PARAMETERS: 
 *		*capsLockP		- return true if caps lock on
 *		*numLockP		- return true if num lock on
 *		*tempShiftP		- current temporary shift
 *		*autoShiftedP	- shift not set by the user
 *
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		GrfGetState(Boolean* capsLockP, Boolean* numLockP,
				WordPtr	tempShiftP, Boolean* autoShiftedP)
{
	Err				err=0;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	
	ErrNonFatalDisplayIf(capsLockP == NULL, "NULL capsLockP");
	ErrNonFatalDisplayIf(numLockP == NULL, "NULL numLockP");
	ErrNonFatalDisplayIf(tempShiftP == NULL, "NULL tempShiftP");
	ErrNonFatalDisplayIf(autoShiftedP == NULL, "NULL autoShiftedP");
	
	// Lock down handles
	PrvEntry(gP);
	
	// Get the state
	if (gP->state.lockFlags & kP3DictFlagsCapsLock)
		*capsLockP = true;
	else
		*capsLockP = false;
		
	if (gP->state.lockFlags & kP3DictFlagsNumLock)
		*numLockP = true;
	else
		*numLockP = false;
		
	*tempShiftP = gP->shiftState;
	
	*autoShiftedP = gP->wasAutoShifted;
	
	
	
	// Unlock
	PrvExit(gP);

	return err;

}



/************************************************************
 *
 *  FUNCTION: GrfSetState
 *
 *  DESCRIPTION: Sets the current shift state of Graffiti.
 *
 *  PARAMETERS: 
 *		capsLock			- set true to turn on caps lock
 *		numLock			- set true to turn on num lock
 *		upperShift		- set true to put into upper shift
 *
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		GrfSetState(Boolean capsLock, Boolean numLock,
				Boolean upperShift)
{
	
	Err				err=0;
	Word				saveShiftState;
	Word				saveLockFlags;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	

	// Save the current capsLock state, numLock state and temporary shift state.
	saveLockFlags = gP->state.lockFlags;
	saveShiftState = gP->shiftState;


	// start with a clean state
	P3InitState(&gP->p3Data, &gP->state);
	gP->uncertain = 0;
	gP->glyphFlags = 0;
	gP->lastChar = 0;
	gP->shiftState = 0;
	
	// Set caps?
	if (capsLock) 
		P3FindBranch(&gP->p3Data, kP3DictFlagsCapsLock, &gP->state);

		
	// Set num?
	if (numLock)
		P3FindBranch(&gP->p3Data, kP3DictFlagsNumLock, &gP->state);
	
	// Go into upper shift?
	if (upperShift) 
		GrfProcessStroke(0, 0, true);
		
	
	// If the capsLock state, numLock state, or temporary shift state
	// has been changed, update the graffiti shift state indicator.
	if ( (saveShiftState != gP->shiftState) || (saveLockFlags != gP->state.lockFlags))
		PrvUpdateIndicator (gP);
	
	
	// Unlock
	PrvExit(gP);

	return err;

}


/************************************************************
 *
 *  FUNCTION: GrfFlushPoints
 *
 *  DESCRIPTION: Disposes of all points in Graffiti's point buffer.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfFlushPoints(void)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Flush the points
	err = P3FlushPoints(&gP->p3Data);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}


/************************************************************
 *
 *  FUNCTION: GrfAddPoint
 *
 *  DESCRIPTION: Adds a point to Graffiti's point buffer
 *
 *  PARAMETERS: 
 *		ptP - pointer to point
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfAddPoint(PointType*	ptP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	TP3Point			pt;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Add the point
	pt.x = ptP->x;
	pt.y = ptP->y;
	err = P3AddPoint(&gP->p3Data, &pt);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfInitState
 *
 *  DESCRIPTION: Re-initializes the dictionary state of Graffiti
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfInitState(void)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Init the dictionary state
	err = P3InitState(&gP->p3Data, &gP->state);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}


/************************************************************
 *
 *  FUNCTION: GrfCleanState
 *
 *  DESCRIPTION: Removes any temporary shifts from the dictionary
 *		state.
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfCleanState(void)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Init the dictionary state
	err = P3CleanState(&gP->p3Data, &gP->state);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}


/************************************************************
 *
 *  FUNCTION: GrfMatch
 *
 *  DESCRIPTION: Recognizes the current stroke in the Graffiti point
 *		buffer and returns with the recognized text.
 *
 *  PARAMETERS: 
 *		*flagsP 		-	glyph flags are returned here
 *		dataPtrP 	-	return text is placed here
 *		*dataLenP	-  size of data ptr on exit, # of characters returned on
 *								exit
 *		*uncertainLenP - return # of uncertain characters
 *		*matchInfoP	-  array of grfMaxMatches match info's, or nil 
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	GrfMatch(WordPtr flagsP, void* dataPtrP, WordPtr dataLenP,
					WordPtr uncertainLenP, GrfMatchInfoPtr matchInfoP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	

	// Call engine
	err = P3Match(&gP->p3Data, &gP->state, flagsP, dataPtrP, dataLenP,
				uncertainLenP, (TP3MatchInfo*)matchInfoP);
	if (err) err = PrvTranslateError(err);

	
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfGetMacro
 *
 *  DESCRIPTION: Looks up a macro in the current macros
 *
 *  PARAMETERS: 
 *		nameP			- name of macro to lookup
 *		macroDataP 	- macro contents returned here
 *		*dataLenP	- on entry: size of macroDataP buffer, on exit:
 *								number of bytes in macro data.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfGetMacro(CharPtr nameP, BytePtr macroDataP,
					WordPtr	dataLenP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	ErrNonFatalDisplayIf(nameP == NULL, "NULL nameP");
	ErrNonFatalDisplayIf(macroDataP == NULL, "NULL macroDataP");
	ErrNonFatalDisplayIf(dataLenP == NULL, "NULL dataLenP");
	
	// Lock down handles
	PrvEntry(gP);
	

	// Call engine
	err = P3GetMacro(&gP->p3Data, (TP3UByte*)nameP, macroDataP, dataLenP);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}


/***********************************************************************
 *
 * FUNCTION:     ExpandMacro
 *
 * DESCRIPTION:  Expand a macro. Note that macros are also expanded in PrvFeedKeys.
 *
 *		macroDataP 	- macro to expand (buffer of size evtEffectiveKeyQStorage)
 *		*dataLenP	- on entry: number of bytes in macro data, on exit:
 *								number of bytes in macro data.
 *
 *  RETURNS: 0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/13/95	Initial Revision
 *			kcr	11/14/95	Bug 402; catch the 'S' after 'D' or 'T'.
 *
 ***********************************************************************/
static void ExpandMacro(const BytePtr macroDataP, WordPtr dataLenP)
{
	Boolean						expandedDate = false, expandedTime = false;
	char							expandedData[grfMaxKeys];
	DateTimeType 				today;
	Byte 							c;
	UInt							index, len;
	char							temp[32];
	DateFormatType				dateFormat;
	TimeFormatType				timeFormat;
	
	
	ErrNonFatalDisplayIf(macroDataP == NULL, "NULL macroDataP");
	ErrNonFatalDisplayIf(dataLenP == NULL, "NULL dataLenP");
	
	
	// No data to process
	if (*dataLenP == 0)
		return;

	if (HasExpansionSequence(macroDataP))
		{
		expandedData[0] = '\0';

		// Get data used by multiple expansions here
		dateFormat = (DateFormatType)PrefGetPreference(prefDateFormat);
		timeFormat = (TimeFormatType)PrefGetPreference(prefTimeFormat);
		TimSecondsToDateTime (TimGetSeconds (), &today);


		// Get the length of the macroData
		len = *dataLenP;
		for (index=1; index < len; index++) {
			c = macroDataP[index];
			
			// Look for date stamp.
			if (c == expandDateChar && expandedDate == false) {	
				DateToAscii (today.month, today.day, today.year, dateFormat, 		
					temp);
				StrCat(expandedData, temp);
				
				expandedDate = true;
				
				//	If the date stamp is followed by a 'S' char, discard it.
				if (macroDataP[index+1] == expandStampChar)
					index++;
				
				// If the next character is the time stamp, add a space.
				if (macroDataP[index+1] == expandTimeChar)
					StrCat(expandedData, " ");
				}
				
			// Look for time stamp
			else if (c == expandTimeChar && expandedTime == false) {
				TimeToAscii (today.hour, today.minute, timeFormat, 
					temp);
				StrCat(expandedData, temp);
				
				expandedTime = true;
				
				//	If the time stamp is followed by a 'S' char, discard it.
				if (macroDataP[index+1] == expandStampChar)
					index++;
				
				// If the next character is the date stamp, add a space.
				if (macroDataP[index+1] == expandDateChar)
					StrCat(expandedData, " ");
				}

			// Else, just pass the character on through
			else {
				temp[0] = c;
				temp[1] = 0;
				StrCat(expandedData, temp);
				}
			}
			
			
		// Now that the macro is expanded copy it to the string to be returned.
		StrCopy((CharPtr) macroDataP, expandedData);
		*dataLenP = StrLen((CharPtr) macroDataP);

		return;
		}

}


/***********************************************************************
 *
 * FUNCTION:     GrfGetAndExpandMacro
 *
 * DESCRIPTION:  Looks up and expand a macro in the current macros
 *
 *		nameP			- name of macro to lookup
 *		macroDataP 	- macro contents returned here
 *		*dataLenP	- on entry: size of macroDataP buffer, on exit:
 *								number of bytes in macro data.
 *
 *  RETURNS: 0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/13/95	Initial Revision
 *
 ***********************************************************************/
Err 		GrfGetAndExpandMacro(CharPtr nameP, BytePtr macroDataP,
					WordPtr	dataLenP)
 {
	Err	err;

 	
	ErrNonFatalDisplayIf(nameP == NULL, "NULL nameP");
	ErrNonFatalDisplayIf(macroDataP == NULL, "NULL macroDataP");
	ErrNonFatalDisplayIf(dataLenP == NULL, "NULL dataLenP");
	
 	macroDataP[0] = 0;
 	
	// get the shortcut text associated with the name
	err = GrfGetMacro (nameP, macroDataP, dataLenP);
	
	if (!err) {
		// look for binary data and expand data requests embedded in the text
		ExpandMacro(macroDataP, dataLenP);
		
		if (*dataLenP == 0) 
			macroDataP[0] = 0;
		}	
		
	// Graffiti error ignored
	return err;
 }



/************************************************************
 *
 *  FUNCTION: GrfFilterPoints
 *
 *  DESCRIPTION: Filters the points in the Graffiti point buffer
 *
 *  PARAMETERS: 
 *		
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfFilterPoints(void)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	

	// Call engine
	err = P3FilterPoints(&gP->p3Data);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfGetNumPoints
 *
 *  DESCRIPTION: Returns the number of points in the point buffer
 *
 *  PARAMETERS: 
 *		*numPtsP		- returned # of points
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfGetNumPoints(WordPtr numPtsP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	
	ErrNonFatalDisplayIf(numPtsP == NULL, "NULL numPtsP");
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3GetNumPoints(&gP->p3Data, numPtsP);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}


/************************************************************
 *
 *  FUNCTION: GrfGetPoint
 *
 *  DESCRIPTION: Returns a point out of Graffiti's point buffer
 *
 *  PARAMETERS: 
 *		index		- which point to get
 *		*pointP	- returned point
 *		
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfGetPoint(Word index, PointType* pointP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	TP3Point			pt;
	
	
	ErrNonFatalDisplayIf(pointP == NULL, "NULL pointP");
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3GetPoint(&gP->p3Data, index, &pt);
	if (err) err = PrvTranslateError(err);
	pointP->x = pt.x;
	pointP->y = pt.y;
	
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfFindBranch
 *
 *  DESCRIPTION: Locates a branch in the Graffiti dictionary by
 *		flags.
 *
 *  PARAMETERS: 
 *		flags - flags of the branch we're searching for
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfFindBranch(Word flags)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3FindBranch(&gP->p3Data, flags, &gP->state);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}




/************************************************************
 *
 *  FUNCTION: GrfMatchGlyph
 *
 *  DESCRIPTION: Recognizes the current stroke as a glyph
 *
 *  PARAMETERS: 
 *		matchInfoP 		- pointer to array of matches to fill in
 *		maxUncertainty - max # of errors to tolerate
 *		maxMatches 		- size of matchInfoP array
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfMatchGlyph (GrfMatchInfoPtr matchInfoP,
					Word maxUnCertainty, Word maxMatches)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3MatchGlyph(&gP->p3Data, (TP3MatchInfo*)matchInfoP, maxUnCertainty, maxMatches);
	if (err) err = PrvTranslateError(err);
	
	// Unlock
	PrvExit(gP);

	return err;
}




/************************************************************
 *
 *  FUNCTION: GrfGetGlyphMapping
 *
 *  DESCRIPTION: Looks up a glyph in the dictionary and returns
 *		the text.
 *
 *  PARAMETERS: 
 *		glyphID		- glyph ID to lookup
 *		*flagsP		- returned dictionary flags
 *		dataPtrP		- where return text goes
 *		*dataLenP	- on entry: size of dataPtrP, on exit: # of bytes returned
 *		*uncertainLenP - return # of uncertain characters in text.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfGetGlyphMapping (Word glyphID, WordPtr flagsP,
					void* dataPtrP, WordPtr dataLenP, WordPtr uncertainLenP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	
	ErrNonFatalDisplayIf(flagsP == NULL, "NULL flagsP");
	ErrNonFatalDisplayIf(dataPtrP == NULL, "NULL dataPtrP");
	ErrNonFatalDisplayIf(dataLenP == NULL, "NULL dataLenP");
	ErrNonFatalDisplayIf(uncertainLenP == NULL, "NULL uncertainLenP");
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3GetGlyphMapping(&gP->p3Data, glyphID, &gP->state,
				flagsP, dataPtrP, dataLenP, uncertainLenP);
	if (err) err = PrvTranslateError(err);
				
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfGetMacroName
 *
 *  DESCRIPTION: looks up a macro name by index
 *
 *  PARAMETERS: 
 *		index 	- index of macro
 *		nameP 	- name returned here
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfGetMacroName(Word index, CharPtr nameP)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	
	
	ErrNonFatalDisplayIf(nameP == NULL, "NULL nameP");
	
	// Lock down handles
	PrvEntry(gP);
	
	// Call engine
	err = P3GetMacroName(&gP->p3Data, index, (TP3UByte*)nameP);
	if (err) err = PrvTranslateError(err);
				
	// Unlock
	PrvExit(gP);

	return err;
}




/************************************************************
 *
 *  FUNCTION: GrfDeleteMacro
 *
 *  DESCRIPTION: Deletes a macro from the macro list
 *
 *  PARAMETERS: 
 *		index - which macro to delete
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfDeleteMacro(Word index)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	TP3Size			size;
	Handle			newH;
	
	// Lock down handles
	PrvEntry(gP);
	
	
	// Call engine, enabling writes to the data storage area
	MemSemaphoreReserve(true);
	err = P3DeleteMacro(&gP->p3Data, index);
	MemSemaphoreRelease(true);
	if (err) {
		err = PrvTranslateError(err);
		goto Exit;
		}
	
	// Get the required size of the Graffiti macros handle
	err = P3GetMacrosSize(&gP->p3Data, &size);
	if (err) {
		err = PrvTranslateError(err);
		goto Exit;
		}
	
	// Shrink it down.
	PrvExit(gP);
	newH = DmResizeResource(gP->macrosH, size);
	if (!newH) 
		err = DmGetLastErr();
	else {
		LocalID	dbID;
		UInt		cardNo;
		ULong		modDate;
		
		gP->macrosH = newH;
		
		// Update modification date, which normally only gets updated when the
		//  database is closed.<ROM2.0>
		DmOpenDatabaseInfo(gP->macrosDbP, &dbID, 0, 0, &cardNo, 0);
		modDate = TimGetSeconds();
		DmSetDatabaseInfo(cardNo, dbID, 0, 0, 0, 0,
								&modDate, 0,
								0, 0, 0, 0, 0);
		}
	PrvEntry(gP);
				
				
Exit:
	// Unlock
	PrvExit(gP);

	return err;
}



/************************************************************
 *
 *  FUNCTION: GrfAddMacro
 *
 *  DESCRIPTION: Adds a macro to the macro list
 *
 *  PARAMETERS: 
 *		nameP			 - name of macro
 *		macroDataP 	 - data of macro
 *		dataLen		 - size of macro data in bytes
 *		macrosSizeP	 - on entry: actual size of macros handle
 *							on exit:  size required for macros handle
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: 
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		GrfAddMacro(CharPtr nameP, BytePtr macroDataP, Word dataLen)
{
	Err				err;
	GrfGlobalsPtr	gP = (GrfGlobalsPtr)GGrfGlobalsP;
	DWord				size;
	Handle			newH;
	Boolean			retry = true;
	LocalID			dbID;
	UInt				cardNo;
	ULong				modDate;
	
	// Lock down handles
	PrvEntry(gP);
	
	// Get size of macros handle
	size = MemHandleSize(gP->macrosH);

	// We try first without resizing, then if we fail we resize the chunk
	//  and try again
	while(1) {
		
		// Disable write-protection while we modify this resource
		err = DmWriteCheck(gP->p3Data.macrosP, 0, size);
		if (err) goto UnlockAndExit;
		
		MemSemaphoreReserve(true);
		err = P3AddMacro(&gP->p3Data, (BytePtr)nameP, macroDataP, dataLen,
				&size);
		if (err) err = PrvTranslateError(err);
		MemSemaphoreRelease(true);

		
		// Done if no error, no more retries, or invalid err
		if (err==0 || !retry || (err && err != grfErrMacroPtrTooSmall)) break;


		// If there was a size error, resize and try again
		PrvExit(gP);
		newH = DmResizeResource(gP->macrosH, size);
		if (!newH) {
			err = DmGetLastErr(); 
			goto Exit; 
			}
		gP->macrosH = newH;
		PrvEntry(gP);
		
		// Only allowed one retry
		retry = false;
		} 
	
				
UnlockAndExit:
	// Unlock
	PrvExit(gP);
	
	// Update the modification date on the ShortCuts database manually since we
	// leave it open and mod dates normally don't get updated until a database is
	// closed. <ROM2.0>
	DmOpenDatabaseInfo(gP->macrosDbP, &dbID, 0, 0, &cardNo, 0);
	modDate = TimGetSeconds();
	DmSetDatabaseInfo(cardNo, dbID, 0, 0, 0, 0,
							&modDate, 0,
							0, 0, 0, 0, 0);
	

Exit:
	return err;
}





/************************************************************
 *
 *  FUNCTION: PrvEntry
 *
 *  DESCRIPTION: Called at the beginning of every Graffiti call. This
 *		routine locks down the engine globals, template and dictionary
 *		handles and sets up the p3Data structure.
 *
 *  PARAMETERS: 
 *		gP - pointer to Graffiti globals.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: System startup code
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvEntry(GrfGlobalsPtr	gP)
{
	ErrFatalDisplayIf(!gP, "Grf not init.");
	
	gP->p3Data.privateP = MemHandleLock(gP->globalsH);
	gP->p3Data.glyphsP = MemHandleLock(gP->templateH);
	gP->p3Data.dictionaryP = MemHandleLock(gP->dictH);
	if (gP->macrosH) 
		gP->p3Data.macrosP = MemHandleLock(gP->macrosH);
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvExit
 *
 *  DESCRIPTION: Called at the end of every Graffiti call. This
 *		routine unlocks the handles used by Graffiti.
 *
 *  PARAMETERS: 
 *		gP - pointer to Graffiti globals.
 *
 *  RETURNS: 0 if no error
 * 
 *  CALLED BY: System startup code
 *
 *  CREATED: 6/30/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvExit(GrfGlobalsPtr	gP)
{
	ErrFatalDisplayIf(!gP, "Grf not init.");
	
	MemPtrUnlock(gP->p3Data.privateP); 
	MemPtrUnlock(gP->p3Data.glyphsP);
	MemPtrUnlock(gP->p3Data.dictionaryP);
	if (gP->p3Data.macrosP)
		MemPtrUnlock(gP->p3Data.macrosP);
		
	return 0;
}


/************************************************************
 *
 *  FUNCTION: PrvTranslateErr
 *
 *  DESCRIPTION: Called internally to translate an internal
 *		Graffiti error into a Pilot error code
 *
 *  PARAMETERS: 
 *		err		- Error code from Graffiti engine
 *
 *  RETURNS: Pilot error code
 * 
 *  CALLED BY: All Graffiti Glue functions
 *
 *  CREATED: 8/29/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvTranslateError(Err err)
{
	// Negative error codes are definitely Graffiti internal
	if (err < 0) return (grfErrorClass | (-err));
	
	// Positive are Internal Graffiti warnings
	return (grfErrorClass | (grfWarningOffset + err));
}


/************************************************************
 *
 *  FUNCTION: PrvUpdateIndicator
 *
 *  DESCRIPTION: Called internally to update the Griffiti
 *		shift state indicator.
 *
 *  PARAMETERS:  
 *		gP - pointer to Graffiti globals.
 *
 *  RETURNS: Pilot error code
 * 
 *  CALLED BY: Graffiti Glue functions that change the lock and 
 *		shift states.
 *
 *  CREATED: 8/30/95
 *
 *  BY: Art Lamb
 *
 *************************************************************/
static void PrvUpdateIndicator (GrfGlobalsPtr gP)
{
	Word lockFlags = 0;
	
	if (gP->state.lockFlags & kP3DictFlagsCapsLock)
		lockFlags |= glfCapsLock;
		
	if (gP->state.lockFlags & kP3DictFlagsNumLock) {
		lockFlags |= glfNumLock;
		
		// If we're in split mode, we don't ever show the numLock indicator so
		//  instead we show whether or not we'll be in CapsLock when the user types
		//  in the alpha side.
		if (gP->restoreCaps && gP->splitMode)
			lockFlags |= glfCapsLock;
		}
		
		
	// If we're in split-mode, don't ever tell the UI about numLock 
	if (gP->splitMode) 
		lockFlags &= ~glfNumLock;
	
	GsiSetShiftState (lockFlags, gP->shiftState);
}