/*******************************************************************  
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		MemoryMgrNew.c
 *
 * Description:
 *		New Memory Manager for Pilot. This version supports heaps of >64K in size. 
 *
 * History:
 *   	10/25/94		RM		- Created by Ron Marianetti
 *		5/3/95		VMK	- Modified MemMove to handle overlapping ranges
 *		11/11/96		RM		- Modified to support >64K heaps
 *
 *******************************************************************/


#include <SysAll.h>
#include <Crc.h>


// Don't include unless building version 2 of the Memory manager
#if 	MEMORY_VERSION == MEMORY_VERSION_2 



#define	NON_PORTABLE
#include <SystemPrv.h>
#include <HardwarePrv.h>

#define 	memFillFreeValue 0x5555


/********************************************************************
 * Memory Manager Private Routines
 ********************************************************************/
static MemHeapHeaderPtr
		PrvHeapPtrAndID(Ptr chunkDataP, UInt* heapIDP);

static MemHeapHeaderPtr  
		PrvGetHeapPtr(UInt heapID, UIntPtr saveDSP);

static Err 
		PrvCompactHeap(MemHeapHeaderPtr heapP);

static MemChunkHeaderPtr  
		PrvFindBiggestMovableChunk(MemChunkHeaderPtr startP, DWord maxSize);

static void  
		PrvMoveChunk(MemChunkHeaderPtr dstChunkP, MemChunkHeaderPtr srcChunkP);

static CardHeaderPtr 
		PrvGetCardHeaderInfo(UInt cardNo, CardInfoPtr* cardInfoPP, Boolean* ramOnlyCardP);
		
static Err 
		PrvInitHeapPtr(MemHeapHeaderPtr heapP, ULong size, UInt numHandles, Boolean zeroData);

static void 
		PrvUnlockAllChunks(UInt heapID);

static Err  
		PrvFreeChunkPtr(MemChunkHeaderPtr chunkP);

static void  
		PrvAdjustForNewAddress(UInt heapID);


static DWord	
		PrvCalcStoreCRC(StorageHeaderPtr storeP);

static void 
		ThisShouldGenerateALinkError(void);

static UInt 
		PrvCurOwnerID(void);

static DWord 
		PrvHostToTargetOffset(DWord hostOffset, CardInfoPtr infoP);

static DWord 
		PrvTargetToHostOffset(DWord hostOffset, CardInfoPtr infoP);

static void 
		PrvDebugAction(UInt heapID, VoidPtr p, VoidHand h, 
				Boolean alwaysScramble, Boolean postModify);

static void
		PrvFillFreeChunks(UInt heapID);

static UInt
		PrvHeapScramble(MemHeapHeaderPtr heapP, DWord firstOffset, DWord lastOffset);


static VoidPtr	
		PrvChunkNew(UInt heapID, ULong reqSize, UInt attributes);

static Err			
		PrvChunkFree(VoidPtr p);

static Err		
		PrvPtrResize(VoidPtr chunkDataP, ULong newSize);


static Err	
		PrvPtrUnlock(VoidPtr p);

static VoidPtr	
		PrvHandleCheck(Handle	h);
		
static MemChunkHeaderPtr		
		PrvPtrCheck(VoidPtr p);
		



/************************************************************
 *
 *  FUNCTION: MemNumCards 
 *
 *  DESCRIPTION: Returns the number of Memory card slots in the system.
 *   Not all of the slots need to be populated.
 *
 *  PARAMETERS: 
 *
 *  RETURNS: Number of slots
 *
 *  CREATED: 6/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemNumCards(void)
{
	return GMemCardSlots;
}


/************************************************************
 *
 *  FUNCTION: MemFormatCard
 *
 *  DESCRIPTION: Initializes a card's RAM area to empty heaps
 *		If the card is an all-RAM card, it also sets up the card's
 *		header.
 *
 *  PARAMETERS: 
 *		cardNo		 	-> either 0 or 1
 *		cardNameP 		-> card header name if it's RAM only card
 *		manufNameP		-> card header manufacturer name if it's RAM only card
 *		ramStoreNameP	-> name to give RAM store
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 10/27/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
#define	kMaxBlocks		8						// Max # of discontiguous RAM blocks

Err		MemCardFormat(UInt cardNo, CharPtr cardNameP, 
					CharPtr manufNameP, CharPtr ramStoreNameP)
{
	WordPtr					wP;

	Int						i;
	
	StorageHeaderPtr		ramStoreP;
	DWord						ramStoreOffset;
	Boolean					ramOnlyCard;
	CardHeaderPtr			cardP;
	
	UInt						numBlocks;
	DWordPtr					physBlockInfoP;
	DWord						logBlockInfo[kMaxBlocks*2];
	

	DWord						firstHeapSize;
	
	Err						error;
	CardInfoPtr				cardInfoP;
	
	Err						err;
	UInt						firstHeapMasterPtrs;
	


	// Wait for ownership
	MemSemaphoreReserve(true);

	
	// Get the card info
	cardP = PrvGetCardHeaderInfo(cardNo, &cardInfoP, &ramOnlyCard);
	if (!cardP) {err = -1; goto Exit;}
	

	// Get pointer to the RAM Store structure on this card
	ramStoreP = cardInfoP->ramStoreP;
	ramStoreOffset = MemPtrToLocalID(ramStoreP);
	

	// If it's a RAM only card, init the card header
	if (ramOnlyCard) {
		
		cardP->initStack = 0;
		cardP->resetVector = 0;
		cardP->signature = sysCardSignature;
		cardP->hdrVersion = 1;
		cardP->flags = memCardHeaderFlagRAMOnly;
		StrCopy((CharPtr)cardP->name, cardNameP);
		StrCopy((CharPtr)cardP->manuf, manufNameP);
		cardP->version = 1;
		cardP->creationDate = 0x12345678L;
		cardP->numRAMBlocks = 1;
		cardP->blockListOffset = (DWord)(&cardP->reserved[0]) - (DWord)(cardInfoP->baseP);
		
		physBlockInfoP = (DWordPtr)(cardInfoP->baseP + cardP->blockListOffset);
		*physBlockInfoP++ = 0;
		*physBlockInfoP++ = cardInfoP->firstRAMBlockSize;
		}



	//------------------------------------------------------------
	// Initialize the RAM Storage Header
	//------------------------------------------------------------
	// Get pointer to the RAM Block list
	numBlocks = cardP->numRAMBlocks;
	if (numBlocks) {
		DWord		rtcHours, rtcHourMinSecCopy;
		
		// Save some of the non-volatile params
		rtcHours = ramStoreP->nvParams.rtcHours;
		rtcHourMinSecCopy = ramStoreP->nvParams.rtcHourMinSecCopy;
		if (rtcHours < 0x000C67F8 || rtcHours > 0x00111ee8) 
			rtcHours = 0x000C92D0;		// 1/1/98; 12/1/97 was 0x000C8FE8
	
		// Clear the RAM Storage header
		wP = (WordPtr)(ramStoreP);
		for (i=0; i<sysStoreHeaderSize/2; i++)
			*wP++ = 0;
	
	
		// Init the RAM Storage header
		ramStoreP->signature = sysStoreSignature;
		ramStoreP->version = 1;
		ramStoreP->flags = memStoreHeaderFlagRAMOnly;
		StrCopy((CharPtr)ramStoreP->name, ramStoreNameP);
		ramStoreP->creationDate = 0;
		ramStoreP->backupDate = 0;
		ramStoreP->heapListOffset = ramStoreOffset + sysStoreHeaderSize;
		ramStoreP->initCodeOffset1 = 0;
		ramStoreP->initCodeOffset2 = 0;
		ramStoreP->databaseDirID = 0;
		ramStoreP->rsvSpace = cardInfoP->rsvSpace;
		ramStoreP->dynHeapSpace = cardInfoP->dynHeapSpace;
		ramStoreP->nvParams.rtcHours = rtcHours;			 
		ramStoreP->nvParams.rtcHourMinSecCopy = rtcHourMinSecCopy;			 
		
		// Make copy of cardinfo firstRAMBlockSize so that we can detect
		//  when we're rebooting with a different amount of RAM and consequently
		//  re-format the RAM area. This is probably only applicable during development
		//  when we're occasionally using part of RAM to hold the ROM image. 
		//  ROMSysLaunch compares this field in the store header with it's
		//  calculated RAM size in order to determine if the store header is valid.
		ramStoreP->firstRAMBlockSize = cardInfoP->firstRAMBlockSize;
	
	
		// Create the BlockInfo array for this card by starting with the
		//  block info as defined in the card header, mapping it to
		//  logical addresses, and then removing blocks for the reserve bytes 
		//  at the start of the RAM store.
		// 
		//  NOTE: The HwrGetRAMMapping call always creates
		//  a logical block that starts at the RAM Store Header location. That way, it
		//  is easier to find and skip the store header area when creating the heaps in 
		//  MemStoreInit(). 
		physBlockInfoP = (DWordPtr)MemLocalIDToPtr(cardP->blockListOffset, cardNo);
		HwrGetRAMMapping((Ptr)cardInfoP, &numBlocks, physBlockInfoP, logBlockInfo);
				
				
		// Remove a chunk from first block for the system reserved area
		logBlockInfo[0] += cardInfoP->rsvSpace;
		logBlockInfo[1] -= cardInfoP->rsvSpace;
		
		
		// Figure out the desired size of the first heap (the dynamic heap if card 0)
		if (cardInfoP->dynHeapSpace)
			firstHeapSize = cardInfoP->dynHeapSpace;
		else
			firstHeapSize = 0;			// use all available space and create 1 heap
			
		
		//------------------------------------------------------------
		// Init the RAM heap list and the RAM heaps. This routine takes a number
		// of arguments:
		//
		//    firstHeapSize 			- size of first heap (special for dynamic heap in card 0)
 		//		firstHeapMstrPtrs 	- A way to change the initial # of master ptrs
 		//										for the first heap. Used for setting the # of master
		//										pts for the dynamic heap differently than for the
 		//										storage heaps.
 		//		cardNo 					- which card number store is in
		//		numBlocks 				- number of memory blocks on card
		//    logBlockInfo			- array of block pointers and block sizes for the RAM area
		//    ramStoreP 				-  MemStoreInit will use this pointer as a designation
		//										 of a NO-HEAP-ZONE.
		//    memMstrPtrTableInitSizeS - - Number of master pointers to pre-allocate in each heap
 		//									after the first heap
		//
		//       
		//------------------------------------------------------------
		if (cardNo == 0) firstHeapMasterPtrs = memMstrPtrTableInitSizeD;
		else firstHeapMasterPtrs = memMstrPtrTableInitSizeS;
		error = MemStoreInit(firstHeapSize, firstHeapMasterPtrs,
					cardNo,  numBlocks,  logBlockInfo,
					ramStoreP, 
					memMstrPtrTableInitSizeS);
					
		// If no error, set the ramStore crc
		if (!error) ramStoreP->crc = PrvCalcStoreCRC(ramStoreP);
		}
	else
		error = memErrNoRAMOnCard;
					
					
Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	return error;
}




/************************************************************
 *
 *  FUNCTION: MemStoreInit
 *
 *  DESCRIPTION: Initializes a memory store on a card by setting up
 *   the heap list given the block list and intializing all the heaps.
 *
 *   This routine assumes that THERE IS A MEMORY BLOCK THAT STARTS AT
 *		storeP. It further assumes that the heapListOffset of the store
 *    header has already been initialized to be the first free byte in 
 *		this memory block after the store header and whatever other data 
 *    may be stored after the store headser. 
 *
 *    Using these assumptions makes it easy to skip the first N bytes of that
 *    block when allocating heaps, where N is the size of the store header 
 *		+ reserve bytes +  heap list (size determined by this routine).
 *
 *   The firstHeapSize parameter is used to create the desired dynamic heap
 *    size when initializing card 0.
 *    
 *
 *  PARAMETERS: 
 *			firstHeapSize 	- A way to change the size of the first heap. Used
 *									for setting the size of the dynamic heap in card 0.
 *									Pass 0 to make the first heap as large as possible.
 *			firstHeapMstrPtrs 	- A way to change the initial # of master ptrs
 *									for the first heap. Used for setting the # of master
 *									pts for the dynamic heap differently than for the
 *									storage heaps.
 *			cardNo 			- which card number store is in
 *			numBlocks 		- number of memory blocks on card
 *			blockInfoP 		- pointer to array of block ptr/block size pairs
 *			storeP   		- pointer to where storage header is on card. No heaps
 * 								will be placed over the storage header
 *			numMstrPtrs    - Number of master pointers to pre-allocate in each heap
 *									after the first heap.
 *
 *  NOTE: If numMstrPtrs is nil, it is assumed that the store is a ROM
 *   store so the read only bit will be set in the heap headers
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 10/27/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemStoreInit(DWord firstHeapSize, UInt firstHeapMstrPtrs, 
						UInt cardNo,  Word numBlocks, DWordPtr blockInfoP, 
						StorageHeaderPtr storeP, Word numMstrPtrs)
{
	BytePtr					heapStart;
	ULong						heapSize;
	
	DWord						blockSize;
	
	UInt						numHeaps;
	HeapListType*			heapListP;
	
	UInt						maxHeaps;
	Word						saveNumBlocks;
	DWordPtr					saveBlockInfoP;
	
	DWord						rsvSize;
	CardInfoPtr				infoP;
	
	Boolean					initContents;
	UInt						masterPtrs;


	// Wait for ownership
	MemSemaphoreReserve(true);

	// Get the card info
	infoP = memCardInfoP(cardNo);

	// Put in default firstHeapSize, if necessary
	if (!firstHeapSize)	firstHeapSize = 0x00FFFFFF;

	//--------------------------------------------------------------
	// Do a pre-flight check to see how many heaps we can make - this
	//  is so we reserve the right amount of space for the heap list
	//   at the front of the first block
	//--------------------------------------------------------------
	maxHeaps = 0;
	saveNumBlocks = numBlocks;
	saveBlockInfoP = blockInfoP;
	
	// DOLATER... in a number of places, this routine tests the block size to contain
	// at least 0x100 bytes;  however, our default master pointer table sizes can be several
	// times greater than that.  If a memory card image contains multiple RAM blocks, the heap
	// could be formatted incorrectly.  vmk 1/2/98

	blockSize = blockInfoP[1];
	while(numBlocks) {
		
		// If not enough room left in this block for another heap, go
		// on to the next block
		if (blockSize <= 0x100) {
			numBlocks--;
			if (numBlocks <= 0) break;
			blockInfoP += 2;
			blockSize = blockInfoP[1];
			}

		// If this is the first heap, allocate the desired amount
		if (maxHeaps == 0)
			heapSize = firstHeapSize;
			
		// Else, allocate the default
		else
			heapSize = blockSize;
			
		// Clip to the available space in the block
		if (heapSize > blockSize) heapSize = blockSize;
			
		blockSize -= heapSize;
		maxHeaps++;
		}
		
	numBlocks = saveNumBlocks;
	blockInfoP = saveBlockInfoP;


	//--------------------------------------------------------------
	// Now, do the real thing and init each heap
	//--------------------------------------------------------------
	heapListP = (HeapListType*)MemLocalIDToPtr(storeP->heapListOffset, cardNo);
	heapListP->numHeaps = numHeaps = 0;
	
	// Figure out how much space we need for the storage header, other
	//  stuff, heapList area.
	rsvSize = (DWord)heapListP 
					+ sizeof(HeapListType) +  maxHeaps * sizeof(DWord)
					- (DWord)storeP;
					
	
	// For the first time through loop, 
	blockSize = 0;

	while(numBlocks || blockSize>0) {
		
		// If not enough room left in this block for another heap, go
		// on to the next block
		if (blockSize <= 0x100) {
			if (numBlocks <= 0) break;
			
			// Get next block info
			heapStart = (BytePtr)blockInfoP[0];
			blockSize = blockInfoP[1];
			blockInfoP += 2;
			numBlocks--;
			if (blockSize <= 0x100) continue;
			
			// If this block is where the store header is, start the heap
			//  after the store header.
			if (heapStart == (BytePtr)storeP) {
				heapStart += rsvSize;
				blockSize -= rsvSize;
				}
			}

		// DOLATER... code here assumes that there is going to be only one dynamic heap;
		// code elsewhere in the module tries to support the possibility of more than one
		// dynamic heap.  This is something to be aware of.  vmk 1/2/98

		// If this is the first heap, allocate the desired amount
		initContents = true;
		if (numHeaps == 0) {
			heapSize = firstHeapSize;
			masterPtrs = firstHeapMstrPtrs;
			if (cardNo == 0) initContents = false;
			}
			
		// Else, allocate the default
		else {
			heapSize = blockSize;
			masterPtrs = numMstrPtrs;
			}
			
		// Clip to the available space in the block
		if (heapSize > blockSize) {
			masterPtrs = (ULong)masterPtrs * (ULong)blockSize / (ULong)heapSize;
			heapSize = blockSize;
			}
			
						
		// Take this heap space out of the block
		blockSize -= heapSize;

		// Store the heap offset in the card's RAM heap list
		heapListP->heapOffset[numHeaps++] = MemPtrToLocalID(heapStart);

		// Init the heap. If it's not the dynamic heap, init the contents too.
		PrvInitHeapPtr((MemHeapHeaderPtr)heapStart, heapSize, masterPtrs, initContents);

		// offset to next heap
		heapStart += heapSize;
		}

	// Store the number of heaps created in the first word of the heap list
	heapListP->numHeaps = numHeaps;


	// Release ownership
	MemSemaphoreRelease(true);

	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemStoreSearch
 *
 *  DESCRIPTION: Searches the given address range for a Memory Store. This
 *   Routine looks at every 4K boundary within the memory range for the start
 *   of a Memory Store and returns the pointer to the store if found. A store
 *   must have a valid signature and CRC check.
 *
 *  PARAMETERS: 
 *			startP 			- address to start looking at
 *			range 			- range of addresses
 *			*storePP 		- return pointer to store, if found
 *
 *  RETURNS: 0 if no error (found)
 *
 *  CREATED: 5/2/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemStoreSearch(VoidPtr startP, DWord range, StorageHeaderPtr* storePP)
{
	DWord						blockSize = 0x1000;
	BytePtr					p, lastP;
	StorageHeaderPtr		storeP;
	
	// Start at the first boundary
	p = (BytePtr)startP;
	
	// Figure out the last valid block to check
	lastP = (BytePtr)startP + range - blockSize;
	
	// Scan for a signature
	for (; p <= lastP; p += blockSize) {
		storeP = (StorageHeaderPtr)p;
		
		// Validate the signature
		if (storeP->signature != sysStoreSignature) continue;
		
		// Validate the checksum
		if (storeP->crc != PrvCalcStoreCRC(storeP)) continue;
		
		// Found!!
		*storePP = storeP;
		return 0;
		}
		
	// Not Found
	return memErrNoStore;
	
}


/************************************************************
 *
 *  FUNCTION: MemInit
 *
 *  DESCRIPTION: Called by the system during Reset. This function
 *		scans both memory cards for heaps and builds the Memory Manager's
 *		heap list. It also initializes the Pilot globals to 0.
 *
 *  PARAMETERS:  
 *		reserveBytes	-> how many bytes to reserve before RAM heap list 
 *								  and heap #0.
 *							   if 0xFFFFFFFF specified, the default value of sysLowMemSize 
 *									will be used.
 *
 *  RETURNS: void
 *
 *  CREATED: 10/27/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemInit(void)
{
	Int						i, numHeaps, card;
	UInt						heapID;
	Boolean					ramOnlyCard0 = false;
	CardHeaderPtr			cardP;
	CardInfoPtr				cardInfoP, infoP;
	

	//------------------------------------------------------------
	// Make sure the globals have been setup
	//------------------------------------------------------------
	ErrFatalDisplayIf(GMemCardInfoP==0, "MemCardInfoP global not init.");



	//------------------------------------------------------------
	// See if card 0 is a RAM only card (only possible under
	//  emulation mode)
	//------------------------------------------------------------
	// Get the card header
	cardP = PrvGetCardHeaderInfo(0, &cardInfoP, &ramOnlyCard0);
	

	//------------------------------------------------------------
	// Check to make sure our globals didn't grow too much.
	// We reserve more than enough space for our globals so that we
	//  can add more globals in the future without having to re-format 
	//  existing memory cards.
	//------------------------------------------------------------
	i = sizeof(LowMemType);
	if (sizeof(LowMemType) > sysLowMemSize)
		ThisShouldGenerateALinkError();
		

	//------------------------------------------------------------
	// Create the Global Heap Info table for each card
	//------------------------------------------------------------
	infoP = memCardInfoP(0);
	for (card=0; card<GMemCardSlots; card++) {
		if (infoP->size)  
			MemInitHeapTable(card);
		infoP++;
		}
			

	//------------------------------------------------------------
	// Re-Init the dynamic heaps 
	//------------------------------------------------------------
	for (i=0; i<memDynamicHeaps; i++) {
		MemHeapHeaderPtr heapP;
		
		// Re-initialize the dynamic heap size, in case it got trashed
		//  last time due to some memory trashing error. This is a kind of hack
		//  and only works if there is 1 dynamic heap. If we later support
		//  more than 1 dynamic heap, this will have to be more general.
		infoP = memCardInfoP(0);
		heapP = MemHeapPtr(i);
		heapP->size = infoP->dynHeapSpace;
		MemHeapInit(i, memMstrPtrTableInitSizeD, false);
		}



	//------------------------------------------------------------
	// Go through and unlock all movable chunks in other heaps and
	//  adjust heaps for their new address, in case it changed
	//------------------------------------------------------------
	infoP = memCardInfoP(0);
	for (card = 0; card < GMemCardSlots; card++) {
		if (!infoP->size)  continue;
		
		numHeaps = MemNumRAMHeaps(card);  
		for (i=0; i<numHeaps; i++) {
			heapID = MemHeapID(card, i);
			PrvUnlockAllChunks(heapID);
			PrvAdjustForNewAddress(heapID);
			MemHeapCompact(heapID);
			}
			
		infoP++;
		}


	return 0;


}

/************************************************************
 *
 *  FUNCTION: MemKernelInit
 *
 *  DESCRIPTION: Called by the system after MemInit and after 
 *		the multi-tasking kernel has been installed. This routine will 
 *    setup the semaphore(s) that the Memory Manager uses to share
 *    heaps among tasks.
 *
 *  PARAMETERS:  
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 5/10/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemKernelInit(void)
{
	DWord				tag = 'MemM';
	Err 				err;
	
	// Create the Memory Manager semaphore. We use a semaphore so that we 
	// don't get switched out in the middle of modifying a heap
	err = SysResSemaphoreCreate((DWordPtr)&GMemSemaphoreID, &tag);
	if (err) DbgBreak();
	
	return err;
}




/************************************************************
 *
 *  FUNCTION: MemHeapInitTable
 *
 *  DESCRIPTION: Called by the system during Reset. This function
 *		builds the global heap info table up for the given card. This
 *		table contains the address of each heap.
 *
 *  PARAMETERS: card number
 *
 *  RETURNS: void
 *
 *  CREATED: 10/27/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemInitHeapTable(UInt cardNo)
{
	StorageHeaderPtr		storeP;
	
	Boolean					ramOnlyCard;
	HeapListType*			heapListP;
	
	CardHeaderPtr			cardP;
	CardInfoPtr				cardInfoP;
	


	// Get pointer to the card header
	cardP = PrvGetCardHeaderInfo(cardNo, &cardInfoP, &ramOnlyCard);
	if (!cardP) return 0;
	

	// Check the validity of the RAM store header
	storeP = cardInfoP->ramStoreP;
	if (storeP) {
		if (storeP->signature != sysStoreSignature) 
			MemCardFormat(cardNo,  (CharPtr)"PalmCard", 
						(CharPtr)"Palm Computing", (CharPtr)"RAM Store");
		}


	// Get the pointer to the RAM heap list offset table on the card
	heapListP = (HeapListType*)MemLocalIDToPtr(storeP->heapListOffset, cardNo);
	
	
	// Cache the heap info in the card info
	cardInfoP->numRAMHeaps = heapListP->numHeaps;
	cardInfoP->ramHeapOffsetsP = (DWordPtr)&heapListP->heapOffset[0];
	

	//------------------------------------------------------------
	// Append the ROM heaps after the RAM heaps
	//------------------------------------------------------------
	cardInfoP->numROMHeaps = 0;
	if (!ramOnlyCard) {
		storeP = (StorageHeaderPtr)MemLocalIDToPtr(cardInfoP->cardHeaderOffset + sysROMStoreRelOffset, cardNo);
		if (storeP->heapListOffset) {
			heapListP = (HeapListType*)MemLocalIDToPtr(storeP->heapListOffset, cardNo);
			
			cardInfoP->numROMHeaps = heapListP->numHeaps;
			cardInfoP->romHeapOffsetsP = (DWordPtr)&heapListP->heapOffset[0];
			}
		}
			
	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemCardInfo
 *
 *  DESCRIPTION: Returns the info on a card
 *
 *  PARAMETERS: card number, pointers to return variables
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemCardInfo(UInt cardNo, CharPtr nameP, CharPtr manufNameP,
				UIntPtr versionP, ULongPtr crDateP,
				ULongPtr romSizeP, ULongPtr ramSizeP,
				ULongPtr freeBytesP)
{
	
	// Get the card header pointer
	CardHeaderPtr			cardP;
	Boolean					ramCard;
	StorageHeaderType*	storeP;
	
	HeapListType*			heapListP;
	MemHeapHeaderPtr			heapP;
	ULong						romSize, ramSize;
	UInt						i, heapID;
	ULong						free, max, freeSize, numHeaps;
	
	DWordPtr					blockListP;
	CardInfoPtr				cardInfoP;
	

	// Get card info
	cardP = PrvGetCardHeaderInfo(cardNo, &cardInfoP, &ramCard);
	if (!cardP) 
		return memErrNoCardHeader;
		
	if (cardP->signature != sysCardSignature) 
		return memErrNoCardHeader;
		

	// Get info
	if (nameP)
		StrCopy(nameP, (CharPtr)cardP->name);
		
	if (manufNameP)
		StrCopy(manufNameP, (CharPtr)cardP->manuf);
		
	if (versionP)
		*versionP = cardP->version;
		
	if (crDateP)
		*crDateP = cardP->creationDate;
		
	if (romSizeP) {
		if (ramCard) *romSizeP = 0;
		else {
			storeP = (StorageHeaderType*)MemLocalIDToPtr(cardInfoP->cardHeaderOffset
							 + sysROMStoreRelOffset, cardNo);
		
		
			// Start with the card header, store header and RAM block list
			//  which are all stored next to each other starting at the cardHeader
			romSize = storeP->heapListOffset - cardInfoP->cardHeaderOffset;
			heapListP = (HeapListType*)MemLocalIDToPtr(storeP->heapListOffset, cardNo);
			numHeaps = heapListP->numHeaps;
			romSize += sizeof(HeapListType) + (numHeaps-1) * sizeof(DWord);
		
			for (i=0; i<numHeaps; i++) {
				heapP = (MemHeapHeaderPtr)MemLocalIDToPtr(heapListP->heapOffset[i], cardNo);
				romSize += heapP->size;
				if (!heapP->size) romSize += 0x010000L;
				}
		
			*romSizeP = romSize;
			}
		}
		
		
	// For RAM Size, just add the sizes of every block of RAM
	if (ramSizeP) {
		ramSize = 0;
		blockListP = (DWordPtr)MemLocalIDToPtr(cardP->blockListOffset, cardNo);
		for (i=0; i<cardP->numRAMBlocks; i++) {
			blockListP++;										// skip offset to block
			if (*blockListP != 0xFFFFFFFF)
				ramSize += *blockListP++;
			else
				ramSize += cardInfoP->firstRAMBlockSize;
			}
			
		*ramSizeP = ramSize;
		}
		
		
	// For free bytes, go through each RAM heap and accumulate the free bytes
	if (freeBytesP) {
		freeSize = 0;
		numHeaps = cardInfoP->numRAMHeaps;
		for (i=0; i<numHeaps; i++) {
			heapID = MemHeapID(cardNo, i);
			MemHeapFreeBytes(heapID, &free, &max);
			freeSize += free;
			}
			
		*freeBytesP = freeSize;
		}
			
	return 0;	
}




/************************************************************
 *
 *  FUNCTION: MemStoreInfo
 *
 *  DESCRIPTION: Returns the store information for either the
 *		ROM or RAM store on a memory card
 *
 *  PARAMETERS: card number, store number (0:ROM, 1:RAM), 
 *		references to return info variables any of which can be nil.
 *
 *  RETURNS: version number
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemStoreInfo(UInt cardNo, UInt storeNumber,
					UIntPtr versionP, UIntPtr flagsP, CharPtr nameP,
					ULongPtr	crDateP,  ULongPtr bckUpDateP,
					ULongPtr	heapListOffsetP, ULongPtr initCodeOffset1P,
					ULongPtr initCodeOffset2P, LocalID*	databaseDirIDP)
{
	Boolean				ramCard;
	StorageHeaderPtr	storeP;
	CardHeaderPtr		cardP;
	CardInfoPtr			cardInfoP;


	// Check bounds on the card number
	if (cardNo >= GMemCardSlots) return memErrCardNotPresent;
	

	//------------------------------------------------------------
	// Get the card Info.
	//------------------------------------------------------------
	cardP = PrvGetCardHeaderInfo(cardNo, &cardInfoP, &ramCard);
	
	// If it's a RAM only card, can't return info on ROM
	if (ramCard && storeNumber == 0) 
		return memErrRAMOnlyCard;
		
	
	// Get the offset to the store
	if (storeNumber == 0) 
		storeP = (StorageHeaderType*)MemLocalIDToPtr(cardInfoP->cardHeaderOffset
						 + sysROMStoreRelOffset, cardNo);
	else 
		storeP = cardInfoP->ramStoreP;
	

	if (storeP->signature != sysStoreSignature) 
		return memErrInvalidStoreHeader;


	// Return the info
	if (versionP) *versionP = storeP->version;
	if (flagsP) *flagsP = storeP->flags;
	if (nameP) StrCopy(nameP, (CharPtr)storeP->name);
	if (crDateP) *crDateP = storeP->creationDate;
	if (bckUpDateP) *bckUpDateP = storeP->backupDate;
	if (heapListOffsetP) *heapListOffsetP = storeP->heapListOffset;
	if (initCodeOffset1P) *initCodeOffset1P = storeP->initCodeOffset1;
	if (initCodeOffset2P) *initCodeOffset2P = storeP->initCodeOffset2;
	if (databaseDirIDP) 
		*databaseDirIDP = storeP->databaseDirID;

	return 0;
}


/************************************************************
 *
 *  FUNCTION: MemStoreSetInfo
 *
 *  DESCRIPTION: Sets the store information for the
 *		RAM store on a memory card
 *
 *  PARAMETERS: card number,  
 *		references to new info variables - any of which could be nil ptrs
 *
 *  RETURNS: version number
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err			MemStoreSetInfo(UInt cardNo, UInt storeNumber,
					UIntPtr versionP, UIntPtr flagsP,  CharPtr nameP, 
					ULongPtr crDateP, ULongPtr bckUpDateP, 
					ULongPtr heapListOffsetP, ULongPtr initCodeOffset1P,
					ULongPtr initCodeOffset2P, LocalID*	databaseDirIDP)
{
	Boolean				ramCard;
	StorageHeaderPtr	storeP;
	CardHeaderPtr		cardP;
	CardInfoPtr			cardInfoP;

	if (storeNumber == 0) return memErrWriteProtect;

	//------------------------------------------------------------
	// Get the card Info.
	//------------------------------------------------------------
	cardP = PrvGetCardHeaderInfo(cardNo, &cardInfoP, &ramCard);
	
	storeP = cardInfoP->ramStoreP;
	if (!storeP) return memErrNoRAMOnCard;
	
	if (storeP->signature != sysStoreSignature) 
		return memErrInvalidStoreHeader;


	// Wait for ownership
	MemSemaphoreReserve(true);


	// Set the info
	if (versionP)
		storeP->version = *versionP;
		
	if (flagsP) 
		storeP->flags = *flagsP;

	if (nameP)
		StrCopy((CharPtr)storeP->name, nameP);

	if (crDateP)
		storeP->creationDate = *crDateP;

	if (bckUpDateP)
		storeP->backupDate = *bckUpDateP;

	if (heapListOffsetP)
		storeP->heapListOffset = *heapListOffsetP;

	if (initCodeOffset1P)
		storeP->initCodeOffset1 = *initCodeOffset1P;

	if (initCodeOffset2P)
		storeP->initCodeOffset2 = *initCodeOffset2P;

	if (databaseDirIDP)
		storeP->databaseDirID = *databaseDirIDP;
		
		
		
	// Recalculate the crc check on this store and save it
	storeP->crc = PrvCalcStoreCRC(storeP);
	
	
	// Release ownership
	MemSemaphoreRelease(true);

	return 0;
}


/************************************************************
 *
 *  FUNCTION: MemNVParamInfo
 *
 *  DESCRIPTION: Used internally by other System code in order to
 *   get and set the System Non-volatile parameters. These parameters include
 *   the hours since Jan,1904 used for tracking the current
 *	  time and any other information that is inconvenient to store in
 *	  a database because it must be accessed or updated at interrupt time.
 *
 *	  The Non-volatile params are stored in the RAM store header on card #0
 *
 *   If called with set=false, this routine simply returns a copy of the current
 *	  params in *paramsP. If called with set=true, this routine
 *	  will change the current params to match what's in *paramsP.
 *
 *  PARAMETERS: 
 *		set	- if true, params will be changed according to *paramsP
 *				  if false, current params will be returned in *paramsP
 *		*paramsP - new params if set is true, returned params if set is false.
 *
 *  RETURNS: 0 if no error.
 *
 *  CREATED: 9/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err			MemNVParams(Boolean set, SysNVParamsPtr  paramsP)
{
	Boolean				ramCard;
	StorageHeaderPtr	storeP;
	CardHeaderPtr		cardP;
	CardInfoPtr			cardInfoP;
	SysNVParamsPtr		dataP;


	//------------------------------------------------------------
	// Get the card Info and then get the storage header for the
	// RAM store on card 0.
	//------------------------------------------------------------
	cardP = PrvGetCardHeaderInfo(0, &cardInfoP, &ramCard);
	
	storeP = cardInfoP->ramStoreP;
	if (!storeP) return memErrNoRAMOnCard;
	
	if (storeP->signature != sysStoreSignature) 
		return memErrInvalidStoreHeader;
		
		
	// Get ptr to NV Params
	dataP = &storeP->nvParams;
	
	
	// If setting, enable writes, set the data, and update the CRC
	if (set) {
		Boolean		restoreProtection;
		
		// Set new params
		restoreProtection = HwrEnableDataWrites();
		MemMove(dataP, paramsP, sizeof(SysNVParamsType));
		storeP->crc = PrvCalcStoreCRC(storeP);
		if (restoreProtection) HwrDisableDataWrites();
		}
		
	// If getting, copy data to caller's buffer
	else
		MemMove(paramsP, dataP, sizeof(SysNVParamsType));
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemNumHeaps
 *
 *  DESCRIPTION: Returns the number of heaps in the given card
 *
 *  PARAMETERS: card number
 *
 *  RETURNS: number of heaps
 *
 *  CREATED: 10/28/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemNumHeaps(UInt cardNo)
{
	CardInfoPtr	infoP;
	
	// Optimized for 2 cards only
	infoP = memCardInfoP(0);
	if (cardNo == 1)
		infoP++;
		
	return infoP->numRAMHeaps + infoP->numROMHeaps;
		
}


/************************************************************
 *
 *  FUNCTION: MemNumRAMHeaps
 *
 *  DESCRIPTION: Returns the number of RAM heaps in the given card
 *
 *  PARAMETERS: card number
 *
 *  RETURNS: number of RAM heaps
 *
 *  CREATED: 10/28/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemNumRAMHeaps(UInt cardNo)
{
	CardInfoPtr	infoP;
	
	// Optimized for 2 cards only
	infoP = memCardInfoP(0);
	if (cardNo == 1)
		infoP++;
		
	return infoP->numRAMHeaps ;
		
}



/************************************************************
 *
 *  FUNCTION: MemHeapID
 *
 *  DESCRIPTION: Returns the heap ID for a given card number and
 *		heap index.
 *
 *  PARAMETERS: card number, heap number
 *
 *  RETURNS: heapID
 *
 *  CREATED: 10/28/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt 	MemHeapID(UInt cardNo, UInt heapNo)
{
	if (cardNo == 0) return heapNo;
	else return heapNo | 0x8000;
}



/************************************************************
 *
 *  FUNCTION: MemHeapDynamic
 *
 *  DESCRIPTION: Returns true if the given heap is a dynamic heap
 *
 *  PARAMETERS: heapID
 *
 *  RETURNS: 
 *		true if dynamic, false if not.
 *
 *  CREATED: 8/1/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean 		MemHeapDynamic(UInt heapID)
{
	// This logic assumes heapID = heapIndex for card 0 and that
	//  all dynamic heaps are in card 0.
	if (heapID < memDynamicHeaps) return true;
	return false;
} 




/************************************************************
 *
 *  FUNCTION: MemHeapPtr
 *
 *  DESCRIPTION: Returns Pointer to heap given heap ID
 *
 *  PARAMETERS: card number, heap number
 *
 *  RETURNS: Heap Pointer, or nil
 *
 *  CREATED: 10/28/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr 		MemHeapPtr(UInt heapID)
{
	UInt						heapNo;
	CardInfoPtr				infoP;
	#if EMULATION_LEVEL != EMULATION_NONE
	DWord						offset;
	#endif

	heapNo = heapID & 0x7FFF;


	// Get the card Info pointer
	if (heapID & 0x8000) {
		ErrFatalDisplayIf(hwrNumCardSlots < 2, "Invalid Card #");
		infoP = memCardInfoP(1);
		}
	else
		infoP = memCardInfoP(0);
		
		
	//---------------------------------------------------------------
	// Under Emulation mode, we use the slower method which works for
	//   Memory card images with shifted ROM locations
	//---------------------------------------------------------------
	#if EMULATION_LEVEL != EMULATION_NONE
	
	// See which heap it is
	if (heapNo >= infoP->numRAMHeaps) {
		heapNo -= infoP->numRAMHeaps;
		ErrFatalDisplayIf(heapNo >= infoP->numROMHeaps, "Invalid heapID");
		offset = infoP->romHeapOffsetsP[heapNo];
		}
	else 
		offset = infoP->ramHeapOffsetsP[heapNo];
		
	offset = PrvTargetToHostOffset(offset, infoP);
	return (MemHeapHeaderPtr)(infoP->baseP + offset);
	
	
	#else
	//---------------------------------------------------------------
	// Under native mode, the pointer is simple the base address of the card
	//  + the heap offset.
	//---------------------------------------------------------------
	if (heapNo >= infoP->numRAMHeaps) {
		heapNo -= infoP->numRAMHeaps;
		ErrFatalDisplayIf(heapNo >= infoP->numROMHeaps, "Invalid heapID");
		return (MemHeapHeaderPtr)(infoP->baseP + infoP->romHeapOffsetsP[heapNo]);
		}
	else 
		return (MemHeapHeaderPtr)(infoP->baseP + infoP->ramHeapOffsetsP[heapNo]);

	#endif	
	
		
} 



/************************************************************
 *
 *  FUNCTION: MemHeapFreeBytes
 *
 *  DESCRIPTION: Computes the total amount of free space in a heap
 *
 *  PARAMETERS: heapID, reference to free bytes, largest free chunk
 *
 *  RETURNS: non-zero if error
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemHeapFreeBytes(UInt heapID, ULongPtr freeP, ULongPtr maxP)
{
	ULong							freeBytes = 0;
	MemHeapHeaderPtr		   	heapP;
	MemChunkHeaderPtr				chunkP;
	ULong							maxSize=0;
	DWord							size;

	// Wait for ownership
	MemSemaphoreReserve(false);


	// Get a near heap pointer from the heap ID 
	heapP = MemHeapPtr(heapID);


	// Start at the first chunk
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );

	// Walk the heap and accumulate sizes of free chunks
	while((size = chunkP->size) != 0) {

		// If it's a free chunk
		if (chunkP->free) {
			freeBytes += size;
			if (size - sizeof(MemChunkHeaderType) > maxSize)
				maxSize = size - sizeof(MemChunkHeaderType);
			}

		// Go on to next chunk
		chunkP = (MemChunkHeaderPtr) ((BytePtr)chunkP + size);
		}


	// Set return values
	*freeP = freeBytes;
	*maxP = maxSize;


	// Release ownership
	MemSemaphoreRelease(false);

	return 0;
}


/************************************************************
 *
 *  FUNCTION: MemHeapSize
 *
 *  DESCRIPTION: Returns the total size of the heap
 *
 *  PARAMETERS: heapID 
 *
 *  RETURNS: size, or 0 if error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
ULong 	MemHeapSize(UInt heapID)
{
	ULong							size = 0;
	MemHeapHeaderPtr		   	heapP;


	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);


	size = heapP->size;
	if (!size) size = 0x010000L;
		  

	// exit
	return size;
}


/************************************************************
 *
 *  FUNCTION: MemHeapFlags
 *
 *  DESCRIPTION: Returns the heap flags
 *
 *  PARAMETERS: heapID 
 *
 *  RETURNS: flags
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt 	MemHeapFlags(UInt heapID)
{
	UInt								flags;
	MemHeapHeaderPtr		   		heapP;



	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);


	flags = heapP->flags;
		  
	// return
	return flags;
}


/************************************************************
 *
 *  FUNCTION: MemHeapCompact
 *
 *  DESCRIPTION: Compacts a heap 
 *
 *  PARAMETERS: heap ID
 *
 *  RETURNS:
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemHeapCompact(UInt heapID)
{
	MemHeapHeaderPtr	heapP;
	Err				err;


	// Wait for ownership
	MemSemaphoreReserve(true);

	// Error Checking
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, true, false);

	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);
	err = PrvCompactHeap(heapP);

	// Error Checking
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, false, true);

	// Release ownership
	MemSemaphoreRelease(true);

	return err;
}


/************************************************************
 *
 *  FUNCTION: MemInitHeap
 *
 *  DESCRIPTION: Re-initializes a heap and accepts parameter
 *		for the number of offsets to reserve for movable chunks
 *
 *  PARAMETERS: heapID, number of offsets to reserve or -1
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/18/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	MemHeapInit(UInt heapID, Int numHandles, Boolean initContents)
{
	MemHeapHeaderPtr	heapP;
	ULong				size;
	Err				err;


	// Wait for ownership
	MemSemaphoreReserve(true);

	// Get a pointer to the heap
	heapP = MemHeapPtr(heapID);

	// if no numHandles, take existing value
	if (numHandles < 0) numHandles = heapP->mstrPtrTbl.numEntries;

	// Use the same size
	size = heapP->size;
	if (size == 0) size = 0x10000L;

	// Init it
	err = PrvInitHeapPtr(heapP, size, numHandles, initContents);

	// Error Checking
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, false, true);

	// Release ownership
	MemSemaphoreRelease(true);

	return err;
}


/************************************************************
 *
 *  FUNCTION: MemHeapFreeByOwnerID
 *
 *  DESCRIPTION: Scans the heap and frees all chunks with the
 *   given owner ID.
 *
 *  PARAMETERS: heapID, owner ID
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 4/13/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err  MemHeapFreeByOwnerID(UInt heapID, UInt ownerID)
{
	MemHeapHeaderPtr		heapP;
	MemChunkHeaderPtr		chunkP;
	Err					err;
	DWord					size;

	// Wait for ownership
	MemSemaphoreReserve(true);


	// Get a near heap pointer from the heapID
	heapP = MemHeapPtr(heapID);

	// Walk the heap and look for chunks with the given owner ID
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );

	while((size = chunkP->size) != 0) {
		if (chunkP->owner == ownerID)
			MemChunkFree((BytePtr)chunkP + sizeof(MemChunkHeaderType));

		// Go on to next chunk
		chunkP = (MemChunkHeaderPtr) ((BytePtr)chunkP + size);
		}
		
		
	// Compact the heap
	err = MemHeapCompact(heapID);


	// Release ownership
	MemSemaphoreRelease(true);

	return err;
}


/************************************************************
 *
 *  FUNCTION: MemChunkNew
 *
 *  DESCRIPTION: Allocates a new chunk in the given heap
 *
 *  PARAMETERS: heapID, size of chunk, chunk attribytes
 *		The chunk attributes can be one or more of:
 *			memNewChunkFlagNonMovable
 *			memNewChunkFlagParAlign
 *			ORed with the owner ID
 *			
 *
 *  RETURNS: ChunkID, or 0 if error
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr	MemChunkNew(UInt heapID, ULong reqSize, UInt attributes)
{
	VoidPtr						retP;


	// Wait for ownership
	MemSemaphoreReserve(true);

	// Debug mode
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, true, false);
	
	// Call guts
	retP = PrvChunkNew(heapID, reqSize, attributes);

	// Debug mode
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, false, true);
	
	// Release ownership
	MemSemaphoreRelease(true);


	// If we're allocating a handle, protect it
	if (retP && ((attributes & memNewChunkFlagNonMovable) == 0))
		return memHandleProtect(retP);
		
	else
		return retP;
}




/************************************************************
 *
 *  FUNCTION: MemChunkFree
 *
 *  DESCRIPTION: Disposes of a chunk
 *
 *  PARAMETERS: Chunk ID
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/02/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemChunkFree(VoidPtr p)
{
	Err			err;


	// Check for error
	if (! PrvPtrCheck(p)) 
		return memErrInvalidParam;


	// Wait for ownership
	MemSemaphoreReserve(true);

	// Error Checking
	if (GMemDebugMode) {
		UInt	heapID = MemPtrHeapID(p);
		PrvDebugAction(heapID, 0, 0, true, false);
	
		// Call guts
		err = PrvChunkFree(p);
		
		// Error Checking
		PrvDebugAction(heapID, 0, 0, false, true);
		}
		
	// Normal...
	else
		err = PrvChunkFree(p);
	
	// Release ownership
	MemSemaphoreRelease(true);
	
	return err;

}



/************************************************************
 *
 *  FUNCTION: MemPtrNew
 *
 *  DESCRIPTION: Allocates a non-movable chunk in the dynamic heap
 *
 *  PARAMETERS: requested size of chunk
 *
 *  RETURNS: ptr to chunk, or 0 if error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr	MemPtrNew(ULong size)
{
	VoidPtr						retP;


	// Wait for ownership
	MemSemaphoreReserve(false);

	// Error Checking
	if (GMemDebugMode) {
		PrvDebugAction(0, 0, 0, true, false);

		// Call guts
		retP = PrvChunkNew(0, size, memNewChunkFlagNonMovable | PrvCurOwnerID());
		
		// Error Checking
		PrvDebugAction(0, 0, 0, false, true);
		}
		
	// Normal..
	else 
		retP = PrvChunkNew(0, size, memNewChunkFlagNonMovable | PrvCurOwnerID());


	// Release ownership
	MemSemaphoreRelease(false);
	
	return retP;
}



/************************************************************
 *
 *  FUNCTION: MemPtrRecoverHandle
 *
 *  DESCRIPTION: recovers the handle to a movable chunk given the ptr
 *
 *  PARAMETERS: pointer to chunk data
 *
 *  RETURNS: Handle, or 0 if error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	MemPtrRecoverHandle(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr	chunkP;
	Ptr*				ptrP;
	SDWord			hOffset;

	// Check for errors and get chunk header
	if (! (chunkP = PrvPtrCheck(chunkDataP))) 
		return memHandleProtect(0);

	// Error Checking
	if (GMemDebugMode) PrvDebugAction(0, chunkDataP, 0, false, false);

	// Get it's handle
	if ((hOffset = chunkP->hOffset) != 0)  {
		ptrP = (Ptr*)((DWord)chunkP - (hOffset << 1));
		}
	else {
		ErrFatalDisplayIf(1, "Not a Handle");
		ptrP = 0;
		}

	return  memHandleProtect(ptrP);
}



/************************************************************
 *
 *  FUNCTION: MemPtrFlags
 *
 *  DESCRIPTION: Returns the flags for a chunk given the chunk data ptr
 *
 *  PARAMETERS: chunkID
 *
 *  RETURNS: chunk flags
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemPtrFlags(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr				chunkP;
	UInt							flags;

	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return 0;

	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, chunkDataP, 0, false, false);

	// Get the flags
	flags = memChunkFlags(chunkP);


	return flags;
} 


/************************************************************
 *
 *  FUNCTION: MemPtrSize
 *
 *  DESCRIPTION: Returns the requested size of a chunk
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: chunk size
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
ULong		MemPtrSize(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr				chunkP;
	ULong							size;


	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return 0;

	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, chunkDataP, 0, false, false);

	// Get the size
	size = chunkP->size - (chunkP->sizeAdj) - sizeof(MemChunkHeaderType);

	return size;
} 


/************************************************************
 *
 *  FUNCTION: MemPtrOwner
 *
 *  DESCRIPTION: Returns the owner ID of a chunk
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: owner ID
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemPtrOwner(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr				chunkP;
	UInt							owner;

	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return 0;

	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, chunkDataP, 0, false, false);

	// Get the owner
	owner = chunkP->owner;

	return owner;
} 



/************************************************************
 *
 *  FUNCTION: MemPtrHeapID
 *
 *  DESCRIPTION: Returns the heapID of a chunk
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: heap ID
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemPtrHeapID(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr		chunkP;
	UInt					heapID;
	
	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return 0;

	PrvHeapPtrAndID(chunkDataP, &heapID);

	return heapID;
} 


/************************************************************
 *
 *  FUNCTION: MemPtrDataStorage
 *
 *  DESCRIPTION: Returns true if the given pointer is part of a 
 *   Data Storage Heap, else it is a pointer in the dynamic heap.
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: true if part of a data storage heap
 *
 *  CALLED BY: Fields package to determine if it needs to worry
 *    about data storage write-protection when editing a text field.
 *
 *  CREATED: 5/8/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean 	MemPtrDataStorage(VoidPtr chunkDataP)
{
	MemChunkHeaderPtr		chunkP;
	UInt					heapID;
	
	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return false;

	// Get the heap ID
	PrvHeapPtrAndID(chunkDataP, &heapID);

	return (heapID != 0);
} 




/************************************************************
 *
 *  FUNCTION: MemPtrCardNo
 *
 *  DESCRIPTION: Returns the card number given a pointer to a chunk
 *
 *  PARAMETERS: chunk ID
 *
 *  RETURNS: card number
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	MemPtrCardNo(VoidPtr p)
{
	CardInfoPtr	infoP;
	UInt			i;


	// Search in each card
	infoP = memCardInfoP(0);
	for (i=0; i<GMemCardSlots; i++) {
		if (	(DWord)p > (DWord)infoP->baseP  &&  
				(DWord)p < (DWord)infoP->baseP + infoP->size) {
			// Heap Validity
			if (GMemDebugMode) PrvDebugAction(0, p, 0, false, false);
			return i;
			}
		infoP++;
		}
		
	ErrDisplay("Invalid Chunk Ptr");
	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemPtrSetOwner
 *
 *  DESCRIPTION: Sets the owner ID of a chunk
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemPtrSetOwner(VoidPtr chunkDataP, UInt owner)
{
	MemChunkHeaderPtr				chunkP;

	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return memErrInvalidParam;

	// Check arguments
	if (owner > 14) 
		return memErrInvalidParam;

	// Enable writes
	MemSemaphoreReserve(true);
	
	// Heap Validity
	if (GMemDebugMode)	PrvDebugAction(0, chunkDataP, 0, false, false);

	// Set the owner
	chunkP->owner = owner;

	// Restore write protection
	MemSemaphoreRelease(true);
	
	return 0;
} 


/************************************************************
 *
 *  FUNCTION: MemPtrResize
 *
 *  DESCRIPTION: Resizes a chunk
 *
 *  PARAMETERS: chunk data pointer, new size
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemPtrResize(VoidPtr chunkDataP, ULong newSize)
{
	MemChunkHeaderPtr		chunkP;
	Err					err;

	// Check for error
	if (! (chunkP = PrvPtrCheck(chunkDataP))) return memErrInvalidParam;

	// Wait for ownership
	MemSemaphoreReserve(true);

	// Error Checking
	if (GMemDebugMode) {
		UInt	heapID;
		heapID = MemPtrHeapID(chunkDataP);
		PrvDebugAction(heapID, 0, 0, true, false);
	
		// Call Guts
		err = PrvPtrResize(chunkDataP, newSize);
		
		// Heap Validity
		if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, false, true);
		}
		
	// Normal...
	else
		err = PrvPtrResize(chunkDataP, newSize);
		

	// Release ownership
	MemSemaphoreRelease(true);

	return err;
}



/************************************************************
 *
 *  FUNCTION: MemPtrUnlock
 *
 *  DESCRIPTION: Unlocks a chunk given a pointer to the chunk
 *
 *  PARAMETERS: pointer to chunk
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	MemPtrUnlock(VoidPtr p)
{
	MemChunkHeaderPtr				chunkP;
	Err							err;


	// Check for error
	if (! (chunkP = PrvPtrCheck(p))) return memErrInvalidParam;
	
	// Enable writes
	MemSemaphoreReserve(true);
	
	// DebugMode
	if (GMemDebugMode) {
		UInt	heapID;
		heapID = MemPtrHeapID(p);
	
		// Do it
		err = PrvPtrUnlock(p);
		
		// Thrash the heap
		PrvDebugAction(heapID, 0, 0, true, false);
		}
		
	// Normal..
	else
		err = PrvPtrUnlock(p);
	
	// Restore write-protection
	MemSemaphoreRelease(true);

	
	return err;
}



/************************************************************
 *
 *  FUNCTION: MemPtrResetLock
 *
 *  DESCRIPTION: Unlocks a chunk all the way to 0
 *
 *  PARAMETERS: handle to chunk
 *
 *  RETURNS:
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemPtrResetLock(VoidPtr p)
{
	MemChunkHeaderPtr				chunkP;
	UInt							heapID;


	// Check for error
	if (! (chunkP = PrvPtrCheck(p))) return memErrInvalidParam;

	// Enable writes
	MemSemaphoreReserve(true);
	
	
	// Save heapID if debug mode
	if (GMemDebugMode) heapID = MemPtrHeapID(p);
	
	
	// If movable, clear lock count
	if (chunkP->lockCount  != memPtrLockCount) {
		chunkP->lockCount = 0;
		}

	// Restore write-protection
	MemSemaphoreRelease(true);
	

	// Thrash the heap
	if (GMemDebugMode) PrvDebugAction(heapID, 0, 0, true, false);

	return 0;
}




/************************************************************
 *
 *  FUNCTION: MemHandleNew
 *
 *  DESCRIPTION: Allocates a movable chunk in the dynamic heap
 *
 *  PARAMETERS: requested size of chunk
 *
 *  RETURNS: ptr to chunk, or 0 if error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidHand	MemHandleNew(ULong size)
{
	Handle	h;


	// Wait for ownership
	MemSemaphoreReserve(false);

	// Error Checking
	if (GMemDebugMode) {
		PrvDebugAction(0, 0, 0, true, false);

		// Call guts
		h = PrvChunkNew(0, size, PrvCurOwnerID());
		
		// Error Checking
		PrvDebugAction(0, 0, 0, false, true);
		}
		
	// Normal
	else
		h = PrvChunkNew(0, size, PrvCurOwnerID());
		

	// Release ownership
	MemSemaphoreRelease(false);

	// Return result
	if (h) 
		return  memHandleProtect(h);
	else 
		return 0;
}


/************************************************************
 *
 *  FUNCTION: MemHandleFree
 *
 *  DESCRIPTION: Disposes of a movable chunk
 *
 *  PARAMETERS: Handle to chunk
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemHandleFree(VoidHand h)
{
	Err 		err;
	register Ptr	p;
	
	
	// Wait for ownership
	MemSemaphoreReserve(true);
	
	// Get pointer to the chunk and error check the handle
	if (! (p = PrvHandleCheck(h))) {err = memErrInvalidParam; goto Exit;}
	

	// Error Checking Mode
	if (GMemDebugMode) {
		UInt		heapID;
		
		// Thrash the heap
		heapID = MemPtrHeapID(p);
		PrvDebugAction(heapID, 0, 0, true, false);
		p = PrvHandleCheck(h);						// Re-get pointer
		
		// Free it
		err = PrvChunkFree(p);
		
		// Fill Free Chunks
		PrvDebugAction(heapID, 0, 0, false, true);
		}
		
	// Normal..
	else
		err = PrvChunkFree(p);
		
		
Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	
	// Exit
	return err;
}




/************************************************************
 *
 *  FUNCTION: MemHandleFlags
 *
 *  DESCRIPTION: Returns the flags for a chunk given the chunk handle
 *
 *  PARAMETERS: handle
 *
 *  RETURNS: chunk flags
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemHandleFlags(VoidHand h)
{
	UInt					flags;
	register VoidPtr	p;
	MemChunkHeaderPtr		chunkP;

	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {flags = 0; goto Exit;}
	
	// Get the flags
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	flags = *((BytePtr)chunkP);

Exit:
	// Release ownership
	MemSemaphoreRelease(false);
	
	return flags;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleSize
 *
 *  DESCRIPTION: Returns the requested size of a chunk
 *
 *  PARAMETERS: chunk handle
 *
 *  RETURNS: chunk size
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
ULong		MemHandleSize(VoidHand h)
{
	ULong						size;
	register VoidPtr		p;
	MemChunkHeaderPtr			chunkP;


	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {size = 0; goto Exit;}
	
	// Get the size
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	size = chunkP->size - (chunkP->sizeAdj) - sizeof(MemChunkHeaderType);


Exit:
	// Release ownership
	MemSemaphoreRelease(false);
	
	return size;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleOwner
 *
 *  DESCRIPTION: Returns the owner ID of a chunk
 *
 *  PARAMETERS: chunk data handle
 *
 *  RETURNS: owner ID
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemHandleOwner(VoidHand h)
{
	UInt					owner;
	register VoidPtr	p;
	MemChunkHeaderPtr		chunkP;

	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {owner = 0; goto Exit;}
	
	// Get the owner
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	owner = chunkP->owner;

Exit:
	// Release ownership
	MemSemaphoreRelease(false);

	return owner;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleLockCount
 *
 *  DESCRIPTION: Returns the lock count of a chunk
 *
 *  PARAMETERS: Handle to chunk
 *
 *  RETURNS: lock count
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemHandleLockCount(VoidHand h)
{
	MemChunkHeaderPtr		chunkP;
	UInt					lock;
	register BytePtr	p;

	// Wait for ownership
	MemSemaphoreReserve(false);

	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {lock = 0; goto Exit;}
	
	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)(p - sizeof(MemChunkHeaderType));
	
	// Get the lock count
	lock = chunkP->lockCount;

Exit:
	// Release ownership
	MemSemaphoreRelease(false);

	return lock;
} 





/************************************************************
 *
 *  FUNCTION: MemHandleHeapID
 *
 *  DESCRIPTION: Returns the heapID of a chunk
 *
 *  PARAMETERS: chunk data handle
 *
 *  RETURNS: heap ID
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		MemHandleHeapID(VoidHand h)
{
	UInt					heapID;
	register BytePtr	p;
	
	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {heapID = 0; goto Exit;}
	
	// Call the root procedure
	PrvHeapPtrAndID((Ptr)p, &heapID);


Exit:
	// Release ownership
	MemSemaphoreRelease(false);

	return heapID;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleDataStorage
 *
 *  DESCRIPTION: Returns true if the given handle is part of a 
 *   Data Storage Heap, else it is a handle in the dynamic heap.
 *
 *  PARAMETERS: chunk data handle
 *
 *  RETURNS: true if part of a data storage heap
 *
 *  CALLED BY: Fields package to determine if it needs to worry
 *    about data storage write-protection when editing a text field.
 *
 *  CREATED: 5/11/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean 	MemHandleDataStorage(VoidHand h)
{
	UInt					heapID;
	register VoidPtr	p;
	
	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {heapID = 0; goto Exit;}
	
	// Get the heap ID
	PrvHeapPtrAndID(p, &heapID);

Exit:
	// Release ownership
	MemSemaphoreRelease(false);

	return (!MemHeapDynamic(heapID));
} 




/************************************************************
 *
 *  FUNCTION: MemHandleCardNo
 *
 *  DESCRIPTION: Returns the card number given a handle to a chunk
 *
 *  PARAMETERS: chunk handle
 *
 *  RETURNS: card number
 *
 *  CREATED: 11/16/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	MemHandleCardNo(VoidHand h)
{
	UInt					cardNo;
	register VoidPtr	p;

	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {cardNo = 0; goto Exit;}
	
	// Get card number
	cardNo = MemPtrCardNo(p);

Exit:
	// Release ownership
	MemSemaphoreRelease(false);
	
	return cardNo;

}



/************************************************************
 *
 *  FUNCTION: MemHandleSetOwner
 *
 *  DESCRIPTION: Sets the owner ID of a chunk
 *
 *  PARAMETERS: chunk data handle
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemHandleSetOwner(VoidHand h, UInt owner)
{
	Err					err;
	register VoidPtr	p;
	MemChunkHeaderPtr		chunkP;

	// Wait for ownership
	MemSemaphoreReserve(true);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {err = memErrInvalidParam; goto Exit;}
	
	// Set Owner
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	chunkP->owner = owner;

Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	
	return err;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleResize
 *
 *  DESCRIPTION: Resizes a chunk
 *
 *  PARAMETERS: chunk data handle, new size
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemHandleResize(VoidHand h, ULong newSize)
{
	Err						err;
	register VoidPtr		p;
	
	// Wait for ownership
	MemSemaphoreReserve(true);
	
	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {err = memErrInvalidParam; goto Exit;}
	
	// Error check mode
	if (GMemDebugMode) {
	
		// Thrash the heap
		PrvDebugAction(0, 0, h, true, false);
		p = PrvHandleCheck(h);
	
		// Resize
		err = PrvPtrResize(p, newSize);

		// Fill free chunks
		PrvDebugAction(0, 0, h, false, true);
		}
		
	// Normal
	else
		err = PrvPtrResize(p, newSize);

Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: MemHandleLock
 *
 *  DESCRIPTION: Locks down a chunk
 *
 *  PARAMETERS: Handle to chunk
 *
 *  RETURNS: pointer to start of chunk data
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr		MemHandleLock(VoidHand h)
{
	MemChunkHeaderPtr				chunkP;
	BytePtr						p;

	// Wait for ownership
	MemSemaphoreReserve(true);

	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) goto Exit;
	
	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)(p - sizeof(MemChunkHeaderType));
	
	// If it's a non-movable chunk, ignore. This could happen if we try
	//  and lock down a resource handle returned from a ROM database.
	if (!chunkP->hOffset) goto Exit;
	
	// Bump the lock count
	chunkP->lockCount++;

	// Check for overflow
	#if ERROR_CHECK_LEVEL != ERROR_CHECK_NONE
	if (chunkP->lockCount == memPtrLockCount) {
		ErrDisplay("Chunk over-locked");
		chunkP->lockCount--;
		}
	#endif


Exit:
	// Release ownership
	MemSemaphoreRelease(true);

	return p;
} 


/************************************************************
 *
 *  FUNCTION: MemHandleUnlock
 *
 *  DESCRIPTION: Unlocks a chunk given a handle to the chunk
 *
 *  PARAMETERS: handle to chunk
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	MemHandleUnlock(VoidHand h)
{
	Err							err;
	register	VoidPtr			p;

	// Wait for ownership
	MemSemaphoreReserve(true);
	
	// Heap Validity
	if (GMemDebugMode) PrvDebugAction(0, 0, h, false, false);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {err = memErrInvalidParam; goto Exit;}
	
	// Unlock it
	err = PrvPtrUnlock(p);

	// Thrash the heap
	if (GMemDebugMode) PrvDebugAction(0, 0, h, true, false);

Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: MemHandleResetLock
 *
 *  DESCRIPTION: Unlocks a chunk all the way to 0
 *
 *  PARAMETERS: handle to chunk
 *
 *  RETURNS:
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		MemHandleResetLock(VoidHand h)
{
	Err							err;
	register	VoidPtr			p;
	MemChunkHeaderPtr				chunkP;

	// Wait for ownership
	MemSemaphoreReserve(true);

	// Get pointer to chunk and check for errors
	if (! (p = PrvHandleCheck(h))) {err = memErrInvalidParam; goto Exit;}
	
	// Do it
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	err = MemPtrResetLock(p);
	
	
Exit:
	// Release ownership
	MemSemaphoreRelease(true);
	
	return err;
}





/************************************************************
 *
 *  FUNCTION: MemLocalIDToGlobal
 *
 *  DESCRIPTION: Converts a local chunkID, which is card relative, into
 *		a global pointer in the designated card
 *
 *  PARAMETERS: local chunkID, card number
 *
 *  RETURNS: global chunk ID
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr	MemLocalIDToGlobal(LocalID local,  UInt cardNo)
{
	Ptr	p;
	
	if (local==0) {
		ErrFatalDisplayIf(true, "Nill ID");
		return 0;
	}

	ErrFatalDisplayIf(cardNo >= GMemCardSlots, "Invalid card #");

	// Under emulation mode, shift the offset accordingly
	#if	EMULATION_LEVEL != EMULATION_NONE
	local = PrvTargetToHostOffset(local, memCardInfoP(cardNo));
	#endif
	
	if (cardNo == 0)
		p = (Ptr)((local & 0xFFFFFFFE) + memCardInfoP(0)->baseP);
	else 
		p = (Ptr)((local & 0xFFFFFFFE) + memCardInfoP(1)->baseP);
		
		
	// If it's a handle, "protect" it
	if (local & 0x01)
		return memHandleProtect(p);
	else
		return p;
}


/************************************************************
 *
 *  FUNCTION: MemLocalIDToPtr
 *
 *  DESCRIPTION: Returns a pointer to a chunk designated by local ID
 *		and card number. 
 *
 *    Note: If the Local ID references a movable chunk and that chunk
 *     is not locked, this routine will return 0 as an error condition
 *
 *  PARAMETERS: local chunkID, card number
 *
 *  RETURNS: ptr to chunk, or 0 if error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr	MemLocalIDToPtr(LocalID local,  UInt cardNo)
{
	BytePtr	p;
	
	if (local==0) {
		ErrFatalDisplayIf(true, "Nill ID");
		return 0;
	}

	ErrFatalDisplayIf(cardNo >= GMemCardSlots, "Invalid card #");
	
	
	// Under emulation mode, shift the offset accordingly
	#if	EMULATION_LEVEL != EMULATION_NONE
	local = PrvTargetToHostOffset(local, memCardInfoP(cardNo));
	#endif
	
	
	// Get the pointer or handle
	if (cardNo == 0)
		p = (BytePtr)((local & 0xFFFFFFFE) + memCardInfoP(0)->baseP);
	else
		p = (BytePtr)((local & 0xFFFFFFFE) + memCardInfoP(1)->baseP);


	// If it's a handle, dereference it if it's locked
	if (local & 0x01) {
		
		#if MEMORY_FORCE_LOCK == MEMORY_FORCE_LOCK_ON
		// If Handle locking is enforced, make sure this handle is locked
		//  before we dereference it
		if (!MemHandleLockCount((Handle)p)) {
			ErrDisplay("Chunk not locked");
			return 0;
			}
		#endif
		
		return *((Handle)p);
		}
		
		
	else
		return p;

}


/************************************************************
 *
 *  FUNCTION: MemLocalIDToLockedPtr
 *
 *  DESCRIPTION: Returns a pointer to a chunk designated by local ID
 *		and card number. 
 *
 *    Note: If the Local ID references a movable chunk this routine
 *			will automatically lock the chunk before returning.
 *
 *  PARAMETERS: local chunkID, card number
 *
 *  RETURNS: ptr to chunk, or 0 if error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr	MemLocalIDToLockedPtr(LocalID local,  UInt cardNo)
{
	BytePtr	p;
	
	if (local==0) {
		ErrFatalDisplayIf(true, "Nill ID");
		return 0;
	}

	ErrFatalDisplayIf(cardNo >= GMemCardSlots, "Invalid card #");
	
	
	// Under emulation mode, shift the offset accordingly
	#if	EMULATION_LEVEL != EMULATION_NONE
	local = PrvTargetToHostOffset(local, memCardInfoP(cardNo));
	#endif
	
	
	// Get the pointer or handle
	if (cardNo == 0)
		p = (BytePtr)((local & 0xFFFFFFFE) + memCardInfoP(0)->baseP);
	else
		p = (BytePtr)((local & 0xFFFFFFFE) + memCardInfoP(1)->baseP);


	// If it's a handle, lock it
	if (local & 0x01) 
		return MemHandleLock((Handle)p);
		
	else
		return p;

}




/************************************************************
 *
 *  FUNCTION: MemHandleToLocalID
 *
 *  DESCRIPTION: Converts a handle into a local chunk ID which is
 *		card relative. The only difference between local ID's to handles
 *		and local ID's to pointers is that the low bit is set for
 *		handle based IDs.
 *
 *  PARAMETERS: Handle
 *
 *  RETURNS:
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalID MemHandleToLocalID(VoidHand h)
{

// -------------------- Emulation mode--------------------
#if EMULATION_LEVEL != EMULATION_NONE
	CardInfoPtr	infoP;
	UInt			i;
	DWord			offset;

	// Unprotect it
	h = memHandleUnProtect(h);
	
	// Search in each card
	infoP = memCardInfoP(0);
	for (i=0; i<GMemCardSlots; i++) {
		if (	(DWord)h > (DWord)infoP->baseP  &&  
				(DWord)h < (DWord)infoP->baseP + infoP->size) {
			offset = (DWord)h - (DWord)infoP->baseP;
			return PrvHostToTargetOffset(offset, infoP) | 0x0001;
			}
		infoP++;
		}

	ErrDisplay("Invalid Handle");
	return 0;
		
// ---------------------- Optimized Native Mode---------------------	
#else 
	// Unprotect it
	h = memHandleUnProtect(h);
	
	// If it's a pointer in the dynamic heap, we must subtract the card base
	if ((DWord)h < hwrCardBase0) 
		return ((DWord)h - hwrCardBase0) | 0x0001;
	else
		return ((DWord)h & hwrCardOffsetMask) | 0x0001;

#endif		
		
}



/************************************************************
 *
 *  FUNCTION: MemPtrToLocalID
 *
 *  DESCRIPTION: Converts a pointer into a local chunk ID which is
 *		card relative. The only difference between local ID's to handles
 *		and local ID's to pointers is that the low bit is set for
 *		handle based IDs.
 *
 *  PARAMETERS: pointer
 *
 *  RETURNS:
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalID MemPtrToLocalID(VoidPtr p)
{
	
	
// -------------------- Emulation mode--------------------
#if EMULATION_LEVEL != EMULATION_NONE
	CardInfoPtr	infoP;
	UInt			i;
	DWord			offset;

	// See which card this pointer belongs to
	infoP = memCardInfoP(0);
	for (i=0; i<GMemCardSlots; i++) {
		if (	(DWord)p > (DWord)infoP->baseP  &&  
				(DWord)p < (DWord)infoP->baseP + infoP->size) {
			offset =  (DWord)p - (DWord)infoP->baseP;
			return PrvHostToTargetOffset(offset, infoP);
			}
		infoP++;
		}

	ErrDisplay("Invalid Ptr");
	return 0;
		
// ---------------------- Optimized Native Mode---------------------	
#else 
	// If it's a pointer in the dynamic heap, we must subtract the card base
	if ((DWord)p < hwrCardBase0) 
		return ((DWord)p - hwrCardBase0);
	else
		return ((DWord)p & hwrCardOffsetMask);
#endif		
		
}


/************************************************************
 *
 *  FUNCTION: MemLocalIDKind
 *
 *  DESCRIPTION: Returns whether or not a localID references a handle
 *		or a pointer.
 *
 *  PARAMETERS: local ID
 *
 *  RETURNS:
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
LocalIDKind MemLocalIDKind(LocalID local)
{
	if (local & 0x0001) return memIDHandle;
	else return memIDPtr;
}




/************************************************************
 *
 *  FUNCTION: MemMove
 *
 *  DESCRIPTION: A Block move routine. 
 *
 *  PARAMETERS: src, dst, numBytes
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY
 *			Name	Date		Description
 *			----	----		-----------
 *			scl	1/22/98	MemMove FROM null changed from fatal to NONfatal error.
 *
 *************************************************************/
Err MemMove(const VoidPtr dP, const void * const sP, ULong bytes)
{
	BytePtr	dstP, srcP;
	register	WordPtr dstWP;
	register	const Word * srcWP;
	ULong		words;
	
	// Return if no bytes
	if (!bytes)
		return 0;
	
	// Fatal = Show dialog (or drop to debugger if we've
	//   been there before) in ALL builds!
	// Writing to null is bad.  We do not allow this to happen!
	ErrFatalDisplayIf(dP == NULL, "MemMove to NULL");

	// NonFatal = Show dialog (or drop to debugger if we've
	//   been there before), but ONLY in debug builds!
	// Reading from null is bad, but not fatal.  Chances are that the
	//   app probably wrote to null (but didn't use MemMove).  However,
	//   if we die on a release build (as we did in early 3.0 builds)
	//   it costs us compatibility with a lot of apps that "seemed" to
	//   work fine on earlier systems (like 1.0 and 2.0).
	ErrNonFatalDisplayIf(sP == NULL, "MemMove from NULL");
	
	
	//----------------------------------------------------------------------
	// If destination is before the source, copy from beginning to end
	//----------------------------------------------------------------------
	if ( dP <= sP ) {
		// Copy a byte if we're add aligned
		if ((Word)dP & 0x0001) {
			*((BytePtr)dP) = *((BytePtr)sP);
			bytes--;
			dstWP = (WordPtr)((BytePtr)dP + 1);
			srcWP = (WordPtr)((BytePtr)sP + 1);
			}
		else {
			dstWP = dP;
			srcWP = sP;
			}
			
			
		// If we're even aligned, copy words
		if ((((Word)dstWP | (Word)srcWP) & 0x0001) == 0) {
			words = bytes >> 1;
			if (words) {
				do {
					*dstWP++ = *srcWP++;
					} while (--words);
				bytes &= 0x01;
				}
			}
		

		// Copy remaining bytes
		if (bytes) {
			dstP = (BytePtr)dstWP;
			srcP = (BytePtr)srcWP;
			do {
				*dstP++ = *srcP++;
				} while (--bytes);
			}
		}
	
	
	//----------------------------------------------------------------------
	// Otherwise, copy from end to beginning
	//----------------------------------------------------------------------
	else {
		// Copy a byte if we're add aligned
		dstWP = (WordPtr)((BytePtr)dP + bytes);
		srcWP = (WordPtr)((BytePtr)sP + bytes);
		if ((Word)dstWP & 0x0001) {
			dstWP = (WordPtr)((BytePtr)dstWP - 1);
			srcWP = (WordPtr)((BytePtr)srcWP - 1);
			*((BytePtr)dstWP) = *((BytePtr)srcWP);
			bytes--;
			}
			
			
		// If we're even aligned, copy words
		if ((((Word)dstWP | (Word)srcWP) & 0x0001) == 0) {
			words = bytes >> 1;
			if (words) {
				do {
					*(--dstWP) = *(--srcWP);
					} while (--words);
				bytes &= 0x01;
				}
			}
		

		// Copy remaining bytes
		if (bytes) {
			dstP = (BytePtr)dstWP;
			srcP = (BytePtr)srcWP;
			do {
				*(--dstP) = *(--srcP);
				} while (--bytes);
			}
				
		}
		
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemSet
 *
 *  DESCRIPTION: Set Memory to a specific value
 *		DOLATER... optimize this...
 *
 *  PARAMETERS: dstP, numBytes, value
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 4/6/95
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Rewrote to set using ULongs.  Tuned by disassembly.
 *			vmk	1/15/98	Bail out if numBytes is zero
 *************************************************************/
Err MemSet(const VoidPtr dstP, ULong numBytes, Byte value)
{
	BytePtr	dP;
	ULong longValue;
	ULong setCount;


	// Return if no bytes to set
	if (!numBytes)
		return 0;
	
	
	dP = dstP;
	
	ErrFatalDisplayIf(dstP == NULL, "MemSet to NULL");
	
	
	// Set values one byte at a time until the destination is at
	// a four byte boundary.
	setCount = 4 - ((ULong) dP & 0x03);
	if (setCount > 0)
		do {
			if (numBytes-- == 0)
				goto Exit;
			
			*dP++ = value;
			} while (--setCount);
	
	
	// Write the value using longs for better speed.
	longValue = value;
	longValue |= (longValue << 8);
	longValue |= (longValue << 16);
	
	setCount = numBytes >> 2;		// Number of longs to move
	numBytes &= 0x3;					// The bytes not moved as a long
	if (setCount > 0)
		do {
			*((ULongPtr)dP)++ = longValue;
			} while (--setCount);
	
	
	// A fraction of a ULong may remain to be filled.  Set it.
	if (numBytes > 0) 
		do {
			*dP++ = value;
			} while(--numBytes);
			
	
	
Exit:	
	return 0;
}


/************************************************************
 *
 *  FUNCTION: MemCmp
 *
 *  DESCRIPTION: Compares two blocks of memory.
 *
 *  PARAMETERS: 2 pointers and the number of bytes to compare
 *
 *  RETURNS: 0 if they match, non-zero if not
 *				 + if s1 > s2
 *				 - if s1 < s2
 *
 *  CREATED: 5/21/96
 *
 *  BY: Art Lamb
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/24/96	Rewrote to speed up.  Tuned by disassembly.
 *************************************************************/
Int MemCmp (const void * const s1, const void * const s2, ULong numBytes)
{
	Byte 		result;
	
	
	ErrFatalDisplayIf(s1 == NULL || s2 == NULL, "Passing NULL to MemCmp");
	result = 0;
	
	if (numBytes > 0)
		do {
			if ((result = (*((BytePtr)s1)++ - *((BytePtr)s2)++)) != 0)
				break;
			} while (--numBytes);
		
			
	return (Int) result;
}


/************************************************************
 *
 *  FUNCTION: MemSemaphoreReserve
 *            NOTE: This call gets replaced when AMX Loads!!!!
 *
 *  DESCRIPTION: 
 *	  Called by Memory Manager and some Data Manager routines on entry.
 *	  If writeAccess is false, this call waits for ownership  of the 
 *		Memory Manager Semaphore and prevents other tasks from changing 
 *		the heaps while the semaphore is held.
 *
 *   If the writeAccess parameter is true, this routine disables task 
 *   switching altogether and enables writes to the data storage area. It is used 
 *   by the Data Manager when it needs to update data in the user storage 
 *   heap. We place this call in this AMX module because it is hardware 
 *	  specific and we want a direct jump to the AMX procedures for performance 
 *   reasons.
 *
 *  This call MUST be balanced with a call to MemSemaphoreRelease!
 *
 *  PARAMETERS: 
 *			writeAccess	- set true to enable writes to data storage area
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 7/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemSemaphoreReserve(Boolean writeAccess)
{
#if	EMULATION_LEVEL != EMULATION_NONE

	// If we don't need write access, simply reserve the Memory Manager
	//  semaphore
	if (!writeAccess) {
		if (GMemSemaphoreID >= 5) ErrDisplay("Might be unbalanced Reserve...");	
		GMemSemaphoreID++;
		}
		
		
	// If we need write access, disable task switching altogether and enable
	//  writes to the data area
	else {
	
		// Bump the write enable level
		if (GHwrDataWELevel >= 5) ErrDisplay("Might be unbalanced Reserve...");	
		GHwrDataWELevel++;
		}
	
#endif	

	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemSemaphoreRelease
 *            NOTE: This call gets replaced when AMX Loads!!!!
 *
 *  DESCRIPTION: 
 *		If writeAccess is false, this routine releases ownership of the Memory
 *   Manager semaphore. 
 *
 *   If writeAccess is true, it restores  write-protection to the data storage
 *   area and restores task switching. 
 *
 *   It must be called with the SAME writeAccess parameter that was passed 
 *   to most recent MemSemaphoreReserve.
 *
 *  PARAMETERS: 
 *		writeAccess - should be same value as passed to most recent
 *							MemSemaphoreReserve call.
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 7/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		MemSemaphoreRelease(Boolean writeAccess)
{
#if	EMULATION_LEVEL != EMULATION_NONE
	
	// If write access was not required, just decrement the semaphore
	if (!writeAccess) {
		if (GMemSemaphoreID <= 0) ErrDisplay("Might be unbalanced Reserve...");
		GMemSemaphoreID--;
		}
		
		
	// Else, decrement the Write-Enable level and restore task switching
	// if we reach 0.
	else {
		if (GHwrDataWELevel <= 0) ErrDisplay("Might be unbalanced Reserve...");
		GHwrDataWELevel--;
		}
		
#endif
	return 0;
}



/************************************************************
 *
 *  FUNCTION: MemDebugMode
 *
 *  DESCRIPTION: Returns the current Debugging mode of the Memory Manager
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Word MemDebugMode(void)
{
	return GMemDebugMode;
}



/************************************************************
 *
 *  FUNCTION: MemSetDebugMode
 *
 *  DESCRIPTION: Sets the Debugging mode of the Memory Manager
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err MemSetDebugMode(Word flags)
{
	Boolean						fillFree = false;
	UInt							cardNo, heapID;
	UInt							heapNo;
	CardInfoPtr					infoP;
	Word							oldFlags;
	Err							err=0;
	char							text[128];
	char							num[8];
	
	
	// Wait for ownership if not called from Debugger
	MemSemaphoreReserve(true);


	// Save the old flags
	oldFlags = GMemDebugMode;
	
	// If setting the minimum heapFree capture, clear the current setting
	if ((flags & memDebugModeRecordMinDynHeapFree) && !(oldFlags & memDebugModeRecordMinDynHeapFree))
		GMemMinDynHeapFree = 0;
		
	
	// If setting fillFreeChunks, pre-init the free chunks
	if (	 (flags & memDebugModeFillFree) && 
			!(oldFlags & memDebugModeFillFree))
		fillFree = true;
		
	
	//-----------------------------------------------------------------------
	// Check all the heaps and pre-fill free chunks if necessary
	//-----------------------------------------------------------------------
	if (flags) {
		infoP = memCardInfoP(0);
		for (cardNo=0; cardNo < GMemCardSlots; cardNo++, infoP++) {
			if (!infoP->size) continue;
			
			for (heapNo = 0; heapNo < MemNumRAMHeaps(cardNo); heapNo++) {
				heapID = MemHeapID(cardNo, heapNo);
				err = MemHeapCheck(heapID);
				if (err) goto Exit;
				
				if (fillFree)
					PrvFillFreeChunks(heapID);
				}
				
			} // cardNo
		}
		
		
	// Set the new flags
	GMemDebugMode = flags;
	
	
Exit:
	// Display error
	if (err) {
		StrCopy(text, "Heap #");
		StrIToA(num, heapID);
		StrCat(text, num);
		StrCat(text, " is invalid");
		DbgSrcMessage(text);
		}
	
	// Release ownership if not called from Debugger
	MemSemaphoreRelease(true);
	
	return err;
}




/************************************************************
 *
 *  FUNCTION: MemHeapScramble
 *
 *  DESCRIPTION: Scrambles the given heap.
 *		We do multiple passes over the heap, until we get to a pass that can
 *		no longer scramble the heap.
 *
 *		For each movable chunk with moved bit clear {
 *			if chunk next to a free chunk
 *				 shift it up or down into free chunk area
 *				 set moved bit in flags
 *			else 
 *				 if possible to reallocate
 *					 reallocate chunk and move to new location
 *					 set moved bit in flags
 *			}
 *		
 *
 *
 *  PARAMETERS: 
 *		heapID	- heap to scramble
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err MemHeapScramble(UInt heapID)
{
	Err							err = -1;
	MemHeapHeaderPtr		   	heapP;
	MemChunkHeaderPtr				chunkP;
	ULong							heapSize, lastOffset, firstOffset;
	UInt							scrambles;
	DWord							size;
	
	
	// Wait for ownership
	MemSemaphoreReserve(true);

	// Get a heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);
	
	// If it's read only, don't do anything
	if (heapP->flags & memHeapFlagReadOnly) {
		err = 0;
		goto Exit;
		}
		
	
	// Get offset of end of heap and to first chunk in heap
	heapSize = MemHeapSize(heapID);
	lastOffset = heapSize - sizeof(MemHeapTerminatorType);
	firstOffset = sizeof(MemHeapHeaderType) 
					+ heapP->mstrPtrTbl.numEntries * sizeof(Ptr);
	
	
	// Scramble the heap until we can't scramble no more....Whenever
	//  a chunk is moved, it's memChunkFlagMovedBit is set so that
	//  we can track which chunks have been scrambled.
	do {
		scrambles = PrvHeapScramble(heapP, firstOffset, lastOffset);
		} while(scrambles);
		
		
	//-------------------------------------------------------------
	// Clear all the moved bits we set during the scramble.
	//-------------------------------------------------------------
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + firstOffset);
	while((size = chunkP->size) != 0) {
		chunkP->moved = false;
		
		// On to next chunk
		chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + size);
		} 
					

	// Heap OK
	err = 0;

Exit:
	
	// Release ownership
	MemSemaphoreRelease(true);
	
	// Display error, if any
	ErrFatalDisplayIf(err, "Error occurred while scrambling heap");
	
	return err;
}



/************************************************************
 *
 *  FUNCTION: MemHeapCheck
 *
 *  DESCRIPTION: Checks validity of given heap
 *
 *  PARAMETERS: 
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *		vmk	7/18/97	Added memHeapFlagVers2 to valid flag set in flag validity checking
 *
 *************************************************************/
Err MemHeapCheck(UInt heapID)
{
	Err							err = -1;
	MemHeapHeaderPtr		   	heapP;
	MemChunkHeaderPtr				chunkP;
	Ptr							chunkDataP;
	Handle						chunkH;
	ULong							heapSize, lastOffset, heapOffset;
	WordPtr						wP;
	UInt							count;
	char							text[128];
	char							num[16];
	

	text[0] = '\0';	
	
	// Wait for ownership
	MemSemaphoreReserve(false);


	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);
	
	
	// If it's read only, don't do anything
	if (heapP->flags & memHeapFlagReadOnly) {
		err = 0;
		goto Exit;
		}

	// Check validity of heap header
	if (heapP->flags & ~(memHeapFlagReadOnly | memHeapFlagVers2)) 
		{
		StrCopy(text, "\nBad flags");
		goto Exit;
		}
	if (heapP->size & 0x01)
		{
		StrCopy(text, "\nBad size");
		goto Exit;
		}

	
	// Get pointer to first chunk
	heapSize = MemHeapSize(heapID);
	lastOffset = heapSize - sizeof(MemHeapTerminatorType);
	
	heapOffset = sizeof(MemHeapHeaderType) 
					+ heapP->mstrPtrTbl.numEntries * sizeof(Ptr);
					
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + heapOffset);
	
	
	// Walk through the chunks
	do {
		chunkDataP = (Ptr)((BytePtr)chunkP + sizeof(MemChunkHeaderType));
		chunkH = 0;
		
		// Check validity of chunk header
		if (chunkP->size == 0 || chunkP->size & 0x01)
			{
			StrCopy(text, "\nBad size");
			goto Exit;
			}
		if (chunkP->moved || chunkP->unused2 || chunkP->unused3)
			{
			StrCopy(text, "\nBad flags");
			goto Exit;
			}
		if (chunkP->free && chunkP->lockCount)
			{
			StrCopy(text, "\nFree chunk locked");
			goto Exit;
			}
		
		
		// Determine the handle
		if (chunkP->hOffset) {
			chunkH = (Handle)((BytePtr) chunkP - ((Long)chunkP->hOffset*2));
			if (*chunkH != (Ptr)chunkDataP)
				{
				StrCopy(text, "\nBad handle");
				goto Exit;
				}
			}
			
			
		// If it's a free chunk and free chunks are filled, check the contents
		if (chunkP->free) 
			if (GMemDebugMode & memDebugModeFillFree) {
				wP = (WordPtr)chunkDataP;
				count = chunkP->size  - sizeof(MemChunkHeaderType);
				count = (count >> 1) + 1;
				while(--count) {
					if (*wP++ != memFillFreeValue) {
						StrCopy(text, "\nFree chunk: ");
						StrIToH(num, (Long)chunkDataP);
						StrCat(text, num);
						StrCat(text, " overwritten.");
						DbgSrcMessage(text);
						goto Exit;
						}
					}
				}
				
				
		// On to next chunk
		heapOffset += chunkP->size;
		chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		} while(heapOffset < lastOffset);
					
		
	// Make sure the last chunk has 0 in it's size field
	if (chunkP->size)
			{
			StrCopy(text, "\nBad Terminator");
			goto Exit;
			}
	
	// Heap OK
	err = 0;

Exit:
	
	// Release ownership
	MemSemaphoreRelease(false);
	
	// Display error, if any
	if (err) {
		if (text[0] != '\0')
			{
			DbgSrcMessage(text);
			if (!GDbgInDebugger) DbgSrcBreak();
			}

		StrCopy(text, "\nHeap ");
		StrIToA(num, heapID);
		StrCat(text, num);
		StrCat(text, " invalid.");
		DbgSrcMessage(text);
		DbgSrcMessage("\nTurning off checking.\n");
		if (!GDbgInDebugger) DbgSrcBreak();
		GMemDebugMode = 0;
		}
	
	return err;
}




/************************************************************
 *
 *  FUNCTION: PrvHandleCheck, private
 *
 *  DESCRIPTION: Checks the validity of a chunk handle. This routine
 *		is called by every Memory Manager routine that might write
 *		to the data storage area so it MUST BE VERY FAST!!.
 *
 *  PARAMETERS:
 *		h - chunk handle
 *			
 *  RETURNS: 
 *		ptr to chunk data if valid, else 0
 *
 *  CREATED: 8/8/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static VoidPtr	PrvHandleCheck(Handle	h)
{
	Ptr					p;
	MemChunkHeaderPtr	chunkP;
	SDWord				hOffset;
	
	// With error checking on, check for nil handle
	if (!h) {
		p = 0;
		goto Exit;
		}
	
	// Remove the lock protection
	h = memHandleUnProtect(h);
	
	// Get pointer to the chunk header
	p = *h;
	if (!p)
		{
		#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		p = p;				// so we can set break point in the IDE's debugger
		#endif
		
		goto Exit;
		}

	chunkP = (MemChunkHeaderPtr)(p - sizeof(MemChunkHeaderType));
	
	// Validate that the handle offset references the handle that points
	//  back to the chunk.
	if ((hOffset = chunkP->hOffset) != 0) {
		if ((Long)chunkP - ((Long)hOffset*2)  != (Long)h) 
			p = 0;
		}
	// If it's not a movable chunk, just make sure it has the right lockcount
	else {
		if (chunkP->lockCount != memPtrLockCount) 
			p = 0;
		}
	
Exit:
	ErrFatalDisplayIf(!p, "Invalid handle");
	return p;
}


/************************************************************
 *
 *  FUNCTION: PrvPtrCheck, private
 *
 *  DESCRIPTION: Checks the validity of a chunk pointer. This routine
 *		is called by every Memory Manager routine that might write
 *		to the data storage area so it MUST BE VERY FAST!!.
 *
 *  PARAMETERS:
 *		p - chunk data pointer
 *			
 *  RETURNS: 
 *		ptr to chunk header if valid, else 0
 *
 *  CREATED: 8/8/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static MemChunkHeaderPtr	PrvPtrCheck(VoidPtr	p)
{
	MemChunkHeaderPtr	chunkP;
	SDWord				hOffset;
	
	// With error checking on, check for nil handle
	ErrFatalDisplayIf(!p, "Nil Ptr");
	
	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	
	// With error checking on, check for nil handle
	ErrNonFatalDisplayIf(chunkP->unused2 || chunkP->unused3, "Bad chunk header");
	
	// If it's a movable chunk, validate that the handle offset
	//  references the handle that points back to the chunk.
	if ((hOffset = chunkP->hOffset) != 0) {
		Handle	h;
		h = (Handle)( (BytePtr)chunkP - ((Long)hOffset * 2) );
		if ((DWord)(*h)  !=  (DWord)p) {chunkP = 0; goto Exit;}
		}
		
	// If it's not a movable chunk, it must have a max lock count
	else {
		if (chunkP->lockCount != memPtrLockCount) 
			chunkP = 0;
		}
	
Exit:
	ErrFatalDisplayIf(!chunkP, "Invalid chunk ptr");
	return chunkP;
}


/************************************************************
 *
 *  FUNCTION: MemPtrCheck
 *
 *  DESCRIPTION: Checks the validity of a chunk pointer. 
 *
 *  PARAMETERS:
 *		p - chunk data pointer
 *			
 *  RETURNS: 
 *		ptr to chunk header if valid, else 0
 *
 *  CREATED: 8/8/95
 *
 *  BY: Roger Flores
 *
 *************************************************************/
 // TEMP CODE to be finished later.
static MemChunkHeaderPtr	MemPtrCheck(VoidPtr p)
{
//	MemChunkHeaderPtr	chunkP;
//	SDWord				hOffset;
	
	// With error checking on, check for nil pointer
	ErrFatalDisplayIf(!p, "NULL Ptr");
	
	// With error checking on, check for handle instead of a pointer
	ErrFatalDisplayIf((DWord) p & 0x80000000, "Ptr is Handle");
	
	// Verify that the pointer points to a heap.
	// Verify that the pointer points to a chunk
	// return the start of the chunk incase the caller wants to check other things.
	
/*	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));
	
	// With error checking on, check for nil handle
	ErrNonFatalDisplayIf(chunkP->unused2 || chunkP->unused3, "Bad chunk header");
	
	// If it's a movable chunk, validate that the handle offset
	//  references the handle that points back to the chunk.
	if ((hOffset = chunkP->hOffset) != 0) {
		Handle	h;
		h = (Handle)( (BytePtr)chunkP - ((Long)hOffset * 2) );
		if ((DWord)(*h)  !=  (DWord)p) {chunkP = 0; goto Exit;}
		}
		
	// If it's not a movable chunk, it must have a max lock count
	else {
		if (chunkP->lockCount != memPtrLockCount) 
			chunkP = 0;
		}
	
Exit:
	ErrFatalDisplayIf(!chunkP, "Invalid chunk ptr");
*/	return p;
}





/************************************************************
 *
 *  FUNCTION: PrvChunkNew, private
 *
 *  DESCRIPTION: Allocates a new chunk in the given heap.  Zero-size allocations
 *						are not allowed.
 *
 *						If zero is passed for size, no allocation takes place and NULL
 *						is returned.  The EC version will trigger a failed assertion
 *						when size of zero is passed.
 *
 *  PARAMETERS: heapID, size of chunk, chunk attribytes
 *		The chunk attributes can be one or more of:
 *			memNewChunkFlagNonMovable
 *			memNewChunkFlagParAlign
 *			ORed with the owner ID
 *			
 *
 *  RETURNS: ChunkID, or 0 if error
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	10/3/97	Add memMaxChunkAllocSize check
 *		vmk	12/12/97	Added non-fatal assertion on size = 0
 *
 *************************************************************/
static VoidPtr	PrvChunkNew(UInt heapID, ULong reqSize, UInt attributes)
{
	BytePtr						p;
	MemHeapHeaderPtr		   	heapP;

	MemChunkHeaderPtr			chunkP;
	MemChunkHeaderPtr			lastBigChunkP;

	Boolean						compacted = false;
	DWord							oldSize;
	VoidPtr						retP=0;
	Boolean						atEnd;
	DWord							actSize;
	
	Ptr*							ptrP=0;
	MemMstrPtrTablePtr			mstrTblP;
	Int							i;
	
	DWord							size;


	//ErrNonFatalDisplayIf(reqSize == 0, "zero-size alloc");

	// Check for zero size or size that exceeds our limits
	if (!reqSize || reqSize > memMaxChunkAllocSize) return 0;

	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);


	// the Actual size of the new chunk must include the chunk header
	if (reqSize & 0x01) 
		actSize = reqSize + 1 + sizeof(MemChunkHeaderType);
	else 
		actSize = reqSize + sizeof(MemChunkHeaderType);
		


	//------------------------------------------------------------
	// If it's a movable chunk (!atEnd), find a free offset entry in the
	//  offset table and setup offsetP to point to it.
	//------------------------------------------------------------
	lastBigChunkP = 0;
	if (attributes & memNewChunkFlagNonMovable) {
		if (attributes & memNewChunkFlagAtStart)
			atEnd = false;
		else
			atEnd = true;
		}

	else {
		if (attributes & memNewChunkFlagAtEnd)
			atEnd = true;
		else
			atEnd = false;

		// Look for a free master pointer
		mstrTblP = &heapP->mstrPtrTbl;
		ptrP = (Ptr*) ( (BytePtr)mstrTblP + sizeof(MemMstrPtrTableType) );
		i = mstrTblP->numEntries ;
		while (i > 0) {
		
			// If this one is free break out
			if (*ptrP == 0) break;
			
			// If we've reached the end of current table, go on to next table
			if (i == 1) {
				ptrP = 0;
				if (!mstrTblP->nextTblOffset) break;
				mstrTblP = (MemMstrPtrTablePtr) ( (BytePtr)heapP + mstrTblP->nextTblOffset );
				ptrP = (Ptr*) ( (BytePtr)mstrTblP + sizeof(MemMstrPtrTableType) );
				i = mstrTblP->numEntries;
				}
			
			else {
				i--;
				ptrP++;
				}
			}


		// If we didn't find a free offset, add another master pointer table
		if (!ptrP) {
			
			// Allocate another offset table
			p = MemChunkNew(heapID, 
							sizeof(MemMstrPtrTableType) + memMstrPtrTableGrowBy*sizeof(Ptr), 
							memNewChunkFlagNonMovable);
			if (!p) goto Exit;

			// Set the owner to memOwnerMasterPtrTbl for tracking purposes
			chunkP = (MemChunkHeaderPtr)(p - sizeof(MemChunkHeaderType));
			chunkP->owner = memOwnerMasterPtrTbl;

			// Link the new master pointer table in.
			mstrTblP->nextTblOffset = (DWord)p - (DWord)heapP;
			mstrTblP = (MemMstrPtrTablePtr)(p);
			mstrTblP->numEntries = memMstrPtrTableGrowBy;
			mstrTblP->nextTblOffset = 0;

			// Init the table to 0's
			ptrP = (Ptr*) ( (BytePtr)mstrTblP + sizeof(MemMstrPtrTableType) );
			for (i=0; i<memMstrPtrTableGrowBy; i++) 
				*ptrP++ = 0;
				
			// Use the first one
			ptrP = (Ptr*) ( (BytePtr)mstrTblP + sizeof(MemMstrPtrTableType) );
			}
		}
		




	//------------------------------------------------------------
	// Look for a free chunk big enough to hold the request
	//------------------------------------------------------------
	// Start at the first chunk
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );

	// Get the size
	size = chunkP->size;

	// Look for a free chunk big enough to hold the request
	while(1) {
	
		// If it's a free chunk
		if (chunkP->free) {

			// and it's big enough...
			if (size >= actSize) {

				// If we're trying to allocate at the end, record this chunk
				// pointer as the lastBigChunkP, but keep searching for a
				// later chunk
				if (atEnd) lastBigChunkP = chunkP;
				

				// Put the new chunk here
				else 	break;

				}
			}


		// Go on to next chunk
		chunkP = (MemChunkHeaderPtr) ((BytePtr)chunkP + size);
		size = chunkP->size;

		// If we're at the end of the heap, take special action
		if (size == 0) {

			// If we're intentionally trying to allocate at the end of the heap,
			//  break out if we've already found a free chunk big enough
			if (lastBigChunkP) {
				chunkP = lastBigChunkP;
				break;
				}

			// Compact the heap and try again
			if (!compacted) {
				PrvCompactHeap(heapP);
				chunkP = (MemChunkHeaderPtr)((BytePtr)heapP 
								+ sizeof(MemHeapHeaderType) + (heapP->mstrPtrTbl.numEntries << 2));
				size = chunkP->size;
				compacted = true;
				lastBigChunkP = 0;
				}
			else  goto Exit;
			}
		}




	// We found a chunk to break up, now do it
	oldSize = chunkP->size;
	


	//------------------------------------------------------------
	// Split up the free chunk into a smaller free chunk and
	//  the new chunk, or just reflag it as the new chunk if it's
	//  not big enough
	//------------------------------------------------------------

	// If allocating at the end, put the new chunk at the end
	// of the free chunk
	if (atEnd) {
		// If it's big enough, Chop the free block down to size and place
		//  the new chunk at the end of it
		if (oldSize > actSize + sizeof(MemChunkHeaderType))  {
			chunkP->size = oldSize - actSize;
			chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
			chunkP->size = actSize;
			}
		else
			actSize = oldSize;
		}
	
	
	// If non-movable chunk....
	if (attributes & memNewChunkFlagNonMovable) {	
		memChunkFlagsClear(chunkP);
		chunkP->sizeAdj =  (actSize - reqSize - sizeof(MemChunkHeaderType));
		chunkP->lockCount = memPtrLockCount;
		chunkP->owner = attributes & 0x0F;
		chunkP->hOffset = 0;
		retP  = (BytePtr)chunkP + sizeof(MemChunkHeaderType);
		}
		
	// Else if movable chunk...
	else {
		// Setup the flags for the new chunk
		chunkP->free = false;
		chunkP->sizeAdj = (actSize - reqSize - sizeof(MemChunkHeaderType));
		chunkP->owner = attributes & 0x0F;
		chunkP->hOffset = ((DWord)chunkP - (DWord)ptrP) >> 1;
		*ptrP = (Ptr)((BytePtr)chunkP + sizeof(MemChunkHeaderType));
		retP = ptrP;
		
		// If it's requested pre-locked, lock it and set up the return pointer
		if (attributes & memNewChunkFlagPreLock) {
			chunkP->lockCount++;
			retP = *ptrP;
			}
		}
		
	
	// If we allocated at the front of the free chunk, break out the unused space
	//  at the end as a new free chunk 
	if (!atEnd) {
		// If the chunk was big enough to split, make a free chunk at the end
		if (oldSize > actSize + sizeof(MemChunkHeaderType))  {
			chunkP->size = actSize;
			chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + actSize);
			memClearChunkHeader(chunkP);
			chunkP->size = oldSize - actSize;
			chunkP->free = true;
			}
		// If it wasn't big enough to split, it's actual size was the old size
		//  so we need to fix up the flags field
		else 
			chunkP->sizeAdj = oldSize - reqSize - sizeof(MemChunkHeaderType);
		}

		  

Exit:
	
	// If Memory Debug is on, see if we need to record minimum free space in
	//  the dynamic heap
	if (GMemDebugMode) {
		if ((GMemDebugMode & memDebugModeRecordMinDynHeapFree) && heapID==0) {
			ULong		freeBytes, maxChunk;
			MemHeapFreeBytes(heapID, &freeBytes, &maxChunk);
			if (freeBytes < GMemMinDynHeapFree || GMemMinDynHeapFree==0)
				GMemMinDynHeapFree = freeBytes;
			}
		}

	return retP;
}



/************************************************************
 *
 *  FUNCTION: PrvChunkFree, private
 *
 *  DESCRIPTION: Disposes of a chunk
 *
 *  PARAMETERS: Chunk ID
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/02/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err		PrvChunkFree(VoidPtr p)
{
	MemChunkHeaderPtr				chunkP;
	MemChunkHeaderPtr				nextChunkP;
	Ptr*								ptrP;
	DWord								size;

	// Get the chunk pointer header pointer
	chunkP = (MemChunkHeaderPtr)((BytePtr)p - sizeof(MemChunkHeaderType));


	// Check validity
	#if ERROR_CHECK_LEVEL != ERROR_CHECK_NONE
	if (chunkP->free) {
		ErrDisplay( "Freeing a free chunk");
		goto Exit;
		}
	if (chunkP->size & 0x01) {
		ErrDisplay( "Freeing Invalid chunk ptr");
		goto Exit;
		}
	#endif


	// If it had an entry in the master pointer table, clear it
	if (chunkP->hOffset)  {
		ptrP = (Ptr*)( (Long)chunkP - ((Long)chunkP->hOffset << 1) );
		*ptrP = 0;
		}


	// Mark it as free
	size = chunkP->size;
	memClearChunkHeader(chunkP);
	chunkP->size = size;
	chunkP->free = true;



	// Merge in all following free chunks
	nextChunkP = chunkP;
	while(1) {
		nextChunkP = (MemChunkHeaderPtr) ((BytePtr)nextChunkP + nextChunkP->size);


		// If we're at the end of the heap, bail
		if (nextChunkP->size == 0) break;


		// If the next chunk is free, merge them together
		if (nextChunkP->free) 
			chunkP->size += nextChunkP->size;
		else
			break;
		} 

Exit:
	return 0;

}




/************************************************************
 *
 *  FUNCTION: PrvPtrUnlock
 *
 *  DESCRIPTION: Unlocks a chunk given a pointer to the chunk
 *
 *  PARAMETERS: pointer to chunk
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/17/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvPtrUnlock(VoidPtr p)
{
	MemChunkHeaderPtr				chunkP;


	// Check for error
	ErrFatalDisplayIf(p==0, "nil Chunk ptr");

	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)((BytePtr)(p) - sizeof(MemChunkHeaderType));
	
	// If it's a non-movable chunk, ignore
	if (!chunkP->hOffset) goto Exit;

	// Decrement lock count
	if (chunkP->lockCount  != memPtrLockCount) {
		if (chunkP->lockCount) 
			chunkP->lockCount--;  
		else {
			ErrDisplay("Chunk under-locked");
			}
		}
		
Exit:
	return 0;
}


/************************************************************
 *
 *  FUNCTION: PrvPtrResize
 *
 *  DESCRIPTION: Resizes a chunk
 *
 *		The original implementation accidentally allowed reallocation
 *		to size zero.  To rectify this situation, passing a new size of
 *		zero will cause an assertion to fail in the debug build PalmOS v3.x.
 *
 *  PARAMETERS: chunk data pointer, new size
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 11/10/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	10/3/97	Added memMaxChunkAllocSize check
 *		vmk	12/12/97	Added non-fatal assertion on newSize = 0
 *
 *************************************************************/
static Err		PrvPtrResize(VoidPtr chunkDataP, ULong newSize)
{
	MemHeapHeaderPtr		heapP;
	Err					err=0;
	ULong					oldActSize;
	ULong					newActSize;
	ULong					freeSpace;

	MemChunkHeaderPtr		chunkP, tmpChunkP, freeChunkP;
	MemChunkHeaderPtr		nextChunkP;
	Handle				chunkH;
	
	UInt					heapID;
	
	Boolean				compacted;


	// Check for error
	ErrFatalDisplayIf(chunkDataP==0, "nil Chunk ptr");

	// Since zero size allocs are discouraged and are likely bugs, try to discourage
	// developers from reallocating to zero size (unfortunately,
	// earlier versions, 1.0 and 2.0, allowed reallocs to size zero;
	// in the interest of not breaking existing 3rd party apps without
	// sufficient warning, we're adding this non-fatal assertion)
	// DOLATER... in 4.0, consider disallowing zero-size reallocs
	//ErrNonFatalDisplayIf(newSize == 0, "zero-size realloc");

	if ( newSize > memMaxChunkAllocSize )
		{
		err = memErrInvalidParam;
		goto Exit;
		}

	// Get pointer to the chunk header
	chunkP = (MemChunkHeaderPtr)((BytePtr)chunkDataP - sizeof(MemChunkHeaderType));


	// Figure out the new actual size
	if (newSize & 0x01)
		newActSize = newSize + 1 + sizeof(MemChunkHeaderType);
	else
		newActSize = newSize + sizeof(MemChunkHeaderType);


	//------------------------------------------------------------
	// Are we shrinking? It's easy..
	//------------------------------------------------------------
	oldActSize = chunkP->size;
	if (newActSize < oldActSize) {

		// If it's big enough to create a free chunk at the end...
		if (oldActSize >= newActSize + sizeof(MemChunkHeaderType)) {
			chunkP->size = newActSize;

			freeChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + newActSize);
			memClearChunkHeader(freeChunkP);
			freeChunkP->size = oldActSize - newActSize;
			freeChunkP->free = true;
			}

		else
			newActSize = oldActSize;

		// Adjust the requested size
		chunkP->sizeAdj = (newActSize - newSize - sizeof(MemChunkHeaderType));
		}




	//------------------------------------------------------------
	// Else if we're growing...
	//------------------------------------------------------------
	else {
		
		//------------------------------------------------------------
		// First, merge any following free chunks together and just
		//  grow the existing chunk into the following free space if
		//  possible.
		//------------------------------------------------------------
		nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		tmpChunkP = nextChunkP;
		while(tmpChunkP->size && tmpChunkP->free) {
			if (nextChunkP != tmpChunkP)
				nextChunkP->size += tmpChunkP->size;
			tmpChunkP = (MemChunkHeaderPtr)((BytePtr)tmpChunkP + tmpChunkP->size);
			}

		// If the next chunk is free and big enough to hold the extra space,
		//  merge it in
		if (nextChunkP->size && nextChunkP->free)
			freeSpace = nextChunkP->size;
		else
			freeSpace = 0;


		//------------------------------------------------------------
		// If there's not enough free space following the chunk, we must
		//  look for a free chunk somewhere else in the heap and move it there
		//------------------------------------------------------------
		if (freeSpace + oldActSize < newActSize) {
			// make sure it's movable
			if (chunkP->lockCount) {
				err = memErrChunkLocked;
				goto Exit;
				}

			// Look for a free chunk big enough somewhere in the heap
			heapP = 	PrvHeapPtrAndID(chunkDataP, &heapID);
			chunkH = (Handle)((DWord)chunkP - ((Long)chunkP->hOffset << 1));

			compacted = false;
			while (1) {
				nextChunkP = (MemChunkHeaderPtr)((BytePtr)heapP 
									+ sizeof(MemHeapHeaderType) +  (heapP->mstrPtrTbl.numEntries << 2));
				freeChunkP = 0;
				while(nextChunkP->size) {
					if (nextChunkP->free) {
						if (nextChunkP->size >= newActSize) {
							freeChunkP = nextChunkP;
							break;
							}
						}
					nextChunkP = (MemChunkHeaderPtr)((BytePtr)nextChunkP + nextChunkP->size);
					}

				// If we found a free chunk break out
				if (freeChunkP) break;
				
				// If we've already compacted, bail
				if (compacted) break;

				// If we haven't tried it yet, compact the heap and look again
				PrvCompactHeap(heapP);
				compacted = true;

				// Figure out the chunk pointer again in case it moved
				chunkP = (MemChunkHeaderPtr)((*chunkH) - sizeof(MemChunkHeaderType));
				}
				

			// If we found a free chunk big enough, move our chunk there
			if (freeChunkP) {
				freeSpace = freeChunkP->size - oldActSize;

				// Move the chunk contents
				PrvMoveChunk(freeChunkP, chunkP);

				// save pointer to new chunkP
				chunkP = freeChunkP;
				}

			}  // Looking for free chunk somewhere else in the heap
					

		// If there's room for the bigger chunk and a free chunk...
		if (freeSpace + oldActSize >= newActSize + sizeof(MemChunkHeaderType)) {
			chunkP->size = newActSize;
			chunkP->sizeAdj = (newActSize - sizeof(MemChunkHeaderType) - newSize);

			freeChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + newActSize);
			memClearChunkHeader(freeChunkP);
			freeChunkP->size = freeSpace + oldActSize - newActSize;
			freeChunkP->free = true;
			}

		// If there's barely room for the bigger chunk
		else if (freeSpace + oldActSize >= newActSize) {
			newActSize = oldActSize + freeSpace;
			chunkP->size = newActSize;
			chunkP->sizeAdj = (newActSize - sizeof(MemChunkHeaderType) - newSize);
			}

		else
			err = memErrNotEnoughSpace;
				
		} // Growing...
			
		

	// Return
Exit:
	return err;

}


/************************************************************
 *
 *  FUNCTION: PrvHeapScramble
 *
 *  DESCRIPTION: Does a single scramble pass on the heap and returns
 *		the number of chunks it was able to relocate.
 *
 *		For each movable chunk with moved bit clear {
 *			if chunk follows a free chunk
 *				 shift it up into free chunk area
 *				 set moved bit in flags
 *			else 
 *				 if possible to reallocate
 *					 reallocate chunk and move to new location
 *					 set moved bit in flags
 *			}
 *		
 *  PARAMETERS: 
 *		heapP				- pointer to heap header
 *		firstOffset 	- offset to first chunk in heap
 *		lastOffset		- offset to last chunk in heap
 *
 *	 CALLED BY: MemHeapScramble
 *
 *  RETURNS: # of chunks relocated.
 *
 *  CREATED: 7/4/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	PrvHeapScramble(MemHeapHeaderPtr heapP, DWord firstOffset, DWord lastOffset)
{
	MemChunkHeaderPtr				prevChunkP, chunkP, nextChunkP;
	MemChunkHeaderPtr				newChunkP, freeChunkP;
	Handle						chunkH;
	UInt							scrambles = 0;
	DWord							freeSize, chunkSize, reqSize;
	DWord							oldSize;
	
	// Start the loop at 0
	chunkP = 0;
	nextChunkP = (MemChunkHeaderPtr)((BytePtr)heapP + firstOffset);
	
	// Walk through the chunks
	while(1) {
	
		// Point to next chunk
		prevChunkP = chunkP;
		chunkP = nextChunkP;
		if (!chunkP->size) break;		// 0 at end of heap
		nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		
		// If this chunk was already moved, or is a free chunk, skip it
		if (chunkP->moved || chunkP->free ) continue;
		
		// If this chunk is not movable, skip it
		if (chunkP->lockCount) continue;
		
		// Determine the handle location for this chunk
		chunkH = (Handle)((BytePtr) chunkP - ((Long)chunkP->hOffset*2));
			
			
		//------------------------------------------------------------------
		// If the previous chunk is free, move this one into that space
		//------------------------------------------------------------------
		if (prevChunkP) {
			if (prevChunkP->free) {

				freeSize = prevChunkP->size;
				chunkSize = chunkP->size;
				MemMove(prevChunkP, chunkP, chunkSize);
				
				// Point to the new location of the chunk and the free chunk
				newChunkP = prevChunkP;
				chunkP = (MemChunkHeaderPtr)((BytePtr)prevChunkP + chunkSize);
				
				// Fix up the handle of the chunk and set the moved bit
				newChunkP->hOffset = ((DWord)newChunkP - (DWord)chunkH) >> 1;
				*chunkH = (Ptr)((BytePtr)newChunkP + sizeof(MemChunkHeaderType));
				newChunkP->moved = true;
				scrambles++;
				
				// Mark the free chunk
				memClearChunkHeader(chunkP);
				chunkP->size = freeSize;
				chunkP->free = true;
				
				// If the next chunk is free, merge it in
				if (nextChunkP->free) {
					chunkP->size += nextChunkP->size;
					nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
					}
					
				
				// All done
				continue;
				}
			} // prevChunkP
			
			
		//------------------------------------------------------------------
		// If possible, re-allocate this chunk somewhere else in the heap
		//------------------------------------------------------------------
		freeChunkP = (MemChunkHeaderPtr)((BytePtr)heapP + firstOffset);
		reqSize =  chunkP->size + sizeof(MemChunkHeaderType);
		while (freeChunkP->size) {
		
			// If there's an available free chunk, and big enough, break out
			if (freeChunkP->free) 
				if (freeChunkP->size >= reqSize) break;
				
			// Next chunk
			freeChunkP = (MemChunkHeaderPtr)((BytePtr)freeChunkP + freeChunkP->size);
			} 
			
		// If we didn't find a vacancy, skip it
		freeSize = freeChunkP->size;
		if (!freeSize) continue;
		
		// Move this chunk to the free space and fix up it's handle field
		MemMove(freeChunkP, chunkP, chunkP->size);
		newChunkP = freeChunkP;
		newChunkP->hOffset = ((DWord)newChunkP - (DWord)chunkH) >> 1;
		*chunkH = (Ptr)((BytePtr)newChunkP + sizeof(MemChunkHeaderType));
		newChunkP->moved = true;
		scrambles++;
		
		// Mark the extra free chunk at the end of the destination
		freeChunkP = (MemChunkHeaderPtr)((BytePtr)newChunkP + newChunkP->size);
		memClearChunkHeader(freeChunkP);
		freeChunkP->size = freeSize - newChunkP->size;
		freeChunkP->free = true;
		
		// Mark the current chunk as free
		oldSize = chunkP->size;
		memClearChunkHeader(chunkP);
		chunkP->size = oldSize;
		chunkP->free = true;
	
		// If the next chunk is free too, merge it in
		if (nextChunkP->free) {
			chunkP->size += nextChunkP->size;
			nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
			}
		} 
					
		
	// Return number of chunks we moved
	return	scrambles;
}



#if EMULATION_LEVEL != EMULATION_NONE
/************************************************************
 *
 *  FUNCTION: PrvHostToTargetOffset, private
 *
 *  DESCRIPTION: Used only under Emulation mode. We need this
 *   routine when we try and craft a ROM image for use
 *   on the device, but we don't have enough RAM on the host to
 *   contain the entire card's address space. 
 *
 *   For example, a memory card might have only 1 Meg of RAM starting at
 *   address 0 but it's ROM might start at the 8 MByte boundary
 *   or even higher. When this is the case, we "compress" the card image
 *   and place the ROM image immediately after the RAM area in the host
 *   memory. 
 *
 *   For compressed memory cards then, we must add a shift amount
 *   to ROM pointers when calculating a LocalID that can be used on
 *   the device. This shift amount is the targetROMShift field in the
 *   CardInfoType for the card and gives the difference between the
 *   Emulated location of the ROM and the final desired location of the ROM
 *
 *  PARAMETERS: offset to chunk as used on host, CardInfoPtr
 *
 *  RETURNS: offset to chunk that can be used on target.
 *
 *  CREATED: 5/3/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static DWord PrvHostToTargetOffset(DWord hostOffset, CardInfoPtr infoP)
{
	// If it's in the ROM area, we must add a shift amount to it
	if (hostOffset >= infoP->cardHeaderOffset - infoP->targetROMShift)
		return hostOffset + infoP->targetROMShift;
		
	else
		return hostOffset;
}


/************************************************************
 *
 *  FUNCTION: PrvTargetToHostOffset
 *
 *  DESCRIPTION: Used only under Emulation mode. We need this
 *   routine when we try and craft a ROM image for use
 *   on the device, but we don't have enough RAM on the host to
 *   contain the entire card's address space. 
 *
 *   For example, a memory card might have only 1 Meg of RAM starting at
 *   address 0 but it's ROM might start at the 8 MByte boundary
 *   or even higher. When this is the case, we "compress" the card image
 *   and place the ROM image immediately after the RAM area in the host
 *   memory. 
 *
 *   For compressed memory cards then, we must add a shift amount
 *   to ROM pointers when calculating a LocalID that can be used on
 *   the device. This shift amount is the targetROMShift field in the
 *   CardInfoType for the card and gives the difference between the
 *   Emulated location of the ROM and the final desired location of the ROM
 *
 *  PARAMETERS: offset to chunk that can be used on target, CardInfoPtr
 *
 *  RETURNS: offset to chunk that can be used on the host
 *
 *  CREATED: 5/3/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static DWord PrvTargetToHostOffset(DWord targetOffset, CardInfoPtr infoP)
{	
	// If this offset is in the ROM area, we must subtract the targetROMShift
	if (targetOffset >= infoP->cardHeaderOffset)
		return targetOffset - infoP->targetROMShift;
		
	else 	
		return targetOffset;
}

#endif // EMULATION_LEVEL != EMULATION_NONE


/************************************************************
 * PRIVATE
 *-------------------------------------------------------------
 *  FUNCTION: PrvDebugAction, private
 *
 *  DESCRIPTION: Called by various Memory Manager routines when
 *   GMemDebugMode is not nil in order to scramble the heap,
 *   check the heap, or fill free chunks, etc.
 *
 *   NOTE: If p is not nil, it is used to determine the heapID,
 *				else if h is not nil, it is used to determine the heapID,
 *				else heapID has the heap ID
 *
 *	  This routine checks the flags in GMemDebugMode and takes the
 *		appropriate action given:
 *
 *   If postModify is true, it will simply fill in the free chunks with
 *		initialized data.
 *
 *	  Else {
 *		 It will check the appropriate heap(s).
 *   	 If preModify is true, it will scramble the appropriate heap(s).
 *		 }
 *
 *
 *  PARAMETERS: 
 *   NOTE: the heap I
 *		heapID 			- which heap to act on
 *		p		 			- pointer to chunk in heap to act on, 
 *		h					- handle to chunk in heap to act on
 *		alwaysScramble - If true, heap(s) will be scrambled even if 
 *								memDebugModeScrambleOnAll is false.
 *		postModify		- true when called from end of a routine that 
 *								just modified the heap. This tells us to simply re-fill free chunks
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void PrvDebugAction(UInt heapID, VoidPtr p, VoidHand h, Boolean alwaysScramble,
					Boolean postModify)
{
	Err			err = 0;
	CardInfoPtr	infoP;
	UInt			cardNo;
	Boolean		check=false, scramble=false;
	UInt			heapNo;

	// Wait for ownership
	MemSemaphoreReserve(false);
	
	// If a chunk pointer is specified, use that to get the heap ID
	if (p) heapID = MemPtrHeapID(p);
	else if (h) {
		h = memHandleUnProtect(h);
		heapID = MemPtrHeapID(*h);
		}

	// If the heap has just�been modified, re-fill free chunks
	if (postModify) {
		if (GMemDebugMode & memDebugModeFillFree)
			PrvFillFreeChunks(heapID);
		}
		
	else {
		if (GMemDebugMode & memDebugModeCheckOnAll  ||
			 	((GMemDebugMode & memDebugModeCheckOnChange) && alwaysScramble))
			 check = true;
			 
		if (GMemDebugMode & memDebugModeScrambleOnAll  ||
			 ((GMemDebugMode & memDebugModeScrambleOnChange) && alwaysScramble))
			 scramble = true;
			 
			 
		//-----------------------------------------------------------------------
		// Loop through all heaps
		//-----------------------------------------------------------------------
		if (GMemDebugMode & memDebugModeAllHeaps) {
			infoP = memCardInfoP(0);
			for (cardNo=0; cardNo < GMemCardSlots; cardNo++, infoP++) {
				if (!infoP->size) continue;
				for (heapNo = 0; heapNo < MemNumRAMHeaps(cardNo); heapNo++) {
					heapID = MemHeapID(cardNo, heapNo);
					
					if (check)
						err = MemHeapCheck(heapID);
					if (err) goto Exit;
					
					if (scramble) {
						err = MemHeapScramble(heapID);
						if (GMemDebugMode & memDebugModeFillFree)
							PrvFillFreeChunks(heapID);
						}
	
					if (err) goto Exit;
					}
					
				} // cardNo
			
			}
			
		//-----------------------------------------------------------------------
		// Just the one heap
		//-----------------------------------------------------------------------
		else {
			// See if we need to check the heap
			if (check)
				err = MemHeapCheck(heapID);
			if (err) goto Exit;
				
			// See if we need to scramble the heap
			if (scramble) {
				err = MemHeapScramble(heapID);
				if (GMemDebugMode & memDebugModeFillFree)
					PrvFillFreeChunks(heapID);
				}
			}
		}
		
Exit:
	// Release ownership
	MemSemaphoreRelease(false);
	
	return;	
}






/************************************************************
 * PRIVATE
 *-------------------------------------------------------------
 *  FUNCTION: PrvFillFreeChunks, private
 *
 *  DESCRIPTION: Fills all free chunks in a heap with data
 *
 *  PARAMETERS: heapID
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void PrvFillFreeChunks(UInt heapID)
{
	MemHeapHeaderPtr		   	heapP;
	MemChunkHeaderPtr				chunkP;
	Ptr							chunkDataP;
	ULong							heapOffset;
	WordPtr						wP;
	DWord							count;
	
	
	// Get a near heap pointer from the heap ID
	heapP = MemHeapPtr(heapID);
	
	// If it's read only, don't do anything
	if (heapP->flags & memHeapFlagReadOnly) {
		return;
		}
		

	// Get pointer to first chunk
	heapOffset = sizeof(MemHeapHeaderType) 
					+ heapP->mstrPtrTbl.numEntries * sizeof(Ptr);
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + heapOffset);
	
	
	// Walk through the chunks
	do {

		// If it's a free chunk, init it's contents
		if (chunkP->free) {
			chunkDataP = (Ptr)((BytePtr)chunkP + sizeof(MemChunkHeaderType));
			wP = (WordPtr)chunkDataP;
			count = chunkP->size - sizeof(MemChunkHeaderType);
			count = (count >> 1) + 1;
			while(--count) 
				*wP++ = memFillFreeValue;
			}
			
				
		// On to next chunk
		chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		} while(chunkP->size);
					
}






/************************************************************
 *
 *  FUNCTION: PrvCurOwnerID, private
 *
 *  DESCRIPTION: Returns the owner ID of the current application by
 *    referencing the appInfo structure stored at 0(A5).
 *
 *  PARAMETERS: none
 *
 *  RETURNS: owner ID
 *
 *  CREATED: 4/12/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static UInt PrvCurOwnerID(void)
{
	SysAppInfoPtr	unusedAppInfoP;
	
	
	return SysGetAppInfo(&unusedAppInfoP, &unusedAppInfoP)->memOwnerID;
}
	


/************************************************************
 *
 *  FUNCTION: PrvInitHeapPtr, private
 *
 *  DESCRIPTION: Initializes a block of RAM as a heap and fills it
 *		with one free chunk
 *
 *  PARAMETERS: heap pointer, heap size, number of handles
 *		to pre-allocate
 *
 *  NOTE: if numHandles is 0, it is assumed that the heap is a ROM heap
 *   so the read only bit will be set in the heap header
 *
 *  RETURNS: error code
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err	PrvInitHeapPtr(MemHeapHeaderPtr heapP, ULong size, UInt numHandles,
					Boolean initContents)
{
	MemChunkHeaderPtr	 		chunkP;
	Ptr*							iP;
	
	register ULong				free;
	Int							i;

	MemHeapTerminatorType*	termP;
	
	// Init the heap header
	if (numHandles == 0) 
		heapP->flags = memHeapFlagReadOnly | memHeapFlagVers2;
	else 
		heapP->flags = memHeapFlagVers2;
	
	heapP->size = size;
	heapP->mstrPtrTbl.numEntries = numHandles;
	heapP->mstrPtrTbl.nextTblOffset = 0;
	free = size - sizeof(MemHeapHeaderType) - sizeof(MemChunkHeaderType) 
				- heapP->mstrPtrTbl.numEntries * sizeof(Ptr)
				 - sizeof(MemHeapTerminatorType) /* for 0 terminator */;


	// Initialize the master pointer table to 0's.
	iP = (Ptr*)((BytePtr)heapP + sizeof(MemHeapHeaderType));
	for (i=0; i<numHandles; i++) 
		*iP++ = 0;


	// Make the first free chunk. It starts after the heap header, and after 
	// the offset table.
	chunkP = (MemChunkHeaderPtr)iP;
	memClearChunkHeader(chunkP);
	chunkP->size =  free + sizeof(MemChunkHeaderType);
	chunkP->free = true;
	
	
	// Initialize the contents, if specified
	if (initContents)
		MemSet((BytePtr)chunkP + sizeof(MemChunkHeaderType), chunkP->size - sizeof(MemChunkHeaderType), 0x55);
		
	
	// Make the end of heap marker 
	termP = (MemHeapTerminatorType*)((BytePtr)chunkP + chunkP->size);
	*termP = 0;                   


   return 0;
}





/************************************************************
 *
 *  FUNCTION: CompactHeap, Private
 *
 *  DESCRIPTION: Compacts a heap 
 *
 *  PARAMETERS: heap pointer, saved DS
 *
 *  RETURNS: error code
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	1/27/98	Fixed heap corruption in master pointer freeing code
 *
 *************************************************************/
static Err	 PrvCompactHeap(MemHeapHeaderPtr heapP)
{

	MemChunkHeaderPtr			firstChunkP, chunkP, immigrantP;
	MemChunkHeaderPtr			nextChunkP;
	MemMstrPtrTablePtr		mstrTblP;
	MemMstrPtrTablePtr		prevTblP;
	Ptr*						entryP;
	Int						i;
	Boolean					firstFreeMstrSkipped = false;


	//-------------------------------------------------------------------
	// We take this time to free up any master pointer chunks that are no longer
	//  used.
	//-------------------------------------------------------------------
	prevTblP = &heapP->mstrPtrTbl;
	while(prevTblP->nextTblOffset) {
	
		// Get pointer to next table
		mstrTblP = (MemMstrPtrTablePtr)((DWord)heapP + prevTblP->nextTblOffset);
	
		// See if it's all free
		entryP = (Ptr*)((DWord)mstrTblP + sizeof(MemMstrPtrTableType));
		for (i=mstrTblP->numEntries; i>0; i--, entryP++) 
			if (*entryP) break;
				
		// If not all free, go to next block
		if (i > 0) {
			prevTblP = mstrTblP;
			continue;
			}
		
		// If it's all free, take it out of the linked list and dispose it
		//
		// But never delete the first "unused" master pointer chunk...
		// This fixes the bug where we're allocating a moveable chunk, and, as a result,
		// find a free handle in a master pointer chunk with all free handle slots or a new
		// master pointer chunk is added, but then compaction is triggered while
		// allocating the chunk itself, which deletes the just allocated master pointer
		// chunk before we have a chance to store the new chunk's handle in it.  Subsequently,
		// we ended up storing handles in a master pointer chunk that is marked
		// free (and available for allocation).  This was resulting in heap corruption.
		// It is believed that this was a bug in 1.0 and 2.0 as well.	vmk 1/27/98
		if ( firstFreeMstrSkipped ) {
			prevTblP->nextTblOffset = mstrTblP->nextTblOffset;
			PrvChunkFree(mstrTblP);
			}
		else {
			prevTblP = mstrTblP;					// skip the first "unused" master pointer chunk
			firstFreeMstrSkipped = true;
			}
		}




	// Get a pointer to the first chunk
	firstChunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );
	chunkP = firstChunkP;


	//-------------------------------------------------------------------
	// While not at the end of the heap, try and find movable chunks that
	//  we can move into free spaces at the front of the heap.
	// 
	// <RM> 1-21-98
	// Modified to speed up heap compaction. The old code here had a "hole"
	//  in the logic that always made it call PrvFindBiggestMovableChunk
	//  after it had merged free chunks together.
	// Now, we first try and merge following free chunks then either move
	//  the next chunk up into the free space if it's movable or search
	//  for another movable chunk somewhere else. 
	//-------------------------------------------------------------------
	while(chunkP->size) {

		// Search for the next free chunk
		while(!(chunkP->free)) {
			chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
			if (!chunkP->size) break;
			}
		if (!chunkP->size) break;


		// Get pointer to the following chunk, Exit loop if we're at the end of
		//  the heap (nextChunkP->size == 0)
		nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		if (!nextChunkP->size) break;
		

		//------------------------------------------------------------
		// First, merge any following free chunks into the current (free)
		//  chunk. Keep doing this till we come to the next non-free chunk. 
		//------------------------------------------------------------
		while (nextChunkP->free) {
			chunkP->size += nextChunkP->size;
			nextChunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
			if (! nextChunkP->size) break;
			}
		// Exit if we're at the end of the heap
		if (! nextChunkP->size) break;


		//------------------------------------------------------------
		// If the following chunk is movable, shift it up to fill the
		// free space.
		//------------------------------------------------------------
		if ( (nextChunkP->lockCount) == 0 && !(nextChunkP->free)) {
			PrvMoveChunk(chunkP, nextChunkP);
			}

		//------------------------------------------------------------
		// Else, try and find a movable chunk somewhere else in the heap
		// that will fit into this free space.
		//------------------------------------------------------------
		else {
			// Search for a chunk that we can move into this free space
			immigrantP = PrvFindBiggestMovableChunk(nextChunkP, chunkP->size);
			
			// If we found one, move it
			if (immigrantP) 
				PrvMoveChunk(chunkP, immigrantP);
			}

		// skip this  chunk and search for the next free one
		chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		}  		

	return 0;

}




/************************************************************
 *
 *  FUNCTION: PrvFindBiggestMovableChunk, Private
 *
 *  DESCRIPTION: Searches heap for the biggest movable chunk that is
 *		less than or equal to maxSize.
 *
 *  PARAMETERS: heap pointer, start offset, maxSize
 *
 *  RETURNS: chunk pointer, or nil
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static MemChunkHeaderPtr PrvFindBiggestMovableChunk(MemChunkHeaderPtr startP, 
										DWord maxSize)
{

	MemChunkHeaderPtr	chunkP;
	MemChunkHeaderPtr	bestP = 0;
	DWord				bestSize = 0;

	// Loop through and find a movable chunk that's <=  maxSize
	chunkP = startP;

	while(chunkP->size) {
		if (! (chunkP->free))
			if ((chunkP->lockCount) == 0)
				if (chunkP->size <= maxSize && chunkP->size > bestSize) {
					bestP = chunkP;
					bestSize = bestP->size;
					}

		chunkP = (MemChunkHeaderPtr)((BytePtr)chunkP + chunkP->size);
		}

	// Return it
	return bestP;
}




/************************************************************
 *
 *  FUNCTION: PrvMoveChunk, private
 *
 *  DESCRIPTION: Moves src chunk to dest chunk and creates
 *    a free chunk to fill space left by src chunk and
 *    space at end of dest chunk not taken up by src chunk.
 *
 *    This routine correctly handles the situation where dest chunk
 *    overlaps src chunk as long as dest chunk is BEFORE src chunk.
 *
 *  PARAMETERS: dest chunk pointer, src chunk pointer
 *
 *  RETURNS: void
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void  PrvMoveChunk(MemChunkHeaderPtr dstChunkP, MemChunkHeaderPtr srcChunkP)
{
	DWord					srcMinActSize, words, dSize;
	DWord					srcOldActSize, dstOldActSize;
	DWord					srcReqSize;
	WordPtr				srcP, dstP;
	MemChunkHeaderPtr		chunkP;
	Boolean				overlap;
	Ptr*					ptrP;


	// Save the actual sizes
	dstOldActSize = dstChunkP->size;
	srcOldActSize = srcChunkP->size;


	// See if they overlap
	overlap = false;
	if (dstChunkP < srcChunkP) 
		if ((DWord)dstChunkP + srcOldActSize > (DWord)srcChunkP) 
			overlap = true;


	// Get the min actual size and the requested sizes of each chunk
	srcReqSize = srcChunkP->size - (srcChunkP->sizeAdj);
	srcMinActSize = srcReqSize;
	if (srcMinActSize & 0x01) srcMinActSize++;

	// Get the address of the master pointer (the handle) of the chunk being moved
	ptrP = (Ptr*)((DWord)srcChunkP - ((Long)srcChunkP->hOffset << 1));
	


	// Copy src to dst using the min required size of the src
	srcP = (WordPtr)srcChunkP;
	dstP = (WordPtr)dstChunkP;
	words = srcMinActSize >> 1;
	if (words) 
	do {
		*dstP++ = *srcP++;
		} while(--words);



	// Update the handle to point to the new home
	*(ptrP) = (Ptr)dstChunkP + sizeof(MemChunkHeaderType);
	
	// Update the hOffset field of the moved chunk to reference the master pointer
	dstChunkP->hOffset = ((DWord)dstChunkP - (DWord)ptrP) >> 1;


	//-------------------------------------------------------------
	// Figure out the size and location of the free chunk that will
	// go at the end of dst after we've moved the chunk there.
	//-------------------------------------------------------------
	chunkP = (MemChunkHeaderPtr)((BytePtr)dstChunkP + srcMinActSize);

	if (!overlap) 
		dSize = dstOldActSize - srcMinActSize;
	else 
		dSize = (DWord)(srcChunkP) + srcOldActSize - (DWord)chunkP;
		

	//-------------------------------------------------------------
	// Create the free chunk at the end of dst, if we have enough 
	// to form a chunk header.
	//-------------------------------------------------------------
	if (dSize >= sizeof(MemChunkHeaderType)) {

		// Clip the size of the moved chunk down to a minimum
		dstChunkP->size = srcMinActSize;

		// Create the free chunk at the end
		memClearChunkHeader(chunkP);
		chunkP->size = dSize;
		chunkP->free = true;
		}

	// Else, just grow it slightly to take up the slack
	else {
		dstChunkP->size = dstOldActSize;
		}


	// Set the appropriate size adjustment for the moved chunk
	dstChunkP->sizeAdj = dstChunkP->size - srcReqSize;


	// Create free chunk where the src chunk came out from
	if (!overlap) {
		DWord		oldSize;
		oldSize = srcChunkP->size;
		memClearChunkHeader(srcChunkP);
		srcChunkP->size = oldSize;
		srcChunkP->free = true;
		}

}



/************************************************************
 *
 *  FUNCTION: PrvUnlockAllChunks, Private
 *
 *  DESCRIPTION: Scans the heap and unlocks all movable chunks.
 *
 *  PARAMETERS: heapID
 *
 *  RETURNS: chunk pointer, or nil
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void  PrvUnlockAllChunks(UInt heapID)
{
	MemHeapHeaderPtr		heapP;
	MemChunkHeaderPtr	chunkP;

	// Get a near heap pointer from the heapID
	heapP = MemHeapPtr(heapID);

	// Walk the heap
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );

	while(chunkP->size) {
		if ((chunkP->lockCount) != memPtrLockCount)
		chunkP->lockCount = 0;

		// Go on to next chunk
		chunkP = (MemChunkHeaderPtr) ((BytePtr)chunkP + chunkP->size);
		}
		
}


/************************************************************
 *
 *  FUNCTION: PrvAdjustForNewAddress, Private
 *
 *  DESCRIPTION: Adjusts all handles after a memory card had been moved
 *		to a different slot, or when emulation app has re-launched and has
 *		a different address for the memory card. This routine is called by
 *		MemInitHeapTable.
 *
 *  PARAMETERS: heapID
 *
 *  RETURNS: chunk pointer, or nil
 *
 *  CREATED: 11/03/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void  PrvAdjustForNewAddress(UInt heapID)
{
	MemHeapHeaderPtr		heapP;
	MemChunkHeaderPtr		chunkP;
	Ptr*					ptrP;

	// Get a near heap pointer from the heapID
	heapP = MemHeapPtr(heapID);

	// Walk the heap
	chunkP = (MemChunkHeaderPtr)((BytePtr)heapP + sizeof(MemHeapHeaderType)
					+ (heapP->mstrPtrTbl.numEntries << 2) );

	while(chunkP->size) {
		// See if this chunk has a handle
		if (chunkP->hOffset) {
			
			// Get the master pointer address		
			ptrP = (Ptr*)((DWord)chunkP - ((Long)chunkP->hOffset << 1));
	
			// Update the handle to point to the chunk
			*(ptrP) = (Ptr)chunkP + sizeof(MemChunkHeaderType);
			}
   
		// Go on to next chunk
		chunkP = (MemChunkHeaderPtr) ((BytePtr)chunkP + chunkP->size);
		}
		
}



/************************************************************
 * PRIVATE
 *-------------------------------------------------------------
 *  FUNCTION: PrvGetCardHeaderPtr, private
 *
 *  DESCRIPTION: Returns the card header pointer for a card
 *			and a boolean signifying whehter it's RAM only or not
 *
 *  PARAMETERS: card number, reference to boolean
 *
 *  RETURNS: card header pointer
 *
 *  CREATED: 11/09/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static CardHeaderPtr PrvGetCardHeaderInfo(UInt cardNo, 
		CardInfoPtr* cardInfoPP, Boolean* ramOnlyCardP)
{
	CardHeaderPtr		cardP;
	CardInfoPtr			infoP;

	// Get the card size and base address
	ErrFatalDisplayIf(cardNo >= GMemCardSlots, "Invalid Card #");
	
	
	
	// Get the card info (optimized for 2 cards)
	if (cardNo == 0) 
		infoP = memCardInfoP(0);  
	else
		infoP = memCardInfoP(1);

	*cardInfoPP = infoP;
	if (!infoP->size) return 0;



	//------------------------------------------------------------
	// Look for the ROM card header
	//------------------------------------------------------------
	if (infoP->cardHeaderOffset == sysRAMOnlyCardHeaderOffset) {
		*ramOnlyCardP = true;
		cardP = (CardHeaderPtr)infoP->baseP;
		}
	else {
		*ramOnlyCardP = false;

		#if EMULATION_LEVEL != EMULATION_NONE
		cardP = (CardHeaderPtr)MemLocalIDToPtr(infoP->cardHeaderOffset, cardNo);
		#else
		cardP = (CardHeaderPtr)(infoP->baseP + infoP->cardHeaderOffset);
		#endif
		}
	
	
	
	return cardP;
}


/************************************************************
 *
 *  FUNCTION: PrvHeapPtrAndID, private
 *
 *  DESCRIPTION: Returns the heap pointer and heapID for a given chunk
 *
 *  PARAMETERS: chunk data pointer
 *
 *  RETURNS: heap ID
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static MemHeapHeaderPtr		PrvHeapPtrAndID(Ptr chunkDataP, UInt* heapIDP)
{
	UInt					i;
	MemHeapHeaderPtr		heapP;
	UInt					heapID;
	ULong					size;
	DWord					chunkOffset, heapOffset;
	
	CardInfoPtr			infoP;
	Boolean				found=false;
	
	
	// Check for error
	ErrFatalDisplayIf(chunkDataP==0, "Nil Chunk ptr");
	
	
	
	// See if it's in card 1
	if (GMemCardSlots > 1) {
		infoP = memCardInfoP(1);
		if (	(DWord)chunkDataP > (DWord)infoP->baseP  &&  
				(DWord)chunkDataP < (DWord)infoP->baseP + infoP->size) {
			found = true;
			heapID = 0x8000;
			}
		}
		
		
	// If not card 1, check card 0
	if (!found) {
		infoP = memCardInfoP(0);
		if (((DWord)chunkDataP < infoP->dynHeapSpace + infoP->rsvSpace) ||
			 ((DWord)chunkDataP > (DWord)infoP->baseP  &&  
				 (DWord)chunkDataP < (DWord)infoP->baseP + infoP->size)) {
			found = true;
			heapID = 0x0000;
			}
		}
		
	// If still not found, see if it's in the dynamic heap
#if EMULATION_LEVEL == EMULATION_NONE
	if (!found) {
		if ((DWord)chunkDataP & ~hwrCardOffsetMask == 0) {
			infoP = memCardInfoP(0);
			found = true;
			heapID = 0x0000;
			}
		}
#endif
		
	if (!found) {
		ErrDisplay("Invalid Chunk Ptr");
		return 0;
		}
	


	// Get Chunk Info
	chunkOffset = (DWord)chunkDataP - (DWord)infoP->baseP;


		
	// Search for the heap pointer in the RAM Heaps
	for (i=0; i<infoP->numRAMHeaps; i++) {
		heapOffset = infoP->ramHeapOffsetsP[i];
		if (heapOffset > chunkOffset) continue;
		
		heapP = (MemHeapHeaderPtr)(infoP->baseP + heapOffset);
		size = heapP->size;
		if (!size) size = 0x00010000L;
		if (heapOffset + size < chunkOffset) continue;
		
		*heapIDP =  heapID | i;
		return heapP;
		}
		
	// Search for the heap pointer in the ROM Heaps
	for (i=0; i<infoP->numROMHeaps; i++) {
		heapOffset = infoP->romHeapOffsetsP[i];
		if (heapOffset > chunkOffset) continue;
		
		heapP = (MemHeapHeaderPtr)(infoP->baseP + heapOffset);
		size = heapP->size;
		if (!size) size = 0x00010000L;
		if (heapOffset + size < chunkOffset) continue;
		
		// <RM> 1-26-98
		// Now add infoP->numRAMHeaps to the heap index. 
		*heapIDP =  heapID | (i + infoP->numRAMHeaps);
		return heapP;
		}
		
	// If we got here, error
	ErrDisplay("Heap ID not found");
	return 0;
		
} 



/************************************************************
 *
 *  FUNCTION: PrvCalcStoreCRC, private
 *
 *  DESCRIPTION: Calculates the CRC for a Memory Store
 *
 *  PARAMETERS: store pointer
 *
 *  RETURNS: crc
 *
 *  CREATED: 5/2/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static DWord	PrvCalcStoreCRC(StorageHeaderPtr storeP)
{
	return Crc16CalcBlock(storeP, 
				sizeof(StorageHeaderType) - sizeof(DWord), 0);
}
		
	
#endif //#if 	MEMORY_VERSION == MEMORY_VERSION_2 

