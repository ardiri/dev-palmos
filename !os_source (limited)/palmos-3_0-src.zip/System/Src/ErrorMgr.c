/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		error.c
 *
 * Description:
 *		Error Management routines for Pilot
 *
 * History:
 *   	10/25/94  RM - Created by Ron Marianetti
 *
 *******************************************************************/


#include <SysAll.h>
#include <FatalAlert.h>

#define	NON_PORTABLE
#include <SystemPrv.h>
#include <EmuStubs.h>


#if EMULATION_LEVEL == EMULATION_NONE

/************************************************************
 *
 *  FUNCTION: ErrSetJump
 *
 *  DESCRIPTION: Saves PC and all processor registers except those that
 *		can change after calling a C routine into a structure of
 *		type ErrJumpBuf.
 *
 *		ErrSetJump is always used with ErrLongJump. After saving the
 *		context with ErrSetJump, an application can at any later time
 *		make a call to ErrLongJump and return immediately to the
 *		instruction following the ErrSetJump call with all
 *		processor registers and stack pointer set to the same values
 *		they had when the context was saved with ErrSetJump.
 *
 *		On return from ErrSetJump as a result of a ErrLongJump, the
 *		result will be non-zero.
 *
 *  PARAMETERS: Pointer to ErrJumpBuf structure
 *
 *  RETURNS: 0 when saving context, non 0 if returning from a ErrLongJump
 *
 *  CREATED: 3/2/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Int asm ErrSetJump(ErrJumpBuf buf)
{
		MOVE.L	(SP)+, A1							// get return address
		MOVE.L	(SP), A0							// pointer to buf
		MOVEM.L	D3-D7/A1-A7, (A0)					// save registers
		MOVEQ	#0, D0								// result code
		JMP		(A1)								// return to caller
}


/************************************************************
 *
 *  FUNCTION: ErrLongJump
 *
 *  DESCRIPTION: Restores PC and all processor registers except those that
 *		can change after calling a C routine from a structure of
 *		type ErrJumpBuf.
 *
 *		ErrSetJump is always used with ErrLongJump. After saving the
 *		context with ErrSetJump, an application can at any later time
 *		make a call to ErrLongJump and return immediately to the
 *		instruction following the ErrSetJump call with all
 *		processor registers and stack pointer set to the same values
 *		they had when the context was saved with ErrSetJump.
 *
 *		On return from ErrSetJump as a result of a ErrLongJump, the
 *		result will be non-zero.
 *
 *  PARAMETERS: Pointer to ErrJumpBuf structure, non-zero result code
 *		for "return" from ErrSetJump
 *
 *  RETURNS: void
 *
 *  CREATED: 3/2/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void asm ErrLongJump(ErrJumpBuf buf, Int result)
{
		ADD.W	#4, SP							// ignore return address
		MOVE.L	(SP)+, A0						// get pointer to buf
		MOVE.W	(SP), D0						// result code
		BNE.S	@0								// if non-zero -->
		MOVEQ	#1, D0							// force non-zero
@0:
		MOVEM.L	(A0), D3-D7/A1-A7				// restore registers
		JMP		(A1)							// return to original PC
}


#endif // EMULATION_LEVEL == EMULATION_NONE

/************************************************************
 *
 *  FUNCTION: ErrExceptionList
 *
 *  DESCRIPTION: Returns the address of the pointer to the
 *   first ErrExceptionType structure linked into the
 *   exception list. Used by the ErrTry, ErrCatch, and ErrThrow
 *   macros in order to find the exception list.
 *
 *   When called from an application task, this routine returns
 *   the application's exception list which is stored in the
 *   SysAppInfoPtr of the app. When called from a system thread,
 *   this routine returns the system's exception list, which is
 *   stored in a low memory global.
 *
 *  PARAMETERS: none
 *
 *  RETURNS: address of the pointer.
 *
 *  CREATED: 5/16/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Ptr* ErrExceptionList(void)
{
	SysAppInfoPtr appInfoP;
	
	// We do this so we don't have to link in the SystemMgr.c module
	//  with every app on the host that uses the Error Manager. Under emulation
	//  mode, there are no separate tasks so we might as well use the
	//  the System List stored at GErrFirstExceptionP.
	#if EMULATION_LEVEL == EMULATION_NONE
	SysAppInfoPtr unusedAppInfoP;
	
	appInfoP = SysGetAppInfo(&unusedAppInfoP, &unusedAppInfoP);
	#else
	appInfoP = (SysAppInfoPtr)GCurUIAppInfoP;
	#endif
	
	return &appInfoP->errExceptionP;
}




/************************************************************
 *
 *  FUNCTION: ErrThrow
 *
 *  DESCRIPTION: A Throw causes a jump to the nearest Catch block.
 *
 *  PARAMETERS: error code
 *
 *  RETURNS: never returns
 *
 *  CREATED: 3/2/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void ErrThrow(Long err)
{
	ErrExceptionType*	tryP;
	
	tryP = (ErrExceptionPtr)*ErrExceptionList();
	
	if (tryP) {
		tryP->err = err;
		ErrLongJump(tryP->state, 1);
		}
		
	else {
		ErrDisplay("ErrThrow called without a pending ErrTry");
		}

}



/************************************************************
 *
 *  FUNCTION: ErrDisplayFileLineMsg
 *
 *  DESCRIPTION: Displays a non-exitable dialog with an error message
 *		Does not allow user to continue
 *
 *  PARAMETERS: filename, line number, message
 *
 *  RETURNS: never returns
 *
 *  CREATED: 10/25/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	1/20/98	Added check for fatalDoNothing
 *
 *************************************************************/
void ErrDisplayFileLineMsg(const Char * const filename, UInt lineNo, const Char * const msg)
{

#if EMULATION_LEVEL == EMULATION_MAC
	StubErrDisplayFileLineMsg(filename, lineNo, msg);

#else
	UInt	fatalAlertResult;
	char	text[256];
	char	str[10];
	
	
	// Form the error message
	StrCopy(text, filename);
	StrCat(text, ", Line:");
	StrIToA(str, lineNo);
	StrCat(text, str);
	StrCat(text, ", ");
	StrCat(text, msg);


	// If the UI has not been initialized yet, we can't put up an alert
	//  so we'll force entry into the Debugger
	if (!(GSysMiscFlags & sysMiscFlagUIInitialized)) {
		GDbgWasEntered = true;
		DbgBreak();
		}
				
		
	// If the debugger was entered already, go to it
	if (GDbgWasEntered) {
		DbgMessage(text);
		DbgMessage("\n");
		DbgBreak();
		}
		
	// Else, show a fatal alert
	else {
		// If we re-entered, something terrible is wrong so just loop indefinitely so that
		//  we don't eat up stack space.
		if (GSysMiscFlags & sysMiscFlagInFatalAlert) 
			while(1)	
				;
				
		// Set flag to detect re-entry
		GSysMiscFlags |= sysMiscFlagInFatalAlert;
	
	
		// Display alert and reset if the first button (0) is pressed.
		if ( (fatalAlertResult = SysFatalAlert(text)) == fatalReset )
			SysReset();
			
		// If the the second button(1) is pressed (can only happen with
		//  full error checking on) go into Debugger.
		else if ( fatalAlertResult != fatalDoNothing )
			DbgBreak();
			
		// Clear re-entry detector
		GSysMiscFlags &= ~sysMiscFlagInFatalAlert;
		}
		
		

#endif
}





