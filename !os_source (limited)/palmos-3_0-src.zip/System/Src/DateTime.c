/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     DateTime.c
 * AUTHOR:	 Roger Flores: Feb 6, 1995
 *
 * DECLARER: System
 *
 * ROUTINES:
 *     
 *		
 * DESCRIPTION:
 *	  This file contains the time manager routines.
 *
 **********************************************************************/

#include <SysAll.h>
#include <DateTime.h>

#include <Chars.h>


/***********************************************************************
 *
 * FUNCTION: 	 TimAdjust
 *
 * DESCRIPTION: Return a new date +- the time adjustment.  This is useful
 * for advancing a day or week and not worrying about month and year wrapping.
 * If the time is advanced out of bounds it is is cut at the bounds surpassed.
 *
 * PARAMETERS:  struct tm, the adjustment in seconds
 *
 * RETURNED:	the adjust struct tm
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95	Initial Revision
 *
 ***********************************************************************/
 
void TimAdjust(DateTimePtr dateTimeP, Long adjustment)
{
	ULong seconds;
	
	seconds = TimDateTimeToSeconds(dateTimeP);

	// we must be careful about large dates which appear negative if
	// signed.	
	if (adjustment < 0)
		{
		adjustment = -adjustment;
		if ((ULong) adjustment > seconds)
			seconds = 0;
		else
			seconds -= (ULong) adjustment;
		}
	else
		{
		seconds += adjustment;
		if (seconds > (ULong) maxSeconds)
			seconds = maxSeconds;
		}

	TimSecondsToDateTime(seconds, dateTimeP);
}


/***********************************************************************
 *
 * FUNCTION: 	 TimDateTimeToSeconds
 *
 * DESCRIPTION: Return the date and time in seconds since 1/1/1904
 *
 * PARAMETERS:  struct tm
 *
 * RETURNED:	the time in seconds since 1/1/1904
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95		Initial Revision
 *
 ***********************************************************************/
 
ULong TimDateTimeToSeconds(DateTimePtr dateTimeP)
{
	ULong seconds;
	UInt years;
	UInt i;
	
	seconds = ((ULong) (dateTimeP->year - firstYear) / 4) * daysInFourYears;
	years = (dateTimeP->year - firstYear) % 4;
	
	// The first year of four years is a leap year (1904 is a leap year).
	// Add the seconds of the years between the year and the prior leap year
	// (not the last year because it's a partial year).
	if (years > 0)
		{
		seconds += daysInLeapYear;
		years--;
		seconds += years * daysInYear;
		}
	
	// Now add the seconds elapsed in the last year.
	years = dateTimeP->year;
	for (i = dateTimeP->month - 1; i > 0; i--)
		{
		seconds += DaysInMonth(i, years);
		}
	
	seconds += dateTimeP->day - 1;
	
	seconds = seconds * daysInSeconds;
	
	seconds += (ULong) dateTimeP->hour * hoursInSeconds;
	
	seconds += dateTimeP->minute * minutesInSeconds;
	
	seconds += dateTimeP->second;
	
	return seconds;
}


/***********************************************************************
 *
 * FUNCTION:	TimSecondsToDateTime
 *
 * DESCRIPTION: Return the date and time given seconds
 *
 * PARAMETERS:  struct tm
 *
 * RETURNED:	the date and time given seconds since 1/1/1904
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95		Initial Revision
 *
 ***********************************************************************/
 
void TimSecondsToDateTime(ULong seconds, DateTimePtr dateTimeP)
{
	UInt fourYears;
	UInt dayInMonth;
	ULong day;
	
	
	// Now convert from seconds to days.
	day = seconds / daysInSeconds;
	seconds = seconds % daysInSeconds;
	dateTimeP->weekDay = (day + 5) % daysInWeek;
	
	fourYears = day / daysInFourYears;
	day %= daysInFourYears;
	
	if (day >= daysInLeapYear)
		{
		day -= daysInLeapYear;
		dateTimeP->year = firstYear + fourYears * 4 + 1 + day / daysInYear;
		day %= daysInYear;
		}
	else
		dateTimeP->year = firstYear + fourYears * 4;
	
	
	// We are down to one year
	dateTimeP->month = 1;
	while ((dayInMonth = DaysInMonth(dateTimeP->month, dateTimeP->year)) <=
			day)
		{
		day -= dayInMonth;
		dateTimeP->month += 1;
		}
		
	dateTimeP->day = day + 1;

	// now calc the time 
	dateTimeP->hour = seconds / hoursInSeconds;
	seconds = seconds % hoursInSeconds;
	dateTimeP->minute = seconds / minutesInSeconds;
	seconds = seconds % minutesInSeconds;
	dateTimeP->second = seconds;
	
	
}


/***********************************************************************
 *
 * FUNCTION: 	 DayOfWeekArray, private
 *
 * DESCRIPTION: Returns pointer to array of day of week offsets
 *
 *  PARAMETERS:  	void
 *
 *  RETURNS: BytePtr
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/2/95	Initial Revision
 *
 ***********************************************************************/
static BytePtr asm 	DayOfWeekArray(void)
{
	// Code from Tomohiko Sakamoto
	//	static int t[] = {0,3,2,5,0,3,5,1,4,6,2,4};

	LEA	@array, A0
	RTS
@array:
	DC.B	4,0,6,2,4,0,2,5,1,3,6,1
}


/***********************************************************************
 *
 * FUNCTION: 	 DayOfWeek
 *
 * DESCRIPTION: Returns the day of the week.
 *
 * PARAMETERS:  month, day, year (ex: 1995)
 *
 * RETURNED:	the day of the week (sunday = 0, monday=1, etc.)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95		Initial Revision
 *
 ***********************************************************************/
UInt DayOfWeek (UInt month, UInt day, UInt year)
{
	UInt year2000Correction = 0;
	
	
	// The year 2000 is a leap year.
	if (year > 2000)
		year2000Correction = 1;
	else if (year == 2000 && month > 2)
		year2000Correction = 1;
		
	year -= month < 3;
	return (year + year / 4 - year / 100 + DayOfWeekArray()[month-1] + 
		day + year2000Correction) % daysInWeek;
}


/***********************************************************************
 *
 * FUNCTION: 	 DayOfMonth
 *
 * DESCRIPTION: Returns the day of a month (ex: first Friday) on 
 *              which the specified date occurs.
 *
 * PARAMETERS:  month, day, year (ex: 1995)
 *
 * RETURNED:	the day of the month
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/14/95	Initial Revision
 *
 ***********************************************************************/
UInt DayOfMonth (UInt month, UInt day, UInt year)
{
	Int dayOfWeek;
	
	dayOfWeek = DayOfWeek (month, day, year);
	
	return ((day-1) / daysInWeek * daysInWeek + dayOfWeek);
}


/***********************************************************************
 *
 * FUNCTION: 	 DaysInMonth
 *
 * DESCRIPTION: Returns the number of days in the month
 *
 * PARAMETERS:  year, month
 *
 * RETURNED:	days in the month
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	1/31/95		Initial Revision
 *
 ***********************************************************************/ 
UInt DaysInMonth(UInt month, UInt year)
{
	// if August or later
	if (month >= 8)
		return 31 - (month & 1);
		
	// if not February
	if (month != 2)
		return 30 + (month & 1);
		
	// If not a leap year
	if ((year - firstYear) % 4 != 0)
		return 28;
	
	// All years divisible by four in our time span (1904 - 2032) 
	// are leap years.
	return 29;
}



/***********************************************************************
 *
 * FUNCTION:    TimeToAscii
 *
 * DESCRIPTION:  Convert the time passed to an ascii string.
 *
 * PARAMETERS:  hours    - hours (0-23)
 *					 minutes	 - minutes (0-59)
 *					 timeFormat - how to format the time string
 *					 pString  - pointer to string which gets the result. The
 *									string must be of length timeStringLength
 *
 * RETURNED:	 pointer to the text of the current selection
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *			roger 2/28/95	Changed and made available to system
 *			roger 8/5/96	Added new tfComma24h format
 *
 ***********************************************************************/
void TimeToAscii(Byte hours, Byte minutes, TimeFormatType timeFormat, CharPtr pString)
	{
	char t;
	
	
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	// Fill up the destination as much as allowed with a value to reveal errors.
	MemSet(pString, timeStringLength, 0xfe);	
#endif
	
	t = hours;
	if ( (timeFormat == tfColon24h) || (timeFormat == tfDot24h) ||
		  (timeFormat == tfHours24h) || (timeFormat == tfComma24h) )
		{
		if (t >= 20)
			{
			t -= 20;
			*pString++ = '2';
			}
		}
	else
		{
		t %= 12;

		if (t == 0)
			{
			t = 2;
			*pString++ = '1';
			}
		}

	if (t >= 10)
		{
		t -= 10;
		*pString++ = '1';
		}
	*pString++ = '0' + t;


	// Now add the minutes
	if ( (timeFormat != tfHoursAMPM) && (timeFormat != tfHours24h) )
		{
		*pString++ = TimeSeparator(timeFormat);
	
		// Translate minutes in to text characters:
		*pString++ = '0' + minutes / 10;
		*pString++ = '0' + minutes % 10;
		}
			
	
	if ( (timeFormat == tfColonAMPM) || (timeFormat == tfDotAMPM) ||
		(timeFormat == tfHoursAMPM))
		{
		*pString++ = ' ';
		if (hours >= 12)
			*pString++ = 'p';
		else
			*pString++ = 'a';
		*pString++ = 'm';
		}

	*pString++ = '\0';
	}


/***********************************************************************
 *
 * FUNCTION: 	 DateAdjust
 *
 * DESCRIPTION: Return a new date +- the days adjustment.  This is useful
 * for advancing a day or week and not worrying about month and year wrapping.
 * If the time is advanced out of bounds it is is cut at the bounds surpassed.
 *
 * PARAMETERS:  struct tm, the adjustment in seconds
 *
 * RETURNED:	the adjust struct tm
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/21/95	Initial Revision
 *
 ***********************************************************************/
 
void DateAdjust (DatePtr dateP, Long adjustment)
{
	ULong days;
	
	days = DateToDays (*dateP);

	// we must be careful about large dates which appear negative if
	// signed.	
	if (adjustment < 0)
		{
		adjustment = -adjustment;
		if ((ULong) adjustment > days)
			days = 0;
		else
			days -= (ULong) adjustment;
		}
	else
		{
		days += adjustment;
		if (days > (ULong) maxDays)
			days = maxDays;
		}

	DateDaysToDate (days, dateP);
}

/***********************************************************************
 *
 * FUNCTION: 	 DateToDays
 *
 * DESCRIPTION: Return the date in days since 1/1/1904
 *
 * PARAMETERS:  date - DateType structure
 *
 * RETURNED:	the days since 1/1/1904
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/14/95	Initial Revision
 *
 ***********************************************************************/
 ULong DateToDays (DateType date)
{
	ULong days;
	UInt years;
	UInt i;
	
	days = ((ULong) date.year / 4) * daysInFourYears;
	
	// The first year of four years is a leap year (1904 is a leap year).
	// Add the days of the years between the year and the prior leap year
	// (not the last year because it's a partial year).  If years is equal
	// to zero then the year is a leap year.
	years = date.year % 4;
	if (years > 0)
		{
		days += daysInLeapYear;
		years--;
		days += years * daysInYear;
		}
	
	// Now add the days elapsed in the last year.
	years = date.year;
	for (i = date.month - 1; i > 0; i--)
		{
		days += DaysInMonth(i, years + firstYear);
		}
	
	days += date.day - 1;
	
	return days;
}

/***********************************************************************
 *
 * FUNCTION:	DateSecondsToDate
 *
 * DESCRIPTION: Return the date given seconds
 *
 * PARAMETERS:  seconds - seconds since 1/1/1904
 *              dateP - pointer to DateType structure (retuned) 
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/15/95	Initial Revision
 *
 ***********************************************************************/

void DateSecondsToDate (ULong seconds, DatePtr dateP)
{
	DateTimeType dateTime;

	TimSecondsToDateTime (seconds, &dateTime);
	dateP->year = dateTime.year - firstYear;
	dateP->month = dateTime.month;
	dateP->day = dateTime.day;
} 

/***********************************************************************
 *
 * FUNCTION:	DateDaysToDate
 *
 * DESCRIPTION: Return the date given days
 *
 * PARAMETERS:  days  -  days since 1/1/1904
 *              dateP - pointer to DateType structure
 *
 * RETURNED:	date
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/21/95	Initial Revision
 *
 ***********************************************************************/
 
void DateDaysToDate(ULong days, DatePtr dateP)
{
	UInt year;
	UInt fourYears;
	UInt dayInMonth;
	
	
	fourYears = days / daysInFourYears;
	days %= daysInFourYears;
	
	if (days >= daysInLeapYear)
		{
		days -= daysInLeapYear;
		year = firstYear + fourYears * 4 + 1 + days / daysInYear;
		days %= daysInYear;
		}
	else
		year = firstYear + fourYears * 4;
	dateP->year = year - firstYear;
	
	// We are down to one year
	dateP->month = 1;
	while ((dayInMonth = DaysInMonth(dateP->month, year)) <= days)
		{
		days -= dayInMonth;
		dateP->month++;
		}
		
	dateP->day = days + 1;
}

/***********************************************************************
 *
 * FUNCTION:		IToShortYear
 *
 * DESCRIPTION:	Convert the passed year to a two-digit year and
 *						print it in the passed string.
 *
 * PARAMETERS:		CharPtr				pString - string to fill with result
 *						Word					years - number to convert
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	10/4/95	Initial Revision
 *
 ***********************************************************************/
static void IToShortYear (CharPtr pString, Word years)
	{
	if (years < 10)
		{	//	Single digit years must be preceeded by '0'
		*pString = '0';
		pString++;
		}

	StrIToA (pString, years);
	}	//	end of IToShortYear

/***********************************************************************
 *
 * FUNCTION:		DateToAscii
 *
 * DESCRIPTION:	Convert the time passed to an ascii string in the
 *						passed DateFormatType.
 *
 *						NOTE: this routine handles the long AND short forms
 *						of the date formats.
 *
 * PARAMETERS:  months   - months (1-12)
 *					 days		 - days (1-31)
 *					 years	 - years (ex: 1995)  If year is < 10 then a zero 
 *									precedes the year's digit resulting in at least 
 *									two digits.  This ruins displaying years < 10 A.D.
 *					 dateFormat - long or short DateFormatType
 *					 pString  - pointer to string which gets the result. The
 *									string must be of length dateStringLength for
 *									standard formats or longDateStrLength for
 *									long date formats.
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/28/95	Initial Revision
 *			kcr	9/13/95	added dfDMYLongWithComma, dfYMDLongWithDot formats
 *			kcr	9/15/95	fixed two minor bugs in dfDMYLongWithComma & dfDMYLong
 *			kcr	9/22/95	dfDMYLongNoDay now uses full month names
 *			kcr	9/26/95	fixed 'long assignment to char str' problem
 *			kcr	10/3/95	added dfMYMed
 *			roger	11/13/96	Changed years to always print at least two digits
 *			scl	3/11/97	added dfMYMedNoPost for French 2.0 ROM
 *
 ***********************************************************************/

void DateToAscii(Byte months, Byte days, Word years,
					  DateFormatType dateFormat,
					  CharPtr pString)
{
	char		separator;
	CharPtr	monthFullNames;
	int		i;
	VoidHand	monthNamesH, monthFullNamesH;
	CharPtr	monthNames;
	
	
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	// Fill up the destination as much as allowed with a value to reveal errors.
	MemSet(pString, dateStringLength, 0xfe);	
#endif
	
	
	// determine the separator to use - for the short forms only.
	switch (dateFormat) 
		{
		case dfDMYWithDots:
		case dfYMDWithDots:
			separator = '.';
			break;
			
		case dfDMYWithDashes:
		case dfYMDWithDashes:
			separator = '-';
			break;
			
		default:
			separator = '/';
		
		}
	
	
	// Print the date in the correct month, day, and year order
	if (dateFormat == dfMDYWithSlashes)
		{
		StrIToA(pString, months);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString++ = separator;
		
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString++ = separator;
		
		// The year should be two digits.  Prepend a zero if not!
		StrIToA(pString, years % 100);
		if (pString[1] == '\0')		// single digit!
			{
			pString[1] = pString[0];
			pString[0] = '0';			// prepend a zero
			} 
		pString += 2;
		*pString = '\0';
		
		return;
		}
		
	//	Cover all of the DMY cases
	if (dateFormat == dfDMYWithDashes ||
		 dateFormat == dfDMYWithDots ||
		 dateFormat == dfDMYWithSlashes)
		{
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString++ = separator;
		
		StrIToA(pString, months);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString++ = separator;
		
		
		// The year should be two digits.  Prepend a zero if not!
		StrIToA(pString, years % 100);
		if (pString[1] == '\0')		// single digit!
			{
			pString[1] = pString[0];
			pString[0] = '0';			// prepend a zero
			} 
		pString += 2;
		*pString = '\0';
		
		return;
		}
		
	//	Cover all of the YMD cases
	if (dateFormat == dfYMDWithDashes ||
		 dateFormat == dfYMDWithDots ||
		 dateFormat == dfYMDWithSlashes)
		{
		// The year should be two digits.  Prepend a zero if not!
		StrIToA(pString, years % 100);
		if (pString[1] == '\0')		// single digit!
			{
			pString[1] = pString[0];
			pString[0] = '0';			// prepend a zero
			} 
		pString += 2;
		*pString++ = separator;
		
		StrIToA(pString, months);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString++ = separator;
		
		
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		*pString = '\0';

		return;
		}

	//	MEDIUM & LONG FORMATS:
	//	The month names are used for most formats, so we'll fetch
	//	them only once.
	monthNamesH = DmGetResource (strRsc, monthNamesStrID);
	ErrFatalDisplayIf( (! monthNamesH), "Rsrc not found");
	monthNames = MemHandleLock (monthNamesH);
	
	
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	// Fill up the destination as much as allowed with a value to reveal errors.
	MemSet(pString, longDateStrLength, 0xfe);	
#endif
	
	
	//	Format the date as: Dec '95
#if COUNTRY == COUNTRY_FRANCE
	if ((dateFormat == dfMYMed) || (dateFormat == dfMYMedNoPost))
#else
	if (dateFormat == dfMYMed)
#endif
		{
		*pString = monthNames [(months-1)*4];
		pString++;
		*pString = monthNames [(months-1)*4 + 1];
		pString++;
		*pString = monthNames [(months-1)*4 + 2];
		pString++;
		*pString = monthNames [(months-1)*4 + 3];
		pString++;

#if COUNTRY == COUNTRY_FRANCE						// French folks don't like "'" ('97)
		if (dateFormat != dfMYMedNoPost)
#endif
			{
			*pString = '\'';
			pString++;
			}

		IToShortYear (pString, years % 100);	//	Only last two digits are req'd
		}	//	end of if <dfMYMed>


	// Format the date as: Dec 31, 1995
	else if (dateFormat == dfMDYLongWithComma)
		{
		//	Copy 4 bytes (3 for month, 1 space).
		*pString = monthNames [(months-1)*4];
		pString++;
		*pString = monthNames [(months-1)*4 + 1];
		pString++;
		*pString = monthNames [(months-1)*4 + 2];
		pString++;
		*pString = monthNames [(months-1)*4 + 3];
		pString++;

		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		
		*pString = ',';
		pString++;
		*pString = ' ';
		pString++;
		
		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);		
		}


	// Format the date as: 31 Dec 1995
	else if (dateFormat == dfDMYLong)
		{
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;

		*pString = ' ';
		pString++;

		*pString = monthNames [(months-1)*4];
		pString++;
		*pString = monthNames [(months-1)*4 + 1];
		pString++;
		*pString = monthNames [(months-1)*4 + 2];
		pString++;
		*pString = monthNames [(months-1)*4 + 3];
		pString++;

		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);
		}


	// Format the date as: '31. Dec 1995' or '31 Dec, 1995'
	else if (dateFormat == dfDMYLongWithDot ||
				dateFormat == dfDMYLongWithComma)
		{
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else
			pString += 2;

		if (dateFormat == dfDMYLongWithDot)
			{
			*pString = '.';
			pString++;
			}
		*pString = ' ';
		pString++;

		*pString = monthNames [(months-1)*4];
		pString++;
		*pString = monthNames [(months-1)*4 + 1];
		pString++;
		*pString = monthNames [(months-1)*4 + 2];
		pString++;
		
		if (dateFormat == dfDMYLongWithComma)
			{
			*pString = ',';
			pString++;
			}

		*pString = ' ';
		pString++;
		
		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);		
		}

	// Format the date as: '1995.12.31'
	else if (dateFormat == dfYMDLongWithDot)
		{
		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);
		pString = StrChr(pString, '\0');

		*pString = '.';
		pString++;

		StrIToA(pString, months);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;

		*pString = '.';
		pString++;

		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else
			pString += 2;
		}

	// Format the date as: 1995 Dec 31
	else if (dateFormat == dfYMDLongWithSpace)
		{
		// Write the year
		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);
		pString = StrChr(pString, '\0');
		
		*pString = ' ';
		pString++;
		
		
		// Write the month's name.
		//	Copy 4 bytes (3 for month, 1 space).
		*pString = monthNames [(months-1)*4];
		pString++;
		*pString = monthNames [(months-1)*4 + 1];
		pString++;
		*pString = monthNames [(months-1)*4 + 2];
		pString++;
		*pString = monthNames [(months-1)*4 + 3];
		pString++;
		
		
		// Write the days
		StrIToA(pString, days);
		if (pString[1] == '\0')
			pString += 1;
		else 
			pString += 2;
		
		}


	// Format the date as: December 1995
	else if (dateFormat == dfDMYLongNoDay)
		{
		monthFullNamesH = DmGetResource (strRsc, monthFullNamesStrID);
		ErrFatalDisplayIf( (! monthFullNamesH), "Rsrc not found");
		monthFullNames = MemHandleLock (monthFullNamesH);

		//	Find appropriate month
		for (i = 0; i < months-1; i++)
			{
			monthFullNames = StrChr (monthFullNames, spaceChr);
			monthFullNames++;		//	Skip past the space char
			}
		//	copy month name to string
		while (*monthFullNames != spaceChr)
			{
			*pString = *monthFullNames;
			pString++;
			monthFullNames++;
			}
		*pString = spaceChr;
		pString++;

		MemHandleUnlock (monthFullNamesH);
		
		if (years < 10)
			{	//	Single digit years must be preceeded by '0'
			*pString = '0';
			pString++;
			}

		StrIToA(pString, years);		
		}

	MemHandleUnlock (monthNamesH);
	return;
}	//	end of DateToAscii



/***********************************************************************
 *
 * FUNCTION:    DateToDOWDMFormat
 *
 * DESCRIPTION:  Convert the date passed to an ascii string.
 *
 * PARAMETERS:  dayOfWeek  - day of week (0-6)
 *					 months     - months (1-12)
 *					 days		   - days (1-31)
 *					 dateFormat - false to use AM and PM
 *					 pString    - pointer to string which gets the result. The
 *									  string must be of length timeStringLength
 *
 * RETURNED:	 pointer to the text of the current selection
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	5/30/95	Initial Revision
 *
 ***********************************************************************/

void DateToDOWDMFormat(Byte month, Byte day, Word year,
	DateFormatType dateFormat, CharPtr pString)
	{
	Byte dayOfWeek;
	VoidHand dayOfWeekStringsH;
	char (*dayOfWeekArray) [daysInWeek][4];


	// Start with the day of the week.  Copies three letters for the day of the week
	// string plus a following space
	dayOfWeekStringsH = DmGetResource (strRsc, daysOfWeekStrID);
	
	dayOfWeek = DayOfWeek (month, day, year);

	// "Sun Mon Tue Wed Thu Fri Sat "
	dayOfWeekArray = MemHandleLock(dayOfWeekStringsH);
	MemMove(pString, (*dayOfWeekArray)[dayOfWeek], 4);
	MemHandleUnlock(dayOfWeekStringsH);

	pString += 4;
	
	DateToAscii (month, day, year, dateFormat, pString);
	}
	
