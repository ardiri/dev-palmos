/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		globals.c
 *
 * Description:
 *		Handles initialization and creation of Pilot globals under
 *	both the native and emulation modes
 *
 * History:
 *   	10/26/94	RM		- Created by Ron Marianetti
 *		7/3/95	VMK	- Added setup for Serial Link Manager globals to SysReset()
 *		10/ 7/96 SCL	- Added PrvRelocateData routine, modified SysAppStartup
 *		10/30/96 SCL	- Changed SysAppStartup to ONLY call PrvRelocateData
 *								if the DATA resource includes relocation data
 *		10/30/96 SCL	- SysAppStartup: CODE #0 and DATA #0 are now optional.
 *
 *******************************************************************/


#include <Pilot.h>

#include <SysEvtMgr.h>
#include <Keyboard.h>
#include <Launcher.h>
#include <PenMgr.h>
#include <FeatureMgr.h>
#include <Graffiti.h>
#include <ScrDriver.h>
#include <ConsoleMgr.h>
#include <SerialMgr.h>
#include <AlarmMgr.h>
#include <KeyMgr.h>
#include <NetMgr.h>
#include <INetMgr.h>
#include <FatalAlert.h>
#include <event.h>
#include <ExgMgr.h>
#include <ExgLib.h>

#define	NON_PORTABLE
#include <SystemPrv.h>
#include <DataPrv.h>
#include <SysEvtPrv.h>
#include <KeyPrv.h>
#include <SysConfigPrv.h>

#if EMULATION_LEVEL == EMULATION_NONE
	// Make sure this compiler constant was defined in the Makefile
	#ifndef CONSOLE_SERIAL_LIB
		#error	"The Compiler define CONSOLE_SERIAL_LIB MUST BE DEFINED ON THE COMMAND LINE!!"
	#endif
#endif 	//EMULATION_LEVEL != EMULATION_NONE


// Defines
#define uiAppStackSize		0xA00

// Private routines and types
typedef void 	ResetHandler(void);

static char * 	PrvDecompressData(char *ptr,char *datasegment);

static char *	PrvRelocateData(char *ptr,char *segment,long relocbase);

static Int		PrvCallSafely(ProcPtr procP);

static Int	 	PrvCallWithNewStack(ProcPtr procP, Ptr newStack);

static void		TaskTerminationProc(ULong taskID, Long reason);

static void		InitSystemGlobals(void);

// When we launch an app with no globals world, we set the high bit of A5
//  so that can get a bus error if the called app inadvertently accesses globals.
//  (it shouldn't).
#define PrvProtectSegmentRegister(r)	((Ptr) ((DWord) (r) | 0x80000000))
#define PrvUnprotectSegmentRegister(r)	((Ptr) ((DWord) (r) & ~0x80000000))


/************************************************************
 *
 *  FUNCTION: SysUnimplemented
 *
 *  DESCRIPTION: The entire trap table is initialized with this routine
 *		before installing the real handlers in case we forget to install any traps
 *
 *  PARAMETERS: void
 *
 *  RETURNS: void
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void SysUnimplemented(void)
{
	ErrDisplay("Unimplemented");
}



/************************************************************
 *
 *  FUNCTION: SysColdBoot
 *
 *  DESCRIPTION: Does a cold, card boot. Re-formats all RAM areas
 *   of memory cards.
 *
 *  PARAMETERS: none
 *
 *  RETURNS:
 *
 *  CREATED: 10/31/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void SysColdBoot(Ptr card0P, ULong card0Size, 
							Ptr card1P, ULong card1Size, 
							DWord sysCardHeaderOffset)
{

#if EMULATION_LEVEL != EMULATION_NONE
	SysPowerOn(card0P, card0Size, card1P, card1Size, sysCardHeaderOffset, true);

#else
	ResetHandler*		resetP;
	CardHeaderPtr		cardP;
	Word*					wP;
	Word					offset;
	CardInfoPtr			infoP;
	
	// Fetch the address of the reset vector out of the card header
	infoP = memCardInfoP(0);
	cardP = (CardHeaderPtr)(infoP->baseP + infoP->cardHeaderOffset);
	
	// The hard reset entry point is 2 past the normal one
	wP = (Word*)cardP->resetVector;
	
	// On the Pre328 board, the reset vector points to the area near 0
	//  where ROM appears right after reset, so we need to add the 
	//  current location of the ROM to that.
	if (((DWord)wP & 0xFFFF0000) == 0) 
		wP = (Word*)((DWord)wP + infoP->cardHeaderOffset);
	

	// Our PilotRez tool substitues a JMP *+offset instruction for
	// the first instruction of the startup code in 
	// the reset code resource boot #10000. So, we must calculate
	// the start of the reset code from this instruction.
	offset = wP[1] + 2;
	resetP = (ResetHandler*)((DWord)wP + (DWord)offset + 2);
	

	// Call it...
	(*resetP)();
#endif
}






/************************************************************
 *  FUNCTION: 		SysInit 
 *
 *  DESCRIPTION: 	Initializes the System Manager
 *
 *  PARAMETERS:  	void
 *
 *  RETURNS: void
 *
 *  CALLED BY: 
 *		Native Mode: SysLaunch() in ROMSysLaunch.c after initializing the
 *   	 Memory Manager.
 *
 *		Emulated Mode: SysReset() after initializing the Memory Manager
 *
 *  CREATED: 4/28/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void EmThreadsInit(void);
void SysInit(void)
{
	
	// The pointer to the array of hard key to application creator types is
	// no longer used. The system preferences now store the creator types for
	//  which app to launch when a key is pressed.
	//GSysHardKeyCreators = HardKeyCreators();
	
	// Set the threshold for battery warning.
	GSysBatteryWarnThreshold = hwrStepsPerVolt*2 - hwrVoltStepsOffset;

	// This threshold is checked periodically by our timer procedure and
	//  causes the system to go immediately into sleep mode. 
	// Because we also have an interrupt generated by the hardware when
	//  the voltage falls below 1.6 volts that also causes us to shutdown,
	//  we probably will never hit this threshold.
	GSysBatteryMinThreshold = hwrStepsPerVolt*8/10 - hwrVoltStepsOffset;

	GSysNextBatteryAlertTimer = sysTicksPerSecond*60;


	// Init the battery level
	#if EMULATION_LEVEL == EMULATION_NONE
	GHwrBatteryLevel = HwrBatteryLevel();
	
	// Under emulation, the battery is always full and... we must
	//  initialize our multi-tasking emulator
	#else
	EmThreadsInit();
	GHwrBatteryLevel = 255;
	#endif
}





/************************************************************
 *
 *  FUNCTION: SysReset
 *
 *  DESCRIPTION: Re-initializes Pilot globals and dynamic
 *		memory heap. 
 *
 *		Under Windows emulation mode, this routine
 *		looks for two data files that represent the memory of card
 *		1 and card 2. If these are found, the Pilot's memory
 *		image is created using them. If they are not found, they
 *		will be created.
 *
 *		Under Native mode, this routine simply looks for the memory
 *		cards at fixed locations.
 *
 *  PARAMETERS: 
 *
 *  RETURNS: void
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	7/3/95	Added setup for Serial Link Manager globals
 *
 *************************************************************/
void SysReset(void)
{
#if EMULATION_LEVEL != EMULATION_NONE
	LowMemType*		lowMemP;
	WordPtr			wP;
	UInt				i;
	CardInfoType	cardInfo[hwrNumCardSlots];
	Word				memCardSlots;
	
	
	// Save the memory card info
	memCardSlots = GMemCardSlots;
	for (i=0; i<hwrNumCardSlots; i++)
		cardInfo[i] = *(memCardInfoP(i));


	// Clear all the low memory globals
	lowMemP = (LowMemType*)PilotGlobalsP;
	wP = (WordPtr)(&lowMemP->fixed.globals);
	for (i=0; i< sizeof(FixedGlobalsType)/2; i++)
		*wP++ = 0;


	// Restore the memory card info
	GMemCardSlots = memCardSlots;
	GMemCardInfoP = (Ptr)&GMemCardInfo[0];
	for (i=0; i<hwrNumCardSlots; i++)
		((CardInfoPtr)GMemCardInfoP)[i] = cardInfo[i];

	// Init System AppInfo
	GSysAppInfoP = (Ptr)&GSysAppInfo;
	GCurUIAppInfoP = (Ptr)&GSysAppInfo;
	
	// Set up Serial Link Globals pointer
	GSlkGlobalsP = (Ptr)&GSlkGlobals;

	// Init the Hardware Manager
	HwrInit();

	// Init the Memory Manager. This initializes the Pilot globals
	//  and creates the global heap info table for each card.
	MemInit();
	
	// Init the Data Manager
	DmInit();
	
	// Init System Manager
	SysInit();
	
	
#else 
	ResetHandler*		resetP;
	CardHeaderPtr		cardP;
	CardInfoPtr			cardInfoP;
	
	// Fetch the address of the reset vector out of the card header
	cardInfoP = memCardInfoP(0);
	cardP = (CardHeaderPtr)(cardInfoP->baseP + cardInfoP->cardHeaderOffset);
	
	// The soft reset entry point is the same one used for reset exceptions
	resetP = (ResetHandler*)(cardP->resetVector);
	
	// On the Pre328 board, the reset vector points to the area near 0
	//  where ROM appears right after reset, so we need to add the 
	//  current location of the ROM to that.
	if (((DWord)resetP & 0xFFFF0000) == 0) 
		resetP = (ResetHandler*)((DWord)resetP + cardInfoP->cardHeaderOffset);
	
	// Call it...
	(*resetP)();
#endif
}


/************************************************************
 *
 *  FUNCTION: SysPowerOn
 *
 *  DESCRIPTION: Powers up Pilot in the state it was left
 *		in from last power down. 
 *
 *		Under Emulation mode, this routine operates the same as
 *		SysReset because we can't restore the dynamic heap and globals
 *		since they contain pointers and our globals end up at a different
 *		location in memory every time we launch the emulation application.
 *
 *		In Native mode, this routine uses the dynamic heap and globals
 *		from the last Power-Down.
 *
 *  PARAMETERS: 
 *
 *  RETURNS:
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void 	SysPowerOn(Ptr card0P, ULong card0Size, 
							Ptr card1P, ULong card1Size,
							DWord sysCardHeaderOffset,
							Boolean reFormat)
{

#if EMULATION_LEVEL != EMULATION_NONE
	CardInfoPtr				infoP;
	StorageHeaderPtr		storeP;
	Err						err;
	UInt						i;
	BytePtr					p;
	Boolean					reFormat0, reFormat1;
	LowMemType*				lowMemP;
	ULong						size;
	
	
	// Init reFormat flags
	reFormat0 = reFormat1 = reFormat;
	
	// Setup pointer to Pilot globals
	PilotGlobalsP = card0P;
	
	
	// Init the globals to 0
	lowMemP = (LowMemType*)PilotGlobalsP;
	p = (BytePtr)&(lowMemP->fixed.globals);
	size = sizeof(LowMemType) - ((DWord)p - (DWord)lowMemP);
	for (i=0; i<size; i++)
		*p++ = 0;
	

	// Set up pointer to cardInfo array
	GMemCardInfoP = (Ptr)(&GMemCardInfo[0]);
	GMemCardSlots = hwrNumCardSlots;
	

	//-------------------------------------------------------------------------
	// Save card 0 info into emulation globals
	//-------------------------------------------------------------------------
	infoP = memCardInfoP(0);
	infoP->baseP = (BytePtr)card0P;
	infoP->size = card0Size;
	
	if (sysCardHeaderOffset < card0Size) {
		infoP->firstRAMBlockSize = sysCardHeaderOffset;
		infoP->cardHeaderOffset = sysCardHeaderOffset;
		}
	else {
		infoP->firstRAMBlockSize = card0Size;
		infoP->cardHeaderOffset = sysRAMOnlyCardHeaderOffset;
		}
		
	
	// Search for the RAM store on this card
	err = MemStoreSearch(infoP->baseP, infoP->firstRAMBlockSize, &storeP);
	if (!err) {
		infoP->rsvSpace = storeP->rsvSpace;
		infoP->dynHeapSpace = storeP->dynHeapSpace;
		infoP->ramStoreP = storeP;
		}
		
	// If the RAM store header was not found, fill in default sizes of the
	//  dynamic heap and low memory area and force a re-format.
	else {
		reFormat0 = true;
		infoP->rsvSpace = sysLowMemSize;
		infoP->dynHeapSpace = memCalcDynamicHeapSize(infoP->firstRAMBlockSize);
		infoP->ramStoreP = (StorageHeaderPtr)(infoP->baseP + infoP->rsvSpace 			
												+ infoP->dynHeapSpace);
		}


	//-------------------------------------------------------------------------
	// Save card 1 info into emulation globals
	//-------------------------------------------------------------------------
	if (GMemCardSlots > 1) {
		infoP = memCardInfoP(1);
		infoP->baseP = (BytePtr)card1P;
		infoP->size = card1Size;
		
		if (sysCardHeaderOffset < card1Size) {
			infoP->firstRAMBlockSize = sysCardHeaderOffset;
			infoP->cardHeaderOffset = sysCardHeaderOffset;
			}
		else {
			infoP->firstRAMBlockSize = card1Size;
			infoP->cardHeaderOffset = sysRAMOnlyCardHeaderOffset;
			}
		
		// Search for the RAM store on this card
		err = MemStoreSearch(infoP->baseP, infoP->firstRAMBlockSize, &storeP);
		if (!err) {
			infoP->rsvSpace = storeP->rsvSpace;
			infoP->dynHeapSpace = storeP->dynHeapSpace;
			infoP->ramStoreP = storeP;
			}
			
		// If the RAM store header was not found, fill in default sizes of the
		//  dynamic heap and low memory area and force a re-format.
		else {
			reFormat1 = true;
			infoP->rsvSpace = sysCardHeaderSize;
			infoP->dynHeapSpace = 0;
			infoP->ramStoreP = (StorageHeaderPtr)(infoP->baseP + infoP->rsvSpace 
												+ infoP->dynHeapSpace);
			}
	
		}


	// Format the cards if desired
	if (reFormat0) {
		MemCardFormat(0, "Card 0", "Palm Computing", "RAM Store 0");
		if (GMemCardSlots > 1 && reFormat1) 
			MemCardFormat(1, "Card 1", "Palm Computing", "RAM Store 1");
		}

	// Reset the system
	SysReset();
	
#endif

}






/************************************************************
 *
 *  FUNCTION: SysUILaunch
 *
 *  DESCRIPTION: Called during startup sequence in order to
 *   install and initialize the UI Managers. This routine
 *	 is called from the AMX restart procedure called "PilotRestart"
 *	 after AMX has been installed.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: void
 *
 *  CREATED: 3/13/95
 *
 *  BY: Ron Marianetti
 *
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	9/3/96	Install net lib in emulation mode
 *			scl	3/11/97	Do FtrInit before PrefGetPreference in emulation mode
 *			gmp 8/19/26 Add ExgInit and Serial library load for emulation
 *			roger	12/12/97	Change to use SysCurAppInfo
 *
 *************************************************************/
typedef void (*InstallProcPtr)(Ptr dispatchTableP);
Err SerPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);
Err NetPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);
Err RMPLibPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);
Err INetLibPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);
void 	SysUILaunch()
{
#if EMULATION_LEVEL != EMULATION_NONE
	SysAppInfoPtr			appInfoP;
	SysLibEntryProcPtr		libP=0;
	Word							refNum;

	
	// Init the Feature Manager
	FtrInit();
	
	// Init the GSysPrefFlags and GSysBatteryKind globals
	//  from the preferences.
	GSysPrefFlags = PrefGetPreference(prefSysPrefFlags);
	GSysBatteryKind = PrefGetPreference(prefSysBatteryKind);

	// Initialize the screen driver
	ScrInit();
	
	// Intialize the low level event manager
	EvtSysInit();
	
	// Initialize Graffiti
	GrfInit();

	// Initialize the UI
	UIInitialize ();

	// <RM> 1-16-98,  Mark it as initialized so that ErrDisplay() knows it's
	//  safe to display error alerts
	GSysMiscFlags |= sysMiscFlagUIInitialized;
	
	// Initialize Sound Manager
	SndInit();
	
	// Initialize Time Manager
	TimInit();
	
	// Initialize Alarm Manager (MUST BE AFTER TIME MANAGER INITIALIZATION)
	AlmInit();
	
	// Intialize the key manager
	KeyInit();


	// Setup run-time features. 
	if (GHwrMiscFlags & hwrMiscFlagHasBacklight) 
		FtrSet(sysFtrCreator, sysFtrNumBacklight, 0x01);
		
	// Setup run-time features. 
	if (INCLUDE_DES == INCLUDE_DES_ON) 
		FtrSet(sysFtrCreator, sysFtrNumEncryption, 0x01);
	else
		FtrSet(sysFtrCreator, sysFtrNumEncryption, 0x00);
		
	
	//-------------------------------------------------------------------------
	// Install the Serial Library. 
	//-------------------------------------------------------------------------
	libP = SerPrvInstallDispatcher;
	SysLibInstall(libP, &refNum);
	

	// Initialize the Exg manager (Must be after serial library is installed)
	ExgInit();  

	//-------------------------------------------------------------------------
	// Install the Net Library. The NetPrvInstallDispatcher() routine
	//  is smart enough not to install on the "Personal" version of the ROM. 
	//-------------------------------------------------------------------------
	libP = NetPrvInstallDispatcher;
	SysLibInstall(libP, &refNum);
	
	// Install the Reliable Message Protocol plug-in for the Net Library.
	// The RMPLibPrvInstallDispatcher is smart enough not to install unless
	//  the NetLib is installed.
	libP = RMPLibPrvInstallDispatcher;
	SysLibInstall(libP, &refNum);

	// Install the Internet Library. 
	// The InetLibPrvInstallDispatcher is smart enough not to install unless
	//  the NetLib is installed.
	libP = INetLibPrvInstallDispatcher;
	SysLibInstall(libP, &refNum);
	
	
	// Allocate a fake chunk to simulate the memory used by the AMX kernel
	// Also add to this miscellaneous data used on the real hardware
	GSysKernelDataP = MemPtrNew(0xDF8 + 0x2E8);
	
	// Allocate a fake chunk to simulate the UIShell app info block and stack
	GSysUIShellAppInfoP = MemPtrNew(sizeof(SysAppInfoType));
	appInfoP = (SysAppInfoPtr)GSysUIShellAppInfoP;
	MemSet(appInfoP, sizeof(SysAppInfoType), 0);
	appInfoP->stackP = MemPtrNew(uiAppStackSize);
	appInfoP->stackEndP = appInfoP->stackP + uiAppStackSize;
	appInfoP->globalsChunkP = MemPtrNew(0x38);

	// Create an appInfo structure for the "one" app.
	GCurUIAppInfoP = MemPtrNew(sizeof(SysAppInfoType));
	MemSet(GCurUIAppInfoP, sizeof(SysAppInfoType), 0);
	((SysAppInfoPtr)GCurUIAppInfoP)->memOwnerID = SysNewOwnerID();

	// Put in pre-opened system databases into the DmAccess List
	((SysAppInfoPtr)GCurUIAppInfoP)->dmAccessP = (Ptr)((SysAppInfoPtr)GSysAppInfoP)->dmAccessP;
	
	// Disable Graffiti if this is a DEMO ROM
	#if USER_MODE == USER_MODE_DEMO
	GSysMiscFlags |= sysMiscFlagGrfDisable;
	#endif
	


#else 
	
	Handle						codeH;
	InstallProcPtr				codeP;
	UInt							cardNo;
	LocalID						dbID;
	Err							err;
	DWord							result;
	UInt							rid;
	DmSearchStateType			searchState;
	DmOpenRef					dbR;
	Handle						h;
	SysLibEntryProcPtr		libP=0;
	Word							refNum;
	
	//-------------------------------------------------------------------------
	// Get the UI code resources and install them
	//-------------------------------------------------------------------------
	for (rid = sysResIDBootUICodeStart; 1; rid++) {
		codeH = DmGetResource(sysResTBootCode, rid);
		if (!codeH)  break;
		
		codeP = (InstallProcPtr)MemHandleLock(codeH);
		(*codeP)((Ptr)GSysDispatchTableP);
		}
	
	// Make sure we got the minimum set
	if (rid <= sysResIDBootUICodeMin) DbgBreak();
	
	

	//-------------------------------------------------------------------------
	// Init the Higher level managers
	//-------------------------------------------------------------------------
	// Init the GSysPrefFlags from the preferences
	GSysPrefFlags = PrefGetPreference(prefSysPrefFlags);


	// Initialize the screen driver
	ScrInit();
	
	// Initialize the System Event Manager
	EvtSysInit();
	
	// Initialize Graffiti
	GrfInit();

	//Initialize the Keyboard Manager
	KeyInit();						 
	
	// Initialize Sound Manager
	SndInit();
	
	
	// Setup run-time features. 
	if (GHwrMiscFlags & hwrMiscFlagHasBacklight) 
		FtrSet(sysFtrCreator, sysFtrNumBacklight, 0x01);
		
	// Setup run-time features. 
	if (INCLUDE_DES == INCLUDE_DES_ON) 
		FtrSet(sysFtrCreator, sysFtrNumEncryption, 0x01);
	else
		FtrSet(sysFtrCreator, sysFtrNumEncryption, 0x00);
		
	// Initialize the Exg manager
	if (! (GSysResetFlags & sysResetFlagNoExtensions)) 
		ExgInit();  
	
	//-------------------------------------------------------------------------
	// Install the Net Library, if found and extensions are not disabled.
	// DOLATER... use the SysLibLoad() call instead....
	//-------------------------------------------------------------------------
	if (! (GSysResetFlags & sysResetFlagNoExtensions)) {
		DmGetNextDatabaseByTypeCreator(true, &searchState, netLibType, 
				netCreator, true, &cardNo, &dbID);
		if (dbID) {

			// Open up this resource file
			dbR = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
			ErrNonFatalDisplayIf(!dbR, "Can't open Net library");
			if (dbR) {
				
				// Get the library resource
				h = DmGet1Resource(sysResTLibrary, 0);
				ErrNonFatalDisplayIf(!h, "Can't get libr resource");
				if (h) {

					// Install the library
					libP = (SysLibEntryProcPtr)MemHandleLock(h);
					refNum = 0;
					err = SysLibInstall(libP, &refNum);
					
					// Close this database, but protect it so it doesn't get deleted
					DmCloseDatabase(dbR);
					DmDatabaseProtect(cardNo, dbID, true);
					}
				}
			}
		}


	//-------------------------------------------------------------------------
	// Install the Internet Library, if found and extensions are not disabled.
	//-------------------------------------------------------------------------
	if (! (GSysResetFlags & sysResetFlagNoExtensions)) {
		SysLibLoad(inetLibType, inetCreator, &refNum);
		}



	//-------------------------------------------------------------------------
	// Install the Reliable Message Protocol plug-in for the Net Library if it
	//  is present in the system file. When we build versions of the ROM without
	//  the Reliable Message Protocol Library, it's resource is not included
	//  in the system resource file.
	//-------------------------------------------------------------------------
	if (! (GSysResetFlags & sysResetFlagNoExtensions)) {

		h = DmGetResource(sysResTLibrary, sysResIDLibraryRMPPlugIn);
		if (h) {

			// Install the library
			libP = (SysLibEntryProcPtr)MemHandleLock(h);
			refNum = 0;
			err = SysLibInstall(libP, &refNum);
			}
		}


	// Initialize the UI
	UIInitialize ();
	
	// <RM> 1-16-98,  Mark it as initialized so that ErrDisplay() knows it's
	//  safe to display error alerts
	GSysMiscFlags |= sysMiscFlagUIInitialized;
	
	// Disable Graffiti if this is a DEMO ROM
	#if USER_MODE == USER_MODE_DEMO
	GSysMiscFlags |= sysMiscFlagGrfDisable;
	#endif
	
	

	//-------------------------------------------------------------------------
	// Launch The UI Application Shell. This "application" gets launched as
	//  a separate task and acts as the shell for the current UI app. UI apps
	//  are in turn launched one at a time as subroutines from the UIAppShell.
	//-------------------------------------------------------------------------
	DmGetNextDatabaseByTypeCreator(true, &searchState, sysFileTUIAppShell, sysFileCSystem, true,
			&cardNo, &dbID);
	ErrFatalDisplayIf(!dbID, "Could not find UIAppShell");
	if (dbID) {
		err = SysAppLaunch(cardNo, dbID, 

					sysAppLaunchFlagNewStack | 
					sysAppLaunchFlagNewGlobals,
					0, 0, &result);
		ErrFatalDisplayIf(err, "Could not launch UIAppShell");
		}
#endif
}





/************************************************************
 *
 *  FUNCTION: SysDoze
 *
 *  DESCRIPTION:  Puts the processor to sleep but keeps system clock
 *		running and all peripherals awake
 *
 *  PARAMETERS:   
 *		onlyNMI  - if set, only an NMI can wake up the CPU
 *
 *  RETURNS: void
 *
 *  CREATED: 5/25/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void SysDoze(Boolean onlyNMI)
{
	HwrDoze(onlyNMI);
}


/************************************************************
 *
 *  FUNCTION: SysSleep
 *
 *  DESCRIPTION:  Puts the system into lowest power mode by
 *			shutting down all peripherals, CPU, and system clock
 *
 *  PARAMETERS: 
 *			untilReset - if true, system won't come out of sleep unless system
 *								is reset.
 *		emergency - if true, system will shut down faster than normal. Mainly,
 *							any key debouncing is bypassed.
 *
 *  RETURNS: void
 *
 *  CREATED: 5/25/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void SysSleep(Boolean untilReset, Boolean emergency)
{
	HwrSleep(untilReset, emergency);
}


/************************************************************
 *
 *  FUNCTION: SysGetROMToken
 *
 *  DESCRIPTION:	This routine is used to locate a "ROM token" from
 *						the list burned into ROM by the manufacturer of the
 *						device.
 *
 *  PARAMETERS:	cardNo	memory card number
 *						token		4-byte ROM token to search for
 *						dataP		pointer to a container which will receive the
 *									address of the token's data, or NULL if this
 *									info is not needed
 *						sizeP		pointer to a container which will receive the
 *									size (in bytes) of the token's data, or NULL
 *									if this info is not needed
 *
 *  RETURNS:		NULL if successful, "cheesy" error code otherwise
 *						*dataP	address of token's data
 *						*sizeP	size (in bytes) of the token's data
 *
 *  CREATED:		2/5/98
 *
 *  BY:				Steve Lemke
 *
 *************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE
// This "wrapper" routine calls HwrGetROMToken (in HardwareMgrEmu.c),
// but ONLY in Simulator builds. In a device build, the function
// prototype for SysGetROMToken (in <SystemMgr.h>) refers directly
// to the HwrGetROMToken trap word...
Err SysGetROMToken (Word cardNo, DWord token,	BytePtr * dataP,
						WordPtr sizeP)
{
	return( HwrGetROMToken (cardNo, token, dataP, sizeP) );
}
#endif


/************************************************************
 *
 *  FUNCTION: SysSetPerformance
 *
 *  DESCRIPTION:  Sets various performance options for the
 *   system.
 *
 *  PARAMETERS: 
 *			*sysClockP - On Entrance: desired system clock frequency.
 *											 or 0 to not change it.
 *							 On Exit: actual system clock.
 *			*cpuDutyP  - On Entrance: desired CPU duty cycle, 
 *												or 0 to not change it.
 *							 On Exit, current duty cycle value.
 *
 *      NOTE: the sysClockP and cpuDutyP pointers must NEVER BE NIL!
 *					in order to just retrive the current value of either
 *					one, pass a pointer to a 0 value, not a nil pointer.						
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 5/25/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err SysSetPerformance(ULongPtr sysClockP, UIntPtr cpuDutyP)
{

#if EMULATION_LEVEL == EMULATION_NONE
	Word				status;
	Boolean			clockChange = false;
	UInt				openSerial = 0;
	UInt				serRefNum;
	SerSettingsType		serSettings;
	Err				err;
	
	// First disable interrupts
	status = SysDisableInts();
	
	// Set boolean if we're changing the system clock and shut down
	//  peripherals that might be affected by it
	if (*sysClockP) {
		clockChange = true;
		
		// See if the serial library is installed, if and so, if it's open
		err = SysLibFind("Serial Library", &serRefNum);
		if (!err) {
			err = SerGetSettings(serRefNum, &serSettings);
			if (!err) {
				do {
					err = SerClose(serRefNum);
					openSerial++;
					} while (err == serErrStillOpen);
				}
			}
								
		// We never shut down timer 1 because it's needed for refreshes.	
		//HwrTimerShutdown(1);
		HwrTimerSleep(2);
		HwrLCDSleep(false, false);
		}
	
	// Set the system clock
	HwrSetSystemClock(sysClockP);
	
	
	// If the system clock changed, we must re-init the peripherals
	if (clockChange) {
	
		// Re-init the timers
		HwrTimerInit(1);
		HwrTimerInit(2);

		// Re-init the LCD
		HwrLCDInit(hwrDisplayPeriod, 0, 0, 0, 0);   
		}
		
	// Set the CPU duty cycle
	HwrSetCPUDutyCycle(cpuDutyP);
		

	// Restore interrupts
	SysRestoreStatus(status);
	
	
	// Re-open the serial port if it was open before. Make sure interrupts
	//  are disabled because SerOpen uses TimGetTicks().
	if (clockChange) 
		while(openSerial--) {
			SerOpen(serRefNum,  sysDefaultSerPort, serSettings.baudRate);
			SerSetSettings(serRefNum, &serSettings);
			}
		
#endif

	return 0;
}



/************************************************************
 *
 *  FUNCTION: SysSetAutoOffTime
 *
 *  DESCRIPTION: This routine sets the timeout value in seconds for
 *					auto power-off. 0 Means never power off.
 *
 *  PARAMETERS: 
 *		seconds	- timeout in seconds, or 0 for no timeout
 *
 *  RETURNS: previous value of timeout in seconds.
 *
 *  CREATED: 8/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt 		SysSetAutoOffTime(UInt	seconds)
{	
	UInt						oldValue;
	
	// Get the old value
	oldValue = GSysAutoOffSeconds;
	
	// Save new value low memory global
	GSysAutoOffSeconds = seconds; 
		
		
	// If we're Debugging, don't enable auto-off
	#if DEBUG_LEVEL == DEBUG_LEVEL_FULL
	GSysAutoOffSeconds = 0;
	#endif

	return oldValue;
}


/************************************************************
 *
 *  FUNCTION: SysTicksPerSecond
 *
 *  DESCRIPTION: This routine returns the number of ticks per
 *		second. It is provided so that apps can be tolerant of
 *		changes to the ticks per second rate in the system. 
 *
 *  PARAMETERS: 
 *		void
 *
 *  RETURNS: # of ticks per second.
 *
 *  CREATED: 7/3/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Word 		SysTicksPerSecond(void)
{	
	return sysTicksPerSecond;
}


/***********************************************************************
 *
 * FUNCTION:    PrvGetBatteryPercent
 *
 * DESCRIPTION: Get the battery level as a percent.
 *
 * PARAMETERS:	batteryLevel - the battery level from SysBatteryInfo
 * 				kind - the battery kind (SysBatteryKind)
 *
 * RETURNED:    the percent
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	7/19/95			Initial Revision
 *			rsf	11/13/97		Made into a system call from launcher.c
 *
 ***********************************************************************/
static Byte PrvGetBatteryPercent (UInt batteryLevel, SysBatteryKind kind)
{
	UInt batteryPercent;
	UInt low, hi;
	
	
	//----------------------------------------------------------------------------
	// Figure out the percent battery life left given the battery kind and voltage
	// ALKALINE:
	//----------------------------------------------------------------------------
	if (kind == sysBatteryKindNiCad) {
		UInt	range;
		
		// Clip to max
		if (batteryLevel > 260) batteryLevel = 260;
		
		// Find nearest bucket
		if 		(batteryLevel > 250) 
			{ batteryPercent = 90; range = 10; low = 250; hi = 260; }

		else if 	(batteryLevel > 240) 
			{ batteryPercent = 60; range = 30; low = 240; hi = 250; }

		else if 	(batteryLevel > 235) 
			{ batteryPercent = 20; range = 40; low = 235; hi = 240; }

		else if 	(batteryLevel > 230) 
			{ batteryPercent = 10; range = 10; low = 230; hi = 235; }

		else if 	(batteryLevel > 225) 
			{ batteryPercent = 5;  range = 5;  low = 225; hi = 230; }

		else {
			if (batteryLevel < 200) batteryLevel = 200;
			batteryPercent = 00;   range = 5;  low = 200; hi = 225;
			}

		// Figure out the percentage by linear interpolation between
		//  the low and hi points for the current 
		batteryPercent += (range * (batteryLevel - low) + (hi-low)/2) / (hi-low);
		}
		
		
	//----------------------------------------------------------------------------
	// Figure out the percent battery life left given the battery kind and voltage
	// NICAD:
	//----------------------------------------------------------------------------
	else if (kind == sysBatteryKindAlkaline) {
		// Clip to max
		if (batteryLevel > 300) batteryLevel = 300;
		
		// Find nearest 10%
		if 		(batteryLevel > 275) 
			{ batteryPercent = 90; low = 275; hi = 300; }

		else if 	(batteryLevel > 262) 
			{ batteryPercent = 80; low = 262; hi = 275; }

		else if 	(batteryLevel > 254) 
			{ batteryPercent = 70; low = 254; hi = 262; }

		else if 	(batteryLevel > 248) 
			{ batteryPercent = 60; low = 248; hi = 254; }

		else if 	(batteryLevel > 243) 
			{ batteryPercent = 50; low = 243; hi = 248; }

		else if 	(batteryLevel > 238) 
			{ batteryPercent = 40; low = 238; hi = 243; }

		else if 	(batteryLevel > 233) 
			{ batteryPercent = 30; low = 233; hi = 238; }

		else if 	(batteryLevel > 225) 
			{ batteryPercent = 20; low = 225; hi = 233; }

		else if 	(batteryLevel > 210) 
			{ batteryPercent = 10; low = 210; hi = 225; }

		else 
			{
			if (batteryLevel < 160) batteryLevel = 160;
			batteryPercent = 00; low = 160; hi = 210;
			}
		
		// Figure out the percentage by linear interpolation between
		//  the low and hi points for the current 
		batteryPercent += (10*(batteryLevel - low) + (hi-low)/2) / (hi-low);
		}
		
	// If we don't have a lookup table for this kind of battery, just use
	//  the straight voltage and take 160 as the min and 300 as the max
	else {
		batteryLevel -= 160;
		if (batteryLevel > 140) batteryLevel = 140;
		if (batteryLevel < 0) batteryLevel = 0;
		batteryPercent = (batteryLevel * 100 + 140/2) / 140;
		}
	
	
	// <RM 9/11/96> Because the power supply voltage is not regulated very well, we perform
	//  a slight hack here to make sure new batteries show full scale. We do this
	//  by indicating full batterys if they are 90% or more
	if (batteryPercent >= 90) batteryPercent = 100;
	
	
	return batteryPercent;
}


/************************************************************
 *
 *  FUNCTION: SysBatteryInfo
 *
 *  DESCRIPTION: This routine can be used to retrieve or change settings for
 *		the Batteries. If the parameter 'set' is true, any one or more of the battery
 *		settings can be changed. If 'set' is false, any one or more of the battery
 *		settings can be retrieved.
 *
 *		'warnThresholdP' and 'maxTicksP' are the battery warning voltage threshold and
 *		timeout. If the battery voltage falls below the threshold or, if the timeout
 *		expires, a lowBatteryChr key event will be enqueued. Normally, apps call
 *		SysHandleEvent which will put call SysBatteryWarningDialog in response to
 *		this event. 
 *
 *		'criticalThresholdP' is the critical battery voltage threshold. If the battery
 *		voltage falls below this level, the System will turn off without warning and will
 *		not turn on.
 *
 *		The battery voltage is equal to:
 *				
 *				voltage = (level + hwrVoltStepsOffset) 
 *							  --------------------------
 *							      hwrStepsPerVolt
 *
 *  PARAMETERS: 
 *		set 				-  if true, parameters with non-nil pointers will be changed except
 *									for pluggedIn, which can only be queried.
 *			   				   if false, parameters will non-nil pointers will be retrieved
 *		warnThresholdP 		-  Pointer to battery voltage warning threshold in volts*100, or nil.
 *		criticalThresholdP 	-  Pointer to battery voltage critical threshold in volts*100, or nil.
 *		maxTicksP			-  Pointer to the battery timeout, or nil.
 *		kindP				-  Pointer to the battery kind, or nil.
 *		plugggedInP			-  Pointer to pluggedIn return value, or nil.
 *		percentP			-  Pointer to percent return value, or nil.  Cannot be set.
 *
 *
 *  RETURNS: the current battery voltage in volts*100.
 *
 *  CREATED: 10/23/95
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/13/97	Added percentP
 *
 *
 *************************************************************/
UInt	SysBatteryInfo(Boolean set, UIntPtr warnThresholdP, UIntPtr criticalThresholdP,
			UIntPtr maxTicksP, SysBatteryKind* kindP, Boolean* pluggedInP, BytePtr percentP)
{	
	UInt batteryLevel;
	
		
	// If changing settings...
	if (set) {
		if (warnThresholdP) 
			GSysBatteryWarnThreshold = ((*warnThresholdP) * hwrStepsPerVolt + 50)/100 
					- hwrVoltStepsOffset;
			
		if (criticalThresholdP) 
			GSysBatteryMinThreshold = ((*criticalThresholdP) * hwrStepsPerVolt + 50)/100 
					- hwrVoltStepsOffset;
			
		if (maxTicksP)
			GSysNextBatteryAlertTimer = *maxTicksP;
			
		if (kindP)
			GSysBatteryKind = *kindP;
		}
	
	
	// Calculate the stored average battery level
	batteryLevel = (((UInt)GHwrBatteryLevel + hwrVoltStepsOffset) * 100 + hwrStepsPerVolt / 2) 
				/ hwrStepsPerVolt;
	
	
	// Retreive current settings
	if (warnThresholdP) 
		*warnThresholdP = 	((GSysBatteryWarnThreshold + hwrVoltStepsOffset) * 100 
				+ hwrStepsPerVolt/2) / hwrStepsPerVolt;
		
	if (criticalThresholdP) 
		*criticalThresholdP = ((GSysBatteryMinThreshold + hwrVoltStepsOffset) * 100 
				+ hwrStepsPerVolt/2) / hwrStepsPerVolt;
		
	if (maxTicksP)
		*maxTicksP = GSysNextBatteryAlertTimer;
		
	if (kindP)
		*kindP = (SysBatteryKind) GSysBatteryKind;
		
	if (pluggedInP)
		*pluggedInP = HwrPluggedIn();
			
	if (percentP)
		*percentP = PrvGetBatteryPercent(batteryLevel, (SysBatteryKind) GSysBatteryKind);
			

	return batteryLevel;
}


/************************************************************
 *
 *  FUNCTION: SysBatteryInfoV20
 *
 *  DESCRIPTION: This routine can be used to retrieve or change settings for
 *		the Batteries. If the parameter 'set' is true, any one or more of the battery
 *		settings can be changed. If 'set' is false, any one or more of the battery
 *		settings can be retrieved.
 *
 *		'warnThresholdP' and 'maxTicksP' are the battery warning voltage threshold and
 *		timeout. If the battery voltage falls below the threshold or, if the timeout
 *		expires, a lowBatteryChr key event will be enqueued. Normally, apps call
 *		SysHandleEvent which will put call SysBatteryWarningDialog in response to
 *		this event. 
 *
 *		'criticalThresholdP' is the critical battery voltage threshold. If the battery
 *		voltage falls below this level, the System will turn off without warning and will
 *		not turn on.
 *
 *		The battery voltage is equal to:
 *				
 *				voltage = (level + hwrVoltStepsOffset) 
 *							  --------------------------
 *							      hwrStepsPerVolt
 *
 *  PARAMETERS: 
 *		set 				-  if true, parameters with non-nil pointers will be changed except
 *									for pluggedIn, which can only be queried.
 *			   				   if false, parameters will non-nil pointers will be retrieved
 *		warnThresholdP 		-  Pointer to battery voltage warning threshold in volts*100, or nil.
 *		criticalThresholdP 	-  Pointer to battery voltage critical threshold in volts*100, or nil.
 *		maxTicksP			-  Pointer to the battery timeout, or nil.
 *		kindP				-  Pointer to the battery kind, or nil.
 *		plugggedInP			-  Pointer to pluggedIn return value, or nil.
 *
 *
 *  RETURNS: the current battery voltage in volts*100.
 *
 *  CREATED: 10/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt	SysBatteryInfoV20(Boolean set, UIntPtr warnThresholdP, UIntPtr criticalThresholdP,
			UIntPtr maxTicksP, SysBatteryKind* kindP, Boolean* pluggedInP)
{
	return 	SysBatteryInfo(set, warnThresholdP, criticalThresholdP,
			maxTicksP, kindP, pluggedInP, NULL);
}


/************************************************************
 *
 *  FUNCTION: SysLaunchConsole
 *
 *  DESCRIPTION: This routine will launch the Console task as a 
 *   separate kernel task if it's not already launched. It is called
 *	  by PilotRestart() in the AMX launching code if the system
 *	  was booted up into the Debugger. It is also called by 
 *	  SysHandleEvent in order to handle the startConsoleChr keyboard
 *	  event.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 8/7/95
 *
 *  BY: Ron Marianetti
 *
 *		vmk	8/1/96	Display UI and abort if serial port already open
 *
 *************************************************************/

// The serial library we use for the console depends on a build option
#if CONSOLE_SERIAL_LIB == CONSOLE_SERIAL_LIB_68681
	#define	prvConsoleLibName	 "Serial Lib68681"
#else
	#define	prvConsoleLibName	 "Serial Library"
#endif	 

static void		PrvConsoleProc(void);
Err	SysLaunchConsole(void)
{	
	Err		err=0;
	
#if	EMULATION_LEVEL == EMULATION_NONE
	UInt		socket;
	DWord		taskID;
	DWord		stackSize = 0x600;
	UInt		refNum;
	ULong		baud, flags;
	CharPtr	consoleSerialLibName = prvConsoleLibName;

	// If it's already launched, do nothing
	if (GSysConsoleStackChunkP)
		return 0;
	

	//----------------------------------------------------------------------
	// Allocate space for the console task stack.
	//----------------------------------------------------------------------
	GSysConsoleStackChunkP = MemPtrNew(stackSize);
	if (!GSysConsoleStackChunkP)
		return memErrNotEnoughSpace;
	MemPtrSetOwner(GSysConsoleStackChunkP, 0);
	
	
	
	

	//----------------------------------------------------------------------
	// Open up the comm library used for the console task, if not already open
	//----------------------------------------------------------------------
	err = SysLibFind(consoleSerialLibName, &refNum);
	#if CONSOLE_SERIAL_LIB == CONSOLE_SERIAL_LIB_68328
		ErrFatalDisplayIf(err, "Serial Library not installed");
	#elif CONSOLE_SERIAL_LIB==CONSOLE_SERIAL_LIB_68681
		ErrFatalDisplayIf(err, "Serial Lib68681 not installed");
	#endif	//CONSOLE_SERIAL_LIB==CONSOLE_SERIAL_LIB_68328
	if (err)
		goto NativeExit;

	// If the debugger is already using a comm library, get it's baud
	//   rate and use that as the default baud for the console comm library
	baud = 0; flags = 0;
	err = DbgCommSettings(&baud, &flags);
	if (err || baud == 0)
		baud = sysDefaultSerBaud;
	
	err = SerOpen(refNum, sysDefaultSerPort, baud); 
	if ( err )
		{
		if (err == serErrAlreadyOpen)
			{
			// This is the most likely error that developers can encounter -
			// having the comm library open by their or some other application
			// and attempting to launch the console.  We do not use the
			// ErrFatalDisplayIf macro because it frequently results in sending
			// the text to the serial port instead of displaying it on the Pilot
			// screen.
			SerClose(refNum);
			if (!SysFatalAlert("Console error: serial manager is already in use"))
				SysReset();
			}
		goto NativeExit;
		}

	//----------------------------------------------------------------------
	// Open up the Console and RemoteUI Sockets.
	//----------------------------------------------------------------------
	socket = slkSocketConsole;
	SlkOpenSocket(refNum, &socket, true);

	socket = slkSocketRemoteUI;
	SlkOpenSocket(refNum, &socket, true);
	

	
	//----------------------------------------------------------------------
	// Launch the Console task
	//----------------------------------------------------------------------
//  *** This line removed from publicly available sources, due to license restrictions...
//  *** This line removed from publicly available sources, due to license restrictions...
//  *** This line removed from publicly available sources, due to license restrictions...
	if (err)
		{
		SerClose(refNum);
		goto NativeExit;
		}
	
//  *** This line removed from publicly available sources, due to license restrictions...
	
NativeExit:											// added: vmk 8/1/96
	if ( err )
		{
		if ( GSysConsoleStackChunkP )			// free the console stack if could not launch
			{
			MemPtrFree(GSysConsoleStackChunkP);
			GSysConsoleStackChunkP = 0;
			}
		}
#endif	//EMULATION_LEVEL == EMULATION_NONE	
	return err;
	
}



/***********************************************************************
 *
 *  FUNCTION:     PrvConsoleProc, private
 *
 *  DESCRIPTION:  The console task for Pilot. This task runs in order
 *    to support console commands from the host. It sits in a loop
 *		calling ConGetS() until a message arrives. ConGetS() looks at packets
 *		and if they are message packets it returns with the message string.
 *
 *		If the packet is instead a remote procedure call packet, ConGetS() will 
 *		automatically process the remote procedure call and wait for another
 *		packet. This is in fact how most console commands are implemented from
 *		the host so ConGetS hardly ever returns with a message.
 *
 *  PARAMETERS:  	void 
 *
 *  RETURNS:      void
 *
 *  CALLED BY:    AMX Kernel after this task is installed and triggerred by 
 *		SysLaunchConsole.
 *
 *  CREATED:      8/7/95
 *
 *  BY:           Ron Marianetti
 *
 ***********************************************************************/
static void PrvConsoleProc(void)
{	
	char		buffer[256];
	Err		err;
	UInt		refNum;
	CharPtr	strP = "\nReady...\n";
	
	
	// Setup A5 world so that 0(A5) gets the pointer
	//  to the SysAppInfo structure for the system.
	SysSetA5((DWord)&GSysAppInfoP);
	
	
	// Get the refNum of the serial library
	err = SysLibFind(prvConsoleLibName, &refNum);
	if (err) DbgBreak();
	

	// Wait for commands
	err = 1;
	while(1) {
		if (err) {
			ConPutS(strP);
			SerReceiveFlush(refNum, sysTicksPerSecond/4);
			}
			
		// Wait for command
		err = ConGetS(buffer, -1); 
		
		// echo it
		if (!err && buffer[0]) 
			ConPutS(buffer);
		}
}




/***********************************************************************
 *
 * FUNCTION:    PrvSendTaxi
 *
 * DESCRIPTION: This routine sends the Taxi across the screen
 *
 * PARAMETERS:  
 *			y 			- initial y coordinate
 *			speed 	- how fast the taxi drives across given in pixels/second.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			ron	11/13/95	Initial Revision
 *
 ***********************************************************************/
#define		kTaxiBitmapID			11000			// Bitmap of Taxi
#define		kTaxiMaskID				11001			// Mask of Taxi
#define		kTaxiSmoke				8				// size of smoke of right side of bitmap
#define		kTaxiBounce				8				// vertical bounce in each direction
#define		kTaxiDBounce			2				// delta bounce each frame

static void PrvSendTaxi (UInt speed)
{
	WinHandle			oldDrawWinH, saveWinH=0, workWinH=0;
	WinHandle			taxiWinH=0, maskWinH=0;
	RectangleType		screenR, saveR, workR, taxiR, srcR;
	
	BitmapPtr			taxiBitsP=0;
	BitmapPtr			maskBitsP=0;
	Handle				taxiH, maskH;
	
	SWord					screenWidth, screenHeight;
	Word					error;
	Long					lastTicks, framePeriod, wait;
	Int					delta;
	Int					bounce=0, dBounce=kTaxiDBounce;
	UInt					y;
	
	
	// Pick a random y coordinate to come out from
	y = SysRandom(0) % 140;

	//...................................................................
	// Figure out the delta amount and the delay between frams.
	// The delta is how many pixels away each frame is drawn from
	//  the previous frame.
	// The framePeriod is how many ticks to wait between frames
	//...................................................................
	delta = 8;
	framePeriod = delta * sysTicksPerSecond/speed;
	
	//...................................................................
	// Set the draw window to the display
	//...................................................................
	oldDrawWinH = WinGetDrawWindow();
	WinSetDrawWindow(WinGetDisplayWindow());
	WinGetDisplayExtent(&screenWidth, &screenHeight);
	


	//...................................................................
	// Get the taxi bitmap and mask resources and form window structures
	//  for them.
	//...................................................................
	taxiH = DmGetResource(bitmapRsc, kTaxiBitmapID);
	if (!taxiH) goto Exit;
	taxiBitsP = (BitmapPtr)MemHandleLock(taxiH);
	taxiWinH = WinCreateOffscreenWindow(taxiBitsP->width, taxiBitsP->height,
		screenFormat, &error);
	if (error) goto Exit;
	WinSetDrawWindow(taxiWinH);
	WinDrawBitmap(taxiBitsP, 0, 0);
	WinGetWindowBounds(&taxiR);

	
	maskH = DmGetResource(bitmapRsc, kTaxiMaskID);
	if (!maskH) goto Exit;
	maskBitsP = (BitmapPtr)MemHandleLock(maskH);
	maskWinH = WinCreateOffscreenWindow(maskBitsP->width, maskBitsP->height,
		screenFormat, &error);
	if (error) goto Exit;
	WinSetDrawWindow(maskWinH);
	WinDrawBitmap(maskBitsP, 0, 0);
	
	
	
	// Clip the delta 
	if (delta > taxiR.extent.x) delta = taxiR.extent.x;
	if (delta < 1) delta = 1;
	
	
	
	
	//...................................................................
	// Form the starting position on the screen
	//...................................................................
	screenR.topLeft.x = screenWidth - delta;
	screenR.topLeft.y = y;
	screenR.extent.x = taxiR.extent.x;
	screenR.extent.y = taxiR.extent.y + kTaxiBounce;
	
	// Form our save window
	saveR = screenR;
	saveR.topLeft.x = saveR.topLeft.y = 0;
	saveWinH = WinCreateOffscreenWindow(saveR.extent.x, saveR.extent.y,
		screenFormat, &error);
	if (error) goto Exit;
	
	
	
	//...................................................................
	// Form the work rectangle and window. This window must be the width of the bitmap
	//  plus the delta width for each step
	//...................................................................
	workR = saveR;
	workR.extent.x += delta;
	workWinH = WinCreateOffscreenWindow(workR.extent.x, workR.extent.y,
		screenFormat, &error);
	if (error) goto Exit;
	
	
	
	//...................................................................
	// Save the bits on the screen to our save window
	//...................................................................
	WinSetDrawWindow(WinGetDisplayWindow());
	WinCopyRectangle(0, saveWinH, &screenR, 0, 0, scrCopy);
	
	
	// Init the time and the lastSmoke x coordinate
	lastTicks = 0;
	do {
		
		// Copy the save area to the left side of the work area
		WinCopyRectangle(saveWinH, workWinH, &saveR, 0, 0, scrCopy);
		
		
		// Erase the mask portion of the work area
		// If we're at the low point of the bounce, add smoke
		srcR = taxiR;
		if (bounce != kTaxiBounce) {
			srcR.extent.x -= kTaxiSmoke;
			}
		WinCopyRectangle(maskWinH, workWinH, &srcR, 0, bounce, scrANDNOT);
			
		// OR in the taxi
		WinCopyRectangle(taxiWinH, workWinH, &srcR, 0, bounce, scrOR);
			
			
		// Copy the work rect to the screen after our frame timeout
		wait = lastTicks + framePeriod - TimGetTicks();
		if (wait > 0) SysTaskDelay(wait);
		WinCopyRectangle(workWinH, 0, &workR, 
			screenR.topLeft.x, screenR.topLeft.y, scrCopy);
		lastTicks = TimGetTicks();
			
			
		// Shift to the left and add new bounce
		screenR.topLeft.x -= delta;
		bounce += dBounce;
		if (bounce > kTaxiBounce) {
			bounce = kTaxiBounce;
			dBounce = -kTaxiDBounce;
			}
		else if (bounce < 0) {
			bounce = 0;
			dBounce = kTaxiDBounce;
			}
		
		
		// Restore the work area that the taxi will move out of from our save window.
		//  This is the right edge of the save window goes to the right edge of
		//  the work window.
		srcR.topLeft.x = saveR.extent.x - delta;
		srcR.topLeft.y = 0;
		srcR.extent.x = delta;
		srcR.extent.y = saveR.extent.y;
		WinCopyRectangle(saveWinH, workWinH, &srcR,
			workR.extent.x - delta, 0, scrCopy);
			
			

		// Shift the save image over to the right
		srcR = saveR;
		srcR.extent.x = saveR.extent.x - delta;
		WinCopyRectangle(saveWinH, saveWinH, &srcR,
			delta, 0, scrCopy);
			
		// Save the new left area of the screen to the save window
		srcR = screenR;
		srcR.extent.x = delta;
		WinCopyRectangle(0, saveWinH, &srcR, 0, 0, scrCopy);
		
		// Break out if we're off the screen
		} while((screenR.topLeft.x + taxiR.extent.x + delta) > 0);
	
	
	
Exit:
	// Release resources
	if (taxiBitsP) {
		MemHandleUnlock(taxiH);
		DmReleaseResource(taxiH);
		}
	if (maskBitsP) {
		MemHandleUnlock(maskH);
		DmReleaseResource(maskH);
		}
	if (saveWinH) 
		WinDeleteWindow(saveWinH, false);
	if (workWinH) 
		WinDeleteWindow(workWinH, false);
	if (taxiWinH) 
		WinDeleteWindow(taxiWinH, false);
	if (maskWinH) 
		WinDeleteWindow(maskWinH, false);
	
	// Restore the draw window
	WinSetDrawWindow(oldDrawWinH);
}

/************************************************************
 *
 *  FUNCTION: PrvShowTaxi
 *
 *  DESCRIPTION: Return true if we should show the taxi or not.
 *
 *  PARAMETERS: 
 *			forIdle - true if checking at idle time
 *
 *  RETURNS: Boolean
 *
 *  CREATED: 11/14/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Boolean 		PrvShowTaxi(Boolean forIdle)
{
	ULong		time;
	DWord		flag;
	Boolean	enable=false;
	
	
	// Get the system time
	time  = TimGetSeconds();


	//..................................................................
	// Update the state of the sysPrefFlagNoTaxiIdle flag. If set,
	//  meaning the taxi just showed up recently, clear it if
	//  the 16th bit of the system time has changed since we
	//  set it. This will happen about once every 18 hours. This way,
	//  we make sure the Taxi doesn't show up more than about once
	//  a day.
	//..................................................................
	if (GSysPrefFlags & sysPrefFlagTaxiDisIdle) {
		flag = GSysPrefFlags & sysPrefFlagTaxiDisIdleTime;
		flag <<= 2;						// because flag is either 0x4000 or 0
		if ((time & 0x00010000) != flag)
			GSysPrefFlags &= ~sysPrefFlagTaxiDisIdle;
		}
	
	//..................................................................
	// Return true if the NoTaxi bit is not set.
	//..................................................................
	if (GSysPrefFlags & sysPrefFlagEnableEasterEggs) 
		enable = true;
	
	// If this is not a check to see if it should show up at idle, return
	//   the result now
	if (!forIdle || !enable) return enable;
	
	
	//.........................................................................
	// If this is a check to see if it should show up during idle,
	//  be a little more picky. We will not show it if it just showed up
	//  recently (sysPrefFlagTaxiDisIdle set). 
	// If it didn't show up recently, only show it if the low N bits of
	//  the time equal the top N bits of the time.
	//.........................................................................
	if (GSysPrefFlags & sysPrefFlagTaxiDisIdle) return false;
	if  (((time >> 16) & 0x0FFE) == (time & 0x000FFE))	{		
		GSysPrefFlags |= sysPrefFlagTaxiDisIdle;
		GSysPrefFlags &= ~sysPrefFlagTaxiDisIdleTime;		// clear flag first
		GSysPrefFlags |= (time & 0x00010000) >> 2;			// get current bit value into flag
		return true;
		}

	return false;
}	
					



/************************************************************
 *
 *  FUNCTION: SysHandleEvent
 *
 *  DESCRIPTION: Default Event handling for System events such as
 *   hard and soft key presses. Applications should call this routine
 *   immediately after calling EvtGetEvent unless they want to 
 *   override the default system behavior.
 *
 *  PARAMETERS: saveState boolean
 *
 *  RETURNS: true if the System handled the event
 *
 *  CREATED: 4/28/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Boolean 		SysHandleEvent(EventPtr eventP)
{	
	SysEvtMgrGlobalsPtr	gP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	DWord						creator;
	UInt						cardNo;
	LocalID					dbID;
	PointType*				startPtP;
	PointType*				endPtP;
	short						x, y;
	Boolean					penDown;
	ULong						curCreator;	
	Err						err;
	Word						cmd;
	Boolean					oldState;
	DWord						endTime;
	
	//-------------------------------------------------------------------
	// If it's a pen-down event in the system area, track the pen until
	//  it comes up. This is required under emulation mode because calling
	//  EvtGetPen repeatedly allows the emulator to enqueue the points that
	//  comprise the stroke.
	//-------------------------------------------------------------------
	if (eventP->eType == penDownEvent) {
		
		// Convert coordinate into display space.
		x = eventP->screenX;
		y = eventP->screenY;
		WinWindowToDisplayPt(&x, &y);
		
		// If the start point is in the application area, ignore it
		if (y < gP->appAreaBottom) 
			return false;
			
		// Else, track the pen until it comes up. 
		// DOLATER... we should add a flag to SysEvtMgr so that it doesn't
		//  have to wake up the event loop for penMoved events when we don't
		//  need them...
		else	{
			do {
				EvtGetPen(&x, &y, &penDown);
				} while (penDown);
			return true;
			}
		}	


	//-------------------------------------------------------------------
	// If it's a pen-up event and it's in the system area, try and
	//  recognize it.
	//-------------------------------------------------------------------
	if (eventP->eType == penUpEvent) {
		
		// If the start point is in the application area, ignore it
		if (eventP->data.penUp.start.y < gP->appAreaBottom) 
			return false;
			
		// Pointers for quick reference
		startPtP = &eventP->data.penUp.start;
		endPtP = &eventP->data.penUp.end;


		// If the stroke started in the writing area, send it to Graffiti
		//  to recognize it. The GrfProcessStroke routine will flush 
		//  the stroke out for us.
		if (RctPtInRectangle(startPtP->x, startPtP->y, &gP->writingR)) {
		
			// Send the taxi if the stroke ends at the left edge of the screen
			if (endPtP->x < 2)
				if (KeyCurrentState() & keyBitPageDown)
					if (PrvShowTaxi(false))		
						PrvSendTaxi(64);
		
			// Process Graffiti Stroke
			if (gP->enableGraffiti) {
				GrfProcessStroke(startPtP, endPtP, false);
				return true;
				}
			else
				return false;
			}
				
		// It could be one of the silk screen buttons, call EvtProcessSoftKeyStroke
		//  to convert the stroke to a keycode and enqueue it.
		else if (gP->enableSoftKeys) {
			EvtProcessSoftKeyStroke(startPtP, endPtP);
			return true;
			}
			
		// Else, we didn't handle it
		else
			return false;
		}
		
	//-------------------------------------------------------------------
	// Have some fun with nil events...
	//-------------------------------------------------------------------
	else if (eventP->eType == nilEvent) {
	
		// If idle for at least 10 seconds
		if (GHwrCurTicks - GSysAutoOffEvtTicks > 10*sysTicksPerSecond) {

			// And taxi enabled
			if (PrvShowTaxi(true)) 
				PrvSendTaxi(64);
			}
		}
	
	
	//-------------------------------------------------------------------
	// Check for System keyboard events
	//-------------------------------------------------------------------
	else if (eventP->eType == keyDownEvent) {
	
		if (eventP->data.keyDown.modifiers & appEvtHookKeyMask) 
			{
				UInt		cardNo;														
				LocalID	appDBID;		
				DWord    result;
				DmSearchStateType	searchState;									
				DWord   creator;									
				
				// creator is stored in chr for high two bytes and keycode for lower bytes			
				creator	= eventP->data.keyDown.chr;
				creator <<= 16;
				creator |= eventP->data.keyDown.keyCode;										
				/* Find the application */											
				err = DmGetNextDatabaseByTypeCreator(						
						true/*newSearch*/, &searchState,							
						sysFileTApplication, creator,										
						true/*onlyLatestVers*/, &cardNo, &appDBID);		
				if ( !err)														
					err = SysAppLaunch(cardNo, appDBID,					
						0/*launchFlags*/, sysAppLaunchCmdEventHook, (char *)eventP, &result);	
			
			return true;
			}
		else if (eventP->data.keyDown.modifiers & libEvtHookKeyMask) 
			{
				// we call exgLib here
				// In the emulator this will always call exglib,
				// but on the real unit, this will call the first custom trap in 
				// the library referenced by the refnum in keycode.
				ExgLibHandleEvent(eventP->data.keyDown.keyCode,eventP);
				return true;
			}

	
		if (!(eventP->data.keyDown.modifiers & commandKeyMask)) return false;
		
		if ( eventP->data.keyDown.chr == alarmChr )
			{
			//------------------------------------------------------------------------
			// Call the Alarm Manager to display any alarms which have expired
			//------------------------------------------------------------------------
			AlmDisplayAlarm( true/*displayOnly*/);
			return true;
			}

		// Play click sound except for the power key and low battery key
		if (eventP->data.keyDown.chr != hardPowerChr &&
			 eventP->data.keyDown.chr != lowBatteryChr &&
			 eventP->data.keyDown.chr != ronamaticChr &&
			 eventP->data.keyDown.chr != sendDataChr &&
			 eventP->data.keyDown.chr != autoOffChr)
			SndPlaySystemSound(sndClick);
	
		// Get the creator type of the app we need to switch to
		cmd = sysAppLaunchCmdNormalLaunch;
		switch (eventP->data.keyDown.chr) {
			case hardPowerChr:
				// If the power key is held down for more than keyMinBacklightTicks,
				//  we toggle the backlight. Else, we go to sleep
				endTime = TimGetTicks() + keyMinBacklightTicks;
				
         		// make sure we have a backlight and the backlight is not disabled (for power reasons)
				if ((GHwrMiscFlags & hwrMiscFlagHasBacklight) && !(GSysMiscFlags & sysMiscFlagBacklightDisable))
					do {
						if (!(KeyCurrentState() & keyBitPower))
							break;
						SysTaskDelay(1);							// to conserve power..
						} while (TimGetTicks() < endTime);
				
				// Key held down for a "long" time? If so, toggle backlight
				if (TimGetTicks() >= endTime) {
					Byte	oldState;
					oldState = HwrBacklight(false, false);
					HwrBacklight(true, !oldState);
					}
				// If not, turn off. 
				else {
					// If the NetLib is installed and up, give it a chance to close
					// the current connection. The NetLibHandlePowerOff call returns
					// non-zero if the power off should be ignored.
					if (GSysLibNet)
						if (NetLibHandlePowerOff(GSysLibNet, eventP)) return true;
					
					SysSleep(false, false);
					}
				return true;
				
			case autoOffChr:
				// If the NetLib is installed and up, give it a chance to close
				// the current connection. The NetLibHandlePowerOff call returns
				// non-zero if the power off should be ignored.
				if (GSysLibNet) {
					if (NetLibHandlePowerOff(GSysLibNet, eventP)) return true;
					}
					
				SysSleep(false, false);
				return true;
				
			

			case ronamaticChr: {
				UInt keyCode;
				keyCode = PrefGetPreference(prefRonamaticChar);
				EvtEnqueueKey(keyCode, 0, commandKeyMask);
				return true;
				}

			case keyboardChr:
				SysKeyboardDialog(kbdDefault);
				return true;

			case keyboardAlphaChr:
				SysKeyboardDialog(kbdAlpha);
				return true;

			case keyboardNumericChr:
				SysKeyboardDialog(kbdNumbersAndPunc);
				return true;

			case graffitiReferenceChr:
				SysGraffitiReferenceDialog(referenceDefault);
				return true;

			case launchChr:
				{
				DmSearchStateType	state;
				
				
				creator = PrefGetPreference(prefLauncherAppCreator);
				
				// Use the system launcher if the user hasn't specified 
				// an app to use for the launcher or if the app is missing.
				if (creator == sysFileCNullApp ||
					DmGetNextDatabaseByTypeCreator(true, &state, sysFileTApplication, 
						creator, true, &cardNo, &dbID) == dmErrCantFind)
					{
					SysAppLauncherDialog();
					return true;
					}
				}
				
				// Fall into the code to switch to a launcher app
				break;

			case findChr: {
				GoToParamsType		goTo;
				Find (&goTo);
				return true;
				}

			case lockChr:
				{
				DmSearchStateType	state;
				
				
				// Get the database ID of the Security app given the creator type
				err = DmGetNextDatabaseByTypeCreator(true, &state, 
					sysFileTApplication, sysFileCSecurity, true, &cardNo, &dbID);
				
				// Try and switch apps passing the lock command.
				if (dbID && !err) 
					SysUIAppSwitch(cardNo, dbID, sysAppLaunchCmdSystemLock, 0);
					
				return true;
				}
				
			case backlightChr:
				if (GHwrMiscFlags & hwrMiscFlagHasBacklight) {
					oldState = HwrBacklight(false, 0);
					HwrBacklight(true, !oldState);
					}
				return true;
				break;

			case calcChr:
				creator = PrefGetPreference(prefCalcCharAppCreator);
				break;

			case hardCradleChr:
				creator = PrefGetPreference(prefHardCradleCharAppCreator);
				if (creator == sysFileCSync)
					{
					cmd = sysAppLaunchCmdSyncRequest;
					}
				break;

			case hardCradle2Chr:
				creator = PrefGetPreference(prefHardCradle2CharAppCreator);
				if (creator == sysFileCSync)
					{
					cmd = sysAppLaunchCmdSyncRequestRemote;
					}
				break;

			case hard1Chr:
				creator = PrefGetPreference(prefHard1CharAppCreator);
				break;

			case hard2Chr:
				creator = PrefGetPreference(prefHard2CharAppCreator);
				break;

			case hard3Chr:
				creator = PrefGetPreference(prefHard3CharAppCreator);
				break;

			case hard4Chr:
				creator = PrefGetPreference(prefHard4CharAppCreator);
				break;

			case lowBatteryChr: 
				// Put up the battery warning and schedule the next one
				if (!gP->displayingBatteryAlert) {
					gP->displayingBatteryAlert = true;
					SysBatteryDialog();
					gP->displayingBatteryAlert = false;
					}
				return true;
				
			case enterDebuggerChr: 
				// Go into Debugger. Set the GDbgWasEntered global so that the
				//  Debugger exception handler doesn't reset the device.
				GDbgWasEntered = true;
				DbgBreak();
				return true;
				
			case startConsoleChr: 
				// Startup the console task
				SysLaunchConsole();
				return true;
				
			default:
				return false;
			}
		
		
		// Under emulation, we can't launch another app so don't
		//  handle the event
		#if EMULATION_LEVEL != EMULATION_NONE
		return false;
		#endif


		// Get the creator type of the currently running app to see if the
		//  User hit the same button
		curCreator = 0;
		err = SysCurAppDatabase(&cardNo, &dbID);
		if (!err) 
			err = DmDatabaseInfo(cardNo, dbID, 0,
						0, 0, 0,
						0, 0,
						0, 0,
						0, 0,
						&curCreator);
						
		// If this app is already running, don't launch it again and say
		//  we didn't handle the event so that the app ends up getting the
		//  key event.
		if (curCreator == creator) return false;
			
		
		
		// Get the database ID of the app given the creator type
		if (1) { 
			DmSearchStateType	state;
			err = DmGetNextDatabaseByTypeCreator(true, &state, 
				sysFileTApplication, creator, true, &cardNo, &dbID);
				
			// If not found and its one of the "button" apps then
			// revert back to the default app assigned to the button
			if (err == dmErrCantFind) {
				err = 0;
				switch (eventP->data.keyDown.chr) {
					case calcChr:
						creator = sysFileCDefaultCalcButtonApp;
						break;

					case hardCradleChr:
						creator = sysFileCDefaultCradleApp;
						cmd = sysAppLaunchCmdSyncRequest;
						break;

					case hardCradle2Chr:
						creator = sysFileCDefaultModemApp;
						cmd = sysAppLaunchCmdSyncRequestRemote;
						break;

					case hard1Chr:
						creator = sysFileCDefaultButton1App;
						break;

					case hard2Chr:
						creator = sysFileCDefaultButton2App;
						break;

					case hard3Chr:
						creator = sysFileCDefaultButton3App;
						break;

					case hard4Chr:
						creator = sysFileCDefaultButton4App;
						break;
						
					default:
						err = dmErrCantFind; 
					}
					
				if (err == 0) {
					err = DmGetNextDatabaseByTypeCreator(true, &state, 
						sysFileTApplication, creator, true, &cardNo, &dbID);
				}
			}
				
			// If not found, launch the preferences app with normal action code
			if (err) {
				// launch with normal action code
				cmd = 0;
				err = DmGetNextDatabaseByTypeCreator(true, &state, 
					sysFileTApplication, sysFileCPreferences, true, &cardNo, &dbID);
				if (err) dbID = 0;
				}
			}
		
		// Try and switch apps.
		if (dbID) 
			SysUIAppSwitch(cardNo, dbID, cmd, 0);
			
			
		return true;
		}
		
		
	// Else, don't handle it.
	return false;
}




/************************************************************
 *
 *  FUNCTION: SysUIAppSwitch
 *
 *  DESCRIPTION: Tries to make the current UI application quit and
 *   then launches the given UI application by card number and database ID.
 *
 *  PARAMETERS: cardNo, dbID
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 4/26/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err 		SysUIAppSwitch(UInt cardNo, LocalID dbID, Word cmd, Ptr cmdPBP)
{	
	EventType event;
	
	
	ErrFatalDisplayIf(cardNo >= GMemCardSlots, "Invalid card");
	
	// If the last launch attempt failed, release the command parameter block, if
	//  any. When a launch succeeds, the UIAppShell will clear this global
	//  and free the chunk itself  when the app quits.
	if (GNextUIAppCmdPBP) {
		MemPtrFree(GNextUIAppCmdPBP);
		GNextUIAppCmdPBP = 0;
		}

	// Save info necessary to launch the next app
	GNextUIAppDBID = dbID;
	GNextUIAppCardNo = cardNo;
	GNextUIAppCmd = cmd;
	GNextUIAppCmdPBP = cmdPBP;
	GSysMiscFlags |= sysMiscFlagAlwaysSwitchApp;
	

	// Send a quit event to the current UI App
	#if EMULATION_LEVEL != EMULATION_NONE
	ErrFatalDisplayIf(GCurUIAppInfoP == 0, "No app running");
	#endif
	
	event.eType = appStopEvent;
	EvtAddEventToQueue(&event);
	
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysCurAppDatabase
 *
 *  DESCRIPTION: Returns the card number and Database ID of the 
 *   current application's resource database.  The current app is 
 *   defined as the last running action code or else the UI app.
 *
 *  PARAMETERS: none
 *
 *  RETURNS: 0 if error.
 *
 *  CREATED: 4/27/95
 *
 *  BY: Ron Marianetti
 *
 *	Name	Date		Description
 *	----	----		-----------
 *	roger	12/12/97	Change to use SysCurAppInfo
 *
 *************************************************************/
Err	SysCurAppDatabase(UIntPtr cardNoP, LocalID* dbIDP)
{
	SysAppInfoPtr	infoP;
	SysAppInfoPtr	uiAppP;
	SysAppInfoPtr	actionCodeAppP;
	Err				err;
	
	// Assume error
	*cardNoP = 0;
	*dbIDP = 0;
	
	// Return 0,0 if running emulated mode
	#if EMULATION_LEVEL != EMULATION_NONE
	return 0;
	#endif
	
	// Get pointer to the app info
	SysGetAppInfo(&uiAppP, &actionCodeAppP);
	if (actionCodeAppP)
		infoP = actionCodeAppP;
	else
		infoP = uiAppP;
	if (infoP) 
		err = DmOpenDatabaseInfo((DmOpenRef)infoP->dbP, dbIDP, 0, 
							0, cardNoP, 0);
	else
		err = sysErrParamErr;
		
	return err;
}
	


/************************************************************
 *
 *  FUNCTION: SysCurAppInfoPV20
 *
 *  DESCRIPTION: Returns the SysAppInfoPtr for the current app. 
 *   This routine uses global variables and doesn't rely on A5.
 *
 *  PARAMETERS: none
 *
 *  RETURNS: 0 if error.
 *
 *  CREATED: 4/27/95
 *
 *  BY: Ron Marianetti
 *
 *	Name	Date		Description
 *	----	----		-----------
 *	roger	12/12/97	Change to use the new call
 *
 *************************************************************/
SysAppInfoPtr	SysCurAppInfoPV20(void)
{
	SysAppInfoPtr appInfoP;
	SysAppInfoPtr unusedAppInfoP;
	
	SysGetAppInfo(&appInfoP, &unusedAppInfoP);
	
	return appInfoP;
}
	

/************************************************************
 *
 *  FUNCTION: PrvGetAppInfo
 *
 *  DESCRIPTION: Returns the SysAppInfoPtr for the current app. This
 *   routine assumes that the current application's A5 world has been
 *   setup and that A5 is pointing to it. The SysAppInfoPtr is retrieved
 *   from 0(A5).
 *
 *  PARAMETERS: nothing (A5)
 *				Note that the DWord at (A5 & 0x7fffffff) MUST point to an SysAppInfoType!
 *
 *  RETURNS: SysAppInfoPtr for the current thread or NULL
 *
 *  CREATED: 12/16/97
 *
 *  BY: Roger Flores
 *
 *		vmk	2/16/98	Fixed the assembly version so that it doesn't
 *							use A5 as a temporary register, which was causing
 *							the most significant bit of A5 to be unmasked
 *
 *************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE

static SysAppInfoPtr PrvGetAppInfo(void)
{
	return (SysAppInfoPtr)GCurUIAppInfoP;
}

#else

static SysAppInfoPtr asm PrvGetAppInfo(void)
{
	MOVE.L	A5, D0
	BCLR		#31, D0				// clear the high bit to reverse effects of PrvProtectSegmentRegister
	MOVE.L	D0, A0
	MOVE.L	(A0), A0
	RTS
}

#endif


/************************************************************
 *
 *  FUNCTION: SysGetAppInfo
 *
 *  DESCRIPTION: Returns the SysAppInfoPtr for the current app and
 *   for the last current running action code.  This routine uses
 *   A5 and global variables.
 *
 *  PARAMETERS: uiAppPP - pointer to where to store a SysAppInfoPtr for
 *						  the currently running app
 *				actionCodeAppPP - pointer to where to store a SysAppInfoPtr for
 *						  the currently running action code
 *
 *  RETURNS: uiAppPP is set to the current app's info
 *			 actionCodeAppPP is set the app info used by an action code or else NULL
 *			 The currently running app's appInfo is returned.
 *
 *  CREATED: 12/11/97
 *
 *  BY: Roger Flores
 *
 *************************************************************/
SysAppInfoPtr	SysGetAppInfo(SysAppInfoPtr *rootAppPP, SysAppInfoPtr *actionCodeAppPP)
{
	SysAppInfoPtr currentAppInfoP;
	
	
	ErrNonFatalDisplayIf(rootAppPP == NULL, "Null rootAppPP");
	ErrNonFatalDisplayIf(actionCodeAppPP == NULL, "Null actionCodeAppPP");
	
	currentAppInfoP = PrvGetAppInfo();
	ErrNonFatalDisplayIf(currentAppInfoP == NULL, "Null sys app info");
	if (currentAppInfoP->rootP == NULL)
		{
		// Either the UI app or some other thread is running.  Just use A5.
		*actionCodeAppPP = NULL;
		*rootAppPP = currentAppInfoP;
		}
	else
		{
		// An action code is running
		*rootAppPP = currentAppInfoP->rootP;
		*actionCodeAppPP = currentAppInfoP;
		ErrNonFatalDisplayIf(*actionCodeAppPP == NULL, "Null actionCodeAppP");
		}

	// Validate the return values.
	ErrNonFatalDisplayIf(*rootAppPP == NULL && rootAppPP != actionCodeAppPP, "returning Null uiAppP");
	ErrNonFatalDisplayIf(currentAppInfoP == NULL, "returning Null");
	
	// Structure validation code.
	ErrNonFatalDisplayIf((DWord) currentAppInfoP->dmAccessP > 0x20000000, "Bad dmAccessP");
	ErrNonFatalDisplayIf((DWord) (currentAppInfoP->cmdPBP) > 0x20000000, "Bad cmdPBP");

	// Return the appInfo of the last running app
	return currentAppInfoP;
}
	


/************************************************************
 *
 *  FUNCTION: SysGetStackInfo
 *
 *  DESCRIPTION: Returns the current app's stack bounds as well 
 *  as whether or not the stack is overflowed
 *
 *  PARAMETERS: startPP - where to store the stack's start
 *				endPP - where to store the stack's last byte
 *
 *  RETURNS: true if the stack is valid and false if it's overflowed
 *
 *	This code doesn't correctly handle the case where an action code
 *	allocates it's own stack and then calls another action code.
 *
 *  CREATED: 12/29/97
 *
 *  BY: Roger Flores
 *
 *************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE

Boolean SysGetStackInfo(Ptr *startPP, Ptr *endPP)
{
	*startPP = NULL;
	*endPP = NULL;
	return true;
}

#else

Boolean SysGetStackInfo(Ptr *startPP, Ptr *endPP)
{
	SysAppInfoPtr appInfoP;
	SysAppInfoPtr unusedAppInfoP;
	
	
	appInfoP = SysGetAppInfo(&unusedAppInfoP, &unusedAppInfoP);
	if (!appInfoP->stackP)
		appInfoP = appInfoP->rootP;
		
	*startPP = appInfoP->stackP;
	*endPP = appInfoP->stackEndP;
	
	// This could be smartened by only doing this if stackP <= sp <= stackEndP
	return appInfoP->stackEndP == NULL || *appInfoP->stackEndP == 0xFE;
}

#endif


/************************************************************
 *
 *  FUNCTION: SysBroadcastActionCode
 *
 *  DESCRIPTION: Sends the given action code and parameter block to
 *		the latest version of every UI app.
 *
 *  PARAMETERS: 
 *			cmd 		- 	action code to send
 *			cmdPBP	- action code parameter block
 *
 *  RETURNS: 0 if no error.
 *
 *  CREATED: 9/19/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	SysBroadcastActionCode(Word cmd, Ptr cmdPBP)
{
	UInt					index=0;
	Err					err;
	UInt					cardNo;
	LocalID				dbID;
	DWord					result;
	Boolean				newSearch=true;
	DmSearchStateType	state;
	
	
	// First, broadcast to all applications
	while(1) {
	
		// Find the next application.
		err = DmGetNextDatabaseByTypeCreator(newSearch, &state, sysFileTApplication,
			0, true, &cardNo, &dbID);
		newSearch = false;
		if (err == dmErrCantFind) {err=0; break; }
		
		// Send the action code
		err = SysAppLaunch(cardNo, dbID, 0, cmd, cmdPBP, &result);
		}
	
	
	// Then, broadcast to all panels
	newSearch = true;
	while(1) {
	
		// Find the next panel.
		err = DmGetNextDatabaseByTypeCreator(newSearch, &state, sysFileTPanel,
			0, true, &cardNo, &dbID);
		newSearch = false;
		if (err == dmErrCantFind) {err=0; break; }
		
		// Send the action code
		err = SysAppLaunch(cardNo, dbID, 0, cmd, cmdPBP, &result);
		}
	
	
	ErrFatalDisplayIf(err, "Error broadcasting action code");
	return	err;
}




/************************************************************
 *
 *  FUNCTION: SysAppLaunch
 *
 *  DESCRIPTION: Given a card number and database ID of an application resource
 *		database, this routine will launch that application with the 
 *		given command line arguments.
 *
 *
 *
 *
 *
 *  If it is a "Nested Launch" the 
 *		sysAppLaunchFlagNewStack can be set to automatically create a separate 
 *		stack chunk for the application with a size determined by the PREF resource 
 *		of the application.  If the sysAppLaunchFlagNewStack
 *		bit is not set for a nested launch, the launched application will use the
 *		caller's stack.
 *
 *
 *
 *  If the sysAppLaunchFlagNewGlobals bit is set, the globals world of the application
 *		will be allocated and initialized and register A5 will be set-up to point to the 
 *		globals world. A new globals world implies a new owner ID for memory chunks
 *		allocated by the application. When an application with a globals world quits,
 *		all memory chunks in the dynamic heap which have it's owner ID will be
 *		automatically freed by the system.
 *		
 *
 *  It is expected that an application will be launched with all launch bits
 *		cleared when performing call-back functions to the app, such as when
 *		performing global searches, some syncing functions, etc. This essentially
 *		makes the application a subroutine call from the point of view of the caller.
 *
 *
 *	 Note that a special case launch occurs when we launch the AMX kernel
 *		itself. Because AMX is not yet installed,  calls to SysTaskID return nil. 
 *		When the task ID is nil we use an ownerID of 0 (system) for memory
 *		manager chunks.
 *
 *	 When an application is launched on the current thread (a Nested Launch),
 *		this procedure doesn't return until the nested application quits.
 *
 *
 *
 *
 *
 *	 The Launch process proceeds as follows:
 *	  In SysLaunchApp:
 *		1.) If the sysAppLaunchFlagNewStack bit is set,
 *			the desired stack size is retrieved out of the PREF=0 resource
 *			of the app and a chunk is allocated for the stack.
 *		2.) The CODE=1 resource of the app is located - this is the entry
 *			point to the application's startup code.
 *		3.) If not launching a 
 *			new thread, the task ID of the current task is retrieved.
 *		4.) Cmd and cmdPBP for the new application are stored in the user fields
 *			of the task's TCB for later retrieval by SysAppStartup.
 *
 *
 *
 *
 *		5.) If not a new thread, the current value of launchNestLevel
 *			is incremented. This counter is decremented by SysAppExit and is 
 *			used to determine when the task itself should be deleted and whether or
 *			not the stack chunk and rootCmdPBP chunk should be freed by SysAppExit.
 *
 *		6.) The entry point to CODE=1 resource is simple called. 
 *			This transfers control to the application's startup code.
 *
 *
 *	   In Application startup code:
 *		1.) SysAppStartup is called with a copy of the launch flags.
 *		2.) If the sysAppLaunchFlagNewGlobals bit is set, SysAppStartup 
 *			will get the required size of the app globals out of
 *			the CODE=0 resource, allocate and initialize the globals and
 *			sets up register A5 to point to the globals.
 *		3.) SysAppStartup then retrieves the cmd and cmdPBP from the TCB
 *			user info fields of the current task and returns to the
 *			app startup code with the oldA5, a pointer to the globals chunk,
 *			and the cmd and cmdPBP parameters.
 *		4.) The PilotMain routine of the application is called with cmd and cmdPBP.
 *		
 *	   In Application main() routine:
 *		1.) Application runs and returns eventually with 32-bit result code
 *
 *	   Back in Application startup code
 *		1.) If the sysAppLaunchFlagNewGlobals bit was set, the Globals chunk is freed
 *				and A5 is restored.
 *		2.)
 *
 *
 *
 *
 *		3.) If we weren't starting a new thread, the application startup 
 *			code will simply return to SysAppLaunch. SysAppLaunch then
 *			frees the chunks used to hold the stack and cmdPBP and returns to 
 *			it's caller.
 *
 *  PARAMETERS: 	Word		cmd			- application command code
 *						Ptr		cmdPBP		- application command parameter block
 *						UInt 		launchFlags	- Launch flags, can be 1 or more of:
 *													� sysAppLaunchFlagNewStack
 *														� sysAppLaunchFlagNewGlobals 
 *
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 2/1/95
 *
 *  BY: Ron Marianetti
 *
 *******************************************************************************
 *
 * IMPORTANT!!!!: When launching an app as a separate task, the cmdPBP parameter 
 *		must be allocated as a memory chunk by the caller !! It will be deleted 
 *		for the caller when the application being launched finally quits.
 *
 *************************************************************/
// Function types
typedef Long (*AppEntryPtr)();

Err SysAppLaunch(UInt cardNo, LocalID dbID, UInt launchFlags,
					Word cmd, Ptr cmdPBP, DWord* resultP)
{

#if EMULATION_LEVEL != EMULATION_NONE
	SysAppInfoPtr appInfoP = 0;
	SysAppInfoPtr oldAppInfoP = 0;
	SysAppInfoPtr unusedAppInfoP;
	Err			  err;
	
	
	// Make sure no private flags have been set in the launchFlags
	ErrNonFatalDisplayIf(launchFlags & sysAppLaunchFlagPrivateSet, 
		"Invalid flags passed to SysAppLaunch");
		
	// Clear invalid flags
	launchFlags &= (~sysAppLaunchFlagPrivateSet);

	if (launchFlags & (sysAppLaunchFlagNewThread |
							 sysAppLaunchFlagNewStack |
							 sysAppLaunchFlagNewGlobals |
							 sysAppLaunchFlagUIApp)) {
		ErrDisplay("App launching not supported under emulation mode");
		return sysErrParamErr;
		}
		
	// Allocate an appInfo structure for this app. This structure holds
	//  application specific information like the database handle of the app,
	//  the main code handler, the owner ID, etc.
	appInfoP = MemChunkNew(0, sizeof(SysAppInfoType), memNewChunkFlagNonMovable);
	if (!appInfoP) {
		err = memErrNotEnoughSpace;
		goto Exit;
		}
	oldAppInfoP = SysGetAppInfo(&unusedAppInfoP, &unusedAppInfoP);
	MemMove(appInfoP, oldAppInfoP, sizeof(SysAppInfoType));
	
	if (!appInfoP->rootP)
		appInfoP->rootP = oldAppInfoP;
	
	(SysAppInfoPtr)GCurUIAppInfoP = appInfoP;
	
	// Call PilotMain with selector code
	*resultP = PilotMain(cmd, cmdPBP, launchFlags | sysAppLaunchFlagSubCall);
	
	
	(SysAppInfoPtr)GCurUIAppInfoP = oldAppInfoP;
	
	// Dispose of the appInfo block
	MemPtrFree(appInfoP);

Exit:
	return 0;
	
#else 

	AppEntryPtr				codeP;
	Ptr						stackP = 0;
	
	SysAppPrefsPtr*		prefsH=0;
	SysAppPrefsPtr			prefsP;
	SysAppPrefsType		defPrefs;
	
	ULong						creator;
	ULong						taskID=0;
	Err						err;
	SysTCBUserInfoPtr		tcbUserP=0;
	SysAppInfoPtr			appInfoP = 0;
	SysAppInfoPtr			rootAppInfoP, curAppInfoP;
	Ptr						tempDmAccessP;
	SysAppInfoPtr			saveA5InfoP;
	
	
	
	// Make sure no private flags have been set in the launchFlags
	ErrNonFatalDisplayIf(launchFlags & sysAppLaunchFlagPrivateSet, 
		"Invalid flags passed to SysAppLaunch");
	// Clear invalid flags
	launchFlags &= (~sysAppLaunchFlagPrivateSet);


//  *** These lines removed from publicly available sources, due to license restrictions...
//  *** 
//  *** 


	curAppInfoP = SysGetAppInfo(&rootAppInfoP, &appInfoP);
	
	// Allocate an appInfo structure for this app. This structure holds
	//  application specific information like the database handle of the app,
	//  the main code handler, the owner ID, etc.
	appInfoP = MemChunkNew(0, sizeof(SysAppInfoType), memNewChunkFlagNonMovable);
	if (!appInfoP) {
		err = memErrNotEnoughSpace;
		goto Exit;
		}
	MemSet(appInfoP, sizeof(SysAppInfoType), 0);
	
	
	// Put the cmd, cmdPBP, and launch flags in the appInfo for access by
	//  the app startup code
	appInfoP->cmd = cmd;
	appInfoP->cmdPBP = cmdPBP;
	appInfoP->launchFlags = launchFlags;
	
	// Put in pre-opened system databases into the DmAccess List
	//<RM> 1-14-98 
	// was: appInfoP->dmAccessP = rootAppInfoP->dmAccessP;
	appInfoP->dmAccessP = ((SysAppInfoPtr)GSysAppInfoP)->dmAccessP;
	
	
	// Find a free owner ID and store that in the appInfo structure. If we're launching
	//  AMX (the first time this routine is called) taskID will be nil and we'll
	//  use an owner ID of 0
	taskID = SysTaskID();
	if (taskID && (launchFlags & sysAppLaunchFlagNewGlobals)) {
		appInfoP->memOwnerID = SysNewOwnerID();
		if (!appInfoP->memOwnerID) { err = sysErrOutOfOwnerIDs; goto Exit;}
		}
	else
		appInfoP->memOwnerID = rootAppInfoP->memOwnerID;
	appInfoP->taskID = taskID;
		

	// Open up the database and get the creator ID
	appInfoP->dbP = (Ptr)DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
	if (!appInfoP->dbP) {
		err = DmGetLastErr();
		goto Exit;
		}
	DmDatabaseInfo(cardNo, dbID, 0,
			0, 0, 0,
			0, 0,
			0, 0,
			0, 0,
			&creator);
			
	// If this is the database of the currently running application, we set the
	//  sysAppLaunchFlagSubCall flag in the launch flags which indicates that
	//  we can keep the A5 world valid
	if (!(launchFlags & sysAppLaunchFlagNewGlobals)) {
		LocalID curAppDBID;
		UInt curAppCardNo;
		
		// Get the cardNo and dbID of the currently running app and if it matches,
		//  set the sysAppLaunchFlagSubCall bit in the launch flags.
		if (rootAppInfoP != NULL && rootAppInfoP->dbP) {
			err = DmOpenDatabaseInfo(rootAppInfoP->dbP, &curAppDBID, 0, 0, &curAppCardNo, 0);
			if (!err && curAppDBID == dbID && curAppCardNo == cardNo) {
				launchFlags |= sysAppLaunchFlagSubCall;
				appInfoP->launchFlags |= sysAppLaunchFlagSubCall;
				}
			}
		}
			
			
	// Get the PREF #0 resource which contains the application preferences
	prefsP = &defPrefs;
	prefsH = DmGet1Resource(sysResTAppPrefs, 0);
	if (prefsH) {
		MemMove(prefsP, MemHandleLock(prefsH), sizeof(SysAppPrefsType));
		MemHandleUnlock(prefsH);
		DmReleaseResource(prefsH);
		}
	else {
		prefsP->priority = 30;
		prefsP->stackSize = 0xD00;
		prefsP->minHeapSpace = 0x1000;
		}
	if (!(launchFlags & sysAppLaunchFlagNewStack)) 
		prefsP->stackSize = 0;
		
		
		
	// Allocate space for the stack if specified
	if (prefsP->stackSize) {
		// Make sure all old apps have a stack size large enough to receive IR transmissions.
		if (launchFlags & sysAppLaunchFlagUIApp &&
			prefsP->stackSize < 0xD00)
			prefsP->stackSize = 0xD00;
		
		appInfoP->stackP = stackP = MemChunkNew(0, prefsP->stackSize, memNewChunkFlagNonMovable);
		if (!appInfoP->stackP) {
			err = memErrNotEnoughSpace;
			goto Exit;
			}
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		MemSet(stackP, prefsP->stackSize, 0xFE);
#endif
		appInfoP->stackEndP = stackP + prefsP->stackSize - 1;
		*appInfoP->stackEndP = 0xFE;
		}
		
		
	
	
	//-----------------------------------------------------------------
	// Normally, we get the code resource of the new app, lock it down
	//  and jump to it. 
	//-----------------------------------------------------------------
	if (!(launchFlags & sysAppLaunchFlagSubCall)) {
		// Get the pointer to the entry point of code #1 resource
		appInfoP->codeH = DmGet1Resource(sysResTAppCode, 1);
		if (!appInfoP->codeH) {
			err = DmGetLastErr();
			goto Exit;
			}
		else 
			codeP = (AppEntryPtr)((Ptr)MemHandleLock(appInfoP->codeH));
		}
				
	// For Subcalls, copy database info from the app's current appInfoP
	// In subcall cases, we don't need another open copy of the executable
	//  so we close that and copy the dmAccess list and the dbP
	//  from the app's current appInfoP. SysAppExit() is smart enough
	//  to NOT close databases when it sees the SubCall launch flag.
	else {
		DmCloseDatabase(appInfoP->dbP);
		appInfoP->dbP = rootAppInfoP->dbP;		
		appInfoP->codeH = rootAppInfoP->codeH;

		codeP = (AppEntryPtr)((Ptr)MemHandleLock(appInfoP->codeH));
		MemPtrUnlock(codeP);
		}
	
	
	
	
	//-----------------------------------------------------------------
	// Set up the open database list appropriately. If this is an 
	//  action code call (like a subroutine call), indicated
	//  by no globals, then the action code app gets the current
	//  database list. Otherwise, it simply gets the generic
	//  system list but with the new apps database moved into it. 
	// <RM> 1-26-98
	//-----------------------------------------------------------------
	if (launchFlags & sysAppLaunchFlagNewGlobals)
		DmMoveOpenDBContext((DmAccessPtr*)(&appInfoP->dmAccessP), 
					(DmAccessPtr)appInfoP->dbP);
	else
		appInfoP->dmAccessP = curAppInfoP->dmAccessP;
	
	
	
	//  *** This section removed from publicly available sources, due to license restrictions...
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	//  ***
	
	
	
	//=============================================================
	// Else, just call the app like a subroutine call, but substituting 
	//  new stack pointer if specified.
	//=============================================================
	else {
		DWord		oldA5;
		Ptr			rootA5;
		SysAppInfoPtr oldAppInfoP;
	
		// It's possible that AMX isn't launched yet, so we must use 
		//  the low memory global SysAMXAppInfoP to pass the appInfo
		//  pointer to AMX since the TCB structure is not available.
		if (taskID) {
		
			tcbUserP = SysTaskUserInfoPtr(taskID);

			// Use the TCB User info structure to hold the pointer to the 
			//  appInfo structure temporarily, until the app's startup code
			//  runs and retrieves it.
			tcbUserP->tmpAppInfoP = appInfoP;
			
			// Set up the root pointer since this isn't the first call for the thread.
			if (!(launchFlags & sysAppLaunchFlagUIApp)) {
				oldAppInfoP = PrvGetAppInfo();
				if (oldAppInfoP->rootP == NULL)
					appInfoP->rootP = oldAppInfoP;
				else
					appInfoP->rootP = oldAppInfoP->rootP;
				}
			}
			
		// If launching amx, save the pointer to the AMX appinfo structure in
		//  a low memory global specially reserved for it.
		else
			{
			// A lot of code uses GSysAppInfoP to get to the system's DB access list.
			// Most of this runs as the AMX task.  Make sure this code still get's the
			// correct DB access list.
			GSysAMXAppInfoP = (Ptr)appInfoP;
			GSysAppInfoP = GSysAMXAppInfoP;
			}
		
		
		//---------------------------------------------------------
		// Set up the segment register
		//---------------------------------------------------------
		oldA5 = SysSetA5(0);
		if (launchFlags & sysAppLaunchFlagSubCall)
			{
			// Since we're going back to a running app, set A5 to it's old A5.
			// <RM> 1-14-98
			rootA5 = appInfoP->rootP->a5Ptr;		// This is setup by SysAppStartup()
			ErrFatalDisplayIf(!rootA5, "nil A5 world in root app!");
			
			// The app being launched is already running.  Reuse the root's A5
			// so that the subcalled app can use the global variables setup
			// by the root app. But, point the old A5 to the new appInfoP
			// because we might need it for cases where there is a new stack,etc.
			saveA5InfoP = *(SysAppInfoPtr*)rootA5;
			*(SysAppInfoPtr*)rootA5 = appInfoP;		
			SysSetA5((DWord) rootA5);			
			}
		else
			// (A5 & 0x7fffffff)[0] must point to the appInfo.  Use the copy on the stack.
			SysSetA5((DWord) PrvProtectSegmentRegister(&appInfoP));
		
			
			
		//---------------------------------------------------------
		// Call the App.
		//---------------------------------------------------------
		if (stackP) {
			*resultP = PrvCallWithNewStack(codeP, stackP+prefsP->stackSize);
			MemPtrFree(stackP);
			}
		else
			*resultP = PrvCallSafely(codeP);  // make sure our registers are restored
			
			
			
		//---------------------------------------------------------
		// Clean up subcalled apps.  Note that the SysAppInfoType structure for a 
		// subcalled app is referenced only by this routine.  That is why this cleanup
		// must be done here.
		//---------------------------------------------------------
		if (launchFlags & sysAppLaunchFlagSubCall) {
			// <RM> 1-14-98 
			// Restore the appInfoP pointed to by A5
			*(SysAppInfoPtr*)rootA5 = saveA5InfoP;
			}
			
		//---------------------------------------------------------
		// Clean up action code apps (no globals). In case the action
		//  code app opened or closed databases, mirror the new
		//  dmAccessList into the current app info.
		//---------------------------------------------------------
		if ( !(launchFlags & sysAppLaunchFlagNewGlobals)) 
			curAppInfoP->dmAccessP = appInfoP->dmAccessP;
			

		//---------------------------------------------------------
		// Free up the appInfo now
		// <RM> 1-26-98 
		//---------------------------------------------------------
		MemPtrFree(appInfoP);

	
		// Restore the A5 value of the caller.
		SysSetA5(oldA5);
		
		// clear err out 	
		err = 0;
		}
		
		
		
	//==================================================================
	// We only get here if an error occurred, or if we're returning from a 
	//  nested launch. If there was no error, the app structures will have been
	//  freed by SysAppExit which is called by the app after it quits.
	//==================================================================
Exit:

	if (err) {



			
	
		// Relese chunks already allocated and stored in the appInfo 
		if (appInfoP) {
			
			// Unlock the code resource and release it
			if (appInfoP->codeH) {	
				MemHandleUnlock(appInfoP->codeH);
				DmReleaseResource(appInfoP->codeH);
				}
				
			// Free the stack chunk
			if (appInfoP->stackP) MemPtrFree(appInfoP->stackP);
			
			// Close the application database
			if (appInfoP->dbP) DmCloseDatabase(appInfoP->dbP);
	
			// Dispose of the appInfo block
			MemPtrFree(appInfoP);
			}
		}
		
	return err;
	
#endif //EMULATION_LEVEL != EMULATION_NONE
}


/************************************************************
 *
 *  FUNCTION: SysAppStartup
 *
 *  DESCRIPTION: This is the routine called by application's startup
 *		code. It sets up the globals for an application and returns
 *		the command line arguments, if any.
 *
 *   The structure of an application is as follows:
 *
 *		The entry point to the application is the 4th byte of the
 *		CODE #1 resource.
 *
 *		The first long word of CODE #0 is the number of bytes to reserve
 *		above A5
 *
 *		The second long word of CODE #0 is the number of bytes to reserve
 *		below A5
 *
 *		DATA #0 contains a compressed version of the initialized application
 *		globals.
 *
 *		The argc and argv for the app have been stuffed into the user fields
 *		of the TCB for the current task by SysAppLaunch.
 *
 *  PARAMETERS: ptr to return argc, argv
 *
 *  RETURNS: previous A5 in *oldA5P, pointer to allocated globals in *globalsP.
 *			0 if no error
 *
 *  CREATED: 2/1/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err SysAppStartup(SysAppInfoPtr* appInfoPP, Ptr* prevGlobalsPtrP, 
							Ptr* globalsPtrP)
{
	Handle			codeH;
	DWordPtr			sizeP;
	DWord				above, below;
	Ptr				globalsP;
	
	CharPtr			cP;
	Handle			dataH;
	Ptr				globalRegP;
	
	SysTCBUserInfoPtr	tcbUserP=0;
	ULong				taskID;
	SysAppInfoPtr	appInfoP;
	
	UInt				launchFlags;
	char *			codeP=0;		// important to clear this!
	char *			dataP;
	char *			endOfDataP;
	
	
	// Return the appInfo for this app by retreiving it out of the TCB for the task.
	// SysAppLaunch uses the field tmpAppInfoP of this structure as a convenient
	// temporary holding space for the pointer
	taskID = SysTaskID();
	if (taskID) {
		tcbUserP = SysTaskUserInfoPtr(taskID);
		*appInfoPP = appInfoP = tcbUserP->tmpAppInfoP;
		launchFlags = appInfoP->launchFlags;
		
		// If we need new globals, initialize A5 to temporarily point
		// to our appInfoP on the stack so that Database calls can find
		//  the list of open databases
		// <RM> 1-14-98
		// WAS: if (launchFlags & sysAppLaunchFlagNewThread)
		//			SysSetA5(tcbUserP->initialA5);
		if (launchFlags & sysAppLaunchFlagNewGlobals)
			SysSetA5((DWord)PrvProtectSegmentRegister(&appInfoP));
		}
	// The only time this happens is when we're launching AMX....
	else {
		*appInfoPP = appInfoP = (SysAppInfoPtr)GSysAMXAppInfoP;
		launchFlags = appInfoP->launchFlags;
		}
	
	ErrNonFatalDisplayIf(appInfoP == NULL, "NULL appInfoP");
	
	
	// If we need to create an A5 world.....
	if (launchFlags & sysAppLaunchFlagNewGlobals) {
	

		// Get the CODE #0 resource
		codeH = DmGet1Resource(sysResTAppCode, 0);
		
		// Did we find the CODE #0 resource?
		if (codeH) {

			// the first 2 long words are the # of bytes needed above A5 and below A5
			sizeP = (DWordPtr)MemHandleLock(codeH);
			above = sizeP[0];
			below = sizeP[1];
			
			// Release the CODE=0 resource
			MemPtrUnlock(sizeP);
			DmReleaseResource(codeH);
			}

		// No CODE #0 resource was found - no biggie!
		else {
		
			// Just allocate enough globals space for appInfoP
			above = 4;
			below = 0;
			}

		
		// Allocate space for globals  
		globalsP = (Ptr)MemChunkNew(0, above + below, memNewChunkFlagNonMovable);
		if (!globalsP) return memErrNotEnoughSpace;
		*globalsPtrP = globalsP;
		
		
		// Save ptr to globals chunk in AppInfo for identifcation by the Debugger
		//  when doing a heap dump
		appInfoP->globalsChunkP = globalsP;
		appInfoP->globalEndP = globalsP + (above + below - 1);
		
		
		// Clear the globals
		cP = (CharPtr)globalsP;
		MemSet(cP, above+below, 0);
			
		// Create pointer to globals
		globalRegP = globalsP + below;


		// Store the appInfo structure pointer at 0(A5) for quick
		//  access by the Memory Manager when setting owner id's.
		*((SysAppInfoPtr*)globalRegP) = appInfoP;


		// Set A5 to point to the new globals world
		*prevGlobalsPtrP = (Ptr)SysSetA5((DWord)globalRegP);
		
		
		// Store the value of A5 in the sysAppInfoType. This is used by SysAppLaunch
		//  when it detects that an app that already has a globals world
		// is being called again due to an action code and we need to set it's A5
		//  up appropriately. We can't use the current A5 at the time because it
		//  might be the fake A5 of another app's action code context. 
		appInfoP->a5Ptr = globalRegP;
		
		// Get the DATA #0 resource
		dataH = DmGet1Resource(sysResTAppGData, 0);

		// Did we find the DATA #0 resource?  If not, don't sweat it!
		if (dataH) {

			// Lock it down and calculate the end
			dataP = MemHandleLock(dataH);
			endOfDataP = dataP + MemPtrSize(dataP);
			
			// DATA resource looks like this:
			// +---------------------------------+
			// | long:   offset of CODE 1 xrefs  |---+
			// +---------------------------------+   |
			// | char[]: compressed init data    |   |
			// +---------------------------------+   |
			// | char[]: compressed DATA 0 xrefs |   |
			// +---------------------------------+   |
			// | char[]: compressed CODE 1 xrefs |<--+
			// +---------------------------------+

			// Get the initialized data and decompress it
			// [skip first long of data 0 (unneeded offset)]
			dataP = PrvDecompressData(dataP+4, globalRegP);

			// dataP now points to DATA 0 xrefs

			// It's probably worth noting that the usual Metrowerks startup code (Startup.c) calls
			//  __relocate__ which in turn calls __reloc_compr__ (PrvRelocateData).  So far, I've
			// only seen code snippets that require the first two calls (below) to PrvRelocateData.

			// NOTE: Since at least one third-party build environment (Pila) only includes
			// the compressed init data in their DATA 0 resource, we only perform the
			// relocation if we haven't yet hit the end of the DATA 0 resource.

			if (dataP < endOfDataP) {

				// Get the CODE #1 resource (for xrefs)
				codeP = MemHandleLock(appInfoP->codeH);

				// Relocate DATA segment references to DATA segment
				dataP = PrvRelocateData(dataP, globalRegP, (long) globalRegP);

				// Relocate DATA segment references to CODE segment 1
				if (dataP < endOfDataP) {
					dataP = PrvRelocateData(dataP, globalRegP, (long) codeP);
					}
				}

			// We shouldn't really have to do the remaining relocations because:
			//		(A) Pilot code lives in a single segment (there's no segment loader)
			//		(B) Data references from code segment 1 are via A5
			//		(C) Code segment 1 references from code segment 1 are PC-relative
			//		(D) The last relocate is redundant
			//
			// It might be worth checking with Metrowerks to see if there's any reason any
			// of these four blocks would actually be used in a Pilot application build.
			// Remember that Emulator apps use MW's startup code, NOT this code.

#if 0		// Don't need this (at this time).  See comments immediately above.

			// Relocate DATA segment references to same CODE segment
			if (dataP < endOfDataP) {
				dataP = PrvRelocateData(dataP, globalRegP, (long) globalRegP);

				// Relocate CODE segment 1 references to DATA segment
				if (dataP < endOfDataP) {
					dataP = PrvRelocateData(dataP, codeP, (long) globalRegP);

					// Relocate CODE segment 1 references to CODE segment 1
					if (dataP < endOfDataP) {
						dataP = PrvRelocateData(dataP, codeP, (long) codeP);
					}

					// Relocate CODE segment 1 references to same CODE segment
					if (dataP < endOfDataP) {
						PrvRelocateData(dataP, codeP, (long) codeP);
						}
					}
				}
#endif

			MemHandleUnlock(dataH);
			DmReleaseResource(dataH);

			// Unlock the CODE #1 resource -- Don't panic, we were CALLED by CODE #1.
			// SysAppLaunch locked it before calling it.  This was a secondary lock to
			// get a dereferenced pointer to appInfoP->codeH.

			// NOTE: We only Unlock this if we actually locked it (for DATA 0 xrefs)
			if (codeP) MemPtrUnlock(codeP);

			}	// end if (dataH)

		// Flag that the data has been relocated
		// (or at least that our new 2.0 SysAppStartup code has executed)
		appInfoP->launchFlags |= sysAppLaunchFlagDataRelocated;


		// If this is a UI app, reset the UI state.
		if (launchFlags & sysAppLaunchFlagUIApp) {
			UIReset();
			}

		}	// end if (launchFlags & sysAppLaunchFlagNewGlobals)

	
	// Return to caller
	return 0;
}



/************************************************************
 *
 *  FUNCTION: SysAppExit
 *
 *  DESCRIPTION: This is the routine called by application's startup
 *		code after an app launched in a separate thread exits.
 *
 *		If we're exiting from an App that was launched as a nested launch,
 *		we unlock the code segment, release the code segment, close the
 *		application database, and return. The SysAppLaunch routine will
 *		dispose of the stack chunk after we return. The caller who launched
 *		the app as a nested launch is responsible for disposing the command
 *		parameter block.
 *
 *		If we're exiting from an App on it's own thread, there's no one to
 *		return to so this routine will dispose of the stack chunk
 *		and the rootCmdPB block and delete the task from AMX. AMX will not 
 *		return from the SysTaskDelete call - it will contine on some other thread
 *		as soon as this thread is deleted.
 *
 *  PARAMETERS: result code
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err SysAppExit(SysAppInfoPtr appInfoP, Ptr prevGlobalsP, Ptr globalsP)
{
	Err					err;
	DWord					ownerBit;
	Long					taskID;
	DmOpenRef			dbP, nextDBP;
	UInt					mode, openCount;
	
	
	// Go through and dispose of any memory chunks allocated by this application.
	//  The call to MemHeapFreeByOwnerID also compacts the heap
	if (appInfoP->memOwnerID && appInfoP->rootP == NULL) {
		MemHeapFreeByOwnerID(0, appInfoP->memOwnerID);

		// Return this owner ID to the free pool
		ownerBit = 1 << appInfoP->memOwnerID;
		GSysOwnerIDsInUse &= ~ownerBit;
		}
		
		
	// If this was not a sub-launch (a running app being called 
	//  due to a nested action code), close all opened database. For sub-launches,
	//  the app gets a copy of it's already opened database when it's called.
	if (! (appInfoP->launchFlags & sysAppLaunchFlagSubCall)) {

		// Free up allocated memory chunks for running this app
		if (appInfoP->codeH) {
			MemHandleUnlock(appInfoP->codeH);
			DmReleaseResource(appInfoP->codeH);
			}
		
		// Close the application's resource database.
		if (appInfoP->dbP)
			DmCloseDatabase(appInfoP->dbP);
			
			
		// If this app had it's own A5 world, Go through and close all databases
		//  left open by the application.
		if (appInfoP->launchFlags & sysAppLaunchFlagNewGlobals) {
			dbP = DmNextOpenDatabase(0);
			while(dbP) {
				nextDBP = DmNextOpenDatabase(dbP);
				err = DmOpenDatabaseInfo(dbP, 0,
											&openCount, &mode, 0, 0);
				if (!err && !(mode & dmModeLeaveOpen)) {
					while(openCount--) DmCloseDatabase(dbP);
					}
				dbP = nextDBP;
				}
				
				
			// If this app wanted any databases left open, include them in the
			//   system list
			dbP = DmNextOpenDatabase(0);
			if (dbP) ((SysAppInfoPtr)GSysAppInfoP)->dmAccessP = (Ptr)dbP;
			}
		}


	// Free the globals chunk (if allocated) and restore A5
	if (appInfoP->launchFlags & sysAppLaunchFlagNewGlobals) {
		MemPtrFree(globalsP);
		SysSetA5((DWord)prevGlobalsP);
		}
	
	
//  *** These lines removed from publicly available sources, due to license restrictions...
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  *** 
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
//  ***
			
			
	// Just return to SysAppLaunch.	
	// SysAppLaunch will free the appInfo for us. 
	else 	{
		#if EMULATION_LEVEL != EMULATION_NONE
		(SysAppInfoPtr)GCurUIAppInfoP = appInfoP->rootP;
		#endif
		}
	
	return 0;
}




/************************************************************
 *
 *  FUNCTION: SysNewOwnerID
 *
 *  DESCRIPTION: Returns a new owner ID for use by an application
 *   This owner ID gets placed into all Memory chunks allocated by 
 *		the application.
 *
 *  PARAMETERS: void
 *
 *  CALLED BY: SysAppStartup when allocating globals for the app
 *
 *  RETURNS: 0 if no more owner IDs available
 *
 *  CREATED: 4/5/96
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
UInt		SysNewOwnerID(void)
{
	DWord		bits;
	UInt		owner;
	
	bits = GSysOwnerIDsInUse;
	
	// Find a clear bit starting from bit 1
	owner = 1;
	bits >>= 1;
	
	// Owner IDs can be from 1 to 15
	for (owner=1; owner<=15; owner++) {
		if (!(bits & 0x01)) {
			GSysOwnerIDsInUse |= (1L << owner);
			return owner;
			}
		bits >>= 1;
		}
		
	// If we fell out, no more
	ErrFatalDisplayIf(1, "No More Owner IDs");
	return 0;
}




/************************************************************
 *
 *  FUNCTION: SysSetA5
 *
 *  DESCRIPTION: This routine sets the value of A5
 *
 *  PARAMETERS: result code
 *
 *  RETURNS: previous value of A5
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
asm DWord SysSetA5(DWord newValue)
{
	fralloc +									// setup stack frame
	MOVE.L	A5, D0							// get old value
	MOVE.L	newValue, A5					// set new value
	frfree										// clean up stack frame
	RTS
}



/************************************************************
 *
 *  FUNCTION: SysLibInstall
 *
 *  DESCRIPTION: Installs a library into the Library table
 *			and calls the librarie's install entry point.
 *
 *  PARAMETERS: 
 *			libraryP - pointer to library 
 *			*refNumP - return refNum of library
 *
 *  CALLED BY: Applications that need to install a library
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	SysLibInstall(SysLibEntryProcPtr libraryP, UIntPtr refNumP)
{
	UInt						refNum;
	Err						err;
	SysLibTblEntryPtr		entryP;
	SysLibTblEntryPtr		tableP;
	ULong						reqSize;
	Ptr						oldTableP;
	
	
	// Get pointer to library table
	tableP = (SysLibTblEntryPtr)GSysLibTableP;
	
	// Init return refNum
	*refNumP = sysInvalidRefNum;								// vmk 8/16/96
		
	//-----------------------------------------------------------
	// If not table, allocate initial one
	//-----------------------------------------------------------
	if (!tableP) {
		tableP = MemPtrNew(sysDefaultLibraries * sizeof(SysLibTblEntryType));
		ErrFatalDisplayIf(!tableP, "Out of memory");
		if (!tableP) return memErrNotEnoughSpace;
		MemPtrSetOwner(tableP, 0);
		MemSet(tableP, sysDefaultLibraries * sizeof(SysLibTblEntryType), 0);
		GSysLibTableP = (Ptr)tableP;
		GSysLibTableEntries = sysDefaultLibraries;
		}
	
	// Look for a free entry, but don't use the refNum reserved
	//  for use by the debugger comm library.
	for (refNum=0; refNum<GSysLibTableEntries; refNum++) {
		if (refNum == sysDbgCommLibraryRefNum) continue;
		if (!tableP[refNum].dispatchTblP) break;
		}
		
		
	//-----------------------------------------------------------
	// If no free entries, resize the table
	//-----------------------------------------------------------
	if (refNum >= GSysLibTableEntries) {
		reqSize = (GSysLibTableEntries+1) * sizeof(SysLibTblEntryType);
		err = MemPtrResize(tableP, reqSize);
		
		// If we couldn't resize it, try and reallocate it
		if (err) {
			tableP = MemPtrNew(reqSize);
			ErrFatalDisplayIf(!tableP, "Can't grow library table");
			if (!tableP) return memErrNotEnoughSpace;
			MemSet(tableP, reqSize, 0);
			
			// Copy old table into new
			MemPtrSetOwner(tableP, 0);
			oldTableP = (Ptr)GSysLibTableP;
			MemMove(tableP, oldTableP, reqSize);
			
			// Free old table and change global to point to new one
			GSysLibTableP = (Ptr)tableP;
			MemPtrFree(oldTableP);
			}

		// Increment the table size and get new refNum
		GSysLibTableEntries++;
		refNum = GSysLibTableEntries-1;
		}
		

	//-----------------------------------------------------------
	// Call the library install procedure with a pointer to the
	//  Library entry in the table
	//-----------------------------------------------------------
	*refNumP = refNum;
	entryP = &(tableP[refNum]);
	entryP->dispatchTblP = 0;				// init the new entry
	entryP->globalsP = 0;
	//entryP->cardNo = 0;
	entryP->dbID = 0;
	entryP->codeRscH = 0;
	err = (*libraryP)(refNum, entryP);	// the install procedure will install
													// its dispatch table
	
	// return error code
	return err;
}



/************************************************************
 *
 *  FUNCTION: SysLibLoad
 *
 *  DESCRIPTION:	A utility routine to load a library given its database
 *						creator and type.  After the appliaction is done with the
 *						library which was succesfully loaded via SysLibLoad, it
 *						is responsible for unloading the library by calling
 *						SysLibRemove and passing it the library reference number
 *						returned by SysLibLoad.
 *
 *						DOLATER...
 *							Presently, the "load" functionality is NOT supported for
 *							emulation mode.
 *
 *  PARAMETERS: 
 *			libType			-- type of library database
 *			libCreator		-- creator of library database
 *			refNumP			-- pointer to variable for returning the library
 *								   reference number(on failure, sysInvalidRefNum is
 *									returned in this variable)
 *
 *  CALLED BY: Applications that need to load a library
 *
 *  RETURNS:	0 if no error; otherwise: sysErrLibNotFound, sysErrNoFreeRAM,
 *					sysErrNoFreeLibSlots, or other error returned from the
 *					library's install entry point
 *
 *  COMMENTS:
 *		After the appliaction is done with the library which was SUCCESSFULLY
 *		loaded via SysLibLoad, it is responsible for unloading the library by
 *		calling SysLibRemove and passing it the library reference number
 *		returned by SysLibLoad.
 *
 *  CREATED: 8/22/96
 *
 *  BY: Vitaly Kruglikov
 *
 *		Name	Date		Description
 *		----	----		-----------
 *		vmk	8/27/96	Cleaned up the API and moved unload code to SysLibRemove
 *
 *************************************************************/
Err SysLibLoad(DWord libType, DWord libCreator, UIntPtr refNumP)
{
	Err						err = 0;
	VoidHand					codeRscH = 0;
	SysLibEntryProcPtr	codeRscP = 0;
	UInt						cardNo = 0;
	LocalID					dbID = 0;
	DmSearchStateType		searchState;
	DmOpenRef				dbR = 0;
	SysLibTblEntryPtr		entryP;
	Boolean					libInROM = false;


	ErrFatalDisplayIf(!refNumP, "null arg");
		
	
	// Init return values
	*refNumP = sysInvalidRefNum;
	
	
#if EMULATION_LEVEL != EMULATION_NONE

	// DOLATER... add emulation support here
	
	return( sysErrLibNotFound );
	
#endif	// EMULATION_LEVEL != EMULATION_NONE
	
	//
	// NATIVE IMPLEMENTATION
	//
	DmGetNextDatabaseByTypeCreator(true/*newSearch*/, &searchState,
			libType, libCreator, true/*onlyLatestVers*/, &cardNo, &dbID);
	if ( !dbID )
		return( sysErrLibNotFound );
	
	// Find out if database is in ROM
	libInROM = (MemLocalIDKind(dbID) != memIDHandle);
	
	// Open up this resource database
	dbR = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
	if ( !dbR )
		return( sysErrNoFreeRAM );
	
	// Get the library entry resource
	codeRscH = DmGet1Resource(sysResTLibrary, 0);
	if ( !codeRscH )
		{
		ErrNonFatalDisplayIf(true, "Can't get library rsrc"); 
		err = sysErrLibNotFound;
		}
	else
		{
		// Lock the library entry resource
		codeRscP = (SysLibEntryProcPtr)MemHandleLock(codeRscH);

		// Install the library
		err = SysLibInstall(codeRscP, refNumP);

		// Protect RAM-based library databases first so they don't get deleted.
		if ( !err && !libInROM)
			DmDatabaseProtect(cardNo, dbID, true);
		}
		
	// We can now close the database
	// (in ROM-based libraries, this call will free the master-pointer list)
	DmCloseDatabase(dbR);
	dbR = 0;
	
	if ( err )
		{
		*refNumP = sysInvalidRefNum;			// invalidate the library refNum
		
		#if EMULATION_LEVEL == EMULATION_NONE		
			// release the library resource
			if ( codeRscP && !libInROM)
				{
				MemPtrUnlock(codeRscP);
				DmReleaseResource(codeRscH);
				}
		#endif	// EMULATION_LEVEL == EMULATION_NONE		
		}
	else
		{
		entryP = SysLibTblEntry(*refNumP);
		//entryP->cardNo = cardNo;
		entryP->dbID = dbID;
		if ( libInROM )
			{
			// Clear the code resource handle so that we'll not attempt to unlock
			// ROM-based chunk which would cause fatal error because its master
			// pointer was freed when the library database was closed
			entryP->codeRscH = 0;	
			}
		else
			{
			// Save the code resource handle so that we can unlock and release
			// it in SysLibRemove
			entryP->codeRscH = codeRscH;
			}
		}

	return( err ); 
}



/************************************************************
 *
 *  FUNCTION: SysLibRemove
 *
 *  DESCRIPTION:	Unloads libraries which were installed via SysLibInstall
 *						or SysLibLoad.  Unlocks the library's coded resource and unprotects
 *						the library database(for libraries loaded via SysLibLoad only)
 *						and removes the library from the library table
 *
 *  WARNING!!! The caller MUST be sure the library is closed
 *  	before removing it!!!!!!
 *    This call WILL NOT CLOSE THE LIBRARY FOR THE CALLER.
 *
 *  PARAMETERS: 
 *			refNum - refNum of library
 *
 *  CALLED BY: Applications that need to uninstall a library
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/23/95
 *
 *  BY: Ron Marianetti
 *
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	8/27/96	Added code to remove libraries installed by SysLibLoad
 *
 *************************************************************/
Err	SysLibRemove(UInt refNum)
{
	SysLibTblEntryPtr		entryP;
	SysLibTblEntryPtr		tableP = (SysLibTblEntryPtr)GSysLibTableP;
	

	if ( refNum == sysInvalidRefNum )
		{
		ErrNonFatalDisplayIf(true, "invalid ref num");
		return( sysErrParamErr );
		}
	
	// Get a pointer to the library's entry in the library table
	entryP = &(tableP[refNum]);
	
	// Unlock the code resource and unprotect the library database for libraries
	// loaded via SysLibLoad
	if ( entryP->dbID )
		{
		#if EMULATION_LEVEL == EMULATION_NONE
			// Unlock and release the library resource and unprotect the
			// library database(only if it is in RAM)
			if ( entryP->codeRscH )
				{
				UInt cardNo;
				
				cardNo = MemHandleCardNo(entryP->codeRscH);
				MemHandleUnlock(entryP->codeRscH);
				DmReleaseResource(entryP->codeRscH);
				// Unprotect the database
				DmDatabaseProtect(cardNo, entryP->dbID, false);
				}
		#endif //EMULATION_LEVEL == EMULATION_NONE
				
		}
	
	
	// Clear the entry out of the library table
	entryP->dispatchTblP = 0;
	entryP->globalsP = 0;
	//entryP->cardNo = 0;
	entryP->dbID = 0;
	entryP->codeRscH = 0;

	// return error code
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysLibFind
 *
 *  DESCRIPTION: Locates a system library by name
 *
 *  PARAMETERS: 
 *			nameP		 - pointer to name of library
 *			*refNumP  - refNum of library is returned here
 *
 *  CALLED BY: Applications that need to get the refNum of a
 *		library
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err	SysLibFind(CharPtr nameP, UIntPtr refNumP)
{
	UInt						refNum;
	SysLibTblEntryPtr		entryP;
	CharPtr					libNameP;
	WordPtr					offsetP;
	BytePtr					bP;
	SysLibTblEntryPtr		tableP = (SysLibTblEntryPtr)GSysLibTableP;
	
	
	// Init return refNum
	*refNumP = sysInvalidRefNum;								// vmk 8/16/96

	// Look for a free entry
	entryP = &(tableP[0]);
	for (refNum=0; refNum<GSysLibTableEntries; refNum++, entryP++) {
		// Skip empty slots
		if (!entryP->dispatchTblP) continue;
		
		// Get the name pointer of this library
		bP = (BytePtr)entryP->dispatchTblP;
		offsetP = (WordPtr)bP;
		libNameP = (CharPtr)(bP + offsetP[0]);
		
		// See if it matches
		if (!StrCompare(nameP, libNameP)) {
			*refNumP = refNum;
			return 0;
			}
			
		}
		
	return sysErrLibNotFound;

}



/************************************************************
 *
 *  FUNCTION: SysLibTblEntry
 *
 *  DESCRIPTION: Gets pointer to libraries entry in the library
 *		table.
 *
 *  PARAMETERS: 
 *			refNum - refNum
 *
 *  CALLED BY: Libraries in order to get a pointer to their
 *		globals or when installing their dispatch table.
 *
 *  RETURNS: entry pointer, or 0 if unsuccessful
 *
 *  CREATED: 6/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
SysLibTblEntryPtr	SysLibTblEntry(UInt refNum)
{
	SysLibTblEntryPtr		entryP;
	SysLibTblEntryPtr		tableP = (SysLibTblEntryPtr)GSysLibTableP;
	
	entryP = &(tableP[refNum]);
	return entryP;
}



/************************************************************
 *
 *  FUNCTION: SysTaskID
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
ULong SysTaskID(void)
{
	return 0;
}
#endif

/************************************************************
 *
 *  FUNCTION: SysTaskDelay
 *
 *  DESCRIPTION: The native version of this routine is contained
 *		in the AMXGlue.c module
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
Err		SysTaskDelay(Long delay)
{
	return 0;
}
#endif
							


/************************************************************
 *
 *  FUNCTION: SysTaskCreate
 *
 *  DESCRIPTION: The native version of this routine is contained
 *		in the AMXGlue.c module
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
Err		SysTaskCreate(DWordPtr taskIDP, DWordPtr creator, ProcPtr codeP,
							Ptr stackP, DWord stackSize, DWord attr, DWord priority,
							DWord tSlice)
{
	return 0;
}
#endif

/************************************************************
 *
 *  FUNCTION: SysTaskDelete
 *
 *  DESCRIPTION: The native version of this routine is contained
 *		in the AMXGlue.c module
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
Err		SysTaskDelete(DWord taskID, DWord priority)
							
{
	return 0;
}
#endif


/************************************************************
 *
 *  FUNCTION: SysTaskTrigger
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysTaskTrigger(DWord taskID)
{
	return sysErrNotAllowed;
}


/************************************************************
 *
 *  FUNCTION: SysTaskUserInfoPtr
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: task ID
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
SysTCBUserInfoPtr	SysTaskUserInfoPtr(ULong taskID)
{
	return 0;
}



/************************************************************
 *
 *  FUNCTION: SysTaskSetTermProc
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: nil task ID
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysTaskSetTermProc(DWord taskID, SysTermProcPtr termProcP)
{
	return sysErrNotAllowed;
}



#if EMULATION_LEVEL == EMULATION_NONE
/************************************************************
 *
 *  FUNCTION: SysTimerCreate
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysTimerCreate(DWordPtr timerIDP, DWordPtr tagP, 
							SysTimerProcPtr timerProc, DWord periodicDelay,
							DWord	param)
{
	return 0;
}

/************************************************************
 *
 *  FUNCTION: SysTimerDelete
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysTimerDelete(DWord timerID)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysTimerWrite
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysTimerWrite(DWord timerID, DWord value)
{
	return 0;
}
#endif //EMULATION_LEVEL == EMULATION_NONE


/************************************************************
 *
 *  FUNCTION: SysSemaphoreCreate
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysSemaphoreCreate(DWordPtr smIDP, DWordPtr tagP, SDWord initValue)
{
	return 0;
}

/************************************************************
 *
 *  FUNCTION: SysSemaphoreDelete
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysSemaphoreDelete(DWord smID)
{
	return 0;
}

/************************************************************
 *
 *  FUNCTION: SysSemaphoreWait
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysSemaphoreWait(DWord smID, DWord priority, SDWord timeout)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysSemaphoreSignal
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysSemaphoreSignal(DWord smID)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysSemaphoreSet
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysSemaphoreSet(DWord smID)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysResSemaphoreCreate
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysResSemaphoreCreate(DWordPtr smIDP, DWordPtr tagP)
{
	return 0;
}

/************************************************************
 *
 *  FUNCTION: SysResSemaphoreDelete
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysResSemaphoreDelete(DWord smID)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysResSemaphoreReserve
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysResSemaphoreReserve(DWord smID, DWord priority, SDWord timeout)
{
	return 0;
}


/************************************************************
 *
 *  FUNCTION: SysResSemaphoreRelease
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: void
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 3/15/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysResSemaphoreRelease(DWord smID)
{
	return 0;
}






/************************************************************
 *
 *  FUNCTION: SysKernelInfo
 *
 *  DESCRIPTION: This stub gets replaced by AMX as soon as it loads
 *
 *  PARAMETERS: 
 *			paramP	- pointer to SysKernelInfoType param block
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 7/28/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		SysKernelInfo(VoidPtr	paramP)
{
	return sysErrParamErr;
}




/************************************************************
 *
 *  FUNCTION: TaskTerminationProc, private
 *
 *  DESCRIPTION: This routine gets installed as a termination procedure
 *		to every task. It is called by AMX when a task is deleted, killed,
 *		or stopped. 
 *
 *  PARAMETERS: task ID, reason for termination
 *
 *  RETURNS: void
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void TaskTerminationProc(ULong taskID, Long reason)
{
	
}





/************************************************************
 *
 *  FUNCTION: PrvCallSafely, private
 *
 *  DESCRIPTION: This routine calls the given procedure and
 *   ensures the registers are restored correctly afterwards
 *   (except for D0, D1, D2, A0 and A1)
 *
 *  PARAMETERS: address to jump to
 *
 *  RETURNS: result code from procedure call
 *
 *  CREATED: 1/28/98
 *
 *  BY: David Fedor
 *
 *************************************************************/
static asm Int PrvCallSafely(ProcPtr procP)
{
	// Setup stack frame
	fralloc +
	
	// Save registers for our caller's benefit, in case
	// the called app doesn't restore them when it quits.
	MOVEM.L   D3-D7/A2-A4, -(SP)

	MOVE.L	  procP, A0				// get the procedure ptr
	JSR		  (A0)					// call it

	MOVEM.L   (SP)+, D3-D7/A2-A4	// Restore the registers
	
	// Return to caller
	frfree
	RTS
}



/************************************************************
 *
 *  FUNCTION: PrvCallWithNewStack, private
 *
 *  DESCRIPTION: This routine calls the given procedure with
 *   the given stack pointer.
 *
 *  PARAMETERS: result code
 *
 *  RETURNS: result code from procedure call
 *
 *  CREATED: 2/1/95 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static asm Int PrvCallWithNewStack(ProcPtr procP,  Ptr newStack)
{
	// Setup stack frame
	fralloc +
	
	// Save registers for our caller's benefit, in case
	// the called app doesn't restore them when it quits.
	MOVEM.L   D3-D7/A2-A4, -(SP)
	
	// Push call parameters onto the new stack
	MOVE.L	procP, A1						// procedure ptr in A1
	MOVE.L	newStack, A0					// new stack pointer
	MOVE.L	SP, -(A0)						// save old stack pointer
	MOVE.L	A0, SP							// new stack pointer
	JSR		(A1)								// call procedure
	MOVE.L	(SP), SP							// restore old stack pointer
	
	// Restore the registers
	MOVEM.L   (SP)+, D3-D7/A2-A4
	
	// Return to caller
	frfree
	RTS
}





/************************************************************
 *
 *  FUNCTION: PrvDecompressData, private
 *
 *  DESCRIPTION: Copied from the CodeWarrior library sources.
 *		Decompresses image of an applications initilized global
 *		data.
 *		
 *
 *  PARAMETERS: ptr to compressed data, ptr to destination
 *
 *  CALLED BY: SysAppStartup
 *
 *  RETURNS: pointer to compressed DATA 0 xrefs
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
typedef union GetData {
	char	raw[4];
	short	word;
	long	lword;
}	GetData; 

//
//	Pack Patterns:
//
//	0x1xxx xxxx: <raw data>		x+1 (1..128)	raw data bytes
//	0x01xx xxxx:			x+1 (1..64)		<x> 0x00 data bytes
//	0x001x xxxx: yyyy yyyy		x+2 (2..33)		<x> <y> data bytes
//	0x0001 xxxx:			x+1 (1..16)		<x> 0xFF data bytes
//	0x0000 0001:			pattern: 0x00000000FFFFXXXX
//	0x0000 0010:			pattern: 0x00000000FFXXXXXX
//	0x0000 0011:			pattern: 0xA9F00000XXXX00XX
//	0x0000 0100:			pattern: 0xA9F000XXXXXX00XX
//	0x0000 0000:	end of data
//

static char * PrvDecompressData(char *ptr,char *datasegment)
{
	GetData		ldata;
	int			i,data;
	char		*to,c;
	

	for(i=0; i<3; i++)
	{
		ldata.raw[0]=*ptr++; ldata.raw[1]=*ptr++; ldata.raw[2]=*ptr++; ldata.raw[3]=*ptr++;
		to=datasegment+ldata.lword;
		while(1)
		{
			data=*ptr++;

			//	decompress (x&0x7f)+1 raw data bytes
			if(data&0x80) {	
				data&=0x7F; 
				do *to++=*ptr++;
					while(--data>=0); 
				continue;
				}
				
			//	decompress (x&0x3f)+1 0x00 data bytes
			//	data is already initilized to 0x00
			if(data&0x40) {	
				to+=(data&0x3F)+1; 
				continue;	
				}
				
			//	decompress (x&0x1f)+2 repeating data bytes
			if(data&0x20) {	
				data=(data&0x1F)+1; 
				c=*ptr++; 
				goto cloop;
				}
				
			//	decompress (x&0x0f)+1 0xFF data bytes
			if(data&0x10) {	
				data&=0x0F; c=0xFF;
cloop:			
				do *to++=c; 
					while(--data>=0); 
				continue;
				}
				
			switch(data) {
				case 0x00: break;
				case 0x01: to+=4; *to++=0xFF; *to++=0xFF; *to++=*ptr++; *to++=*ptr++; continue;
				case 0x02: to+=4; *to++=0xFF; *to++=*ptr++; *to++=*ptr++; *to++=*ptr++; continue;
				case 0x03: *to++=0xA9; *to++=0xF0; to+=2; *to++=*ptr++; *to++=*ptr++; to++; *to++=*ptr++; continue;
				case 0x04: *to++=0xA9; *to++=0xF0; to++; *to++=*ptr++; *to++=*ptr++; *to++=*ptr++; to++; *to++=*ptr++; continue;
				default:   DbgBreak(); break;
				}
			break;
			} // While (1)
			
		} // for (i=0; i<3; i++)

	return ptr;
}


/************************************************************
 *
 *  FUNCTION: PrvRelocateData, private
 *
 *  DESCRIPTION: Based on the CodeWarrior library sources.
 *		Relocate code/data references of a segment.
 *
 *  PARAMETERS: pointer to relocation data
 *					 pointer to segments base address
 *					 pointer to reloaction base address
 *
 *  CALLED BY: SysAppStartup
 *
 *  RETURNS: pointer to end of relocation data
 *
 *  CREATED: 10/7/96
 *
 *  BY: Steve Lemke
 *
 *************************************************************/
// Metrowerks calls this routine "__reloc_compr__"
static char * PrvRelocateData(char *ptr,char *segment,long relocbase)
{
	GetData	data;
	long	offset,relocations;
	char	c;

	data.raw[0]=*ptr++; data.raw[1]=*ptr++; data.raw[2]=*ptr++; data.raw[3]=*ptr++;
	relocations=data.lword;

	for(offset=0L; relocations>0; relocations--)
	{
		c=*ptr++;
		if(c&0x80)
		{	//	8-bit signed delta
			c<<=1; offset+=c;
		}
		else
		{
			data.raw[0]=c; data.raw[1]=*ptr++;
			if(c&0x40)
			{	//	15-bit unsigned delta
				
				offset+=(short)(data.word<<2)>>1;
			}
			else
			{	//	direct signed 31-bit offset
				data.raw[2]=*ptr++; data.raw[3]=*ptr++;
				offset=(data.lword<<2)>>1;
			}
		}
		*(long *)(segment+offset)+=relocbase;
	}
	return ptr;
}



#if EMULATION_LEVEL != EMULATION_NONE

/************************************************************
 *
 *  FUNCTION: SysCardImageInfo
 *
 *  DESCRIPTION: Returns info on memory card images used during
 *		Emulation mode
 *
 *  PARAMETERS: cardNumber, cardSize variable
 *
 *  RETURNS:
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Ptr SysCardImageInfo(UInt cardNo, ULongPtr sizeP)
{
	if (!PilotGlobalsP) {
		*sizeP = 0;
		return 0;
		}
		
	if (cardNo < GMemCardSlots) {
		*sizeP = memCardInfoP(cardNo)->size;
		return (Ptr)(memCardInfoP(cardNo)->baseP);
		}
		
	else {
		*sizeP = 0;
		return 0;
		}
}


/************************************************************
 *
 *  FUNCTION: SysCardDeleted
 *
 *  DESCRIPTION: Call to notify Pilot that memory card
 *		no longer exists
 *
 *  PARAMETERS: cardNumber, cardSize variable
 *
 *  RETURNS:
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void SysCardImageDeleted(UInt cardNo)
{
	if (cardNo >= GMemCardSlots) return;
	
	memCardInfoP(cardNo)->baseP = 0;
	memCardInfoP(cardNo)->size = 0;
	
	if (cardNo == 0) PilotGlobalsP = 0;
}

#endif  // EMULATION_LEVEL != EMULATION_NONE


/************************************************************
 *
 *  FUNCTION: SysSetTrapAddress
 *
 *  DESCRIPTION: Call to Set the address of a system trap
 *
 *  PARAMETERS: trap number, trap address
 *
 *  RETURNS: 0 if no err
 *
 *  CREATED: 2/22/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err SysSetTrapAddress(UInt trapNum, VoidPtr procP)
{
	trapNum -= sysTrapBase;
	
	if (trapNum >= sysNumTraps)
		return sysErrParamErr;
		
	GSysDispatchTableP[trapNum] = procP;

	// Bump rev of trap table to invalidate host debugger's cache.
	GSysDispatchTableRev++;

	return 0;
}



/************************************************************
 *
 *  FUNCTION: SysGetTrapAddress
 *
 *  DESCRIPTION: Call to Get the address of a system trap
 *
 *  PARAMETERS: trap number
 *
 *  RETURNS: Procedure ptr
 *
 *  CREATED: 2/22/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
VoidPtr SysGetTrapAddress(UInt trapNum)
{
	return GSysDispatchTableP[trapNum - sysTrapBase];
}




/************************************************************
 *
 *  FUNCTION: SysDisableInts
 *
 *  DESCRIPTION: Disables interrupts and returns saved status
 *		register that can be passed to SysRestoreInts.
 *
 *  PARAMETERS: void
 *
 *  RETURNS: previous status register
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Word asm SysDisableInts(void)
{
	MOVE.W	SR, D0
	ORI.W		#0x0700, SR				// Disable interrupts
	RTS
}


/************************************************************
 *
 *  FUNCTION: SysRestoreStatus
 *
 *  DESCRIPTION: Restores processor status register to passed 
 *   value
 *
 *  PARAMETERS: status register
 *
 *  RETURNS: void
 *
 *  CREATED: 3/23/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
void asm SysRestoreStatus(Word newSR)
{
	MOVE.W	4(SP), SR
	RTS
}



/************************************************************
 *
 *  FUNCTION: SysTranslateKernelErr
 *
 *  DESCRIPTION: Call to translate an error code from an
 *		AMX system call into a Pilot error code
 *
 *  PARAMETERS: AMX error code
 *
 *  RETURNS: Pilot error code
 *
 *  CREATED: 10/26/94 
 *
 *  BY: Ron Marianetti
 *
 *		vmk	11/13/96	Added sysErrDelayWakened mapping
 *
 *************************************************************/
Err SysTranslateKernelErr(Err err)
{
	switch(err) {
	
		// Task Errors
		case 0:		return 0;
		case -1: 	return sysErrParamErr;
		case -2:		return sysErrNoFreeResource;
		case -3:		return sysErrParamErr;
		case -4:		return sysErrNoFreeRAM;
		case -5:		return sysErrNotAllowed;
		case -6:		return sysErrNotAllowed;
		
		// Semaphore Errors
		case -30:	return sysErrInvalidID;
		case -31:	return sysErrNoFreeResource;
		case -32:	return sysErrNotAllowed;
		case -33:	return sysErrParamErr;
		case -34:	return sysErrNotAllowed;
		case -35:	return sysErrParamErr;
		
		
		// WARNINGS
		case 3:		return sysErrDelayWakened;
		case 4:		return sysErrTimeout;
		case 7:		return sysErrSemInUse;
		default:		return sysErrParamErr;
		}
	
	return sysErrParamErr;
}


/***********************************************************************
 *
 * FUNCTION:    SysCompareDataBaseCreators
 *
 * DESCRIPTION: Compare one database name to another (for sorting purposes).
 *
 * PARAMETERS:	 SysDBListItemType *a, *b - the items to compare
 *					 other - not used in the comparison
 *
 * RETURNED:	 if a < b return -1
 *					 if a==b return 0
 *					 if a > b return -1
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/5/96	Initial Revision
 *
 ***********************************************************************/
static Int SysCompareDataBaseCreators (void *a, void *b, Long other)
{
	return ((SysDBListItemType *)b)->creator - ((SysDBListItemType *)a)->creator;
}


/***********************************************************************
 *
 * FUNCTION:    SysCompareDataBaseNames
 *
 * DESCRIPTION: Compare one database name to another (for sorting purposes).
 *
 * PARAMETERS:	 SysDBListItemType *a, *b - the items to compare
 *					 other - not used in the comparison
 *
 * RETURNED:	 if a < b return -1
 *					 if a==b return 0
 *					 if a > b return -1
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/5/96	Initial Revision
 *
 ***********************************************************************/
static Int SysCompareDataBaseNames (void *a, void *b, Long other)
{
	return StrCompare(((SysDBListItemType *)a)->name, ((SysDBListItemType *)b)->name);
}


/************************************************************
 *
 *  FUNCTION: SysCreateDataBaseList
 *
 *  DESCRIPTION: Generate a list of databases found on the memory cards
 *  matching a specific type and return the result.  If lookupName is
 *  true then a name in a tAIN resource is used instead of the database's
 *  name and the list is sorted.  Only the last version of a database 
 *	 is returned.  Databases with multiple versions are listed only once.
 *
 *  PARAMETERS:	type - type of database to find (0 for wildcard)
 *						creator - creator of database to find (0 for wildcard)
 *						dbCount - pointer to contain count of matching databases
 *						dbIDs - pointer to handle allocated to contain the database list
 *						lookupName - use tAIN names and sort the list
 *
 *  RETURNS: dbCount is set to the number of matches
 *				 dbIDs is set to the list of matches
 *
 *  CREATED: 5/28/96
 *
 *  BY: Roger Flores
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/11/97	Fixed last database not using tAIN.
 *
 *************************************************************/
extern Boolean SysCreateDataBaseList(ULong type, ULong creator, 
	WordPtr dbCount, Handle *dbIDs, Boolean lookupName)
{
	Int						dbIndex;		// UInt results in a bug
	
	UInt 						cardNo;
	LocalID					dbID;
	DmOpenRef 				dbP;
	
	DmSearchStateType		searchState;
	Boolean					newSearch = true;
	UInt						maxItems = 16;
	
	SysDBListItemType		*dbListP;
	SysDBListItemType		*dbItemP;
	Err						err=0;
	Handle					ainH;
	
	
	
	// Allocate a minimum size LauncherdbInfoType array to hold
	//  list of dblication databases
	*dbIDs = MemHandleNew(maxItems * sizeof(SysDBListItemType));
	if (!*dbIDs) return false;
	dbListP = MemHandleLock(*dbIDs);

	
	// Create a list of matching databases.  We do not care about the order
	// or multiple versions yet.  The assumption is that there won't be many 
	// multiple versions.
	// �(n)
	dbIndex = 0;
	while (true) 
		{
		// Seach for the next panel
		err = DmGetNextDatabaseByTypeCreator(newSearch, &searchState, 
					type, creator, false, &cardNo, &dbID);
		if (err) break;
		newSearch = false;


		// See if we need to grow our dbList array
		if (dbIndex >= maxItems)
			{
			MemPtrUnlock(dbListP);
			dbListP = 0;
			maxItems += 4;
			err = MemHandleResize(*dbIDs, maxItems * sizeof(SysDBListItemType));
			dbListP = MemHandleLock(*dbIDs);
			if (err) 
				{
				maxItems -= 4;
				break;
				}
			}
			
						
		// Save the info on this db
		dbItemP = &dbListP[dbIndex];
		dbItemP->dbID = dbID;
		dbItemP->cardNo = cardNo;
		dbItemP->iconP = NULL;			// Filled in by LauncherDrawIcons
		
		
		// Get the creator and type of this panel and the version
		DmDatabaseInfo(cardNo, dbID, dbItemP->name, NULL, &dbItemP->version, 
			NULL, NULL, NULL, NULL, NULL, NULL, &dbItemP->type, &dbItemP->creator);
						
		dbIndex++;
		}
		

	// Sort the matches by creator.  This places different versions of apps 
	// next to each other while also ordering the list of apps.  We will
	// need to sort again using the name of the apps should be in a roughly
	// similiar order, especially if the first letter of the creator is the
	// same as the first letter of the app's name.
	// �(n log n)
	SysQSort (dbListP, dbIndex, sizeof(SysDBListItemType), SysCompareDataBaseCreators, 0);
	
	
	// Now look through the apps looking for multiple versions of an app,
	// discarding any earlier versions.  Ideally there will be at most
	// two versions of an app (one in ROM and one in RAM).  We work
	// backwards so that the MemMove moves only bytes already checked.
	// � (n)  (assuming few multiple versions).
	if (type && creator == 0)
		{
		dbItemP = &dbListP[dbIndex - 2];
		while (dbItemP >= dbListP)
			{
			// Same app?  If so remove the older version.
			if (dbItemP->creator == (dbItemP + 1)->creator)
				{
				// Use the first version if it's either newer or if it equal and RAM based.
				// Otherwise use the other one.
				if (dbItemP->version > (dbItemP + 1)->version ||
					 (dbItemP->version == (dbItemP + 1)->version &&
					  MemLocalIDKind(dbItemP->dbID) == memIDHandle))
					MemMove(dbItemP + 1, dbItemP + 2, (BytePtr) &dbListP[dbIndex] - (BytePtr) (dbItemP + 2));
				else
					MemMove(dbItemP, dbItemP + 1, (BytePtr) &dbListP[dbIndex] - (BytePtr) (dbItemP + 1));
				dbIndex--;		// There is one less database now.
				}
			dbItemP--;
			}
		}
	
	
	// If there aren't any databases then exit now without any to save unneccessary work.
	if (dbIndex == 0)
		{
		*dbCount = dbIndex;
		goto Exit;
		}		
	
	// We might want to shrink the database list to conserve memory.  Either
	// extra may have been allocated or item may have been removed if they
	// were duplicates.
	// � (1)
	if (dbIndex < maxItems) 
		{
		MemPtrUnlock(dbListP);
		dbListP = 0;
		err = MemHandleResize(*dbIDs, dbIndex * sizeof(SysDBListItemType));
		dbListP = MemHandleLock(*dbIDs);
		}
		
	
	// If the names were requested then look them up and sort by the names found.
	// � (n)   (assuming the records are mostly ordered already because the
	//          creator and name have the same first letter)
	if (lookupName)
		{
		dbItemP = &dbListP[dbIndex - 1];
		while (dbItemP >= dbListP)
			{
			// Find a name for this database	
			dbP = DmOpenDatabase(dbItemP->cardNo, dbItemP->dbID, dmModeReadOnly);
	
			if ((ainH = DmGet1Resource(ainRsc, ainID)) != 0)
				{
				StrCopy(dbItemP->name, MemHandleLock(ainH));
				MemHandleUnlock(ainH);
				DmReleaseResource(ainH);
				}
			
			DmCloseDatabase(dbP);
			dbItemP--;
			}
			
			
		// Sort the applications by their name.
		SysQSort (dbListP, dbIndex, sizeof(SysDBListItemType), SysCompareDataBaseNames, 0);
		}	
	
	
	// Record how many matches were found
	*dbCount = dbIndex;
	
Exit:
	if (dbListP)
		MemPtrUnlock(dbListP);
	
	// If nothing was found remove the memory allocated.	
	if (*dbCount == 0)
		{
		MemHandleFree(*dbIDs);
		return false;
		}
		
	return true;
}



/************************************************************
 *
 *  FUNCTION: SysCreatePanelList
 *
 *  DESCRIPTION: Generate a list of panels found on the memory cards
 *  and return the result.  Multiple versions of a panel are listed once.
 *
 *  PARAMETERS: panelCount - pointer to set to the number of panels
 *					 panelIDs - pointer to handle containing a list of panels
 *
 *  RETURNS: void
 *
 *  CREATED: 5/28/96
 *
 *  BY: Roger Flores
 *
 *************************************************************/
extern Boolean SysCreatePanelList(WordPtr panelCount, Handle *panelIDs)
{
	return SysCreateDataBaseList(sysFileTPanel, 0, panelCount, panelIDs, true);
}


/************************************************************
 *
 *  FUNCTION: SysGetOSVersionString
 *
 *  DESCRIPTION: Get a pointer to a string containing the OS version.
 *
 *  PARAMETERS: nothing
 *
 *  RETURNS: pointer to a string containing the OS version.  The
 *	caller must free the string using MemPtrFree().
 *
 *  CREATED: 11/13/97
 *
 *  BY: Roger Flores
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			SCL	2/13/98	Ifdef'd out "Pro" StrCat code (not needed for Rocky).
 *
 *************************************************************/
extern CharPtr SysGetOSVersionString()
{
	Handle resultH;
	CharPtr resultP = NULL;
	UInt resultLength;
	Handle strH;
	CharPtr strP;
#if USER_MODE == USER_MODE_DEMO
	Err err;
#endif
	//DWord value;
	
	
	// Copy base version name
	strH = DmGetResource(verRsc, systemVersionID);
	if (strH != NULL)
		{
		strP = MemHandleLock(strH);
		resultLength = StrLen(strP) + sizeofchar(nullChr);
		resultH = MemHandleNew(resultLength);
		if (resultH != NULL)
			{
			resultP = MemHandleLock(resultH);
			StrCopy(resultP, strP);
			MemHandleUnlock(strH);
			}
		DmReleaseResource(strH);
		}
	
	// Add additional feature strings, if necessary.
	// This routine was originally written with Personal vs. Pro in mind.
	// In 2.0, "Pro" meant that NetLib was present (hence FtrGet netFtrCreator).
	// In 3.0 (Rocky), there is no Personal vs. Pro.  However, future versions
	// may need to extend the OS Version String based on other build "differences".
	// This is where that should be done, after adding the appropriate string to
	// Resources:UI.rsrc and an equate for it in <UICommon.h>
#if 0
	if (resultP != NULL) {
		err = FtrGet(netFtrCreator, netFtrNumVersion, &value);
		if (!err) {
			strH = DmGetResource(strRsc, proStrID);
			if (strH != NULL) {
				strP = MemHandleLock(strH);
				// Only append this string if there's something there...
				if (*strP) {
					MemHandleUnlock(resultH);
					resultLength += sizeofchar(spaceChr) + StrLen(strP);
					err = MemHandleResize(resultH, resultLength);
					resultP = MemHandleLock(resultH);
					if (!err) {
						StrCat(resultP, " ");
						StrCat(resultP, strP);
						}
					}
				MemHandleUnlock(strH);
				DmReleaseResource(strH);
				}
			}
		}
#endif

	// Add "Demo" string, if we're doing a POP (Point of Purchase) build
#if USER_MODE == USER_MODE_DEMO
	if (resultP != NULL) {
		strH = DmGetResource(strRsc, demoStrID);
		if (strH != NULL) {
			strP = MemHandleLock(strH);
			// Only append this string if there's something there...
			if (*strP) {
				MemHandleUnlock(resultH);
				resultLength += sizeofchar(spaceChr) + StrLen(strP);
				err = MemHandleResize(resultH, resultLength);
				resultP = MemHandleLock(resultH);
				if (!err) {
					StrCat(resultP, " ");
					StrCat(resultP, strP);
					}
				}
			MemHandleUnlock(strH);
			DmReleaseResource(strH);
			}
		}
#endif

	return resultP;
}

/************************************************************
 *
 *  FUNCTION: SysUIBusy
 *
 *  DESCRIPTION: Set or return the System UI busy count. Various
 *				entities in the system can tie up the UI in ways that
 *				should not be interrupted. Anything that does so, should
 *				Set UI busy so that other entities know about this state.
 *
 *  PARAMETERS: set - true if the second paramter is used to set a value
 *				value - true if UI busy should be incremented, false to decrement
 *
 *  RETURNS: 	current UI busy count (0 if not busy)
 *
 *  CREATED: 11/18/97
 *
 *  BY: Gavin Peacock
 *
 *************************************************************/
extern Word SysUIBusy(Boolean set, Boolean value)
{
	if (set)
		{
		if (value)
			GSysUIBusyCount++;
		else
			{
			ErrFatalDisplayIf(GSysUIBusyCount==0,"UIBusyCount underflow");
			GSysUIBusyCount--;
			}
		}
	return GSysUIBusyCount;
}


