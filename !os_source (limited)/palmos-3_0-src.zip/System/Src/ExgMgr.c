/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     ExgMgr.c
 * AUTHOR:	 Gavin Peacock: May 29, 1997
 *
 * DECLARER: System
 *
 * ROUTINES:
 *		
 * DESCRIPTION:
 *	  This file contains the Exchange Manager routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <ExgMgr.h>
#include <ExgLib.h>
#include <globals.h>
#include <SystemMgr.h>
#include <SysEvtMgr.h>
#include <UICommon.h>

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgInit
 *
 * DESCRIPTION: Initialize the Exchange system. Currently this is used to
 *		load the ir library
 *
 *
 * PARAMETERS:	none
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgInit(void)
{
	Err		 err = 0;
	Word	refNum = 0;
#if EMULATION_LEVEL != EMULATION_NONE
	SysLibEntryProcPtr		libP=0;

	Err IrdPrvInstallDispatcher(UInt refNum, SysLibTblEntryPtr entryP);

	// Install the Irda library
	libP = IrdPrvInstallDispatcher;
	err = SysLibInstall(libP, &refNum);
#else
	//DWord creator = PrefGetPreference(prefExgDefaultLibrary);
	//if (! (GSysResetFlags & sysResetFlagNoExtensions)) 
	err = SysLibLoad(sysFileTExgLib,sysFileCIrLib,&refNum);
#endif
	//ErrNonFatalDisplayIf(err,"Ir Library not loaded");
	GExgActiveLib = refNum;
	return err;
}


/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: PrvGetDefaultLibrary
 *
 * DESCRIPTION: Get the default Exg Library. This should get
 *	the default library from preferences, right now, it just
 *	gets the lib from the globals.
 *
 *
 * PARAMETERS:	none
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
static Err PrvGetDefaultLibrary(ExgSocketPtr socketP)
{
	Err err = 0;
	// how do we look up lib refnum given creator ID???
	//DWord creator = PrefGetPreference(prefExgDefaultLibrary);
	if (!GExgActiveLib || (GExgActiveLib==sysInvalidRefNum))
		{
		FrmAlert(ExchangeNoLibraryAlert);
		err = exgErrBadLibrary;
		}
	else
		socketP->libraryRef = GExgActiveLib;
	return err;
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgRegisterData
 *
 * DESCRIPTION: Registers a data data type with Exg so that incomming data
 *				with that type will be sent to the registering app.
 *
 *
 * PARAMETERS:	creatorID	-- application's creator ID
 *				dataTypes	-- ptr a string buffer with the data types to register
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgRegisterData(const DWord creatorID,const Word id, const Char * const dataTypesP)
{
	Word size = 0;
	if (dataTypesP) size = StrLen(dataTypesP)+1;
	
	PrefSetAppPreferences (creatorID, id, exgDataPrefVersion, 
		(VoidPtr)dataTypesP, size, false);
	return DmGetLastErr();
}

/************************************************************
 *
 *  FUNCTION:PrvExgFindNextTarget
 *
 *  DESCRIPTION:Find next target app from a registry, id indicates
 *		the registry to search amd dataP is the data to find
 *
 *  PARAMETERS: database access ptr,
 *				pointer to index to start searching from (0 to start)
 *				and continue with last result+1 
 *				registry id, index of next 
 *
 *  RETURNS: creatorID of next target, or 0 if not found
 *
 *  CREATED: 11/22/94 
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/

static ULong	PrvExgFindNextTarget(DmOpenRef dbR, Int* idx, Int id, CharPtr dataP,Int* chosenOne)
{
	Int				resID;
	ULong			resType;
	LocalID			locID;
	Handle			resH;
	CharPtr 		resourceP;
	CharPtr			endP;
	Word 			flagBit;
	Int 			flags;			// bit field to mark chosen state of each entry
	UInt			resCount;
	Boolean			requireChosen = *chosenOne;
	ULong 			creator = 0;

	resCount = DmNumResources(dbR);
	while (*idx < resCount)
		{
		if (DmResourceInfo(dbR,*idx,&resType,&resID,&locID)!=0) break;
		
		if (resID == id)
			{ 
			resH = DmGetResourceIndex(dbR,*idx);
			resourceP = MemHandleLock(resH);
			// Get the flags
			flags = *((IntPtr)resourceP);
			flagBit = 1;
			// if we are looking for a chosenOne, and there aren't any here, skip this one
			if (requireChosen && !flags) 
				{
				MemHandleUnlock(resH);
				(*idx)++;
				continue;
				}
			resourceP += sizeof (Int);			// skip the version number
			// registry entry may contain multiple items separated by exgSeparatorChar
			while ((endP = StrChr(resourceP,exgSeparatorChar)) != NULL)
				{
				// if extension begins with *, it is a wildcard and will accept any extension
				if (StrNCaselessCompare(resourceP,dataP,endP-resourceP)==0 || (*resourceP == '*'))
					{
					creator = resType;
					*chosenOne = (flags & flagBit) != 0;
					// if we require a chosen one, then do not break if this is not selected.
					if (!((requireChosen && (*chosenOne==0))))
						break;
					}
				flagBit <<=1;			// check next bit in flags
				resourceP = endP + 1;  // skip to next string
				}
			if (!creator && (StrCaselessCompare(resourceP,dataP)==0))
				creator = resType;
			if (creator)
				{
				// return if this item is selected
				*chosenOne = flags & flagBit;
				MemHandleUnlock(resH);
				break;
				}
			MemHandleUnlock(resH);
			}
 		(*idx)++;
		}
		
	return creator;
}

 

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgConnect
 *
 * DESCRIPTION: Establish a connection with a remote socket
 *				This does not tranfer and data content
 *
 *
 * PARAMETERS:	dataPtr pointer a ExgDataType structure
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgConnect(ExgSocketPtr socketP)
{	
	if (!socketP->libraryRef)
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;
	return ExgLibConnect(socketP->libraryRef,socketP);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgPut
 *
 * DESCRIPTION: Sends the data in socketP using the active EXG device
 *				to the active destination.
 *
 *
 * PARAMETERS:	dataPtr pointer a exgDataType structure
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgPut(ExgSocketPtr socketP)
{	if (!socketP->libraryRef)
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;

	return ExgLibPut(socketP->libraryRef,socketP);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgGet
 *
 * DESCRIPTION: Gets the data identified in dataP using the active 
 *				EXG device to the active destination.
 *
 *
 * PARAMETERS:	dataPtr pointer a exgDataType structure
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgGet(ExgSocketPtr socketP)
{	if (!socketP->libraryRef)
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;

	return ExgLibGet(socketP->libraryRef,socketP);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgAccept
 *
 * DESCRIPTION: Sends the data in dataP using the active Exg device
 *				to the active destination.
 *
 *
 * PARAMETERS:	socketP pointer a exgSocketType structure
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgAccept(ExgSocketPtr socketP)
{	if (!socketP->libraryRef) 
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;
	return ExgLibAccept(socketP->libraryRef,socketP);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgDisconnect
 *
 * DESCRIPTION: Terminate an exchange session. This is used for 
 *	any exchange session with get or put or receive. If error 
 *	parameter is non-zero, the session will be terminated and
 *	an error dialog displayed.
 *
 *
 * PARAMETERS:	socketP pointer a exgSocketType structure
 *				err - application returned error
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
Err ExgDisconnect(ExgSocketPtr socketP,Err error)
{	if (!socketP->libraryRef) 
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;
	return ExgLibDisconnect(socketP->libraryRef,socketP,error);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgSend
 *
 * DESCRIPTION: Sends data referenced by ExgDataType structure.
 *				An application should call this function after
 *				a ExgPut call.
 *
 *
 * PARAMETERS:	socketP pointer a exgSocketType structure
 *				bufP	pointer to buffer with data to send
 *				bufLen  # of bytes to try to send
 *				errP	pointer to Error
 *
 * RETURNS: 	# of bytes sent
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
ULong ExgSend(ExgSocketPtr socketP,const void * const bufP,ULong bufLen,Err* errP)
{	if (!socketP->libraryRef) 
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;
	return ExgLibSend(socketP->libraryRef,socketP,bufP, bufLen,errP);
}

/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgReceive
 *
 * DESCRIPTION: Receives data referenced by ExgDataType structure.
 *				An application should call this function after
 *				being notified that there is incomming data that
 *				it should receive.
 *
 *
 * PARAMETERS:	socketP pointer a exgSocketType structure
 *				bufP	pointer to buffer to receive data
 *				bufLen  # of bytes to try to read
 *				errP	pointer to Error
 *
 * RETURNS: 	# of bytes read, zero if end of file
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
ULong ExgReceive(ExgSocketPtr socketP,VoidPtr bufP,const ULong bufLen,Err* errP)
{	if (!socketP->libraryRef) 
		if (PrvGetDefaultLibrary(socketP)!=0) return exgErrBadLibrary;
	return ExgLibReceive(socketP->libraryRef,socketP,bufP,bufLen,errP);
}

/******************************************************************
 *
 * FUNCTION: PrvExgAskUser
 *
 * DESCRIPTION: called by ExgNotifyReceive, this presents a dialog that
 *				asks the user if they want to receive data. The user can
 *				verify with hard up/down buttons or onscreen ui.
 *
 *
 * PARAMETERS:	message to display
 *
 * RETURNS: ok or not
 *
 * CREATED: 10/23/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
********************************************************************/
static Boolean PrvExgAskUser(CharPtr title,CharPtr msg,Err *errP)
{
	Word error;
	EventType event;
	FormPtr curForm;
	Boolean insPtState;
	PointType insPtPos;
	WinHandle savedDrawWin;
	WinHandle savedActiveWin;
	FormPtr frm;
	FieldPtr fld;
	Boolean ok = false;	

	frm = FrmInitForm(ExchangeForm);
	ErrNonFatalDisplayIf(!frm,"Cannot init Exchange form");
	if (!frm)
		{
		*errP = exgMemError;
		return false;
		}
	fld = FrmGetObjectPtr(frm,FrmGetObjectIndex(frm,ExchangeMessageField));
	ErrFatalDisplayIf(!fld,"Exchange field not found");
	FldSetTextPtr(fld,msg);
	FldRecalculateField(fld,true);  // format the text....
	
	insPtState = InsPtEnabled();
	InsPtGetLocation (&insPtPos.x, &insPtPos.y);
	
	curForm = FrmGetActiveForm ();
	if (! curForm)
		{
		savedDrawWin = WinGetDrawWindow ();
		savedActiveWin = WinGetActiveWindow ();
		}

	FrmSetActiveForm (frm);
	if (title && *title)
		FrmSetTitle (frm,title);
		
	if (! frm->attr.visible)
		FrmDrawForm (frm);
	FrmSetFocus (frm, frm->focus);

	// notify the user that they have something
	SndPlaySystemSound(sndStartUp);				// higher tone
	SndPlaySystemSound(sndConfirmation);		// lower

	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		
		// Check for ronamatic key first in case Graffiti help is already up and
		// the "Yes/No" dialog is over it.  Bringing up Graffiti help again causes a crash.
		if ((event.eType == keyDownEvent) && (event.data.keyDown.chr == ronamaticChr))
			continue;
		
		if (! SysHandleEvent (&event))
			if (! MenuHandleEvent (0, &event, &error))
				FrmHandleEvent (frm, &event);

		if (event.eType == ctlSelectEvent)
			{
			
			if (event.data.ctlSelect.controlID == ExchangeOKButton)
				{
				ok = true;
				break;
				}
			else if (event.data.ctlSelect.controlID == ExchangeCancelButton)
				{
				break;
				}
			}
		// up key is yes, down key is no....
		else if (event.eType == keyDownEvent) 
			{
			if (event.data.keyDown.chr == pageUpChr)
				{
					ok = true;
					break;
				}
			else if (event.data.keyDown.chr == pageDownChr)
				{
					break;
				}
			} 

		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}

	FrmEraseForm (frm);
	InsPtSetLocation (insPtPos.x, insPtPos.y);
	InsPtEnable (insPtState);
	
	if (curForm)
		FrmSetActiveForm (curForm);
	else
		{
		WinSetDrawWindow (savedDrawWin);
		WinSetActiveWindow (savedActiveWin);
		}
	
	FrmDeleteForm(frm);
	return (ok);
}

static Err PrvGetLaunchInfo(ULong creator,UInt *cardP, LocalID *dbIDP)
{
	Err 		err;
	DmSearchStateType	searchState;
										
	/* Find the application */											
	err = DmGetNextDatabaseByTypeCreator(						
			true, &searchState,sysFileTApplication, creator,											
			true, cardP, dbIDP);	
	if (err) // also check for panels...
		err = DmGetNextDatabaseByTypeCreator(						
				true, &searchState,sysFileTPanel, creator,											
				true, cardP, dbIDP);
					
#if EMULATION_LEVEL!= EMULATION_NONE
		// in emulator, the app will not exist, set app info to zero because
		// Emulator version of SysCurAppDatabase will return those values...
		err = 0;
		*cardP = 0;
		*dbIDP = 0;
#endif
	return err;
}

static ULong PrvFindTarget(Word id, CharPtr dataP,ULong defaultTarget)
{
	Int chosenOne;
	Int idx = 0; 
	DmOpenRef dbR;
	 ULong target = 0;  // default for debugging
	ULong firstTarget = 0; 

	if (dataP && *dataP) {
		dbR = PrefOpenPreferenceDB (false);
		if (! dbR) return 0;
		
		do {
			chosenOne = defaultTarget!=0; // set this param non zero if we are only interested in
								 			// targets that are selected as primary
			target = PrvExgFindNextTarget(dbR, &idx,id, dataP,&chosenOne);
			idx++; // next time start and next index...
			if (target && !firstTarget) firstTarget = target;  // remeber the first one we found
		} while (target && !chosenOne);
		// if no target was selected, and we are not looking for a selected one,
		// use the first one we found
		if (!chosenOne && !defaultTarget) target = firstTarget;
		DmCloseDatabase(dbR);
	}	
	//if (!target) target = defaultTarget;
	return target;
}

//ExgRegisterData(sysFileCLauncher,exgRegExtensionID,"reg\tpdb");
//ExgRegisterData(sysFileCAddress,exgRegExtensionID,"vcf");
//ExgRegisterData(sysFileCDatebook,exgRegExtensionID,"vcs");
//ExgRegisterData(sysFileCMemo,exgRegExtensionID,"txt");

// The target is found by using the following logic:
// The target in the socket is verified by making sure it exists
// scan registry for other possible targets and check if any have been selected as primary
// (registry should scan first by type, second by extension
// if a primary is found verify and return it
// if the target exists, return it.
// else, pick first available secondary target and return it

static Err PrvGetTarget(ExgSocketPtr socketP,ULong *creatorP,UInt *cardP, LocalID *dbIDP)
{	
	CharPtr ext;
	Err err = exgErrNoKnownTarget;
	ULong target = 0;
	ULong primaryTarget = 0;
	
	if (socketP->target)
		{
		// make sure the app exists...
		if (PrvGetLaunchInfo(socketP->target,cardP,dbIDP)==0)
			{
			err = 0;  // found one...
			primaryTarget = socketP->target;
			}
		else
			err = exgErrTargetMissing;
		}	
		
	// check for type 	
	if (socketP->type)
		{
		// scan type registry here...
		target = PrvFindTarget(exgRegTypeID,socketP->type,primaryTarget);	
		}
	// check for extension																		
	if (!target && socketP->name)
		{
		// scan for start of extension
		for (ext=socketP->name;*ext && *ext!='.';ext++) ;
		if (*ext) *ext++;  // skip past dot
		target = PrvFindTarget(exgRegExtensionID,ext,primaryTarget);	
		}

	if (target)
		{
		// get target info (app should exist if it is in the registry.)..
		if (PrvGetLaunchInfo(target,cardP,dbIDP)==0)
			err = 0;  // found one...
		else
			err = exgErrTargetMissing;
		}
		else	// if no overriding target was found, use primary target (creator)
			target = primaryTarget;

	*creatorP = target;
	return err;
}

// Given a cardNo and dbId for an app (or panel?), get its name.  Try for the resource name
// first - if that fails, then use the name stored with the database.
// DOLATER: A system trap/routine should be added for this sort of thing, since
// it is done in the launcher, here and potentially may be needed by others.
static Err PrvGetAppName(UInt cardNo,LocalID appDBID,CharPtr dbName)
{
	DmOpenRef appDB;
	Handle strH;
	Err err = 0;
	Boolean gotName = false;
	
	dbName[0] = 0;
	
	// First try to get the app name stored as a tAIN resource
	appDB = DmOpenDatabase(cardNo, appDBID, dmModeReadOnly);
	if (appDB != NULL)
		{
		strH = DmGet1Resource(ainRsc, ainID);
		if (strH != NULL)
			{
			gotName = true;
			StrCopy(dbName, MemHandleLock(strH));
			MemHandleUnlock(strH);
			DmReleaseResource(strH);
			}
		DmCloseDatabase(appDB);
		}
		
	// Use the database name if no resource name was found
	if (!gotName)
		err = DmDatabaseInfo(cardNo,appDBID,dbName,0,0,0,0,0,0,0,0,0,0);
		
	return err;
}


/************************************************************
 * API
 *-----------------------------------------------------------
 *
 * FUNCTION: ExgNotifyReceive
 *
 * DESCRIPTION: Sends data to an application. This is called by an
 *				exchange library when it has received data to be
 *				sent to an app. The library provides a socket header 
 *				that contains enough information for this routine to 
 *				identify the destination app.
 *				This may launch another application in many cases.
 *				This routine must be called from the UI task because it
 *				may bring up a user dialog.
 *
 *
 * PARAMETERS:	dataPtr pointer a exgSocketType structure
 *
 * RETURNS: 0 if no error, else error code
 *
 * CREATED: 5/29/97
 *
 * BY: Gavin Peacock
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *************************************************************/
#define maxExgMessageSize  200

Err ExgNotifyReceive(ExgSocketPtr socketP)
{	Err 		err = 0;
	Boolean 	doDialog = true;
	Boolean		doLaunch = true;
	UInt		cardNo,curCard;														
	LocalID		appDBID,curDBID;														
	DWord 		result;
	ULong		creator;
	Boolean		toDoHack = false;  // Hack to show Todo Name while sending to datebook
	char dbName[dmDBNameLength];
	char title[exgMaxTitleLen];		
	Word titleLen;
		
	dbName[0] = 0;
	
	EvtResetAutoOffTimer(); // reset auto off so the user has a chance to read this
	
	// Do this hack because we don't have time to make the todo app do the right thing
	// It should accept the receive code directly and handle it in this case...
	if (socketP->target == sysFileCToDo)
		{
		toDoHack = true;
		socketP->target = sysFileCDatebook;
		}
		
	/* Find the application (or panel) */											
	err = PrvGetTarget(socketP,&creator,&cardNo,&appDBID);
	if (err) return(err);

	// get the name of the app
#if EMULATION_LEVEL!= EMULATION_NONE
	StrCopy(dbName,"the current application");
#else
	if (toDoHack)	// look up name of toDoApp instead of datebook...
		{
		UInt		cardNoT;														
		LocalID		appDBIDT;
		PrvGetLaunchInfo(sysFileCToDo,&cardNoT,&appDBIDT);
		err = PrvGetAppName(cardNoT,appDBIDT,dbName);
		}
	else	
		err = PrvGetAppName(cardNo,appDBID,dbName);
#endif		
	
	// don't ask user if localmode is selected...
	if (socketP->localMode) doDialog = false;

	// call app before dialog to give it a chance to override the dialog
	if ( !err )	
		{													
		ExgAskParamType	param;
		param.socketP = socketP;
		param.result = doDialog ? exgAskDialog : exgAskOk;  // set current default 
		err = SysAppLaunch(cardNo, appDBID,					
			0/*launchFlags*/, sysAppLaunchCmdExgAskUser, (char *)&param, &result);	
        if (!err) err = result;
		if (!err)
			{
			doDialog = param.result == exgAskDialog;
			if (param.result==exgAskCancel) doLaunch = false;
			}
		}
	// now do the dialog if it is enabled	
 	if (!err && doDialog)
		{
		CharPtr str;
		CharPtr msg;
		VoidHand askH,nameH;
		CharPtr askStr,noNameStr;

		msg = MemPtrNew(maxExgMessageSize);
		ErrNonFatalDisplayIf(!msg,"ExgNotify out of mem");
		if (!msg) return exgMemError;
		askH = DmGetResource (strRsc, ExchangeQuestionString);
		nameH = DmGetResource (strRsc, ExchangeUnnamedString);
		noNameStr = MemHandleLock(nameH);
		
		str = socketP->description;
		if (!str)
			str = socketP->name;
		if (!str)
			str = socketP->type;
		if (!str)
			str = noNameStr;  // "UnNamed";
		
		askStr = MemHandleLock(askH);
		StrPrintF(msg,askStr,str,dbName);
		//StrPrintF(msg,"Do you want to accept \x93%s\x94\ninto %s?",str,dbName);
		MemHandleUnlock(nameH);
		MemHandleUnlock(askH);
		
		// get a title from the library
		title[0] = 0;  // default to title in dialog
		titleLen = exgMaxTitleLen;
		ExgLibControl(socketP->libraryRef,exgLibCtlGetTitle,&title,&titleLen);

		doLaunch = PrvExgAskUser(title,msg,&err);	
		MemPtrFree(msg);
		}
	
	// now do the data transfer if still OK  - two launch calls,one to recieve and the other to display	
	if (!err && doLaunch)
		{
																					
		// call the app (don't launch) telling it to receive data				
		if ( !err )	
			{													
			err = SysAppLaunch(cardNo, appDBID,					
				0/*launchFlags*/, sysAppLaunchCmdExgReceiveData, (char *)socketP, &result);	
        if (!err) err = result;
      	}
      
        // reset auto off so we do not shut down while switching apps
        // accepting data in the previous call may take a long time....
		EvtResetAutoOffTimer(); 
		
 	    // finally goto the new entry (Launch the app if not already launched)
 	    // do this only if app specifies a goToCreator
     	if (!err && socketP->goToCreator)
      		{
      		// get the app card/DB info if it isn't the same app...
      		if (socketP->goToCreator != creator) 
      			{
				/* Find the application (or panel) */											
				err = PrvGetLaunchInfo(socketP->goToCreator,&cardNo,&appDBID);	
				}
			// get the current app ID to see if the app is already running
	     	if (!err) 
	      		err = SysCurAppDatabase(&curCard,&curDBID);
	      		 
			if (!err)
				{																		
	      		// create a goto parameter block from goto info in socketP
	      		// allocate block to system because the system will delete it later
	      		GoToParamsPtr cmdPBP = MemPtrNew(sizeof(GoToParamsType));
	      		if (cmdPBP)
	      			{	
	      			MemPtrSetOwner(cmdPBP,0);
	      			MemSet(cmdPBP,sizeof(GoToParamsType),0);
	      			cmdPBP->dbCardNo = socketP->goToParams.dbCardNo;
	       			cmdPBP->dbID = socketP->goToParams.dbID;
	      			cmdPBP->recordNum = socketP->goToParams.recordNum;
	       			cmdPBP->matchCustom = socketP->goToParams.matchCustom;
	       			// add this line when goto supports uniqueID
	     			//cmdPBP->uniqueID = socketP->gotoParams.uniqueID;
	     			
			      	//if (curCard==cardNo && curDBID==appDBID)     // if this app is active
#if EMULATION_LEVEL!= EMULATION_NONE
					// the emulator will just exit that app if we try to switch to itself,
					// so we will just call it directly
					err = SysAppLaunch(cardNo, appDBID,		   // just call the app			
						0/*launchFlags*/, sysAppLaunchCmdGoTo, 
						(char *)(cmdPBP), &result);	
		       		if (!err) err = result;
	        		MemPtrFree(cmdPBP); // we must delete block if the app was not launched
#else
			      	// Always launch app - if it is running, this will cause it to exit and
			      	// run again, this assures that any modal dialogs will be exited properly
			      	// launch the app
					err = SysUIAppSwitch(cardNo, appDBID,sysAppLaunchCmdGoTo,(char *)(cmdPBP));
					// the system will delete the cmdPBP when the app terminates...	
#endif
					}
					else // unable to allocate cmdPBP
					{
					ErrNonFatalDisplayIf(!cmdPBP, "No memory for PBP");
					err = memErrNotEnoughSpace;	
					}											
		     	}
		     }
		}
	return err;
}



