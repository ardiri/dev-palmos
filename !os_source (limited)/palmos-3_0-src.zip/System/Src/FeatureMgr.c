/*******************************************************************
 * 							 Pilot Software
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 *-------------------------------------------------------------------
 * FileName:
 *		FeatureMgr.c
 *
 * Description:
 *		Feature Management routines for Pilot
 *
 * History:
 *   	6/21/95  RM - Created by Ron Marianetti
 *
 *******************************************************************/

#include <SysAll.h>
#include <FeatureMgr.h>

#define	NON_PORTABLE
#include <Globals.h>
#include <FeaturePrv.h>


/************************************************************
 *	Private routines
 *
 *************************************************************/
static Err	
	PrvEntry(FtrCachePtr cacheP);

static void
	PrvExit(FtrCachePtr cacheP);

static FtrCreatorPtr  
	PrvFindCreator(FtrCachePtr cacheP, DWord creator, Boolean romTable);

static FtrFeaturePtr  
	PrvFindFeature(FtrCreatorPtr creatorP, UInt featureNum);

static Err 
	PrvFtrRegister(FtrCachePtr cacheP, DWord creator, UInt featureNum, DWord value);


/************************************************************
 *
 *  FUNCTION: FtrInit
 *
 *  DESCRIPTION: Initialize the Feature Manager
 *
 *  PARAMETERS: none
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err FtrInit(void)
{
	FtrGlobalsPtr		gP;
	FtrTablePtr			tableP;
	
	
	// Allocate our globals
	gP = MemPtrNew(sizeof(FtrGlobalsType));
	if (!gP) DbgBreak();
	
	// Clear them
	MemSet(gP, sizeof(FtrGlobalsType), 0);
	
	// Save pointer to globals
	GFtrGlobalsP = (Ptr)gP;
	
	
	// Allocate ROM and RAM tables
	gP->romTableH = (FtrTablePtr*)DmGetResource(sysResTFeatures, sysResIDFeatures);
	if (!gP->romTableH) {
		ErrDisplay("Sys Ftr Rsrc not found");
		return -1;
		}
	
	gP->ramTableH = (FtrTablePtr*)MemHandleNew(sizeof(FtrTableType) - sizeof(FtrCreatorType));
	if (!gP->ramTableH) {
		ErrDisplay("Out of Mem");
		return -1;
		}
		
		
	// Init the RAM table
	tableP = MemHandleLock(gP->ramTableH);
	tableP->numEntries = 0;
	MemPtrUnlock(tableP);
		

	return 0;
}





/************************************************************
 *
 *  FUNCTION: FtrUnregister
 *
 *  DESCRIPTION: Unregister a feature
 *
 *  PARAMETERS: 
 *		creator 		- creator type, should be same as the app that owns this
 *									feature
 *		featureNum 	- feature number of the feature
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err FtrUnregister(DWord creator, UInt featureNum)
{
	FtrCacheType		cache;
	FtrCreatorPtr		creatorP;
	FtrFeaturePtr		featureP;
	Err					err;
	DWord					size;
	BytePtr				srcP, dstP, baseP;
	

	// Lock down handle's we'll use, etc.
	err = PrvEntry(&cache);	
	if (err) goto Exit;
	
	
	// First, make sure it exists in the RAM table
	err = ftrErrNoSuchFeature;
	creatorP = PrvFindCreator(&cache, creator, false);
	if (creatorP) {
		featureP = PrvFindFeature(creatorP, featureNum);
		if (!featureP)  goto Exit;
		}
	else
		goto Exit;
		
		
		
	// Get the old size and base
	baseP = (BytePtr)cache.ramTableP;
	size = MemPtrSize(cache.ramTableP);
	
	// Remove the feature from the creator group
	dstP = (BytePtr)featureP;
	srcP = dstP + sizeof(FtrFeatureType);
	MemMove(dstP, srcP, size - (srcP - baseP));
	size -= sizeof(FtrFeatureType);
	creatorP->numEntries--;
	
	// If the creator group is empty, remove it
	if (!creatorP->numEntries) {
		dstP = (BytePtr)creatorP;
		srcP = dstP + (sizeof(FtrCreatorType) - sizeof(FtrFeatureType));
		MemMove(dstP, srcP, size - (srcP - baseP));
		size -= (sizeof(FtrCreatorType) - sizeof(FtrFeatureType));
		cache.ramTableP->numEntries--;
		}
	
		
	// Shrink the table
	err = MemPtrResize(cache.ramTableP, size);
	if (err) {
		ErrDisplay("Err resizing table");
		goto Exit;
		}
		
	
Exit:
	ErrNonFatalDisplayIf(err && err != ftrErrNoSuchFeature, "Err in FtrUnregister");
	PrvExit(&cache);
	return err;	
}



/************************************************************
 *
 *  FUNCTION: FtrGet
 *
 *  DESCRIPTION: Get a feature
 *
 *  PARAMETERS: 
 *		creator 		- creator type, should be same as the app that owns this
 *									feature
 *		featureNum 	- feature number of the feature
 *		*valueP		- value of the feature is returned here
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	8/21/95	Excluded ftrErrNoSuchFeature from causing an
 *								error display
 *************************************************************/
Err FtrGet(DWord creator, UInt featureNum, DWordPtr valueP)
{
	FtrCacheType		cache;
	FtrCreatorPtr		creatorP;
	FtrFeaturePtr		featureP=0;
	Err					err;
	

	// Lock down handle's we'll use, etc.
	err = PrvEntry(&cache);	
	if (err) goto Exit;
	
	
	// Look for it in the RAM table
	creatorP = PrvFindCreator(&cache, creator, false);
	if (creatorP) 
		featureP = PrvFindFeature(creatorP, featureNum);
	
	// If not there, look in the ROM table
	if (!featureP) {
		creatorP = PrvFindCreator(&cache, creator, true);
		if (creatorP) 
			featureP = PrvFindFeature(creatorP, featureNum);
		}

	// Get the feature, if found
	if (featureP) {
		*valueP = featureP->value;
		err = 0;
		}
	else
		err = ftrErrNoSuchFeature;
		
					
Exit:
	ErrNonFatalDisplayIf(err && err != ftrErrNoSuchFeature, "Err in FtrGet");
	PrvExit(&cache);
	return err;	
}




/************************************************************
 *
 *  FUNCTION: FtrSet
 *
 *  DESCRIPTION: Set a feature
 *
 *  PARAMETERS: 
 *		creator 		- creator type, should be same as the app that owns this
 *									feature
 *		featureNum 	- feature number of the feature
 *		newValue		- new value
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err FtrSet(DWord creator, UInt featureNum, DWord newValue)
{
	FtrCacheType		cache;
	FtrCreatorPtr		creatorP;
	FtrFeaturePtr		featureP=0;
	Err					err;
	

	// Lock down handle's we'll use, etc.
	err = PrvEntry(&cache);	
	if (err) goto Exit;
	
	
	// Look for it in the RAM table
	creatorP = PrvFindCreator(&cache, creator, false);
	if (creatorP) 
		featureP = PrvFindFeature(creatorP, featureNum);
	
	// If not found in the RAM table, register it and give it an initial value
	if (!featureP) 
		err = PrvFtrRegister(&cache, creator, featureNum, newValue);
		
	// Else, simply change it's value
	else {
		featureP->value = newValue;
		err = 0;
		}

		
Exit:
	ErrNonFatalDisplayIf(err, "Err in FtrSet");
	PrvExit(&cache);
	return err;	
}



/************************************************************
 *
 *  FUNCTION: FtrGetByIndex
 *
 *  DESCRIPTION: Get a feature by index. This routine is normally
 *		only used by shell commands. Most applications will not need it.
 *
 *		For each table (rom,ram) the caller should pass indices starting 
 *		at 0 and incrementing until it gets back ftrErrNoSuchFeature.
 *
 *  PARAMETERS: 
 *		index			- index of feature
 *		romTable 	- if true, index into ROM table, else RAM table
 *		*ftrCreatorP 	- feature creator is returned here
 *		*numP  		- feature number is returned here
 *		*valueP		- feature value is returned here
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
Err		FtrGetByIndex(UInt index, Boolean romTable, 
					DWordPtr ftrCreatorP, UIntPtr numP, DWordPtr valueP)
{
	FtrCacheType		cache;
	FtrCreatorPtr		creatorP=0;
	FtrFeaturePtr		featureP=0;
	FtrTablePtr			tableP;
	UInt					i, creatorIndex, featureIndex;
	Err					err;
	BytePtr				curP;
	

	// Lock down handle's we'll use, etc.
	err = PrvEntry(&cache);	
	if (err) goto Exit;
	
	// Get pointer to appropriate table
	if (romTable)
		tableP = cache.romTableP;
	else
		tableP = cache.ramTableP;
		
		
	// Assume error
	err = ftrErrNoSuchFeature;
		
	// Loop through table
	curP = (BytePtr)&(tableP->creator[0]);
	for (i=0, creatorIndex=0, featureIndex=0; 1; ) {
		
		// Get the next creator group, if necessary
		if (!creatorP) {
			if (tableP->numEntries == creatorIndex) 
				goto Exit;
			creatorP = (FtrCreatorPtr)curP;
			curP += sizeof(FtrCreatorType) - sizeof(FtrFeatureType);
			featureIndex = 0;
			creatorIndex++;
			}
			
		// Get the feature pointer
		if (featureIndex < creatorP->numEntries) {
			featureP = (FtrFeaturePtr)curP;
			curP += sizeof(FtrFeatureType);
			featureIndex++;
			}
		else {
			creatorP = 0;
			continue;
			}
			
		// See if the index matches
		if (i==index) {
			*ftrCreatorP = creatorP->creator;
			*numP = featureP->num;
			*valueP = featureP->value;
			err = 0;
			goto Exit;
			}
		
		i++;
		}
		
	
Exit:
	PrvExit(&cache);
	return err;	
}






/************************************************************
 *
 *  FUNCTION: PrvEntry 
 *
 *  DESCRIPTION: Common entry procedure used by all Feature routines.
 *		This call gets the Feature globals, locks down the ROM and
 *		RAM feature tables, and puts pointers and handles to the tables
 *		into the cache structure.
 *
 *  PARAMETERS: 
 *		cacheP - pointer to cache structure.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err PrvEntry(FtrCachePtr cacheP)
{
	FtrGlobalsPtr	gP = (FtrGlobalsPtr)GFtrGlobalsP;

	// Err if no globals allocated
	if (!gP) {
		ErrDisplay("Ftr Mgr not init.");
		return ftrErrInternalErr;
		}
	
	// Get handles to tables
	cacheP->romTableH = gP->romTableH;
	cacheP->ramTableH = gP->ramTableH;
	cacheP->romTableP = MemHandleLock(gP->romTableH);
	cacheP->ramTableP = MemHandleLock(gP->ramTableH);
	
	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvExit
 *
 *  DESCRIPTION: Common exit procedure used by all Feature routines.
 *		This call unlocks the ROM and RAM feature tables
 *
 *  PARAMETERS: 
 *		cacheP - pointer to cache structure.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static void PrvExit(FtrCachePtr cacheP)
{
	// Unlock tables
	MemHandleUnlock(cacheP->romTableH);
	MemHandleUnlock(cacheP->ramTableH);
}



/************************************************************
 *
 *  FUNCTION: PrvFindCreator
 *
 *  DESCRIPTION: Searches the given table for given creator group
 *		of features.
 *
 *  PARAMETERS: 
 *		cacheP 	- pointer to cache structure.
 *		creator 	- creator type to search for
 *		romTable - if true, search ROM table else search RAM table
 *
 *  RETURNS: FtrCreatorPtr if successful
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static FtrCreatorPtr 
	PrvFindCreator(FtrCachePtr cacheP, DWord creator, Boolean romTable)
{
	FtrTablePtr		tableP;
	UInt				i;
	BytePtr			bP;
	FtrCreatorPtr	creatorP;
	
	// Get the table pointer
	if (romTable) tableP = cacheP->romTableP;
	else tableP = cacheP->ramTableP;
	
	// Search for this creator table
	creatorP = &tableP->creator[0];
	for (i=0; i<tableP->numEntries; i++) {
		if (creatorP->creator == creator) return creatorP;
		
		// Skip to next creator
		bP = (BytePtr)creatorP;
		bP += creatorP->numEntries * sizeof(FtrFeatureType);
		bP += sizeof(FtrCreatorType) - sizeof(FtrFeatureType);
		creatorP = (FtrCreatorPtr)bP;
		}
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvFindFeature
 *
 *  DESCRIPTION: Searches the given feature in a creator table
 *
 *  PARAMETERS: 
 *		creator 	- creator type to search for
 *		romTable - if true, search ROM table else search RAM table
 *
 *  RETURNS: FtrCreatorPtr if successful
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static FtrFeaturePtr  
	PrvFindFeature(FtrCreatorPtr creatorP, UInt featureNum)
{
	UInt				i;
	FtrFeaturePtr	featureP;
	
	// Search for this feature
	featureP = &creatorP->feature[0];
	for (i=0; i<creatorP->numEntries; i++) {
		if (featureP->num == featureNum) return featureP;
		
		// Skip to next feature
		featureP++;
		}
		
	return 0;
}



/************************************************************
 *
 *  FUNCTION: PrvFtrRegister, private
 *
 *  DESCRIPTION: Register a feature
 *
 *  PARAMETERS: 
 *		creator 		- creator type, should be same as the app that owns this
 *									feature
 *		featureNum 	- feature number of the feature
 *		value			- value of the feature
 *		override		- if true, features registered in the ROM table ONLY can be
 *							overriden.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 6/21/95
 *
 *  BY: Ron Marianetti
 *
 *************************************************************/
static Err PrvFtrRegister(FtrCachePtr cacheP, DWord creator, UInt featureNum, 
				DWord value)
{
	FtrCreatorPtr		ramCreatorP;
	FtrFeaturePtr		featureP;
	Err					err;
	DWord					size;
	BytePtr				srcP, dstP, baseP;
	

	// See if we have a creator table for it in RAM.
	ramCreatorP = PrvFindCreator(cacheP, creator, false);
		
		
		
	// If no RAM creator table, create it
	if (!ramCreatorP) {
	
		// Resize the table to add space for another creator group
		MemHandleUnlock(cacheP->ramTableH);
		size = MemHandleSize(cacheP->ramTableH);
		err = MemHandleResize(cacheP->ramTableH, size + sizeof(FtrCreatorType));
		if (err) goto Exit;
		cacheP->ramTableP = MemHandleLock(cacheP->ramTableH);
		
		// Init the creator group
		srcP = (BytePtr)cacheP->ramTableP;
		ramCreatorP = (FtrCreatorPtr)(srcP + size);
		cacheP->ramTableP->numEntries++;
		ramCreatorP->numEntries = 1;
		ramCreatorP->creator = creator;
		ramCreatorP->feature[0].num = featureNum;
		ramCreatorP->feature[0].value = value;
		}
		
	// Else, just grow the creator group to include the new feature
	else {
		// Resize the table to add space for another feature 
		MemHandleUnlock(cacheP->ramTableH);
		size = MemHandleSize(cacheP->ramTableH);
		err = MemHandleResize(cacheP->ramTableH, size + sizeof(FtrFeatureType));
		if (err) goto Exit;
		cacheP->ramTableP = MemHandleLock(cacheP->ramTableH);
		
		// Shift later entries down
		ramCreatorP = PrvFindCreator(cacheP, creator, false);
		featureP = &(ramCreatorP->feature[ramCreatorP->numEntries]);
		baseP = (BytePtr)cacheP->ramTableP;
		srcP = (BytePtr)featureP;
		dstP = srcP + sizeof(FtrFeatureType);
		MemMove(dstP, srcP, size - (srcP - baseP));
		
		// Add the feature
		ramCreatorP->numEntries++;
		featureP->num = featureNum;
		featureP->value = value;
		}			
			
Exit:
	ErrNonFatalDisplayIf(err, "Err in FtrRegister");
	return err;	
}









