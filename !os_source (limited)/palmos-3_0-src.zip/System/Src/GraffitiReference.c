/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     GraffitiReference.h
 * AUTHOR:	 Roger Flores: June 25, 1996
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain routines to handle the Graffiti Reference.
 *
 **********************************************************************/

#include <Pilot.h>
#include <Graffiti.h>
#include <SysEvtMgr.h>


/***********************************************************************
 *
 * FUNCTION:    GraffitiReferenceDialogScroll
 *
 * DESCRIPTION: Scroll the Graffiti Reference Dialog.
 *
 * PARAMETERS:  frmP - the form
 *					 forward - true to scroll forward, false to scroll backwards
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	8/26/96	Initial Revision
 *
 ***********************************************************************/
 
static void GraffitiReferenceDialogScroll (FormPtr frmP, Boolean forward, 
	ReferenceType *currentReference)
{
	ReferenceType newReference;
	
	
	newReference = *currentReference;
	if (forward)
		{
		// Scroll forwards if not the last screen
		if (newReference < referenceLast)
			{
			newReference++;
			}
		else
			return;
		}
	else
		{
		// Scroll backwards if not the first screen
		if (newReference > referenceFirst)
			{
			newReference--;
			}
		else
			return;
		}
	
	// At this point the bitmap should be changed.
	FrmHideObject(frmP, FrmGetObjectIndex(frmP, 
		graffitiReferenceFirstBitmap + *currentReference));
	*currentReference = newReference;
	FrmShowObject(frmP, FrmGetObjectIndex(frmP, 
		graffitiReferenceFirstBitmap + newReference));
	
	// Update scrollers
	FrmUpdateScrollers (frmP, 
		FrmGetObjectIndex (frmP, graffitiReferenceUpButton), 
		FrmGetObjectIndex (frmP, graffitiReferenceDownButton), 
		newReference > referenceFirst, 		// scroll up?
		newReference < referenceLast);		// scroll down?
}


/***********************************************************************
 *
 * FUNCTION:    GraffitiReferenceDialog
 *
 * DESCRIPTION: Pop up the Graffiti Reference Dialog.
 *
 * PARAMETERS:  referenceType - which reference to display
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	6/25/96	Initial Revision
 *
 ***********************************************************************/
 
extern void SysGraffitiReferenceDialog (ReferenceType referenceType)
{
	EventType event;
	FormPtr frm, originalForm;
	Boolean handled = false;
	Word tempShift;		// graffiti temp shift state
	Boolean numLockMode;
	Boolean junk;
	ReferenceType currentReference;
	

	originalForm =  FrmGetActiveForm();

	// Set up the onscreen keyboard
	GrfGetState(&junk, &numLockMode, &tempShift, &junk);
	if (referenceType == referenceDefault)
		{
		if (tempShift == grfTempShiftPunctuation)
			currentReference = referencePunc2;
		else if (tempShift == grfTempShiftExtended)
			currentReference = referenceExtended;
		else
			currentReference = referenceFirst;
		}
	else
		currentReference = referenceType;


	// Initialize the dialog.  Show just the current bitmap.	
	frm = FrmInitForm (graffitiReferenceDialog);
	FrmShowObject(frm, FrmGetObjectIndex(frm, 
		graffitiReferenceFirstBitmap + currentReference));

	// Update scrollers
	FrmUpdateScrollers (frm, 
		FrmGetObjectIndex (frm, graffitiReferenceUpButton), 
		FrmGetObjectIndex (frm, graffitiReferenceDownButton), 
		currentReference > referenceFirst, 		// scroll up?
		currentReference < referenceLast);		// scroll down?

	FrmSetActiveForm (frm);

	FrmDrawForm (frm);


	// Event loop for the Graffiti Reference dialog
	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		
		if (event.eType == keyDownEvent)
			{
			// Ignore attempts to bring up another graffiti reference
			if (event.data.keyDown.chr == graffitiReferenceChr)
				continue;
			// When the launcher is requested close the graffiti reference
			// to lower the memory impact and risk.
			else if (event.data.keyDown.chr == launchChr)
				{
				EvtAddEventToQueue (&event);
				break;
				}
			}
		
			
		if (!(event.eType == keyDownEvent && 
			event.data.keyDown.chr == graffitiReferenceChr))
			{
			if (!SysHandleEvent(&event))
				FrmHandleEvent (frm, &event); 
			}
		
			
		if (event.eType == ctlRepeatEvent)
			{		
			switch (event.data.ctlRepeat.controlID)
				{
				case graffitiReferenceUpButton:
					GraffitiReferenceDialogScroll(frm, false, &currentReference);
						
					// leave unhandled so the buttons can repeat
					break;
					
				case graffitiReferenceDownButton:
					GraffitiReferenceDialogScroll(frm, true, &currentReference);
					// leave unhandled so the buttons can repeat
					break;
				}
			}


		else if (event.eType == keyDownEvent)
			{
			switch (event.data.keyDown.chr)
				{
				case pageUpChr:
					handled = true;
					GraffitiReferenceDialogScroll(frm, false, &currentReference);
					break;
					
				case pageDownChr:
					handled = true;
					GraffitiReferenceDialogScroll(frm, true, &currentReference);
					break;
				}
			}

		else if (event.eType == ctlSelectEvent)
			{
			if (event.data.ctlSelect.controlID == graffitiReferenceDoneButton)
				{
				break;
				}
			}
					
		else if ((event.eType == frmCloseEvent && 
			event.data.frmClose.formID == graffitiReferenceDialog))
			break;
			
		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}


	
	FrmEraseForm (frm);
	FrmDeleteForm (frm);


	FrmSetActiveForm (originalForm);
}

