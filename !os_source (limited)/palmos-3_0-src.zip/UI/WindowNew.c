/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     window.c
 * AUTHOR:	 Art Lamb: Dec 14, 1994
 *
 * DECLARER: UI
 *
 * ROUTINES:
 *		WinAddWindow
 *		WinClipRectangle
 *		WinCreateOffscreenWindow
 *		WinCreateWindow
 *		WinDeleteWindow
 *		WinDisableWindow
 *		WinDisplayToWindowPt
 *		WinDrawChars
 *		WinDrawGrayLine
 *		WinDrawGrayRectangleFrame
 *		WinDrawLine
 *		WinDrawectangle
 *		WinDrawRectangleFrame
 *		WinDrawWindowFrame
 *		WinEnableWindow
 *		WinEraseLine
 *		WinEraseRectangle
 *		WinEraseRectangleFrame
 *		WinEraseWindow
 *		WinGetActiveWindow
 *		WinGetClip
 *		WinGetDisplayExtent
 *		WinGetDisplayWindow
 *		WinGetDrawWindow
 *		WinGetFirstWindow
 *		WinGetFramesRectangle
 *		WinGetWindowExtent
 *		WinGetWindowFrameRect
 *		WinGetWindowsPointer
 *		WinInvertLine
 *		WinInvertRectangle
 *		WinInvertRectangleFrame
 *		WinRestoreBits
 *		WinSaveBits
 *		WinScrollRectangle
 *		WinSetActiveWindow
 *		WinSetClip
 *		WinSetDrawWindow
 *		WinWindowToDisplayPt
 *		
 * DESCRIPTION:
 *	  This file contains the window routines.
 *
 **********************************************************************/
#include <Pilot.h>

// Don't include unless building version 2 Graphics
#if 	GRAPHICS_VERSION == GRAPHICS_VERSION_2 

#include <ScrDriver.h>

/***********************************************************************
 *
 * Internal structures and function
 *
 ***********************************************************************/

enum LineClipCode {clipLineNone=0, clipLineLeft=1, clipLineRight=2, 
	clipLineTop=4, clipLineBottom=8};


void DrawRectangle (RectanglePtr r, Word cornerDiam);

void InitWindowVariables (void);

enum LineClipCode GetClipCode (short x, short y);

void DrawHLine (short x, short y, short width, short height);

void DrawFrame (FrameType frame, RectanglePtr r);

void DrawRoundedRectangle  (RectanglePtr r, short radius, short penWidth,
	Boolean fill);


/***********************************************************************
 *
 * FUNCTION:    InitWindowVariables
 *
 * DESCRIPTION: This routine initializes global variables used by the 
 *              window routines.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:   nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/ 5/95		Initial Revision
 *
 ***********************************************************************/
void InitWindowVariables (void)
{
	WinPtr winPtr;
	WinHandle winHandle;

	// Create and initialize the display window.  Also, set the draw window
	// to the display window and add the display window to the window list.
	// We actually allocate just one pointer from the Memory Manager and
	// store the extended window information after the original window
	//  structure within the same memory chunk in order to reduce the
	// memory overhead. 
	winHandle = MemPtrNew (sizeof (WindowType));
	DisplayWindow = winHandle;  
	DrawWindow = winHandle;
	FirstWindow = winHandle;

	// Initialize to 0's
	winPtr = WinGetWindowPointer (winHandle);
	MemSet (winPtr, sizeof (WindowType), 0);
	
	
	// Tell the screen driver to fill in the info on the display.
	// It will fill in the gDevice pointer with a pointer to the screen
	//  info. 
	ScrScreenInfo (winPtr); 

	// Set the bounds of the display window to the width and height of
	// the physical display.
	//
	winPtr->windowBounds.extent.x = winPtr->gDeviceP->width;
	winPtr->windowBounds.extent.y = winPtr->gDeviceP->height;
	
	// copy the width, height and baseAddr fields for compatibility
	winPtr->displayWidthV20  = winPtr->gDeviceP->width;
	winPtr->displayHeightV20 = winPtr->gDeviceP->height;
	winPtr->displayAddrV20   = winPtr->gDeviceP->baseAddr;

	// Set the clipping bounds to the bounds of the entire window.
	//
	WinResetClip ();

	// Set the current pattern to black and set the foreground color
	// to black and the background color to white
	//
	GState.grafMode = scrCopy;
	GState.pattern = blackPattern;
	GState.foreColor.r = 0x00;
	GState.foreColor.g = 0x00;
	GState.foreColor.b = 0x00;
	GState.backColor.r = 0xFF;
	GState.backColor.g = 0xFF;
	GState.backColor.b = 0xFF;
	
	// Store a pointer to graphic state in the window structure.
	winPtr->gstate = &GState;

	// Start with no active window.
	//
	ActiveWindow = 0;

	// Clear global variables used to track winEnter and winExit events.
	//
	ExitWindowID = 0;
	EnterWindowID = 0;
	
}


/***********************************************************************
 *
 * FUNCTION:    WinSetActiveWindow
 *
 * DESCRIPTION: This routine makes a window the active window.
 *              The active window is not actually set in this routine, flags
 *              are set to indicate that a window is being exited and 
 *              another window is being entered.  The routine 
 *              EvtGetEvent will send a winExitEvent and a winEnterEvent
 *              when it detects these flags.  The active window is set
 *              by EvtGetEvent when it sends the winEnterEvent.  The draw
 *              window is also set to the new active window, when the
 *              active window is changed.
 *
 *              The active window is where all user input is directed.
 *
 * PARAMETERS:  winHandle  handle of the window to make the active window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinSetActiveWindow (WinHandle winHandle)
{
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	if (winHandle != NULL)
		ECWinValidateHandle(winHandle);
#endif
	
	if (winHandle != ActiveWindow)
		{
		if (ActiveWindow)
			ExitWindowID = ActiveWindow;
		EnterWindowID = winHandle;
		}
	else
		{
		EnterWindowID = ActiveWindow;
		}
		
	if (winHandle)
		WinEnableWindow (winHandle);
}


/***********************************************************************
 *
 * FUNCTION:    WinSetDrawWindow
 *
 * DESCRIPTION: This routine sets the draw window.  All drawing operation
 *              are relative to the draw window.
 *
 * PARAMETERS:  winHandle  handle of the window to make the draw window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinSetDrawWindow (WinHandle winHandle)
{
	WinHandle currDrawWindow;
	
	ECWinValidateHandle(winHandle);
	

	currDrawWindow = DrawWindow;
	DrawWindow = winHandle;
	return (currDrawWindow);
}


/***********************************************************************
 *
 * FUNCTION:    WinGetActiveWindow
 *
 * DESCRIPTION: This routine returns the window handle of the active 
 *              window.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    handle of active window
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinGetActiveWindow (void)
{
	return (ActiveWindow);
}


/***********************************************************************
 *
 * FUNCTION:    WinGetDrawWindow
 *
 * DESCRIPTION: This routine returns the window handle of the draw
 *              window.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    handle of draw window
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinGetDrawWindow (void)
{
	return (DrawWindow);
}


/***********************************************************************
 *
 * FUNCTION:    WinGetDisplayWindow
 *
 * DESCRIPTION: This routine returns the window handle of the display
 *              window.  The display window is create by the system at
 *              startup, it size is the same as the physical diplay (screen).
 *
 * PARAMETERS:  none
 *
 * RETURNED:    handle of display window
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinGetDisplayWindow (void)
{
	return (DisplayWindow);
}


/***********************************************************************
 *
 * FUNCTION:    WinGetFirstWindow
 *
 * DESCRIPTION: This routine returns a pointer to the first window in
 *              the linked list of windows.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    handle of first window
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle  WinGetFirstWindow (void)
{
	return (FirstWindow);	
}


/***********************************************************************
 *
 * FUNCTION:    WinEnableWindow
 *
 * DESCRIPTION: This routine enables a window.  Enabled window will
 *              accept pen input and can be made the active window
 *
 *              This routine does not affect the visual appearance of 
 *              the window.
 *
 * PARAMETERS:  winHandle    handle of window to enable
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinEnableWindow (WinHandle winHandle)
{
	WinPtr winPtr;

	ECWinValidateHandle(winHandle);
	
	// The display window can not be the active window.
	//
	if (winHandle != DisplayWindow)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.format == screenFormat)
			winPtr->windowFlags.enabled = true;
		}
}


/***********************************************************************
 *
 * FUNCTION:    WinDisableWindow
 *
 * DESCRIPTION: This routine disables a window.  Disabled window will
 *              ignore all pen input and can not be made the active
 *              window.
 *
 *              This routine does not affect the visual appearance of 
 *              the window.
 *
 * PARAMETERS:  winHandle    handle of window to disable
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinDisableWindow (WinHandle winHandle)
{
	WinPtr winPtr;

	ECWinValidateHandle(winHandle);
	
	winPtr = WinGetWindowPointer (winHandle);
	winPtr->windowFlags.enabled = false;

}


/***********************************************************************
 *
 * FUNCTION:    WinGetWindowsPointer
 *
 * DESCRIPTION: This routine returns a pointer to the WindowType
 *              structure of the specified window.
 *
 * PARAMETERS:  winHandle    handle of a window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
//WinPtr WinGetWindowPointer (WinHandle winHandle)
//{
//	return (*winHandle);
//}


/***********************************************************************
 *
 * FUNCTION:    WinCreateWindow
 *
 * DESCRIPTION: This routine creates a new window and adds it to the 
 *              window list.  Windows create by this routine will 
 *              draw to the display, see WinCreateOffscreenWindow
 *              we create a window the draw to a memory buffer.
 *
 *              New windows are created disabled, they must be enabled 
 *              before they will accept input.
 *
 * PARAMETERS:  bounds    display relative bounds of the window
 *              frame     type of frame around the window
 *              modal     TRUE if the window is modal
 *              focusable TRUE if the window can be the active window
 *              error     pointer to any error encountered by this function
 *              
 * RETURNED:    handle of the new window.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinCreateWindow (RectanglePtr bounds, FrameType frame, 
	Boolean modal, Boolean focusable, WordPtr error)

{
	WinHandle newWinHandle;
	WinPtr    newWinPtr;

	*error = 0;

	// Create and initialize the window.  
	// We actually allocate just one pointer from the Memory Manager and
	// store the extended window information after the original window
	//  structure within the same memory chunk in order to reduce the
	// memory overhead. 
	newWinHandle = MemPtrNew (sizeof (WindowType));
	ErrFatalDisplayIf( (! newWinHandle), "Error creating window");

	newWinPtr = WinGetWindowPointer (newWinHandle);
	MemSet (newWinPtr, sizeof (WindowType), 0);

	MemMove (&newWinPtr->windowBounds, bounds, sizeof (RectangleType));
	newWinPtr->windowFlags.modal = modal;
	newWinPtr->windowFlags.focusable = focusable;
	newWinPtr->frameType.word = frame;

	// Initialize the device dependent information in the WindowType structure
   // and reset the clipping bounds.
	//
	WinInitializeWindow (newWinHandle);

	// Add the window to the window list.
	//
	WinAddWindow (newWinHandle);

	return (newWinHandle);
}


/***********************************************************************
 *
 * FUNCTION:    WinCreateOffscreenWindow
 *
 * DESCRIPTION: This routine creates a new window and adds it to the 
 *              window list.  Windows created with this routine will
 *              draw to a memory buffer instead of the display.
 *
 *              The memory buffer has two formats: screen format and 
 *              generic format.  Srceen format is the native format of the
 *              video system, window in this format can be copied to the
 *              display faster.  The generic format is device independent.
 *
 * PARAMETERS:  width    width of the window in pixels
 *              height   height of the window in pixels
 *              format   screen (native) or generic
 *              error    pointer to any error encountered by this function
 *
 * RETURNED:    handle of the new window.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinCreateOffscreenWindow (short width, short height,
	WindowFormatType format, WordPtr error)
{
	VoidHand	 winH, imageH;
	WinHandle drawWindow;
	WinHandle newWinHandle;
	WinPtr    newWinPtr;
	WinPtr    drawWinPtr;
	UInt		 depth;
	Word		 rowBytes;

	ErrNonFatalDisplayIf( ((width == 0) || (height == 0)), 
		"Invalid window size");

	*error = 0;

	// Get the draw window pointer so we can clone it's bit depth
	drawWinPtr = WinGetWindowPointer (DrawWindow);
	depth = drawWinPtr->gDeviceP->pixelSize;

	// Allocate the window and a buffer to hold its image.
	winH = MemHandleNew (sizeof (WindowType) + sizeof(GDeviceType));
	if (! winH) return (0);
	
	// Create a display buffer for the window.  Round the line width
	// up to an even word boundary. 
	// (width*depth + (sizeof (Word) - 1)) / sizeof (Word) * bytes per Word.
	rowBytes = (((width*depth) + 15) >> 4) << 1;
	imageH = MemHandleNew (rowBytes * height );
	if (! imageH)
		{
		MemHandleFree (winH);
		return (0);
		}
	
	drawWindow = DrawWindow;

	newWinHandle = MemHandleLock (winH);
	newWinPtr = WinGetWindowPointer (newWinHandle);
	MemSet (newWinPtr,sizeof (WindowType) + sizeof(GDeviceType), 0);
		
	// The space for the GDevice was allocated after the WindowType
	newWinPtr->gDeviceP = (GDevicePtr)(((BytePtr)newWinPtr) + sizeof(WindowType));
	newWinPtr->gDeviceP->baseAddr = MemHandleLock (imageH);
	newWinPtr->gDeviceP->width = width;
	newWinPtr->gDeviceP->height = height;
	newWinPtr->gDeviceP->pixelSize = depth;
	newWinPtr->gDeviceP->rowBytes = rowBytes;

	newWinPtr->windowBounds.extent.x = width;
	newWinPtr->windowBounds.extent.y = height;
	newWinPtr->windowFlags.format = format;
	newWinPtr->windowFlags.offscreen = true;
	
	newWinPtr->gstate = &GState;

	// copy these three fields for compatibility
	newWinPtr->displayWidthV20  = newWinPtr->gDeviceP->width;
	newWinPtr->displayHeightV20 = newWinPtr->gDeviceP->height;
	newWinPtr->displayAddrV20   = newWinPtr->gDeviceP->baseAddr;

	// Add the window to the window list
	//
	WinAddWindow (newWinHandle);

	// Reset the clipping bounds.
	//
	DrawWindow = newWinHandle;
	WinResetClip ();
	DrawWindow = drawWindow;

	return (newWinHandle);
}


/***********************************************************************
 *
 * FUNCTION:    WinDeleteWindow
 *
 * DESCRIPTION: This routine removes a window from the window list and
 *              frees the memory used by the window.
 *
 * PARAMETERS:  winHandle  handle of window to delete
 *              eraseIt    if TRUE the window is erase before it is deleted
 *              error      pointer to any error encountered by this function
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinDeleteWindow (WinHandle winHandle, Boolean eraseIt)
{
	WinHandle  drawWindow;
	WinPtr     winPtr;
	RectangleType frameRect;

	// The display window may not be deleted.
	//
	ErrFatalDisplayIf((winHandle == DisplayWindow), 
		"Can delete display window");
	
	ECWinValidateHandle(winHandle);
	
	// If the window being deleted is the draw window, make the display
	// window the draw window.
	//
	if (winHandle == DrawWindow)
		DrawWindow = DisplayWindow;

	// If the window being deleted is the active window, set the global
	// variable that will cause a winExitEvent to be generated.
	//
	if (winHandle == ActiveWindow)
		{
		ExitWindowID = winHandle;
		ActiveWindow = 0;
		}

	// If the eraseIt parameter is true and the window is on screen, erase
	// the window and its frame.
	//
	winPtr = WinGetWindowPointer (winHandle);
	if ((! winPtr->windowFlags.offscreen) && eraseIt)
		{
		WinGetWindowFrameRect (winHandle, &frameRect);
		drawWindow = DrawWindow;
		DrawWindow = DisplayWindow;
		WinEraseRectangle (&frameRect, 0);
		DrawWindow = drawWindow;
		}

	// Remove the window from the window list.
	//
	WinRemoveWindow (winHandle);

	// If the window is an off-screen window, free its display memory buffer.
	//
	if (winPtr->windowFlags.offscreen)
		MemPtrFree (winPtr->gDeviceP->baseAddr);
	
	
	// If the gDevicePtr was allocated dynamically and does not belong to
	//  the screen driver, free it
	if (winPtr->gDeviceP && winPtr->gDeviceP->dynamic && !winPtr->gDeviceP->forDriver)
		MemPtrFree(winPtr->gDeviceP);
		
	MemPtrFree (winHandle);
}


/***********************************************************************
 *
 * FUNCTION:    WinInitializeWindow
 *
 * DESCRIPTION: This routine initializes the sreeen dependent members
 *              of a WindowType structure and sets the clipping bound
 *              of the window to the bounds of the window.
 *
 * PARAMETERS:  winHandle  handle of a window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/16/94		Initial Revision
 *
 ***********************************************************************/
void WinInitializeWindow (WinHandle winHandle)
{
	WinHandle drawWindow;
	WinPtr    displayWinPtr;
	WinPtr    winPtr;
	
	drawWindow = DrawWindow;

	displayWinPtr = WinGetWindowPointer (DisplayWindow);
	winPtr = WinGetWindowPointer (winHandle);

	// We set the gDevice pointer to be the same as the display window's
	// gDevice pointer which is the screen driver's gDevice. Since the
	// screen driver's gDevice has the forDriver flag set, it won't get
	// disposed of by WinDeleteWindow.
	winPtr->gDeviceP = displayWinPtr->gDeviceP;
	
	winPtr->gstate = &GState;
	
	// copy these three fields for compatibility
	winPtr->displayWidthV20  = winPtr->gDeviceP->width;
	winPtr->displayHeightV20 = winPtr->gDeviceP->height;
	winPtr->displayAddrV20   = winPtr->gDeviceP->baseAddr;

	DrawWindow = winHandle;
	WinResetClip ();

	DrawWindow = drawWindow;
}


/***********************************************************************
 *
 * FUNCTION:    WinAddWindow
 *
 * DESCRIPTION: This routine adds the specified window to the 
 *              active windows list.
 *
 * PARAMETERS:  winHandle  handle of the window 
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinAddWindow (WinHandle winHandle)
{
	WinPtr    winPtr;
	
	winPtr = WinGetWindowPointer (winHandle);
	
	ErrNonFatalDisplayIf(FirstWindow == winPtr, "Window already added");
	winPtr->nextWindow = FirstWindow;
	FirstWindow = winHandle;

	ECWinValidateHandle(winHandle);
}


/***********************************************************************
 *
 * FUNCTION:    WinRemoveWindow
 *
 * DESCRIPTION: This routine removes the specified window from the 
 *              window list.
 *
 * PARAMETERS:  winHandle
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/16/94		Initial Revision
 *
 ***********************************************************************/
void WinRemoveWindow (WinHandle winHandle)
{
	WinHandle handle;
	WinPtr    winPtr;
	WinPtr    ptr = 0;

	ECWinValidateHandle(winHandle);
	
	handle = FirstWindow;
	winPtr = WinGetWindowPointer (winHandle);

	while (handle)
		{
		if (handle == winHandle)
			{
			if (winHandle == FirstWindow)
				FirstWindow = winPtr->nextWindow;
			else
				ptr->nextWindow = winPtr->nextWindow;
			break;
			}

		ptr = WinGetWindowPointer (handle);
		handle = ptr->nextWindow;
		}
}


/***********************************************************************
 *
 * FUNCTION:    WinMoveWindowAddr
 *
 * DESCRIPTION: Update references to a window from an old location to a 
 *              new location.
 *
 * PARAMETERS:  winHandle
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/25/97	Initial Revision
 *
 ***********************************************************************/
void WinMoveWindowAddr (WinPtr oldLocationP, WinPtr newLocationP)
{
	WinHandle oldLocationH, newLocationH;
	WinPtr    winPtr;

	newLocationH = WinGetWindowHandle (newLocationP);
	ECWinValidateHandle(newLocationH);
	oldLocationH = WinGetWindowHandle (oldLocationP);
	
	// Update the window in the window list
	winPtr = WinGetWindowPointer (FirstWindow);
	if (winPtr == oldLocationP)
		FirstWindow = newLocationH;
	else
		{
		// Search through for a pointer to the old location.
		while (winPtr->nextWindow)
			{
			if (winPtr->nextWindow == oldLocationP)
				{
				winPtr->nextWindow = newLocationP;
				break;
				}

			winPtr = winPtr->nextWindow;
			}
		}
	
	if (DrawWindow == oldLocationH)
		DrawWindow = newLocationH;
	
	if (DisplayWindow == oldLocationH)
		DisplayWindow = newLocationH;
	
	if (ActiveWindow == oldLocationH)
		ActiveWindow = newLocationH;
	
}


/***********************************************************************
 *
 * FUNCTION:    WinEraseWindow
 *
 * DESCRIPTION: This routine erases the contents of the draw window. 
 *              The frame around the draw window is not erase by this
 *              routine.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinEraseWindow (void)
{
	RectangleType r;
	WinPtr     winPtr;
	WinHandle  drawWindow;

	winPtr = WinGetWindowPointer (DrawWindow);
	RctSetRectangle (&r, 0, 0, winPtr->windowBounds.extent.x,
		winPtr->windowBounds.extent.y);

	drawWindow = DrawWindow;
	WinEraseRectangle (&r, 0);
	DrawWindow = drawWindow;
}


/***********************************************************************
 *
 * FUNCTION:    WinSaveBits
 *
 * DESCRIPTION: This routine creates an offscreen window and copies the
 *              specified region from the draw window to the offscreen
 *              window.  The offscreen window is the same size as the
 *              region to copy.
 *
 * PARAMETERS:  source   pointer to the bounds of the region to save
 *              error    pointer to any error encountered by this function
 *
 * RETURNED:    the handle of the window containing the saved image, or
 *              zero if an error occurred.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
WinHandle WinSaveBits (RectanglePtr sourceP, WordPtr error)
{
	WinHandle saveWinH;
	WinPtr	saveWinP;
	ULong		size;
	Err		err;
	
	
	// Create the offscreen window.
	saveWinH = WinCreateOffscreenWindow (sourceP->extent.x, sourceP->extent.y, 
		screenFormat, error);
	if (! saveWinH) return(0);
		
	// Store bits in compressed format if the top left coordinate is >= 0
	saveWinP = WinGetWindowPointer(saveWinH);
	saveWinP->gDeviceP->compressed = true;
		
	// initialize the size field of the compressed data to 0 so that we can detect the
	// case where the WinCopyRectangleRoutine returns without doing anything (when totally clipped).
	*((WordPtr)saveWinP->gDeviceP->baseAddr) = 0;
		
	// Save the bits
	WinCopyRectangle (0, saveWinH, sourceP, 0, 0, scrCopy);
	
	
	// Shrink the pointer used to store the bits if the compression was successful
	// The actual size of the compressed data is stored in the first word of
	//  the bits.
	if (saveWinP->gDeviceP->compressed) {
		size = *((WordPtr)saveWinP->gDeviceP->baseAddr);
		if (size) {
			err = MemPtrResize(saveWinP->gDeviceP->baseAddr, size);
			ErrFatalDisplayIf(err, "Resize error");
			}
		// If the size is 0, it means that WinCopyRectangle didn't even call the screen driver
		//  and nothing was saved.
		else
			saveWinP->gDeviceP->compressed = false;
		}

	return (saveWinH);
}


/***********************************************************************
 *
 * FUNCTION:    WinRestoreBits
 *
 * DESCRIPTION: This routine copies the contents of the specified window
 *              to the draw window, and deletes the passed window.  This
 *              routine is generally used to restore a region of the
 *              display that were saved with WinSaveBits.
 *
 * PARAMETERS:  winHandle  handle of window to copy and delete
 *              destX      x coordinate in the draw window to copy to
 *              destY      y coordinate in the draw window to copy to
 *              error      pointer to any error encountered by this function
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinRestoreBits (WinHandle winHandle, short destX, short destY)
{
	WinPtr    winPtr;
	
	if (! winHandle) return;
	
	ECWinValidateHandle(winHandle);
	
	winPtr = WinGetWindowPointer (winHandle);
	WinCopyRectangle (winHandle, 0, &winPtr->windowBounds, destX, destY, scrCopy);
	WinDeleteWindow (winHandle, false);
}

/***********************************************************************
 *
 * FUNCTION:    WinDrawWindowFrame
 *
 * DESCRIPTION: This routine draw the frame of the window that is
 *              currently the draw window.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawWindowFrame (void)
{
	WinHandle drawWindow;
	WinPtr    winPtr;

	drawWindow = DrawWindow;
	DrawWindow = DisplayWindow;
	winPtr = WinGetWindowPointer (drawWindow);
	WinDrawRectangleFrame (winPtr->frameType.word, &winPtr->windowBounds);
	DrawWindow = drawWindow;
}


/***********************************************************************
 *
 * FUNCTION:    WinGetWindowFrameRect
 *
 * DESCRIPTION: This routine returns a rectangle, in display relative
 *              coordinates, that defines the size and location of a 
 *              window and its frame.
 *
 * PARAMETERS:  winHandle  handle of window whose coordinates are desired
 *              r          pointer to the coordinates of the window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinGetWindowFrameRect (WinHandle winHandle, RectanglePtr r)
{
	WinPtr    winPtr;

	ECWinValidateHandle(winHandle);
	
	winPtr = WinGetWindowPointer (winHandle);
	WinGetFramesRectangle (winPtr->frameType.word, &winPtr->windowBounds, r);
}


/***********************************************************************
 *
 * FUNCTION:    WinGetFramesRectangle
 *
 * DESCRIPTION: This function returns the region needed to draw a 
 *              a rectangle with the specified frame around it.  Frames 
 *              are always drawn around (outside) a rectangle.
 *
 * PARAMETERS:  frame        type of frame drawn around the rectangle
 *              r            pointer to the rectangle to frame
 *              obscuredRect pointer to the rectangle obscured by the frame
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
void WinGetFramesRectangle (FrameType frame, RectanglePtr r, 
	RectanglePtr obscuredRect)
{
	FrameBitsType frameType;

	frameType.word = frame;
	MemMove (obscuredRect, r, sizeof(RectangleType));

	// Outset the rectangle by the width of the frame.
	//
	RctInsetRectangle (obscuredRect, -frameType.bits.width);

	// Add the width of the shodow to the right and botton sides of the
	// rectangle.
	//
	obscuredRect->extent.x += frameType.bits.shadowWidth;
	obscuredRect->extent.y += frameType.bits.shadowWidth;
}


/***********************************************************************
 *
 * FUNCTION:    WinGetWindowExtent
 *
 * DESCRIPTION: This routine returns the width and height of the current 
 *              draw window.
 *
 * PARAMETERS:  extentX  pointer to the width of the draw window
 *              extentY  pointer to the height of the draw window
 * 
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinGetWindowExtent (SWordPtr extentX, SWordPtr extentY)
{
	WinPtr    winPtr;

	winPtr = WinGetWindowPointer (DrawWindow);

	if (extentX)
		*extentX = winPtr->windowBounds.extent.x;

	if (extentY)
		*extentY = winPtr->windowBounds.extent.y;
}


/***********************************************************************
 *
 * FUNCTION:    WinGetWindowBounds
 *
 * DESCRIPTION: This routine returns the bounds of the current 
 *              draw window in display relative coordinates.
 *
 * PARAMETERS:  nothing
 * 
 * RETURNED:    pointer to a rectangle
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/3/95	Initial Revision
 *
 ***********************************************************************/
void WinGetWindowBounds (RectanglePtr r)
{
	WinPtr    winPtr;

	winPtr = WinGetWindowPointer (DrawWindow);
	RctCopyRectangle (&winPtr->windowBounds, r);

}


/***********************************************************************
 *
 * FUNCTION:    WinSetWindowBounds
 *
 * DESCRIPTION: Set the bounds of the window to display relative coordinates.
 *
 * PARAMETERS:  winHandle
 *					 r - pointer to a rectangle to use for bounds.
 * 
 * RETURNED:    pointer to a rectangle
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/14/96	Initial Revision - needs fixing to handle other cases.
 *
 ***********************************************************************/
void WinSetWindowBounds (WinHandle winHandle, RectanglePtr r)
{
	WinPtr    winPtr;

	ECWinValidateHandle(winHandle);
	
	winPtr = WinGetWindowPointer (winHandle);
	
	ErrFatalDisplayIf(winPtr->windowFlags.visible, "Visible windows can't change bounds");
	
	RctCopyRectangle (r, &winPtr->windowBounds);
	
	
//	WinResetClip();
}


/***********************************************************************
 *
 * FUNCTION:    WinGetDisplayExtent
 *
 * DESCRIPTION: This routine returns the width and height of the display
 *              (the screen).
 *
 * PARAMETERS:  extentX  pointer to the width of the display
 *              extentY  pointer to the height of the display
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinGetDisplayExtent (SWordPtr extentX, SWordPtr extentY)
{
	WinPtr    winPtr;

	winPtr = WinGetWindowPointer (DisplayWindow);
	*extentX = winPtr->windowBounds.extent.x;
	*extentY = winPtr->windowBounds.extent.y;

}


/***********************************************************************
 *
 * FUNCTION:    WinWindowToDisplayPt
 *
 * DESCRIPTION: This routine converts a window-relative coordinate to
 *              a display-relative coordinate.  The coordinate passed is 
 *              assumed to be relative to the draw window.
 *
 * PARAMETERS:  x   pointer to x coordinate to convert
 *              y   pointer to y coordinate to convert
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinWindowToDisplayPt (SWordPtr x, SWordPtr y)
{
	WinPtr    winPtr;

	winPtr = WinGetWindowPointer (DrawWindow);
	*x += winPtr->windowBounds.topLeft.x;
	*y += winPtr->windowBounds.topLeft.y;
}


/***********************************************************************
 *
 * FUNCTION:    WinDisplayToWindowPt
 *
 * DESCRIPTION: This routine converts a display-relative coordinate to
 *              a window-relative coordinate.  The coordinate returned is 
 *              relative to the display window.
 *
 * PARAMETERS:  x   pointer to x coordinate to convert
 *              y   pointer to y coordinate to convert
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinDisplayToWindowPt (SWordPtr x, SWordPtr y)
{
	WinPtr    winPtr;

	winPtr = WinGetWindowPointer (DrawWindow);
	*x -= winPtr->windowBounds.topLeft.x;
	*y -= winPtr->windowBounds.topLeft.y;
}


/***********************************************************************
 *
 * FUNCTION:    WinGetClip
 *
 * DESCRIPTION: This routine returns the clipping rectangle of the 
 *              draw window.
 *
 * PARAMETERS:  pointer to a structure to hold the clipping bounds
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinGetClip (RectanglePtr r)
{
	WinPtr  winPtr;
	short      left, top;

	winPtr = WinGetWindowPointer (DrawWindow);
	left = winPtr->clippingBounds.left;
	top = winPtr->clippingBounds.top;

	r->topLeft.x = left;
	r->topLeft.y = top;
	r->extent.x =  winPtr->clippingBounds.right - left + 1;
	r->extent.y =  winPtr->clippingBounds.bottom - top + 1;
}


/***********************************************************************
 *
 * FUNCTION:    WinSetClip
 *
 * DESCRIPTION: This routine sets the clipping rectangle of the draw 
 *              window.
 *
 * PARAMETERS:  pointer to a structure holding the clipping bounds
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinSetClip (RectanglePtr r)
{
	WinPtr     winPtr;
	RectangleType clip;

	WinResetClip ();

	MemMove (&clip, r, sizeof (RectangleType));
	WinClipRectangle (&clip);

	winPtr = WinGetWindowPointer (DrawWindow);
	winPtr->clippingBounds.left = clip.topLeft.x;
	winPtr->clippingBounds.top = clip.topLeft.y;
	winPtr->clippingBounds.right = clip.topLeft.x + clip.extent.x - 1;
	winPtr->clippingBounds.bottom = clip.topLeft.y + clip.extent.y - 1;
}


/***********************************************************************
 *
 * FUNCTION:    WinResetClip
 *
 * DESCRIPTION: This routine resets the clipping rectangle of the draw 
 *              window to the portion of the draw window that is within the 
 *              bounds of the display. 
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinResetClip (void)
{
	WinPtr winPtr;

	winPtr = WinGetWindowPointer (DrawWindow);

	winPtr->clippingBounds.left = 0;
	winPtr->clippingBounds.top = 0;
	

	winPtr->clippingBounds.right = min (
		winPtr->windowBounds.extent.x,
		winPtr->gDeviceP->width - winPtr->windowBounds.topLeft.x) - 1;

	winPtr->clippingBounds.bottom = min
		(winPtr->windowBounds.extent.y,
		 winPtr->gDeviceP->height - winPtr->windowBounds.topLeft.y) - 1;
}


/***********************************************************************
 *
 * FUNCTION:    WinClipRectangle
 *
 * DESCRIPTION: This routine clips a rectangle to the clipping rectangle
 *              of the draw window.  The rectangle returns is the 
 *              intersection of the rectangle passed and the draw window's
 *              clipping bounds.
 *
 * PARAMETERS:  pointer to a structure holding the rectangle to clip
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
void WinClipRectangle (RectanglePtr r)
{
	WinPtr    winPtr;
	short        right, bottom;

	winPtr = WinGetWindowPointer (DrawWindow);

	// Clip the left bound of the rectangle.
	//
	if (winPtr->clippingBounds.left > r->topLeft.x)
		{
		r->extent.x -= winPtr->clippingBounds.left - r->topLeft.x;
		if (r->extent.x < 0)
			 r->extent.x = 0;
		r->topLeft.x = winPtr->clippingBounds.left;
		}
	else if (winPtr->clippingBounds.right < r->topLeft.x)
		{
		r->topLeft.x = winPtr->clippingBounds.right;
		r->extent.x = 0;
		}

	// Clip the top bound of the rectangle.
	//
	if (winPtr->clippingBounds.top > r->topLeft.y)
		{
		r->extent.y -= winPtr->clippingBounds.top - r->topLeft.y;
		if (r->extent.y < 0)
			 r->extent.y = 0;
		r->topLeft.y = winPtr->clippingBounds.top;
		}
	else if (winPtr->clippingBounds.bottom < r->topLeft.y)
		{
		r->topLeft.y = winPtr->clippingBounds.bottom;
		r->extent.x = 0;
		}

	// Clip the right bound of the rectangle.
	//
	right = winPtr->clippingBounds.right;
	if (right < r->topLeft.x)
		{
		r->topLeft.x = right;
		r->extent.x = 0;
		}
	else if (right < r->topLeft.x + r->extent.x - 1)
		{
		r->extent.x = right - r->topLeft.x + 1;
		}

	// Clip the bottom bound of the rectangle.
	//
	bottom = winPtr->clippingBounds.bottom;
	if (bottom < r->topLeft.y)
		{
		r->topLeft.y = bottom;
		r->extent.y = 0;
		}
	else if (bottom < r->topLeft.y + r->extent.y - 1)
		{
		r->extent.y = bottom - r->topLeft.y + 1;
		}
}


/***********************************************************************
 *
 * FUNCTION:    WinScrollRectangle
 *
 * DESCRIPTION: This routine scrolls a rectangle in the draw window. 
 *              The rectangle scrolls within its its own bounds, any 
 *              portion of the rectangle that is scrolled outside its
 *              bounds is clipped.
 *
 * PARAMETERS:  r           pointer to the rectangle to scroll
 *              direction   direction to scroll (up, down, left, or right)
 *              distance    distance to scroll in pixels
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinScrollRectangle (RectanglePtr pRect, DirectionType direction, 
	short distance, RectanglePtr vacated)
{
	RectangleType r;
	PointType dest;

	MemMove (&r, pRect, sizeof(r));
	MemMove (vacated, pRect, sizeof(r));
	dest.x = r.topLeft.x;
	dest.y = r.topLeft.y;

	if (direction <= down)  // up or dowm
		{
		r.extent.y -= distance;
		vacated->extent.y = distance;
		if (direction == up)
			{
			r.topLeft.y += distance;
			vacated->topLeft.y += r.extent.y;
			}
		else
			{
			dest.y += distance;
			}
		}
	else                   // left or right
		{
		r.extent.x -= distance;
		vacated->extent.x = distance;
		if (direction == left)
			{
			r.topLeft.x += distance;
			vacated->topLeft.x += r.extent.x;
			}
		else
			dest.x += distance;
		}
	WinCopyRectangle (0, 0, &r, dest.x, dest.y, scrCopy);
	
	
}


/***********************************************************************
 *
 * FUNCTION:    WinCopyRectangle
 *
 * DESCRIPTION: This function copies a rectanglar region from one place
 *              to another (either between windows or within a single
 *              window).
 *
 * PARAMETERS:  srcWin   window from which the rectangle is copied
 *              dstWin   window to which the rectangle is copied
 *              srcRect  bounds of the region to copy
 *              destX    top bound of the rectangle in the destination window
 *              destY    left bound of the rectangle in the destination window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/15/94		Initial Revision
 *
 ***********************************************************************/
void WinCopyRectangle (WinHandle srcWin, WinHandle dstWin,
	RectanglePtr srcRect, short destX, short destY, ScrOperation mode)
{
	WinHandle drawWin;
	WinPtr srcPtr, dstPtr;
	RectangleType r1, r2;

	GState.grafMode = mode;
	GState.patternMode = false;

	drawWin = WinGetDrawWindow ();

	//	If the source window is not specified use the draw window.
	if (! srcWin) srcWin = drawWin;
	ECWinValidateHandle(srcWin);

	//	If the destination window is not specified use the draw window.
	if (! dstWin) dstWin = drawWin;
	ECWinValidateHandle(dstWin);
	
	// Clip the source rectangle to the clipping bound of the source window.
	MemMove (&r1, srcRect, sizeof(RectangleType));
	WinSetDrawWindow (srcWin);
	WinClipRectangle (&r1);

	// If the source rectangle was clipped, offset the destination
	// coordinate by the amount clipped.
	destX += r1.topLeft.x - srcRect->topLeft.x;
	destY += r1.topLeft.y - srcRect->topLeft.y;

	// If the source rectangle is outside the bounds of the display 
	//  then adjust the clipping offset.
//	if (srcRect->topLeft.x < 0)
//		destX += srcRect->topLeft.x;
//	if (srcRect->topLeft.y < 0)
//		destY += srcRect->topLeft.y;		

	// Clip the destination rectangle to the clipping bound of the destination
	// window.
	RctSetRectangle (&r2, destX, destY, r1.extent.x, r1.extent.y);
	WinSetDrawWindow (dstWin);
	WinClipRectangle (&r2);

	// If the destination rectangle was clipped, substract the amount 
	// clipped from the source rectangle.
	r1.topLeft.x += r2.topLeft.x - destX;
	r1.extent.x  -= r2.topLeft.x - destX;
	r1.topLeft.y += r2.topLeft.y - destY;
	r1.extent.y  -= r2.topLeft.y - destY;

	// Determine the width and height of the region to copy.
	r2.extent.x = min (r1.extent.x, r2.extent.x );
	r2.extent.y = min (r1.extent.y, r2.extent.y );

	// If nothing to copy, exit.
	if (! (r2.extent.x <= 0  ||  r2.extent.y <= 0))
		{
		srcPtr = WinGetWindowPointer (srcWin);
		dstPtr = WinGetWindowPointer (dstWin);
		ScrCopyRectangle (
			srcPtr,
			dstPtr,
			r1.topLeft.x + srcPtr->windowBounds.topLeft.x,
			r1.topLeft.y + srcPtr->windowBounds.topLeft.y,
			r2.topLeft.x + dstPtr->windowBounds.topLeft.x,
			r2.topLeft.y + dstPtr->windowBounds.topLeft.y,
			r2.extent.x,
			r2.extent.y);
		}

	WinSetDrawWindow (drawWin);
}


/***********************************************************************
 *
 * FUNCTION:    DrawChars
 *
 * DESCRIPTION: This function draws, erases or inverts the number of 
 *              characters specified in the draw window.
 *
 * PARAMETERS:  chars    pointer to the characters to draw
 *              len      number of characters to draw
 *              x        left bound of first character to draw
 *              y        right bound of first character to draw
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/28/94		Initial Revision
 *
 ***********************************************************************/
static void DrawChars (const Char * const chars, Word len, short x, short y)
{
	AbsRectType clip;
	WinPtr   winPtr;
	short       charRight;
	short       charBottom;
	short       charWidth;
	const Char * charsStart = chars;		// Where in the chars to start drawing chars

	if (! len) return;

	winPtr = WinGetWindowPointer (DrawWindow);

	// Initial the structure that hold the partial character clipping 
	// information.
	//
	clip.left = 0;
	clip.top = 0;
	clip.right = 0;
	clip.bottom = 0;

	// Check if the string fits needs to be clipped.
	//
	charBottom = y + FntLineHeight () - 1;
	charRight = x + FntCharsWidth (charsStart, len) - 1;

	if (x < winPtr->clippingBounds.left ||
		 y < winPtr->clippingBounds.top ||
		 charRight > winPtr->clippingBounds.right ||
		 charBottom > winPtr->clippingBounds.bottom)
		{

		// If the strings is completely outside the clipping region, exit
		//
		if (x >= winPtr->clippingBounds.right ||
			 y >= winPtr->clippingBounds.bottom ||
			 charRight <= winPtr->clippingBounds.left ||
			 charBottom <= winPtr->clippingBounds.top)
			return;

		// Clip the top of the text string.
		//
		if (y < winPtr->clippingBounds.top)
			{
			clip.top = winPtr->clippingBounds.top - y;
			y = winPtr->clippingBounds.top;
			}

		// Clip the bottom of the text string.
		//
		if (charBottom > winPtr->clippingBounds.bottom)
			{
			clip.bottom = charBottom - winPtr->clippingBounds.bottom;
			charBottom = winPtr->clippingBounds.bottom;
			}

		// Clip the left bound of the character string.  Skip characters that
		// are outside the clipping region.
		//
		if (x < winPtr->clippingBounds.left)
			{
			while (len)
				{
				charWidth = FntCharWidth (*charsStart);
				if (x + charWidth >= winPtr->clippingBounds.left)
					break;
				x += charWidth;
				charsStart++;
				len--;
				}
			clip.left = winPtr->clippingBounds.left - x;
			x = winPtr->clippingBounds.left;
			}

		// Clip the right bound of the character string.  Skip characters that
		// are outside the clipping region.
		//
		if (charRight > winPtr->clippingBounds.right)
			{
			while (len)
				{
				charWidth = FntCharWidth (charsStart[len-1]);
				if (charRight - charWidth < winPtr->clippingBounds.right)
					break;
				charRight -= charWidth;
				len--;
				}
			clip.right = charRight - winPtr->clippingBounds.right ;
			charRight = winPtr->clippingBounds.right;
			}
		}

	ScrDrawChars (winPtr,
					  winPtr->windowBounds.topLeft.x + x,
					  winPtr->windowBounds.topLeft.y + y,
					  charRight - x + 1,
					  charBottom - y + 1,
					  clip.top,
					  clip.left,
					  clip.bottom,
					  clip.right,
					  charsStart,
					  len,
					  FntGetFontPtr());

}


/***********************************************************************
 *
 * FUNCTION:    WinDrawChars
 *
 * DESCRIPTION: This function draws the number of characters specified
 *              in the draw window.
 *
 * PARAMETERS:  chars  pointer to the characters to draw
 *              len    number of charactes to draw
 *              x      left bound of first character to draw
 *              y      right bound of first character to draw
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawChars (const Char * const chars, Word len, short x, short y)
{
	GState.grafMode = scrCopy;
	GState.patternMode = false;
	DrawChars (chars, len, x, y);
}

/***********************************************************************
 *
 * FUNCTION:    WinDrawInvertedChars
 *
 * DESCRIPTION: This function draws the number of characters specified
 *              in the draw window.  The characters are drawn in the 
 *              background color and the off pixels or drawn in the 
 *             foreground color.
 *
 * PARAMETERS:  chars  pointer to the characters to draw
 *              len    number of charactes to draw
 *              x      left bound of first character to draw
 *              y      right bound of first character to draw
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/2/96		Initial Revision
 *
 ***********************************************************************/
void WinDrawInvertedChars (const Char * const chars, Word len, short x, short y)
{
	GState.grafMode = scrCopyNOT;
	GState.patternMode = false;
	DrawChars (chars, len, x, y);
}


/***********************************************************************
 *
 * FUNCTION:    WinEraseChars
 *
 * DESCRIPTION: This function erases the number of characters specified
 *              in the draw window.
 *
 * PARAMETERS:  chars  pointer to the characters to erase
 *              len    number of charactes to erase
 *              x      left bound of first character to erase
 *              y      right bound of first character to erase
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinEraseChars (const Char * const chars, Word len, short x, short y)
{
	GState.grafMode = scrANDNOT;
	GState.patternMode = false;
	DrawChars (chars, len, x, y);
}


/***********************************************************************
 *
 * FUNCTION:    WinInvertChars
 *
 * DESCRIPTION: This function inverts the number of characters specified
 *              in the draw window.
 *
 * PARAMETERS:  chars  pointer to the characters to invert
 *              len    number of charactes to invert
 *              x      left bound of first character to invert
 *              y      right bound of first character to invert
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinInvertChars (const Char * const chars, Word len, short x, short y)
{
	GState.grafMode = scrXOR;
	GState.patternMode = false;
	DrawChars (chars, len, x, y);
}

/***********************************************************************
 *
 * FUNCTION:    WinSetUnderlineMode
 *
 * DESCRIPTION: This function set the graphic state to enable or disable
 *              the underlining of characters.  
 *
 * PARAMETERS:  underline  true to enable underlining
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/9/95	Initial Revision
 *
 ***********************************************************************/
UnderlineModeType WinSetUnderlineMode (UnderlineModeType mode)
{
	UnderlineModeType curMode;
	
	curMode = GState.underlineMode;
	GState.underlineMode = mode;
	return (curMode);
}

/***********************************************************************
 *
 * FUNCTION:    GetClipCode
 *
 * DESCRIPTION: This routine returns a value that indicated how the end point
 *              of a lines hould be clipped (left or right, top or bottom).
 *
 * PARAMETERS:  x    line end point coordinate, in the draw window
 *					 y    line end point coordinate, in the draw window
 *
 * RETURNED:    clipping code
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
enum LineClipCode GetClipCode (short x, short y)
{
	WinPtr          winPtr;
	enum LineClipCode  code = clipLineNone;

	winPtr = WinGetWindowPointer (DrawWindow);

	if (x < winPtr->clippingBounds.left)
		code = clipLineLeft;
	else if (x > winPtr->clippingBounds.right)
		code = clipLineRight;

	if (y < winPtr->clippingBounds.top)
		code |= clipLineTop;
	else if (y > winPtr->clippingBounds.bottom)
		code |= clipLineBottom;

	return (code);
}


/***********************************************************************
 *
 * FUNCTION:    DrawLine
 *
 * DESCRIPTION: This routine draws, erases or inverts a line in the 
 *              draw window.
 *
 * PARAMETERS:  x1        x coordinate of the start of the line
 *              y1        y coordinate of the start of the line
 *              x2        x coordinate of the end of the line
 *              y2        y oordinate of the end of the line
 *              drawMode  draw, erase or invert, and whether a pattern
 *                        is used
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
static void DrawLine (short x1, short y1, short x2, short y2)
{
	short             temp;
	WinPtr         winPtr;
	enum LineClipCode lineCode1;
	enum LineClipCode lineCode2;

	winPtr = WinGetWindowPointer (DrawWindow);

	// Clip the line to the draw window's clipping rectangle.
	//
	lineCode2 = GetClipCode (x2, y2);
	while (true)
		{
		lineCode1 = GetClipCode (x1, y1);

		// If both end points are clipped along the same bound, then the 
		// whole line is clipped.
		//
		if (lineCode1 & lineCode2)
			return;
		
		// Check if we're done clipping, we're done if both clipping code 
		// are zero.
		if ((lineCode1 | lineCode2) == 0)
			break;

		if (lineCode1 == 0)
			{
			temp = x1;
			x1 = x2;
			x2 = temp;
			temp = y1;
			y1 = y2;
			y2 = temp;
			lineCode1 = lineCode2;
			lineCode2 = clipLineNone;
			}

		if (lineCode1 & clipLineLeft)
			{
			y1 += (y2 - y1) * (winPtr->clippingBounds.left - x1) / (x2 - x1);
			x1 = winPtr->clippingBounds.left;
			}
		else if (lineCode1 & clipLineRight)
			{
			y1 += (y2 - y1) * (winPtr->clippingBounds.right - x1) / (x2 - x1);
			x1 = winPtr->clippingBounds.right;
			}
		else if (lineCode1 & clipLineTop)
			{
			x1 += (x2 - x1) * (winPtr->clippingBounds.top - y1) / (y2 - y1);
			y1 = winPtr->clippingBounds.top;
			}
		else if (lineCode1 & clipLineBottom)
			{
			x1 += (x2 - x1) * (winPtr->clippingBounds.top - y1) / (y2 - y1);
			y1 = winPtr->clippingBounds.bottom;			
			}
		} // end of clip loop


	// Check if the line is a horizontal or a vertical line.
	//
	if ((x1 != x2) && (y1 != y2))
		{
		ScrLineRoutine (winPtr,
						  	 winPtr->windowBounds.topLeft.x + x1,
							 winPtr->windowBounds.topLeft.y + y1,
							 winPtr->windowBounds.topLeft.x + x2,
							 winPtr->windowBounds.topLeft.y + y2);		
		}
	else
		{
		// If the line is horizontal, make sure x1 is not larger than x2.
		// 
		if (y1 == y2)
			{
			if (x1 > x2)
				{
				temp = x1;
				x1 = x2;
				x2 = temp;
				}
			}
		
		// If the line is verticall, make sure y1 is not larger than y2.
		// 
		else
			{
			if (y1 > y2)
				{
				temp = y1;
				y1 = y2;
				y2 = temp;
				}
			}

		// Draw a horizontal or a vertical line.
		//
		ScrRectangleRoutine (winPtr,
									winPtr->windowBounds.topLeft.x + x1,
									winPtr->windowBounds.topLeft.y + y1,
									x2 - x1 + 1,
									y2 - y1 + 1);		
		}
}


/***********************************************************************
 *
 * FUNCTION:    WinDrawLine
 *
 * DESCRIPTION: This routine draws a line in the draw window
 *
 * PARAMETERS:  x1  x coordinate of the start of the line
 *              y1  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y oordinate of the end of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawLine (short x1, short y1, short x2, short y2)
{
	GState.grafMode = scrCopy;
	GState.patternMode = false;
	DrawLine (x1, y1, x2, y2);
}


/***********************************************************************
 *
 * FUNCTION:    WinEraseLine
 *
 * DESCRIPTION: This routine erases a line in the draw window
 *
 * PARAMETERS:  x1  x coordinate of the start of the line
 *              y1  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y oordinate of the end of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinEraseLine (short x1, short y1, short x2, short y2)
{
	GState.grafMode = scrANDNOT;
	GState.patternMode = false;
	DrawLine (x1, y1, x2, y2);
}


/***********************************************************************
 *
 * FUNCTION:    WinInvertLine
 *
 * DESCRIPTION: This routine inverts a line in the draw window
 *
 * PARAMETERS:  x1  x coordinate of the start of the line
 *              y1  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y oordinate of the end of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinInvertLine (short x1, short y1, short x2, short y2)
{
	GState.grafMode = scrXOR;
	GState.patternMode = false;
	DrawLine (x1, y1, x2, y2);
}


/***********************************************************************
 *
 * FUNCTION:    WinDrawGrayLine
 *
 * DESCRIPTION: This routine draws a line in the draw window
 *
 * PARAMETERS:  x1  x coordinate of the start of the line
 *              y1  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y oordinate of the end of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	12/29/94		Initial Revision
 *			kcr	10/18/95		use vertical striped pattern for horizontal gray lines
 *			bob	1998-01-21	revert to alternating on/off, for back compat.
 *
 ***********************************************************************/
void WinDrawGrayLine (short x1, short y1, short x2, short y2)
{
	PatternType		savePattern;
	Boolean			savePatternMode;
	ScrOperation	saveGrafMode;

	savePattern = GState.pattern;
	savePatternMode = GState.patternMode;
	saveGrafMode = GState.grafMode;
	
	if (y1 == y2) {	//	Horizontal line
		GState.pattern = customPattern;
		GState.customPtn[0] = 0xAAAA;
		GState.customPtn[1] = 0xAAAA;
		GState.customPtn[2] = 0xAAAA;
		GState.customPtn[3] = 0xAAAA;
		}
	else
		GState.pattern = grayPattern;
	GState.grafMode = scrCopy;
	GState.patternMode = true;
	DrawLine (x1, y1, x2, y2);

	GState.pattern = savePattern;
	GState.patternMode = savePatternMode;
	GState.grafMode = saveGrafMode;
}


/***********************************************************************
 *
 * FUNCTION:    WinFillLine
 *
 * DESCRIPTION: This routine fills a line, in the draw window,
 *              with the current pattern.
 *
 * PARAMETERS:  x1  x coordinate of the start of the line
 *              y1  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y oordinate of the end of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinFillLine (short x1, short y1, short x2, short y2)
{
	PatternType savePattern;

	savePattern = GState.pattern;
	GState.pattern = customPattern;
	GState.grafMode = scrCopy;
	GState.patternMode = true;
	DrawLine (x1, y1, x2, y2);
	GState.pattern = savePattern;
}


/***********************************************************************
 *
 * FUNCTION:    DrawHLine
 *
 * DESCRIPTION: This rountine draws a horizontal or a vertical line.
 *
 * PARAMETERS:  x       coordinate of left bound
 *              y       coordinate of top bound
 *              width   horizontal extent of the line
 *              height  vertical extent of the line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/ 4/95		Initial Revision
 *
 ***********************************************************************/
void DrawHLine (short x, short y, short width, short height)
{
	RectangleType rect;

	rect.topLeft.x = x;
	rect.topLeft.y = y;
	rect.extent.x = width;
	rect.extent.y = height;
	DrawRectangle (&rect, 0);
}


/***********************************************************************
 *
 * FUNCTION:    DrawRoundedRectangle
 *
 * DESCRIPTION: This routine draws, erases or inverts a rectangle with
 *              rounded corners or a frame around a rounded rectangle.
 *
 *              A mid-point circle algorithm is used to the genrerate 
 *              the points along 45 degrees of a circle with the radius
 *              specified.  Taking advantage of the symmetry of a cirlce,
 *              we use the generated points to draw the corner points.
 *
 *              A description of the circle algorithm can be found in 
 *              Computers Graphics, by Foley, vanDam, Feiner and Hughes,
 *              second edition, page 83 (see Roger).
 *
 * PARAMETERS:  r         pointer to a rectangle
 *              radius    radius of the corner, the corner is a quarter circle
 *              penWidth  width of the frame
 *              fill      true for filled rectangles, false for frames
 *              grafMode  draw, erase or invert
 *
 * RETURNED:   
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/ 3/95		Initial Revision
 *
 ***********************************************************************/
void DrawRoundedRectangle  (RectanglePtr r, short radius, short penWidth,
	Boolean fill)
{
	RectangleType rect;
	short x, y, d, deltaE, deltaSE;
	short left, top, right, bottom;
	short i, x2, len;
	short xOffset, yOffset;

	left = r->topLeft.x + radius;
	top  = r->topLeft.y + radius;
	right = r->topLeft.x + r->extent.x - radius - 1;
	bottom = r->topLeft.y + r->extent.y - radius - 1;

	// Determine the end point of the sides of the side of the rectangle.
	//
	x = 0;
	y = radius;
	d = 1 - radius;
	deltaE = 3;
	deltaSE = -2 * radius + 5;

	while (y > x)
		{
		if (d < 0)
			{
			d += deltaE;
			deltaE += 2;
			deltaSE += 2;
			x++;
			}
		else
			break;
		}

	// Draw the sides of the rectangle.
	//
	if (! fill)
		{
		for (i = radius; i < radius + penWidth; i++)
			{
			xOffset = x + penWidth - 1;
			DrawLine (left-xOffset, top-i, right+xOffset, top-i);
			DrawLine (left-i, top-xOffset, left-i, bottom+xOffset);
			DrawLine (right+i, top-xOffset, right+i, bottom+xOffset);
			DrawLine (left-xOffset, bottom+i, right+xOffset, bottom+i);
			}
		}

	// If the rectangle is being filled, fill in the center.
	//
	if (fill)
		{
		RctSetRectangle (&rect, r->topLeft.x+1, top-x, 
			r->extent.x-2, bottom-top+(x<<1)+1);
		DrawRectangle (&rect, 0);
		}


	// Check if we have a valid radis, exit if we don't.
	if (right < left) return;

	// Draw the corners of the rectangle.
	//
	x2 = x+1;
	while (y > x)
		{
		if (d < 0)
			{
			d += deltaE;
			deltaE += 2;
			deltaSE += 2;
			x++;
			}
		else
			{
			d += deltaSE;
			deltaE += 2;
			deltaSE += 4;
			x++;
			y--;
			}

		if (fill)
			{
			if (x <= y)
				{
				if (d >= 0) 
					{
					DrawLine (left-x2+1, top-y, right+x2-1, top-y);
					DrawLine (left-x2+1, bottom+y, right+x2-1, bottom+y);
					x2 = x + 1;
					}
				if (x != y)
					{
					DrawLine (left-y+1, top-x, right+y-1, top-x);
					DrawLine (left-y+1, bottom+x, right+y-1, bottom+x);
					}
				}			
			}
		else
			{
			// If the y values is going to change on the next x value
			// draw a corner line segment.
			//
			if (d >= 0)
				{			
				len = x - x2 + penWidth;
				xOffset = x + penWidth - 1;
				yOffset = y + penWidth - 1;
				
				DrawHLine (right+y,      top-xOffset, penWidth, len);
				DrawHLine (right+x2,     top-yOffset, len,      penWidth);
				DrawHLine (left-xOffset, top-yOffset, len,      penWidth);
				DrawHLine (left-yOffset, top-xOffset, penWidth, len);
				DrawHLine (left-yOffset, bottom+x2,   penWidth, len);
				DrawHLine (left-xOffset, bottom+y,    len,      penWidth);
				DrawHLine (right+x2,     bottom+y,    len,      penWidth);
				DrawHLine (right+y,      bottom+x2,   penWidth, len);
				x2 = x+1;
				}
			}
		}		
}


/***********************************************************************
 *
 * FUNCTION:    DrawRectangle
 *
 * DESCRIPTION: This routine draws, erases or inverts a rectangle in the 
 *              draw window.  The rectangle can have square or round 
 *              corners.
 *
 *              The cornerDiam parameter specifies the diameter of 
 *              four imaginary circles that are used to form the rounded
 *              corners.  An imaginary circle is placed within each 
 *              corner tangent to the rectangle on two sides.
 *
 * PARAMETERS:  r           pointer to the rectangle to draw.
 *              cornerDiam  diameter of the rounded corners or zero for
 *                          square corners.
 *              grafMode    draw, erase or invert, and whether a pattern
 *                          is used.
 *
 * RETURNED:   
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void DrawRectangle (RectanglePtr r, Word cornerDiam)
{
	WinPtr winPtr;
	RectangleType rect;

	MemMove (&rect, r, sizeof (RectangleType));

	if (cornerDiam == 0)
		{
		WinClipRectangle (&rect);
		if (rect.extent.x == 0  || rect.extent.y == 0 )
			return;

		winPtr = WinGetWindowPointer (DrawWindow);
		ScrRectangleRoutine (winPtr,
									winPtr->windowBounds.topLeft.x + rect.topLeft.x,
							  		winPtr->windowBounds.topLeft.y + rect.topLeft.y,
									rect.extent.x,
									rect.extent.y);		
		}

	// Draw a rounded rectangle.
	//
	else
		{
		RctInsetRectangle (&rect, -1);
		DrawRoundedRectangle (&rect, cornerDiam, 1, true);
		}
}


/***********************************************************************
 *
 * FUNCTION:    WinDrawRectangle
 *
 * DESCRIPTION: This routine draws a rectangle in the draw window.  The
 *              rectangle can have square or round corners.
 *
 * PARAMETERS:  r           pointer to the rectangle to draw
 *              cornerDiam  diameter of the rounded corners or zero for
 *                          square corners
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawRectangle (RectanglePtr r, Word cornerDiam)
{
	GState.grafMode = scrCopy;
	GState.patternMode = false;
	DrawRectangle (r, cornerDiam);
}


/***********************************************************************
 *
 * FUNCTION:    WinEraseRectangle
 *
 * DESCRIPTION: This routine erases a rectangle in the draw window.  The
 *              rectangle can have square or round corners.
 *
 * PARAMETERS:  r           pointer to the rectangle to erase
 *              cornerDiam  diameter of the rounded corners or zero for
 *                          square corners
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinEraseRectangle (RectanglePtr r, Word cornerDiam)
{
	GState.grafMode = scrANDNOT;
	GState.patternMode = false;
	DrawRectangle (r, cornerDiam);
}


/***********************************************************************
 *
 * FUNCTION:    WinInvertRectangle
 *
 * DESCRIPTION: This routine inverts a rectangle in the draw window.  The
 *              rectangle can have square or round corners.
 *
 * PARAMETERS:  r           pointer to the rectangle to invert
 *              cornerDiam  diameter of the rounded corners or zero for
 *                          square corners
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinInvertRectangle (RectanglePtr r, Word cornerDiam)
{
	GState.grafMode = scrXOR;
	GState.patternMode = false;
	DrawRectangle (r, cornerDiam);
}

/***********************************************************************
 *
 * FUNCTION:    WinFillRectangle
 *
 * DESCRIPTION: This routine draws a rectangle with current custom pattern
 *              The rectangle can have square or round corners.
 *
 * PARAMETERS:  r           pointer to the rectangle to draw
 *              cornerDiam  diameter of the rounded corners or zero for
 *                          square corners
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/29/94		Initial Revision
 *
 ***********************************************************************/
void WinFillRectangle (RectanglePtr r, Word cornerDiam)
{
	PatternType savePattern;

	savePattern = GState.pattern;
	GState.pattern = customPattern;
	GState.grafMode = scrCopy;
	GState.patternMode = true;
	DrawRectangle (r, cornerDiam);
	GState.pattern = savePattern;
}




/***********************************************************************
 *
 * FUNCTION:    WinDrawRectangleFrame
 *
 * DESCRIPTION: This routine draws a rectanglar frame in the draw window.
 *
 * PARAMETERS:  frame       type of frame to draw
 *              r           pointer to the rectangle to frame
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawRectangleFrame (FrameType frame, RectanglePtr r)
{
	GState.grafMode = scrCopy;
	GState.patternMode = false;
	DrawFrame (frame, r); 
}


/***********************************************************************
 *
 * FUNCTION:    WinEraseRectangleFrame
 *
 * DESCRIPTION: This routine erases a rectanglar frame in the draw window.
 *
 * PARAMETERS:  frame       type of frame to erase
 *              r           pointer to the rectangle to frame
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinEraseRectangleFrame (FrameType frame, RectanglePtr r)
{
	GState.grafMode = scrANDNOT;
	GState.patternMode = false;
	DrawFrame (frame, r); 
}


/***********************************************************************
 *
 * FUNCTION:    WinInvertRectangleFrame
 *
 * DESCRIPTION: This routine inverts a rectanglar frame in the draw window.
 *
 * PARAMETERS:  frame       type of frame to invert
 *              r           pointer to the rectangle to frame
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinInvertRectangleFrame (FrameType frame, RectanglePtr r)
{
	GState.grafMode = scrXOR;
	GState.patternMode = false;
	DrawFrame (frame, r); 
}


/***********************************************************************
 *
 * FUNCTION:    WinDrawGrayRectangleFrame
 *
 * DESCRIPTION: This routine draws a gray rectanglar frame in the draw 
 *              window.  The standard gray pattern is not used be this
 *              routine,  the frame is drawn such that the top left pixel
 *              of the frame is always on.
 *
 * PARAMETERS:  frame       type of frame to draw
 *              r           pointer to the rectangle to frame
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawGrayRectangleFrame (FrameType frame, RectanglePtr r)
{
	PatternType savePattern;
	WinPtr    winPtr;
	Word pattern;
	int i;

	savePattern = GState.pattern;
	GState.pattern = customPattern;
	
	// Based on the display relative top left corner of frame, determine
	// which pattern to draw with.  If both x and y are at a even or
	// odd coordinate, use the pattern AA55 (first pixel on). 
	winPtr = WinGetWindowPointer (DrawWindow);
	if ((r->topLeft.x + winPtr->windowBounds.topLeft.x & 1) ^
		 (r->topLeft.y + winPtr->windowBounds.topLeft.y & 1))
		pattern = 0x55AA;				// first pixel off
	else
		pattern = 0xAA55;				// first pixel on

	for (i = 0; i < sizeof (CustomPatternType) / sizeof (Word); i++)
		GState.customPtn[i] = pattern;

	GState.grafMode = scrCopy;
	GState.patternMode = true;
	DrawFrame (frame, r); 
	GState.pattern = savePattern;
}


/***********************************************************************
 *
 * FUNCTION:    WinSetColors
 *
 * DESCRIPTION: This routine sets the new foreground and background
 *		colors and returns the old colors. 0 can be passed for parameters
 *		that should be ignored. 
 *
 * PARAMETERS: 
 *		newForeColorP - pointer to new foreground color
 *		oldForeColorP - old foreground color is returned here
 *		newBackColorP - pointer to new background color
 *		oldBackColorP - old background color is returned here
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
void WinSetColors (const RGBColorType* const newForeColorP, RGBColorType* oldForeColorP,
					const RGBColorType* const newBackColorP, RGBColorType* oldBackColorP)
{
	if (oldForeColorP)
		*oldForeColorP = GState.foreColor;
	if (oldBackColorP)
		*oldBackColorP = GState.backColor;
		
	if (newForeColorP)
		GState.foreColor = *newForeColorP;
	if (newBackColorP)
		GState.backColor = *newBackColorP;
}




/***********************************************************************
 *
 * FUNCTION:    WinGetPattern
 *
 * DESCRIPTION: This routine returns the current fill pattern.  The fill 
 *              pattern is use by the WinFill... routines.
 *
 * PARAMETERS:  pattern buffer to hold pattern
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinGetPattern (CustomPatternType pattern)
{
	MemMove (pattern, GState.customPtn, sizeof (CustomPatternType));
}

/***********************************************************************
 *
 * FUNCTION:    WinSetPattern
 *
 * DESCRIPTION: This routine set the current fill pattern.  The fill 
 *              pattern is use by the WinFill... routines.
 *
 * PARAMETERS:  pattern  pattern to set to
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinSetPattern (CustomPatternType pattern)
{
	MemMove (GState.customPtn, pattern, sizeof (CustomPatternType));
}


/***********************************************************************
 *
 * FUNCTION:    WinDrawBitmap
 *
 * DESCRIPTION: This routine set the current fill pattern.  The fill 
 *              pattern is use by the WinFill... routines.
 *
 * PARAMETERS:  pattern  pattern to set to
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void WinDrawBitmap (BitmapPtr bitmapP, short x, short y)
{
	WindowType 	window;
	GDeviceType	gDevice;
	WinHandle 	drawWindow;
	WindowType*	drawWinP;
	Word			depth;
	BytePtr		bitsP;
	
	BitmapPtr	lastBitmapP;
	
	
	// Get the depth of the draw window so that we can search for the
	//  best depth in the source bitmap to use
	drawWinP = (WindowType*)DrawWindow;
	depth = drawWinP->gDeviceP->pixelSize;
	
	
	// Find the portion of the bitmap resource that has the best possible
	//  source depth
	lastBitmapP = bitmapP;
	do {
		if (bitmapP->version < 1) break;
		if (bitmapP->pixelSize == depth) break;
		if (bitmapP->pixelSize > depth) {bitmapP = lastBitmapP; break;}
		if (!bitmapP->nextDepthOffset) break;
		bitmapP = (BitmapPtr)((DWordPtr)bitmapP + bitmapP->nextDepthOffset);
		} while (1);
	

	// Fill in the device info
	MemSet(&gDevice, sizeof(gDevice), 0);
	gDevice.width = bitmapP->width;
	gDevice.height = bitmapP->height;
	bitsP = (BytePtr)(bitmapP + 1);
	if (bitmapP->flags.hasColorTable) {
		ColorTablePtr	cTableP;
		cTableP = (ColorTablePtr)bitsP;
		bitsP += cTableP->numEntries * sizeof(RGBColorType) + sizeof(cTableP->numEntries);
		}
	gDevice.baseAddr = bitsP;
	if (bitmapP->version >= 1)
		gDevice.pixelSize = bitmapP->pixelSize;
	else
		gDevice.pixelSize = 1;
	gDevice.rowBytes = bitmapP->rowBytes;
	
	
	// Fill in the window info
	window.gDeviceP = &gDevice;
	window.windowFlags.offscreen = true;
	window.gDeviceP->compressed = bitmapP->flags.compressed;
	
	window.windowBounds.topLeft.x = 0;
	window.windowBounds.topLeft.y = 0;
	window.windowBounds.extent.x = bitmapP->width;
	window.windowBounds.extent.y = bitmapP->height;

	window.frameType.word = 0;
	window.gstate = &GState;
	window.nextWindow = 0;

	// copy these fields for compatibility
	window.displayWidthV20 = gDevice.width;
	window.displayHeightV20 = gDevice.height;
	window.displayAddrV20 = gDevice.baseAddr;
	
	window.windowFlags.reserved = 0;
	
	drawWindow = DrawWindow;
	DrawWindow = &window;
	WinResetClip ();
	DrawWindow = drawWindow;
	
	WinCopyRectangle (&window, 0, &window.windowBounds, x, y, scrCopy);
}


/***********************************************************************
 *
 * FUNCTION:    WinModal
 *
 * DESCRIPTION: This routine returns true if the specifed window is modal 
 *
 * PARAMETERS:  winHandle  handle of a window
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/14/95	Initial Revision
 *
 ***********************************************************************/
Boolean WinModal (WinHandle winHandle)
{
	WinPtr    winPtr;

	ECWinValidateHandle(winHandle);
	
	winPtr = WinGetWindowPointer (winHandle);
	return (winPtr->windowFlags.modal);
}


/***********************************************************************
 *
 * FUNCTION:    DrawFrame
 *
 * DESCRIPTION: This routine draws, erases or inverts a frame around
 *              the rectangle specified.
 *
 * PARAMETERS:  frame       type of frame to draw
 *              r           pointer to the rectangle to frame
 *              grafMode    draw, erase or invert
 *
 * RETURNED:    nothing
 *
 * NOTE:        This routine currently only supports shadows on rounded
 *              rectangles with corner diamaters of 4.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/30/94		Initial Revision
 *
 ***********************************************************************/
void DrawFrame (FrameType frame, RectanglePtr r)
{
	RectangleType rect;
	FrameBitsType frameType;
	short         cornerDiam;
	short         left;
	short         top;
	short         right;
	short         bottom;
	short         width;
	RGBColorType	white, ltGray, dkGray, black, oldFore;

	MemMove (&rect, r, sizeof (RectangleType));
	
	frameType.word = frame;
	width = frameType.bits.width;
	cornerDiam = frameType.bits.cornerDiam;

	// Setup the colors if this is a 3D frame
	oldFore = GState.foreColor;
	if (frameType.bits.threeD) {
		white.r = white.g = white.b = 0xFF;
		ltGray.r = ltGray.g = ltGray.b = 0xA0;
		dkGray.r = dkGray.g = dkGray.b = 0x60;
		black.r = black.g = black.b = 0;
		}


	if (cornerDiam)
		{
		RctInsetRectangle (&rect, -1);
		DrawRoundedRectangle (&rect, cornerDiam, width, false);
		RctInsetRectangle (&rect, 1);
		}
	else
		{
		left = rect.topLeft.x;
		right = rect.topLeft.x + rect.extent.x - 1;
		top = rect.topLeft.y;
		bottom = rect.topLeft.y + rect.extent.y - 1;

		while (width)
			{
			// Draw a square cornered frame.
			//
			left--;
			top--;
			right++;
			bottom++;
			if (frameType.bits.threeD) {
			
				// The outside must be ltGray. The inside top and
				//  left lines are white. 
				if (width == 1) {
					GState.foreColor = ltGray;
					DrawLine (left+1, top, right-1, top);
					DrawLine (left, top+1, left, bottom-1);
					}
				else 	{
					GState.foreColor = white;
					DrawLine (left, top, right, top);
					DrawLine (left, top+1, left, bottom-1);
					}
				
				// The outside must be black. The inside right and
				//  bottom lines are dark gray. 
				if (width == 1) {
					GState.foreColor = black;
					DrawLine (left+1, bottom, right-1, bottom);
					DrawLine (right, top+1, right, bottom-1);
					}
				else 	{
					GState.foreColor = dkGray;
					DrawLine (left, bottom, right, bottom);
					DrawLine (right, top+1, right, bottom-1);
					}
				}
				
			else {
				DrawLine (left, top, right, top);
				DrawLine (left, bottom, right, bottom);
				DrawLine (left, top+1, left, bottom-1);
				DrawLine (right, top+1, right, bottom-1);
				}
			width--;
			}
		}

	
	// Draw the 3-D shadow.
	//
	if (frameType.bits.shadowWidth)
		{
		// Draw the bottom side of the shadow.
		//
		rect.topLeft.y	+=	rect.extent.y + 1;
		rect.extent.y = frameType.bits.shadowWidth;
		rect.topLeft.x += 1;					// indent the left end by 2 pixels
		rect.extent.x -= 1;					// indent the right end by 3 pixel 
		DrawRectangle (&rect, 0);

		// Draw the right side of the shadow.
		//
		MemMove (&rect, r, sizeof (RectangleType));
		rect.topLeft.x	+=	rect.extent.x + 1;
		rect.extent.x = frameType.bits.shadowWidth;
		rect.topLeft.y += 1;					// indent the top end by 2 pixels
		rect.extent.y -= 1;					// indent the bottom end by 3 pixel
		DrawRectangle (&rect, 0);

		// Fill in the corner.
		//
		rect.topLeft.x--;
		rect.topLeft.y += rect.extent.y;
		rect.extent.x = 1;
		rect.extent.y = 1;
		DrawRectangle (&rect, 0);
		}
		
		
	// Restore the foreground color
	GState.foreColor = oldFore;

}


/***********************************************************************
 *
 * FUNCTION:    WinValidateHandle
 *
 * DESCRIPTION: Validate a window handle. 
 *
 * PARAMETERS:  winHandle  handle of a window
 *
 * RETURNED:    true if the handle is ok
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *			roger	2/6/98	Add check to look for the window in the window list.
 *
 ***********************************************************************/
Boolean WinValidateHandle (const WinHandle winHandle)
{
	WinPtr    winPtr;
	
	
	winPtr = WinGetWindowPointer (winHandle);
	
	ErrFatalDisplayIf(winPtr == NULL, "NULL window");
	
//	if (MemPtrSize(winPtr) < sizeof(WindowType))
//		goto badWindow;
	
	if (winPtr->windowFlags.reserved)
		goto badWindow;
		
	if (winPtr->gDeviceP && winPtr->gDeviceP->pixelSize > scrMaxDepth)
		goto badWindow;
	
	
	// Since these assignments were added we might as well get some use
	// from them.  Assert them.
	if (winPtr->displayWidthV20 != winPtr->gDeviceP->width)
		goto badWindow;
	
	if (winPtr->displayHeightV20 != winPtr->gDeviceP->height)
		goto badWindow;
	
	if (winPtr->displayAddrV20 != winPtr->gDeviceP->baseAddr)
		goto badWindow;
	
	
	return true;
	
	
badWindow:
	ErrNonFatalDisplayIf(true, "Bad window");
	return false;
}


#endif //#if 	GRAPHICS_VERSION == GRAPHICS_VERSION_2 



