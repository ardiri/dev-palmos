/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     field.c
 * AUTHOR:	 Art Lamb: November 19, 1994
 *
 * DECLARER: Memo
 *
 * DESCRIPTION:
 *	  This file contains the field object routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>
#include <graffiti.h>

#define	NON_PORTABLE
#include <SysEvtMgr.h>
#include <SystemPrv.h>


#define  tabChrWidth      20

/***********************************************************************
 *
 * Stactic function
 *
 ***********************************************************************/

static Boolean	AtEndOfLine (FieldPtr fld, Word pos);
static void		CancelSelection (FieldPtr fld);
static Boolean	CompactFieldHeight (FieldPtr fld, Word pos);
static void		DeleteFromText (FieldPtr fld, Word startPos, Word charsToDelete);
static Boolean	ExpandFieldHeight (FieldPtr fld, Word pos);
static Boolean	ExpandTextString (FieldPtr fld, Word newSize);
static void		FormatAndDrawFromPos (FieldPtr fld, Word pos, Boolean draw);
static void		FormatAndDrawLineIfChanged (FieldPtr fld, Word lineNumber);
static void 	FormatAndDrawIfWrappingChanged (FieldPtr fld, Word lineNumber);
static void		FormatAndDrawLines (FieldPtr fld, Boolean draw);
static Word		FormatLine (FieldPtr fld, Word start);
static Word		GetLineCharsWidth (FieldPtr fld, Word lineNum);
static Word		GetStringPosOfInsPtPos (FieldPtr fld);
static Word		GetVisibleCharsInLine (FieldPtr fld, Word lineNum);
static Word		GetVisibleLines (FieldPtr fld);
static Boolean	IsSelection (FieldPtr fld);
static void		SetInsPtFromStringPos (FieldPtr fld, Word pos);
static Word		StartOfLine (FieldPtr fld, Word pos);
static Word		StartOfPreviousLine (FieldPtr fld, Word startOfLine);
static void		UpdateStartOfLines (FieldPtr fld, short amount, Word pos);
static void 	ModifyText (FieldPtr fld, Word offset, CharPtr charsP, Word len);
static void 	UndoReset (void);
static Boolean UndoRecordTyping (FieldPtr fld,  Word pos);
static Boolean UndoRecordBackspaces (FieldPtr fld, Word pos);
static Boolean UndoRecordPaste (FieldPtr fld, Word pos);
static void 	UndoRecordCut (FieldPtr fld);



/***********************************************************************
 *
 * FUNCTION:    ECValidateField 
 *
 * DESCRIPTION: This routine performs various edit checks on a field 
 *              object.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/23/95	Initial Revision
 *
 ***********************************************************************/
static void ECValidateField (FieldPtr fld)
{
	Word i;
	Word pos;
	Word numLines;
	FontID curFont;
	
	curFont = FntSetFont (fld->fontID);	

	// The field has to be tall enough to display at 
	numLines = GetVisibleLines (fld);

	// Check that the insertion point position is reasonable.
	ErrFatalDisplayIf (fld->insPtXPos > fld->rect.extent.x, 
		"Invalid insertion point position");
	ErrFatalDisplayIf (fld->insPtYPos > numLines, 
		"Invalid insertion point position");
	
	if (fld->text)
		{
		ErrFatalDisplayIf ( StrLen(fld->text) != fld->textLen, 
			"Invalid field length");
		}
	else	
		{
		ErrFatalDisplayIf ( ((fld->insPtXPos > 0) || (fld->insPtYPos > 0)),
			"Invalid insertion point position");
		}

	// Validate the word wrapping info.
	if ( (! fld->attr.singleLine) && (fld->text))
		{
		ErrFatalDisplayIf (!fld->lines, "No word wrapping info");
		
		pos = fld->lines->start;
		for (i = 0; i < numLines; i++)
			{
			ErrFatalDisplayIf (pos != fld->lines[i].start, 
				"Invalid word wrapping info");
			pos += fld->lines[i].length;

			ErrFatalDisplayIf (pos > fld->textLen, 
				"Invalid word wrapping info");
			}
		}
	
	 FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION:    DrawLine 
 *
 * DESCRIPTION: Draw a line a text.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              start       postion in text string of first character to draw
 *              charsToDraw number of characters to draw.
 *              lineNum
 *              erase       true to erase the rest of the line.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94	Initial Revision
 *
 ***********************************************************************/
static void DrawLine (FieldPtr fld, Word start, Word charsToDraw, 
	Word lineNum, Boolean erase)
{
	short         		drawX, drawY, y;
	Word					count;
	Word					charsDrawn;
	Word          		charsWidth;
	CharPtr       		chars;
	RectangleType 		eraseR;
	RectangleType		clipR;
	RectangleType		savedClipR;
	UnderlineModeType underlineMode;

	chars = &fld->text[start];
	
	// Don't draw the linefeedChr character.
	if ((charsToDraw) && chars[charsToDraw-1] == linefeedChr)
		charsToDraw--;

	// Don't draw trailing spaceChrs.
	while (charsToDraw && chars[charsToDraw-1] == spaceChr) charsToDraw--;

	// Calculate the draw position of the line.
	drawX = fld->rect.topLeft.x;
	drawY = fld->rect.topLeft.y + (lineNum * FntLineHeight ());
	if (fld->attr.justification == rightAlign)
		{
		drawX += fld->rect.extent.x - FntCharsWidth (chars, charsToDraw);
		}

	charsWidth = FntLineWidth (chars, charsToDraw);
	if (charsWidth > fld->rect.extent.x)
		charsWidth = fld->rect.extent.x;

	//	Erase the region after the last character of the line.
	if (erase)
		{
		eraseR.topLeft.y = drawY;
		eraseR.extent.y  = FntCharHeight();

		if (fld->attr.justification == rightAlign)
			{
			eraseR.topLeft.x = fld->rect.topLeft.x;
			eraseR.extent.x = drawX - fld->rect.topLeft.x;
			}
		else
			{
			eraseR.topLeft.x = drawX + charsWidth;
			eraseR.extent.x =  fld->rect.extent.x - charsWidth;
			}
			
		if (fld->attr.underlined)
			eraseR.extent.y--;
			
		if (eraseR.extent.x > 0)
			WinEraseRectangle (&eraseR, 0);
		}

	// Clip the text of a single line field to the bounds of the field.
	if (fld->attr.singleLine)
		{
		WinGetClip (&savedClipR);
		RctCopyRectangle (&fld->rect, &clipR);
		WinClipRectangle (&clipR);
		WinSetClip (&clipR);
		}

	// Set the correct underline mode in graphic state.
	underlineMode = WinSetUnderlineMode ( 
		(UnderlineModeType) fld->attr.underlined);
		
	// Draw the text.
	count = 0;
	charsDrawn = 0;
	while (true)
		{
		// Count until we reach a tab character.
		while ((count < charsToDraw) && (chars[count] != tabChr))
			count++;
			
		// Draw the characters until/between the tab characters.
		WinDrawChars (&chars[charsDrawn], count-charsDrawn, drawX, drawY);
		if (count >= charsToDraw) break;
		
		// Erase the width of the tab character.
		eraseR.topLeft.x = drawX + FntLineWidth (&chars[charsDrawn], 
			count-charsDrawn);
		eraseR.extent.x = tabChrWidth - ((eraseR.topLeft.x - fld->rect.topLeft.x) 
			 % tabChrWidth);
		eraseR.topLeft.y = drawY;
		eraseR.extent.y  = FntCharHeight();
		if (fld->attr.underlined)
			eraseR.extent.y--;
		if (eraseR.topLeft.x + eraseR.extent.x > fld->rect.topLeft.x + fld->rect.extent.x)
			eraseR.extent.x = fld->rect.extent.x - (eraseR.topLeft.x - fld->rect.topLeft.x);
		WinEraseRectangle (&eraseR, 0);
		
		// Underline the tab.
		if (fld->attr.underlined)
			{
			y = drawY + FntCharHeight() - 1;
			WinDrawGrayLine (eraseR.topLeft.x, y, 
				eraseR.topLeft.x + eraseR.extent.x - 1, y);
			}		

		// Move the draw position past the tab.
		drawX = eraseR.topLeft.x + eraseR.extent.x;

		// Skip over the tab.
		count++;
		charsDrawn = count;
		}

	WinSetUnderlineMode (underlineMode);

	if (fld->attr.underlined)
		{
		drawX = fld->rect.topLeft.x;
		if (fld->attr.justification != rightAlign)
			drawX += charsWidth;
		drawY += FntCharHeight() - 1;
		WinDrawGrayLine (drawX, drawY, 
			drawX + fld->rect.extent.x - charsWidth - 1, drawY);
		}		

	if (fld->attr.singleLine)
		{
		WinSetClip (&savedClipR);
		}
}


/***********************************************************************
 *
 * FUNCTION:    DrawLines 
 *
 * DESCRIPTION: Draw a lines of text.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              erase       true to erase the rest of the line.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/30/95	Initial Revision
 *
 ***********************************************************************/
static void DrawLines (FieldPtr fld, Boolean erase)
{
	Word			lineNum;
	Word 			numLines;
	LineInfoPtr line;
	
	if (fld->attr.singleLine)
		{
		DrawLine (fld, 0, fld->textLen, 0, erase);
		}
	else
		{
		numLines = fld->rect.extent.y / FntLineHeight ();
	
		line = fld->lines;
		if (line)
			{
			for (lineNum = 0; lineNum < numLines; lineNum ++)
				{
		    	DrawLine (fld, line->start, line->length, lineNum, erase);
				line++;
				}
			}
		else
			{
			for (lineNum = 0; lineNum < numLines; lineNum ++)
				{
		    	DrawLine (fld, 0, 0, lineNum, erase);
		    	}
		    }	
		}
}


/***********************************************************************
 *
 * FUNCTION:    AutoShift
 *
 * DESCRIPTION: This routine sets Graffiti to upper-case shift in 
 *              appropriate.
 *
 * PARAMETERS:  fld  - pointer to a FieldType structure.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/27/96	Initial Revision
 *
 ***********************************************************************/
static void AutoShift (FieldPtr fld)
{
	register Char chr;
	Word pos;

	if (! fld->attr.autoShift)
		return;
	
	if (! fld->textLen)
		{
		GrfSetState (false, false, true);
		return;
		}
		
	pos = GetStringPosOfInsPtPos (fld);

	// If we have a period followed by a series of spaces then case shift
	// Griffiti.
	if (pos && (fld->text[pos-1] == spaceChr))
		{
		pos--;
		while (pos && (fld->text[pos] == spaceChr))
			pos--;

		chr = fld->text[pos];
		if (pos && (chr == periodChr || chr == '!' || chr == '?'))
			{
			GrfSetState (false, false, true);
			return;
			}
		}

	// If we have a period followed by a series of linefeeds then case shift
	// Griffiti.
	else if (pos && (fld->text[pos-1] == linefeedChr))
		{
		pos--;
		while (pos && (fld->text[pos] == linefeedChr))
			pos--;

		chr = fld->text[pos];
		if (pos && (chr == periodChr || chr == '!' || chr == '?'))
			{
			GrfSetState (false, false, true);
			return;
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    InsertChar
 *
 * DESCRIPTION: Insert a character into the text of a field and redraw the 
 *              field.  This routine performs any word wrapping or 
 *              scrolling that is necessary.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              ch          character to insert.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94	Initial Revision
 *       ron   7/21/95  Now use ModifyText routine in all places that modify the
 *                       text in order to support write-protected data storage.
 *
 ***********************************************************************/
static void InsertChar (FieldPtr fld, char ch)
{
	Word pos;
	Word start;
	Word end;
	Word offset;
	Word numLines;
	Word lineNumber;
	Word lineWidth;
	Word blockSize;
	short drawX, drawY;
	CharPtr chars;
	Boolean atEnd;
	Boolean notify = false;
	LineInfoPtr line;
	UnderlineModeType underlineMode;


	fld->attr.dirty = true;

	// If there is a selection, replace it with the character passed.
	//
	if (IsSelection (fld))
		{
		pos = fld->selFirstPos;
		if ( ! UndoRecordTyping (fld, pos)) return;

		FldInsert (fld, &ch, 1);
		}

	else if (fld->textLen < fld->maxChars)
		{
		UndoReset ();
		
		// If necessary, expand the memory block that contains the field's 
		// text string.
		if (fld->textLen+1 >= fld->textBlockSize)
			{
			if (! ExpandTextString (fld, 0)) return;
			}

		// Scroll the insertion point into view.
		if (! fld->attr.insPtVisible)
			{
			SetInsPtFromStringPos (fld, fld->selFirstPos);
			notify = true;
			}

		// Insert the character into the field's text string.
		pos = GetStringPosOfInsPtPos (fld);
		chars = fld->text + pos;		
		blockSize = MemHandleSize (fld->textHandle);
		if (blockSize == fld->textBlockSize) {
			//<RM> MemMove (chars+1, chars, fld->textLen - pos + 1);
			ModifyText(fld, pos+1, chars, fld->textLen - pos + 1);
			}
		else
			{
			offset = fld->text - (CharPtr) MemDeref(fld->textHandle);
			//<RM> MemMove (chars+1, chars, blockSize - pos - offset - 1);
			ModifyText(fld, pos+1, chars, blockSize -  pos - offset - 1);
			}
		//<RM> *chars = ch;
		ModifyText(fld, pos, &ch, sizeof(Char));
		fld->textLen++;

		UpdateStartOfLines (fld, 1, fld->insPtYPos+1);
		pos++;

		// If a character is being added to the end of a line, and the field is 
		// left justified, and the character is not a linefeedChr or a tab character,
		// then we can just draw the new character.
		atEnd = ((ch != linefeedChr) && (ch != tabChr) && AtEndOfLine(fld, pos));

		// Compute the length the the current line plus the new character.
		if (atEnd)
			{
			if (! fld->attr.singleLine)
				fld->lines[fld->insPtYPos].length++;
			lineWidth = GetLineCharsWidth (fld, fld->insPtYPos); 
			}

		// If the new character fits on the end of the current line just draw the 
		// new character.
		if (atEnd && lineWidth <= fld->rect.extent.x)
			{
			drawY = fld->rect.topLeft.y + (fld->insPtYPos * FntLineHeight ());
			drawX = fld->rect.topLeft.x + lineWidth - FntCharWidth (ch);
			underlineMode = WinSetUnderlineMode (
				(UnderlineModeType)fld->attr.underlined);
			WinDrawChars ((CharPtr) &ch, 1, drawX, drawY);
			WinSetUnderlineMode (underlineMode);
			fld->insPtXPos++;
			}

		else
			{
			// If the field has a scroll bar get the positions of the first and last
			// visible characters.  We will use these values later to determine if the
			// scroll bar needs to be updated.
			if (fld->attr.hasScrollBar)
				{
				numLines = GetVisibleLines(fld);
				line = &fld->lines [numLines - 1];
				start = fld->lines->start;
				end = line->start + line->length;
				if (fld->insPtYPos+1 == numLines) end++;
				}

			// Reformat the field starting with the previous line, inserting a 
			// white-space character may cause part of the current line to move 
			// onto the previous line.
			lineNumber = fld->insPtYPos;
			if ((! atEnd) && lineNumber > 0) lineNumber--;

			FormatAndDrawIfWrappingChanged (fld, lineNumber);
			if (! ExpandFieldHeight (fld, pos))
				{
				SetInsPtFromStringPos (fld, pos);

				// Entering a space or a tab may cause the height of a field
				// to decrease.
				if (ch == spaceChr || ch == tabChr)
					CompactFieldHeight (fld, pos);
				}
			else
				FldSetInsertionPoint (fld, pos);

			// If the field has a scroll bar and the positions of the first or last
			// visible characters is different then send an event to notify the 
			// application the the scroll bar needs to be updated.
			if (fld->attr.hasScrollBar)
				{
				if (start != fld->lines->start || end != (line->start + line->length))
					notify = true;
				}				
			}
		
		if (notify)
			FldSendChangeNotification (fld);

		}
	// The field is full, play the overflow sound.
	else
		{
		SndPlaySystemSound (sndError);
		}
}


/***********************************************************************
 *
 * FUNCTION:    BackspaceChar
 *
 * DESCRIPTION: Delete the character before the insertion point and
 *              redraw the field.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void BackspaceChar (FieldPtr fld)
{
	LineInfoPtr	line;
	LineInfoPtr	lastLine;
	Word			insPtXPos;
	Word			pos;
	Word			firstVisible;
	Word			lastVisible;
	Word			numLines;
	Word			start, length;
	Word			charsToDelete;


	if (! fld->text)
		return;

	fld->attr.dirty = true;

	// If the field has a scroll bar get the positions of the first and last
	// visible characters.  We will use these values later to determine if the
	// scroll bar needs to be updated.
	if (fld->attr.hasScrollBar)
		{
		numLines = GetVisibleLines(fld);
		lastLine = &fld->lines [numLines - 1];
		firstVisible = fld->lines->start;
		lastVisible = lastLine->start + lastLine->length;
		}


	// If there is a selection, delete the selected text.
	if (IsSelection (fld))
		{
		if ( ! UndoRecordBackspaces (fld, fld->selFirstPos))
			return;
		charsToDelete = fld->selLastPos - fld->selFirstPos;
		pos = fld->selFirstPos;
		CancelSelection (fld);
		DeleteFromText (fld, pos, charsToDelete);

		if (pos < fld->lines->start)
			{
			FormatAndDrawFromPos (fld, pos, true);
			SetInsPtFromStringPos (fld, pos);
			}
		else
			{
			SetInsPtFromStringPos (fld, pos);
			UpdateStartOfLines (fld, -charsToDelete, fld->insPtYPos+1);
			FormatAndDrawIfWrappingChanged (fld, fld->insPtYPos);
			SetInsPtFromStringPos (fld, pos);			
			}

		if (! CompactFieldHeight (fld, pos))
			ExpandFieldHeight (fld, pos);

		// If the field has a scroll bar and the positions of the first or last
		// visible characters is different then send an event to notify the 
		// application the the scroll bar needs to be updated.
		if (fld->attr.hasScrollBar)
			{
			if (firstVisible != fld->lines->start || 
			    lastVisible - charsToDelete != lastLine->start + lastLine->length)
				FldSendChangeNotification (fld);
			}				

		return;
		}



	// Scroll the insertion point into view.
	if (! fld->attr.insPtVisible)
		SetInsPtFromStringPos (fld, fld->selFirstPos);


	// For single line fields, delete the character before the insertion
	//	point, redraw the line and adjust the insertion point position.
	insPtXPos = fld->insPtXPos;
	if (fld->attr.singleLine)
		{
		if (insPtXPos)
			{
			UndoRecordBackspaces (fld, insPtXPos-1);
			DeleteFromText (fld, insPtXPos-1, 1);
			DrawLine (fld, 0, fld->textLen, 0, true);
			fld->insPtXPos--;
			}
		return;
		}

 
	// Delete a character from a multi-line field.  Fisrt check that the
	// insertion point is beyond the first character of the field.
	pos = GetStringPosOfInsPtPos(fld);
	if (pos == 0) return;
	
	pos--;
	UndoRecordBackspaces (fld, pos);
	DeleteFromText (fld, pos, 1);

	// If the insertion point is in the first column of the first row,
	// scroll the field up one line.
	if ((fld->insPtXPos == 0) && (fld->insPtYPos == 0))
		{ 
		fld->lines->start = StartOfPreviousLine (fld, fld->lines->start-1);
		FormatAndDrawLines (fld, true);
		}
	else
 		{
		if (fld->insPtXPos == 0)
			fld->insPtYPos--;
 		UpdateStartOfLines (fld, -1, fld->insPtYPos+1);

		// If the prior line does not end with a linefeedChr, check if the
		// current line should be concatenated to the prior line.
		//
		line = &fld->lines[fld->insPtYPos];
		if (line->start && fld->text[line->start-1] != linefeedChr)
			{
			start = StartOfPreviousLine (fld, line->start);
			length = FormatLine (fld, start);
			if (start+length > line->start)
				{
				line->start = start;
				FormatAndDrawLines (fld, true);
				}
			else
	    		FormatAndDrawLineIfChanged (fld, fld->insPtYPos);
			}
		else
    		FormatAndDrawLineIfChanged (fld, fld->insPtYPos);
 		}
	SetInsPtFromStringPos (fld, pos);

	if (! CompactFieldHeight (fld, pos))
		ExpandFieldHeight (fld, pos);
		
	// If the field has a scroll bar and the positions of the first or last
	// visible characters is different then send an event to notify the 
	// application the the scroll bar needs to be updated.
	if (fld->attr.hasScrollBar)
		{
		if (firstVisible != fld->lines->start || 
		    lastVisible - 1 != (lastLine->start + lastLine->length))
			FldSendChangeNotification (fld);
		}				
}




/***********************************************************************
 *
 * FUNCTION:    AllocateLines
 *
 * DESCRIPTION: Allocate the structure that contains the word wrapping
 *              information.  An array of LineInfoType structure is 
 *              allocated, there is an array element for each visible
 *              line.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/12/94	Initial Revision
 *
 ***********************************************************************/
static void AllocateLines (FieldPtr fld)
{
	VoidHand handle;
	int numBytes; 
	
	if (fld->attr.singleLine) return;

	if (! fld->lines)
		{
		numBytes = sizeof (LineInfoType) * GetVisibleLines(fld);
		ErrNonFatalDisplayIf( (numBytes==0), "Allocation error");
		
		if (numBytes == 0)
			numBytes = sizeof (LineInfoType);
		
		handle = MemHandleNew (numBytes);
		ErrFatalDisplayIf( (handle==0), "Allocation error");

		fld->lines = MemHandleLock (handle);
		MemSet (fld->lines, numBytes, 0);
		}
}


/***********************************************************************
 *
 * FUNCTION:    GetVisibleLines
 *
 * DESCRIPTION: This function returns the number of lines that can be 
 *              display within the visible bounds of the field.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art		11/23/94		Initial Revision
 *			roger	10/8/97	Added ec code
 *
 ***********************************************************************/
static Word GetVisibleLines (FieldPtr fld)
{
	ErrNonFatalDisplayIf(fld->fontID != FntGetFont(), "Font set incorrectly");
	
	return (fld->rect.extent.y / FntLineHeight());
}


/***********************************************************************
 *
 * FUNCTION:    GetMaxLines
 *
 * DESCRIPTION: This function returns the number of visible lines 
 *              that can by a the field.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 maximum visible.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/29/97	Initial Revision
 *
 ***********************************************************************/
static Word GetMaxLines (FieldPtr fld)
{
	Word maxHeight;
	FontID currFont;
	
	if (fld->fontID == stdFont)
		return (maxFieldLines);
	else
		{
		currFont = FntSetFont (stdFont);
		maxHeight = maxFieldLines * FntLineHeight ();
		FntSetFont (currFont);
		return (maxHeight / FntLineHeight ());
		}
}


/***********************************************************************
 *
 * FUNCTION:    GetLineCharsWidth
 *
 * DESCRIPTION: Get the width, in pixels, of the the line specified.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              lineNum     line number, the first visible line is 0
 *
 * RETURNED:	 width of the character of the line, in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94	Initial Revision
 *
 ***********************************************************************/
static Word GetLineCharsWidth (FieldPtr fld, Word lineNum)
{
	CharPtr chars;
	Word length;

	if (fld->attr.singleLine)
		{
		chars = fld->text;
		length = fld->textLen;
		}
	else
		{
		chars = fld->text + fld->lines[lineNum].start;
		length = fld->lines[lineNum].length;
		}
	if (length && chars[length-1] == linefeedChr) length--;
	return (FntLineWidth (chars, length));
}


/***********************************************************************
 *
 * FUNCTION:    GetVisibleCharsInLine
 *
 * DESCRIPTION: Get the width, in characters, of the the line specified.
 *              linefeedChr character are not treated as visible characters, 
 *              they're not counted.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              lineNum     line number, the first visible line is 0
 *
 * RETURNED:	 number of characters in the specified line.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94	Initial Revision
 *
 ***********************************************************************/
static Word GetVisibleCharsInLine (FieldPtr fld, Word lineNum)
{
	CharPtr chars;
	Word length;
	
	
	ErrNonFatalDisplayIf( fld->text == NULL, "No field text");
	
	if (fld->attr.singleLine)
		{
		chars = fld->text;
		length = fld->textLen;
		}
	else
		{
		ErrNonFatalDisplayIf( fld->lines == NULL, "No field lines");
		
		chars = fld->text + fld->lines[lineNum].start;
		length = fld->lines[lineNum].length;
		}
	if (length && chars[length-1] == linefeedChr) length--;
	return (length);
}



/***********************************************************************
 *
 * FUNCTION:    UpdateStartOfLines
 *
 * DESCRIPTION: This routine is called when characters are added to
 *              a field.  This routine will adjust the structure that
 *              keeps track of the starting postion of each visible line.
 *              Only the line that start after the postion passed are
 *              modified.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              amount      amount a add to starting postion of each line.
 *              pos         position after which adjusts should be made.
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static void UpdateStartOfLines (FieldPtr fld, short amount, Word lineNum)
{
	LineInfoPtr line;
	Word        numLines;

	if (fld->attr.singleLine) return;
	
	line = fld->lines;
	numLines = GetVisibleLines (fld);
	while (lineNum < numLines)
		{
		line[lineNum].start +=  amount;
		lineNum++;
		}
}

/***********************************************************************
 *
 * FUNCTION:    FormatAndDrawFromPos
 *
 * DESCRIPTION: This routine performs the word wrapping calculation
 *              for dynamicly resizable field that have text scrolled
 *              off the top of the field.  The text is format so the 
 *              as much of the text as posible is visible.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              draw true if lines should be drawn
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/15/95	Initial Revision
 *
 ***********************************************************************/
static void FormatAndDrawToFill (FieldPtr fld, Boolean draw)
{
	Word numLines;
	Word start, length, i;
	LineInfoPtr line;
	LineInfoPtr firstLine;
	LineInfoPtr lastLine;


	// Single line field should not use this routine.
	ErrFatalDisplayIf( (fld->attr.singleLine), "Invalid attribute");


	// Format the display lines from the start of the first visible line.
	numLines = GetVisibleLines (fld);
	line = fld->lines;
	start = StartOfLine (fld, line->start);

	for (i = 0; i < numLines; i++)
		{
		length = FormatLine (fld, start);
		line->start  = start;
		line->length = length;
		start += length;
		line++;
		}


	// Scroll the field down to fill in any blank lines at the end the field.
	firstLine = fld->lines;

	lastLine = &fld->lines [numLines-1];
	if (fld->text[fld->textLen-1] == linefeedChr)
		lastLine--;
		
	while (firstLine->start && (lastLine->length == 0))
		{
		// Move the display line information down one line.
		//
		MemMove (&fld->lines[1], fld->lines, 
			sizeof(LineInfoType) * (numLines-1));
	
		// Format and draw the line which scrolled into view.
		//
		line = fld->lines;
		line->start = StartOfPreviousLine (fld, line->start);
		line->length = FormatLine (fld, line->start);
		}

	if (draw)
		DrawLines (fld, true);
}



/***********************************************************************
 *
 * FUNCTION:    FormatAndDrawFromPos
 *
 * DESCRIPTION: Staring with the line that contains the character 
 *              position specified, perform the word wrapping 
 *              calculation for each line visible line and redraw 
 *              the lines.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              pos  character position
 *              draw true if lines should be drawn
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/7/94	Initial Revision
 *			art	7/2/96	Add check for allocated lines structure
 *
 ***********************************************************************/
static void FormatAndDrawFromPos (FieldPtr fld, Word pos, Boolean draw)
{
	// Single line field don't have display formatting information.
	if ((! fld->attr.singleLine) && fld->lines)
		{
		fld->lines->start = StartOfLine (fld, pos);
		FormatAndDrawLines (fld, draw);
		}

	else if (draw)
		DrawLines (fld, true);	
}



/***********************************************************************
 *
 * FUNCTION:    FormatAndDrawLines
 *
 * DESCRIPTION: Starting with the first visible line, perform the word 
 *              wrapping calculation for each line visible line
 *              and redraw the line the "draw" parameter is true.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              draw true if lines should be drawn
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94	Initial Revision
 *
 ***********************************************************************/
static void FormatAndDrawLines (FieldPtr fld, Boolean draw)
{
	LineInfoPtr line;
	Word numLines, start, length, i;

	// Single line field don't have display formatting information.
	if (fld->attr.singleLine)
		{
		if (draw)
			DrawLine (fld, 0, fld->textLen, 0, true);
		return;
		}

	// Field that dynamicly expand and contract have special behavior when the 
	// top of the the text is scrolled out of view.
	if (fld->attr.dynamicSize)
		{
		if (fld->lines->start)
			{
			FormatAndDrawToFill (fld, draw);
			return;
			}
		}

	numLines = GetVisibleLines (fld);

	ErrNonFatalDisplayIf (! fld->lines, "No word wrapping info");
	
	line = fld->lines;
	start = line->start;
	
	for (i = 0; i < numLines; i++)
		{
		length = FormatLine (fld, start);
		line->start  = start;
		line->length = length;
		if (draw) DrawLine (fld, start, length, i, true);
		start += length;
		line++;
		}
}



/***********************************************************************
 *
 * FUNCTION:    FormatAndDrawLineIfChanged
 *
 * DESCRIPTION: Starting with the display line that the insertion point 
 *              is on, perform the word wrapping calculation for each line 
 *              and redraw the line if it has changeed.
 *
 *              This routine is called when a character is inserted or 
 *              deleted (backspaceChrd out).
 *              
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              lineNumber staring line  number;
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static void FormatAndDrawLineIfChanged (FieldPtr fld, Word lineNumber)
{
	LineInfoPtr  line;
	Word         newLineStart;
	Word         newLineLength;
	Word         numLines;

	// Single line field don't have display formatting information.
	if (fld->attr.singleLine)
		{
		DrawLine (fld, 0, fld->textLen, 0, true);
		return;
		}

	// Field that dynamicly expand and contract have special behavior when the 
	// top of the the text is scrolled out of view.
	if (fld->attr.dynamicSize)
		{
		if (fld->lines->start)
			{
			FormatAndDrawToFill (fld, true);
			return;
			}
		}

	numLines = GetVisibleLines (fld);
	line = &fld->lines[lineNumber];
	newLineStart = line->start;
	do
		{
		// Determine how many character will fix on the the line.
		newLineLength = FormatLine (fld, newLineStart);

		// Draw lines which changed. The current line always changes.
		if ( (fld->insPtYPos == lineNumber) ||
			  (line->start	!= newLineStart)	||
			  (line->length != newLineLength) )
			{
			// If both lines are blank then don't bother drawing them 
			if (line->length || newLineLength)
				DrawLine (fld, newLineStart, newLineLength, lineNumber, true);

			line->start  = newLineStart;
			line->length = newLineLength;
			}
		else if (lineNumber >= fld->insPtYPos)
			// If the line's format has not change then we can assume that
			// the rest of the line have not been changed, so we're done.
			break;

		newLineStart = newLineStart + newLineLength;
		line++;
		lineNumber++;
		}
	while	(lineNumber < numLines);
}

/***********************************************************************
 *
 * FUNCTION:    FormatAndDrawIfWrappingChanged
 *
 * DESCRIPTION: Starting with the display line specified,  
 *              perform the word wrapping calculation for each line 
 *              and redraw the line if it has changeed.
 *
 *              This routine is called when a character is inserted or 
 *              deleted (backspaceChrd out).
 *              
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              lineNumber staring line  number;
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	110/2/95	Initial Revision
 *
 ***********************************************************************/
static void FormatAndDrawIfWrappingChanged (FieldPtr fld, Word lineNumber)
{
	LineInfoPtr	line;
	Word			start, length;

	if (fld->attr.singleLine)
		{
		FormatAndDrawLineIfChanged (fld, lineNumber);
		return;
		}

	// If the prior line does not end with a linefeedChr, check if the
	// current line should be concatenated to the prior line.
	line = &fld->lines[lineNumber];
	if (line->start && fld->text[line->start-1] != linefeedChr)
		{
		start = StartOfPreviousLine (fld, line->start);
		length = FormatLine (fld, start);
		if (start+length > line->start)
			{
			line->start = start;
			FormatAndDrawLines (fld, fld->attr.visible);
			}

		else
	 		FormatAndDrawLineIfChanged (fld, lineNumber);
		}
	else
		FormatAndDrawLineIfChanged (fld, lineNumber);
}


/***********************************************************************
 *
 * FUNCTION:    WordWrap
 *
 * DESCRIPTION: Given a character position in the field text, determine 
 *              the number of characters that can be displayed on a line.
 *
 * PARAMETERS:	 chars       pointer to a null-terminated string
 *              maxWidth    maximum line width in pixels
 *
 * RETURNED:	 length of the line in characters
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static Word WordWrap (CharPtr chars, Word maxWidth)
{
 	Word    length, breakLen, lineWidth;
	char    ch;

	length = 0;
	breakLen = 0;
	lineWidth = 0;

	while ((ch = chars[length]) != 0)
		{
		length++;

		if ((ch == spaceChr) || (ch == tabChr))
			{
			if (lineWidth >=  maxWidth)
				{
				if (breakLen)
					length = breakLen;

				// Append trailing spaceChrs to the end of the line.
				while (chars[length] == spaceChr) length++;
				
				return (length);
				}
			else
				breakLen = length;

			if (ch == spaceChr)
				lineWidth += FntCharWidth (ch);
			else
				lineWidth += tabChrWidth - (lineWidth % tabChrWidth);
			}

		else if (ch == linefeedChr)
			{
			if (lineWidth > maxWidth)
				length = breakLen;
			return (length);
			}

		else 
			{
			lineWidth += FntCharWidth (ch);
			if (lineWidth > maxWidth) 
				{
				if (breakLen)
					length = breakLen;
				else
					length--;
				return (length);;
				}
			}
		}
	return (length);
}


/***********************************************************************
 *
 * FUNCTION:    FormatLine
 *
 * DESCRIPTION: Given a character position in the field text, determine 
 *              the number of characters that can be displayed on a line.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *              start       postion in text string of first character
 *
 * RETURNED:	 length of the line in characters
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static Word FormatLine (FieldPtr fld, Word start)
{
	if (start >= fld->textLen) return (0);

	return (FntWordWrap (&fld->text[start], fld->rect.extent.x));
}

/***********************************************************************
 *
 * FUNCTION:    FindReverseByte
 *
 * DESCRIPTION: This routine searches a string in reverse order for the
 *              the character specified.
 *
 * PARAMETERS:	fld          a pointer to the string to search
 *             byteToFind   the character to find
 *             len
 *             
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static Boolean FindReverseByte (CharPtr text, char byteToFind, Word len, 
	WordPtr pos)
{
	CharPtr p;
	
	p = text + len - 1;
	
	while (len)
		{
		if (*p == byteToFind)
			{
			*pos = len-1;
			return (true);
			}
		p--;
		len--;
		};
	
	return (false);
}

/***********************************************************************
 *
 * FUNCTION:    StartOfPreviousLine
 *
 * DESCRIPTION: Given the starting position of a display line, calculate
 *              the starting position of the previous line.
 *
 * PARAMETERS:	fld          pointer to a FieldType structure.
 *             startOfLine  starting position of a display line
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static Word StartOfPreviousLine (FieldPtr fld, Word startOfLine)
{
  Word start, endOfPrevLine, retValue;

	startOfLine = min (startOfLine, fld->textLen);
		
	if (startOfLine <= 0) return (0);

   endOfPrevLine = startOfLine - 1;
	if (endOfPrevLine && fld->text[endOfPrevLine] == linefeedChr)
		endOfPrevLine--;

	// Search backward for a linefeedChr.  If we find one, our staring postion
	// is the character after the linefeedChr, otherwise out starting position
	// is the start of the field's text.
	if (FindReverseByte (fld->text, linefeedChr, endOfPrevLine, &start))
      start++;					// skip over the linefeedChr
    else
		start = 0;				// start of text string

   // Format the text until we get to the position passed, and then return
	// the starting position of the prior line. 
	do
      {
      retValue = start;
      start += FormatLine (fld, start);
      }
    while (start < startOfLine);

  return (retValue);
}


/***********************************************************************
 *
 * FUNCTION:    StartOfLine
 *
 * DESCRIPTION: Given the character position, calculate the starting 
 *              position of the line that the character is in.
 *
 * PARAMETERS:	fld     pointer to a FieldType structure.
 *             pos     starting position of a display line
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/7/94	Initial Revision
 *
 ***********************************************************************/
static Word StartOfLine (FieldPtr fld, Word pos)
{
  Word start, retValue;

	if (pos == 0) return (0);

	// Search backward for a linefeedChr.  If we find one, our staring postion
	// is the character after the linefeedChr, otherwise out starting position
	// is the start of the field's text.
	//
	if (FindReverseByte (fld->text, linefeedChr, pos-1, &start))
      start++;					// skip over the linefeedChr
    else
		start = 0;				// start of text string

   // Format the text until we get to the position passed, and then return
	// the starting position of the prior line. 
	//
	do
      {
      retValue = start;
      start += FormatLine (fld, start);
      }
    while (start <= pos && start < fld->textLen);

  return (retValue);
}



/***********************************************************************
 *
 * FUNCTION:    IsSelection
 *
 * DESCRIPTION: This routine returns true if there is a current selection.
 *
 * PARAMETERS:	fld         pointer to a FieldType structure.
 *
 * RETURNED:	true of a selection exists.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static Boolean IsSelection (FieldPtr fld)
{
  return (fld->selFirstPos != fld->selLastPos);
}



/***********************************************************************
 *
 * FUNCTION:    DeleteFromText
 *
 * DESCRIPTION: Delete the range of character specified.
 *
 * PARAMETERS:	 fld            pointer to a FieldType structure.
 *              startPos       position of first character to delete
 *              charsToDelete  number of characters to delete
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *       ron   7/21/95  Now use ModifyText routine in all places that modify the
 *                       text in order to support write-protected data storage.
 *
 ***********************************************************************/
static void DeleteFromText (FieldPtr fld, Word startPos, Word charsToDelete)
{
	CharPtr chars;
	Word    endPos;
	Word    offset;
	Word    blockSize;

	chars = fld->text;
	if (chars && fld->textLen)
		{	
		charsToDelete = min (charsToDelete, fld->textLen -  startPos);
		endPos = startPos + charsToDelete;

		blockSize = MemHandleSize (fld->textHandle);
		if (blockSize == fld->textBlockSize) {
			//<RM> MemMove (&chars[startPos], &chars[endPos], fld->textLen+1 - endPos);
			ModifyText(fld, startPos, &chars[endPos], fld->textLen+1 - endPos);
			}
		else
			{
			offset = fld->text - (CharPtr) MemDeref(fld->textHandle);
			//<RM> MemMove (&chars[startPos], &chars[endPos], blockSize - offset - endPos);
			ModifyText(fld, startPos, &chars[endPos], blockSize - offset - endPos);
			}

		fld->textLen -= (endPos - startPos);
		}
}


/***********************************************************************
 *
 * FUNCTION:    ExpandFieldHeight
 *
 * DESCRIPTION: Given the current position of the insertion point,
 *              determine if the height of the field should be
 *              expanded, If it should, send a fldHeightChangedEvent.
 *
 * PARAMETERS:  fld  pointer to a FieldType structure.
 *              pos  character position of the insertion point.
 *
 * RETURNED:    true if the height of the field should be expanded.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/13/94	Initial Revision
 *
 ***********************************************************************/
static Boolean ExpandFieldHeight (FieldPtr fld, Word pos)
{
	Word numLines;
	Word start;
	Word length;

	if (! fld->attr.dynamicSize) return (false);

	// Check if the height of the field may be expanded and if the
	// field is less than the maximum height.
	//
	numLines = GetVisibleLines (fld);
	if (numLines < GetMaxLines (fld))
		{
		// Determine how many line we need to add to the field in order to
		//	display the position passed.
		length = fld->lines[numLines-1].length;
		start = fld->lines[numLines-1].start + length;

		// If the last character is not a linefeed and is visible, don't 
		// expand the field's height.
		if (start && (start == fld->textLen) && 
			(fld->text[start-1] != linefeedChr))
			return (false);
			

		while (fld->textLen > start)
			{
			length = FormatLine (fld, start);
			start += length;
			if ( ++numLines == GetMaxLines (fld)) break;

			ErrFatalDisplayIf( (length == 0), "Invalid character pos");
			}

		//	If the character position passed contains a line feed, move to the
		// next line.
		if (fld->textLen && fld->text[fld->textLen-1] == linefeedChr && length) 
			numLines = min (numLines+1, GetMaxLines (fld));

		if (numLines == GetVisibleLines(fld))
			return (false);

		// Send an event containing the new bounds of the field and the 
		// character position of the insertion point.  The bounds are not
		// chanaged in this routine, FldSetBounds preforms that function.
		FldSendHeightChangeNotification (fld, pos, numLines);

		return (true);
		}

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    CompactFieldHeight
 *
 * DESCRIPTION: Determine if the height of the field should be
 *              compressed, if it should, send a fldHeightChangedEvent.
 *              Dynamicly sizing field that have blank line need to be
 *              compressed.
 *
 * PARAMETERS:  fld  pointer to a FieldType structure.
 *              pos  character position of the insertion point.
 *
 * RETURNED:    true if the height of the field should be compressed.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/16/95	Initial Revision
 *
 ***********************************************************************/
static Boolean CompactFieldHeight (FieldPtr fld, Word pos)
{
	Word height;
	Word numLines;
	LineInfoPtr line;

	if (! fld->attr.dynamicSize) return (false);

	numLines = GetVisibleLines (fld);
	if (numLines == 1) return (false);
	
	// Check for blank line at the end of the field.
	height = numLines;
	line = &fld->lines [numLines-1];
	while ((line->length == 0) && (height > 1))
		{
		height--;
		line--;
		}

	if (height == numLines) return (false);

	// If the text ends with a linefeed add a line.
	if ( (fld->textLen) && (fld->text[fld->textLen-1] == linefeedChr))
		{
		height++;
		if (height == numLines) return (false);
		}


	// Send an event containing the new bounds of the field and the 
	// character position of the insertion point.  The bounds are not
	// chanaged in this routine, FldSetBounds preforms that function.
	FldSendHeightChangeNotification (fld, pos, height);

	return (true);
}



/***********************************************************************
 *
 * FUNCTION:    ScrollRect
 *
 * DESCRIPTION: Move the bits of the displayed line up or down a line.
 *
 * PARAMETERS:	 fld        pointer to a FieldType structure.
 *              direction  up or down.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void ScrollRectangle (FieldPtr fld, DirectionType direction)
{
	RectangleType  rect;
	RectangleType vacated;
	Word lineHeight;

	RctCopyRectangle (&fld->rect, &rect);
	lineHeight = FntLineHeight();
	rect.extent.y = rect.extent.y / lineHeight * lineHeight;
	WinScrollRectangle (&rect, direction, lineHeight, &vacated);
	WinEraseRectangle (&vacated, 0);
}



/***********************************************************************
 *
 * FUNCTION:    ScrollDisplayDown
 *
 * DESCRIPTION: Scroll the visible lines down by one line and draw a
 *              new line at the top of the field.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void ScrollDisplayDown (FieldPtr fld)
{
	LineInfoPtr line;
	
	if (fld->lines->start > 0)
		{
		// Move the display line information down one line.
		//
		MemMove (&fld->lines[1], fld->lines, 
			sizeof(LineInfoType) * (GetVisibleLines (fld)-1));
	
		// Format and draw the line which scrolled into view.
		//
		line = fld->lines;
		line->start = StartOfPreviousLine (fld, line->start);
		line->length = FormatLine (fld, line->start);
		if (fld->attr.visible)
			{
			ScrollRectangle (fld, down);
			DrawLine (fld, line->start, line->length, 0, true);
			}
		}
}



/***********************************************************************
 *
 * FUNCTION:    ScrollDisplayUp
 *
 * DESCRIPTION: Scroll the visible lines up by one line and draw a
 *              new line at the bottom of the field.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void ScrollDisplayUp (FieldPtr fld)
{
	LineInfoPtr line;
	Word numLines;


	// Move the display line information up oneline.
	numLines = GetVisibleLines (fld);
	MemMove (fld->lines, &fld->lines[1], sizeof(LineInfoType) * (numLines-1));

	// Draw the line which scrolled into view.
	line = &fld->lines[numLines-1];
	line->start = line->start + line->length;
	line->length = FormatLine (fld, line->start);
	if (fld->attr.visible)
		{
		ScrollRectangle (fld, up);
		DrawLine (fld, line->start, line->length, numLines-1, true);
		}
}



/***********************************************************************
 *
 * FUNCTION:    SetInsPtFromStringPos
 *
 * DESCRIPTION:  Given a character position in the field's text, postion
 *               the insertion point.  This routine updated the 
 *               insertion point postion stored in the field's data
 *               structure, it does not position the blinking insertion
 *               point.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              pos  character position in field's text
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94	Initial Revision
 *
 ***********************************************************************/
static void SetInsPtFromStringPos (FieldPtr fld, Word pos)
{
	LineInfoPtr line;
	Word        numLines, i;

	fld->attr.insPtVisible = true;

	pos = min (pos, fld->textLen);

	if (fld->attr.singleLine)
		{
		fld->insPtYPos = 0;
		fld->insPtXPos = pos;			
		return;
	}
	
	if ((! fld->lines) || (! fld->textLen))
		{
		fld->insPtXPos = 0;
		fld->insPtYPos = 0;			
		return;
		}

	// If the character position passed is off the top of the 
	// display, scroll the field down until the character is visible.
	//
	if (fld->textLen)
		{
		line = fld->lines;
		while (pos < line->start)
			{
			ScrollDisplayDown (fld);
			}
		}

	// If the character at the position passed is off the bottom of the 
	// display, scroll the field up until the character is visible.
	//
	numLines = GetVisibleLines (fld);
	line = &fld->lines[numLines-1];
	while (pos > line->start + line->length)
		{
		ScrollDisplayUp (fld);
		}

	//	Determine which visible line the position passed is in, and set the
	// y cooridinate of the insertion point to that line.
	//
	line = fld->lines;
	for (i = 0; i < numLines; i++)
		{
		if (pos <= line->start + line->length)
			break;
		line++;
		}
	fld->insPtYPos = i;

	// Set the x position of the insertion point. If the character position 
	// passed contains a line feed, move to the start of the next line.
	//
	fld->insPtXPos = pos - line->start;
	if (pos && fld->text[pos-1] == linefeedChr)
		{
		if (fld->insPtYPos+1 == numLines)
			{
			ScrollDisplayUp (fld);
			fld->insPtXPos = 0;
			}
		else if ((line->length) && (fld->insPtXPos))
			{
			fld->insPtYPos++;
			fld->insPtXPos = 0;
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    GetStringPosOfInsPtPos
 *
 * DESCRIPTION: Return the string position that matches the insertion 
 *              point position.
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	character position in field's text of insertion point.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94		Initial Revision
 *
 ***********************************************************************/
static Word GetStringPosOfInsPtPos (FieldPtr fld)
{
	LineInfoPtr line;
	FontID      curFont;
	Boolean 		insPtPosPastEndOfText;

	if (! fld->attr.insPtVisible)
		return (fld->selFirstPos);
	
	curFont = FntSetFont (fld->fontID);
	
	ErrNonFatalDisplayIf( (fld->insPtYPos > GetVisibleLines(fld)-1), 
		"Invalid insertion point position");
	
	insPtPosPastEndOfText = fld->insPtYPos > GetVisibleLines(fld)-1;
	FntSetFont (curFont);
	
	if (insPtPosPastEndOfText)
		return (fld->textLen);

	if (fld->attr.singleLine)
		return (fld->insPtXPos);

	if (! fld->lines) return 0;

	line = &fld->lines[fld->insPtYPos];
	if (fld->insPtXPos < line->length)	
		return (line->start + fld->insPtXPos);
		
	if (line->length && (fld->text[line->start + line->length -1] == linefeedChr))
		return (line->start + line->length - 1);
		
	return (line->start + line->length);
}

/***********************************************************************
 *
 * FUNCTION:    PositionVisible
 *
 * DESCRIPTION: This routine returns true if the character position passed
 *              is within the visible text.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *              pos  character position in field's text
 *              
 * RETURNED:	 true if position is visible.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/12/95	Initial Revision
 *
 ***********************************************************************/
static Boolean PositionVisible (FieldPtr fld, Word pos)
{
	Word numLines;
	LineInfoPtr line;
	
	if (fld->attr.singleLine)
		return (true);

	if (! fld->text)
		return (true);

	numLines = GetVisibleLines (fld);
	line = &fld->lines[numLines-1];

//	if (line->length == 0)
//		return (true);

	if (pos < fld->lines->start)
		return (false);

	else if (pos == fld->lines->start)
		return (true);

	else if (pos > line->start + line->length)
		return (false);

	else if (pos == line->start + line->length)
		{
		if (fld->text[pos-1] == linefeedChr)
			return (line->length == 0);
		else
			return (true);
		}

	else 
		return (true);
}


/***********************************************************************
 *
 * FUNCTION:    SetBlinkingInsPtLocation
 *
 * DESCRIPTION: Set the position of the blinking insertion point.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94		Initial Revision
 *
 ***********************************************************************/
static void SetBlinkingInsPtLocation (FieldPtr fld)
{
	short	x, y;
	Word insPtXPos;
	CharPtr chars;

	chars = fld->text;
	x = fld->rect.topLeft.x;

	if (fld->attr.singleLine)
		{
		insPtXPos = fld->insPtXPos;
		if (fld->attr.justification == rightAlign)
			x += fld->rect.extent.x - FntCharsWidth (chars, fld->textLen);
		}
	else if (fld->textLen)
		{
		insPtXPos = min (fld->insPtXPos, 
			GetVisibleCharsInLine(fld, fld->insPtYPos));
		chars += fld->lines[fld->insPtYPos].start;
		}
	else
		insPtXPos = 0;
		
	x += min (FntLineWidth (chars, insPtXPos) - 1, fld->rect.extent.x);
	x = max (x, 0);

	y = fld->rect.topLeft.y + (fld->insPtYPos * FntLineHeight());
	WinWindowToDisplayPt (&x, &y);
	InsPtSetLocation (x, y);
}


/***********************************************************************
 *
 * FUNCTION:    SetInsPtPosFromPt
 *
 * DESCRIPTION: Given a window relitive coordinate, calculate the 
 *              position of the insertion point.  This routine modifies
 *              the field's data structure that keeps track of the 
 *              location of the insertion point.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              x,y  window relitive coordinate
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94		Initial Revision
 *
 ***********************************************************************/
static void SetInsPtPosFromPt (FieldPtr fld, short x, short y)
{
	Word xPos, yPos, charsPerLine, width, lastWidth;
	CharPtr chars;
	LineInfoPtr line;

	fld->attr.insPtVisible = true;


	// Compute the line that the y-coordinate is on.
	yPos = max (((y - fld->rect.topLeft.y) / FntLineHeight ()), 0);
	if (fld->attr.singleLine)
		yPos = 0;
	else
		yPos = min (yPos, GetVisibleLines (fld)-1);
	fld->insPtYPos = yPos;

	// If the coordinate is on a blank line, position the insertion point
	// after the last character of the field.
	if (fld->attr.singleLine)
		charsPerLine = fld->textLen;
	else if (fld->lines)
		charsPerLine = fld->lines[yPos].length;
	else
		charsPerLine = 0;

	if ((charsPerLine == 0))
		{
		if (fld->textLen)
			SetInsPtFromStringPos (fld, fld->textLen);
		else
			{
			fld->insPtXPos = 0;
			fld->insPtYPos = 0;			
			}
		return;
		}

	// Compute the x position of the insertion point.  First, adjust the 
	// x coordinate such that it is within the bounds of field.
	x = max (0, x - fld->rect.topLeft.x);
	if (fld->attr.singleLine)
		{
		chars = fld->text;
		if (fld->attr.justification == rightAlign)
			{
			x -= fld->rect.extent.x - FntCharsWidth (chars, charsPerLine);
			if (x < 0)
				{
				fld->insPtXPos = 0;
				return;
				}
			}
		}
	else 
		{
		line = &fld->lines[yPos];			
		chars = &fld->text[line->start];			
		if (chars[line->length-1] == linefeedChr)
			charsPerLine--;
		}

	// Determine where in the line (the character position) the x coordinate
	// passed is. 
	xPos = 0;
	width = 0;
	lastWidth = 0;
	while (xPos < charsPerLine) 
		{
		if (chars[xPos] != tabChr)
			width += FntCharWidth (chars[xPos]);
		else
			width += tabChrWidth - (width % tabChrWidth);
		
		if (width >= x)
			{
			if ((x - lastWidth) >= ((width - lastWidth) >> 1))
				xPos++;
			break;
			}
		xPos++;
		lastWidth = width;
		}

	fld->insPtXPos = xPos;
}


/***********************************************************************
 *
 * FUNCTION:    UpdateInsPt
 *
 * DESCRIPTION: This routine is called after a field has been
 *              scrolled or the font used to dispaly the field
 *              has been changed.
 *
 *              This routine will turn the blinking insertion point
 *              on if the position where the insertion point is
 *              located is visible.  
 *
 *              If the position of the insertion point was visible
 *              (indicated by the parameter insPtOn) and is not longer
 *              visible, its position is stored in the selFirstPos
 *              member of the field structure.
 *
 * PARAMETERS:	 fld      - pointer to a FieldType structure.
 *              insPtOn  - true if the insertion point was on
 *              insPtPos - character position of the insertion point
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94		Initial Revision
 *
 ***********************************************************************/
static void UpdateInsPt (FieldPtr fld, Boolean insPtOn, Word insPtPos)
{
	// If the insertion point was on and its position is still visible, 
	// turn it back on.  
	if (insPtOn)
		{
		if (PositionVisible (fld, insPtPos))
			{
			SetInsPtFromStringPos (fld, insPtPos);
		  	InsPtEnable (true);
			SetBlinkingInsPtLocation (fld);
			}
		else
			{
			fld->selFirstPos = insPtPos;
			fld->selLastPos = insPtPos;
			fld->insPtXPos = 0;
			fld->insPtYPos = 0;
			fld->attr.insPtVisible = false;
			}
		}

	// If the insertion point was not on and its position was become 
	// visible, turn it on.
	else if (PositionVisible (fld, fld->selFirstPos) &&
		     (! IsSelection (fld)))
		{
		SetInsPtFromStringPos (fld, fld->selFirstPos);
		if (fld->attr.hasFocus)
			{
		  	InsPtEnable (true);
			SetBlinkingInsPtLocation (fld);
			}
		}

	else if (fld->attr.insPtVisible)
		{
		 if (! IsSelection (fld))
		 	{
			fld->selFirstPos = insPtPos;
			fld->selLastPos = insPtPos;
			}
		fld->insPtXPos = 0;
		fld->insPtYPos = 0;
		fld->attr.insPtVisible = false;
		}		
}


/***********************************************************************
 *
 * FUNCTION:    MoveInsPtUpOneLine
 *
 * DESCRIPTION: Move the insertion point up one line, if the insertion
 *              point is on the first visible line, scroll the field down.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94		Initial Revision
 *
 ***********************************************************************/
static void MoveInsPtUpOneLine (FieldPtr fld)
{
	if (fld->attr.singleLine) return;

	if (fld->insPtYPos > 0)
		fld->insPtYPos--;
	else
		ScrollDisplayDown (fld);
}



/***********************************************************************
 *
 * FUNCTION:    MoveInsPtDownOneLine 
 *
 * DESCRIPTION: Move the insertion point down one line, if the insertion
 *              point is on the last visible line, scroll the field up.
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94		Initial Revision
 *
 ***********************************************************************/
static void MoveInsPtDownOneLine  (FieldPtr fld)
{
	Word pos;
	LineInfoPtr line;

	if (fld->attr.singleLine) return;

	// If the current line is not the last line, or if the current line is 
	// the last line and ends with a linefeedChr, move the insertion point down
	// one line.
	//
	line = &fld->lines[fld->insPtYPos];
	pos = line->start + line->length;
	if ( (pos < fld->textLen) || 
	     (line->length && fld->text[pos-1] == linefeedChr) )
		{
		if (fld->insPtYPos < GetVisibleLines(fld)-1)
			fld->insPtYPos++;
		else
			ScrollDisplayUp (fld);
		}
}


/***********************************************************************
 *
 * FUNCTION:    InsPtUp
 *
 * DESCRIPTION: Move the insertion point down a line.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94		Initial Revision
 *
 ***********************************************************************/
static void InsPtUp (FieldPtr fld)
{
	if (!fld->text) return;
	
	if (! fld->attr.insPtVisible)
		SetInsPtFromStringPos (fld, fld->selFirstPos);

	if (IsSelection (fld))
		{
		CancelSelection (fld);
		SetInsPtFromStringPos (fld, fld->selFirstPos);
		}
	else
	  MoveInsPtUpOneLine (fld);
}


/***********************************************************************
 *
 * FUNCTION:    InsPtDown
 *
 * DESCRIPTION: Move the insertion point up a line.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94		Initial Revision
 *
 ***********************************************************************/
static void InsPtDown (FieldPtr fld)
{
	Word pos;
	
	if (!fld->text) return;
	
	if (! fld->attr.insPtVisible)
		SetInsPtFromStringPos (fld, fld->selFirstPos);

	if (IsSelection (fld))
		{
		pos = fld->selLastPos;
		CancelSelection (fld);
		SetInsPtFromStringPos (fld, pos);
		}
	else
	  MoveInsPtDownOneLine (fld);
}


/***********************************************************************
 *
 * FUNCTION:    InsPtLeft
 *
 * DESCRIPTION: Move the insertion point one character left, if the 
 *              insertion point is at the left bound of the field, wrap
 *              to the end of the previous line.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void InsPtLeft (FieldPtr fld)
{
	if (!fld->text) return;
	
	if (! fld->attr.insPtVisible)
		SetInsPtFromStringPos (fld, fld->selFirstPos);

	if (IsSelection (fld))
		{
		CancelSelection (fld);
		SetInsPtFromStringPos (fld, fld->selFirstPos);
		}

	else if (fld->insPtXPos > 0)
		fld->insPtXPos--;

	else if (! fld->attr.singleLine)
		{
		if (fld->lines[fld->insPtYPos].start > 0)
			{
			MoveInsPtUpOneLine (fld);
			fld->insPtXPos = GetVisibleCharsInLine (fld, fld->insPtYPos);
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    InsPtRight
 *
 * DESCRIPTION: Move the insertion point one character right, if the 
 *              insertion point is at the end of the line, wrap
 *              to the start of the next line.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static void InsPtRight (FieldPtr fld)
{
	Word pos;

	if (!fld->text) return;
	
	if (! fld->attr.insPtVisible)
		SetInsPtFromStringPos (fld, fld->selFirstPos);


	if (IsSelection (fld))
		{
		pos = fld->selLastPos;
		CancelSelection (fld);
		SetInsPtFromStringPos (fld, pos);
		}

	else if (fld->insPtXPos < GetVisibleCharsInLine (fld, fld->insPtYPos) )
		fld->insPtXPos++;

	else if (! fld->attr.singleLine)
		{
		if (GetStringPosOfInsPtPos (fld) < fld->textLen)
			{
			MoveInsPtDownOneLine (fld);
			fld->insPtXPos = 0;
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    InsPtInField
 *
 * DESCRIPTION: The routine returns true if the field speciied has the
 *              focus and the insertion point is enabled.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 true if the insertion point is blinking in the specified 
 *              field.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/25/94	Initial Revision
 *
 ***********************************************************************/
static Boolean InsPtInField (FieldPtr fld)
{
	if (fld->attr.hasFocus)
		return (InsPtEnabled());

	return (false);
}

/***********************************************************************
 *
 * FUNCTION:    ModifyText
 *
 * DESCRIPTION: Modifies text in the text handle. This routine correctly
 *					  handles modifying a record contained in the write-protected
 *					  data storage area. 
 *						
 *              This routine assumes the text handle is already locked
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *			       offset   offset into text to start writing
 *              charsP   pointer to next text to write
 *					 len		 len of text to write
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			ron	7/21/95	Initial Revision
 *
 ***********************************************************************/
static void ModifyText (FieldPtr fld, Word offset, CharPtr charsP, Word len)
{
	ULong		startOffset;
	Ptr		chunkP;
	
	// Get the offset of the start of the text in the chunk handle
	chunkP = (CharPtr)MemDeref(fld->textHandle);
	startOffset = fld->text - (CharPtr)chunkP;
	
	// Write the new text
	DmWrite(chunkP, startOffset+offset, charsP, len); 
}



/***********************************************************************
 *
 * FUNCTION:    ExpandTextString
 *
 * DESCRIPTION: Reallocate the memory block that contain the text of the 
 *              field
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              newSize  amount to grow the memory block or zero to increase
 *                       by a default percentage.
 *
 * RETURNED:	 nothing.
 *
 * NOTE:			 If the handle is a database record, this routine may move
 *              the record to another heap, which will cause the handle to
 *              change.             
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94	Initial Revision
 *       ron   7/21/95  Now use ModifyText routine in all places that modify the
 *                       text in order to support write-protected data storage.
 *
 ***********************************************************************/
static Boolean ExpandTextString (FieldPtr fld, Word newSize)
{
	Err	   error;
	Word		offset;
	Word		blockSize;
	Word		newBlockSize;
	VoidHand handle;
	Char		zero=0;
	Ptr		chunkP;

	// If a new length is not sepcified then expand the string by
	// 20% or a minimun of 16 bytes.
	if (newSize == 0)
		{
		newSize = min (fld->maxChars + 1, 
							fld->textBlockSize + max (fld->textBlockSize / 5, 16));
		}
	else 
		newSize++;  // add one for null terminator

	
	// If we already have a handle, we'll resize it.  The field's text
	// string does not necessary start at the begining of the memory
	// block or end at the end of the memory block.  In other words
	// the text string may not be the only thing in the block.
	if (fld->textHandle)
		{
		offset = fld->text - (CharPtr) MemDeref(fld->textHandle);

		blockSize = MemHandleSize(fld->textHandle);
		newBlockSize = blockSize + newSize - fld->textBlockSize;

		MemHandleUnlock (fld->textHandle);
		ErrFatalDisplayIf(MemHandleLockCount(fld->textHandle) > 0, 
			"Field object overlocked");

		error = MemHandleResize (fld->textHandle, newBlockSize);
		
		chunkP = MemHandleLock(fld->textHandle);
		fld->text = (CharPtr) chunkP + offset;

		if (error)
			{
			if (MemHandleDataStorage (fld->textHandle))
				{
				Int index;
				VoidHand h;
				DmOpenRef dbP;
				
				MemHandleUnlock (fld->textHandle);
				
				index = DmSearchRecord (fld->textHandle, &dbP);
				h = DmResizeRecord (dbP, index, newBlockSize);
				if (h)
					{
					fld->textHandle = h;
					chunkP = MemHandleLock(fld->textHandle);
					fld->text = (CharPtr) chunkP + offset;
					}
				else
					{
					chunkP = MemHandleLock(fld->textHandle);
					fld->text = (CharPtr) chunkP + offset;
					FrmAlert (DeviceFullAlert);
					return (false);
					}
				}

			else
				ErrDisplay ("Memory reallocation error");
			}
		
		
		// Null terminate.
		if (fld->textLen == 0)
			ModifyText(fld, 0, &zero, sizeof(Char));


		fld->textBlockSize = newSize;
		}


	// Allocate a new block to hold the text string and null terminate it.
	else
		{
		handle = MemHandleNew (newSize);
		fld->textHandle = handle;
		fld->text = MemHandleLock (handle);

		ModifyText(fld, 0, &zero, sizeof(Char));
		
		fld->textBlockSize = newSize;
		
		AllocateLines (fld);
		}

	return (true);
}

/***********************************************************************
 *
 * FUNCTION:    AtEndOfLine
 *
 * DESCRIPTION: This routine will return true if the insertion point 
 *              is after the last character of a line.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 true if after last character of a line.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/25/94		Initial Revision
 *
 ***********************************************************************/
static Boolean AtEndOfLine (FieldPtr fld, Word pos)
{
//	Word lineNum;
	
	if (fld->attr.singleLine)
		{
		if (fld->attr.justification == leftAlign)
			return (fld->insPtXPos+1 == fld->textLen);
		else
			return (false);
		}

//	lineNum = fld->insPtYPos;
//	if (fld->insPtXPos < fld->lines[lineNum].length)
//		return (false);

	if (pos == fld->textLen)
		return (true);
	
	if (fld->text[pos] == linefeedChr)
		return (true);
		
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    InvertCharsRange
 *
 * DESCRIPTION: Invert specified characer range on the specified line.
 *              This rountine performs the actual inverting.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              lineNum  line number
 *              startPos character position of start of range
 *              endPos   character position of end of range.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/28/94		Initial Revision
 *
 ***********************************************************************/
static void InvertCharsRange (FieldPtr fld, Word lineNum, Word startPos,
	Word endPos)
{
	RectangleType r;
	LineInfoPtr line;
	
	if (fld->attr.singleLine)
		{
		r.topLeft.x = FntCharsWidth (fld->text, startPos);
		if (fld->attr.justification == rightAlign)
			{
			r.topLeft.x += fld->rect.extent.x - 
				FntCharsWidth (fld->text, fld->textLen);
			}	

		if ((r.topLeft.x) > fld->rect.extent.x)
			return;

		r.extent.x = FntCharsWidth (&fld->text[startPos], endPos-startPos);
		if ((r.topLeft.x + r.extent.x) > fld->rect.extent.x)
			r.extent.x = fld->rect.extent.x - r.topLeft.x;
		}
	else
		{
		line = &fld->lines[lineNum];
		r.topLeft.x = FntLineWidth (&fld->text[line->start], 
			startPos - line->start);
	
		r.extent.x = FntLineWidth (&fld->text[line->start], 
			endPos - line->start) - r.topLeft.x;
		}

	r.topLeft.x += fld->rect.topLeft.x;
	r.extent.y = FntLineHeight ();
	r.topLeft.y = fld->rect.topLeft.y + (lineNum * r.extent.y);
	

	// Trailing spaces may cause the update region to be outside the bounds 
	// of the field.
	if (r.topLeft.x > fld->rect.topLeft.x + fld->rect.extent.x)
		return;
		
	if (r.topLeft.x + r.extent.x > fld->rect.topLeft.x + fld->rect.extent.x)
		r.extent.x = fld->rect.extent.x - (r.topLeft.x - fld->rect.topLeft.x);

	WinInvertRectangle (&r, 0);
}


/***********************************************************************
 *
 * FUNCTION:    UpdateHighlight
 *
 * DESCRIPTION: Adjust the current highlighted region to include or exclude
 *              the specified range of characters.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              startPos character position of start of range
 *              endPos   character position of end of range.           
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/25/94		Initial Revision
 *
 ***********************************************************************/
static void UpdateHighlight (FieldPtr fld, Word startPos, Word endPos)
{
	LineInfoPtr line;
	Word numLines;
	Word lineNumber;
	Word invertStart;
	Word invertEnd;
	Word lineStartPos;
	Word lineEndPos;

	if (fld->selFirstPos == fld->selLastPos)
		{
		invertStart = startPos;
		invertEnd = endPos;
		}
	else if (fld->selFirstPos == startPos)
		{
		invertStart = min (fld->selLastPos, endPos);
		invertEnd = max (fld->selLastPos, endPos);
		}
	else if (fld->selLastPos == endPos)
		{
		invertStart = min (fld->selFirstPos, startPos);
		invertEnd = max (fld->selFirstPos, startPos);
		}
	else
		{
		invertStart = min (fld->selFirstPos, startPos);
		invertEnd = max (fld->selLastPos, endPos);
		}

	if (fld->attr.singleLine)
		{
		InvertCharsRange (fld, 0, invertStart, invertEnd);
		return;
		}

	line = fld->lines;
	numLines = GetVisibleLines (fld);

	for (lineNumber = 0; lineNumber < numLines; lineNumber++)
		{
		if ((invertStart < line->start + line->length) && 
		    (invertEnd > line->start))
			{
			lineStartPos = max (invertStart, line->start);
			lineEndPos = min (invertEnd , line->start + line->length);
			InvertCharsRange (fld, lineNumber, lineStartPos, lineEndPos);
			}
		line++;
		}
}


/***********************************************************************
 *
 * FUNCTION:    InvertSelection
 *
 * DESCRIPTION: Invert the current selection.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94		Initial Revision
 *
 ***********************************************************************/
static void InvertSelection (FieldPtr fld)
{
	LineInfoPtr line;
	Word lineNumber;
	Word numLines;
	Word startPos;
	Word endPos;

	if (fld->attr.singleLine)
		{
		InvertCharsRange (fld, 0, fld->selFirstPos, fld->selLastPos);
		}

	else
		{
		line = fld->lines;
		numLines = GetVisibleLines (fld);

		for (lineNumber = 0; lineNumber < numLines; lineNumber++)
			{
			if ((fld->selFirstPos < line->start + line->length) && 
			    (fld->selLastPos > line->start))
				{
				startPos = max (fld->selFirstPos, line->start);
				endPos = min ( fld->selLastPos, line->start + line->length);
				InvertCharsRange (fld, lineNumber, startPos, endPos);
				}
			line++;
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    InvertSelectionInLine
 *
 * DESCRIPTION: Invert the range of the current selection that is 
 *              in the specified line.
 *
 * PARAMETERS:	 fld     - pointer to a FieldType structure.
 *              lineNum - line number (zero based).
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/21/94		Initial Revision
 *
 ***********************************************************************/
static void InvertSelectionInLine (FieldPtr fld, Word lineNumber)
{
	LineInfoPtr line;
	Word startPos;
	Word endPos;

	if (fld->attr.singleLine)
		{
		InvertCharsRange (fld, 0, fld->selFirstPos, fld->selLastPos);
		return;
		}

	line = &fld->lines[lineNumber];
	if ((fld->selFirstPos < line->start+ line->length) && 
	    (fld->selLastPos > line->start))
		{
		startPos = max (fld->selFirstPos, line->start);
		endPos = min ( fld->selLastPos, line->start + line->length);
		InvertCharsRange (fld, lineNumber, startPos, endPos);
		}
}


/***********************************************************************
 *
 * FUNCTION:    SetSelection
 *
 * DESCRIPTION: Set a current selection to the range specified and
 *              update the highlighting of the the selection.  If
 *              and startPos and endPos are the same, there will no
 *              highlighted selection.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              startPos character position of start of selection
 *              endPos   character position of end of selection 
 *
 * RETURNED:	
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94		Initial Revision
 *
 ***********************************************************************/
static void SetSelection (FieldPtr fld, Word startPos, Word endPos)
{
	Word temp;
  if (startPos == endPos)
    {
    if (IsSelection (fld)) InvertSelection (fld);
    }
  else
    {
    if (startPos > endPos)
    	{
    	temp = startPos;
    	startPos = endPos;
		endPos = temp;
    	}
	 UpdateHighlight (fld, startPos, endPos);
    }
	fld->selFirstPos = startPos;
	fld->selLastPos = endPos;
}



/***********************************************************************
 *
 * FUNCTION:    CancelSelection
 *
 * DESCRIPTION: Unhighlight the current selection an set and start and end
 *              postions of the selection range to zero.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/25/94		Initial Revision
 *
 ***********************************************************************/
static void CancelSelection (FieldPtr fld)
{
	if (IsSelection (fld)) InvertSelection (fld);
	fld->selLastPos = fld->selFirstPos;
}


/***********************************************************************
 *
 * FUNCTION:    ScrollSelectionDown
 *
 * DESCRIPTION: Scroll the field down a line and highlight the new line that
 *              is visible at the top of the field.
 *
 *              This routine is called while drag selecting.
 *
 * PARAMETERS:	 fld       pointer to a FieldType structure.
 *              anchorPos anchor position of selection (characher position)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94		Initial Revision
 *
 ***********************************************************************/
static void ScrollSelectionDown (FieldPtr fld, Word anchorPos)
{
	if (fld->attr.singleLine) return;

	if (! fld->lines) return;

	if (fld->lines->start)
		{

		if (fld->lines->start > anchorPos)
			{
			InvertSelection (fld);
			fld->selLastPos = StartOfPreviousLine (fld, fld->lines->start);
			}

		ScrollDisplayDown (fld);
		SetSelection (fld, fld->lines->start, anchorPos);
		}
}


/***********************************************************************
 *
 * FUNCTION:    ScrollSelectionUp
 *
 * DESCRIPTION: Scroll the field up a line and highlight the new line that
 *              is visible at the bottom of the field.
 *
 *              This routine is called while drag selecting.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              anchorPos anchor position of selection (characher position)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/23/94		Initial Revision
 *
 ***********************************************************************/
static void ScrollSelectionUp (FieldPtr fld, Word anchorPos)
{
	Word pos;
	LineInfoPtr line;

	if (fld->attr.singleLine) return;

	if (! fld->lines) return;

	line = &fld->lines[GetVisibleLines(fld)-1];
	pos = line->start + line->length;

	if ( (pos < fld->textLen) || 
	     (line->length && fld->text[pos-1] == linefeedChr) )
		{
		if (pos < anchorPos)
			{
			InvertSelection (fld);
			pos += FormatLine (fld, pos);
			fld->selFirstPos = pos;
			}
			
		ScrollDisplayUp (fld);
		pos = line->start + line->length;
		SetSelection (fld, anchorPos, pos );
		}
}


/***********************************************************************
 *
 * FUNCTION:    GetBoundsOfInsPtPos
 *
 * DESCRIPTION: Return the bound of the insertion point position.  
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/25/94	Initial Revision
 *
 ***********************************************************************/
static void GetBoundsOfInsPtPos (FieldPtr fld, RectanglePtr r)
{
	Word pos, width, charsInLine;
	CharPtr chars;
	LineInfoPtr line;

	if (fld->attr.singleLine)
		{
		chars = fld->text;
		charsInLine = fld->textLen;
		r->topLeft.x = fld->rect.topLeft.x;
		if (fld->attr.justification == rightAlign)
			r->topLeft.x += fld->rect.extent.x - GetLineCharsWidth (fld, 0);
		}
	else if (fld->text)
		{
		line = &fld->lines[fld->insPtYPos];
		chars = &fld->text[line->start];
		charsInLine = line->length;
		r->topLeft.x = fld->rect.topLeft.x;
		}
	else
		charsInLine = 0;

	if (charsInLine)
		{
		width = 0;
		pos = fld->insPtXPos;

		// Calculate the size of half of the width of the character before
		// the insertion point.
		if (pos > 0)
			{
			if (chars[pos-1] != tabChr)
				width = (FntCharWidth (chars[pos-1]) + 1) / 2;
			else if (pos > 1)
				width = (FntLineWidth (chars, pos) - 
							FntLineWidth (chars, pos-1) + 1) / 2;
			else
				width = (tabChrWidth + 1) / 2;


			r->topLeft.x += FntLineWidth (chars, pos) - width;
			}

		// Add half of the width of the character following the insertion point.
		if (chars[pos] != tabChr)
			width += FntCharWidth (chars[pos]) / 2;

		else if (charsInLine > 1)
			width += (FntLineWidth (chars, pos+1) - 
						 FntLineWidth (chars, pos)) / 2;
		else
			width += tabChrWidth / 2;

		r->extent.x = width;
		}

	// If there are not any character on the line, the bounds extent to the 
	// full width of the field.
	else
		{
		r->extent.x = fld->rect.extent.x;
		}


	r->topLeft.y = fld->rect.topLeft.y + (fld->insPtYPos * FntLineHeight()); 
	r->extent.y = FntLineHeight();
}


/***********************************************************************
 *
 * FUNCTION:     SaveSelection
 *
 * DESCRIPTION:  This routine save the current field selection to 
 *               the undo buffer.
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *               pos - character postion
 *
 * RETURNED:     true if selection was sucessfully saved to the undo
 *               buffer
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static Boolean UndoSaveSelection (FieldPtr fld)
{
	Word count;
	
	count = fld->selLastPos - fld->selFirstPos;
	if (count < undoBufferSize)
		{
		MemMove (UndoGlobals.buffer, &fld->text[fld->selFirstPos], count);
		UndoGlobals.bufferLen = count;
		}
	else
		{
		if (FrmAlert (UndoAlert) == UndoCancelButton) 
			return (false);
		else
			UndoGlobals.bufferLen = 0;
		}
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:     UndoReset
 *
 * DESCRIPTION:  This routine resets the undo gloabal variables.  It 
 *               should be called each time a field object gains the
 *              focus.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static void UndoReset (void)
{
	UndoGlobals.mode = undoNone;
}


/***********************************************************************
 *
 * FUNCTION:     UndoRecordTyping
 *
 * DESCRIPTION:  This routine is called wherever a character is input.
 *               If the current undo mode is not typing mode, the undo 
 *               state is cleared, and the starting and ending
 *               positions of the typed character range are initialized 
 *               to the values passed.  If the current undo mode is
 *               typing mode the end position of the typed 
 *               character range is incremented.
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *               pos - character postion
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static Boolean UndoRecordTyping (FieldPtr fld,  Word pos)
{
	if (UndoGlobals.mode == undoTyping)
		{
		UndoGlobals.mode = undoNone;
		}
	else
		{
		UndoGlobals.mode = undoTyping;
		UndoGlobals.start = pos;
		UndoGlobals.end = pos + 1;
		UndoGlobals.bufferLen = 0;
		
		if (fld->selFirstPos != fld->selLastPos)
			{
			if (! UndoSaveSelection (fld))
				return (false);
			}
		}
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:     UndoRecordBackspaces
 *
 * DESCRIPTION:  This routine is called wherever a backspace character 
 *               is input.  If the current undo mode is not backspace mode,
 *               and there is a selection,  the selection is saved to the 
 *               undo buffer and the undo mode is set to delete mode.  If
 *               there is not a selection, the character to backspace is 
 *               save to the undo buffer.
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *               pos - character position of the chaacter to backspace
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static Boolean UndoRecordBackspaces (FieldPtr fld, Word pos)
{
	if (UndoGlobals.mode == undoBackspace)
		{
		UndoGlobals.bufferLen = min (UndoGlobals.bufferLen+1, 
			undoBufferSize);

		MemMove (&UndoGlobals.buffer[1], UndoGlobals.buffer,
			UndoGlobals.bufferLen - 1);

		UndoGlobals.buffer[0] = fld->text[pos];
		}
	else
		{
		if (fld->selFirstPos != fld->selLastPos)
			{
			UndoGlobals.mode = undoDelete;
			if (! UndoSaveSelection (fld))
				{
				UndoGlobals.mode = undoNone;
				return (false);
				}
			}
		else
			{ 
			UndoGlobals.mode = undoBackspace;
			UndoGlobals.bufferLen = 1;
			UndoGlobals.buffer[0] = fld->text[pos];
			}
		}
	return (true);
}



/***********************************************************************
 *
 * FUNCTION:     UndoRecordPaste
 *
 * DESCRIPTION:  This routine is called wherever a paste editing command
 *               is executed.  The starting and ending positions of the 
 *               character pasted are recorded,  If there is a selection 
 *               the selected character are copied to the undo buffer.
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *               pos - character position where the pasted occurs
 *
 * RETURNED:     false if paste operation was canceled
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static Boolean UndoRecordPaste (FieldPtr fld, Word pos)
{
	Word count;

	UndoGlobals.mode = undoPaste;
	UndoGlobals.start = pos;

	ClipboardGetItem (clipboardText, &count);
	UndoGlobals.end = UndoGlobals.start + count;
	
	if (fld->selFirstPos != fld->selLastPos)
		{
		return (UndoSaveSelection (fld));
		}
	else
		UndoGlobals.bufferLen = 0;
		
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:     UndoRecordCut
 *
 * DESCRIPTION:  This routine is called wherever a cat editing command
 *               is executed.  
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *
 ***********************************************************************/
static void UndoRecordCut (FieldPtr fld)
{
	UndoGlobals.mode = undoCut;
}



/***********************************************************************
 *
 * FUNCTION:     FldUndo
 *
 * DESCRIPTION:  Always undo the right thing.  Got it?
 *
 * PARAMETERS:   fld - pointer to the field that has the focus
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/7/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldUndo (const FieldPtr fld)
{
	Word count;
	VoidHand charsH;
	CharPtr charsP;
	
	switch (UndoGlobals.mode)
		{
		case undoNone:
			SndPlaySystemSound (sndError);
			break;
			
		// Undo typing.
		case undoTyping:
			FldDelete (fld, UndoGlobals.start, UndoGlobals.end);
			FldInsert (fld, UndoGlobals.buffer, UndoGlobals.bufferLen);
			break;
			

		// Undo backspaces.
		case undoBackspace:
			FldInsert (fld, UndoGlobals.buffer, UndoGlobals.bufferLen);
			break;

			
		// Undo delete.
		case undoDelete:
			FldInsert (fld, UndoGlobals.buffer, UndoGlobals.bufferLen);
			break;
			

		// Undo paste.
		case undoPaste:
			FldDelete (fld, UndoGlobals.start, UndoGlobals.end);
			FldInsert (fld, UndoGlobals.buffer, UndoGlobals.bufferLen);
			break;
			

		// Undo cut.
		case undoCut:
			charsH = ClipboardGetItem (clipboardText, &count);
			if (charsH)
				{
				charsP = MemHandleLock (charsH);
				FldInsert (fld, charsP, count);
				MemPtrUnlock (charsP);
				}
			break;
		}

	UndoReset ();
}


/***********************************************************************
 *
 * FUNCTION:    FldDrawField
 *
 * DESCRIPTION: This routine draw the text of a field and the frame.
 *
 * PARAMETERS:	 fld   pointer to a FieldType structure.
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldDrawField (const FieldPtr fld)
{
	FontID      curFont;
	Boolean     insPtOn;

	if (! fld->attr.usable) return;

	curFont = FntSetFont (fld->fontID);

	if ((insPtOn = InsPtInField (fld)) == true)
		{
		InsPtEnable (false);
		}

	DrawLines (fld, fld->attr.visible);

	if (insPtOn)
		{
	  	InsPtEnable (true);
		SetBlinkingInsPtLocation (fld);
		}
	else if (IsSelection (fld))
		InvertSelection (fld);


	fld->attr.visible = 1;

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldEraseField
 *
 * DESCRIPTION: This routine erases the text of a field and turns off
 *              the insertion point if its in the field.
 *
 * PARAMETERS:  fld    pointer to a FieldType structure.
 *
 * RETURNED:   nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldEraseField (const FieldPtr fld)
{
	if ( fld->attr.visible  && fld->attr.usable)
		{
		if (fld->attr.hasFocus)
			InsPtEnable (false);

		WinEraseRectangle (&fld->rect, 0);

		fld->attr.visible = false;
		}
}


/***********************************************************************
 *
 * FUNCTION:    FldCopy
 *
 * DESCRIPTION: This routine copies the current selection to the text
 *              clipboard.
 *
 * PARAMETERS:  fld    pointer to a FieldType structure.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldCopy (const FieldPtr fld)
{
	Word charsToCopy;

	// Beep if there is not a selection.
	if (! IsSelection (fld)) 
		{
		SndPlaySystemSound (sndError);
		return;
		}
	
	charsToCopy = fld->selLastPos - fld->selFirstPos;

	if (charsToCopy > cbdMaxTextLength)
		{
		FrmAlert (ClipboardLimitAlert);
		return;
		}

	ClipboardAddItem (clipboardText, fld->text + fld->selFirstPos, 
		charsToCopy);
}


/***********************************************************************
 *
 * FUNCTION:    FldCut
 *
 * DESCRIPTION: This routine copies the current selection to the text
 *              clipboard, deletes the selection from the field and
 *              redraws the field.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			art	4/19/96	Added autoshifting
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldCut (const FieldPtr fld)
{
	Word charsToDelete;

	// Beep if there is not a selection.
	if (! IsSelection (fld)) 
		{
		SndPlaySystemSound (sndError);
		return;
		}
	
	charsToDelete = fld->selLastPos - fld->selFirstPos;
	if (charsToDelete > cbdMaxTextLength)
		{
		FrmAlert (ClipboardLimitAlert);
		return;
		}

	UndoRecordCut (fld);

	ClipboardAddItem (clipboardText, fld->text + fld->selFirstPos, charsToDelete);
	FldDelete (fld, fld->selFirstPos, fld->selLastPos);
	
	AutoShift (fld);
}


/***********************************************************************
 *
 * FUNCTION:    FldPaste
 *
 * DESCRIPTION: This routine replaces the current selection with the 
 *              contents of the text clipboard.  If there is no current 
 *              selection, the clipboard text is inserted at the position
 *              of the insertion point.
 *
 * PARAMETERS:  fld    pointer to a FieldType structure.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *       ron   7/21/95  Now use ModifyText routine in all places that modify
 *                      the text in order to support write-protected data
 *                      storage.
 *       art   8/8/95   Code moved to FldInsert
 *			art	4/19/96	Added autoshifting
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldPaste (const FieldPtr fld)
{
	Word pos;
	Word pasteLen;
	VoidHand pasteCharsH;
	CharPtr pasteChars;

	// Get the text of paste from the clipboard,  if there's nothing
	// on the clipboard, beep and exit.
	pasteCharsH = ClipboardGetItem (clipboardText, &pasteLen);
	if ((! pasteLen) || (! pasteCharsH))
		{
		SndPlaySystemSound (sndError);
	 	return;
	 	}

	if (fld->selLastPos != fld->selFirstPos)
		pos = fld->selFirstPos;
	else
		pos = GetStringPosOfInsPtPos (fld);

	
	// Copy to current selection the undo buffer, if it will fix.
	if (UndoRecordPaste (fld, pos))
		{
		pasteChars = MemHandleLock (pasteCharsH);

		if (! FldInsert (fld, pasteChars, pasteLen))
			UndoReset ();

		MemPtrUnlock (pasteChars);
		}

	AutoShift (fld);
}


/***********************************************************************
 *
 * FUNCTION:    FldInsert
 *
 * DESCRIPTION: This routine replaces the current selection with the 
 *              string passed.  If there is no current selection, 
 *              the string passed is inserted at the position
 *              of the insertion point.
 *
 * PARAMETERS:  fld    pointer to a FieldType structure.
 *
 * RETURNED:    true if the string was successfully inserted.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/8/94	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean FldInsert (const FieldPtr fld, const CharPtr insertChars, 
	const Word insertLen)
{
	FontID curFont;
	Word byteToMove;
	Word offset;
	Word newLen;
	Word charsToDelete;
	Word pos;

	if (! fld->attr.editable) return (false);

	if (insertLen == 0) return (false);
	
	charsToDelete = fld->selLastPos - fld->selFirstPos;
	newLen = fld->textLen + insertLen - charsToDelete ;

	// If inserting the text passed will expand the field 
	// beyond its maximun character limit, don't insert the text.
	if (newLen > fld->maxChars)
		{
		SndPlaySystemSound (sndError);
		return (false);
		}


	curFont = FntSetFont (fld->fontID);

	// If necessary, expand the memory block that contains the field's 
	// text string.
	if (newLen >= fld->textBlockSize)
		{
		if (! ExpandTextString (fld, newLen))
			{
			FntSetFont (curFont);
			return (false);
			}
		}


	fld->attr.dirty = true;

	// If there's a selection, delete it.
	if (charsToDelete)
		{
		pos = fld->selFirstPos;
		CancelSelection (fld);
		DeleteFromText (fld, pos, charsToDelete);
		}
	else
		pos = GetStringPosOfInsPtPos (fld);

					
	// Insert the text passed.
	offset = fld->text - (CharPtr) MemDeref(fld->textHandle);
	byteToMove = MemHandleSize (fld->textHandle) - pos - offset - insertLen;
	ModifyText (fld, pos + insertLen, fld->text + pos, byteToMove);
	ModifyText (fld, pos, insertChars, insertLen);
	fld->textLen += insertLen;


	// Redraw the field
	InsPtEnable (false);
	
	if (fld->attr.singleLine)
		FormatAndDrawLines (fld, fld->attr.visible);
	else
		{
		if ((pos < fld->lines->start) || (! fld->attr.insPtVisible))
			FormatAndDrawFromPos (fld, pos, fld->attr.visible);
		else
			FormatAndDrawFromPos (fld, fld->lines->start, fld->attr.visible);
		}
	

	if (! ExpandFieldHeight (fld, pos+insertLen))
		{
		SetInsPtFromStringPos (fld, pos+insertLen);
		SetBlinkingInsPtLocation (fld);
		CompactFieldHeight (fld, pos+insertLen);
		}


	FldSendChangeNotification (fld);

	InsPtEnable (fld->attr.visible && fld->attr.insPtVisible);

	FntSetFont (curFont);
	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    FldDelete
 *
 * DESCRIPTION: This routine deletes the specified range of characters 
 *              from the field and redraws the field.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *              start  starting character position
 *              end    ending character position
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/8/95	Initial Revision
 *			art	7/2/96	Add check text value
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldDelete (const FieldPtr fld, const Word start, const Word end)
{
	FontID curFont;
	Word charsToDelete;
	Word pos;

	if (!fld->text) return;

	curFont = FntSetFont (fld->fontID);

	fld->attr.dirty = true;

	CancelSelection (fld);

	if (fld->attr.hasFocus)
		InsPtEnable (false);

	charsToDelete = end - start;
	pos = start;

	DeleteFromText (fld, pos, charsToDelete);

	if ((pos < fld->lines->start) || (! fld->attr.insPtVisible))
		{
		FormatAndDrawFromPos (fld, pos, fld->attr.visible);
		SetInsPtFromStringPos (fld, pos);
		}
	else
		{
		SetInsPtFromStringPos (fld, pos);
		UpdateStartOfLines (fld, -charsToDelete, fld->insPtYPos+1);
		FormatAndDrawIfWrappingChanged (fld, fld->insPtYPos);
		SetInsPtFromStringPos (fld, pos);			
		}

	if (fld->attr.hasFocus)
		{
		SetBlinkingInsPtLocation (fld);
		InsPtEnable (fld->attr.visible);
		}

	if (! CompactFieldHeight (fld, pos))
		ExpandFieldHeight (fld, pos);

//	if (fld->attr.hasScrollBar)
		FldSendChangeNotification (fld);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldRecalculateField
 *
 * DESCRIPTION: Recalculate the beginnings (starting character position) and
 *              length of all the visible lines of the field.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/28/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldRecalculateField (const FieldPtr fld, const Boolean redraw)
{
	FontID curFont;

	if (fld->attr.singleLine) return;
	
	curFont = FntSetFont (fld->fontID);
	
	if (! fld->lines)
		AllocateLines (fld);
		
	fld->insPtXPos = 0;
	fld->insPtYPos = 0;

	if (redraw)
		{
		if ((InsPtInField (fld)) == true)
			InsPtEnable (false);

		FormatAndDrawLines (fld, fld->attr.visible);
		}
	
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldGrabFocus
 *
 * DESCRIPTION: Set the location and height the blinking insertion point
 *              and start the insertion point blinking.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/1/94	Initial Revision
 *			art	3/27/96	Add autoshifting
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldGrabFocus (const FieldPtr fld)
{
	FontID curFont;
	
	if ((! fld->attr.editable) || (! fld->attr.usable)) return;

	if (fld->attr.hasFocus) return;
	
	fld->attr.hasFocus = 1;

	curFont = FntSetFont (fld->fontID);
	InsPtSetHeight (FntLineHeight());

	if ( (! IsSelection(fld)) && fld->attr.insPtVisible)
		{
		SetBlinkingInsPtLocation (fld);
		if (fld->attr.visible)
			InsPtEnable (true);
		}
	FntSetFont (curFont);

	// Auto-shift if the field is empty.
	if (fld->attr.autoShift && (! fld->textLen))
		GrfSetState (false, false, true);

//	if (fld->attr.autoShift)
//		AutoShift (fld);
	else
		GrfSetState (false, false, false);
}


/***********************************************************************
 *
 * FUNCTION:    FldReleaseFocus
 *
 * DESCRIPTION: Turn off the blinking insertion point, reset the graffiti
 *              state and the undo state.
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/8/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldReleaseFocus (const FieldPtr fld)
{
	Word charsToDelete;
	FontID curFont;
	
	if (fld->attr.hasFocus)
		{
		curFont = FntSetFont (fld->fontID);
		InsPtEnable (false);

		// Delete partial graffiti macro names.
		GrfFieldChange (true, &charsToDelete);
		
//		if (charsToDelete)
//			{
//			pos = GetStringPosOfInsPtPos (fld);
//			FldDelete (fld, pos, pos + charsToDelete);
//			}

		UndoReset ();

		fld->attr.hasFocus = 0;
		FntSetFont (curFont);
		}
}


/***********************************************************************
 *
 * FUNCTION:    FldGetSelection
 *
 * DESCRIPTION: This routine returns the current selection of a field.
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *
 * RETURNED:    startPos starting character position of character range
 *              endPos   ending character posiiton of character range,
 *                       range is exclusive of ending position.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldGetSelection (const FieldPtr fld, const WordPtr startPosition, 
	const WordPtr endPosition)
{
	*startPosition = fld->selFirstPos;
	*endPosition = fld->selLastPos;
}


/***********************************************************************
 *
 * FUNCTION:    FldSetSelection
 *
 * DESCRIPTION: Set the current selection of a field and highligth the 
 *              selection if the field is visible.  If the startPosition
 *              equals the endPosition, the current selection is
 *              unhighlighted.
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *              startPos starting character position of character range
 *              endPos   ending character posiiton of character range,
 *                       range is exclusive of ending position.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetSelection (const FieldPtr fld, const Word startPosition, 
	const Word endPosition)
{
	FontID curFont;
	
	if (fld->attr.visible)
		{
		curFont = FntSetFont (fld->fontID);
		if (fld->attr.hasFocus)
			InsPtEnable (false);

		CancelSelection (fld);
			
		SetSelection (fld, startPosition, endPosition);
		if (fld->attr.hasFocus && startPosition == endPosition)
			InsPtEnable (true);
		FntSetFont (curFont);
		}
	else
		{
		fld->selFirstPos = startPosition;
		fld->selLastPos = endPosition;
		}

	UndoReset ();
}


/***********************************************************************
 *
 * FUNCTION:    FldGetBounds
 *
 * DESCRIPTION: Return the current visual bounds of a field.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *
 * RETURNED:    rect        bounds of the field.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldGetBounds (const FieldPtr fld, const RectanglePtr rect)
{
	RctCopyRectangle (&fld->rect, rect);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetBounds
 *
 * DESCRIPTION: This routine changes the bounds of a field and if the
 *              field is visible, redraw the field.  
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *              rect        new bounds of the field
 *
 * RETURNED:    nothing.
 *
 * KNOWN PROBLEMS:
 *		This routine does support changed the width of a visible field.
 *    The insertion point is assumed to be off when this routine is 
 *    called.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetBounds (const FieldPtr fld, const RectanglePtr rect)
{
	FontID			curFont;
	LineInfoPtr		line;
	VoidHand 		handle;
	Word				error;
	Word				start;
	Word				lineNum;
	Word				numLines;
	Word				newNumLines;

	curFont = FntSetFont (fld->fontID);

	numLines = GetVisibleLines (fld);
	newNumLines = (rect->extent.y / FntLineHeight());

	// If the height of the field is being changed, resize the block that 
	// contains the line word wrapping info.
	if (fld->lines && fld->rect.extent.y != rect->extent.y)
		{
		if (newNumLines != numLines)
			{
			handle = MemPtrRecoverHandle (fld->lines);
			MemHandleUnlock (handle);
			error = MemHandleResize (handle, newNumLines * sizeof(LineInfoType));
			ErrFatalDisplayIf( error, "Memory reallocation error");
			fld->lines = MemHandleLock (handle);
			}
		}


	// Set the new bounds of the field.
	RctCopyRectangle (rect, &fld->rect);


	// Word wrap and draw the new lines.
	if (fld->lines && newNumLines > numLines)
		{
		line = &fld->lines[numLines];
		start = fld->lines[numLines-1].start +
		        fld->lines[numLines-1].length;
		for (lineNum = numLines; lineNum < newNumLines; lineNum ++)
			{
			line->start = start;
			line->length = FormatLine (fld, line->start);
			start += line->length;
			if (fld->attr.visible)
		   	DrawLine (fld, line->start, line->length, lineNum, true);
			line++;
			}
		}

	if (fld->attr.hasFocus)
		SetBlinkingInsPtLocation (fld);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetText
 *
 * DESCRIPTION: This routine sets the text value of the field,  updates
 *              the word wrapping infomation and places the insertion point
 *              after the last visible character.
 *
 *              The pointer pass is stored in the field's structure, 
 *              in other words this routine does not make a copy of
 *              the string passed.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *              textHandle  handle of a block that contain a null-terminated
 *                          text string.
 *              offset      offset from the start of the block to the start of 
 *                          the text string.
 *              size        allocated size of the text string, ** NOT ** the
 *                          string length.
 *
 * RETURNED:    nothing.
 *
 * NOTE:
 *		!!! This routine does NOT free the memory block that holds the
 *		current text value. 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/ 9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *			roger	12/8/97	Added call to UndoReset.
 *
 ***********************************************************************/
void FldSetText (const FieldPtr fld, const VoidHand textHandle, const Word offset, 
	const Word size)
{
	Word pos;
	FontID curFont;
	
	// Validate the pass parameters.
#if ERROR_CHECK_LEVEL != ERROR_CHECK_NONE

	if (textHandle)
		{
		if (MemHandleSize(textHandle) < offset)
			ErrDisplay ("Offset passed out of block");

		if (MemHandleSize(textHandle) < offset + size)
			ErrDisplay ("Invalid size");
		}

#endif


	curFont = FntSetFont (fld->fontID);

	fld->attr.dirty = false;
	

	// Unlock the handle that contian the existing text string.
	if (fld->textHandle)
		MemHandleUnlock (fld->textHandle);

	if (textHandle)
		{
		fld->textHandle = textHandle;
		fld->text = (CharPtr) MemHandleLock (textHandle) + offset;
		fld->textBlockSize = size;

		if (size)
			fld->textLen = StrLen (fld->text);
		else
			fld->textLen = 0;

		// Allocate the structure that contains the word wrapping info.
		AllocateLines (fld);
		
		// Preform the word wrapping calculations, but don't redraw the field
		FormatAndDrawFromPos (fld, 0, false);
		}

	else
		{
		fld->text = NULL;
		fld->textHandle = 0;
		fld->textLen = 0;
		fld->textBlockSize = 0;	
		if (fld->lines)
			{
			MemPtrFree (fld->lines);
			fld->lines = NULL;
			}	
		}


	// When the text value of a field is set, the insertion point is 
	// positioned after the last character.  If that character position is
	// visible, will set the position of the "blink" insertion point,
	// otherwise the position of the insertion point is save in the 
	// selFirstPos member of the field structure.
	pos = fld->textLen;
	fld->selFirstPos = pos;
	fld->selLastPos = pos;
	if (PositionVisible (fld, pos))
		{
		fld->attr.insPtVisible = true;
		SetInsPtFromStringPos (fld, pos);
		}
	else
		{
		fld->attr.insPtVisible = false;
		fld->insPtXPos = 0;
		fld->insPtYPos = 0;
		}
	
	if (fld->attr.hasFocus)
		UndoReset();
	
	FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION:    FldGetTextHandle
 *
 * DESCRIPTION: Return a handle to the block that contains the text 
 *              string of a field.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *
 * RETURNED:    handle of the text string of a field, 0 is a 
 *              possible value.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/8/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Handle FldGetTextHandle (const FieldPtr fld)
{
	return (fld->textHandle);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetTextHandle
 *
 * DESCRIPTION: Set the handle of the block that contains the text 
 *              string of a field.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *              textHandle  handle of the text string of a field, 0 is a 
 *              				 possible value.
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/13/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetTextHandle (const FieldPtr fld, const Handle textHandle)
{
	Word blockSize;
	
	if (textHandle)
		blockSize = MemHandleSize (textHandle);
	else
		blockSize = 0;

	FldSetText (fld, textHandle, 0, blockSize);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetTextPtr
 *
 * DESCRIPTION: Return a pointer to the text string of a field.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *
 * RETURNED:    pointer to the text string of a field, NULL is a 
 *              possible value.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/ 9/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
CharPtr FldGetTextPtr (const FieldPtr fld)
{
	return (fld->text);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetTextPtr
 *
 * DESCRIPTION: Set the field to point to a text string.  Since the field
 *              cannot resize a pointer, only handles can be resize, the
 *              field must be not editable.
 *
 *	NOTE:
 *					If setting a multi-line field, the call should be followed
 *					by a call to FldRecalculateField().
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *              textPtr  pointer to a null-terminated string.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/13/95	Initial Revision
 *			vmk	10/31/96	Took out error check for !fld->attr.singleLine
 *								in agreement with Art.
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetTextPtr (const FieldPtr fld, const CharPtr textP)
{
	ErrNonFatalDisplayIf(fld->attr.editable, "Invalid field attribute");

	fld->text = textP;
	fld->textLen = StrLen (textP);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetTextLength
 *
 * DESCRIPTION: Returns the length of the text string of a field.
 *
 * PARAMETERS:  fld -  pointer to a FieldType structure.
 *
 * RETURNED:    length to a field's text string
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/30/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetTextLength (const FieldPtr fld)
{
	return (fld->textLen);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetFont
 *
 * DESCRIPTION: This routine returns the id of the font used to draw the 
 *              text of a field.
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *              fontId   id of new font
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/23/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
FontID FldGetFont (const FieldPtr fld)
{
	return (fld->fontID);
	
}

/***********************************************************************
 *
 * FUNCTION:    FldSetFont
 *
 * DESCRIPTION: This routine set the font of a the field, updates
 *              the word wrapping infomation and draws the field if the 
 *              field is visible.
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *              fontId   id of new font
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/23/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetFont (const FieldPtr fld, const FontID fontID)
{
	Word pos;
	Word numLines;
	Word insPtPos;
	FontID curFont;
	Boolean insPtOn;

	if (fld->fontID == fontID)
		return;

	curFont = FntSetFont (fld->fontID );
	if ((insPtOn = InsPtInField (fld)) == true)
		InsPtEnable (false);

	insPtPos = GetStringPosOfInsPtPos (fld);		

	fld->fontID = fontID;
	FntSetFont (fontID);
	
	if (fld->attr.visible)
		{
		WinEraseRectangle (&fld->rect, 0);
		}
		

	// Get the position of the first visible character.
	if (fld->text)
		pos = StartOfLine (fld, fld->lines->start);
	else
		pos = 0;
	

	// Reallocate the structure that holds the word wrapping info because
	// the number of visible lines may have changed.
	if (fld->lines)
		{
		MemPtrFree (fld->lines);
		fld->lines = 0;
		AllocateLines (fld);
		}


	// Preform the word wrapping calculations
	FormatAndDrawFromPos (fld, pos, false);
		

	// Remove any blank lines from the bottom of the display.
	if (fld->textLen)
		{
		numLines = GetVisibleLines (fld);
		while (fld->lines->start)
			{
			if (fld->lines[numLines-1].length)
				break;
				
			if (fld->text[fld->textLen-1] == linefeedChr)
				{
				if (numLines < 2) 
					break;
				if (fld->lines[numLines-2].length)
					break;
				}
			ScrollDisplayDown (fld);
			}
		}


	// Redraw the field if it's already visible.
	if (fld->attr.visible)
		DrawLines (fld, true);	


	// Highlight the current selection.
	if ( fld->attr.visible && IsSelection (fld))
		{
		InvertSelection (fld);
		}	


	// If the field has the focus then change the height of the insertion
	// point.
	if (fld->attr.hasFocus)
		InsPtSetHeight (FntLineHeight());


	// If the insertion point was on and its position is still visible, 
	// turn it back on.  If the insertion point was not on and its 
	// position was become  visible, turn it on. 
	UpdateInsPt (fld, insPtOn, insPtPos);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetUsable
 *
 * DESCRIPTION: This routine set a field usable or not usable.  
 *              Non-usable will not display or accept input.
 *
 * PARAMETERS:  fld      pointer to a FieldType structure.
 *              usable   true to set usable, false to set not usable
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/23/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetUsable (const FieldPtr fld, const Boolean usable)
{
	fld->attr.usable = usable;
}


/***********************************************************************
 *
 * FUNCTION:    FldFreeMemory
 *
 * DESCRIPTION: This routine releases the memory blocks that was allocated
 *              th hold the text of a field, and the word wrapping 
 *              information.
 *
 * PARAMETERS:  fld         pointer to a FieldType structure.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/12/94	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldFreeMemory (const FieldPtr fld)
{
	if (fld->textHandle)
		{
		ErrFatalDisplayIf (MemHandleDataStorage (fld->textHandle),
			"Deleting dm handle");
		
		MemHandleFree (fld->textHandle);
		fld->text = NULL;
		fld->textHandle = 0;
		}

	if (fld->lines)
		{
		MemPtrFree (fld->lines);
		fld->lines = NULL;
		}
		
	fld->insPtXPos = 0;
	fld->insPtYPos = 0;
	fld->textLen = 0;
	fld->textBlockSize = 0;
}


/***********************************************************************
 *
 * FUNCTION:    FldGetInsPtPosition
 *
 * DESCRIPTION: Return the string position of the insertion point
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	character position of insertion point
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetInsPtPosition (const FieldPtr fld)
{
	return (GetStringPosOfInsPtPos (fld));
}


/***********************************************************************
 *
 * FUNCTION:    FldSetInsPtPosition
 *
 * DESCRIPTION: Given a string position this routine sets the 
 *              location of the insertion point.
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	character position of insertion point
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetInsPtPosition (const FieldPtr fld, const Word pos)
{
	FontID curFont;
	Boolean insPtOn;

	curFont = FntSetFont (fld->fontID);

	if ((insPtOn = InsPtInField (fld)) == true)
		InsPtEnable (false);

	SetInsPtFromStringPos (fld, pos);
	
	if (fld->attr.hasFocus)
		SetBlinkingInsPtLocation (fld);

	if (insPtOn)
	  	InsPtEnable (true);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetInsertionPoint
 *
 * DESCRIPTION: Given a string position this routine sets the 
 *              location of the insertion point.  This routine differs 
 *              from FldSetIntPtPosition in that it does not make the 
 *              character position visible.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              pos  character position in the text of the field
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/19/96	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetInsertionPoint (const FieldPtr fld, const Word pos)
{
	FontID curFont;
	Boolean insPtOn;

	curFont = FntSetFont (fld->fontID);

	if ((insPtOn = InsPtInField (fld)) == true)
		InsPtEnable (false);

	fld->selFirstPos = pos;
	fld->selLastPos = pos;

	if (PositionVisible (fld, pos))
		{
		fld->attr.insPtVisible = true;

		SetInsPtFromStringPos (fld, pos);
		
		if (fld->attr.hasFocus)
			SetBlinkingInsPtLocation (fld);

		if (insPtOn)
		  	InsPtEnable (true);
		}

	else
		{
		fld->attr.insPtVisible = false;
		fld->insPtXPos = 0;
		fld->insPtYPos = 0;
		}

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetScrollPosition
 *
 * DESCRIPTION: Return the string position of the first character in the 
 *              first line of a field.
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	character position of first visible character
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetScrollPosition (const FieldPtr fld)
{
	if ((fld->attr.singleLine) || (!fld->lines))
		return (0);

	return (fld->lines[0].start);
}

/***********************************************************************
 *
 * FUNCTION:    FldSetScrollPosition
 *
 * DESCRIPTION: Return the string position of the first character in the 
 *              first line of a field.
 *
 * PARAMETERS:	fld  pointer to a FieldType structure.
 *
 * RETURNED:	character position of first visible character
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/21/95	Initial Revision
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetScrollPosition (const FieldPtr fld, Word pos)
{
	Word			numLines;
	Word			insPtPos;
	FontID		curFont;
	Boolean		insPtOn;
	LineInfoPtr	line;

	if ((fld->attr.singleLine) || (!fld->lines))
		return;

	curFont = FntSetFont (fld->fontID);

	if ((insPtOn = InsPtInField (fld)) == true)
		{
		InsPtEnable (false);
		insPtPos = GetStringPosOfInsPtPos (fld);
		}

	// Word wrap the lines and if we're setting the scroll position 
	// to the top of the field, draw the field.
	pos = min (pos, fld->textLen);
	FormatAndDrawFromPos (fld, pos, ((pos == 0) && (fld->attr.visible)));

	// Make sure we're showing a full screen of text.
	numLines = GetVisibleLines (fld);
	if ((pos > 0) && (numLines > 1))
		{
		while (fld->lines->start)
			{	
			// If the last line is not empty, we're done.
			if (fld->lines[numLines-1].length)
				break;

			// If the second to the last line is not empty and the line
			// end with a linefeedChr, we're done.
			if ( (fld->lines[numLines-2].length) &&
				  (fld->text[fld->textLen-1] == linefeedChr) )
				break;
							
			// Move the display line information donw one line.
			MemMove (&fld->lines[1], fld->lines, 
				sizeof(LineInfoType) * (numLines-1));
	
			// Format the line which scrolled into view.
			line = fld->lines;
			line->start = StartOfPreviousLine (fld, line->start);
			line->length = FormatLine (fld, line->start);
			}
		}

	if (fld->attr.visible)
		{
		if (pos > 0)
			DrawLines (fld, true);
	
		if (IsSelection (fld))
			UpdateHighlight (fld, fld->selFirstPos, fld->selFirstPos);
		}

	// If the insertion point was on and its position is still visible, 
	// turn it back on.  If the insertion point was not on and its 
	// position was become  visible, turn it on. 
	UpdateInsPt (fld, insPtOn, insPtPos);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    StartOfPreviousLine
 *
 * DESCRIPTION: This routine scrolls a field up by the number of lines 
 *              specified.
 *
 * PARAMETERS:	fld           pointer to a FieldType structure.
 *             linesToScroll number of lines to scroll.
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/96	Initial Revision
 *
 ***********************************************************************/
static void ScrollUpNLines (FieldPtr fld, Word linesToScroll)
{
	Word start;
	Word startOfLine;
	Word endOfPrevLine;
	Word lineStart;
	Word lineCount = 0;
  

	startOfLine = min (fld->lines->start, fld->textLen);
	if (startOfLine <= 0) return;

   endOfPrevLine = startOfLine - 1;
	if (endOfPrevLine && fld->text[endOfPrevLine] == linefeedChr)
		endOfPrevLine--;

	// Find the first line that begins after after a linefeed and is at 
	// or before the line we wish to scroll to.
	do 
		{
		// Search backward for a linefeedChr.  If we find one, our staring
		// postion is the character after the linefeedChr, otherwise out 
		// starting position is the start of the field's text.
		if (FindReverseByte (fld->text, linefeedChr, endOfPrevLine, &start))
	      start++;					// skip over the linefeedChr
	    else
			start = 0;				// start of text string

		// Count the number of lines we move back through.
		lineStart = start;
		while (lineStart < startOfLine)
			{
     		lineCount++;
      	lineStart += FormatLine (fld, lineStart);
			}

		if (start == 0) break;

		startOfLine = start;
		if (startOfLine > 1)
	   	endOfPrevLine = startOfLine - 2;		// move before linefeed	
	   else
	   	endOfPrevLine = 0;
		}
	while (lineCount < linesToScroll);


	// If we're moved back to many line, move foreward until we're at the 
	// correct line.
	while (lineCount > linesToScroll)
		{
      start += FormatLine (fld, start);		
		lineCount--;
		}

	fld->lines->start = start;

	FormatAndDrawLines (fld, true);
}


/***********************************************************************
 *
 * FUNCTION:    FldScrollField
 *
 * DESCRIPTION: This routine scrolls a field up or down by the number
 *              of lines specified.
 *
 * PARAMETERS:	fld           pointer to a FieldType structure.
 *             linesToScroll number of lines to scroll.
 *             direction     up or down
 *
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/30/95	Initial Revision
 *			art	5/23/96	Optimized scrolling up
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldScrollField (const FieldPtr fld, Word linesToScroll, 
	const DirectionType direction)
{
	Word			pos;
	Word			topPos;
	Word			insPtPos;
	Word			numLines;
	FontID		curFont;
	Boolean		insPtOn;
	LineInfoPtr	line;

	if ((fld->attr.singleLine) || (!fld->text)) return;

	curFont = FntSetFont (fld->fontID);

	if ((insPtOn = InsPtInField (fld)) == true)
		InsPtEnable (false);

//	if (fld->attr.insPtVisible)
		insPtPos = GetStringPosOfInsPtPos (fld);		
		
	if (linesToScroll == 1)
		{
		if (direction == up)
			{
			ScrollDisplayDown (fld);
			if (IsSelection (fld))
				InvertSelectionInLine (fld, 0);
			}
		else if (direction == down)
			{
			ScrollDisplayUp (fld);
			if (IsSelection (fld))
				InvertSelectionInLine (fld, GetVisibleLines (fld) - 1);
			}
		}

	// Scroll the field by more then one line.
	else
		{
		topPos = fld->lines->start;
		numLines = GetVisibleLines (fld);

		if (direction == up)
			{
			ScrollUpNLines (fld, linesToScroll);
			}

		else if (direction == down)
			{
			while (linesToScroll--)
				{
				// If the end of the text is visible don't scroll anymore.
				line = &fld->lines[numLines-1];
				pos = line->start + line->length;
				if ( (pos < fld->textLen) || 
					  (line->length && fld->text[pos-1] == linefeedChr) )
					{
					// Move the display line information up one line.
					MemMove (fld->lines, &fld->lines[1], 
						sizeof(LineInfoType) * (numLines-1));
		
					// Format the line which scrolled into view.
					line->start = line->start + line->length;
					line->length = FormatLine (fld, line->start);
					}
				}

			// Redraw the field if it was scrolled.
			if (topPos != fld->lines->start)
				DrawLines (fld, true);
			}

		if ( (topPos != fld->lines->start) && (IsSelection (fld)))
			UpdateHighlight (fld, fld->selFirstPos, fld->selFirstPos);
		}

	// If the insertion point was on and its position is still visible, 
	// turn it back on.  If the insertion point was not on and its 
	// position was become  visible, turn it on. 
	UpdateInsPt (fld, insPtOn, insPtPos);

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FldScrollable
 *
 * DESCRIPTION: This routine returns true if the field is scrollable
 *              in the direction specified.
 *
 * PARAMETERS:	fld           pointer to a FieldType structure.
 *             direction     up or down
 *
 * RETURNED:	true if the field is scrollable
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/30/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean FldScrollable (const FieldPtr fld, const DirectionType direction)
{
	Word pos;
	Word numLines;
	FontID curFont;
	LineInfoPtr line;

	if (fld->attr.singleLine)
		return (false);
	
	if (! fld->lines)
		return (false);

	if (direction == up)
		return (fld->lines->start > 0);

	else if (direction == down)
		{
		curFont = FntSetFont (fld->fontID);
		numLines = GetVisibleLines (fld);
		FntSetFont (curFont);
		line = &fld->lines[numLines-1];
		pos = line->start + line->length;
		if (pos < fld->textLen)
			return (true);
			 
		return (line->length && (fld->text[pos-1] == linefeedChr));
		}

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetScrollValues
 *
 * DESCRIPTION: This routine returns the values necessary to update a 
 *              scroll bar.
 *
 * PARAMETERS:  fld - pointer to a FieldType structure.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/29/96	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldGetScrollValues (const FieldPtr fld, const WordPtr scrollPosP, 
	const WordPtr textHeightP, const WordPtr fieldHeightP)
{
	Word firstVisible;
	Word maxWidth;
	CharPtr chars;
	FontID curFont;


	ErrFatalDisplayIf (fld->attr.singleLine, "Not scrollable");


	curFont = FntSetFont (fld->fontID);
	
	*fieldHeightP = GetVisibleLines (fld);

	if (! fld->text)
		{
		*scrollPosP = 0;
		*textHeightP = 0;
		}

	else
		{
		chars = fld->text;
		firstVisible = fld->lines[0].start;
		maxWidth = fld->rect.extent.x;

		FntGetScrollValues (chars, maxWidth, firstVisible, textHeightP, scrollPosP);
		}

	FntSetFont (curFont);	
}


/***********************************************************************
 *
 * FUNCTION:    FldGetVisibleLines
 *
 * DESCRIPTION: This routine returns the number of lines that can be 
 *              display within the visible bounds of the field. 
 *
 * PARAMETERS:	fld           pointer to a FieldType structure.
 *             direction     up or down
 *
 * RETURNED:	number if lines
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/30/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetVisibleLines (const FieldPtr fld)
{
	Word numLines;
	FontID curFont;
	
	curFont = FntSetFont (fld->fontID);
	numLines = fld->rect.extent.y / FntLineHeight();
	FntSetFont (curFont);
	return (numLines);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetTextHeight
 *
 * DESCRIPTION: This routine returns the height of lines of text that
 *              the specified field has, empty lines are not counted.
 *
 * PARAMETERS:  fld -  pointer to a FieldType structure.
 *
 * RETURNED:    number of lines of with text.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/10/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetTextHeight (const FieldPtr fld)
{
	Word height = 1;
	Word numLines;
	FontID curFont;

	if ((! fld->attr.singleLine) && (fld->text) && (fld->textLen > 0))
		{
		height = 0;
		numLines = GetVisibleLines (fld);
		while  (height < numLines)
			{
			if (fld->lines[height].length == 0)
				break;
			height++;
			}
		}
	
	curFont = FntSetFont (fld->fontID);
	height *= FntLineHeight ();
	FntSetFont (curFont);
	
	return (height);
}


/***********************************************************************
 *
 * FUNCTION:    FldCalcFieldHeight
 *
 * DESCRIPTION: Given a string, determine the height of a field.
 *
 * PARAMETERS:	 chars       pointer to a null-terminated string
 *              maxWidth    maximum line width in pixels
 *
 * RETURNED:	 number of line needed to draw the string passed
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/26/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldCalcFieldHeight (const CharPtr chars, const Word maxWidth)
{
	Word length = 0;
	Word height = 0;
	
	if (!chars) return 1;

	do {
		length += FntWordWrap (&chars[length], maxWidth);
		height++;
		}
	while (chars[length]);

	// If the text end with a linefeed add one to the height.
	if (length && chars[length-1] == linefeedChr) 
		height++;

	return (height);
}

/***********************************************************************
 *
 * FUNCTION:    FldWordWrap
 *
 * DESCRIPTION: Given a string and a width, return the number of 
 *              character that can be displayed using the current 
 *              font.
 *
 * PARAMETERS:	 chars       pointer to a null-terminated string
 *              maxWidth    maximum line width in pixels
 *
 * RETURNED:	 number of characters.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/7/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldWordWrap  (const CharPtr chars, const Word maxWidth)
{
	return (WordWrap (chars, maxWidth));
}

/***********************************************************************
 *
 * FUNCTION:    FldCompactText
 *
 * DESCRIPTION: Compact the memory block that contain the text of the 
 *              field to release any unused space.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/8/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldCompactText (const FieldPtr fld)
{
	Err	   error;
//	Word		len;
	Word		offset;
	Word		blockSize;
	Word		freeSpace;
//	CharPtr	src;
//	CharPtr	dst;

	if (! fld->textHandle) return;
		
	freeSpace = fld->textBlockSize - fld->textLen - 1;
	if (!freeSpace) return;

	// The field's text string does not necessary start at the 
	// begining of the memory block or end at the end of the 
	// memory block.  In other words the text string may not be 
	// the only thing in the block.
	//
	// If there is something stored in the block, after the string 
	// we're editting, move it such that the free space is removed.
	blockSize = MemHandleSize(fld->textHandle);
	offset = fld->text - (CharPtr) MemDeref(fld->textHandle);

//	src = fld->text + fld->textBlockSize;
//	dst = src - freeSpace;
//	len = blockSize - (fld->textBlockSize + offset);
//	MemMove (dst, src, len);

	blockSize -= freeSpace;
	MemHandleUnlock (fld->textHandle);
	error = MemHandleResize (fld->textHandle, blockSize);
	ErrFatalDisplayIf( error, "Memory reallocation error");
		
	fld->text = (CharPtr) MemHandleLock(fld->textHandle) + offset;
	fld->textBlockSize -= freeSpace;
}


/***********************************************************************
 *
 * FUNCTION:    FldDirty
 *
 * DESCRIPTION: This routine returns true if the field has been 
 *              modified by the user since the text value was 
 *              set (FldSetText).
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 true if the field is user modified.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/24/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean FldDirty (const FieldPtr fld)
{
	return (fld->attr.dirty);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetDirty
 *
 * DESCRIPTION: This routine sets whether the field has been 
 *              modified.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *					 dirty	 true if the text is modified
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/28/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetDirty (const FieldPtr fld, const Boolean dirty)
{
	fld->attr.dirty = dirty;
}


/***********************************************************************
 *
 * FUNCTION:    FldGetMaxChars
 *
 * DESCRIPTION: This routine returns the maximum number of character 
 *              that the field will accept.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 maximum number of characters that may be input.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/13/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetMaxChars (const FieldPtr fld)
{
	return (fld->maxChars);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetMaxChars
 *
 * DESCRIPTION: This routine set the maximum number of character 
 *              that the field will accept.
 *
 * PARAMETERS:	 fld       pointer to a FieldType structure.
 *              maxChars  maximum number of characters that may be input.
 *
 * RETURNED:	 nothing 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/13/95		Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetMaxChars (const FieldPtr fld, const Word maxChars)
{
	fld->maxChars = maxChars;
}


/***********************************************************************
 *
 * FUNCTION:    FldGetTextAllocatedSize
 *
 * DESCRIPTION: This routine returns the number of character 
 *              allocated to hold the field's text string,  this 
 *              value should not be confused the the lenght the of text 
 *              string.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 number of characters allocated for the field's text.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/29/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetTextAllocatedSize (const FieldPtr fld)
{
	return (fld->textBlockSize);
}


/***********************************************************************
 *
 * FUNCTION:    FldSetTextAllocatedSize
 *
 * DESCRIPTION: This routine set the number of character 
 *              allocated to hold the field's text string,  this 
 *              value shoulg not be confused the the lenght the of text 
 *              string.
 *
 * PARAMETERS:	 fld           - pointer to a FieldType structure.
 *              allocatedSize - number of characters allocated for 
 *                              the field's text.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/29/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetTextAllocatedSize (const FieldPtr fld, const Word allocatedSize)
{
	fld->textBlockSize = allocatedSize;
}


/***********************************************************************
 *
 * FUNCTION:    FldGetAttributes
 *
 * DESCRIPTION: This routine returns the attributes of a field.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              attrP	 pointer to the attributes
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/29/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldGetAttributes (const FieldPtr fld, const FieldAttrPtr attrP)
{
	*attrP = fld->attr;
}


/***********************************************************************
 *
 * FUNCTION:    FldSetAttributes
 *
 * DESCRIPTION: This routine sets the attributes of a field.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *              attrP	 pointer to the attributes
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/29/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSetAttributes (const FieldPtr fld, const FieldAttrPtr attrP)
{
	fld->attr = *attrP;
}


/***********************************************************************
 *
 * FUNCTION:    FldSendChangeNotification
 *
 * DESCRIPTION: This routine sends a fldChangedEvent.
 *
 * PARAMETERS:	 fld      pointer to a FieldType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/30/95	Initial Revision
 *			ron   8/21/96	Modified to use EvtAddUniqueEventToQueue so that
 *									event queue doesn't overflow when multiple FldInsert
 *									or FldDelete calls are made in a row.
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSendChangeNotification (const FieldPtr fld)
{
	EventType event;
	
	MemSet (&event, sizeof (event), 0);
	event.eType = fldChangedEvent;
	event.data.fldChanged.fieldID = fld->id;
	event.data.fldChanged.pField = fld;
	EvtAddUniqueEventToQueue (&event, (DWord)fld, false);
}


/***********************************************************************
 *
 * FUNCTION:    FldSendHeightChangeNotification
 *
 * DESCRIPTION: This routine sends a fldChangedHeightEvent.
 *
 * PARAMETERS:	 fld  pointer to a FieldType structure.
 *              pos  character position of the insertion point
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/12/95	Initial Revision
 *			ron   8/21/96	Modified to use EvtAddUniqueEventToQueue so that
 *									event queue doesn't overflow when multiple FldInsert
 *									or FldDelete calls are made in a row.
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void FldSendHeightChangeNotification (const FieldPtr fld, const Word pos, 
	const Short numLines)
{
	FontID curFont;
	EventType event;
	
	curFont = FntSetFont (fld->fontID);

	event.eType = fldHeightChangedEvent;
	event.data.fldHeightChanged.fieldID = fld->id;
	event.data.fldHeightChanged.pField = fld;
	event.data.fldHeightChanged.currentPos = pos;
	event.data.fldHeightChanged.newHeight = 
		min (GetMaxLines (fld), numLines) * FntLineHeight ();

	EvtAddUniqueEventToQueue (&event, (DWord)fld, false);

	FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION:    FldMakeFullyVisible
 *
 * DESCRIPTION: This routine will cause a dynamicly resizable field to 
 *              expand its height in order to make its text fully
 *              visible.
 *
 * PARAMETERS:	 fld - pointer to a field object.
 *
 * RETURNED:	 true it the field was not fully visible.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/20/95	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean FldMakeFullyVisible (const FieldPtr fld)
{
	Word pos;
	Word numLines;
	FontID curFont;

	curFont = FntSetFont (fld->fontID);
	
	// If the field is dynanicly resizeable and some of the text is not 
	// visible, then send a height change notification.
	if (fld->attr.dynamicSize && 
	 	(! PositionVisible (fld, fld->textLen)) &&
	 	(GetVisibleLines (fld) < GetMaxLines (fld)))
		{
		pos = GetStringPosOfInsPtPos (fld);
		numLines = FldCalcFieldHeight (fld->text, fld->rect.extent.x);
		FldSendHeightChangeNotification (fld, pos, numLines);

		FntSetFont (curFont);
		return (true);
		}

	FntSetFont (curFont);
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    FldGetNumberOfBlankLines
 *
 * DESCRIPTION: This routine returns the number of bland line that
 *              are display at the end of field.  This routine is 
 *              useful for updating a scroll bar after character have
 *              been remove from the end of a field.
 *
 * PARAMETERS:	 fld         pointer to a FieldType structure.
 *
 * RETURNED:	 number of blank lines visible.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/2/96	Initial Revision
 *			trev	08/08/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word FldGetNumberOfBlankLines (const FieldPtr fld)
{
	Word			numLines;
	FontID curFont;
	Word			count = 0;

	curFont = FntSetFont (fld->fontID);
	numLines = GetVisibleLines (fld);
	FntSetFont (curFont);

	if (! fld->lines) return (numLines);
	
	while (numLines--)
		{
		if (fld->lines[numLines].length != 0)
			{
			if (count && fld->text[fld->textLen-1] == linefeedChr)
				count--;
			break;
			}
		count++;
		}

	return (count);
}


/***********************************************************************
 *
 * FUNCTION:    FldNewField
 *
 * DESCRIPTION: Create a field. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 id - id of the new field
 *					 x - x of the new field
 *					 y - y of the new field
 *					 width - width of the new field
 *					 height - height of the new field
 *					 font - font of the new field
 *					 maxChars - maxChars of the new field
 *					 underlined - true to display an underline.  Normally set for editing.
 *					 singleLine - true if the field is a single line tall
 *					 justification - the justification used for the text
 *					 autoShift - true to enable automatic shifting for Graffiti input
 *					 hasScrollBar - true to display a scrollbar
 *					 numeric - true to restrict input to numbers
 *
 * RETURNED:    0 if error else a pointer to the field
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
FieldPtr FldNewField (VoidPtr *formPP, const Word id, 
	const Word x, const Word y, const Word width, const Word height, 
	const FontID font, DWord maxChars, Boolean editable, Boolean underlined, 
	Boolean singleLine, Boolean dynamicSize, JustificationType justification, 
	Boolean autoShift, Boolean hasScrollBar, Boolean numeric)
{
	FieldPtr fieldP;
	Err error;
	
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)fieldP, frmFieldObj, 
					sizeof(FieldType));
	if (error)
		return 0;
	
	fieldP->id = id;
	fieldP->rect.topLeft.x = x;
	fieldP->rect.topLeft.y = y;
	fieldP->rect.extent.x = width;
	fieldP->rect.extent.y = height;
	
	fieldP->attr.usable = true;
	fieldP->attr.editable = editable;
	if (underlined)
		fieldP->attr.underlined = grayUnderline;
	fieldP->attr.singleLine = singleLine;
	fieldP->attr.dynamicSize = dynamicSize;
	fieldP->attr.autoShift = autoShift;
	fieldP->attr.hasScrollBar = hasScrollBar;
	fieldP->attr.numeric = numeric;
	fieldP->attr.justification = justification;
	fieldP->attr.insPtVisible = true;	
	fieldP->maxChars = maxChars;
	fieldP->fontID = font;
	
	
	return fieldP;
}


/***********************************************************************
 *
 * FUNCTION:    FldHandleEvent
 *
 * DESCRIPTION: 
 *
 * PARAMETERS:	 fld    pointer to a FieldType structure.
 *              event  pointer to an EventType structure.
 *
 * RETURNED:	 true if the event was handle by the field.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *			art	3/27/96	Add autoshifting
 *			trev	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean FldHandleEvent (const FieldPtr fld, const EventPtr event)
{
	unsigned char ch;
	Word anchorPos;
	Word scrollPos;
	Word charsToDelete;
	Short x, y;
	WordPtr charAttr;
	RectangleType r;
	Boolean handled;
	Boolean penDown;
	FontID curFont;
	EventType newEvent;

#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	ECValidateField (fld);
#endif

	if (! fld->attr.usable)
		return (false);

	if (event->eType == keyDownEvent)
		{
		if (! fld->attr.editable)
			return (false);
			
		if (event->data.keyDown.modifiers & commandKeyMask)
			return (false);

		handled = true;
		InsPtEnable (false);
		curFont = FntSetFont (fld->fontID);
		ch = event->data.keyDown.chr;

		charAttr = GetCharAttr();

		if (IsAscii (ch) && IsPrint (charAttr, ch))
			{
			if (fld->attr.numeric)	
				{
				if (IsDigit (charAttr, ch)  || 
						(ch == UIDecimalSeparator && 
							((!fld->text) ||
							(fld->text && StrChr(fld->text, UIDecimalSeparator) == NULL))))
					InsertChar (fld, ch);
				else
					SndPlaySystemSound (sndError);
				}
			else
				{
				InsertChar (fld, ch);
				if (ch == spaceChr)
					AutoShift (fld);
				}
			}

		else if ((ch == linefeedChr) || (ch == tabChr))
			{
			if (! (fld->attr.singleLine || fld->attr.justification == rightAlign))
				InsertChar (fld, ch);
			if (ch == linefeedChr)
				AutoShift (fld);
			}
		else if (ch == backspaceChr)
			{
			BackspaceChar (fld);
			if (EvtKeyQueueEmpty ())
				AutoShift (fld);
			}
		else if (ch == upArrowChr)
			InsPtUp (fld);
		else if (ch == downArrowChr)
			InsPtDown (fld);
		else if (ch == leftArrowChr)
			InsPtLeft (fld);
		else if (ch == rightArrowChr)
			InsPtRight (fld);
		else
			handled = false;

		if ((fld->attr.insPtVisible) && (! IsSelection (fld)))
			{
			if ( ! fld->attr.hasFocus)
				FldGrabFocus (fld);
			else
				{
				SetBlinkingInsPtLocation (fld);
				InsPtEnable (true);
				}
			}
		FntSetFont (curFont);
		}

	else if (event->eType == penDownEvent)
		{
		EvtCopyEvent (event, &newEvent);
		newEvent.eType = fldEnterEvent;
		newEvent.data.fldEnter.fieldID = fld->id;
		newEvent.data.fldEnter.pField = fld;
		EvtAddEventToQueue (&newEvent);
		}

	else if (event->eType == fldEnterEvent)
		{
		curFont = FntSetFont (fld->fontID);
		CancelSelection (fld);
		UndoReset ();

		SndPlaySystemSound (sndClick);
		
		GrfFieldChange (false, &charsToDelete);

		x = event->screenX;
		y = event->screenY;
		SetInsPtPosFromPt (fld, x, y);
		
		anchorPos = GetStringPosOfInsPtPos (fld);
		SetSelection (fld, anchorPos, anchorPos);

		if (fld->attr.editable)
			{
			if ( ! fld->attr.hasFocus)
				FldGrabFocus (fld);
			else
				{
				GrfSetState (false, false, false);
				SetBlinkingInsPtLocation (fld);
				InsPtEnable (true);
				}
			}

		// If the field is dynanicly resizeable and some of the text is not 
		// visible, then send a height change notification.  If the field
		// is already fully visible then start drag-selecting.
		if ( ! FldMakeFullyVisible (fld))
			{
			scrollPos = FldGetScrollPosition (fld);
			GetBoundsOfInsPtPos (fld, &r);
			do
				{
				if (y < fld->rect.topLeft.y)  /* above field */
					{
					InsPtEnable (false);
					ScrollSelectionDown (fld, anchorPos);
					}
				else if (y >= fld->rect.topLeft.y + fld->rect.extent.y) // below field
					{
					InsPtEnable (false);
					ScrollSelectionUp (fld, anchorPos);
					}
				else if (! RctPtInRectangle (x, y, &r))
					{
					SetInsPtPosFromPt (fld, x, y);
					GetBoundsOfInsPtPos (fld, &r);
					InsPtEnable (false);
					SetSelection (fld, GetStringPosOfInsPtPos (fld), anchorPos);
					}
				if (! IsSelection (fld) && fld->attr.editable)
					InsPtEnable (true);
				PenGetPoint (&x, &y, &penDown);
				} while (penDown);
	
			if (scrollPos != FldGetScrollPosition (fld))
				FldSendChangeNotification (fld);
			}
		
		FntSetFont (curFont);
		handled = true;
		}


	else if (event->eType == fldHeightChangedEvent)
		{
		// Set the insertion point.
//		FldSetInsPtPosition (fld, event->data.fldHeightChanged.currentPos);

		// Turn the insertion point back on.
		if (fld->attr.hasFocus)
			InsPtEnable (true);
		}


	else
		handled = false;
		
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	ECValidateField (fld);
#endif

	return (handled);
}


