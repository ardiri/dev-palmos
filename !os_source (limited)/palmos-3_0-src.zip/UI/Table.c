/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     table.h
 * AUTHOR:	 Art Lamb: February 7, 1995
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contains the table object routines.
 *
 **********************************************************************/
#include <Pilot.h>

// #include <Quickdraw.h>

/***********************************************************************
 *
 *	Internal constants and functions
 *
 ***********************************************************************/
#define tableSelectIndictorHeight	11
#define tableFont							boldFont


/***********************************************************************
 *
 * FUNCTION:    ECValidateTable
 *
 * DESCRIPTION: This routine performs various edit checks on a table 
 *              object.
 *
 * PARAMETERS:	 table  pointer to a TableType structure.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/31/96	Initial Revision
 *
 ***********************************************************************/
static void ECValidateTable (TablePtr table)
{
	ErrFatalDisplayIf (table->currentRow >= table->numRows, 
		"Invalid table row");

	ErrFatalDisplayIf (table->currentColumn >= table->numColumns, 
		"Invalid table column");
}


/***********************************************************************
 *
 * FUNCTION:    InitCheckboxItem
 *
 * DESCRIPTION: This routine initializes a checkbox table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              clt    - pointer to a control structure
 *              x      - left bound to the item
 *              y      - top bound of the item
 *              on     - true if checkbox is checked
 *              
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/26/95	Initial Revision
 *
 ***********************************************************************/
static void InitCheckboxItem (ControlPtr ctl,
	short x, short y, short width, Boolean on)
{
	FontID curFont;

	MemSet (ctl, sizeof(ControlType), 0);
	ctl->attr.usable = true;
	ctl->attr.enabled = true;
	ctl->style = checkboxCtl;
	ctl->bounds.topLeft.x = x;
	ctl->bounds.topLeft.y = y;
	ctl->bounds.extent.x = width;

	curFont = FntSetFont (tableFont);
	ctl->bounds.extent.y = FntLineHeight ();
	FntSetFont (curFont);
	
	CtlSetValue (ctl, on);
}


/***********************************************************************
 *
 * FUNCTION:    InitTextItem
 *
 * DESCRIPTION: This routine initializes a editable text table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *       art	4/12/96	Set current field editable before calling load
 *                      data callback routine.
 *			art	6/18/96	Add fld parameter to load data callback routine.
 *			art	8/26/97	Set font id form value in a table structure.
 *
 ***********************************************************************/
static Err InitTextItem (TablePtr table, FieldPtr fld, Word row, 
	Word column, short x, short y, Boolean editable, Boolean visible)
{
	Err err;
	VoidHand textH;
	Word textOffset;
	Word textAllocSize;
	TableItemPtr item;
	
	item = item = &table->items[row*table->numColumns+column];

	MemSet (fld, sizeof(FieldType), 0);
	
	fld->attr.usable = true;
	fld->attr.visible = visible;
	fld->attr.editable = true;	
	fld->attr.underlined = true;
	fld->attr.insPtVisible = true;
	fld->attr.dynamicSize = ( ! table->rowAttrs[row].staticHeight);
	fld->attr.hasScrollBar = table->attr.hasScrollBar;
	

	fld->rect.topLeft.x = x;
	fld->rect.topLeft.y = y;
	fld->rect.extent.x = table->columnAttrs[column].width;
	fld->rect.extent.y = min (table->rowAttrs[row].height,
		table->bounds.topLeft.y + table->bounds.extent.y - y);

	fld->maxChars = tableMaxTextItemSize;

	fld->fontID = item->fontID;

	// If the item has a note, leave space for the note indicator.
	if (item->itemType == textWithNoteTableItem)
		fld->rect.extent.x -= tableNoteIndicatorWidth;
		
	// If the application has reserved space to the rigth of the text item,
	// leave space for it.
	else if (item->itemType == narrowTextTableItem)
		fld->rect.extent.x -= item->intValue;


	if (editable)
		table->attr.editing = true;

	
	// Call the application to get the text to display in the field.
	if (! table->columnAttrs[column].loadDataCallback)
		return (0);
		
	err = table->columnAttrs[column].loadDataCallback (table, row, column,
		editable, &textH, &textOffset, &textAllocSize, fld);

	if (! FldGetTextHandle (fld))
		FldSetText (fld, textH, textOffset, textAllocSize);
	
	return (err);
}



/***********************************************************************
 *
 * FUNCTION:    DrawLableItem
 *
 * DESCRIPTION: This routine draw a label item in table object.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void DrawLabelItem (TablePtr table, TableItemPtr item, Word column, 
	short x, short y)
{
	Word len;
	short width;
	char ch = colonChr;
	FontID curFont;
	
	curFont = FntSetFont (stdFont);
	len = StrLen (item->ptr);
	width = FntCharsWidth (item->ptr, len);
	x += table->columnAttrs[column].width - width - FntCharWidth (colonChr);
	WinDrawChars (item->ptr, len, x, y);
	x += width;
	WinDrawChars (&ch, 1, x, y);
	FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION:    DrawNumericItem
 *
 * DESCRIPTION: This routine draw a numeric table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              item   - pointer to the item
 *              column - 
 *              
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void DrawNumericItem (TablePtr table, TableItemPtr item, Word column, 
	short x, short y)
{
	Word len;
	short width;
	Char str[8];
	
	FntSetFont (boldFont);
	
	StrIToA (str, item->intValue);
	len = StrLen (str);
	
	width = FntCharsWidth (str, len) - 1;
	x += (table->columnAttrs[column].width - width) / 2;
	WinDrawChars (str, len, x, y);
}


/***********************************************************************
 *
 * FUNCTION:    DrawTexttem
 *
 * DESCRIPTION: This routine draw a text item in table object.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void DrawTextItem (TablePtr table, TableItemPtr item, 
	Word row, Word col, short x, short y)
{
	char noteChr;
	short drawX;
	FontID curFont;
	FieldType field;
	
	InitTextItem (table, &field, row, col, x, y, false, false);

	FldDrawField (&field);

	FldSetTextHandle (&field, 0);
		
	FldFreeMemory (&field);
	
	// If the item has a note, draw the note indicator.
	if (item->itemType == textWithNoteTableItem)
		{
		curFont = FntSetFont (symbolFont);
		noteChr = symbolNote;
		drawX = x + table->columnAttrs[col].width - FntCharWidth (noteChr);
		WinDrawChars (&noteChr, 1, drawX, y);
		FntSetFont (curFont);
		}
}


/***********************************************************************
 *
 * FUNCTION:    DrawCheckboxItem
 *
 * DESCRIPTION: This routine draws a checkbox table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              item   - pointer to an item in the table
 *              row    - row the item is in
 *              column - column the item is in
 *              x      - left bound to the item
 *              y      - top bound of the item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/26/95	Initial Revision
 *
 ***********************************************************************/
static void DrawCheckboxItem (TablePtr table, TableItemPtr item, 
	Word column, short x, short y)
{
	ControlType ctl;
		
	InitCheckboxItem (&ctl, x, y, table->columnAttrs[column].width,
				item->intValue);
		
	CtlDrawControl (&ctl);
}


/***********************************************************************
 *
 * FUNCTION:    DrawPopupTriggerItem
 *
 * DESCRIPTION: This routine draws a popup trigger item of table object.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              item   - pointer to an item in the table
 *              row    - row the item is in
 *              column - column the item is in
 *              x      - left bound to the item
 *              y      - top bound of the item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void DrawPopupTriggerItem (TablePtr table, TableItemPtr item, 
	Word column, short x, short y)
{
	ControlType ctl;
	CharPtr text;
	char colonChar;
	FontID curFont;

			
	curFont = FntSetFont (stdFont);
	MemSet (&ctl, sizeof(ControlType), 0);
	ctl.attr.usable = true;
	ctl.attr.enabled = true;
	ctl.style = popupTriggerCtl;
	ctl.bounds.topLeft.x = x;
	ctl.bounds.topLeft.y = y;
	ctl.bounds.extent.x = table->columnAttrs[column].width;
	ctl.bounds.extent.y = FntLineHeight ();
	
	text = LstGetSelectionText ((ListPtr) item->ptr, item->intValue);
	CtlSetLabel (&ctl, text);
	CtlDrawControl (&ctl);
	colonChar = ':';
	WinDrawChars(&colonChar, 1, x + table->columnAttrs[column].width -
		FntCharWidth(':'), y);
	
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    DrawDateItem
 *
 * DESCRIPTION: This routine draws a checkbox table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              item   - pointer to an item in the table
 *              row    - row the item is in
 *              column - column the item is in
 *              x      - left bound to the item
 *              y      - top bound of the item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/26/95	Initial Revision
 *
 ***********************************************************************/
static void DrawDateItem (TablePtr table, TableItemPtr item,
	Word column, short x, short y)
{
	char chr;
	char dayStr [3];
	char monthStr [3];
	Word dayStrLen;
	Word monthStrLen;
	short drawX, drawY;
	FontID curFont;
	DateType date;
	DateTimeType today;
	long todayL, dateL;
	
	// If there is no date draw a dash to indicate such.
	if (item->intValue == -1)
		{
		curFont = FntSetFont (stdFont);
		drawX = x + table->columnAttrs[column].width - 7;
		drawY = y + ((FntLineHeight () + 1) / 2);
		WinDrawLine (drawX, drawY, drawX+5, drawY);		
		FntSetFont (curFont);
		return;
		}
	
	*((IntPtr) (&date)) = item->intValue;

	curFont = FntSetFont (stdFont);
	
	StrIToA (monthStr, date.month);
	StrIToA (dayStr, date.day);
	
	monthStrLen = StrLen (monthStr);
	dayStrLen = StrLen (dayStr);
	
	// Right align the day values.
	drawX = x + table->columnAttrs[column].width - 3 -
		FntCharsWidth (monthStr, monthStrLen) -
		FntCharWidth ('/') - 
		FntCharsWidth (dayStr, dayStrLen);	
	drawY = y;
	
	// Draw the date.
	WinDrawChars (monthStr, monthStrLen, drawX, drawY);
	drawX += FntCharsWidth (monthStr, monthStrLen) ;
	
	chr = '/';
	WinDrawChars (&chr, 1, drawX, drawY);
	drawX += FntCharWidth (chr);

	WinDrawChars (dayStr, dayStrLen, drawX, drawY);	
	
	// If the date is on or before today draw an exclamation mark.
	TimSecondsToDateTime (TimGetSeconds(), &today);

	todayL = ( ((long) today.year) << 16) + 
				( ((long) today.month) << 8) + 
				  ((long) today.day);

	dateL = ( ((long) date.year + firstYear) << 16) + 
			  ( ((long) date.month) << 8) + 
				 ((long) date.day);
	
	if (dateL <= todayL)
		{
		drawX += FntCharsWidth (dayStr, dayStrLen) + 1;
		
		chr = '!';
		FntSetFont (boldFont);
		WinDrawChars (&chr, 1, drawX, drawY);
		}

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    SendTableSelectEvent
 *
 * DESCRIPTION: This routine add a table select event to the event queue.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row selected
 *              column - column selected
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/9/95	Initial Revision
 *			roger	1/13/97	Added playSound
 *			roger	11/12/97	Don't play sound when a fldEnterEvent will be generated
 *
 ***********************************************************************/
static void SendTableSelectEvent (TablePtr table, Word row, Word column,
	Boolean playSound)
{
	EventType event;
	TableItemStyleType itemStyle;
	
	event.eType = tblSelectEvent;
	event.data.tblSelect.tableID = table->id;
	event.data.tblSelect.pTable = table;
	event.data.tblSelect.row = row;
	event.data.tblSelect.column = column;
	EvtAddEventToQueue (&event);
	
	if (playSound)
		{
		itemStyle = table->items[row*table->numColumns + column].itemType;
		
		if (itemStyle != textTableItem &&
			itemStyle != textWithNoteTableItem &&
			itemStyle != narrowTextTableItem)
			{
			SndPlaySystemSound(sndClick);
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    SendTableExitEvent
 *
 * DESCRIPTION: This routine add a table exit event to the event queue.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row selected
 *              column - column selected
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/29/95	Initial Revision
 *
 ***********************************************************************/
static void SendTableExitEvent (TablePtr table, Word row, Word column)
{
	EventType event;
	
	event.eType = tblExitEvent;
	event.data.tblExit.tableID = table->id;
	event.data.tblExit.pTable = table;
	event.data.tblExit.row = row;
	event.data.tblExit.column = column;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    PointInTableItem
 *
 * DESCRIPTION: This routine determine which, if any, item the passed
 *              coordinate is on.
 *
 * PARAMETERS:	 table   - pointer to a table object
 *              x       - coordinate
 *              y       - coordinate
 *              pRow    - row of the item (return value)
 *              pColumn - column of the item (return value)
 *              pRect   - bounds of the item (return value)
 *
 * RETURNED:	 true if the coordinate is on an item.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static Boolean PointInTableItem (TablePtr table, short x, short y,
	WordPtr pRow, WordPtr pCol, RectanglePtr pRect)
{
	Word row, col;
	FontID curFont;
	TableItemPtr item;
	RectangleType r;

	if (! RctPtInRectangle (x, y, &table->bounds)) return (false);

	r.topLeft.x = table->bounds.topLeft.x;
	r.topLeft.y = table->bounds.topLeft.y;
	r.extent.x = table->bounds.extent.x;
		
	for (row = table->topRow; row < table->numRows; row++)
		{
		if (! table->rowAttrs[row].usable)
			continue;
		
		// Is the point within the bounds of the row.
		r.extent.y = table->rowAttrs[row].height;
		if (RctPtInRectangle (x, y, &r))
			{
			if (! table->rowAttrs[row].selectable)
				return (false);
				
			for (col = 0; col < table->numColumns; col++)
				{
				if (! table->columnAttrs[col].usable) 
					continue;
					
				// Is the point within the bounds of the column
				r.extent.x = table->columnAttrs[col].width;
				r.extent.y = table->rowAttrs[row].height;
				if (RctPtInRectangle (x, y, &r))
					{
					// If the item is not a text item check if the point is in
					// the first line of the column.
					item = &table->items[row*table->numColumns+col];
					if ( (item->itemType != textTableItem) &&
						  (item->itemType != textWithNoteTableItem) &&
						  (item->itemType != narrowTextTableItem))
						{
						curFont = FntSetFont (tableFont);
						r.extent.y = FntLineHeight ();
						FntSetFont (curFont);
				
						if (! RctPtInRectangle (x, y, &r))
							return (false);
						}

					RctCopyRectangle (&r, pRect);
					*pRow = row;
					*pCol = col;
					return (true);
					}
					
				// Move to the next column.
				r.topLeft.x += r.extent.x + table->columnAttrs[col].spacing;
				}

			// We were in a useable row, but we were not a any of the columns.
			return (false);
			}

		// Move to next row.
		r.topLeft.y += table->rowAttrs[row].height;
		}

	return (false);
}

/***********************************************************************
 *
 * FUNCTION: 	 SelectItem
 *
 * DESCRIPTION: This routine is called when a pen down event occurs in
 *              a table object that is selectable (selectable items 
 *              highlight when they are pressed).  This routine will track
 *              the pen until it is released.
 *
 * PARAMETERS:	 table - pointer to a table object
 *              r     - pointer to the bounds of an item
 *					
 * RETURNED:	 true if the pen is release within the bounds of the item
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/11/95	Initial Revision
 *
 ***********************************************************************/
static Boolean SelectItem (TablePtr table, EventPtr event, Word row, 
	Word column, RectanglePtr r)
{
	short x, y;
//	FontID curFont;
	Boolean penDown = true;
	Boolean selected = true;
		
	ErrNonFatalDisplayIf (row >= table->numRows, "Invalid table row");
	ErrNonFatalDisplayIf (column >= table->numColumns, "Invalid table column");
	ErrNonFatalDisplayIf (r == NULL, "NULL bounds");
	
//	curFont = FntSetFont (tableFont);
//	r->extent.y = FntLineHeight ();
//	FntSetFont (curFont);

	if (! RctPtInRectangle (event->screenX, event->screenY, r))
		return (false);

	WinInvertRectangle (r, 0);

	do 
		{
		PenGetPoint (&x, &y, &penDown);

		if (RctPtInRectangle (x, y, r))
			{
			if (! selected)
				{
				WinInvertRectangle (r, 0);
				selected = true;
				}
			}

		else if (selected)
			{
			WinInvertRectangle (r, 0);
			selected = false;
			}

		} while (penDown);
		

	if (selected)
		{
		table->attr.selected = true;
		table->currentRow = row;
		table->currentColumn = column;
		
		// Post a tableSelectEvent.
		SendTableSelectEvent (table, row, column, true);
		}
		
	else
		// Post a tableExitEvent.
		SendTableExitEvent (table, row, column);
		

	return (selected);
}


/***********************************************************************
 *
 * FUNCTION:    CustomItemHandleEvent
 *
 * DESCRIPTION: This routine handles events in custom table items.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void CustomItemHandleEvent (TablePtr table, EventPtr pEvent,
	Word row, Word column, RectanglePtr r)
{
	Boolean itemsSelected;
		
	itemsSelected = table->attr.selected;

	SelectItem (table, pEvent, row, column, r);

	// If a new item was not selected, highlight the prior selection.
	if ((! table->attr.selected) && itemsSelected)
		TblSelectItem (table, table->currentRow, table->currentColumn);
}


/***********************************************************************
 *
 * FUNCTION:    PopupTriggerHandleEvent
 *
 * DESCRIPTION: This routine handles event in a popup trigger table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void PopupTriggerHandleEvent (TablePtr table, EventPtr pEvent,
	Word row, Word column, RectanglePtr r)
{
	ControlType ctl;
	EventType event;
	ListPtr lst;
	CharPtr text;
	short newSelection;
	TableItemPtr item;
	Char colonChar;
	FontID currFont;
	
	
	item = &table->items[row*table->numColumns + column];
	
	ErrFatalDisplayIf(item->itemType != popupTriggerTableItem, "Bad table popup item");

	// Create a control object.  Use it now to handle the control selection.
	// We might use it later to draw the control if it changes (list selection).
	MemSet (&ctl, sizeof(ControlType), 0);
	ctl.attr.usable = true;
	ctl.attr.enabled = true;
	ctl.attr.visible = true;
	ctl.style = popupTriggerCtl;
	RctCopyRectangle (r, &ctl.bounds);
	
	// Setting the text is tricky because the text is stored within
	// a list in the item.  
	lst = (ListPtr) item->ptr;
	CtlSetLabel (&ctl, LstGetSelectionText (lst, item->intValue));


	// Now feed the tableSelectEvent into the control.  It will handle
	// the event only if it is within the bounds of the control.
	pEvent->eType = penDownEvent;		// so the control will handle it
	if (CtlHandleEvent(&ctl, pEvent))
		{
		while (true)
			{
			EvtGetEvent (&event, evtWaitForever);

			if (event.eType == ctlEnterEvent)
				CtlHandleEvent(&ctl, &event);

			else if (event.eType == ctlSelectEvent)
				{
				// Display the popup list.
				LstSetPosition (lst, r->topLeft.x, r->topLeft.y);
				LstSetSelection (lst, item->intValue);
				newSelection = LstPopupList (lst);

				// If not selection was made or the currently selected item 
				// was selected again,  don't do anytime else.
				if (newSelection == noListSelection) break;
				if (newSelection == item->intValue) break;

				// Change the label of the table item.
				text = LstGetSelectionText (lst, newSelection);
				CtlEraseControl (&ctl);
				CtlSetLabel (&ctl, text);
				CtlDrawControl (&ctl);
				currFont = FntSetFont(stdFont);
				colonChar = ':';
				WinDrawChars(&colonChar, 1, ctl.bounds.topLeft.x + 
					ctl.bounds.extent.x - FntCharWidth(':'), 
					ctl.bounds.topLeft.y);
				FntSetFont (currFont);


				// Save the items selected in the table item's data.
				item->intValue = newSelection;

				// Post a tableSelectEvent.
				SendTableSelectEvent (table, row, column, false);
				}

			else
				{
				// If we got an event that we didn't expect, put it back in the 
				// queue.
				EvtAddEventToQueue (&event);
				break;
				}
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    CheckboxHandleEvent
 *
 * DESCRIPTION: This routine handles event in a checkbox table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void CheckboxHandleEvent (TablePtr table, EventPtr pEvent,
	Word row, Word column, RectanglePtr r)
{
	ControlType ctl;
	EventType event;
	TableItemPtr item;
	
	item = &table->items[row*table->numColumns + column];
				
	InitCheckboxItem (&ctl, r->topLeft.x, r->topLeft.y, 
		table->columnAttrs[column].width, item->intValue);
	ctl.attr.visible = true;
	
	// Convert the table enter event to a field enter event.
	EvtCopyEvent (pEvent, &event);
	event.eType = ctlEnterEvent;
	event.data.ctlEnter.controlID = ctl.id;
	event.data.ctlEnter.pControl = &ctl;

	while (true)
		{
		if (event.eType == ctlEnterEvent)
			CtlHandleEvent (&ctl, &event);

		else if (event.eType == ctlSelectEvent)
			{
			item->intValue = CtlGetValue (&ctl);
			SendTableSelectEvent (table, row, column, true);
			}

		else if (event.eType == ctlExitEvent)
			{
			// Post a tableExitEvent.
			SendTableExitEvent (table, row, column);
			}
				
		else
			{
			// If we got an event that we didn't expect, put it back in the 
			// queue.
			EvtAddEventToQueue (&event);
			break;
			}
						
		EvtGetEvent (&event, evtWaitForever);
		}
}


/***********************************************************************
 *
 * FUNCTION:    InvertEditIndicator
 *
 * DESCRIPTION: This routine inverts the region to the left of the text 
 *              item, to indicate that the item is selected  
 *
 * PARAMETERS:	 table   - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/16/95	Initial Revision
 *
 ***********************************************************************/
static void InvertEditIndicator (TablePtr table)
{
	Int col;
	RectangleType itemR, indictorR;

	TblGetItemBounds (table, table->currentRow, table->currentColumn, &itemR);

	indictorR.topLeft.y = itemR.topLeft.y;
	indictorR.extent.y = tableSelectIndictorHeight;
	indictorR.topLeft.x = 0;
	indictorR.extent.x = 0;
	
	// Find the start of the edit indicator.
	for (col = 0; col < table->numColumns; col++)
		{
		if (table->columnAttrs[col].usable)
			{
			if (table->columnAttrs[col].editIndicator)
				break;
			indictorR.topLeft.x += table->columnAttrs[col].width + 
		                			  table->columnAttrs[col].spacing;
			}	
		}

	// Compute the width of the edit indicator.
	for (; col < table->numColumns; col++)
		{
		if (table->columnAttrs[col].usable)
			{
			if (! table->columnAttrs[col].editIndicator)
				{
				if (col)
					indictorR.extent.x -= table->columnAttrs[col-1].spacing;
				break;
			
				}
			indictorR.extent.x += table->columnAttrs[col].width + 
		                			 table->columnAttrs[col].spacing;
			}
		}
			
	WinInvertRectangle (&indictorR, 3);
}



/*
static void InvertEditIndicator (TablePtr table)
{
	Word spacing;
	RectangleType itemR, indictorR;

	TblGetItemBounds (table, table->currentRow, table->currentColumn, &itemR);
	if (itemR.topLeft.x)
		{
		if (table->currentColumn)
			spacing = table->columnAttrs[table->currentColumn-1].spacing;
		else
			spacing = 0;
		indictorR.topLeft.x = table->bounds.topLeft.x;
		indictorR.topLeft.y = itemR.topLeft.y;
		indictorR.extent.x = itemR.topLeft.x - table->bounds.topLeft.x - spacing;
		indictorR.extent.y = tableSelectIndictorHeight;
		WinInvertRectangle (&indictorR, 3);
		}
}
*/

/***********************************************************************
 *
 * FUNCTION:    SaveTextItem
 *
 * DESCRIPTION: This routine checks if the focus is being changed to
 *              another item of the table.  If it is and the item
 *              that currently has the focus is a text item, the 
 *              save data callback routine is executed.
 * 
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 true if the table should be redrawn
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/5/95	Initial Revision
 *
 ***********************************************************************/
static Boolean SaveTextItem (TablePtr table)
{
	Word index;
	Boolean redraw = false;

	// If we're not editing, return
	if (! table->attr.editing)
		return (false);

	// If the item that has the focus is not a text item, returm.
	index = table->currentRow * table->numColumns + table->currentColumn;
	if ((table->items[index].itemType != textTableItem) &&
		 (table->items[index].itemType != textWithNoteTableItem) &&
		 (table->items[index].itemType != narrowTextTableItem))
		return (false);
		

	// Release any extra memory the field routines may have allocated 
	// for editing the text string.
	FldCompactText (&table->currentField);


	// Call the application to have it save the current text item.
	if (table->columnAttrs[table->currentColumn].saveDataCallback)
		{
		redraw = table->columnAttrs[table->currentColumn].saveDataCallback (
			table, table->currentRow, table->currentColumn);
		}


	// Invert the region to the left of the text item, this highlighted
	// region indicated that the table has in edit mode.
	FldReleaseFocus (&table->currentField);
	FldSetSelection (&table->currentField, 0, 0);
	InvertEditIndicator (table);


	// We're no longer editing the field, so lets clean up, clear the 
	// editing flag and turn off the inserting point or selection and 
	// release the memory allocated for the field.  Do not free the 
	// block the contains the string we edited.  
	table->attr.editing = false;
	FldSetTextHandle (&table->currentField, 0);
	FldFreeMemory (&table->currentField);
	
	if (redraw)
		TblRedrawTable (table);

	return (redraw);
}


/***********************************************************************
 *
 * FUNCTION:    SelectTextItem
 *
 * DESCRIPTION: This routine is called when the table object receives a 
 *              penDown event that is within the bounds of a text item.
 *              If the item that the pen is on is not the item that 
 *              is currently being edited,  a field obejct is 
 *              initialized for editing the text item.
 *
 * PARAMETERS:	 table   - pointer to a table object
 *              pEvent  - a penDawn event
 *              item    - a pointer to the table item the pen is on
 *              row     - row of the  item
 *              column  - column of the item
 *              r       - bounds of the item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void SelectTextItem (TablePtr table, EventPtr event,
	Word row, Word column, RectanglePtr r)
{
	Err err;
	FieldPtr fld;
	EventType newEvent;
	TableItemPtr item;
	RectangleType indictorR;
	
	ErrNonFatalDisplayIf (row >= table->numRows, "Invalid table row");
	ErrNonFatalDisplayIf (column >= table->numColumns, "Invalid table column");
	
	fld = &table->currentField;

	// Check if the pen is on the note indicator.
	item = &table->items[row*table->numColumns + column];
	if (item->itemType == textWithNoteTableItem)
		{
		indictorR.topLeft.x = r->topLeft.x + r->extent.x - tableNoteIndicatorWidth;
		indictorR.topLeft.y = r->topLeft.y;
		indictorR.extent.x = tableNoteIndicatorWidth;
		indictorR.extent.y = tableNoteIndicatorHeight;
		
		if (RctPtInRectangle (event->screenX, event->screenY, &indictorR))
			{
			SaveTextItem (table);
			SelectItem (table, event, row, column, &indictorR);
			return;
			}
		}
		

	// If the item is a nerrow-text-item there is some space, in the column,
	// reserved by the application for drawing sometime other then text.  The
	// width of reserved space is store in "intValue".  Check if the pen is
	// in the reserved space.
	else if (item->itemType == narrowTextTableItem)
		{
		indictorR.topLeft.x = r->topLeft.x + r->extent.x - item->intValue;
		indictorR.topLeft.y = r->topLeft.y;
		indictorR.extent.x = item->intValue;
		indictorR.extent.y = r->extent.y;		
		if (RctPtInRectangle (event->screenX, event->screenY, &indictorR))
			return;
		}


	// If we are not already editing this item, initialize the field
	// structure that's used for editing text item and highlight the edit
	// indication.
	if ((row != table->currentRow) || 
		 (column != table->currentColumn) ||
		 (! table->attr.editing) )
		{
		err = InitTextItem (table, fld, row, column, r->topLeft.x, 
			r->topLeft.y, true, true);

		// If the field does not have a text handle then the initializition
		// must have failed.
		if (err)
			{
			table->attr.editing = false;
			return;
			}
		
//		table->attr.editing = true;
		table->currentRow = row;
		table->currentColumn = column;
		
		InvertEditIndicator (table);
		}

	SendTableSelectEvent (table, row, column, true);

	// Convert the table enter event to a field enter event.
	EvtCopyEvent (event, &newEvent);
	newEvent.eType = fldEnterEvent;
	newEvent.data.fldEnter.fieldID = fld->id;
	newEvent.data.fldEnter.pField = fld;

	FldHandleEvent (fld, &newEvent);
}


/***********************************************************************
 *
 * FUNCTION:    ResizeTextItem
 *
 * DESCRIPTION: This routine expands or compresses the height of a text 
 *              item, it is called when the table object receives a 
 *              fldHeightChanged event.  
 *
 * PARAMETERS:	 table   - pointer to a table object
 *              pEvent  - a penDawn event
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/16/95	Initial Revision
 *			art	8/28/97	Add code to erase partially visible items
 *
 ***********************************************************************/
static void ResizeTextItem (TablePtr table, EventPtr event)
{
	short scrollAmount;
	Word row;
	Word height;
	Word maxHeight;
	Word newHeight;
	Boolean insPtState;
	RectangleType r, vacated, fldR, newBounds, itemR, scrollR;

	insPtState = InsPtEnabled ();
	InsPtEnable (false);

	newHeight = event->data.fldHeightChanged.newHeight;

	RctCopyRectangle (&table->currentField.rect, &fldR);
	RctCopyRectangle (&fldR, &newBounds);
	newBounds.extent.y = newHeight;

	// The height of the field can not expand below the botton of the table.
	maxHeight = table->bounds.topLeft.y + table->bounds.extent.y - 
		fldR.topLeft.y;
	
	
	// Expanding the height of a text item, scroll the table items above the
	// current text item up, the top items will be forced off the display.
	if (newHeight > maxHeight)
		{
		scrollAmount = 0;
		while (table->currentRow)
			{
			scrollAmount += table->rowAttrs[0].height;

			// Remove the top row from the table.
			TblRemoveRow (table, 0);
			table->currentRow--;

			if (scrollAmount >= (newHeight - maxHeight))
				break;
			}

		// Scroll the table up by the height of the item scrolled off the top.
		RctCopyRectangle (&table->bounds, &scrollR);
		scrollR.extent.y = fldR.topLeft.y - table->bounds.topLeft.y + fldR.extent.y;
		WinScrollRectangle (&scrollR, up, scrollAmount, &vacated);

		// Erase from the bottom of the region scrolled to the end of the table.
		vacated.extent.y = table->bounds.extent.y - (vacated.topLeft.y - 
			table->bounds.topLeft.y);
		WinEraseRectangle (&vacated, 0);
		
		// Offset the new field bounds by the amount we scrolled the table.
		newBounds.topLeft.y -= scrollAmount;
		
		// Set the new height of the row.
		table->rowAttrs[table->currentRow].height = newHeight;
		
		// Invalidate the rows below the current row so that that will be
		// redrawn.
		for (row = table->currentRow+1; row < table->numRows; row++)
			{
			if (table->rowAttrs[row].usable)
				table->rowAttrs[row].invalid = true;
			}		
		}


	// Expanding the height of a text item, scoll the table items below the
	// text item down. 
	else if (newHeight > fldR.extent.y)
		{
		// Get the bounds of the region that encompasses all the items below the 
		// text item and erase it.
		r.topLeft.x = table->bounds.topLeft.x;
		r.topLeft.y = fldR.topLeft.y + fldR.extent.y;
		r.extent.x = table->bounds.extent.x;
		r.extent.y = table->bounds.extent.y - (r.topLeft.y - table->bounds.topLeft.y);

		scrollAmount = newHeight - fldR.extent.y;
		WinScrollRectangle (&r, down, scrollAmount, &vacated);
		WinEraseRectangle (&vacated, 0);

		// Set the new height of the row.
		table->rowAttrs[table->currentRow].height += scrollAmount;

		// Invalidate any items that were forced off the display.
		height = 0;
		for (row = 0; row < table->numRows; row++)
			{
			if (table->rowAttrs[row].usable)
				{
				if (height >= table->bounds.extent.y)
					{
					table->rowAttrs[row].invalid = true;
					table->rowAttrs[row].usable = false;
					}

				// If an item is partially visible, erase it.
				else if (height + table->rowAttrs[row].height > table->bounds.extent.y)
					{
					r.topLeft.x = table->bounds.topLeft.x;
					r.topLeft.y = table->bounds.topLeft.y + height;
					r.extent.x = table->bounds.extent.x;
					r.extent.y = table->bounds.extent.y - height;
					WinEraseRectangle (&r, 0);
					
					table->rowAttrs[row].invalid = true;
					table->rowAttrs[row].usable = false;
					}
				
				height += table->rowAttrs[row].height;
				}
			}
		}
		
	// Compressing the height of a text item, scoll the table items below the
	// text item up. 
	else if (newHeight < fldR.extent.y)
		{
		// Get the bounds of the region that encompasses all the items below the 
		// text item.
		r.topLeft.x = table->bounds.topLeft.x;
		r.topLeft.y = fldR.topLeft.y + newHeight;
		r.extent.x = table->bounds.extent.x;
		r.extent.y = table->bounds.extent.y - (r.topLeft.y - table->bounds.topLeft.y);

		scrollAmount = fldR.extent.y - newHeight;
		WinScrollRectangle (&r, up, scrollAmount, &vacated);
		WinEraseRectangle (&vacated, 0);

		table->rowAttrs[table->currentRow].height = newHeight;
		

		// If the last visible item is partially of the bottom of the display
		// mark the item invalid so that it will be redrawn.
		row = TblGetLastUsableRow (table);
		TblGetItemBounds (table, row, table->currentColumn, &itemR);
	
		if (itemR.topLeft.y + itemR.extent.y > 
			 table->bounds.topLeft.y + table->bounds.extent.y - scrollAmount)
			{
			TblMarkRowInvalid (table, row);	
			}
		}


	// Change the size of the field.
	FldSetBounds (&table->currentField, &newBounds);
	FldSetInsPtPosition (&table->currentField, 
		event->data.fldHeightChanged.currentPos);

	// Turn the insertion point back on.
	InsPtEnable (insPtState);
}		




/***********************************************************************
 *
 * FUNCTION:    DrawItem
 *
 * DESCRIPTION: This routine draws the specified item of the table.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *
 ***********************************************************************/
static void DrawItem (TablePtr table, Word row, Word col, short x, short y)
{
	TableItemPtr item;
	RectangleType r;
	
	item = &table->items[row*table->numColumns + col];

	switch (item->itemType)
		{
		case labelTableItem:
			DrawLabelItem (table, item, col, x, y);
			break;

		case numericTableItem:
			DrawNumericItem (table, item, col, x, y);
			break;

		case textTableItem:
		case textWithNoteTableItem:
			DrawTextItem (table, item, row, col, x, y);
			break;

		case checkboxTableItem:
			DrawCheckboxItem (table, item, col, x, y);
			break;

		case popupTriggerTableItem:
			DrawPopupTriggerItem (table, item, col, x, y);
			break;

		case dateTableItem:
			DrawDateItem (table, item, col, x, y);
			break;

		case narrowTextTableItem:
			DrawTextItem (table, item, row, col, x, y);
			// fall through

		case customTableItem:
			// if there is a custom draw routine, call it.
			if (! table->columnAttrs[col].drawCallback)
				break;
			RctSetRectangle (&r, x, y, table->columnAttrs[col].width,
				table->rowAttrs[row].height);
			table->columnAttrs[col].drawCallback (table, row, col, &r);			
			break;
		}
}




/***********************************************************************
 *
 * FUNCTION:    TblDrawTable
 *
 * DESCRIPTION: This routine draws a table.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblDrawTable (const TablePtr table)
{
	int	row, col;
	short x, y;
	RectangleType r;

	table->attr.visible = true;
	
	x = table->bounds.topLeft.x;
	y = table->bounds.topLeft.y;
	
	for (row = table->topRow; row < table->numRows; row++)
		{
		if (table->rowAttrs[row].usable)
			{	
			table->rowAttrs[row].invalid = false;

			for (col = 0; col < table->numColumns; col++)
				{
				if (table->columnAttrs[col].usable)
					{	
					DrawItem (table, row, col, x, y);
					x += table->columnAttrs[col].width + 
						  table->columnAttrs[col].spacing;
					}
				}
			x = table->bounds.topLeft.x;
			y += table->rowAttrs[row].height;
			}
		} 

	if (table->attr.editing)
		InvertEditIndicator (table);

	else if (table->attr.selected)
		{
		TblGetItemBounds (table, table->currentRow, table->currentColumn, &r);
		WinInvertRectangle (&r, 0);
		}

	// Erase the region below the last row drawn.
	if ((y - table->bounds.topLeft.y) < table->bounds.extent.y)
		{
		RctSetRectangle (&r, 
			table->bounds.topLeft.x, 
			y,
			table->bounds.extent.x, 
			table->bounds.extent.y - (y - table->bounds.topLeft.y));
		WinEraseRectangle (&r, 0);
		}
}


/***********************************************************************
 *
 * FUNCTION:    TblRedrawTable
 *
 * DESCRIPTION: This routine redraws the rows of the table that are marked
 *              invalid.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *       art	5/21/96	Fixed bug when redrawing edit indicator.
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblRedrawTable (const TablePtr table)
{
	Int	index;
	Int	row, col;
	short x, y;
	Boolean redrawEditIndicator = false;
	TableItemPtr item;
	RectangleType r;
	RectangleType clipR;
	
	if (! table->attr.visible)
		return;
		
	WinGetClip (&clipR);
	WinSetClip (&table->bounds);

	x = table->bounds.topLeft.x;
	y = table->bounds.topLeft.y;
	
	for (row = table->topRow; row < table->numRows; row++)
		{
		if (table->rowAttrs[row].usable)
			{
			if (table->rowAttrs[row].invalid)
				{
				table->rowAttrs[row].invalid = false;
				
				// If we're editing the current row, turn of the insertion point.
				if (table->attr.editing && (row == table->currentRow))
					{
					InsPtEnable (false);
					redrawEditIndicator = true;
					}
					
				// Erase the bounds of the row
				RctSetRectangle (&r, table->bounds.topLeft.x, y, 
					table->bounds.extent.x,
					table->rowAttrs[row].height);
				WinEraseRectangle (&r, 0);
				
				// Draw the items in the row
				for (col = 0; col < table->numColumns; col++)
					{
					if (table->columnAttrs[col].usable)
						{	
						DrawItem (table, row, col, x, y);
						x += table->columnAttrs[col].width + 
						     table->columnAttrs[col].spacing;
						}
					}
				}

			x = table->bounds.topLeft.x;
			y += table->rowAttrs[row].height;
			}
		}

	// insure that the current field bounds are correct, and restore the
	// insertion point and the edit indicator.	
	if (redrawEditIndicator)
		{
		InvertEditIndicator (table);
		TblGetItemBounds (table, table->currentRow, table->currentColumn, &r);
		
		// If the item has a note, leave space for the note indicator.
		// If the application has reserved space to the rigth of the text item,
		// leave space for it.
		index = table->currentRow * table->numColumns + table->currentColumn;
		item = item = &table->items[index];
		if (item->itemType == textWithNoteTableItem)
			r.extent.x -= tableNoteIndicatorWidth;
		else if (item->itemType == narrowTextTableItem)
			r.extent.x -= item->intValue;

		FldSetBounds (&table->currentField, &r);
		InsPtEnable (true);
		}


	// Erase the region below the last row drawn.
	if ((y - table->bounds.topLeft.y) < table->bounds.extent.y)
		{
		RctSetRectangle (&r, 
			table->bounds.topLeft.x, 
			y,
			table->bounds.extent.x, 
			table->bounds.extent.y - (y - table->bounds.topLeft.y));
		WinEraseRectangle (&r, 0);
		}

	WinSetClip (&clipR);	
}


/***********************************************************************
 *
 * FUNCTION:    TblEraseTable
 *
 * DESCRIPTION: This routine erases a table object.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblEraseTable (const TablePtr table)
{
	WinEraseRectangle (&table->bounds, 0);
	table->attr.visible = false;
	table->attr.selected = false;
}


/***********************************************************************
 *
 * FUNCTION:    TblHandleEvent
 *
 * DESCRIPTION: This routine 
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean TblHandleEvent (const TablePtr table, const EventPtr event)
{
	Word	row, column;
	RectangleType r;
	TableItemPtr item;
	EventType newEvent;
	
	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		ECValidateTable (table);
	#endif

	if (! table->attr.editable) return (false);

	if (event->eType == keyDownEvent)
		{
		if (! table->attr.editing)
			return (false);
		else if (FldHandleEvent (&table->currentField, event))
			return (true);
		else if (event->data.keyDown.chr == confirmChr)
			{
			TblReleaseFocus (table);
			return (true);
			}
		}
		
	else if (event->eType == fldEnterEvent)
		{
		FldHandleEvent (&table->currentField, event);
		}
		
	else if (event->eType == fldHeightChangedEvent)
		{
		ResizeTextItem (table, event);
		FldHandleEvent (&table->currentField, event);
		return (true);
		}
		
	else if (event->eType == penDownEvent)
		{
		if (PointInTableItem (table, event->screenX, event->screenY,
				 &row, &column, &r))
			{
			TblUnhighlightSelection (table);
		
			// If the focus is not being changed, and the current item is a 
			// text item,  save its data.
			if ((row != table->currentRow) || (column != table->currentColumn))
				SaveTextItem (table);

			EvtCopyEvent (event, &newEvent);
			newEvent.eType = tblEnterEvent;
			newEvent.data.tblEnter.tableID = table->id;
			newEvent.data.tblEnter.pTable = table;
			newEvent.data.tblEnter.row = row;
			newEvent.data.tblEnter.column = column;
			EvtAddEventToQueue (&newEvent);

			return (true);
			}

		else
			return (false);
		}			


	else if (event->eType == tblEnterEvent)
		{
		row = event->data.tblEnter.row;
		column = event->data.tblEnter.column;
		

		// Get the bounds of the table item.
		TblGetItemBounds (table, row, column, &r);

		item = &table->items[row*table->numColumns + column];
		switch (item->itemType)
			{
			case textTableItem:
			case textWithNoteTableItem:
			case narrowTextTableItem:
				SelectTextItem (table, event, row, column, &r);
				break;

			case checkboxTableItem:
				CheckboxHandleEvent (table, event, row, column, &r);
				break;

			case popupTriggerTableItem:
				PopupTriggerHandleEvent (table, event, row, column, &r);
				break;

			case customTableItem:
				CustomItemHandleEvent (table, event, row, column, &r);
				break;
				
			case numericTableItem:
			case dateTableItem:
			case labelTableItem:
				SelectItem (table, event, row, column, &r);
				break;

			default:
				return (false);
			}
		}
	return (false);	
}


/***********************************************************************
 *
 * FUNCTION:    TbltGetItemBounds
 *
 * DESCRIPTION: This routine returns the bounds of a an item in a table.
 *
 * PARAMETERS:	 table   - pointer to a table object
 *              row     - row of the item (zero based)
 *              column  - column of the item (zero based)
 *              r       - pointer to a structure that will hold the bound
 *                        of the item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblGetItemBounds (const TablePtr table, const Word row, 
	const Word column, const RectanglePtr r)
{
	int i;
	FontID curFont;
	TableItemPtr item;
	
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	r->topLeft.x = table->bounds.topLeft.x;
	r->topLeft.y = table->bounds.topLeft.y;

	// Find the top bound of the item.
	for (i = table->topRow; i < row; i++)
		{
		if (table->rowAttrs[i].usable)
			r->topLeft.y += table->rowAttrs[i].height;
		}
		
	// Find the bottom bound of the item.
	for (i = 0; i < column; i++)
		{
		if (table->columnAttrs[i].usable)
			r->topLeft.x += table->columnAttrs[i].width + 
			                table->columnAttrs[i].spacing;
		}
		
	r->extent.x = table->columnAttrs[column].width;
	r->extent.y = table->rowAttrs[row].height;
	
	item = &table->items[row*table->numColumns+column];
	if ((item->itemType != textTableItem) &&
		 (item->itemType != textWithNoteTableItem) && 
		 (item->itemType != narrowTextTableItem))
		{
		curFont = FntSetFont (item->fontID);
		r->extent.y = FntLineHeight ();
		FntSetFont (curFont);
		}
}


/***********************************************************************
 *
 * FUNCTION:    TblUnhighlightSelection
 *
 * DESCRIPTION: This routine unhighlighs) the currently selected item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/15/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblUnhighlightSelection (const TablePtr table)
{
	RectangleType r;
	
	if (table->attr.selected)
		{
		if (table->attr.visible)
			{
			TblGetItemBounds (table, table->currentRow, table->currentColumn, &r);
			WinInvertRectangle (&r, 0);
			}
		table->attr.selected = false;
		}
}

/***********************************************************************
 *
 * FUNCTION:    TbltSelectItem
 *
 * DESCRIPTION: This routine selects (highlighs) the item specified,
 *              if there is already a selected item, it is unhighlighed.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item to select (zero based)
 *              column - column of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblSelectItem (const TablePtr table, const Word row, const Word column)
{
	RectangleType r;
	

	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");


	if (! table->attr.visible)
		return;

	if (table->attr.selected)
		{
		TblGetItemBounds (table, table->currentRow, table->currentColumn, &r);
		WinInvertRectangle (&r, 0);
		}
	table->currentRow = row;
	table->currentColumn	= column;

	TblGetItemBounds (table, row, column, &r);
	WinInvertRectangle (&r, 0);
	table->attr.selected = true;
}


/***********************************************************************
 *
 * FUNCTION:    TblGetItemInt
 *
 * DESCRIPTION: This routine returned the interger value stores in a table
 *              item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item to select (zero based)
 *              column - column of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/7/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word TblGetItemInt (const TablePtr table, const Word row, const Word column)
{
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->items[row*table->numColumns + column].intValue);
}


/***********************************************************************
 *
 * FUNCTION:    TblSetItemInt
 *
 * DESCRIPTION: This routine set the interter value of the item specified.
 *              An application can store whatever it wants in the interter
 *              value of an item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item (zero based)
 *              column - column of the item (zero based)
 *              value  - any byte value
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetItemInt (const TablePtr table, const Word row, const Word column, 
 	const Word value)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->items[row*table->numColumns + column].intValue = value;
 }

/***********************************************************************
 *
 * FUNCTION:    TblSetItemPtr
 *
 * DESCRIPTION: This routine set the interter value of the item specified.
 *              An application can store whatever it wants in the interter
 *              value of an item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item (zero based)
 *              column - column of the item (zero based)
 *              value  - any byte value
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetItemPtr (const TablePtr table, const Word row, const Word column, 
 	const VoidPtr value)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->items[row*table->numColumns + column].ptr = value;
 }

/***********************************************************************
 *
 * FUNCTION:    TblSetItemStyle
 *
 * DESCRIPTION: This routine set the style of the item specified.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item (zero based)
 *              column - column of the item (zero based)
 *              type   - 
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *       art	5/21/96	Set editIndicator to true for non-text columns
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetItemStyle (const TablePtr table, const Word row, const Word column, 
 	const TableItemStyleType style)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->items[row*table->numColumns + column].itemType = style;
	
	// In version 2.0 I added a column attribute that indicates if a column
	// should be highlighted when we're in edit mode. To maintain
	// compatability with version 1.0 we initialize that attribute.
	if (style != textTableItem &&
		 style != textWithNoteTableItem &&
		 style != narrowTextTableItem)
		table->columnAttrs[column].editIndicator = true;
	else
		table->columnAttrs[column].editIndicator = false;
 }


/***********************************************************************
 *
 * FUNCTION:    TblGetItemFont
 *
 * DESCRIPTION: This routine returns thefont id stored in a the 
 *              specified table item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item to select (zero based)
 *              column - column of the item to select (zero based)
 *
 * RETURNED:	 the font id of the specified item
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/29/97	Initial Revision
 *
 ***********************************************************************/
FontID TblGetItemFont (TablePtr table, Word row, Word column)
{
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->items[row*table->numColumns + column].fontID);
}


/***********************************************************************
 *
 * FUNCTION:    TblSetItemFont
 *
 * DESCRIPTION: This routine set the font id of the item specified.
 *
 * PARAMETERS:	 table   - pointer to a table object
 *              row     - row of the item (zero based)
 *              column  - column of the item (zero based)
 *              fontID  - font id
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/29/97	Initial Revision
 *
 ***********************************************************************/
 void TblSetItemFont (TablePtr table, Word row, Word column, FontID fontID)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->items[row*table->numColumns + column].fontID = fontID;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetRowUsable
 *
 * DESCRIPTION: This routine returns true if the specified row 
 *              is usable.  Rows that are unusable do not display.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row number (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/10/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Boolean TblRowUsable  (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->rowAttrs[row].usable);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetRowUsable
 *
 * DESCRIPTION: This routine sets a row in a table usable or unusable.
 *              Rows that are unusable do not display.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item to select (zero based)
 *              usable - true or false
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowUsable  (const TablePtr table, const Word row, 
 	const Boolean usable)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].usable = usable;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetRowStaticHeight
 *
 * DESCRIPTION: This routine sets the static height attribute of a row.
 *              A rows that that has its static height attribute set will
 *              not expand / contract the height of the row as test is 
 *              added / removed from a text item.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row of the item to select (zero based)
 *              static - true or false
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/5/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowStaticHeight (const TablePtr table, const Word row, 
 	const Boolean staticHeight)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].staticHeight = staticHeight;
 }


/***********************************************************************
 *
 * FUNCTION:    TblGetLastUsableRow
 *
 * DESCRIPTION: This routine returns the last row in a table that 
 *              in usable (displayable)
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              rowP   - row index, zero based (returned value)
 *
 * RETURNED:	 row   - row index (zero based) or -1 if there are no 
 *                     usable rows.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/29/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Word TblGetLastUsableRow (const TablePtr table)
 {
	Word i;
	Word row = -1;
	
	for (i = 0; i < table->numRows; i++)
		{
		if (table->rowAttrs[i].usable)
			row = i;			
		}
	return (row);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetRowSelectable
 *
 * DESCRIPTION: This routine sets a row in a table selectable or
 *              non-selectable. Rows that are non-selectable 
 *              will not highlight when touched.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *              selectable - true or false
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowSelectable  (const TablePtr table, const Word row, 
 	const Boolean selectable)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].selectable = selectable;
 }
 
 
/***********************************************************************
 *
 * FUNCTION:    TbRowSelectable
 *
 * DESCRIPTION: This routine returns true if the row specified is 
 *              selectable. Rows that are non-selectable 
 *              will not highlight when touched.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *
 * RETURNED:	 id of the row specied
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Boolean TblRowSelectable (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->rowAttrs[row].selectable);
 }
 
/***********************************************************************
 *
 * FUNCTION:    TblFindRowID
 *
 * DESCRIPTION: This routine returns the number of the row that 
 *              matches the specified id.
 *
 * PARAMETERS:	 table - pointer to a table object.
 *              id    - row id to find
 *              rowP  - pointer to the row number (return value)
 *
 * RETURNED:	 true is a match was found
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/15/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean TblFindRowID (const TablePtr table, const Word id, 
	const WordPtr rowP)
{
	int row;
	
	for (row = 0; row < table->numRows; row++)
		{
		if (table->rowAttrs[row].usable)
			{
			if (id == table->rowAttrs[row].id)
				{
				*rowP = row;
				return (true);
				}
			}				
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    TblFindRowData
 *
 * DESCRIPTION: This routine returns the row number that contains the
 *              specified data value.
 *
 * PARAMETERS:	 table - pointer to a table object.
 *              data  - row data to find
 *              rowP  - pointer to the row number (return value)
 *
 * RETURNED:	 true is a match was found
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/28/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean TblFindRowData (const TablePtr table, const DWord data, 
	const WordPtr rowP)
{
	int row;
	
	for (row = 0; row < table->numRows; row++)
		{
		if (table->rowAttrs[row].usable)
			{
			if (data == table->rowAttrs[row].data)
				{
				*rowP = row;
				return (true);
				}
			}				
		}
	return (false);
}


 /***********************************************************************
 *
 * FUNCTION:    TblGetRowID
 *
 * DESCRIPTION: This routine returns id value of the row specifed.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Word TblGetRowID (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->rowAttrs[row].id);
 }
 
 
 /***********************************************************************
 *
 * FUNCTION:    TblSetRowID
 *
 * DESCRIPTION: This routine set to id value of the row specifed.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *              id         - id to identify a row
 *
 * RETURNED:	 nothinh
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowID (const TablePtr table, const Word row, const Word id)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].id = id;
 }
 

 /***********************************************************************
 *
 * FUNCTION:    TblGetRowData
 *
 * DESCRIPTION: This routine returns data value of the row specifed.  
 *              The data value is a place holder for application
 *              specific values.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/27/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 DWord TblGetRowData (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->rowAttrs[row].data);
 }
 
 
 /***********************************************************************
 *
 * FUNCTION:    TblSetRowData
 *
 * DESCRIPTION: This routine set to data value of the row specifed.
 *              The data value is a place holder for application
 *              specific values.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *              date       - application specific data
 *
 * RETURNED:	 nothinh
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowData (const TablePtr table, const Word row, const DWord data)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].data = data;
 }
 

/***********************************************************************
 *
 * FUNCTION:    TblSetRowInvalid
 *
 * DESCRIPTION: This routine returns true if the specified row 
 *              is invalid.  Rows that are invalid need to be redrawn.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row number (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/21/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Boolean TblRowInvalid  (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	return (table->rowAttrs[row].invalid);
 }


 /***********************************************************************
 *
 * FUNCTION:    TblMarkRowInvalid
 *
 * DESCRIPTION: This routine marks the image of the row specifed invalid.  
 *              Rows that are mark invalid will be drawn by the table 
 *              redraw routine (TblRedrawTable).  Row the are not mark 
 *              invalid will not draw.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblMarkRowInvalid (const TablePtr table, const Word row)
{
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	table->rowAttrs[row].invalid = true;
}


 /***********************************************************************
 *
 * FUNCTION:    TblMarkTableInvalid
 *
 * DESCRIPTION: This routine marks the image of all the rows in a table
 *              invalid.  Rows that are mark invalid will be drawn by 
 *              the table redraw routine (TblRedrawTable).  Row the are 
 *              not mark invalid will not draw.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              row        - row of the item to select (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblMarkTableInvalid (const TablePtr table)
{
	long row;
	
	for (row = 0; row < table->numRows; row++)
		table->rowAttrs[row].invalid = true;
}


 /***********************************************************************
 *
 * FUNCTION:    TblInsertRow
 *
 * DESCRIPTION: This routine insert a row into the table before the 
 *              specified row.  The number of row in the table is 
 *              not increased, the last row in the table is 
 *              removed.
 *
 * PARAMETERS:	 table    - pointer to a table object
 *              row      - row to insert before (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblInsertRow (const TablePtr table, const Word row)
{
	Word rowsToMove;
	Word columns;
	
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	columns = table->numColumns;
	rowsToMove = table->numRows - row - 1;
	if (rowsToMove == 0) return;

	MemMove (&table->rowAttrs[row+1], &table->rowAttrs[row],
		rowsToMove * sizeof (TableRowAttrType));
	
	MemMove (&table->items[(row+1)*columns], &table->items[row*columns],
		rowsToMove * columns * sizeof (TableItemType));
		
	if ((table->attr.editing || table->attr.selected) &&
	    (row <= table->currentRow))
		{
		table->currentRow++;
		ErrNonFatalDisplayIf (table->currentRow >= table->numRows, "currentRow violated constraint!");
		}
}


 /***********************************************************************
 *
 * FUNCTION:    TblRemoveRow
 *
 * DESCRIPTION: This routine removes the specified row from the table 
 *              The number of row in the table is not decreased, 
 *              a row is added to the end of the table.
 *
 * PARAMETERS:	 table    - pointer to a table object
 *              row      - row to insert before (zero based)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblRemoveRow (const TablePtr table, const Word row)
{
	Word rowsToMove;
	Word columns;
	
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	columns = table->numColumns;
	rowsToMove = table->numRows - row - 1;

	MemMove (&table->rowAttrs[row], &table->rowAttrs[row+1],
		rowsToMove * sizeof (TableRowAttrType));
	
	MemMove (&table->items[row*columns], &table->items[(row+1)*columns],
		rowsToMove * columns * sizeof (TableItemType));
	

	table->rowAttrs[table->numRows-1].id = 0;
	table->rowAttrs[table->numRows-1].invalid = true;
	table->rowAttrs[table->numRows-1].usable = false;
}


 /***********************************************************************
 *
 * FUNCTION:    TblGetSelection
 *
 * DESCRIPTION: This routine returns the row and column of the currently
 *              selected table item.
 *
 * PARAMETERS:	 table      - pointer to a table object
 *              rowP       - row of the selected item (zero based)
 *              columnP    - column of the selected item (zero based)
 *
 * RETURNED:	 true if the item is highlighed false if not
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/2/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean TblGetSelection (const TablePtr table, const WordPtr rowP,
	const WordPtr columnP)
{
	*rowP = table->currentRow;
	*columnP = table->currentColumn;

	return (table->attr.selected == true);
}


/***********************************************************************
 *
 * FUNCTION:    TblGetNumberOfRows
 *
 * DESCRIPTION: This routine returns the number of rows in a table.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *
 * RETURNED:	 number of rows in the specified table.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Word TblGetNumberOfRows (const TablePtr table)
 {
	return (table->numRows);
 }

/***********************************************************************
 *
 * FUNCTION:    TblGetBounds
 *
 * DESCRIPTION: This routine returns the bounds of a table.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              r      - pointer to a RectangleType structure
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/27/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblGetBounds (const TablePtr table, const RectanglePtr r)
 {
	RctCopyRectangle (&table->bounds, r);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetBounds
 *
 * DESCRIPTION: This routine sets the bounds of a table.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              r      - pointer to a RectangleType structure
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/27/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetBounds (const TablePtr table, const RectanglePtr r)
 {
	RctCopyRectangle (r, &table->bounds);
 }


/***********************************************************************
 *
 * FUNCTION:    TblGetRowHeight
 *
 * DESCRIPTION: This routine returns the height of the specified row.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row to set (zero based)
 *
 * RETURNED:	 height in pixels
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/19/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 Word TblGetRowHeight (const TablePtr table, const Word row)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

 	return (table->rowAttrs[row].height);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetRowHeight
 *
 * DESCRIPTION: This routine sets the height of the specified row.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              row    - row to set (zero based)
 *              height - new height in pixels
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/27/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetRowHeight (const TablePtr table, const Word row, const Word height)
 {
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

 	table->rowAttrs[row].height = height;
 }


/***********************************************************************
 *
 * FUNCTION:    TblGetColumnWidth
 *
 * DESCRIPTION: This routine returns the width of the specified column
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              column - column number (zero based)
 *
 * RETURNED:	 width of a column
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/27/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word TblGetColumnWidth (const TablePtr table, const Word column)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

 	return (table->columnAttrs[column].width);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetColumnWidth
 *
 * DESCRIPTION: This routine sets the width of the specified column.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              column - column number (zero based)
 *              width  - width of the column
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblSetColumnWidth (const TablePtr table, const Word column, 
	const Word width)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

 	table->columnAttrs[column].width = width;
 }

/***********************************************************************
 *
 * FUNCTION:    TblGetColumnSpacing
 *
 * DESCRIPTION: This routine returns the spacing after the specified column.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              column - column number (zero based)
 *
 * RETURNED:	 spacing after column
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/26/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word TblGetColumnSpacing (const TablePtr table, const Word column)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

 	return (table->columnAttrs[column].spacing);
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetColumnSpacing
 *
 * DESCRIPTION: This routine sets the spacing after the specified column.
 *
 * PARAMETERS:	 table    - pointer to a table object
 *              column   - column number (zero based)
 *              spacing  - spacing after the column
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/26/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblSetColumnSpacing (const TablePtr table, const Word column, 
	const Word spacing)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

 	table->columnAttrs[column].spacing = spacing;
 }

/***********************************************************************
 *
 * FUNCTION:    TblSetColumnUsable
 *
 * DESCRIPTION: This routine sets a column in a table usable or unusable.
 *              Columns that are unusable do not display.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              column - column of the item to select (zero based)
 *              usable - true or false
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetColumnUsable  (const TablePtr table, const Word column, 
 	const Boolean usable)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

	table->columnAttrs[column].usable = usable;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetColumnEditIndicator
 *
 * DESCRIPTION: This routine set the column attribute that control whether
 *              a column highlights when the table is in edit mode.
 *
 * PARAMETERS:	 table  - pointer to a table object
 *              column - column of the item (zero based)
 *              editIndicator
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/21/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetColumnEditIndicator (const TablePtr table, const Word column, 
 	const Boolean editIndicator)
 {
	table->columnAttrs[column].editIndicator = editIndicator;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetCustomDrawProcedure
 *
 * DESCRIPTION: This routine sets the custom draw callback routine for
 *              the column specified.  The custom draw callback routine
 *              is used to draw table items with a style of
 *              customTableItem.
 *
 * PARAMETERS:	 table       - pointer to a table object
 *              column       - column of table
 *              drawCallback - callback routine.
 *
 * NOTE:        The callback routine should have the follow prototye:
 *							void drawCallback (VoidPtr table, Word row,
 *							Word column, RectanglePtr bounds);
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/16/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetCustomDrawProcedure (const TablePtr table, const Word column, 
 	const TableDrawItemFuncPtr drawCallback)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

	table->columnAttrs[column].drawCallback = drawCallback;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetLoadDataProcedure
 *
 * DESCRIPTION: This routine sets the load data  callback routine for
 *              the column specified.  The callback routine is used
 *              to obtain the data valus of a table items.
 *
 * PARAMETERS:	 table            - pointer to a table object
 *              column           - column of table
 *              loadDataCallback - callback routine.
 *
 * NOTE:        The callback routine should have the follow prototye:
 *							VoidHand  LoadDataCallback (VoidPtr table, Word row,
 *                   Word column, Boolean editable, 
 *							WordPtr dataOffset, WordPtr dataSize);
 *
 *              The callback routine should return the handle of a block 
 *              that contains a null terminated text string, the 
 *              offset from the start of the block to the start of the
 *              string, and the amount of space allocated for the string.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetLoadDataProcedure (const TablePtr table, const Word column,
 	const TableLoadDataFuncPtr loadDataCallback)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

	table->columnAttrs[column].loadDataCallback = loadDataCallback;
 }


/***********************************************************************
 *
 * FUNCTION:    TblSetSaveDataProcedure
 *
 * DESCRIPTION: This routine sets the save data  callback routine for
 *              the column specified.  The callback routine is called when 
 *              the table object determine the the data of a text object
 *              needes to be saved.
 *
 * PARAMETERS:	 table            - pointer to a table object
 *              column           - column of table
 *              saveDataCallback - callback routine.
 *
 * NOTE:        The callback routine should have the follow prototye:
 *							VoidPtr  SaveDataCallback (VoidPtr table, Word row,
 *							Word column);
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
 void TblSetSaveDataProcedure (const TablePtr table, const Word column,
 	const TableSaveDataFuncPtr saveDataCallback)
 {
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");

	table->columnAttrs[column].saveDataCallback = saveDataCallback;
 }


/***********************************************************************
 *
 * FUNCTION:    TblReleaseFocus
 *
 * DESCRIPTION: This routine release the focus.  If the current item is
 *              a text item, the memory allaocated for editing is released
 *              and the insertion point is turned off.
 *
 * PARAMETERS:	 table - pointer to a table object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblReleaseFocus (const TablePtr table)
{
	SaveTextItem (table);
}


/***********************************************************************
 *
 * FUNCTION:    TblEditing
 *
 * DESCRIPTION: This routine returns true if the table is in edit mode.
 *              The table is in edit mode when a text item is being
 *              edited.
 *
 * PARAMETERS:	 table - pointer to a table object
 *
 * RETURNED:	 true if the table is in edit mode
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean TblEditing (const TablePtr table)
{
	return (table->attr.editing);
}


/***********************************************************************
 *
 * FUNCTION:    TblGetCurrentField
 *
 * DESCRIPTION: This routine returns a pointer to the field structure 
 *              used to edit the current text item
 *
 * PARAMETERS:	 table - pointer to a table object
 *
 * RETURNED:	 FieldPtr or NULL if the table is not is edit mode.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/3/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
FieldPtr TblGetCurrentField (const TablePtr table)
{
	if (table->attr.editing)
		return (&table->currentField);
	
	return (NULL);
}


/***********************************************************************
 *
 * FUNCTION:    TblGrabFocus
 *
 * DESCRIPTION: This routine will put the table into edit mode.
 *
 * PARAMETERS:	 table - pointer to a table object.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/30/95	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblGrabFocus (const TablePtr table, const Word row, const Word column)
{
	FieldPtr fld;
	RectangleType itemR;

	ErrFatalDisplayIf(table->attr.editing, "Table already has focus");
	ErrFatalDisplayIf (column >= table->numColumns, "Invalid parameter");
	ErrFatalDisplayIf (row >= table->numRows, "Invalid parameter");

	fld = &table->currentField;
	TblGetItemBounds (table, row, column, &itemR);
	InitTextItem (table, fld, row, column, itemR.topLeft.x, itemR.topLeft.y, 
		true, true);

	table->attr.editing = true;
	table->currentRow = row;
	table->currentColumn = column;
		
	InvertEditIndicator (table);
}


/***********************************************************************
 *
 * FUNCTION:    TblSetRowStaticHeight
 *
 * DESCRIPTION: This routine sets the hasScrollBar attribute the table.
 *              A table that has its attribute set will initialize it's
 *              field object such that it will send fldChanged events
 *              when that scroll bar needs to be updated.
 *
 * PARAMETERS:	 table        - pointer to a table object
 *              hasScrollBar - true or false
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/7/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void TblHasScrollBar (const TablePtr table, const Boolean hasScrollBar)
{
	table->attr.hasScrollBar = hasScrollBar;
}