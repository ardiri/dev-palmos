/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     font.c
 * AUTHOR:	 Art Lamb: Dec 14, 1994
 *
 * DECLARER: UI
 *
 * ROUTINES:
 *		FntAccentHeight
 *		FntAscent
 *		FntAverageCharWidth
 *		FntBaseLine
 *		FntCharHeight
 *		FntCharWidth
 *		FntCharsWidth
 *		FntDescenderHeight
 *		FntGetFont
 *		FntLineHeight
 *		FntProportionalFont
 *		FntSetFont
 *
 * DESCRIPTION:
 *	  This file contains the font routines.
 *
 **********************************************************************/

//#define PILOT_PRECOMPILED_HEADERS_OFF 1
//#define USE_TRAPS 	0

#include <Pilot.h>

// zzz - fix this
#define  tabChrWidth      20
#define	missingChar		  -1

/***********************************************************************
 *
 * FUNCTION:    FindReverseByte
 *
 * DESCRIPTION: This routine searches a string in reverse order for the
 *              the character specified.
 *
 * PARAMETERS:	fld          a pointer to the string to search
 *             byteToFind   the character to find
 *             len
 *             
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/22/94	Initial Revision
 *
 ***********************************************************************/
static Boolean FindReverseByte (const Char * const text, char byteToFind, Word len, 
	WordPtr pos)
{
	Char const * p;
	
	p = text + len - 1;
	
	while (len)
		{
		if (*p == byteToFind)
			{
			*pos = len-1;
			return (true);
			}
		p--;
		len--;
		};
	
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    FntGetFont
 *
 * DESCRIPTION: This routine returns the FontID of the current font.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    FontID of the current font.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
FontID FntGetFont (void)
{
	return (UICurrentFontID);
}


/***********************************************************************
 *
 * FUNCTION:    FntSetFont
 *
 * DESCRIPTION: This routine set the current font.  If the font is a valid
 * font but doesn't exist, the stdFont is used.
 *
 * PARAMETERS:  fontID   id of the font to make the active font
 *
 * RETURNED:    ID of the current font prior to the change.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *			roger	9/26/97	Now substitutes the stdFont for missing fonts
 *			SCL	12/10/97	Rewrote to support new (separate) font tables
 *			SCL	1/23/98	Now uses stdFont if passed an invalid font
 *
 ***********************************************************************/
FontID FntSetFont (const FontID fontID)
{
	FontID newFontID = fontID;
	FontID oldFontID;

	// See if fontID is a valid system font or app font ID
	if ( !FntIsAppDefined(newFontID) ? (newFontID >= UINumSysFonts) :
			(newFontID-fntAppFontCustomBase >= UINumAppFonts) ) {
		ErrNonFatalDisplayIf(true, "Invalid font");
		newFontID = stdFont;
	}
	
	oldFontID = UICurrentFontID;
	UICurrentFontID = newFontID;
	
	// Set the new font or a default one.
	if ( FntIsAppDefined(newFontID) ) {
		UICurrentFontPtr = UIAppFontPtr[newFontID-fntAppFontCustomBase];
	} else {
		UICurrentFontPtr = UISysFontPtr[newFontID];
	}

	if (UICurrentFontPtr == NULL)
		UICurrentFontPtr = UISysFontPtr[stdFont];

	ErrNonFatalDisplayIf (UICurrentFontPtr == NULL, "Invalid font");
	
	return oldFontID;
}


/***********************************************************************
 *
 * FUNCTION:    FntGetFontPtr
 *
 * DESCRIPTION: This routine returns a pointer to the current font.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    FontPtr of the current font.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
FontPtr FntGetFontPtr (void)
{
	return (UICurrentFontPtr);
}


/***********************************************************************
 *
 * FUNCTION:    FntDefineFont
 *
 * DESCRIPTION: Define a font.  Only an app font may be defined.  The
 * application is responsible for freeing or releasing the font when
 * the application 
 *
 * PARAMETERS:  fontID - id of the font to define.  Should be a app defined
 * 							 font only.
 *					 fontP - Pointer to font to use.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/26/97	Initial Revision
 *			SCL	12/10/97	Rewrote to support new (separate) app font table
 *
 ***********************************************************************/
Err FntDefineFont (FontID fontID, FontPtr fontP)
{
	ULong				reqSize;
	FontTablePtr	tableP;
	Ptr				oldTableP;
	Err				err;
	FontID			appFontIndex;

	ErrNonFatalDisplayIf (!FntIsAppDefined(fontID), "App defined fonts only");
	
	appFontIndex = (FontID) (fontID - fntAppFontCustomBase);
	
	// See if there's room in the app font table for this font
	if (appFontIndex >= UINumAppFonts) {
	
		// if not, try to resize the table
		reqSize = (appFontIndex+1) * sizeof(FontPtr);
		err = MemPtrResize(UIAppFontTablePtr, reqSize);
		
		// If we couldn't resize it, try and reallocate it
		if (err) {
			tableP = MemPtrNew(reqSize);
			if (!tableP) return memErrNotEnoughSpace;
			MemSet(tableP, reqSize, 0);
			
			// Copy old table into new
			MemPtrSetOwner(tableP, 0);
			oldTableP = (Ptr)UIAppFontTablePtr;
			MemMove(tableP, oldTableP, reqSize);
			
			// Free old table and change global to point to new one
			UIAppFontTablePtr = tableP;
			MemPtrFree(oldTableP);
			}

		// Save the new table size
		UINumAppFonts = appFontIndex;
		}


	UIAppFontPtr[appFontIndex] = fontP;
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    FntProportionalFont
 *
 * DESCRIPTION: This function indicates whether the current font is
 *              proportionally spaced or fixed width.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    TRUE if the current font is proportionally 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
//Boolean FntProportionalFont (void)
//{
//	return (UICurrentFontPtr->pixelWidth == 0);
//}


/***********************************************************************
 *
 * FUNCTION:    FntBaseLine
 *
 * DESCRIPTION: This function returns the distance from the top of 
 *              character cell to the baseline for the current font.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    Baseline of the font, expressed in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
SWord FntBaseLine (void)
{
	return (UICurrentFontPtr->ascent);
}



/***********************************************************************
 *
 * FUNCTION:    FntCharHeight
 *
 * DESCRIPTION: This function returns the height of the characters in the 
 *              current font.  The value returns includes the height of
 *              character accents and descenders.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    Height of the characters in the current font, , expressed
 *              in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
SWord FntCharHeight (void)
{
	return (UICurrentFontPtr->fRectHeight);
}


/***********************************************************************
 *
 * FUNCTION:    FntLineHeight
 *
 * DESCRIPTION: This function returns the height of a line in the current
 *              font.  The height of a line is the height of the character
 *              cell plus the space between lines (the external leading).
 *
 * PARAMETERS:  none
 *
 * RETURNED:   The height of a line in the current font.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
SWord FntLineHeight (void)
{
	return (UICurrentFontPtr->fRectHeight + UICurrentFontPtr->leading);
}


/***********************************************************************
 *
 * FUNCTION:    FntAverageCharWidth
 *
 * DESCRIPTION: This function returns the average width of characters
 *              in the current font.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    The average width of characters in the current font, 
 *              expressed in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
SWord FntAverageCharWidth (void)
{
	return (UICurrentFontPtr->fRectWidth);
}


/***********************************************************************
 *
 * FUNCTION:    FntAccentHeight
 *
 * DESCRIPTION: This routine returns the height of an accent of the 
 *              characters in the current font.  The height of an accent
 *              is the distance between the top of the character cell and
 *              the top a non-accent capital letter.
 *
 * PARAMETERS:  none
 *
 * RETURNED:   Height of an accent, expressed in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
//short FntAccentHeight (void)
//{
//	return (UICurrentFontPtr->intLead);
//}


/***********************************************************************
 *
 * FUNCTION:    FntDescenderHeight
 *
 * DESCRIPTION: This routine returns the height of a decender of the 
 *              characters in the current font.  The height of a decender
 *              is the distance between the base line an the bottom
 *              of the character cell.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    Height of a decender, expressed in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
SWord FntDescenderHeight (void)
{
	return (UICurrentFontPtr->descent);
}


/***********************************************************************
 *
 * FUNCTION:    FntAscent
 *
 * DESCRIPTION: This routine returns the ascent of the characters in 
 *              the current font.  The ascent of a character is the 
 *              distance from the top of a non-accent capital letter
 *              to the base line.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    Ascent of the characters expressed in pixels.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *
 ***********************************************************************/
//short FntAscent (void)
//{
//return (UICurrentFontPtr->baseLine - UICurrentFontPtr->intLead);
//}


/***********************************************************************
 *
 * FUNCTION:    FntCharWidth
 *
 * DESCRIPTION: This routine returns the width of the specified character.
 *						If the specified character does not exist within the current
 *						font, the Missing Char Symbol will be substituted.
 *
 * PARAMETERS:  ch   character whose width is desired
 *
 * RETURNED:    width of the specified character, in pixels
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			kcr	11/7/95		returns values for Missing Char Symbol if nesc.
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
SWord FntCharWidth (const Char ch)
{
	Byte index;
	SByte width;	//<RM 10/9/97> changed to SByte so that comparison with missingChar works

	//	Is the character in range.
	if ((((unsigned char)ch) >= UICurrentFontPtr->firstChar) && 
		 (((unsigned char)ch) <= UICurrentFontPtr->lastChar))
		{
		index = (unsigned char) ch - UICurrentFontPtr->firstChar;

		width = ((FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
			UICurrentFontPtr->owTLoc + index)->width;
		if (width != missingChar) return (width);
		}
	
	//	Return the width of the Missing Char Symbol, which is located at index=last-first+1.
	index = UICurrentFontPtr->lastChar - UICurrentFontPtr->firstChar + 1;
	return ((FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
		UICurrentFontPtr->owTLoc + index)->width;

}


/***********************************************************************
 *
 * FUNCTION:    FntCharsWidth
 *
 * DESCRIPTION: This routine returns the width of the specified character
 *              string.  The Missing Character Symbol will be substituted for
 *						any char which does not exist in the current font.
 *
 * PARAMETERS:  pChars  pointer to a string of characters
 *              length  number of character in the string.
 *
 * RETURNED:    width of the string, in pixels
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			kcr	11/7/95		substitutes Missing Char Symbol for missing chars
 *
 ***********************************************************************/
SWord FntCharsWidth (const Char * pChars, Word length)
{
	FontCharInfoType * ptr;
	short width = 0;
	Word firstChar;
	Word lastChar;
	unsigned char ch;

	ErrNonFatalDisplayIf(length > 0 && pChars == NULL, "Null pChars");
	
	firstChar = UICurrentFontPtr->firstChar;
	lastChar = UICurrentFontPtr->lastChar;
	ptr = (FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
			UICurrentFontPtr->owTLoc;

	while (length)
		{
		ch = *pChars;
		if (ch >= firstChar && ch <= lastChar &&
			 ptr[ch - firstChar].width != missingChar)	//	char does not exist
			width += ptr[ch - firstChar].width;
		else	//	use width of Missing Char symbol
			width += ptr[lastChar - firstChar +1].width;

		pChars++;
		length--;
		}
	
	return (width);
}


/***********************************************************************
 *
 * FUNCTION:    FntCharsInWidth
 *
 * DESCRIPTION: Finds the number of characters in a string that fit
 * within a passed width.  Spaces at the end of a string are ignored and 
 * removed. Any chars after a carriage return are ignored and the string
 * is considered truncated.
 *
 * PARAMETERS:  string  			- pointer to the char string
 *              stringWidthP   	- maximum width to allow
 *              stringLengthP 	- maximum characters to allow
 *					 assumes current Font
 *
 * RETURNED:    stringWidthP  	- set to the width of the chars allowed
 *              stringLengthP 	- set to the number of chars within the width
 *              fitWithinWidth 	- whether the string is considered truncated
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/20/95	Initial Revision
 *			roger 12/4/95	Added fitWithinWidth to clear up function usage.
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
 
void	FntCharsInWidth(const Char * string, SWord *stringWidthP, 
	SWord *stringLengthP, Boolean *fitWithinWidth)
{
	Int width = 0;
	Int charWidth;
	Int length = 0;
	Int maxLength = *stringLengthP;
	Int maxWidth = *stringWidthP;
	Word firstChar;
	Word lastChar;
	unsigned char ch;
	const Char * s2;
	FontCharInfoType * info;


	ErrNonFatalDisplayIf(string == NULL, "Null string");
	ErrNonFatalDisplayIf(stringWidthP == NULL, "Null stringWidthP");
	ErrNonFatalDisplayIf(stringLengthP == NULL, "Null stringLengthP");
	ErrNonFatalDisplayIf(fitWithinWidth == NULL, "Null fitWithinWidth");
	
	firstChar = UICurrentFontPtr->firstChar;
	lastChar = UICurrentFontPtr->lastChar;
	info = (FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
			UICurrentFontPtr->owTLoc;

	
	while (*string != '\0' && *string != linefeedChr && length < maxLength)
		{
		// If the character exist, get its width, otherwise get the width
		// of the Missing Character symbol.
		ch = *string;

		if (ch >= firstChar && ch <= lastChar && 
				info[ch - firstChar].width != missingChar)
			charWidth = info[ch - firstChar].width;
		else	
			charWidth = info[lastChar - firstChar +1].width;

		if (width + charWidth <= maxWidth)
			{
			width += charWidth;
			length++;
			}
		else
			break;			// can't add any more characters.
			
		string++;
		}
		
	// string is the first character that didn't get included.  A '\0'
	// means the entire string fit, a linefeedChr means the string wrapped
	// (didn't fit), and anything else means the string was too wide.
	// Now, if the string is too wide because of blank characters, then
	// the string shouldn't considered to be truncated.  It's entire visible
	// contents does fit.
	

	// If the character we were adding was a whitespace and
	// all the characters until the end of the string are white spaces
	// then we don't consider the string truncated.
	if (length >= maxLength)		// used up all the characters
		*fitWithinWidth = true;
	else
	if (*string == linefeedChr)
		*fitWithinWidth = false;
	else
	if (*string == '\0')
		*fitWithinWidth = true;
	else
		{
		s2 = string;
		
		while (*s2 == ' ' || *s2 == tabChr)
			s2++;
		
		if (*s2 == '\0')
			*fitWithinWidth = true;
		else
			*fitWithinWidth = false;
		}
	

	// Visual optimization.  If the last char was unseen remove it.
	// Drawing it adds nothing of value.
	string--;
	while (length > 0 && 
		(*string == ' ' || *string == linefeedChr || *string == tabChr))
		{
		width -= FntCharWidth(*string);
		string--;
		length--;
		}


	*stringWidthP = width;
	*stringLengthP = length;
}


/***********************************************************************
 *
 * FUNCTION:    FntLineWidth
 *
 * DESCRIPTION: This routine returns the width of the specified line
 *              of text.  It takes tab characters in to account.  It is
 *					 assumed that the characters passed are left-align and
 *              that the fisrt character of the string is the first
 *              charater draw on a line.  In other words, this routine
 *              will not work for characters that start in a
 *              position other than the start of a line.
 *
 * PARAMETERS:	 pChars  pointer to a string of characters
 *              length  number of character in the string.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/20/95	Initial Revision
 *			kcr	11/7/95	handles missing chars
 *
 ***********************************************************************/
SWord FntLineWidth (const Char * pChars, Word length)
{
	FontCharInfoType * ptr;
	short width = 0;
	Word firstChar;
	Word lastChar;
	unsigned char ch;

	ErrNonFatalDisplayIf(length > 0 && pChars == NULL, "Null pChars");
	
	firstChar = UICurrentFontPtr->firstChar;
	lastChar = UICurrentFontPtr->lastChar;
	ptr = (FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
			UICurrentFontPtr->owTLoc;
			
	while (length)
		{
		ch = *pChars;
		if (ch == tabChr)
			// zzz calculate tab width base on the size of the font
			width += tabChrWidth - (width % tabChrWidth);

		else if (ch >= firstChar && ch <= lastChar &&
					ptr[ch - firstChar].width != missingChar)	//	char exists in font
			width += ptr[ch - firstChar].width;

		else	//	Use width of Missing Char Symbol
			width += ptr[lastChar - firstChar +1].width;

		pChars++;
		length--;
		}
	
	return (width);
}


/***********************************************************************
 *
 * FUNCTION:    FntWordWrap
 *
 * DESCRIPTION: Given a string, determine the number of characters that
 *               can be displayed within the specified width.
 *
 * PARAMETERS:	 chars       pointer to a null-terminated string
 *              maxWidth    maximum line width in pixels
 *
 * RETURNED:	 length of the line in characters
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/96		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word FntWordWrap (const Char * const chars, const Word maxWidth)
{
 	register Word length, lineWidth;
 	Word		breakLen;
	Byte   	ch;

	SByte		width; //<RM 10/9/97> changed to SByte so that comparison with missingChar works
	Byte		firstChar;
	Byte		lastChar;
	FontCharInfoType * charInfo;

	length = 0;
	breakLen = 0;
	lineWidth = 0;

	ErrNonFatalDisplayIf(chars == NULL, "Null chars");
	
	firstChar = UICurrentFontPtr->firstChar;
	lastChar = UICurrentFontPtr->lastChar;
	charInfo = ((FontCharInfoType *) (&UICurrentFontPtr->owTLoc) + 
			UICurrentFontPtr->owTLoc);
	
	
	while ((ch = chars[length]) != 0)
		{
		length++;

		//	Is the character in range.
		if ((ch >= firstChar) && (ch <= lastChar))
			{
			width = charInfo[ch - firstChar].width;
			//	If the character is missing return the width of the Missing Char Symbol, 
			// which is located at index=last-first+1.
			if (width == missingChar) 
				width = charInfo[lastChar - firstChar + 1].width;
			}
		else
			width = charInfo[lastChar - firstChar + 1].width;


		if ((ch == spaceChr) || (ch == tabChr))
			{
			if (lineWidth >=  maxWidth)
				{
				if (breakLen)
					length = breakLen;

				// Append trailing spaceChrs to the end of the line.
				while (chars[length] == spaceChr) length++;
				
				// Append trailing linefeed to the end of the line.
				if (chars[length] == linefeedChr) length++;
				
				return (length);
				}
			else
				breakLen = length;

			if (ch == spaceChr)
				lineWidth += width;
			else
				lineWidth += tabChrWidth - (lineWidth % tabChrWidth);
			}

		else if (ch == linefeedChr)
			{
			if (lineWidth > maxWidth && length > 1 && chars[length-2] != spaceChr)
				length = breakLen;
			return (length);
			}

		else 
			{
			lineWidth += width;

			if (lineWidth > maxWidth) 
				{
				if (breakLen)
					length = breakLen;
				else
					length--;
				return (length);;
				}
			}
		}
	return (length);
}


/***********************************************************************
 *
 * FUNCTION:    FntWordWrapReverseNLines
 *
 * DESCRIPTION: This routine word wraps a text string backwards by the 
 *              number of lines spacified.  The character position of the 
 *              start of the first line and the number of lines we actually
 *              word wraped are returned.
 *
 * PARAMETERS:	chars          - pointer to a null-terminated string
 *             maxWidth       - maximum line width in pixels
 *             linesToScrollP - passed: lines to scroll
 *                              returned: lines scrolled
 *             scrollPosP       passed: first character
 *                              returned: first character after wrapping
 *
 * RETURNED:	nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/18/96	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void FntWordWrapReverseNLines (const Char * const chars, const Word maxWidth, 
	const WordPtr linesToScrollP, const WordPtr scrollPosP)
{
	Word start;
	Word startOfLine;
	Word endOfPrevLine;
	Word lineStart;
	Word lineCount = 0;
 	Word linesToScroll;


	ErrNonFatalDisplayIf(chars == NULL, "Null chars");
	
	linesToScroll = *linesToScrollP;
	startOfLine = *scrollPosP;

   endOfPrevLine = startOfLine - 1;
	if (endOfPrevLine && chars[endOfPrevLine] == linefeedChr)
		endOfPrevLine--;

	// Find the first line that begins after after a linefeed and is at 
	// or before the line we wish to scroll to.
	do 
		{
		// Search backward for a linefeedChr.  If we find one, our staring
		// postion is the character after the linefeedChr, otherwise out 
		// starting position is the start of the field's text.
		if (FindReverseByte (chars, linefeedChr, endOfPrevLine, &start))
	      start++;					// skip over the linefeedChr
	    else
			start = 0;				// start of text string

		// Count the number of lines we move back through.
		lineStart = start;
		while (lineStart < startOfLine)
			{
     		lineCount++;
      	lineStart += FntWordWrap (&chars[lineStart], maxWidth);
			}

		if (start <= 1) 
			{
			// Is the first line a linefeed?
			if (start == 1)
				{
				start = 0;
				lineCount++;
				}
			break;
			}

		startOfLine = start;
	   endOfPrevLine = startOfLine - 2;		// move before linefeed	
		}
	while (lineCount < linesToScroll);

	// If we're moved back to many line, move foreward until we're at the 
	// correct line.
	while (lineCount > linesToScroll)
		{
      start += FntWordWrap (&chars[start], maxWidth);		
		lineCount--;
		}

	if (lineCount < linesToScroll)
		*linesToScrollP = lineCount;

	*scrollPosP = start;
}
	 

/***********************************************************************
 *
 * FUNCTION:    FntGetScrollValues
 *
 * DESCRIPTION: Given a string and a position within the sting this 
 *              routine returns the values necessary to update a 
 *              scroll bar.
 *
 * PARAMETERS:  chars     - null-terminated string
 *              width     - width to word wrap at, in pixels
 *              scrollPos - character position of the first visible character
 *              linesP    - (returned) number of lines of text
 *              topLineP  - (returned) top visible line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/7/96	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void FntGetScrollValues (const Char * const chars, const Word width, 
	const Word scrollPos, const WordPtr linesP, const WordPtr topLineP)
{
	Word length = 0;
	Word lines = 0;
	Word topLine = 0;
	
	ErrNonFatalDisplayIf(chars == NULL, "Null chars");
	
	if (*chars)
		{
		do {
			if (length <= scrollPos)
				topLine = lines;
			length += FntWordWrap (&chars[length], width);
			lines++;
			}
		while (chars[length]);
	
		// If the text end with a linefeed add one to the height.
		if (length && chars[length-1] == linefeedChr) 
			lines++;

		if (scrollPos && chars[scrollPos-1] == linefeedChr) 
			topLine++;
		}

	*topLineP = topLine;
	*linesP = lines;
}

