/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:	Pilot [EMULATOR]
 * FILE:		ScrUtils.c
 * AUTHOR:	Ron Marianetti
 *
 * DESCRIPTION:
 *			Screen driver utility functions for Pilot
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Created
 *
 **********************************************************************/

#include <Common.h>
#include <ScrDriver.h>



//======================================================================
// Private routines
//==========================================================================


						
 /***********************************************************************
 *
 * FUNCTION:	ScrCompressScanLine
 *
 * DESCRIPTION: Utility routine used by Screen driver in order to compress
 *		a scan line of a bitmap. Each scan-line is compressed as a sequence of 
 *		8 byte sections where each section starts with a byte of flags followed by
 *		up to 8 bytes of data. If a bit in the flags byte is clear, the byte is taken
 *		from the previous scan-line, else the byte is taken from the 0-8 bytes of data
 *		following the flags byte.
 *
 * bytes: 		   1  |       N                           | 1     |        N
 *            ----------------------------------------------------------------------
 *             flags | 1 byte for each bit set in flags  | flags | 
 *
 *	PARAMETERS:
 *		lineP 		- pointer to source scan line
 *		prevLineP 	- pointer to previous source scan line
 *		width 		- width of source scan line in bytes.
 *		dstP 			- pointer to space for compressed data. 
 *		firstLine 	- true if this is the first scan line.
 *
 * RETURNED:	# of bytes placed in dstP.
 *
 * CALLED BY:
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
UInt ScrCompressScanLine(BytePtr lineP, BytePtr prevLineP, UInt width, BytePtr dstParamP,
					Boolean firstLine)
{
	Byte		data;
	Byte		flags;
	Int		bitNo=-1;
	BytePtr	flagsP;
	BytePtr	dstP = dstParamP;
	
	
	// Loop through each byte in the source scan line	
	do {
		// If starting a new sequence write out place holder for flags field.
		if (bitNo<0) {
			flags = 0;
			bitNo = 7;
			
			// Remember location of flags and write out null byte for now
			flagsP = dstP;
			dstP++;
			}
			
		// Get next byte of source
		data = *lineP++;
		
		// If this byte is not equal, set bit in flags and write out data
		if (firstLine  ||  (data != *prevLineP++)) {
			flags |= 0x01;
			*dstP++ = data;
			}			
			
		// If we've finished a sequence of 8 bytes, write out flags
		if (bitNo == 0) 
			*flagsP = flags;
			
			
		// On to next bit in flags
		flags <<= 1;
		bitNo--;
		} while(--width);
		
		
	// If we didn't finish all 8 bytes in the sequence, put in 0's for the rest of
	//  the flags
	if (bitNo >= 0) {
		if (bitNo) flags <<= bitNo;
		*flagsP = flags;
		}
		
		
	// Return # of bytes in compressed scan line
	return (dstP - dstParamP);
}






 /***********************************************************************
 *
 * FUNCTION:	ScrDeCompressScanLine
 *
 * DESCRIPTION: Utility routine used by Screen driver in order to decompress
 *		a scan line of a bitmap. 
 *
 *	PARAMETERS:
 *		src 	- pointer to source compressed scan line
 *		dstP -  where uncompressed scan line goes, contains previous line of pixels.
 *		width - width of uncompressed scan line in bytes.
 *		firstLine - true if this is the first line of the bitmap
 *
 * RETURNED:	# of bytes of compressed data used up
 *
 * CALLED BY:
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
UInt ScrDeCompressScanLine(BytePtr srcParamP, BytePtr dstP, UInt width)
{
	Byte	flags;
	Int	bitNo = -1;
	BytePtr	srcP = srcParamP;
	
	do {
		// Get flags byte
		if (bitNo < 0) {
			flags = *srcP++;
			bitNo = 7;
			}
			
		// Decompress next byte
		if (flags & 0x80) 
			*dstP++ = *srcP++;
		else
			dstP++;
			
		// Next bit in flags
		flags <<= 1;
		bitNo--;
	
		} while(--width);
	

	// Return # of bytes we used up in source
	return (srcP - srcParamP);
}




