/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     control.h
 * AUTHOR:	 Roger Flores: October 28, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain control object routines.
 *
 **********************************************************************/
#include <Pilot.h>

#define popupIndicatorGap				5
#define popupIndicatorWidth			7
#define popupIndicatorHeight			((popupIndicatorWidth+1)/2)
#define horizontalSpace					3

#define minButtonWidth					36

// ticks (1/60 s) between repeat ctlRepeatEvents
#define firstControlRepeatInterval	30
#define controlRepeatInterval			9

// These routines WERE placed in the beginning to avoid declaring them.
// However, doing so now makes CtlHandleEvent unreachable from ROMInstallUI1.c!
// So, we get to declare them after all...  :-)
static FrameType ButtonFrameToFrameType (ControlPtr pControl);
static void InvertControl (ControlPtr pControl);
static void DrawIndicator (short x, short y);


/***********************************************************************
 *
 * FUNCTION: 	 CtlDrawControl
 *
 * DESCRIPTION: Draw a control object on screen.
 *					 The control is drawn only if it is usable.
 *
 * PARAMETERS:  pControl     - pointer to control object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlDrawControl (const ControlPtr pControl)
	{
	short				drawX, drawY;
	short				textLen;
	RectangleType	r, clip, saveClip;
	FrameType 		frame;
	char				ch;
	FontID			currFont;


	if (pControl->attr.usable)
		{
		pControl->attr.visible = true;
		RctCopyRectangle (&(pControl->bounds), &r);
// art	WinEraseRectangle (&pControl->bounds, 0);
		if (pControl->text)
			textLen = StrLen (pControl->text);
		else
			textLen = 0;
			

		// Set to the appropriate font
		if (pControl->style == checkboxCtl)
			currFont = FntSetFont (checkboxFont);
		else
			currFont = FntSetFont (pControl->font);


		// Draw the frame around the bounds.  Do this now before
		// we restrict the clipping to the control's bounds.
		if (pControl->style != selectorTriggerCtl)
			{
			if ((frame = ButtonFrameToFrameType(pControl)) != noFrame)
				WinDrawRectangleFrame (frame, &(pControl->bounds));
			}
		else
			WinDrawGrayRectangleFrame (simpleFrame, &(pControl->bounds));


		// Restrict the clipping to the control's bounds.
		WinGetClip (&saveClip);
		RctCopyRectangle (&r, &clip);
		WinClipRectangle (&clip);
		WinSetClip (&clip);


		// Calculate where to draw the text horizontally.
		switch (pControl->style)
			{
			case buttonCtl:
			case repeatingButtonCtl:
			case pushButtonCtl:
				// center text string horizontally
				drawX = r.topLeft.x + ((r.extent.x -
					FntCharsWidth (pControl->text, textLen) + 1) / 2);
					
				// Special erase for the inversion case.  This 
				// causes some flash.  The way to remove the flash
				// is to have the ability to draw text COMPLETELY
				// inverted, i.e. the background color is inverted
				// too.  This currently isn't possible.
				if (pControl->attr.on && textLen)
					WinEraseRectangle (&pControl->bounds, 0);
				break;
			case checkboxCtl:
				// decide which char to use now so we can include it
				// in the drawX calculation.
				if (pControl->attr.on)
					ch = symbolCheckboxOn;
				else
					ch = symbolCheckboxOff;
				// The checkbox is drawn first.  Then drawX is incremented to
				// where the text is to be drawn
				drawX = r.topLeft.x;
				break;
			default:        // popupTrigger and selectorTrigger
				drawX = r.topLeft.x + horizontalSpace;
			}


		// draw the checkbox
		if (pControl->style == checkboxCtl)
			{
			drawY = r.topLeft.y + ((r.extent.y - FntCharHeight ()) / 2);
			WinDrawChars (&ch, 1, drawX, drawY);
			drawX += FntCharWidth(ch) + popupIndicatorGap;
			FntSetFont (pControl->font);
			}

		// draw the popup trigger
		else if (pControl->style == popupTriggerCtl)
			{
			DrawIndicator (drawX, 
					r.topLeft.y + (r.extent.y - popupIndicatorHeight + 1) / 2);
			drawX += popupIndicatorWidth + popupIndicatorGap;
			}
		
		
		// Draw the control's text at (drawX, drawY)
		drawY = r.topLeft.y + ((r.extent.y - FntBaseLine() + 
			FntDescenderHeight()) / 2) - FntDescenderHeight();
		WinDrawChars (pControl->text, textLen, drawX, drawY);


		if (pControl->attr.on && pControl->style != checkboxCtl)
			InvertControl(pControl);

		WinSetClip (&saveClip);
		FntSetFont (currFont);
		}
	}


/***********************************************************************
 *
 * FUNCTION: CtlEraseControl
 *
 * DESCRIPTION: 
 *
 * PARAMETERS:	
 *
 * RETURNED:	
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/29/94		Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlEraseControl (const ControlPtr pControl)
	{
	RectangleType	r;
	FrameBitsType  frame;


	if (pControl->attr.usable && pControl->attr.visible)
		{
		if (pControl->style == checkboxCtl ||
			 (pControl->attr.frame == noButtonFrame &&
			  pControl->style != selectorTriggerCtl))
			{
			WinEraseRectangle (&pControl->bounds, 0);
			}
		else
			{
			frame.word = ButtonFrameToFrameType(pControl);
			WinGetFramesRectangle(frame.word, &pControl->bounds, &r);
			WinEraseRectangle (&r, frame.bits.cornerDiam);
			}
		pControl->attr.visible = false;
		}
	}


/***********************************************************************
 *
 * FUNCTION:    CtlShowControl
 *
 * DESCRIPTION: Set a control usable and draw it.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlShowControl (const ControlPtr pControl)
	{
	pControl->attr.usable = true;
	CtlDrawControl (pControl);
	}


/***********************************************************************
 *
 * FUNCTION:    CtlHideControl
 *
 * DESCRIPTION: Set a control not usable and erase it.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlHideControl (const ControlPtr pControl)
	{
	CtlEraseControl (pControl);
	pControl->attr.usable = false;
	}



/***********************************************************************
 *
 * FUNCTION:    CtlSetUsable
 *
 * DESCRIPTION: Set a control usable or not usable
 *
 * PARAMETERS:	 pControl - pointer to control object
 *              usable   - true to set usable, false to set not usable.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/5/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlSetUsable (const ControlPtr pControl, const Boolean usable)
	{
	pControl->attr.usable = usable;
	}

/***********************************************************************
 *
 * FUNCTION:    CtlEnabled
 *
 * DESCRIPTION: REturns true if the control is enabled.  Disabled controls
 *              do not responed to the pen.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *
 * RETURNED:	 true if enable, false if not usable.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean CtlEnabled (const ControlPtr pControl)
	{
	return (pControl->attr.enabled);
	}


/***********************************************************************
 *
 * FUNCTION:    CtlSetEnabled
 *
 * DESCRIPTION: Set a control enabled or disabled.  Disabled controls
 *              do not responed to the pen.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *              enable  - true to set enable, false to set not usable.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/13/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlSetEnabled (const ControlPtr pControl, const Boolean enable)
	{
	pControl->attr.enabled = enable;
	}


/***********************************************************************
 *
 * FUNCTION:    CtlGetValue
 *
 * DESCRIPTION: Return the current value of the specified control.
 *
 * PARAMETERS:  pControl - pointer to control object
 *
 * RETURNED:	 The cuurent value of the control, 0=off, 1=on.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
SWord CtlGetValue (const ControlPtr pControl)
	{
   return pControl->attr.on;
	}


/***********************************************************************
 *
 * FUNCTION:    CtlSetValue
 *
 * DESCRIPTION: Set the current value of the specified control.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *              newValue  - 0=off, non-zero=on
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlSetValue (const ControlPtr pControl, const SWord newValue)
	{
	SWord value;
	
	if (newValue)
		value = 1;
	else
		value = 0;
	if (pControl->attr.visible && pControl->attr.on != value)
		{
		InvertControl (pControl);
		}
	pControl->attr.on = value;
	}


/***********************************************************************
 *
 * FUNCTION:    CtlGetLabel
 *
 * DESCRIPTION: Return a string pointer to the control's text label.
 *
 * PARAMETERS:  pControl - pointer to control object
 *
 * RETURNED:	 The cuurent label of the control.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
CharPtr CtlGetLabel (const ControlPtr pControl)
	{
   return pControl->text;
	}


/***********************************************************************
 *
 * FUNCTION:    CtlSetLabel
 *
 * DESCRIPTION: Set the current label of the specified control.
 *
 * PARAMETERS:	 pControl - pointer to control object
 *              newLabel - pointer to new text label
 *
 * RETURNED:	 nothing
 *
 * NOTE:        Any changes made to this routine that results in a 
 *              different calculation of the bounds of the control
 *              must also be made to the resource builder.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlSetLabel (const ControlPtr pControl, const CharPtr newLabel)
	{
	short 	width;
	FontID	currFont;
	RectangleType	r;

	pControl->text = newLabel;

	if (pControl->style == popupTriggerCtl ||
		 pControl->style == selectorTriggerCtl ||
		 pControl->style == checkboxCtl)
		{
		currFont = FntSetFont (pControl->font);
		// Don't include the blank column in the last letter
		if (newLabel)
			width = FntCharsWidth(newLabel, StrLen(newLabel)) - 1;
		else
			width = 0;

		// If the control is a selector, round the width up to and odd
		// value so that the corners of the gray frame draw properly.
		if (pControl->style == selectorTriggerCtl)
			width = (width + (2 * horizontalSpace -1)) | 1;
			
		if (pControl->style == popupTriggerCtl)
			width += (2 * horizontalSpace) + popupIndicatorWidth + 
				popupIndicatorGap;

		if (pControl->style == checkboxCtl)
			{
			FntSetFont (checkboxFont);
			width += horizontalSpace + FntCharWidth(symbolCheckboxOn) + 
				popupIndicatorGap;
			}

		if (pControl->attr.leftAnchor)
			{
			// if the width shrinks record the area no longer
			// part of the control.
			RctCopyRectangle (&(pControl->bounds), &r);
			r.topLeft.x += (width - horizontalSpace);
			r.extent.x -= (width - horizontalSpace);
			
			pControl->bounds.extent.x = width;
			}
		else
			{
			// if the width shrinks record the area no longer
			// part of the control.
			RctCopyRectangle (&(pControl->bounds), &r);
			// We also want to erase the popupIndicator and the
			// popupIndicatorGap incase the label is smaller
			r.extent.x -= (width - horizontalSpace - popupIndicatorWidth -
				popupIndicatorGap);

			pControl->bounds.topLeft.x = pControl->bounds.topLeft.x +
				pControl->bounds.extent.x - width;
			pControl->bounds.extent.x = width;
			}
		FntSetFont (currFont);
		}
	else
		{
		// For all other types of buttons set r
		// Unoptimized way to insure the old text of a push button is cleared.
		RctCopyRectangle (&(pControl->bounds), &r);

		if (pControl->attr.usable && pControl->attr.visible)
			WinEraseRectangle (&r, 0);
		}
		


	if (pControl->attr.usable && pControl->attr.visible)
		{
		// erase the area no longer part of the control (because the
		// CtlDrawControl can't).
		if (r.extent.x > 0)
			{
			// If the control is a selector erase the frame as well
			if (pControl->style == selectorTriggerCtl)
				{
				r.topLeft.x--;
				r.topLeft.y--;
				r.extent.x += 2;
				r.extent.y += 2;
				}
				
			WinEraseRectangle (&r, 0);
			}
		CtlDrawControl (pControl);
		}
	}

/***********************************************************************
 *
 * FUNCTION:    CtlHitControl
 *
 * DESCRIPTION: This routine simulates the pressing of a control.
 *
 * PARAMETERS:  pControl - pointer to control object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CtlHitControl (const ControlPtr pControl)
{
	EventType event;
	
	MemSet (&event,sizeof (EventType), 0);
	
	event.eType = ctlSelectEvent;
	event.penDown = false;
	event.screenX = pControl->bounds.topLeft.x + (pControl->bounds.extent.x / 2);
	event.screenY = pControl->bounds.topLeft.y + (pControl->bounds.extent.y / 2);
	event.data.ctlSelect.controlID = pControl->id;
	event.data.ctlSelect.pControl = pControl;
	event.data.ctlSelect.on = false;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    CtlValidatePointer
 *
 * DESCRIPTION: Validate a control pointer. 
 *
 * PARAMETERS:  pControl  pointer of a control
 *
 * RETURNED:    true if the pointer is ok
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
Boolean CtlValidatePointer (const ControlPtr pControl)
{
	ErrFatalDisplayIf(pControl == NULL, "NULL control");
	
	if (MemPtrSize(pControl) < sizeof(ControlType))
		goto badControl;
	
	if (pControl->attr.frame > rectangleButtonFrame)
		goto badControl;
		
	if (pControl->style > repeatingButtonCtl)
		goto badControl;
	 
	return true;

badControl:
	ErrNonFatalDisplayIf(true, "Bad Control");
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    CtlNewControl
 *
 * DESCRIPTION: Create a control. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 controlID - ID of the new control
 *					 style - style of the new control
 *					 textP - string for the new control.  Copied after the control.
 *					 x - x of the new control
 *					 y - y of the new control
 *					 width - width of the new control.  Zero means to calc a default.
 *					 height - height of the new control.  Zero means to calc a default.
 *					 font - font of the new control
 *					 group - group of the new control
 *					 leftAnchor - true if the control is anchored left.  Affects resizing.
 *
 * RETURNED:    0 if error else a pointer to the control
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
ControlPtr CtlNewControl (VoidPtr *formPP, const Word ID, const ControlStyleType style, 
	const CharPtr textP, 
	const Word x, const Word y, const Word width, const Word height, 
	const FontID font, Byte group, Boolean leftAnchor)
{
	UInt size;
	ControlPtr controlP;
	Err error;
	FontID currFont;
	
	
	size = sizeof(ControlType);
	if (textP)
		size += StrLen(textP) + sizeofchar(nullChr);
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)controlP, frmControlObj, size);
	if (error)
		return 0;
	
	controlP->id = ID;
	controlP->style = style;
	switch (style)
		{
		case buttonCtl:
		case pushButtonCtl:
			controlP->attr.frame = standardButtonFrame;
		}
	controlP->bounds.topLeft.x = x;
	controlP->bounds.topLeft.y = y;
	
	controlP->attr.usable = true;
	controlP->attr.leftAnchor = leftAnchor;
	controlP->attr.enabled = true;
	controlP->font = font;
	controlP->group = group;
	
	if (width)
		controlP->bounds.extent.x = width;
	else if (textP)
		{
		// Size the control to fit the label.
		CtlSetLabel (controlP, textP);
		if (controlP->bounds.extent.x == 0)
			{
			controlP->bounds.extent.x = FntCharsWidth(textP, StrLen(textP)) - 1 + 
				2 * (horizontalSpace + 2);
			controlP->bounds.extent.x = max(controlP->bounds.extent.x, minButtonWidth);
			}
		}
	
	if (height)
		controlP->bounds.extent.y = height;
	else
		{
		currFont = FntSetFont (font);
		controlP->bounds.extent.y = FntLineHeight() + 2;
		FntSetFont (currFont);
		}
	
	if (textP)
		{
		controlP->text = (CharPtr) (controlP + 1);
		StrCopy(controlP->text, textP);
		}
	
	return controlP;
}


/***********************************************************************
 *
 * FUNCTION:    CtlHandleEvent
 *
 * DESCRIPTION: Handle event in the specified control.  This routine
 *              handles two type of events, penDownEvents and
 *              controlEnterEvent.
 *
 *              When this routine receives a penDownEvents it checks
 *              if the pen position is within the bounds of the
 *              control object, if it is a ctlEnterEvent is
 *              added to the event queue and the routine exits.
 *
 *              When this routine receives a ctlEnterEvent it
 *              checks that the control id in the event record match
 *              the id of the control specified, if they match
 *              this routine will track the pen until it comes up
 *              in the bounds in which case ctlSelectEvent is sent.
 *              If the pen exits the bounds a ctlExitEvent is sent.
 *
 *
 * PARAMETERS:	 pControl - pointer to control object (ControlType)
 *              pEvent    - pointer to an EventType structure.
 *
 * RETURNED:	TRUE if the event was handle or FALSE if it was not.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean CtlHandleEvent (const ControlPtr pControl, const EventPtr pEvent)
	{
	EventType	newEvent;
	Boolean		penDown;
	Boolean		hilighted;
	short			x, y;
	RectangleType	frameBounds;

	if ( (! pControl->attr.usable) ||
		  (! pControl->attr.visible) ||
		  (! pControl->attr.enabled) )
		return (false);

	WinGetFramesRectangle(ButtonFrameToFrameType(pControl), &pControl->bounds,
		&frameBounds);

	switch (pEvent->eType)
		{
		case penDownEvent:
			if (RctPtInRectangle (pEvent->screenX, pEvent->screenY,
								  &frameBounds))
				{
				EvtCopyEvent (pEvent, &newEvent);
				newEvent.eType = ctlEnterEvent;
				newEvent.data.ctlEnter.controlID = pControl->id;
				newEvent.data.ctlEnter.pControl = pControl;
				newEvent.screenX = pEvent->screenX;
				newEvent.screenY = pEvent->screenY;
				EvtAddEventToQueue (&newEvent);
				return true;
				}
			break;

		case ctlEnterEvent:
				InvertControl(pControl);
				// fall through to ctlRepeatEvent
				
		case ctlRepeatEvent:
			if (pEvent->data.ctlEnter.controlID == pControl->id)
				{
				hilighted	= true;
				penDown		= true;

				// We are going to send an event.  Fill in common info here.
				newEvent.data.ctlSelect.controlID = pControl->id;
				newEvent.data.ctlSelect.pControl = pControl;

				do
					{
					PenGetPoint (&x, &y, &penDown);
					if (RctPtInRectangle (x, y, &frameBounds))
						{
						if (penDown)
							{
							if (!hilighted)
								{
								hilighted = true;

								// Draw the inverse of what's there as if it's activated.
								InvertControl (pControl);
								
								// If we were outside the bounds reset the 
								// repeat timer to right now
								pEvent->data.ctlRepeat.time = TimGetTicks();
								}
							// If this is a repeating control and this is the first
							// press or a press after a long enough time interval
							// then send a ctlRepeatEvent
							if (pControl->style == repeatingButtonCtl &&
								(pEvent->eType == ctlEnterEvent ||
									((TimGetTicks() > pEvent->data.ctlRepeat.time) &&
										((TimGetTicks() - pEvent->data.ctlRepeat.time) >= controlRepeatInterval))))
								{
								newEvent.eType = ctlRepeatEvent;
								newEvent.penDown = penDown;
								newEvent.screenX = x;
								newEvent.screenY = y;
								// The first repeat time is longer than the rest
								// Operates like a repeating keyboard
								newEvent.data.ctlRepeat.time = TimGetTicks();
								if (pEvent->eType == ctlEnterEvent)
									newEvent.data.ctlRepeat.time += 
										(firstControlRepeatInterval - controlRepeatInterval);
								EvtAddEventToQueue (&newEvent);
								
								SndPlaySystemSound(sndClick);

								return true;
								}
								
							}
						else /* pen is up */
							{
							if (pControl->style == checkboxCtl ||
								 pControl->style == pushButtonCtl)
								{
								// Didn't use CtlSetValue to avoid redraw.
								pControl->attr.on = ~pControl->attr.on;
								}
							else
								InvertControl (pControl);

							// repeatingButtonCtl never send a ctlSelectEvent
							// They do not send anything when the button is released
							if (pControl->style != repeatingButtonCtl)
								{
								newEvent.eType = ctlSelectEvent;
								newEvent.penDown = penDown;
								newEvent.screenX = x;
								newEvent.screenY = y;
								newEvent.data.ctlSelect.on = pControl->attr.on;
								EvtAddEventToQueue (&newEvent);
								
								SndPlaySystemSound(sndClick);
	
								return true;
								}
							}
						}
					else /* moved out of rectangle */
						{
						if (hilighted)
							{
							hilighted = false;
							// Trick to revert
							if (pControl->style == checkboxCtl)
								pControl->attr.on = ~pControl->attr.on;
							InvertControl (pControl);
							// Undo trick
							if (pControl->style == checkboxCtl)
								pControl->attr.on = ~pControl->attr.on;
							}

						// The user did not select the control.
						if (!penDown)
							{
							newEvent.eType = ctlExitEvent;
							newEvent.penDown = penDown;
							newEvent.screenX = x;
							newEvent.screenY = y;
							EvtAddEventToQueue (&newEvent);
							}
						}
					} while (penDown);

				}
			break;
		}

	return false;

	}



/***********************************************************************
 *
 * FUNCTION:    ButtonFrameToFrameType
 *
 * DESCRIPTION: Return a frame type.
 *					 Selector triggers are handled specially to return a
 *					 rectangleFrame since there isn't a gray frame type.
 *
 * PARAMETERS:  pControl     - pointer to control object to with frame
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/1/94	Initial Revision
 *
 ***********************************************************************/

static FrameType ButtonFrameToFrameType (ControlPtr pControl)
	{
		switch (pControl->style)
			{
			case buttonCtl:
			case repeatingButtonCtl:
				switch (pControl->attr.frame)
					{
					case standardButtonFrame:
						return roundFrame;
					case boldButtonFrame:
						return boldRoundFrame;
					case rectangleButtonFrame:
						return simpleFrame;
					}
				return noFrame;
			case pushButtonCtl:
				return rectangleFrame;
			case selectorTriggerCtl:
				return rectangleFrame;
			}
		return noFrame;
	}


/***********************************************************************
 *
 * FUNCTION:
 *
 * DESCRIPTION: Invert the control.
 * 				 This routine flips between two visual states.
 *					 Calling the routine twice leaves the visual state
 *					 identical to the starting state for all control
 *					 styles except checkboxCtl.  For that style you may
 *					 wish to temporarily fiddle with the on attribute.
 *
 * PARAMETERS:  pControl     - pointer to control object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *
 ***********************************************************************/


static void InvertControl (ControlPtr pControl)
   {
	short  drawX, drawY;
	char   ch;
	FontID currFont;
	FrameBitsType frame;

	switch (pControl->style)
		{
		case checkboxCtl:
			if (pControl->attr.on)
				ch = symbolCheckboxOff;
			else
				ch = symbolCheckboxOn;
			currFont = FntSetFont (checkboxFont);
			drawX = pControl->bounds.topLeft.x;
			drawY = pControl->bounds.topLeft.y +
				((pControl->bounds.extent.y - FntCharHeight ()) / 2);

			WinDrawChars (&ch, 1, drawX, drawY);
			FntSetFont (currFont);
			break;

		case buttonCtl:
		case repeatingButtonCtl:
			frame.word = ButtonFrameToFrameType (pControl);
			WinInvertRectangle (&pControl->bounds, frame.bits.cornerDiam);
			break;

		default:
			  WinInvertRectangle (&pControl->bounds, 0);
			  break;
		}
	}


/***********************************************************************
 *
 * FUNCTION:    DrawIndicator
 *
 * DESCRIPTION: Draw the selector trigger indicator.
 *					 The indicator normally indicates the presence of a
 *					 popup list.
 *
 * PARAMETERS:  x, y - top left corner of the indicator
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *
 ***********************************************************************/

static void DrawIndicator (short x, short y)
	{
		short i;

		for (i = popupIndicatorWidth; i > 0; i-=2)
			{
			WinDrawLine (x, y, x+i, y);
			x++;
			y++;
			}
	}
