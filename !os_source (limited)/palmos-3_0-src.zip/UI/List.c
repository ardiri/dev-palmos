/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     list.h
 * AUTHOR:	 Roger Flores: November 3, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain the list object routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>

extern Short LstPopupListWithScrollBar (ListPtr pList);


#define lstScrollBarWidth			7

#define lstPopupIndicatorOffset	12
#define maxVisiblePopupItems  	5
#define scrollIndicatorWidth		9
#define scrollIndicatorHeight    9
#define scrollUpIndicator  		symbolSmallUpArrow
#define scrollDownIndicator   	symbolSmallDownArrow
#define listFrame 					rectangleFrame
#define textInsetWidth				2

// define default values for list scroll rate
#define listScrollMinDelay     0
#define listScrollInitDelay    21
#define listScrollAcceleration 3


#define VisibleItems(l)        (min((l->bounds.extent.y / FntLineHeight()), l->numItems))
#define LastVisibleItem(l)     (l->topItem + VisibleItems(l) - 1)
#define LastItem(l)            (l->numItems - 1)
#define ListScrolledToTop(l)   (l->topItem == 0)
#define ListScrolledToBottom(l) (LastItem(l) == LastVisibleItem(l))


// Maximium length of the incremental search buffer.
#define maxListLookupLen		5


/***********************************************************************
 *
 *	Internal functions
 *
 ***********************************************************************/
Boolean PtAboveRect (short x, short y, RectangleType *r);
Boolean PtBelowRect (short x, short y, RectangleType *r);


/***********************************************************************
 *
 * FUNCTION:    ItemIsVisible
 *
 * DESCRIPTION: Return true if the item is visible.
 *
 * PARAMETERS:	 pList         - pointer to list object
 *              i					- item number
 *
 * RETURNED:	 true if the item is one of the visible items.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/

static Boolean ItemIsVisible (ListPtr pList, short i)
{
  return i >= pList->topItem &&
			i <= LastVisibleItem(pList);
}


/***********************************************************************
 *
 * FUNCTION:    GetBounds
 *
 * DESCRIPTION: Copy the bounds of an item from a list to a rectangle.
 *
 * PARAMETERS:	 bounds			- rectangle into which are placed the bounds
 *					 pList         - pointer to list object
 *              i					- item number
 *
 * RETURNED:	 bounds is filled in.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/
static void GetBounds (RectanglePtr bounds, ListPtr pList, short i)
{
	bounds->extent.x = pList->bounds.extent.x;
	bounds->extent.y = FntLineHeight ();
	bounds->topLeft.x = pList->bounds.topLeft.x;
	bounds->topLeft.y = pList->bounds.topLeft.y + i * bounds->extent.y;
}


/***********************************************************************
 *
 * FUNCTION:    LstGetVisibleItems
 *
 * DESCRIPTION: Return the number of items visible.
 *
 * PARAMETERS:	 pList         - pointer to list object
 *
 * RETURNED:	 the number of items visible
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/4/96	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Int LstGetVisibleItems (const ListPtr pList)
{
	Int visibleItems;
	FontID currFont;
	

	currFont = FntSetFont (pList->font);
	
	visibleItems = VisibleItems(pList);
	
	FntSetFont (currFont);
	
	return visibleItems;
}


/*-----------------------------------------------------------*/
/*                        DrawItem                           */
/*-----------------------------------------------------------*/
static void DrawItem (ListPtr pList, Word itemNum)
{
	short y;
	CharPtr text;

	{
	y = (itemNum - pList->topItem) * FntLineHeight ();
	text = pList->itemsText[itemNum];
	WinDrawChars (text, StrLen(text), pList->bounds.topLeft.x + textInsetWidth,
		pList->bounds.topLeft.y + y);
	}
}


/***********************************************************************
 *
 * FUNCTION:    EraseInsideListBounds
 *
 * DESCRIPTION: Sometimes the list erases within it's visual bounds
 * to prevent the border from flickering or to clear item data before
 * LstDrawList is called.
 *
 * PARAMETERS:	 list       - pointer to list object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/25/95	Initial Revision
 *
 ***********************************************************************/
static void EraseInsideListBounds(ListPtr pList)
	{
	RectangleType bounds;


	// If the list is visible erase the list items but not the
	// list bounds.  This is an optimation to keep the list bounds
	// from visually flickering.
	if (pList->attr.usable && pList->attr.visible)
		{
		RctCopyRectangle (&pList->bounds, &bounds);
		WinEraseRectangle(&bounds, 0);
		}

	pList->attr.visible = false;
	}


/***********************************************************************
 *
 * FUNCTION:    InvertCurrentSelection
 *
 * DESCRIPTION: Invert the current selection if visible.
 *
 * PARAMETERS:	 list          - pointer to list object
 *
 * RETURNED:	 true if inverted
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/
static Boolean InvertCurrentSelection (ListPtr pList)
	{
	RectangleType bounds;


	if (pList->currentItem != noListSelection &&
		 ItemIsVisible(pList, pList->currentItem))
		{
		GetBounds (&bounds, pList, pList->currentItem - pList->topItem);
		WinInvertRectangle (&bounds, 0);
		return true;
		}

	return false;
  }


/***********************************************************************
 *
 * FUNCTION:    InvertScrollUpIndicator
 *
 * DESCRIPTION: Invert the scroll up indicator.
 *
 * PARAMETERS:	 pList         - pointer to list object
 *					 eraseArea		- true if the area behind the 
 *										  indicator needs erasing
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/

static void InvertScrollUpIndicator (ListPtr pList, Boolean eraseArea)
	{
	char ch;
	FontID			currFont;
	RectangleType	r;
	SWord				x;
	SWord				y;
	

	if (pList->attr.hasScrollBar)
		return;

	if (!ListScrolledToTop(pList))
		{
		currFont = FntSetFont (symbolFont);
		ch = scrollUpIndicator;
		x = pList->bounds.topLeft.x + pList->bounds.extent.x - scrollIndicatorWidth - 1;
		y = pList->bounds.topLeft.y + 1;
		if (eraseArea)
			{
			r.topLeft.x = x + 1;		// don't know why we need the + 1 but we do
			r.topLeft.y = y;
			r.extent.x = scrollIndicatorWidth;
			r.extent.y = scrollIndicatorHeight;
			WinEraseRectangle(&r, 0);
			}
		WinInvertChars (&ch, 1, x, y);
		FntSetFont (currFont);
		}
	}


/***********************************************************************
 *
 * FUNCTION:    InvertScrollDownIndicator
 *
 * DESCRIPTION: Invert the scroll up indicator.
 *
 * PARAMETERS:	 pList         - pointer to list object
 *					 eraseArea		- true if the area behind the 
 *										  indicator needs erasing
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/
static void InvertScrollDownIndicator (ListPtr pList, Boolean eraseArea)
	{
	char ch;
	FontID			currFont;
	RectangleType	r;
	SWord				x;
	SWord				y;

	if (pList->attr.hasScrollBar)
		return;

	if (!ListScrolledToBottom(pList))
		{
		currFont = FntSetFont (symbolFont);
		ch = scrollDownIndicator;
		x = pList->bounds.topLeft.x + pList->bounds.extent.x - scrollIndicatorWidth - 1;
		y = pList->bounds.topLeft.y + pList->bounds.extent.y - scrollIndicatorHeight - 1;
		if (eraseArea)
			{
			r.topLeft.x = x + 1;		// don't know why we need the + 1 but we do
			r.topLeft.y = y;
			r.extent.x = scrollIndicatorWidth;
			r.extent.y = scrollIndicatorHeight;
			WinEraseRectangle(&r, 0);
			}
		WinInvertChars (&ch, 1, x, y);
		FntSetFont (currFont);
      }
   }


/************************************************************
 *
 *  FUNCTION: PartialCaselessCompare
 *
 *  DESCRIPTION: Compares two strings with case and accent insensitivity.
 *               If all of s1 is matches all or part of s1 then the
 *               there is a match
 *
 *  PARAMETERS: 2 string pointers
 *
 *  RETURNS: 0 if they match, non-zero if not
 *
 *  REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/4/96	Initial Revision
 *
 *************************************************************/
static Int PartialCaselessCompare (CharPtr s1, CharPtr s2)
{
	Byte	c1, c2;
	Int result;
	BytePtr	tableP;

	// Check for err
	ErrFatalDisplayIf(s1 == NULL || s2 == NULL, "NULL string passed");
	
	// Get pointer to translation table
	tableP = GetCharCaselessValue();
	
	while (true)
		{
		c1 = *s1++;
		if (c1 == '\0') break;
		
		c2 = *s2++;
		result = tableP[c1] - tableP[c2];
		if (result) return result;
		};
		
	return 0;		// equal strings
}


/***********************************************************************
 *
 * FUNCTION:     LookupStringInList
 *
 * DESCRIPTION:  This routine seatches a list for a the string passed.
 *
 * PARAMETERS:   lst       - pointer to a list object
 *					  key       - string to lookup record with
 *					  indexP    - to contain the record found
 *            
 *
 * RETURNED:     true if a match was found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/10/96	Initial Revision
 *
 ***********************************************************************/
static Boolean LookupStringInList (ListPtr lst, CharPtr key, UIntPtr indexP, 
	BooleanPtr uniqueP)
{
	Int 		result;
	Int 		numItems;
	UInt		kmin, probe, i;
	CharPtr	itemP;
	Boolean	match = false;
	
	*uniqueP = false;
	
	if ((! key) || (! *key) ) return false;
		
	numItems = LstGetNumberOfItems (lst);
	if (numItems == 0) return false;
	
	result = 0;
	kmin = probe = 0;

	
	while (numItems > 0)
		{
		i = numItems / 2;
		probe = kmin + i;


		// Compare the a list item to the key.
		itemP = LstGetSelectionText (lst, probe);
		result = PartialCaselessCompare (key, itemP);


		// If the date passed is less than the probe's date , keep searching.
		if (result < 0)
			numItems = i;

		// If the date passed is greater than the probe's date, keep searching.
		else if (result > 0)
			{
			kmin = probe + 1;
			numItems = numItems - i - 1;
			}

		// If equal stop here!  Make sure the match is unique by checking
		// the item before and after the probe,  if either matches then
		// we don't have a unique match.
		else
			{
			// Start by assuming we have a unique match.
			match = true;
			*uniqueP = true;
			*indexP = probe;

			// If we not have a unique match,  we want to return the 
			// index one the first item that matches the key.
			while (probe)
				{
				itemP = LstGetSelectionText (lst, probe-1);
				if (PartialCaselessCompare (key, itemP) != 0)
					break;
				*uniqueP = false;
				*indexP = probe-1;
				probe--;
				}

			if (!*uniqueP) break;

			if (probe + 1 < LstGetNumberOfItems (lst))
				{
				itemP = LstGetSelectionText (lst, probe+1);
				if (PartialCaselessCompare (key, itemP) == 0)
					*uniqueP = false;				
				}
			break;		
			}
		}
	return (match);
}


/***********************************************************************
 *
 * FUNCTION:    IncrementalSearch
 *
 * DESCRIPTION: Updated the incremental search buffer with the passed 
 *              character and search the list for a match.  If a match 
 *              is found it will be selected.
 *
 * PARAMETERS:  nothing
 *                		
 * RETURNED:    true if a unique match has found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/2/96	Initial Revision
 *
 ***********************************************************************/
static Boolean IncrementalSearch (ListPtr list, CharPtr buffer, Char chr)
{
	Word len;
	Word index;
	WordPtr charAttr;
	Boolean redraw = false;
	Boolean unique = false;

	if (! list->attr.search)
		return (false);
		
	charAttr = GetCharAttr();
	if (! (IsPrint (charAttr, chr) || IsCntrl (charAttr, chr)))
		return (false);
	

	len = StrLen (buffer);
	
	if (chr == backspaceChr)
		{
		if (len)
			buffer[--len] = 0;
		}
	else if (chr == linefeedChr)
		{
		return (list->currentItem != noListSelection);
		}
	else if (len < maxListLookupLen)
		{
		buffer[len++] = chr;
		buffer[len] = 0;
		}
	else
		return (false);



	// Check for a match.
	if ( ! LookupStringInList (list, buffer, &index, &unique))
		{
		// If the character was a backspace and the auto buffer is empty
		// then set the list selection to none.
		if (chr == backspaceChr)
			{
			if (! len)
				index = noListSelection;
			}

		// If we didn't get a match, remove the character from the search key.
		else
			{
			SndPlaySystemSound (sndError);
			buffer[--len] = 0;
			return (false);
			}
		}
		

	// Display the new selection.
	if (index != list->currentItem)
		{
		// Unhighlight the old selection
	   InvertCurrentSelection (list); 

		list->currentItem = index;
		
		// If there is no selection then scroll the list to the top.
		if (index == noListSelection)
			{
			if (list->topItem)
				{
				list->topItem = 0;
				redraw = true;
				}
			}

		// If the new selection is not visible make it visible.
		else if ( ! InvertCurrentSelection (list))
			{
			list->topItem = min(index, list->numItems - VisibleItems(list));
			redraw = true;
			}
			
		if (redraw)
			{
			EraseInsideListBounds (list);
			LstDrawList (list);
			}
		}

	
	return (unique);
}


/***********************************************************************
 *
 * FUNCTION:    LstScrollList
 *
 * DESCRIPTION: Scroll the list up or down a number of items.
 *
 * PARAMETERS:	 pList         - pointer to list object
 *					 direction	   - direction to scroll
 *					 itemCount		- items to scroll in direction
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *			roger	9/23/96	Exported
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean LstScrollList(const ListPtr pList, 
	const enum directions direction, short itemCount)
{
	Word redrawItemStart, redrawItemEnd;
	Word item;
	RectangleType	r, vacated;
	FontID currFont;
	

	currFont = FntSetFont (pList->font);
	
	RctCopyRectangle (&(pList->bounds), &r);

	if (direction == up)
		{
		if (!ListScrolledToTop(pList))
			{
			itemCount = min(itemCount, pList->topItem);
			if (itemCount > 0)
				{
				InvertCurrentSelection (pList);
				InvertScrollUpIndicator (pList, false);
				WinScrollRectangle (&r, down, itemCount * FntLineHeight(), &vacated);
				WinEraseRectangle (&vacated, 0);
				pList->topItem -= itemCount;
				redrawItemStart = pList->topItem;
				redrawItemEnd = redrawItemStart + itemCount - 1;
				}
			}
		else
			itemCount = 0;
		}
	else  // scroll down
		{
		if (!ListScrolledToBottom(pList))
			{
			itemCount = min(itemCount, (pList->numItems - VisibleItems(pList))
								 - pList->topItem );
			if (itemCount > 0)
				{
				InvertCurrentSelection (pList);
				InvertScrollDownIndicator (pList, false);
				WinScrollRectangle (&r, up, itemCount * FntLineHeight(), &vacated);
				WinEraseRectangle (&vacated, 0);
				pList->topItem += itemCount;
				redrawItemEnd = LastVisibleItem(pList);
				redrawItemStart = redrawItemEnd - itemCount + 1;
				}
			}
		else
			itemCount = 0;
		}

	// draw the newly visible items
	if (itemCount > 0)
		{
		if (pList->drawItemsCallback)
			{
			// The text should be indented a bit
			RctCopyRectangle (&(pList->bounds), &r);
			r.topLeft.x += textInsetWidth;
			r.extent.x -= textInsetWidth;
			r.extent.y = FntLineHeight();
			r.topLeft.y += r.extent.y * (redrawItemStart - pList->topItem);
			
			for (item = redrawItemStart; item <= redrawItemEnd; item++)
				{
				pList->drawItemsCallback (item, &r, pList->itemsText);
				r.topLeft.y += r.extent.y;
				}
			}
		else
			{
			for (item = redrawItemStart; item <= redrawItemEnd; item++)
				{
				DrawItem(pList, item);
				}
			}

		InvertScrollUpIndicator(pList, true);
		InvertScrollDownIndicator(pList, true);
		InvertCurrentSelection (pList);
		
		FntSetFont (currFont);
		return true;
		}
	
	FntSetFont (currFont);
	return false;
}



/*--------------------------------------------------------*/
/*                    PtAboveRect                         */
/*--------------------------------------------------------*/
Boolean PtAboveRect (short x, short y, RectangleType *r)
{
	return ( (y < r->topLeft.y) && (x > r->topLeft.x) &&
				(x <= r->topLeft.x + r->extent.x) );
}

/*--------------------------------------------------------*/
/*                   PtBelowRect                          */
/*--------------------------------------------------------*/
Boolean PtBelowRect (short x, short y, RectangleType *r)
{

	return ( (y >= r->topLeft.y + r->extent.y) && (x > r->topLeft.x) &&
				(x <= r->topLeft.x + r->extent.x) );
}


/*---------------------------------------------------------*/
/*                      PointToItem                        */
/*---------------------------------------------------------*/
/*
Word PointToItem (short y, RectanglePtr rect)
{
	short item;
	short visibleItems;

	visibleItems = rect->extent.y / FntLineHeight();

	// Determine the item that the point in on
	item = ((y - rect->topLeft.y) / FntLineHeight());

	// Check for algorithm error resulting from point on rectangle frame
	if (item < 0) item = 0;
	if (item >= visibleItems) item = visibleItems-1;
	return (item);
}
*/


/***********************************************************************
 *
 * FUNCTION:    InvertVisibleItem
 *
 * DESCRIPTION: Invert the visible item i'th from the top.
 *
 * PARAMETERS:	 list          - pointer to list object
 *              i             - position from the top item
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/3/94	Initial Revision
 *
 ***********************************************************************/
static void InvertVisibleItem (ListPtr pList, unsigned short i)
	{
	RectangleType bounds;

//	if (ItemIsVisible(pList, i))
	if (i != noListSelection)
		{
		GetBounds (&bounds, pList, i);
		WinInvertRectangle (&bounds, 0);
		}
  }


/***********************************************************************
 *
 * FUNCTION:    LstDrawList
 *
 * DESCRIPTION: Draw a list object.  If the list is disabled it will
 *					 be drawn grayed-out.  If the list is not useable
 *					 the list will not draw.  If it is empty nothing is drawn.
 *
 * PARAMETERS:	 list - pointer to list object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/28/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstDrawList (const ListPtr pList)
	{
	RectangleType	r, saveClip;
	WinHandle		curDrawWin;
	FontID			currFont;
   short				i;
	short          visibleItem;


	if (!pList->attr.usable) return;

	pList->attr.visible = true;

	// If there isn't any text or draw function don't try to draw!
	if ((pList->numItems == 0 && pList->bounds.extent.y <= 0) || 
		(pList->itemsText == NULL && !pList->drawItemsCallback && pList->numItems > 0) ) 
		return;


	if (pList->attr.poppedUp)
		{
		RectangleType frame;
		
		// Erase the window's backgroud
		curDrawWin = WinSetDrawWindow (WinGetDisplayWindow());
		WinGetWindowFrameRect (pList->popupWin, &frame);
		RctInsetRectangle (&frame, -1);
		WinEraseRectangle (&frame, 0);

		// Draw the popup list's frame
		WinSetDrawWindow (pList->popupWin);
		WinDrawWindowFrame ();
		}
	else
		WinDrawRectangleFrame (listFrame, &(pList->bounds));


	currFont = FntSetFont (pList->font);


	// Restrict the clipping to the list's bounds.
	WinGetClip (&saveClip);
	RctCopyRectangle (&(pList->bounds), &r);
	WinClipRectangle (&r);
	WinSetClip (&r);


	visibleItem = LastVisibleItem(pList) + 1;
	ErrNonFatalDisplayIf(visibleItem > pList->numItems, 
		"The list is scrolled too far down");
	

	if (pList->drawItemsCallback)
		{
		RctCopyRectangle (&(pList->bounds), &r);

		// The text should be indented a bit
		r.topLeft.x += textInsetWidth;
		r.extent.x -= textInsetWidth;
		r.extent.y = FntLineHeight();
		
		for (i = pList->topItem; i < visibleItem; ++i)
			{
			pList->drawItemsCallback (i, &r, pList->itemsText);
			r.topLeft.y += r.extent.y;
			}
		}
	else
		{
		for (i = pList->topItem; i < visibleItem; ++i)
			{
			DrawItem (pList, i);
			}
		}

	WinSetClip (&saveClip);

	InvertScrollUpIndicator(pList, true);
	InvertScrollDownIndicator(pList, true);
	InvertCurrentSelection(pList);

	FntSetFont (currFont);

	if (pList->attr.poppedUp)
		WinSetDrawWindow (curDrawWin);
	}


/***********************************************************************
 *
 * FUNCTION:    LstEraseList
 *
 * DESCRIPTION: Erase the bounds of the list object specified.
 *
 * PARAMETERS:	 list - pointer to list object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/28/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstEraseList (const ListPtr pList)
	{
	RectangleType r;

	WinGetFramesRectangle (listFrame, &(pList->bounds), &r);
	WinEraseRectangle (&r, 0);
	pList->attr.visible = false;
	}


/***********************************************************************
 *
 * FUNCTION:    LstGetSelection
 *
 * DESCRIPTION: Returns the current selection in the list.  If there 
 *              is no selection, returns NoListSelection (-1).
 *
 * PARAMETERS:	 list - pointer to list object
 *
 * RETURNED:	 currently selected list choice (0=first item, -1=none)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/29/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word LstGetSelection (const ListPtr pList)
	{
	return (pList->currentItem);
	}


/***********************************************************************
 *
 * FUNCTION:    LstSetSelection
 *
 * DESCRIPTION: Sets the selection for a list.  Old selection is unselected,
 *              if any.  If the list is visible the selected item is 
 *              visually updated.
 *
 * PARAMETERS:	 list    - pointer to list object
 *              itemNum - item to select (0=first item in list)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/29/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetSelection (const ListPtr pList, const Word itemNum)
	{
	FontID 			currFont;
	
	
	currFont = FntSetFont (pList->font);
	
	if (pList->attr.usable && pList->attr.visible)
	   InvertCurrentSelection (pList);  // visually remove the old selection

	pList->currentItem = itemNum;


   // Make the new selection visible, scrolling the list if 
   // neccessary (assuming the new itemNum isn't noListSelection).
	if (pList->attr.usable && pList->attr.visible)
	   {
		if (!InvertCurrentSelection (pList) && itemNum != noListSelection)
			{
			// Scroll
			pList->topItem = min(itemNum, pList->numItems - VisibleItems(pList));
			EraseInsideListBounds(pList);
			LstDrawList(pList);
			}
		}

	FntSetFont (currFont);
	}

/***********************************************************************
 *
 * FUNCTION:    LstGetNumberOfItems
 *
 * DESCRIPTION: Returns the number of items in a list.
 *
 * PARAMETERS:	 list - pointer to list object
 *
 * RETURNED:	 number of items in a list.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/24/94	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Word LstGetNumberOfItems (const ListPtr pList)
	{
	return (pList->numItems);
	}


/***********************************************************************
 *
 * FUNCTION:    LstSetTopItem
 *
 * DESCRIPTION: Set the the item visible.  The item may not become the
 * top item if it's in the last page.
 *
 * PARAMETERS:	 list    - pointer to list object
 *              itemNum - item to select (0=first item in list)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/5/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetTopItem (const ListPtr pList, const Word itemNum)
{
	FontID currFont;
	

	currFont = FntSetFont (pList->font);
	
	ErrNonFatalDisplayIf(itemNum >= pList->numItems && itemNum != noListSelection, 
		"Invalid item");
	
	pList->topItem = min(itemNum, pList->numItems - VisibleItems(pList));
	
	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    LstMakeItemVisible
 *
 * DESCRIPTION: Makes the item visible, preferably at the top.
 *
 * PARAMETERS:	 list    - pointer to list object
 *              itemNum - item to select (0=first item in list)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/10/94	Initial Revision
 *			roger	12/5/95	Change the top item only if the item isn't visible
 *
 ***********************************************************************/
void LstMakeItemVisible (const ListPtr pList, const Word itemNum)
{
	Int visibleItems;
	FontID currFont;
	

	ErrNonFatalDisplayIf(itemNum >= pList->numItems && itemNum != noListSelection, 
		"Invalid item");
	
	currFont = FntSetFont (pList->font);
	
	visibleItems = VisibleItems(pList);
	
	// if the item isn't visible make it the top most item
	if (itemNum < pList->topItem || 
		itemNum >= (pList->topItem + visibleItems))
		{
		LstSetTopItem (pList, itemNum);
		}
	FntSetFont (currFont);
}


/***********************************************************************
 *
 * FUNCTION:    LstGetSelectionText
 *
 * DESCRIPTION:  Returns a pointer to the text of the specifed item
 *               in the list.
 *
 * PARAMETERS:  list    - pointer to list object
 *
 * RETURNED:	 pointer to the text of the current selection
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/29/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
CharPtr LstGetSelectionText (const ListPtr pList, const Word itemNum)
	{
//	ErrNonFatalDisplayIf(itemNum >= pList->numItems && itemNum != noListSelection, 
//		"Invalid item");
//	ErrNonFatalDisplayIf(pList->drawItemsCallback != NULL && itemNum != 0, 
//		"Can't get text when draw function set");
	
	
	if (itemNum < pList->numItems)
		return pList->itemsText[itemNum];

	return (NULL);
	}


/***********************************************************************
 *
 * FUNCTION:    LstSetListChoices
 *
 * DESCRIPTION: Set the choices of a list.  The array of text strings
 *              passed to this routine.  This routine does not affect
 *              the display of the list.
 *
 *					 The routine SysFormPointerArrayToStrings is useful if
 *					 what you have is a block of multiple strings.
 *
 * PARAMETERS:	 list       - pointer to list object
 *              itemsText  - pointer to an array of of text string           
 *              numItems   - number of choice in the list
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/28/94	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetListChoices
 (const ListPtr pList, Char ** itemsText, const UInt numItems)
	{
	UInt newTopItem;
	FontID currFont;
	

	currFont = FntSetFont (pList->font);

	// Set the list to the new items
	pList->itemsText = itemsText;
	pList->numItems = numItems;
	
	
	// Insure that the current selection is within the list's 
	// new number of items.
	if (pList->currentItem != noListSelection &&
		pList->currentItem >= pList->numItems)
		pList->currentItem = pList->numItems - 1;


	// Insure that the list isn't scrolled too far down
	newTopItem = LastItem(pList) - (VisibleItems(pList) - 1);
	if (pList->topItem > newTopItem)
		pList->topItem = newTopItem;
		

	EraseInsideListBounds(pList);
	
	FntSetFont (currFont);
	}


/***********************************************************************
 *
 * FUNCTION:    LstSetDrawFunction
 *
 * DESCRIPTION: Set a callback function to call to draw each item instead
 * 				 drawing the item's text string.
 *
 * PARAMETERS:	 list       - pointer to list object
 *              func  		- pointer to function which draws items           
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/12/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetDrawFunction (const ListPtr pList, const ListDrawDataFuncPtr func)
	{
	pList->drawItemsCallback = func;
	}
	

/***********************************************************************
 *
 * FUNCTION:    LstSetHeight
 *
 * DESCRIPTION: This routine set the number of item that are visible in a
 *              list.  This routine does not redraw the list if it is 
 *              already visible.  It also adjusts topItem to prevent
 *					 a shrunk list from being scrolled down too far.
 *
 * PARAMETERS:	 list          - pointer to list object
 *              visibleItems  - number of choice visible at once
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/7/95	Initial Revision
 *			roger	8/28/95	Add topItem adjustment.
 *			roger	4/11/96	Fix topItem when visibleItems >= numItems.
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetHeight (const ListPtr pList, Word visibleItems)
	{
	FontID currFont;
	short x;
	short screenHeight;
	short height;
	short lineHeight;

	currFont = FntSetFont (pList->font);
	lineHeight = FntLineHeight ();
	height = visibleItems * lineHeight;

	// Make sure the bottom of the list is on the display.
	WinGetDisplayExtent (&x, &screenHeight);
	screenHeight -= 2;	// minus 2 for 3d shadow
	
	// Case where the list is longer than the screen and even if
	// the list starts at the top
	if (height >= screenHeight)
		{
		// Size the list to fit as many items on screen as can fit
		visibleItems = screenHeight / lineHeight;
		height = visibleItems * lineHeight;
		
		// Move the list up, centering it vertically.
		pList->bounds.topLeft.y = (screenHeight - height) / 2;
		}
	
	// Case where the list is longer than the screen but moving it
	// higher will allow it all to appear.
	else if (screenHeight - pList->bounds.topLeft.y < height)
		{
		// Move the list up until all the items are visible.
		pList->bounds.topLeft.y = screenHeight - height;
		}
		
	pList->bounds.extent.y = height;
	
	
	// If the list is now longer than numItems make sure all items are visible.
	if (visibleItems >= pList->numItems)
		{
		pList->topItem = 0;
		}
	// Reduce the top item if the list would appear scrolled down too far.
	else if (pList->topItem + visibleItems > pList->numItems)
		pList->topItem = pList->numItems - visibleItems;
		

	FntSetFont (currFont);
	}


/***********************************************************************
 *
 * FUNCTION:    LstSetPosition
 *
 * DESCRIPTION: This routine set the position of a list.  The list is
 *              not redrawn, as a matter-a-fact this routine should not
 *              be called when the list is visible.
 *
 * PARAMETERS:	 list   - pointer to list object
 *              x      - left bound
 *              y      - top bound
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/11/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void LstSetPosition (const ListPtr pList, const SWord x, const SWord y)
	{
	pList->bounds.topLeft.x = x;
	pList->bounds.topLeft.y = y;
	}
	

/***********************************************************************
 *
 * FUNCTION:    LstHandleScrollingIndicators
 *
 * DESCRIPTION: If the pen is down within a visible scroll indicator
 *
 * PARAMETERS:	 list   - pointer to list object
 *              x      - left bound
 *              y      - top bound
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	7/31/95	Initial Revision
 *
 ***********************************************************************/
static Boolean LstHandleScrollingIndicators (ListPtr pList, EventPtr event)
{
	RectangleType r;
	Boolean   inverted;
	Boolean   penDown;
	Int		 x, y;
	FontID currFont;
	

	if (pList->attr.hasScrollBar)
		return (false);

	currFont = FntSetFont (pList->font);

	// Handle tapping a scroll indicator.  Check first whether any 
	// indicator is visible by checking if the number of items are 
	// greater than those displayed (so some appear off the list and
	// thus scrolling to them is possible).
	if (event->screenX > pList->bounds.topLeft.x + pList->bounds.extent.x -
		 scrollIndicatorWidth &&
		 VisibleItems(pList) < pList->numItems)
		{
		// See if the pen is within the bounds of the indicators.
		if ((event->screenY - pList->bounds.topLeft.y < scrollIndicatorHeight) ||
			 (event->screenY - pList->bounds.topLeft.y > pList->bounds.extent.y -
					scrollIndicatorHeight ))
			{

			// calculate the bounds of the indicator.
			if (event->screenY - pList->bounds.topLeft.y < scrollIndicatorHeight)
				{
				// Consume tap if the indicator is not there.
				if (ListScrolledToTop(pList))
					{
					return true;
					}
				r.topLeft.y = pList->bounds.topLeft.y;
				}
			else
				{
				// Consume tap if the indicator is not there.
				if (ListScrolledToBottom(pList))
					{
					return true;
					}
				r.topLeft.y = pList->bounds.topLeft.y + pList->bounds.extent.y -
					scrollIndicatorHeight;
				}
			r.topLeft.x = pList->bounds.topLeft.x + pList->bounds.extent.x -
				scrollIndicatorWidth;
			r.extent.x = scrollIndicatorWidth;
			r.extent.y = scrollIndicatorHeight;


			WinInvertRectangle (&r, 0);
			inverted	= true;
			penDown		= true;

			do
				{
				PenGetPoint (&x, &y, &penDown);

				if (RctPtInRectangle (x, y, &r))
					{
					if (penDown)
						{
						if (!inverted)
							{
							inverted = true;

							// Draw the inverse of what's there as if it's activated.
							WinInvertRectangle (&r, 0);
							}
						}
					}
				else /* moved out of rectangle */
					{
					if (inverted)
						{
						inverted = false;
						WinInvertRectangle (&r, 0);
						}
					}
				} while (penDown);

			if (inverted)
				{
				inverted = false;
				WinInvertRectangle (&r, 0);
				}
			if (RctPtInRectangle (x, y, &r))
				{
				LstScrollList(pList, (r.topLeft.y == pList->bounds.topLeft.y) ?
							  up : down,  VisibleItems(pList) - 1);
				}
	
			FntSetFont (currFont);
			return true;
			}
		}
		
	FntSetFont (currFont);
	return false;		// not handled
}
	

/***********************************************************************
 *
 * FUNCTION:    LstHandleEvent
 *
 * DESCRIPTION: Handle event in the specified list.  This routine 
 *              handles two type of events, penDownEvents and 
 *              lstEnterEvent.
 *
 *              When this routine receives a penDownEvents it checks
 *              if the pen position is within the bounds of the
 *              list object, if it is this routine tracks the pen 
 *              until the pen comes up.  If the pen comes up
 *              within the bounds of the list, a lstEnterEvent is 
 *              added to the event queue, and the routine is exited.
 *
 *              When this routine receives a lstEnterEvent it 
 *              check that the list id in the event record match
 *              the id of the list specified, if there is a match
 *              this routne will create and display a popup window
 *              containing the list's choices, and the routine is exited. 
 *
 *              If a penDownEvents is received while the list's popup 
 *              window is display, and the the pen postion is outside the 
 *              bounds of the popup window, the  will be dismissed.
 *              If the pen postion is within the bounds of the window 
 *              the this routne will track the pen until it comes up. 
 *              If the pen comes up in the list a lstExitEvent will be
 *              added to the event queue.
 *
 *
 * PARAMETERS:	 list      - pointer to list object
 *              pEvent    - pointer to an EventType structure.
 *              pError    - pointer to returned erro code
 *
 * RETURNED:	 TRUE if the event was handle or FALSE if it was not.
 *              pError     - error code.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/29/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean LstHandleEvent (const ListPtr pList, const EventPtr event)

	{
	EventType newEvent;
	FontID	 currFont;
	Boolean   inverted, currentItemInverted;
	Boolean   penDown;
	UInt     newSelection;        // item under the pen
	UInt     newerSelection;      // newer item under pen, may not equal above
	Int		 x, y;
	Int		lastItemBottomY;
	Word 		ticks;
	ULong	 	delay;
	ULong  	firstTick;
	Boolean  scrolled;

	if (!pList->attr.usable ||
		 !pList->attr.visible)
		return (false);

	newSelection = pList->currentItem - pList->topItem;
		// use the current item. This suppresses a flash
		// when the newer selection == the new selection.


	switch (event->eType)
		{
		case penDownEvent:
			if (RctPtInRectangle (event->screenX, event->screenY, &(pList->bounds)))
				{
				EvtCopyEvent (event, &newEvent);
				newEvent.eType = lstEnterEvent;
				newEvent.data.lstEnter.listID = pList->id;
				newEvent.data.lstEnter.pList = pList;
				newEvent.screenX = event->screenX;
				newEvent.screenY = event->screenY;
				EvtAddEventToQueue (&newEvent);
				return true;
				}
			break;

		case lstEnterEvent:
			{
			currFont = FntSetFont (pList->font);
	
	
			if (LstHandleScrollingIndicators (pList, event))
				{
				FntSetFont(currFont);
				return true;
				}
				
				
			// The loop below handles list item selection and dragging, as
			// well as drag scrolling.
	//		InvertCurrentSelection (pList);
			currentItemInverted = true;
			inverted = false;
			
			
			// Calculate lastItemBottomY to quickly tell if a point is 
			// past the last visible item but within the list's bounds
			lastItemBottomY = pList->bounds.topLeft.y + 
				(VisibleItems(pList) * FntLineHeight());
	
	
			do
				{
				PenGetPoint (&x, &y, &penDown);
				if (RctPtInRectangle (x, y, &(pList->bounds)) &&
					y < lastItemBottomY)
					{
					// Process the new pen point.
					newerSelection = (y - pList->bounds.topLeft.y) / FntLineHeight();
					// handle selections past end of small list
					if (newerSelection > LastVisibleItem(pList))
						newerSelection = noListSelection;
					if (newerSelection != newSelection)
						{
						if (inverted)
							InvertVisibleItem (pList, newSelection);
						if (currentItemInverted)
							{
							InvertCurrentSelection (pList);
							currentItemInverted = false;
							}
						InvertVisibleItem (pList, newerSelection);
						inverted = true;
						newSelection = newerSelection;
						}
	
					if (penDown)
						{
						// Reset drag scrolling values
						delay = listScrollInitDelay;
						firstTick = TimGetTicks();
						}
					else /* pen is up */
						{
						pList->currentItem = pList->topItem + newerSelection;
	//					InvertCurrentSelection (pList);
						// The visible item inverted is hereby considered the current item
						currentItemInverted = true;
						newEvent.eType = lstSelectEvent;
						newEvent.data.lstSelect.selection = pList->currentItem;
						
						SndPlaySystemSound (sndClick);
						}
					}
				else /* moved out of rectangle */
					{
	
	
					// drag scrolling code
					ticks = TimGetTicks () - firstTick;
					scrolled = false;
					if (PtBelowRect (x, y, &pList->bounds) ||
						 PtAboveRect (x, y, &pList->bounds))
						{
						if ((ticks > listScrollMinDelay) && (ticks > delay))
							{
	
							if (inverted)
								{
								InvertVisibleItem (pList, newSelection);
								inverted = false;
								}
							// Handle above the list
							if (y < pList->bounds.topLeft.y)
								{
								if (LstScrollList (pList, up, 1))
									{
									newSelection = 0;
									InvertVisibleItem (pList, newSelection);
									inverted = true;
									delay = max (0, ((Long)delay - listScrollAcceleration));
									firstTick = TimGetTicks();
									scrolled = true;
									}
								}
							else
								{
								if (LstScrollList (pList, down, 1))
									{
									newSelection = VisibleItems(pList) - 1;
									InvertVisibleItem (pList, newSelection);
									inverted = true;
									delay = max (0, ((Long)delay - listScrollAcceleration));
									firstTick = TimGetTicks();
									scrolled = true;
									}
								}
							}
						else
							{
							// Handle above the list
							if (y < pList->bounds.topLeft.y)
								{
								if (!ListScrolledToTop(pList))
									{
									scrolled = true;
									if (newSelection != 0)
										{
										if (inverted)
											InvertVisibleItem (pList, newSelection);
										newSelection = 0;
										InvertVisibleItem (pList, newSelection);
										inverted = true;
										}
									}
								}
							else
								{
								// Are we at the botton of the list?
								if (!ListScrolledToBottom(pList))
									{
									scrolled = true;
									if (newSelection != VisibleItems(pList) - 1)
										{
										if (inverted)
											InvertVisibleItem (pList, newSelection);
										newSelection = VisibleItems(pList) - 1;
										InvertVisibleItem (pList, newSelection);
										inverted = true;
										}
									}
								}
							}
						}
	
	
					if (!scrolled)
						{
						if (inverted)
							{
							InvertVisibleItem (pList, newSelection);
							inverted = false;
							}
	/*				   if (!currentItemInverted)
							{
							InvertCurrentSelection (pList);
							currentItemInverted = true;
							}
	*/
					   newSelection = noListSelection;
						}
	
					if (!penDown)
						{
						// The user did not select the control.
						newEvent.eType = lstExitEvent;
	
						// If the user pen ups above or below the list we must remove
						// the inverted visible item.  If the pen is to the side the
						// visible item is already inverted.
						if (inverted)
							{
							InvertVisibleItem (pList, newSelection);
							inverted = false;
							}
						}
					}
				} while (penDown);
	
	
			if (!currentItemInverted)
				{
				InvertCurrentSelection (pList);
				currentItemInverted = true;
				}
	
			// Return lstSelectEvent or lstExitEvent
			newEvent.penDown = penDown;
			newEvent.screenX = x;
			newEvent.screenY = y;
			newEvent.data.lstSelect.listID = pList->id;
			newEvent.data.lstSelect.pList = pList;
			EvtAddEventToQueue (&newEvent);
			FntSetFont (currFont);
			return true;
			}

		default:
			break;
		}
		
	return(false);
	}


/***********************************************************************
 *
 * FUNCTION:    LstPopupList
 *
 * DESCRIPTION: Display a window the contains the choices of the list.
 *              
 *
 * PARAMETERS:	 list    - pointer to list object
 *
 * RETURNED:	 the list item selected or -1 if no item has selected.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
SWord LstPopupList (const ListPtr pList)
	{
	Char				lookupBuffer [maxListLookupLen+1];
	Word				error;
	Word				topItem;
	Short          selectedItem;
	Short				displayWidth;
	Short				displayHeight;
	Boolean        handled;
	Boolean			insPtState;
	ListType			list;
	EventType      event;
	WinHandle   	popupWin;
	WinHandle   	savedBits;
	WinHandle   	savedActiveWin;
	WinHandle   	savedDrawWin;
	RectangleType	r, frame;
	FontID 			currFont;
	
	
	currFont = FntSetFont (pList->font);
	
	// Save the current active window and the current draw window.
	savedActiveWin = WinGetActiveWindow ();
	savedDrawWin = WinGetDrawWindow ();
	
	insPtState = InsPtEnabled ();
	InsPtEnable (false);

	MemMove (&list, pList, sizeof (list));

	// Determine the size and position of the popup window.  Try to position
	//	the popup at the top left bounds of the list object.
	RctCopyRectangle (&list.bounds, &r);
	WinWindowToDisplayPt (&r.topLeft.x, &r.topLeft.y);

	// Force the bottom of the list onto the display.
	WinGetDisplayExtent (&displayWidth, &displayHeight);
	if (r.topLeft.y + r.extent.y > displayHeight - 2)
		r.topLeft.y = displayHeight - r.extent.y - 2;

	// Force the top of the list onto the display.
	if (r.topLeft.y < 1)
		r.topLeft.y = 1;

	// Force the right side of the list onto the display.
	if (r.topLeft.x + r.extent.x > displayWidth - 2)
		r.topLeft.x = max (2, (displayHeight - r.extent.x - 2));
	
	// Force the left side of the list onto the display.
	if (r.topLeft.x < 1)
		r.topLeft.x = 1;


	// Create a window.
	popupWin = WinCreateWindow (&r, popupFrame, true, false, &error);

	// Save the bits behind the popup window.
	WinSetDrawWindow (WinGetDisplayWindow());
	WinGetWindowFrameRect (popupWin, &frame);
	RctInsetRectangle (&frame, -1);
	WinClipRectangle (&frame);
	savedBits = WinSaveBits (&frame, &error);


	// Draw the windows frame.
	WinEnableWindow (popupWin);
	WinSetDrawWindow (popupWin);
	WinSetActiveWindow (popupWin);

	// Draw the choices of the list, make sure the current selection
	// is in view.
	pList->bounds.topLeft.x = 0;
	pList->bounds.topLeft.y = 0;
	pList->attr.usable = true;
	pList->attr.poppedUp = true;
	pList->popupWin = popupWin;

	WinDrawWindowFrame ();
	LstDrawList (pList);


	// Initialize the incremental search buffer.
	*lookupBuffer = 0;

	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		handled = SysHandleEvent (&event);
		if (! handled)
			handled = LstHandleEvent (pList, &event);


		if (event.eType == penDownEvent)
			{
			if (!handled)
				{
				selectedItem = -1;
				break;
				}
			}


		else if (event.eType == lstSelectEvent)
			{
			selectedItem = event.data.lstSelect.selection;
			break;
			}


		else if (event.eType == lstExitEvent)
			{
			selectedItem = -1;
			break;
			}


		// Handle command keys
		else if (event.eType == keyDownEvent)
			{
			// Handle special keys
			if (event.data.keyDown.modifiers & commandKeyMask)
				{
				// Process these chars
				if (event.data.keyDown.chr == pageUpChr)
					{
						LstScrollList(pList, up, VisibleItems(pList) - 1);
						continue;
					}
				else if (event.data.keyDown.chr == pageDownChr)
					{
						LstScrollList(pList, down, VisibleItems(pList) - 1);
						continue;
					}
				else  if (event.data.keyDown.chr != lowBatteryChr)
					{
//					EvtAddEventToQueue (&event);
					selectedItem = -1;
					break;
					}
				}

			else if (IncrementalSearch (pList, lookupBuffer, event.data.keyDown.chr))
				{
				selectedItem = pList->currentItem;
				break;
				}
			}


		// Leave the list if the application is being left.
		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			selectedItem = -1;
			break;
			}
		}


	// Dismiss the popup window
	WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (popupWin, &r);
	RctInsetRectangle (&r, -1);
	WinClipRectangle (&r);
	WinRestoreBits (savedBits , r.topLeft.x, r.topLeft.y);

	WinDeleteWindow (popupWin, false);
	WinSetDrawWindow (savedDrawWin);
	WinSetActiveWindow (savedActiveWin);
	
	topItem = pList->topItem;
	MemMove (pList, &list, sizeof (list));
	if (selectedItem != -1)
		{
		pList->currentItem = selectedItem;
		pList->topItem = topItem;
		}

	InsPtEnable (insPtState);
	
	FntSetFont (currFont);

	return (selectedItem);
}


#if unimplemented

/***********************************************************************
 *
 * FUNCTION:    LstPopupList
 *
 * DESCRIPTION: Display a window the contains the choices of the list.
 *              
 *
 * PARAMETERS:	 list    - pointer to list object
 *
 * RETURNED:	 the list item selected or -1 if no item has selected.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/14/94		Initial Revision
 *
 ***********************************************************************/
Short LstPopupListWithScrollBar (ListPtr pList)
	{
	Word				error;
	Word				topItem;
	Word				visibleItems;
	Short				itemsToScroll;
	Short          selectedItem;
	Short				displayWidth;
	Short				displayHeight;
	Boolean        handled;
	Boolean			insPtState;
	ListType			list;
	EventType      event;
	WinHandle   	popupWin;
	WinHandle   	savedBits;
	WinHandle   	savedActiveWin;
	WinHandle   	savedDrawWin;
	RectangleType	r, frame;
	ScrollBarType	bar;
	FontID 			currFont;
	

	// Save the current active window and the current draw window.
	savedActiveWin = WinGetActiveWindow ();
	savedDrawWin = WinGetDrawWindow ();
	
	insPtState = InsPtEnabled ();
	InsPtEnable (false);

	MemMove (&list, pList, sizeof (list));

	// Determine the size and position of the popup window.  Try to position
	//	the popup at the top left bounds of the list object.
	RctCopyRectangle (&list.bounds, &r);
	WinWindowToDisplayPt (&r.topLeft.x, &r.topLeft.y);

	// Force the bottom of the list onto the display.
	WinGetDisplayExtent (&displayWidth, &displayHeight);
	if (r.topLeft.y + r.extent.y > displayHeight - 2)
		r.topLeft.y = displayHeight - r.extent.y - 2;

	// Force the top of the list onto the display.
	if (r.topLeft.y < 1)
		r.topLeft.y = 1;

	// Force the right side of the list onto the display.
	if (r.topLeft.x + r.extent.x > displayWidth - 2)
		r.topLeft.x = max (2, (displayHeight - r.extent.x - 2));
	
	// Force the left side of the list onto the display.
	if (r.topLeft.x < 1)
		r.topLeft.x = 1;


	// Create a window.
	popupWin = WinCreateWindow (&r, popupFrame, true, false, &error);

	// Save the bits behind the popup window.
	WinSetDrawWindow (WinGetDisplayWindow());
	WinGetWindowFrameRect (popupWin, &frame);
	RctInsetRectangle (&frame, -1);
	WinClipRectangle (&frame);
	savedBits = WinSaveBits (&frame, &error);


	// Draw the windows frame.
	WinEnableWindow (popupWin);
	WinSetDrawWindow (popupWin);
	WinSetActiveWindow (popupWin);


	currFont = FntSetFont (pList->font);
	// Draw the choices of the list, make sure the current selection
	// is in view.
	pList->bounds.topLeft.x = 0;
	pList->bounds.topLeft.y = 0;
	pList->attr.usable = true;
	pList->attr.poppedUp = true;
	pList->attr.hasScrollBar = true;
	pList->popupWin = popupWin;

	// Initialize the scroll bar.
	MemSet (&bar, sizeof (ScrollBarType), 0);
	visibleItems = VisibleItems (pList);

	if (visibleItems > 1)
		{
		RctCopyRectangle (&pList->bounds, &bar.bounds);
		bar.bounds.topLeft.x += bar.bounds.extent.x - lstScrollBarWidth;
		bar.bounds.extent.x = lstScrollBarWidth;
		
		bar.attr.usable = true;
		
		SclSetScrollBar (&bar, pList->currentItem, 
				0, pList->numItems - visibleItems, visibleItems - 1);	
		}


	WinDrawWindowFrame ();
	LstDrawList (pList);
	SclDrawScrollBar (&bar);


	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		SysHandleEvent (&event);

		if ( ! (handled = SclHandleEvent (&bar, &event)))
			handled = LstHandleEvent (pList, &event);

		if (event.eType == penDownEvent)
			{
			if (!handled)
				{
				selectedItem = -1;
				break;
				}
			}

		else if (event.eType == lstSelectEvent)
			{
			selectedItem = event.data.lstSelect.selection;
			break;
			}

		else if (event.eType == lstExitEvent)
			{
			selectedItem = -1;
			break;
			}

		// Handle the up and down physical buttons.
		else if (event.eType == keyDownEvent)
			{
			if (event.data.keyDown.modifiers & commandKeyMask)
				{
				if (event.data.keyDown.chr == pageUpChr)
					{
					LstScrollList(pList, up, VisibleItems(pList) - 1);
					SclSetScrollBar (&bar, pList->currentItem, 
						0, pList->numItems - visibleItems, visibleItems - 1);	

					continue;
					}
				else if (event.data.keyDown.chr == pageDownChr)
					{
					LstScrollList(pList, down, VisibleItems(pList) - 1);

					SclSetScrollBar (&bar, pList->currentItem, 
						0, pList->numItems - visibleItems, visibleItems - 1);	
					continue;
					}
				}
			}
			
		else if (event.eType == sclRepeatEvent)
			{
			itemsToScroll = event.data.sclRepeat.newValue - 
				event.data.sclRepeat.value;
			if (itemsToScroll < 0)
				LstScrollList (pList, up, -itemsToScroll);
			else
				LstScrollList (pList, down, itemsToScroll);
			}


		// Leave the list if the application is being left.
		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			selectedItem = -1;
			break;
			}
		}


	// Dismiss the popup window
	WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (popupWin, &r);
	RctInsetRectangle (&r, -1);
	WinClipRectangle (&r);
	WinRestoreBits (savedBits , r.topLeft.x, r.topLeft.y);

	WinDeleteWindow (popupWin, false);
	WinSetDrawWindow (savedDrawWin);
	WinSetActiveWindow (savedActiveWin);
	
	topItem = pList->topItem;
	MemMove (pList, &list, sizeof (list));
	if (selectedItem != -1)
		{
		pList->currentItem = selectedItem;
		pList->topItem = topItem;
		}

	InsPtEnable (insPtState);

	FntSetFont (currFont);
	
	return (selectedItem);
}

#endif


/***********************************************************************
 *
 * FUNCTION:    LstNewList
 *
 * DESCRIPTION: Create a list. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 id - id of the new list
 *					 x - x of the new list
 *					 y - y of the new list
 *					 width - width of the new list
 *					 height - height of the new list
 *					 font - font of the new list
 *					 visibleItems - the number of items the list displays at once
 *					 triggerId - if this list is a popup list, this is the id of the trigger to use
 *									 Pass zero for a normal list.
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
Err LstNewList (VoidPtr *formPP, const Word id, 
	const Word x, const Word y, const Word width, const Word height, 
	const FontID font, const Word visibleItems, const Word triggerId)
{
	ListPtr listP;
	FormPopupType *popupP;
	Err error;
	FontID currFont;
	
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)listP, frmListObj, 
				sizeof(ListType));
	if (error)
		return error;
	
	listP->id = id;
	listP->bounds.topLeft.x = x;
	listP->bounds.topLeft.y = y;
	listP->bounds.extent.x = width;
	currFont = FntSetFont (font);
	listP->bounds.extent.y = FntLineHeight() * visibleItems;
	FntSetFont (currFont);
	
	listP->font = font;
	listP->numItems = 0;
	
	if (triggerId)
		{
		error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)popupP, frmPopupObj, 
					sizeof(FormPopupType));
		if (error)
			return error;
		
		popupP->controlID = triggerId;
		popupP->listID = id;
		}
	else
		listP->attr.usable = true;
	
	
	return 0;
}





