/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     font.c
 * AUTHOR:	 Art Lamb: Jan 25, 1995
 *
 * DECLARER: UI
 *
 * ROUTINES:
 *
 * DESCRIPTION:
 *	  This file contains routines to initialize the ui.
 *
 **********************************************************************/

#include <Pilot.h>
#include <KeyMgr.h>
#include <ScrDriver.h>



extern void InitWindowVariables (void);


void ThisShouldGenerateALinkError();


/********************************************************************
 * This pointer is created under emulation mode just to make it easier
 * to look at the UI globals from the source level debugger
 *******************************************************************/
#if EMULATION_LEVEL != EMULATION_NONE
	UIGlobalsPtr	UIGlobalsP = 0;
#endif


/***********************************************************************
 *
 * FUNCTION:    UIInitialize
 *
 * DESCRIPTION: This routine returns the decimal seperator of the 
 *              default country (the country specified in the 
 *              Preferences application).
 *
 * PARAMETERS:  none
 *
 * RETURNED:    decimal seperator
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/5/97	Initial Revision
 *
 ***********************************************************************/
static Char UIGetDecimalSeparator (void)
{
	Char 			thousandSeparator;
	Char 			decimalSeparator;
	CountryPreferencesType *	resP;

	// Get the decimal separator for the home country and store it in 
	// a global variable.
  	resP = MemHandleLock (DmGetResource (sysResTCountries, sysResIDCountries));
	LocGetNumberSeparators (
		(NumberFormatType) PrefGetPreference (prefNumberFormat), 
		&thousandSeparator, &decimalSeparator);
	MemPtrUnlock (resP);

	return (decimalSeparator);
}


/***********************************************************************
 *
 * FUNCTION:    UIInitialize
 *
 * DESCRIPTION: This routine initialize the touchdown ui.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/25/95	Initial Revision
 *			SCL	12/10/97	Rewrote to support new (separate) font tables
 *
 ***********************************************************************/
void UIInitialize (void)
{
	unsigned 	i;
	VoidHand		rscH;
	Short  		rscId;
	
	
	// Make sure we haven't outgrown the space reserved for the UI globals
	if (sizeof(UIGlobalsType) > sysUIRsvGlobalsSize)
		ThisShouldGenerateALinkError();
		
		
	// In Emulation mode, save pointer to UI globals in an applicaiton global 
	//  for easier viewing in the Source level debugger
	#if EMULATION_LEVEL != EMULATION_NONE
	UIGlobalsP = (UIGlobalsPtr)GUIGlobalsP;
	#endif
	

	// In Emulation mode, these structures are already initialized to values 
	// which use resources included in the emulation app (to import app.tres
	// and sys.tres).  Now we write in values to use the resources from the
	// app.tres and sys.tres files.

	// Allocate the font tables	
	UISysFontTablePtr = MemPtrNew(UIDefNumSysFonts * sizeof(FontPtr));
	UIAppFontTablePtr = MemPtrNew(UIDefNumAppFonts * sizeof(FontPtr));

	UINumSysFonts = UIDefNumSysFonts;
	UINumAppFonts = UIDefNumAppFonts;

	// Load the system font tables and initialize the font global variables.
	for (i = 0; i < UINumSysFonts; i++)
		{
		rscId = 9000 + i;
		rscH = DmGetResource (fontRscType, rscId);
		ErrNonFatalDisplayIf (!rscH , "System font resource not found");
		if (rscH)
			UISysFontPtr[i] = (FontPtr) MemHandleLock(rscH);
		else
			UISysFontPtr[i] = NULL;
	 	}
	UICurrentFontPtr = UISysFontPtr[stdFont];
	UICurrentFontID = stdFont;


	// Get the decimal separator for the home country and store it in 
	// a global variable.
	UIDecimalSeparator = UIGetDecimalSeparator ();
}


/***********************************************************************
 *
 * FUNCTION:    UIReset
 *
 * DESCRIPTION: This routine reset the ui. It should be called before an
 *              application is launched.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/25/95	Initial Revision
 *			SCL	12/10/97	Rewrote to support new (separate) app font table
 *
 ***********************************************************************/
void UIReset (void)
{
	Int	count;

	// Allocate the globals that go in the Dynamic heap.
	
	// Allocate the event queue
	EventQ = (EventStoreType*)MemPtrNew(eventQueueSize * sizeof(EventStoreType));
	
	// Reset the key mask.
	KeySetMask(keyBitsAll);

	// Allocate the field package's undo buffer.
	UndoGlobals.buffer = (CharPtr) MemPtrNew(undoBufferSize);

	// Initialize the Event Manager
	EvtInitialize();
	
	// Initialize the App Fonts
	UICurrentFontID = stdFont;
	for (count=0; count<UINumAppFonts; count++) {
		UIAppFontPtr[count] = NULL;
	}

	// Initialize the window manager.
	InitWindowVariables ();
	
	// Initialize the form manager.
	CurrentForm = 0;
	
	// Initialize the insertion point manager
	InsPtInitialize();
	
	// Initialize the menu manager
	UICurrentMenu = 0;
	UICurrentMenuRscID = 0;
	
	// Get the decimal separator for the home country and store it in 
	// a global variable.
	UIDecimalSeparator = UIGetDecimalSeparator ();

	WinEraseWindow();
	
	// If necessary, switch back to the 'default' system display mode
	ScrDisplayMode(scrDisplayModeSetToDefaults, NULL, NULL, NULL, NULL);
}


