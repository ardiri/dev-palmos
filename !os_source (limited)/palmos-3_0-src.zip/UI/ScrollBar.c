/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     ScrollBar.c
 * AUTHOR:	 Art Lamb: Feb 13, 1996
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This module contains routines to support scroll bars. 
 *
 **********************************************************************/

#include <Pilot.h>
#include "ScrollBar.h"

#define slop					10
#define minDelay 				10
#define minCarLength			10
#define scrollBarPattern	0x55AA;		// pattern of elevator shaft


/***********************************************************************
 *
 * FUNCTION:     GetArrowLen
 *
 * DESCRIPTION:  This routine returns the lenght of the arrow heads at 
 *               the ends of the scroll bar.
 *
 * PARAMETERS:   bar - pointer to a scroll bar structure.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/17/96	Initial Revision
 *
 ***********************************************************************/
static Short GetArrowLen (ScrollBarPtr bar)
{
	Short girth;
	
	if (bar->bounds.extent.x > bar->bounds.extent.y)
		girth = bar->bounds.extent.y;
	else
		girth = bar->bounds.extent.x;

	return ((girth / 2) + 3);
}


/***********************************************************************
 *
 * FUNCTION:     GetDragLen
 *
 * DESCRIPTION:  This routine returns the length of the drag area of 
 *               the scroll bar,  which is the length of the elevator
 *               shaft minus the length of the elevator car.
 *
 * PARAMETERS:   bar - pointer to a scroll bar structure.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/17/96	Initial Revision
 *
 ***********************************************************************/
static Short GetDragLen (ScrollBarPtr bar)
{
	Short length;
	Short carLength;
	
	// Get the length of the scroll bar.
	if (bar->bounds.extent.x > bar->bounds.extent.y)
		length = bar->bounds.extent.x;
	else
		length = bar->bounds.extent.y;

	// Subtract the length of the two arrow tips.
	length -= GetArrowLen (bar) << 1;

	// Subtract the length of the elevator car.
	carLength = ((long)(bar->pageSize) * length) / 
		  	(bar->maxValue - bar->minValue + bar->pageSize);

	if (carLength < minCarLength)
		carLength = minCarLength;
		
	length -= carLength;
		  	
	return (length);
}


/***********************************************************************
 *
 * FUNCTION:     GetCarLen
 *
 * DESCRIPTION:  This routine returns the length, in pixels, of the 
 *               elevator car.
 *
 * PARAMETERS:   bar - pointer to a scroll bar structure.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/17/96	Initial Revision
 *
 ***********************************************************************/
static Short GetCarLen (ScrollBarPtr bar)
{
	Short length;
	Short carLength;
	
	// Get the length of the scroll bar.
	if (bar->bounds.extent.x > bar->bounds.extent.y)
		length = bar->bounds.extent.x;
	else
		length = bar->bounds.extent.y;

	// Subtract the length of the two arrow tips.
	length -= GetArrowLen (bar) << 1;

	if (length < 0)
		return (0);

	carLength = ((long)(bar->pageSize) * length) / 
		  	(bar->maxValue - bar->minValue + bar->pageSize);

	if (carLength < minCarLength)
		carLength = minCarLength;
		
	return (carLength);
}


/***********************************************************************
 *
 * FUNCTION:     GetCarPos
 *
 * DESCRIPTION:  This routine returns the position of the elevator car.
 *               The value returned is the offset, in pixel, from the
 *               top the the elevator shaft.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/17/96	Initial Revision
 *
 ***********************************************************************/
static Short GetCarPos (ScrollBarPtr bar)
{
	if (bar->minValue == bar->maxValue)
		return 0;
		
	return ((long)(bar->value - bar->minValue) * GetDragLen(bar) ) / 
		(bar->maxValue - bar->minValue);
}


/***********************************************************************
 *
 * FUNCTION:     DragCar
 *
 * DESCRIPTION:  This routine 
 *
 * PARAMETERS:   bar - pointer to a scroll bar structure.
 *               x   - window relative coordinate
 *               y   - window relative coordinate
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static Short DragCar (ScrollBarPtr bar, Short x,Short y, Boolean firstTime)
{   
	Short newPos;
	Short carPos;

	// Compute the offset from the top the the elevator shaft.
	if (bar->bounds.extent.x > bar->bounds.extent.y)
		newPos = x - (bar->bounds.topLeft.x);
	else
		newPos = y - (bar->bounds.topLeft.y);
	newPos += GetArrowLen (bar);

	if (firstTime)
		{
		carPos = GetCarPos (bar);
		bar->savePos = carPos;
		bar->penPosInCar = newPos - carPos;
		}
	newPos -= bar->penPosInCar;

	if (newPos < 0)
		newPos = 0;
	else if (newPos > GetDragLen (bar))
		newPos = GetDragLen (bar);
	
	return (newPos);
}   


/***********************************************************************
 *
 * FUNCTION:     GetRegionRect
 *
 * DESCRIPTION:  This routine returns the bounds of the specified region
 *               of the scroll bar.  Ex: the bounds the the down arrow 
 *               region.
 *
 * PARAMETERS:   bar   - pointer to a scroll bar structure
 *               r     - bound the the specified region (returned value)
 *               item  - scroll bar element, ex: dowr arrow.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static void GetRegionRect (ScrollBarPtr bar, RectanglePtr r, ScrollBarRegionType item)
{
   Short start, length;
	Short arrowLen;
	Short carPos;

	arrowLen = GetArrowLen (bar);;

	switch(item)
		{
		case sclUpArrow:
			start = 0;
			length = arrowLen;
			break;

		case sclDownArrow:
			start = arrowLen + GetDragLen (bar) + GetCarLen (bar);
			length = arrowLen;
			break;

		case sclUpPage:
			start = arrowLen;
			length = GetCarPos (bar); 
			break;

		case sclDownPage:
			carPos = GetCarPos (bar);
			start = arrowLen + carPos + GetCarLen (bar);
			length = GetDragLen (bar) - carPos;
			break;

		case sclCar:
			start = arrowLen + GetCarPos (bar);
			length = GetCarLen (bar);
			break;
		}

	*r = bar->bounds;
	if (r->extent.x < r->extent.y)
		{
	   r->topLeft.y += start;
		r->extent.y = length;
		}
	else
		{
	   r->topLeft.x += start;
		r->extent.x = length;
		}
}


/***********************************************************************
 *
 * FUNCTION:     InvertRegion
 *
 * DESCRIPTION:  This routine invert the region specified region of 
 *               the scroll bar.
 *
 * PARAMETERS:   r      - bounds of the region to invert
 *               region - up arrow or down arrow.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static void InvertRegion (RectanglePtr r, ScrollBarRegionType region)
{
	// Only the up and down arrows invert,  all other region are
	// ingored.
	if ( (region == sclUpArrow) || (region == sclDownArrow))
		{
		WinInvertRectangle(r,0);
		}
}


/***********************************************************************
 *
 * FUNCTION:     DrawArrow
 *
 * DESCRIPTION:  This routine draws the arrow heads on the ends of the 
 *               scroll bar
 *
 * PARAMETERS:   r         - region in which of draw
 *               direction - direction the arrow tip points
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static void DrawArrow (RectanglePtr r, Word direction)
{
	Short x, y;
	Short length;
	Short row;
	Short dx, dy;

	// Calculate point at tip of arrow.
	if (direction <= down)
		{	
		// up or down
		x = r->extent.x / 2;
		y = 1;
		length = r->extent.y - 2;
		if (direction == down) y += length-1;
		}
	else
		{	
		// right or left
		x = 1;
		y = r->extent.y / 2;
		length = r->extent.x - 2;
		if (direction == right) x += length-1;
		} 


	// Convert to actual screen location.
	x += r->topLeft.x;
	y += r->topLeft.y;

	// Draw the arrow tip.
	dx = dy = 0;
	for ( row = 0; row < length; row++)
		{
		switch(direction)
			{	
			case up:
				WinDrawLine (x-dx, y+dy, x+dx, y+dy);
				break;
			case left:
				WinDrawLine (x+dx, y-dy, x+dx, y+dy);
				break;
			case down:
				WinDrawLine (x-dx, y-dy, x+dx, y-dy);
				break;
			case right:
				WinDrawLine (x-dx, y-dy, x-dx, y+dy);
				break;
			}
		dx++;
		dy++;
		}
}


/***********************************************************************
 *
 * FUNCTION:     DrawPageScrollRegion
 *
 * DESCRIPTION:  This routine draw the page scroll regions of the scroll
 *               bar.  The page scroll regions are the areas between the
 *               arrows, above add below the car (scroll box).
 *
 * PARAMETERS:   r - region in which of draw
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static void DrawPageScrollRegion (RectanglePtr r)
{
	if (r->extent.y)
		{
//		WinEraseLine (r->topLeft.x+2, r->topLeft.y, 
//			r->topLeft.x + r->extent.x - 3, r->topLeft.y);

		r->topLeft.x += 2;
		r->extent.x -= 4;
//		r->topLeft.y += 1;
//		r->extent.y -= 2;
		WinFillRectangle (r, 0);
		
//		WinEraseLine (r->topLeft.x + 2, r->topLeft.y + r->extent.y, 
//			r->topLeft.x + r->extent.x - 3, r->topLeft.y + r->extent.y);
		}
}

/***********************************************************************
 *
 * FUNCTION:     DrawScrollCar
 *
 * DESCRIPTION:  This routine draws the eleveator car (scroll box).
 *
 * PARAMETERS:   r - region in which of draw
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *
 ***********************************************************************/
static void DrawScrollCar (ScrollBarPtr bar, RectanglePtr r)
{
	if (r->extent.x && r->extent.y)
		{
		// Erase above and below the car.
		if (bar->value > bar->minValue)	
			WinEraseLine (r->topLeft.x+2, r->topLeft.y-1, 
				r->topLeft.x + r->extent.x - 3, r->topLeft.y-1);

		if (bar->value < bar->maxValue)	
			WinEraseLine (r->topLeft.x+2, r->topLeft.y + r->extent.y, 
				r->topLeft.x + r->extent.x - 3, r->topLeft.y + r->extent.y);

		r->topLeft.x += 2;
		r->extent.x -= 4;
		WinDrawRectangle (r, 0);
		}
}

/***********************************************************************
 *
 * FUNCTION:     SclSetScrollBar
 *
 * DESCRIPTION:  This routine sets the current value, the range, and the 
 *               size of a page.  If the scroll bar is visible
 *               it will be redrawn.
 *
 * PARAMETERS:   bar      - pointer to a scroll bar structure
 *					  value    - current value (position)
 *					  min      - minimum value
 *					  max      - maximum value
 *					  pageSize - size of a page (used when page scrolling).
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/4/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void SclGetScrollBar (const ScrollBarPtr bar, const ShortPtr valueP, 
	const ShortPtr minP, const ShortPtr maxP, const ShortPtr pageSizeP)
{
	*maxP = bar->maxValue;
	*minP = bar->minValue;
	*valueP = bar->value;
	*pageSizeP = bar->pageSize;
}


/***********************************************************************
 *
 * FUNCTION:     SclSetScrollBar
 *
 * DESCRIPTION:  This routine sets the current value, the range, and the 
 *               size of a page.  If the scroll bar is visible
 *               it will be redrawn.
 *
 * PARAMETERS:   bar      - pointer to a scroll bar structure
 *					  value    - current value (position)
 *					  min      - minimum value
 *					  max      - maximum value
 *					  pageSize - size of a page (used when page scrolling).
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void SclSetScrollBar (const ScrollBarPtr bar, Short value, const Short min, 
	const Short max, const Short pageSize)
{
	Boolean redraw = false;
	
	ErrFatalDisplayIf (max < min, "Invalid scroll parameter");

	if (value < min)
		value = min;

	else if (value > max)
		value = max;

	if (bar->attr.visible)
		{
		redraw = (bar->minValue != min) ||
					(bar->maxValue != max) ||
					(bar->value != value) ||
					(bar->pageSize != pageSize);
		}

	bar->minValue = min;
	bar->maxValue = max;
	bar->value = value;
	bar->pageSize = pageSize;
	
	if (redraw)
		SclDrawScrollBar (bar);
}


/***********************************************************************
 *
 * FUNCTION:     SclDrawScrollBar
 *
 * DESCRIPTION:  This routine draws a scroll bar.
 *
 * PARAMETERS:   bar - pointer to a scroll bar structure.
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
void SclDrawScrollBar (const ScrollBarPtr bar)
{
	unsigned int i;
	RectangleType r;
	CustomPatternType savePat;
	CustomPatternType backPattern;

	// If the scroll bar is visible and the minimum and maximum value
	// are the same, erase the scroll bar.
	if (bar->minValue == bar->maxValue)
		{
		if (bar->attr.visible)
			{
			WinEraseRectangle (&bar->bounds, 0);
			bar->attr.shown = false;
			bar->attr.hilighted = false;
			}
		}

	else
		{
		for (i = 0; i < sizeof (savePat) / sizeof(*savePat); i++)
			backPattern[i] = scrollBarPattern;
			
		WinGetPattern (savePat);
		WinSetPattern (backPattern);
	
		if (! bar->attr.hilighted)
			{
			GetRegionRect (bar, &r, sclUpArrow);
			DrawArrow (&r, up | (bar->bounds.extent.x > bar->bounds.extent.y));
	
			GetRegionRect (bar, &r, sclDownArrow);
			DrawArrow (&r, down | (bar->bounds.extent.x > bar->bounds.extent.y));
			}
	
		GetRegionRect (bar, &r, sclUpPage);
		DrawPageScrollRegion (&r);
	
		GetRegionRect (bar, &r, sclDownPage);
		DrawPageScrollRegion (&r);
	
		GetRegionRect (bar, &r, sclCar);
		DrawScrollCar (bar, &r);
	
		WinSetPattern (savePat);

		bar->attr.shown = true;
		}

	bar->attr.visible = true;
}


/***********************************************************************
 *
 * FUNCTION:     SclHandleEvent
 *
 * DESCRIPTION:  This routine handled event in a scroll bar.  PenDown,
 *					  SclEnter, and SclRepeat event are handled.
 *					  When a penDown event occurs in a scroll bar, a scrEnter
                 event is added to the event queue.  When a scrEnter
                 is received, the pen is 
 *
 * PARAMETERS:   event - pointer to a event structure
 *
 * RETURNED:     true if the event was handled.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/13/96	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean SclHandleEvent (const ScrollBarPtr bar, const EventPtr event)
{
	ScrollBarRegionType  item;
	RectangleType 			r;
	RectangleType			slopRect;
	EventType   			newEvent;
	Boolean     			penDown;
	Boolean    				handled;
	Short       			x, y;
	Short						oldY;
	Short       			newValue;
	Short						penPos;
	Word  					ticks;
	Long 						lastTick;

	handled = false;

	if (!(bar->attr.usable && bar->attr.visible && bar->attr.shown))
		return (false);
	
	if (bar->minValue == bar->maxValue)
		return (false);

	if (event->eType == penDownEvent)
		{
		if (RctPtInRectangle (event->screenX, event->screenY, &bar->bounds))
			{
			EvtCopyEvent (event, &newEvent);
			newEvent.eType = sclEnterEvent;
			newEvent.data.sclEnter.scrollBarID = bar->id;
			newEvent.data.sclEnter.pScrollBar = bar;
			EvtAddEventToQueue (&newEvent);
			handled = true ;
			}
		}


	else if (event->eType == sclEnterEvent || event->eType == sclRepeatEvent)
		{
		if (event->data.sclEnter.scrollBarID != bar->id)
			return (false);

		if (event->eType == sclEnterEvent)
			{
			for (item = sclUpArrow; item <= sclCar; item++)
				{
				GetRegionRect (bar, &r, item);
				if (RctPtInRectangle (event->screenX, event->screenY, &r))
					break;
				}
			bar->attr.hilighted = false;
			bar->attr.activeRegion = item;
			lastTick = TimGetTicks ();
			}

		else
			{
			item = (ScrollBarRegionType) bar->attr.activeRegion;
			lastTick = event->data.sclRepeat.time;
			}

		GetRegionRect (bar, &r, item);

		if (item == sclCar)
			slopRect = bar->bounds;
		else
			slopRect = r;

		if ((item != sclUpPage) && (item != sclDownPage))
			RctInsetRectangle (&slopRect, -slop);
		else if (bar->bounds.extent.x > bar->bounds.extent.y)
			{
			slopRect.topLeft.y -= slop;
			slopRect.extent.y += slop << 1;
			}
		else
			{
			slopRect.topLeft.x -= slop;
			slopRect.extent.x += slop << 1;
			}

		newValue = bar->value;
		penDown = true;
		penPos = bar->savePos;
		oldY = event->screenY;
		while (penDown && (newValue == bar->value))
			{
			PenGetPoint (&x, &y, &penDown);
			if (((y - oldY) > 2) || ((y - oldY) < -2))
				oldY = y;
			else
				y = oldY;

			if ((item == sclCar) && (bar->attr.hilighted))
			   penPos = DragCar (bar, x, y, false);

			if (!penDown)
				{	
				if (bar->attr.hilighted)
					{
				   InvertRegion (&r, item);
					bar->attr.hilighted = false;
					}
				}
			else if (RctPtInRectangle (x, y, &slopRect))
				{
				if (penDown)
					{
					if (!bar->attr.hilighted)
						{
						bar->attr.hilighted = true;
						if (item == sclCar)
							penPos = DragCar (bar, x, y, event->eType == sclEnterEvent);
						else
							InvertRegion (&r,item);
						}
					}
				}
			else /* moved out of rectangle */
				{
				if (bar->attr.hilighted)
					{
					bar->attr.hilighted = false;
					if (item == sclCar)
						penPos = bar->savePos;
					else
						InvertRegion(&r,item);
					}
				}

			if (event->eType == sclEnterEvent)
				ticks = minDelay;  /* NO wait on first event */
			else
				ticks = TimGetTicks() - lastTick;

			if ((item == sclCar) || (bar->attr.hilighted && (ticks >= minDelay)))
				{
				switch (item)
					{
					case sclUpArrow:
						newValue--;
						break;
					case sclDownArrow:
						newValue++;
						break;
					case sclUpPage:
						newValue -= bar->pageSize;
						break;
					case sclDownPage:
						newValue += bar->pageSize;
						break;
					case sclCar:
						newValue = bar->minValue + (penPos * 
							((long)(bar->maxValue - bar->minValue))) /
							 GetDragLen (bar);
						break;
					}
				if (newValue > bar->maxValue) newValue = bar->maxValue;
				if (newValue < bar->minValue) newValue = bar->minValue;
				}
			}

		if ((! penDown || (newValue != bar->value)))
			{
			EvtCopyEvent (event, &newEvent);
			newEvent.screenX = x;
			newEvent.screenY = y;
			newEvent.penDown = penDown;
			newEvent.data.sclRepeat.pScrollBar = bar;
			newEvent.data.sclRepeat.value = bar->value;
			newEvent.data.sclRepeat.newValue = newValue;
			newEvent.data.sclRepeat.time = TimGetTicks();
			
			if ((newValue != bar->value))
				newEvent.eType = sclRepeatEvent;
			else
				newEvent.eType = sclExitEvent;
			EvtAddEventToQueue (&newEvent);
			}

		SclSetScrollBar (bar, newValue, bar->minValue, bar->maxValue, bar->pageSize);
			
		handled = true ;
		}

	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:     ScrollBarTest
 *
 * DESCRIPTION:  This routine tests a scroll bar.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/14/96	Initial Revision
 *
 ***********************************************************************/
extern void ScrollBarTest (void);
/*
void ScrollBarTest (void)
{
	Short value;
	Short min;
	Short max;
	Short pageSize;
	EventType event;
	ScrollBarType bar;
	
	bar.bounds.topLeft.x = 152;
	bar.bounds.topLeft.y = 18;
	bar.bounds.extent.x = 7;
	bar.bounds.extent.y = 121;
	bar.id = 1;
	bar.attr.usable = true;
	bar.attr.visible = false;
	bar.attr.hilighted = false;
	
	SclSetScrollBar (&bar, 0, 0, 1, 11);
	SclDrawScrollBar (&bar);

	SclGetScrollBar (&bar, &value, &min, &max, &pageSize);
	
	SclSetScrollBar (&bar, value+1, min, max, pageSize);

	{
	Short x = 156;
	Short y = 79;
	Short penPos, newValue;
	Short newPos;
	Short carPos;
	Short penPosInCar;
	
//	penPos = DragCar (&bar, x, y, true);
	
	newPos = y - bar.bounds.topLeft.y + GetArrowLen (&bar);

	carPos = ((long)(bar.value - bar.minValue) * GetDragLen(&bar) ) / 
		(bar.maxValue - bar.minValue + 1);

	penPosInCar = newPos - carPos;

	newPos -= penPosInCar;
	
	penPos = newPos;

	newValue = bar.minValue + (penPos * 
					((long)(bar.maxValue - bar.minValue) + 1)) /
					GetDragLen (&bar);
	}
		



	do
		{
		EvtGetEvent (&event, evtWaitForever);
		
		if (! SysHandleEvent (&event))
			SclHandleEvent (&bar, &event);
		}
	while (event.eType != appStopEvent);
}
*/