/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     seldaySelectorInfoc
 * AUTHOR:	 Roger Flores: December 2, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain the day selection routines.
 *
 **********************************************************************/

#include <Pilot.h>

#define monthGroup	1

/***********************************************************************
 *
 * FUNCTION:    SelectDayHandleEvent
 *
 * DESCRIPTION: This routine handles events in the date picker.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *       art   10/17/95 Add support for update messages
 *			kcr	11/13/95	Converted prior/next year buttons to repeating buttons
 *			roger	4/26/96	Handle selecting a month when selectByMonth
 *
 ***********************************************************************/
static Boolean SelectDayHandleEvent (EventPtr event)
	{
	char yearString[5];
	Word index;
	FormPtr frm;
	Boolean handled = true;
	Boolean redrawYear = false;
	DaySelectorPtr daySelectorInfo;

	
	frm = FrmGetActiveForm ();
	index = FrmGetObjectIndex (frm, DateSelectorDayGadget);
	daySelectorInfo = FrmGetGadgetData (frm, index);
	
	DayHandleEvent (daySelectorInfo, event);

	if (event->eType == frmUpdateEvent)
		{
		FrmDrawForm (frm);
		DayDrawDays(daySelectorInfo);
		}

	else if (event->eType == ctlSelectEvent)
		{
		if (event->data.ctlSelect.controlID >= january &&
			event->data.ctlSelect.controlID <= december)
			{
			daySelectorInfo->visibleMonth = event->data.ctlSelect.controlID;
			FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->visibleMonth);
			DayDrawDays(daySelectorInfo);
			}
		}
		
	else if (event->eType == ctlRepeatEvent)
		{
		if (event->data.ctlRepeat.controlID == DateSelectorPriorYearButton)
			{
			if (daySelectorInfo->visibleYear > daySelectorMinYear)
				{
				daySelectorInfo->visibleYear--;
				DayDrawDays(daySelectorInfo);
				redrawYear = true;
				}
			}
		else if (event->data.ctlRepeat.controlID == DateSelectorNextYearButton)
			{
			if (daySelectorInfo->visibleYear < daySelectorMaxYear)
				{
				daySelectorInfo->visibleYear++;
				DayDrawDays(daySelectorInfo);
				redrawYear = true;
				}
			}
		handled = false;		// let the ctlRepeat regain control
		}


	// If the user went to the next or prior month we may need to
	// update the day, month, and year areas.
	else if (event->eType == daySelectEvent)
		{
		if (daySelectorInfo->visibleMonth != daySelectorInfo->selected.month)
			{
			daySelectorInfo->visibleMonth = daySelectorInfo->selected.month;
			FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->selected.month);
			DayDrawDays(daySelectorInfo);
			}
		if (daySelectorInfo->visibleYear != daySelectorInfo->selected.year)
			{
			daySelectorInfo->visibleYear = daySelectorInfo->selected.year;
			DayDrawDays(daySelectorInfo);
			redrawYear = true;
			}
		}

	else if (event->eType == keyDownEvent)
		{		
		switch (event->data.keyDown.chr)
			{
			case pageUpChr:
				if (daySelectorInfo->visibleMonth == january)
					{
					if (daySelectorInfo->visibleYear > daySelectorMinYear)
						{
						daySelectorInfo->visibleYear--;
						daySelectorInfo->visibleMonth = december;
						FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->visibleMonth);
						DayDrawDays(daySelectorInfo);
						redrawYear = true;
						}
					}
				else
					{
					daySelectorInfo->visibleMonth--;
					FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->visibleMonth);
					DayDrawDays(daySelectorInfo);
					redrawYear = true;
					}
				handled = true;
				break;
				
			case pageDownChr:
				if (daySelectorInfo->visibleMonth == december)
					{
					if (daySelectorInfo->visibleYear < daySelectorMaxYear)
						{
						daySelectorInfo->visibleYear++;
						daySelectorInfo->visibleMonth = january;
						FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->visibleMonth);
						DayDrawDays(daySelectorInfo);
						redrawYear = true;
						}
					}
				else
					{
					daySelectorInfo->visibleMonth++;
					FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo->visibleMonth);
					DayDrawDays(daySelectorInfo);
					redrawYear = true;
					}
				handled = true;
				break;

			}
		}

	else 
		handled = false;

		
	if (redrawYear)
		{
		// Change year label
		StrIToA(yearString, daySelectorInfo->visibleYear);
		FrmCopyLabel(frm, DateSelectorYearLabel, yearString);
		}

	return (handled);
	}


/***********************************************************************
 *
 * FUNCTION:    SelectDay
 *
 * DESCRIPTION: Display a form showing a date and allow the user
 *              to select a different date.
 *
 * PARAMETERS:  month	- month selected
 *					 day		- day selected
 *					 year		- year selected
 *					 title	- string title for the dialog
 *
 * RETURNED:	 true if the OK button was pressed
 *					 if true the parameters passed are changed
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *       art   10/17/95 Revised to support for update messages
 *       roger 4/26/96	Now also supports selection by week and month
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean SelectDay (const SelectDayType selectDayBy, SWord *month, SWord *day, 
	SWord *year, const CharPtr title)
{
	char yearString[5];
	FormPtr originalForm, frm;
	EventType event;
	Boolean confirmed = false;
	DateTimeType today;
	DaySelectorType daySelectorInfo;
	Word buttonToUse;


	ErrNonFatalDisplayIf (*day > 31, "Invalid day");
	ErrNonFatalDisplayIf (*month > monthsInYear, "Invalid month");
	ErrNonFatalDisplayIf (*year < firstYear || lastYear < *year, "Invalid year");
	ErrNonFatalDisplayIf (title == NULL, "Invalid title");
	
	daySelectorInfo.selectDayBy = selectDayBy;

	daySelectorInfo.selected.month = *month;
	daySelectorInfo.selected.day = *day;
	daySelectorInfo.selected.year = *year;
	daySelectorInfo.visibleMonth = *month;
	daySelectorInfo.visibleYear = *year;


	// init the time info to 0 (no time)
	daySelectorInfo.selected.second = 0;
	daySelectorInfo.selected.minute = 0;
	daySelectorInfo.selected.hour = 0;

	originalForm = FrmGetActiveForm();
	frm = (FormPtr) FrmInitForm (DateSelectorForm);
	FrmSetTitle (frm, title);

	StrIToA(yearString, daySelectorInfo.selected.year);
	FrmCopyLabel(frm, DateSelectorYearLabel, yearString);

	FrmSetControlGroupSelection (frm, monthGroup, daySelectorInfo.selected.month);
	
	
	// Enable either the Today, This Week, or This Month button
	switch (selectDayBy)
		{
		case selectDayByDay:
			buttonToUse = DateSelectorTodayButton;
			break;
		
		case selectDayByWeek:
			buttonToUse = DateSelectorThisWeekButton;
			break;
		
		case selectDayByMonth:
			buttonToUse = DateSelectorThisMonthButton;
			break;
		
		default:
			ErrNonFatalDisplayIf (true, "Invalid SelectDayType");
			break;
		}
	FrmShowObject(frm, FrmGetObjectIndex(frm, buttonToUse));
	

	FrmSetActiveForm (frm);
	FrmDrawForm (frm);

	RctSetRectangle (&(daySelectorInfo.bounds), 7, 63, 140, 70);
	TimSecondsToDateTime(TimGetSeconds(), &today);
	daySelectorInfo.visible = true;
	DayDrawDaySelector (&daySelectorInfo);

	FrmSetGadgetData (frm, 
		FrmGetObjectIndex (frm, DateSelectorDayGadget), &daySelectorInfo);

	FrmSetEventHandler (frm, SelectDayHandleEvent);
	
	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);

		if (! SysHandleEvent (&event))	
			FrmDispatchEvent (&event); 


		if (event.eType == ctlSelectEvent)
			{
			if (selectDayBy == selectDayByMonth &&
				event.data.ctlSelect.controlID >= january &&
				event.data.ctlSelect.controlID <= december)
				{
				// Return with the user's choice of month.
				*month = daySelectorInfo.visibleMonth;
				*year = daySelectorInfo.visibleYear;
				
				// Make sure that the day is within the month (some months are
				// shorter than others).
				today.day = DaysInMonth(today.month, today.year);
				if (*day > today.day)
					*day = today.day;
				confirmed = true;
				break;
				}
			
			if (event.data.ctlSelect.controlID == DateSelectorCancelButton)
				break;

			// Today
			else if (event.data.ctlSelect.controlID == DateSelectorTodayButton)
				{
				// The Today button now exits the dialog.
				*month = today.month;
				*day = today.day;
				*year = today.year;
				confirmed = true;
				break;
				}

			// This week
			else if (event.data.ctlSelect.controlID == DateSelectorThisWeekButton)
				{
				// Can't use today exactly as is because we want the this week, or
				// specifically this week with the same day of the week as the 
				// original day passed in.  Adjust today to be the same day of this
				// week, and handle the fact that the day could be in a different
				// month and/or year.
				TimAdjust(&today,
					((Int) DayOfWeek(*month, *day, *year) - 
					 (Int) DayOfWeek(today.month, today.day, today.year)) * 
					 daysInSeconds);


				// The This Week button exits the dialog.
				*month = today.month;
				*day = today.day;
				*year = today.year;
				
				confirmed = true;
				break;
				}

			// This month
			else if (event.data.ctlSelect.controlID == DateSelectorThisMonthButton)
				{
				// The This Month button exits the dialog.
				*month = today.month;
				*year = today.year;
				
				// Make sure that the day is within the month (some months are
				// shorter than others).
				today.day = DaysInMonth(today.month, today.year);
				if (*day > today.day)
					*day = today.day;
				confirmed = true;
				break;
				}
			}

		else if (event.eType == daySelectEvent)
			{
			// We have a selection.  Now return it.
			if (event.data.daySelect.useThisDate)
				{
				*month = daySelectorInfo.selected.month;
				*day = daySelectorInfo.selected.day;
				*year = daySelectorInfo.selected.year;
				confirmed = true;
				break;
				}
			}
			
		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}

	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	
	FrmSetActiveForm(originalForm);

	return confirmed;
}


/***********************************************************************
 *
 * FUNCTION:    SelectDayV10
 *
 * DESCRIPTION: Display a form showing a date and allow the user
 *              to select a different date.
 *
 * THIS IS AN OUT OF DATE ROUTINE WHICH WILL DISSAPPEAR.
 *
 * PARAMETERS:  month	- month selected
 *					 day		- day selected
 *					 year		- year selected
 *					 title	- string title for the dialog
 *
 * RETURNED:	 true if the OK button was pressed
 *					 if true the parameters passed are changed
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *       art   10/17/95 Revised to support for update messages
 *       roger 4/26/96	Revised to call new routine
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean SelectDayV10 (SWord *month, SWord *day, SWord *year, const CharPtr title)
{
	return SelectDay (selectDayByDay, month, day, year, title);
}
