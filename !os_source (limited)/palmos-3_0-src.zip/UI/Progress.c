/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  PalmOS
 * FILE:     Progress.c
 * AUTHOR:	 Gavin Peacock 8/13/97
 *			(from network progess dialogs by Ron Marianetti)
 *
 * DESCRIPTION: Generic progress dialog routines. These are taken from the
 *	progress dialogs in the network library. But they are made generic so 
 *	that they can be used by any process that wants to display advancing 
 *	progress. The idea is that you can display the dialog and then go into
 *	an event loop that calls a progress dialog handler to handle any dialog
 *	specific events. The dialog can display a few lines of text that are 
 *	automatically centered and formated to display correctly. You can also 
 * specify an icon the indicates the operation in effect. The dialog has one
 *	optional button that can as a cancel or an ok button.
 * These routines are designed to to used from the UI task, but they also 
 *	support being updated from another task that my be doing lower level
 *  transactions.
 *	
 *
 **********************************************************************/

// Include Pilot headers
#include <SysAll.h>
#include <UIAll.h>
#include <SysEvtMgr.h>
#include <KeyMgr.h>

// Include defines for Network Interfaces
#include <Progress.h>


//---------------------------------------------------------------------------
// Private Constants
//---------------------------------------------------------------------------
#define	prvStrIndexOK					1				// "OK"
#define	prvStrIndexCancelling		2				// "Cancelling"
#define	prvStrIndexError				3				// "Error: "
#define	prvStrIndexUnnamed			4				// "Unnamed"

#define	prvProgressIconLeft			4				// Left coordinate for icon
#define	prvProgressIconTop			12				// Top coordinate for icon 12

#define	prvProgressTextLeft			40				// Left coordinate for text 40
#define	prvProgressTextTop			12				// Top coordinate for text
#define	prvProgressTextHeight		52				// height of text
#define	prvProgressTextWidth			110			// width of text 110


//---------------------------------------------------------------------------
// Private Functions
//---------------------------------------------------------------------------
static void PrvUpdateDialog(ProgressPtr prgP);

/***********************************************************************
 *
 * FUNCTION:    PrgUpdateDialog
 *
 * DESCRIPTION: 
 *		This procedure can be used by the protocol task to tell the UI
 *		task what to display. Calls to this procedure can be interspersed
 *		throughout the protocol code to display progress messages.
 *		If this is not called from the UI task, updateNow must be false. This 
 *		will cause the UI task to wake up and it can then call PrgHandleEvent to
 *		update the progress dialog. If called from the UI task, set updateNow true
 *		and the dialog will be updated immediately.
 *		
 *
 * CALLED BY:	 Protocol or UI task to tell UI task what to display
 *
 * PARAMETERS:  prgP - progress data pointer
 *				err  - current error if any
 *				stage - current stage of progress (passed to callback)
 *				messageP - additional text describing this stage
 *				updateNow - boolean - true if called from the UI task
 *
 * RETURNED:    0 if no error.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			Gavin	8/13/97		Initial Revision
 *
 ***********************************************************************/
void	PrgUpdateDialog(ProgressPtr prgP, Word err, Word stage,
					CharPtr	messageP,Boolean updateNow)
{
	
	ErrNonFatalDisplayIf(!prgP,"Null Progress Pointer");
	if (!prgP) return;
	
	// prgP->needUpdate = false;
	prgP->messageChanged = false;  // record if message actually changed

	// Disable task switching so the UI doesn't get partial info
	if (!updateNow) SysTaskSwitching(false);
	
	// Update the stage globals
	if (stage != prgP->stage)
		{
		prgP->stage = stage;
		prgP->needUpdate = true;
		}
		
	if (messageP)
		{ if (StrNCompare(prgP->message,messageP, progressMaxMessage)!=0)
			{
			StrNCopy(prgP->message, messageP, progressMaxMessage);
			prgP->messageChanged = true;
			prgP->needUpdate = true;
			}
		}
	else if (prgP->message[0]) 
		{
		prgP->message[0] = 0;
		prgP->messageChanged = true;
		prgP->needUpdate = true;
		}
		
	// Record error, if any
	if (err != prgP->error)
		{
		prgP->error = err;
		prgP->needUpdate = true;
		}
		
	if (updateNow)
		PrvUpdateDialog(prgP);
	else
		{
		// Renable switching
		SysTaskSwitching(true);

		// Make the UI wake up to update the progress dialog
		EvtWakeup();
		}
}



/***********************************************************************
 *
 * FUNCTION:    PrgHandleEvent
 *
 * DESCRIPTION: This routine is used to process progress dialog events. An
 *				application should first call PrgStartDialog, then drop into a 
 *				loop that gets events and calls this function to handle them. If
 *				This function does not handle an event, the app can check the 
 *				event to see if it should stop. If the user hits the cancel 
 *				button in the progress dialog, this function will return false and
 *				the calling app should call PrgUserCancel() to see if the process
 *				has been canceled.
 *				This routine will not allow autoOff events to be processed unless the
 *				diallog is just displaying an error. It also prevents appStop events.
 * 
 *
 * CALLED BY:	 UI task to check for events and update UI as connection progresses.
 *
 * PARAMETERS:  prgGP - pointer to progress data
 *				eventP - current event to process
 *
 * RETURNED:    true if the event was handled by this routine
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			Gavin   8/13/97		Initial Revision
 *
 ***********************************************************************/
Boolean	PrgHandleEvent(ProgressPtr prgP,EventPtr eventP)
{
	Word			error;
	Boolean			handled = true;  // assume we handle most all events

				
	if (!prgP) 
		{
		// allow system events to be processed...
		//if (eventP)
		//	{
		//	if (! SysHandleEvent (eventP))
		//		if (! MenuHandleEvent (0, eventP, &error))
		//			FrmHandleEvent (FrmGetActiveForm(),eventP);
		//	}
		return false;
		}
	if (!eventP) {	// you can pass null for event to just update the dialog
		PrvUpdateDialog(prgP);
		return false;
		}

	// Filter out some key events
	if (eventP->eType == keyDownEvent) {
		switch (eventP->data.keyDown.chr) {
			case autoOffChr:
				// Don't allow auto-off events unless we're just displaying an error and
				//	waiting for the user to hit OK
				// Note: handled set to true at routine entry
				if (!prgP->error) goto Exit;
				break;
				
			case ronamaticChr:
				// Disallow bringing up anything while the dialog is up
				// Note: handled set to true at routine entry
				goto Exit;
				break;
				
			case pageDownChr:
				prgP->showDetails = true;
				prgP->needUpdate = true;
				break;
			}
		}
		
	// Pass system events off to system.	
	if (! SysHandleEvent (eventP))
		if (! MenuHandleEvent (0, eventP, &error))
			FrmHandleEvent (prgP->frmP,eventP);


	//---------------------------------------------------------------------------
	// Handle our own events here.
	//---------------------------------------------------------------------------
	if (eventP->eType == ctlSelectEvent) {
		switch (eventP->data.ctlSelect.controlID) {
		
			// The "Cancel" button has a dual purpose - it is renamed to the "OK" button
			//  if we've encountered and displayed an error message in the dialog 
			//  and are waiting for the user to acknowledge the error
			case prgProgressBtnCancel:
				// If we were just waiting for an OK, exit
				if (prgP->waitingForOK || prgP->error) {handled = false; goto Exit;}
				
				// else, post a cancel
				prgP->cancel = true;
				prgP->needUpdate = true;
				handled = false;  // indicate not handled so app knows about user cancel
				break;
			}
		}

	// Quitting the app is not allowed while the progress dialog is up
	else if (eventP->eType == appStopEvent) 
		SndPlaySystemSound(sndWarning);
		
		
	// update the progress dialog
	PrvUpdateDialog(prgP);
	
Exit:
	return  handled;
}
	
			
/***********************************************************************
 *
 * FUNCTION:    PrvUpdateDialog
 *
 * DESCRIPTION: Updates the display of a dialog opened with PrgStartDialog
 *				This checks the needUpdate field of the progress structure.
 *				If there are changes that need to be displayed, this will 
 *				display them. 
 *
 * CALLED BY:	 Any UI task routine that wants to update the progress dialog.
 *				This function does not change the state of the dialog, it just
 *				updates the display. 
 *
 * PARAMETERS:  prgP - pointer to progress info Started with PrgStartDialog.
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			gavin	8/13/97	Initial Revision
 *
 ***********************************************************************/
static void PrvUpdateDialog(ProgressPtr prgP)
{		
	const int		maxTextLen = progressMaxMessage; 
	CharPtr 		textP = 0;
	Word			bitmapID;
	Word 			curError;
	Word 			curStage;
	CharPtr 		curMessageP = 0;
	Boolean	 		curCancel;
	RectangleType	r;
	ControlPtr 		ctlP;
	Word			chars;
	CharPtr			cP;
	Word			textLen, lines, lineHeight;
	FontID			oldFont;
	Handle			resH;
	Boolean			delay = false;
	PrgCallbackData	tcP;
	Boolean 		timedOut = false;
	
	if (!prgP) return;
	
	// The textcallback can set a timeout value in ticks
	// if the timeout expires, we clear the timeout value 
	// and force an update  The textCallback will be passed a timedOut flag
	if (prgP->timeout && (TimGetTicks() > prgP->timeout))
		{
		prgP->timeout = 0;
		// set timedout cause only if there wasn't already an update pending...
		if (!prgP->needUpdate) timedOut = true; 
		prgP->needUpdate = true;
		}
	//------------------------------------------------------------------------
	// See if our connection stage has changed, and if so update the string
	//------------------------------------------------------------------------
	if (prgP->needUpdate ) 
		{
		
		// Allocate a buffer for holding the new text
		textP = MemPtrNew(maxTextLen+1);
		if (!textP) {
			goto Exit;
			}
		// Init text variable
		textP[0] = 0;

		// Allocate a buffer for message text from comm layer
		curMessageP = MemPtrNew(progressMaxMessage+1);
		if (!curMessageP) {
			goto Exit;
			}
		// Disable task switching while we fetch the current info and message
		SysTaskSwitching(false);
		
		curStage = prgP->stage;
		curCancel = prgP->cancel;
		StrNCopy(curMessageP, prgP->message, progressMaxMessage);
		curError = prgP->error;
		prgP->needUpdate = false;
		
		SysTaskSwitching(true);
		
		tcP.stage = curStage;
		tcP.textP = textP;
		tcP.textLen = maxTextLen;
		tcP.message = curMessageP;
		tcP.canceled = curCancel;
		tcP.error = curError;
		tcP.bitmapId = prgP->lastBitmapID;
		tcP.showDetails = prgP->showDetails;
		tcP.timedOut = timedOut;
		tcP.textChanged = true;		// assume text changed unless this is cleared
		tcP.timeout = prgP->timeout;
		
		//if (!(prgP->textCallback)(curStage,prgP->showDetails,curMessage,curCancel,curError,textP,maxTextLen,&bitmapID))
		if (!(prgP->textCallback)(&tcP))
			{
			// add some default handlers in case the callback does not handle it...
			
			// If the protocol task hasn't recognized the cancel yet, the boolean
			//  will still be set with no error yet
			if (curCancel && !curError ) {
				SysStringByIndex(prgStringList, prvStrIndexCancelling, textP, maxTextLen);	
				}
				
			// If we got a connection error, display it.
			else if (curError) {
				SysStringByIndex(prgStringList, prvStrIndexError, textP, maxTextLen);	
				SysErrString(curError, textP+StrLen(textP), 
													maxTextLen-StrLen(textP));
				bitmapID = prgPictError;
				}
			else 
				{	
				// unknown stage message....			
				SysStringByIndex(prgStringList, prvStrIndexUnnamed, textP, maxTextLen);	
				}
			}
		else
			{
			// the text callback can modify any of these values...
			prgP->timeout = tcP.timeout;
			curCancel = tcP.canceled;
			curError = tcP.error;
			bitmapID = tcP.bitmapId;
			}
		//-----------------------------------------------------------------------
		// Update the text
		//-----------------------------------------------------------------------
		if (tcP.textChanged)
			{
			// Form the enclosing rect for the text area
			r.topLeft.x = prvProgressTextLeft;
			r.topLeft.y = prvProgressTextTop;
			r.extent.x = prvProgressTextWidth;
			r.extent.y = prvProgressTextHeight;

			// Get the height of each line
			oldFont = FntSetFont(boldFont);
			lineHeight = FntLineHeight();
			
			// Calculate how many lines we'll need to display our text
			textLen = StrLen(textP);
			cP = textP;
			for (lines = 1; 1; lines++) {
				chars = FldWordWrap(cP, r.extent.x);
				if (!chars) break;
				textLen -= chars;
				cP += chars;
				if (!textLen) break;
				}
				
			// Erase the old text
			WinEraseRectangle(&r, 0);

			// Leave an equal amount on top and bottom of text
			if (lineHeight * lines < r.extent.y) 
				r.topLeft.y += (r.extent.y - lineHeight * lines) / 2;
			else 
				lines = r.extent.y / lineHeight;
				
			// Draw the new text, Get rid of newLines because they can't be drawn.
			cP = textP;
			while(lines--) {
				chars = FldWordWrap(cP, r.extent.x);
				if (cP[chars-1] == '\n') cP[chars-1] = ' ';
				WinDrawChars(cP, chars, r.topLeft.x, r.topLeft.y);
				cP += chars;
				r.topLeft.y += FntLineHeight();
				}
			
			// Restore font
			FntSetFont(oldFont);
		}		

		//-----------------------------------------------------------------------
		// Update the ICON if it changed
		//-----------------------------------------------------------------------
		if (bitmapID != prgP->lastBitmapID) {
			resH = DmGetResource(bitmapRsc, bitmapID);
			if (resH) {
				WinDrawBitmap(MemHandleLock(resH), prvProgressIconLeft, prvProgressIconTop);
				MemHandleUnlock(resH);
				prgP->lastBitmapID = bitmapID;
				}
			}


		ctlP = FrmGetObjectPtr (prgP->frmP, FrmGetObjectIndex (prgP->frmP, prgProgressBtnCancel));
		
		if (curCancel && !curError ) 
			{
			// hide the cancel button while cancelling
			CtlHideControl(ctlP);
			}
		// If we got a connection error
		else if (curError && !curCancel)  //  && curError != obxErrUserCancel) 
			{
			// Show the control in the somewhat unlikely case that the Network Interface code encountered
			//  an error during the cancel process (which hid the control) and needs to display it. 
			CtlShowControl(ctlP);
			CtlSetLabel(ctlP, SysStringByIndex(prgStringList, prvStrIndexOK, 
													prgP->ctlLabel, sizeof(prgP->ctlLabel)-1));
			CtlDrawControl(ctlP);
			
			// Set boolean indicating we need a hit on the OK button before
			//  we can exit
			prgP->waitingForOK = true;
			}
				

	// Display success and connect speed messages for a second before we close dialog
	if (delay)
		SysTaskDelay(sysTicksPerSecond*1);

	}
	
Exit:
	if (textP)
		MemPtrFree(textP);
	if (curMessageP)
		MemPtrFree(curMessageP);
		
}




/***********************************************************************
 *
 * FUNCTION:    PrgStartDialog
 *
 * DESCRIPTION: Display a progress dialog that can be updated by another
 *				process. The dialog can contain a cancel or OK button. This
 *				function returns a pointer to an allocated progress structure.
 *				The pointer must be passed to all other progress functions and
 *				MUST be released by calling PrgStopDialog.
 *
 *
 * CALLED BY:	 Any UI task routine that wants to display progress info 
 *
 * PARAMETERS:  textCallBack - pointer to callback function that will supply
 *								text and icons for the current progress state.
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			gavin	8/13/97	Initial Revision
 *
 ***********************************************************************/
ProgressPtr	PrgStartDialog(CharPtr titleP,PrgCallbackFunc textCallback)
{
	ProgressPtr		prgP;
	
	prgP = MemPtrNew(sizeof(*prgP));
	ErrNonFatalDisplayIf(!prgP,"Unable to alloc progress data");
	if (!prgP) return 0;
	
	MemPtrSetOwner(prgP,0);
	MemSet(prgP, sizeof(*prgP), 0);
	
	// save the current form and info
	prgP->oldFrmP = FrmGetActiveForm();
	if (!prgP->oldFrmP) {
		prgP->oldDrawWinH = WinGetDrawWindow();
		prgP->oldActiveWinH = WinGetActiveWindow();
		}
	prgP->oldInsPtState = InsPtEnabled();
	InsPtGetLocation(&prgP->oldInsPtPos.x, &prgP->oldInsPtPos.y);
	
	
	// Init the form
	prgP->frmP = FrmInitForm(prgProgressFrm);
	ErrNonFatalDisplayIf(!prgP->frmP,"Unable to init progress form");
	if (!prgP->frmP) 
		{
		MemPtrFree(prgP);
		return 0;
		}
	MemPtrSetOwner(prgP->frmP,0);
	FrmSetActiveForm(prgP->frmP);

	if (titleP && *titleP)
	    StrNCopy(prgP->title,titleP,progressMaxTitle);
	else
		prgP->title[0] = 0;
		
	if (prgP->title[0])
		FrmSetTitle (prgP->frmP,prgP->title);

	prgP->textCallback = textCallback;
	prgP->needUpdate = false;
	prgP->cancel = false;
	prgP->waitingForOK = false;
	prgP->error = 0;
	prgP->showDetails = 0;
	prgP->lastBitmapID = 0;
	
	prgP->stage = 0;
	
	prgP->needUpdate = true;				// to force an update in PrvConCheckevents

	prgP->timeout = 0;     					

	// If the down key is pressed, show progress details
	if (KeyCurrentState() & keyBitPageDown)
		prgP->showDetails = true;

	// Display it 
	if (!prgP->frmP->attr.visible)
		FrmDrawForm(prgP->frmP);

return (prgP);

}		
	
/***********************************************************************
 *
 * FUNCTION:    PrgStopDialog
 *
 * DESCRIPTION: Removes a Progress dialog that was opened wiht PrgStartDialog.
 *
 * CALLED BY:	 Any UI task routine that wants to remove the progress dialog 
 *
 * PARAMETERS:  prgP - pointer to progress info Started with PrgStartDialog.
 *				force - if true do not wait for the user to confirm an error
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		----------- 
 *			gavin	8/13/97	Initial Revision
 *
 ***********************************************************************/
void PrgStopDialog(ProgressPtr prgP,Boolean force)
{		
	ErrNonFatalDisplayIf(!prgP,"Null Progress Pointer");
	if (!prgP) return;
	
	if (prgP->waitingForOK && !force) {
		// wait until user oks the dialog
		EventType event;
		do {
			EvtGetEvent(&event,evtWaitForever);
		} while (PrgHandleEvent(prgP,&event));
	}
	
	FrmEraseForm(prgP->frmP);
	InsPtSetLocation(prgP->oldInsPtPos.x, prgP->oldInsPtPos.y);
	FrmSetActiveForm(prgP->oldFrmP);
	FrmDeleteForm(prgP->frmP);
	if (!prgP->oldFrmP) {
		WinSetDrawWindow(prgP->oldDrawWinH);
		WinSetActiveWindow(prgP->oldActiveWinH);
		FrmSetActiveForm(prgP->oldFrmP);
		}

	MemPtrFree(prgP);
}


