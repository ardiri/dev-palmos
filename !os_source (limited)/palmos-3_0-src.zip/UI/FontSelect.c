/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Font.c
 * AUTHOR:	 Art Lamb: September 10, 1997
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain the font selector routines.
 *
 **********************************************************************/

#include <Pilot.h>

#define font1				stdFont
#define font2				boldFont
#define font3				largeBoldFont


/***********************************************************************
 *
 * FUNCTION: 	 FontSelect
 *
 * DESCRIPTION: This routine displays the font selection dialog.
 *
 * PARAMETERS:	 fontID - initial setting of the dialog.
 *					
 * RETURNED:	 the font id of the selected font.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/10/97	Initial Revision
 *
 ***********************************************************************/
FontID FontSelect (FontID fontID)
{
	Word			index;
	Word			ctlID;
	Word			buttonHit;
	FormPtr		frm;
	

	frm = FrmInitForm (FontSelectorForm);


	// Set the font setting in the dialog.
	switch (fontID)
		{
		case font1:	ctlID = FontSelector1Button;		break;
		case font2:	ctlID = FontSelector2Button;		break;
		case font3:	ctlID = FontSelector3Button;		break;
		}
	FrmSetControlGroupSelection (frm, FontSelectorFontGroup, ctlID);


	// Display the font selector.
	buttonHit = FrmDoDialog (frm);
	

	// Get the font setting from the dialog if the "OK" button 
	// has pressed.
	if (buttonHit == FontSelectorOKButton)
		{
		index =  FrmGetControlGroupSelection (frm, FontSelectorFontGroup);
		switch (FrmGetObjectId (frm, index))
			{
			case FontSelector1Button:	fontID = font1;	break;
			case FontSelector2Button:	fontID = font2;	break;
			case FontSelector3Button:	fontID = font3;	break;
			}
		}


	FrmDeleteForm (frm);
	
	return (fontID);
}

