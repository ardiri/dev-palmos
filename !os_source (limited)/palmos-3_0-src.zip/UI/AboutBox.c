/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     AboutBox.c
 * AUTHOR:	 Christopher Raff: Oct 25, 1995
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This is the generic 'about box' that is used by the main applications.
 *
 **********************************************************************/

#include <Pilot.h>

/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/

/***********************************************************************
 *
 *	Internal Structutes
 *
 ***********************************************************************/

/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/

/***********************************************************************
 *
 *	Internal Functions
 *
 ***********************************************************************/

/***********************************************************************
 *
 * FUNCTION:		AbtShowAbout
 *
 * DESCRIPTION:	This routine displays the info dialog box.  The app name
 *						will be picked up from either the tAIN resource of the
 *						app, or the name of the application database.
 *
 * PARAMETERS:		ULong				creator - creator ID of this app
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/11/95	Initial Revision
 *			kcr	10/25/95	converted to a generic routine
 *			kcr	11/8/95	use tAIN for app name.
 *			kcr	12/7/95	add app name to title; check length of version str.
 *			mlb	1/30/96	change scan for location of app name in title to look for '%'
 *                      instead of a blank (which caused localization problems).
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void AbtShowAbout (const ULong creator)
	{
	FormPtr 					frm;
	CharPtr					str, tstr;
	CharPtr					ptr;
	CharPtr					strP;
	int						len;
#if EMULATION_LEVEL == EMULATION_NONE
	char						name [dmDBNameLength];
	Err						err;
	DmOpenRef				dbP;
	DmSearchStateType		searchState;
	LocalID					dbID;
	UInt						cardNo;
#endif
	VoidHand strH;

	frm = FrmInitForm (aboutDialog);

	//	Load the app name string.  Also insert app name into title.
	str = FrmGetLabel (frm, aboutNameLabel);
	tstr = FrmGetTitle (frm);
	ptr = StrChr (tstr, '%');
	ErrNonFatalDisplayIf(ptr == NULL, "Title missing '%'");
	// ptr++;		// mlb.  begin the substitution on top of the % character


#if EMULATION_LEVEL != EMULATION_NONE
	StrCopy (str, "<appname>");
	StrCopy (ptr, "<appname>");
#else
	//	This is involved - locate apps 'appl' database, open it, fetch
	//	tAIN resource.  If it exists, use it as name.  If no tAIN
	//	resource, use name of 'app' database.  Close 'appl' database.
	err = DmGetNextDatabaseByTypeCreator (true, &searchState,
			 			sysFileTApplication, creator, false,
			 			&cardNo, &dbID);
	if (err)
		goto exit;

	dbP = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
	if (!dbP)
		goto exit;

	strH = DmGet1Resource (ainRsc, ainID);
	if (strH)
		{
		strP = MemHandleLock (strH);
		StrCopy (str, strP);
		StrCopy (ptr, strP);
		MemHandleUnlock (strH);
		DmReleaseResource (strH);
		}
	else
		{
		DmDatabaseInfo(cardNo, dbID, name, NULL, NULL, NULL, NULL, 
						NULL, NULL, NULL, NULL, NULL, NULL);
		StrCopy (str, name);
		StrCopy (ptr, name);
		}
	DmCloseDatabase(dbP);
#endif

	// load the version string.
	str = FrmGetLabel (frm, aboutVersionLabel);
	ptr = StrChr (str, ' ');
	ptr++;
	len = StrLen (ptr);					//	This is the space we have for the
												//	version string.
	strH = DmGetResource (verRsc, appVersionID);
	if (strH)
		{
		strP = MemHandleLock (strH);
		while (len > 0 && *strP)
			{
			*ptr++ = *strP++;
			len--;
			}
		*ptr = 0;
		MemHandleUnlock (strH);
		DmReleaseResource (strH);
		}
	else
		{
		strH = DmGetResource (strRsc, aboutErrorStr);
		StrCopy (str, MemHandleLock (strH));
		MemHandleUnlock (strH);
		DmReleaseResource (strH);
		}

	FrmDoDialog (frm);
	
exit:
 	FrmDeleteForm (frm);
	}	//	end of AbtShowAbout


