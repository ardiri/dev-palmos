/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Form.c
 * AUTHOR:	 Art Lamb: November 7, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain the form object routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <Keyboard.h>
#include <Hardware.h>				// hwrDisplayWidth

#define fmrCornerDiam 				0

#define titleFont						boldFont
#define titleHeight 					15
#define titleMarginX 				3	// Don't forget the blank column after the last char
#define titleMarginY 				2

#define helpButtonWidth				10
#define helpCornerRadius			5

#define maxCategoryLabelWidth		80

#define frmMinFreeBytes		4000	// The bits obscured by a form will not be
											// saved if the free memory is below this
											// limit.

#define prvActiveStateSignature	0x55	// signature used for PrvActiveStateType


// PrvActiveStateType: Internal structure used by FrmActiveState();
// this structure abstracts the saved state data from the caller as this information
// will likely need to change in the future.  Callers use the structure
// FormActiveStateType instead.
//
typedef struct PrvActiveStateType {
	Byte			sig;					// set to prvActiveStateSignature when state is being saved;
											// this is used by EC code to detect if restore has been
											// envoked without saving first (this field can be reused
											// for other purposes if needed)

	Boolean		insPtState;			// enabled state of insertion point
	FormPtr		curForm;				// current active form
	PointType	insPtPos;			// position of insertion point
	WinHandle	savedDrawWin;		// draw window handle
	WinHandle	savedActiveWin;	// active window handle
	DWord			dwReserved;			// reserved for future extensions
	} PrvActiveStateType;
	
	

// This declaration is used for performing link-time assertions
static void ThisShouldGenerateALinkError(void);




/***********************************************************************
 *
 * FUNCTION: 	 FrmGetWindowHandle
 *
 * DESCRIPTION: This routine returns the window handle of a form.
 *
 * PARAMETERS:	 frm	memory block that contains the form.
 *					
 * RETURNED:	 The segment of the memory block that the form is in,  since 
 *              the form structure begins with the WindowType structure this
 *              is also a WinHandle.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
WinHandle FrmGetWindowHandle (const FormPtr frm)
{
	return (WinGetWindowHandle (frm));
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmInitForm
 *
 * DESCRIPTION: This routine loads and initializes a form resource.
 *
 * PARAMETERS:	 rscID	the resource id of the form.
 *					
 * RETURNED:	 The handle of the memory block that the form is in,  since 
 *              the form structure begins with the WindowType structure this
 *              is also a WinHandle.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
FormPtr FrmInitForm (const Word rscID)
{
	FormPtr frm;


#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	frm = FrmGetFormPtr (rscID);
	ErrFatalDisplayIf ((frm), "Form already loaded");
#endif	

	frm = ResLoadForm (rscID);

	WinInitializeWindow (FrmGetWindowHandle(frm));

	WinAddWindow (FrmGetWindowHandle(frm));
	
	frm->window.windowFlags.dialog = true;
	
	frm->focus = noFocus;

	return(frm);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmDeleteForm
 *
 * DESCRIPTION: This routine release the memory occupied by a form.  Any
 *              memory allocated by object in the form is also relased.
 *
 * PARAMETERS:	 frmHandle	the handle of memory block that contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmDeleteForm (const FormPtr frm)
{
	Word i;
	MenuBarPtr menuP;
	
	ECFrmValidatePtr(frm);
	
	if (frm == CurrentForm) 
		{
		CurrentForm = NULL;
		
		menuP = MenuGetActiveMenu ();
		if (menuP)
			{
			MenuDispose (menuP);
			MenuSetActiveMenu (NULL);
			}
		}
	
	// Release any memory that field object may have allocated.
	for (i = 0; i < frm->numObjects; i++)
		{
		if  (frm->objects[i].objectType == frmFieldObj)
			FldFreeMemory (frm->objects[i].object.field);
		}
	
	WinDeleteWindow (FrmGetWindowHandle(frm), false);
}


/***********************************************************************
 *
 * FUNCTION: 	 DrawTitle
 *
 * DESCRIPTION: This routine draws a dotted line
 *
 * PARAMETERS:	 x1  x coordinate of the start of the line
 *              y2  y coordinate of the start of the line
 *              x2  x coordinate of the end of the line
 *              y2  y coordinate of the end of the line
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *
 ***********************************************************************/
static void DrawDottedLine (short x1, short y1, short x2, short y2)
{
	CustomPatternType pattern;
	CustomPatternType savedPattern;

	MemSet (pattern, sizeof (CustomPatternType), 0x88);
	WinGetPattern (savedPattern);
	WinSetPattern (pattern);
	WinFillLine (x1, y1, x2, y2);
	WinGetPattern (savedPattern);
}

/***********************************************************************
 *
 * FUNCTION: 	 DrawTitle
 *
 * DESCRIPTION: This routine draws the title of a form.
 *
 * PARAMETERS:	 frmHandle	the handle of memory block the contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *
 ***********************************************************************/
static void DrawTitle (FormPtr frm, FormTitleType * title)
{
	char * text;
	char ch;
	short textLen;
	short x;
	short windowWidth;
	short windowHeight;	
	FontID currFont;
	RectangleType r;

	currFont = FntSetFont (titleFont);
	text = title->text;
	if (title)
		textLen = StrLen (text);
	else
		textLen = 0;
	WinGetWindowExtent (&windowWidth, &windowHeight);
	
	if (frm->window.windowFlags.modal)
		{
		r.topLeft.x = 0;
		r.topLeft.y = 1;
		r.extent.x = windowWidth;
		r.extent.y = FntLineHeight ();
		x  = (windowWidth - FntCharsWidth (text, textLen) + 1) >> 1;
		WinDrawLine (1, 0, r.extent.x-2, 0);
		WinDrawRectangle (&r, 0);
		WinInvertChars (text, textLen, x, 0);
		
		// Draw the help icon if the dialog was a help message.
		if (frm->helpRscId)
			{
			FntSetFont (symbolFont);
			r.topLeft.x = windowWidth - helpButtonWidth - 2;
			r.topLeft.y = 0;
			r.extent.y = helpButtonWidth;
			r.extent.x = helpButtonWidth;
			WinEraseRectangle (&r, helpCornerRadius);
			ch = symbolHelp;
			x = r.topLeft.x + ((r.extent.x - FntCharWidth (ch)) /2);
			WinDrawChars (&ch, 1, x, 0);
			}
		}

	else if (title->rect.extent.x == windowWidth)
		{
		x  = (windowWidth - FntCharsWidth (text, textLen) + 1) >> 1;
		RctSetRectangle (&r, 0, 0, windowWidth, FntLineHeight() + 2);
		WinDrawRectangle (&r, 3);
		WinInvertChars (text, textLen, x, 1);		
		}

	else
		{
		FntSetFont (titleFont);
		r.topLeft.x = 0;
		r.topLeft.y = 0;
		r.extent.x = FntCharsWidth (text, textLen) + titleMarginX + (titleMarginX - 1);
		r.extent.y = titleHeight;
		WinDrawRectangle (&r, 3);
		WinInvertChars (text, textLen, titleMarginX, titleMarginY);
		
		// Draw a under the title from the left edge of window to the right
		// edge.
		RctSetRectangle (&r, 0, titleHeight - 2, windowWidth, 2);
		WinDrawRectangle (&r, 0);
		}
	FntSetFont (currFont);

}

/***********************************************************************
 *
 * FUNCTION: 	 DrawLabel
 *
 * DESCRIPTION: This routine draws a label object of a form.
 *
 * PARAMETERS:	 frm		pointer to memory block the contains the form.
 *              label   pointer to a label object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *
 ***********************************************************************/
static void DrawLabel (FormLabelType * label)
{
	CharPtr text;
	CharPtr ptr;
	Word len;
	short y;
	
	if (! label->attr.usable) return;

	FntSetFont (label->fontID);
	text = label->text;
	y = label->pos.y;
	
	while (true)
		{
		ptr = StrChr (text, crChr);
		if (ptr)
			len = ptr - text;
		else
			len = StrLen (text);

		WinDrawChars (text, len, label->pos.x, y);
		
		if (! ptr) break;

		text = ptr + 1;
		y += FntLineHeight ();
		}
}

/***********************************************************************
 *
 * FUNCTION: 	 GetLabelBounds
 *
 * DESCRIPTION: This routine returns the bounds of a label object.
 *
 * PARAMETERS:	 label   pointer to a label object
 *              r			pointer to rectangle to hold bounds
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	1/7/96	Initial Revision extracted from eraseLabel
 *
 ***********************************************************************/
static void GetLabelBounds (FormLabelType * label,RectanglePtr r)
{
	Word len;
	Word width;
	Word height;
	CharPtr ptr;
	CharPtr text;
	FontID curFont;

	curFont = FntSetFont (label->fontID);

	// Compute the height of the label
	text = label->text;
	height = 1;
	width = 0;
	while (true)
		{
		ptr = StrChr (text, crChr);
		if (ptr)
			len = ptr - text;
		else
			len = StrLen (text);

		width = max (width, FntCharsWidth (text, len));
		
		if (! ptr) break;

		text = ptr + 1;
		height++;
		}
	
	r->topLeft.x = label->pos.x;
	r->topLeft.y = label->pos.y;
	r->extent.x = width;
	r->extent.y = FntLineHeight() * height;
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION: 	 EraseLabel
 *
 * DESCRIPTION: This routine erases a label object of a form.
 *
 * PARAMETERS:	 frm		pointer to memory block the contains the form.
 *              label   pointer to a label object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/5/95	Initial Revision
 *			gavin 1/7/97   Moved code into GetLabelBounds
 *
 ***********************************************************************/
static void EraseLabel (FormPtr frm, FormLabelType * label)
{
	RectangleType r;

	if (!frm->attr.visible) return;

	GetLabelBounds(label,&r);
	WinEraseRectangle (&r, 0);
}

/***********************************************************************
 *
 * FUNCTION: 	 GeBitmapBounds
 *
 * DESCRIPTION: This routine returns the bounds of a bitmap object.
 *
 * PARAMETERS:	 label   pointer to a bitmap object
 *              r			pointer to rectangle to hold bounds
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	1/7/96	Initial Revision extracted from FrmHideObject
 *
 ***********************************************************************/
static void GetBitmapBounds (FormBitmapType * bitmapP,RectanglePtr r)
{
	VoidHand resH;
	BitmapPtr bitmap;

	resH = DmGetResource (bitmapRsc, bitmapP->rscID);
	bitmap = MemHandleLock (resH);
	r->topLeft.x = bitmapP->pos.x;
	r->topLeft.y = bitmapP->pos.y;
	r->extent.x = bitmap->width;
	r->extent.y = bitmap->height;
	MemHandleUnlock (resH);
}

/***********************************************************************
 *
 * FUNCTION:    RedrawDisplay
 *
 * DESCRIPTION: This routine sends a frmUpdate event to all visible forms.
 *
 * PARAMETERS:  updateR - region to update
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/2/95	Initial Revision
 *
 ***********************************************************************/
static void RedrawDisplay (RectanglePtr updateR)
{
	WinPtr winPtr;
	FormPtr frm;
	FormPtr curForm;
	Boolean handled;
	EventType event;
	WinHandle winHandle;
	WinHandle curDrawWindow;
	RectangleType r;
	RectangleType clipR;
	RectangleType formR;
	RectangleType saveClipR;
	
		
	// By convention each forms covers the entire width of the display, and
	// is bottom justified.  If this convention has been followed, then we
	// can optimize the display refresh by drawing the forms front-most to
	// rear-most.  First we need to check if our convention has been 
	// followed.
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	{
	Short displayWidth, displayHeight;
	Boolean optimize = false;

	WinGetDisplayExtent (&displayWidth, &displayHeight);
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			WinGetWindowFrameRect (winHandle, &r);
			if ((r.topLeft.x > 0) || (r.extent.x < displayWidth) ||
				 (r.topLeft.y + r.extent.y < displayHeight))
				 ErrDisplay ("Invalid window position");
			}
		winHandle = winPtr->nextWindow;		
		}
	}	
#endif	

	// Save the current form and the current draw window.
	curDrawWindow = WinGetDrawWindow ();
	curForm = CurrentForm;	

	// Set the diplay window's clipping region to the update region,  things
	// like frames around windows are drawn in the display window.
	WinSetDrawWindow (WinGetDisplayWindow ());
	WinSetClip (updateR);

	clipR = *updateR;

	// Search the window list for forms.
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			if (frm->attr.visible)
				{
				// Make the form the current draw window and the
				// active form.
				CurrentForm = frm;
				WinSetDrawWindow (winHandle);
				
				// Set the clipping region to the bounds of the region
				// we want to update.
				WinGetClip (&saveClipR);

				WinGetWindowFrameRect (winHandle, &formR);				
				RctGetIntersection (&formR, &clipR, &r);
				if (r.extent.y > 0)
					{
					WinDisplayToWindowPt (&r.topLeft.x, &r.topLeft.y);
					WinSetClip (&r);
	
					MemSet (&event, sizeof(EventType), 0);
					event.eType = frmUpdateEvent;
					event.data.frmUpdate.updateCode = frmRedrawUpdateCode;
		
					// Let the form handle the update event, if it has an event
					// handler defined.  Otherwise, have the default event handler
					// update the display.
					handled = false;
					if (frm->handler)
						handled = frm->handler (&event);
					if (! handled)
						FrmHandleEvent (frm, &event);
		
					// Restore the form's clipping region.
					WinSetClip (&saveClipR);
	
					// Check if we've filled in the entire update region.
					if (formR.topLeft.y <= updateR->topLeft.y) break;			
		
					// Reduce the size of the update region by the area of the 
					// form just drawn.
					clipR.extent.y = formR.topLeft.y - updateR->topLeft.y;
					}
				}
			}
		winHandle = winPtr->nextWindow;		
		}

	WinSetDrawWindow (WinGetDisplayWindow ());
	WinResetClip ();
		
	CurrentForm = curForm;
	WinSetDrawWindow (curDrawWindow);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmDrawForm
 *
 * DESCRIPTION: This routine draws all the object in a form and the 
 *              frame around the form.
 *
 * PARAMETERS:	 frmHandle	the handle of memory block the contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			art	2/20/96	Added scroll bar
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmDrawForm (const FormPtr frm)
{
	Word i;
	Word error;
	ULong freeBytes;
	ULong maxChunk;
	RectangleType frame;
	FormObjectType obj;
	WinHandle win;
   FontID currFont;
	VoidHand resH;

	ECFrmValidatePtr(frm);
	
   win = FrmGetWindowHandle (frm);

	// Save the bits behind the form if there's enough memory to do so.
	if (frm->attr.saveBehind && !frm->attr.visible)
		{
		WinSetDrawWindow (WinGetDisplayWindow());
		WinGetWindowFrameRect (win, &frame);
		WinClipRectangle (&frame);
		
		MemHeapFreeBytes (0, &freeBytes, &maxChunk);
		if (freeBytes > frmMinFreeBytes)
			frm->bitsBehindForm = WinSaveBits (&frame, &error);
		else
			frm->bitsBehindForm = 0;
			
		WinEraseRectangle (&frame, fmrCornerDiam);
		}

	WinSetDrawWindow (win);
	WinDrawWindowFrame();

	currFont = FntGetFont ();

	for (i = 0; i < frm->numObjects; i++)
		{
		obj = frm->objects[i].object;
		switch (frm->objects[i].objectType)
			{
			case frmFieldObj:
				FldDrawField (obj.field);
				break;

			case frmControlObj:
				CtlDrawControl (obj.control);
				break;

			case frmListObj:
				LstDrawList (obj.list);
				break;

			case frmTableObj:
				TblDrawTable (obj.table);
				break;

			case frmBitmapObj:
				if (obj.bitmap->attr.usable)
					{
					resH = DmGetResource (bitmapRsc, obj.bitmap->rscID);
					WinDrawBitmap (MemHandleLock (resH), 
						obj.bitmap->pos.x, obj.bitmap->pos.y);
					MemHandleUnlock (resH);
					}
				break;

			case frmLineObj:
				break;

			case frmFrameObj:
				break;

			case frmRectangleObj:
				break;

			case frmLabelObj:
				DrawLabel (obj.label);
				break;

			case frmTitleObj:
				DrawTitle (frm, obj.title);
				break;

			case frmScrollBarObj:
				SclDrawScrollBar (obj.scrollBar);
				break;
			}
		}

	if (frm->attr.graffitiShift && (! GsiEnabled ()))
		GsiEnable (true);

	FntSetFont (currFont);

	frm->attr.visible = 1;
}

/***********************************************************************
 *
 * FUNCTION: 	 FrmEraseForm
 *
 * DESCRIPTION: This routine erases a form from the display.  If the region
 *              obscured by the form was saved by FrmDrawForm, this routine
 *              will restore that region.
 *
 * PARAMETERS:	 frmHandle	the handle of memory block the contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmEraseForm (const FormPtr frm)
{
	RectangleType r;
	WinHandle drawWin;

	ECFrmValidatePtr(frm);
	
	if (!frm->attr.visible) return;
	frm->attr.visible = 0;

	// Disable the insertion point and the graffiti shift state indicator.
	if (frm == FrmGetActiveForm())
		{
		InsPtEnable (false);
		GsiEnable (false);
		}

	// Get the bounds to the form and its frame.
	drawWin = WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (FrmGetWindowHandle(frm), &r);
	WinClipRectangle (&r);

	// If the image behind the form was save (by the draw routine), restore
	// the display region obscured by the form.
	if ((frm->attr.saveBehind) && (frm->bitsBehindForm))
		{
		WinRestoreBits (frm->bitsBehindForm, r.topLeft.x, r.topLeft.y);
		frm->bitsBehindForm = 0;
		}
	else
		{
		WinEraseRectangle (&r, fmrCornerDiam);
		if (frm->attr.saveBehind)
			RedrawDisplay (&r);
		}

	WinSetDrawWindow (drawWin);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetUserModifiedState
 *
 * DESCRIPTION: This routine returns TRUE if an object in the form has 
 *              been modified by the user since it was initialized or 
 *              since the last call to FrmSetNotUserModified.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 TRUE if an object was modified
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Boolean FrmGetUserModifiedState (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	return (frm->attr.dirty);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetNotUserModified
 *
 * DESCRIPTION: This routine clear the flag the keeps track of whether
 *              or not the form has been modified by the user.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetNotUserModified (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	frm->attr.dirty = false;
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmGetFocus
 *
 * DESCRIPTION: This routine returns the item number of the object 
 *              that has the focus.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 object with focus, -1 if none.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmGetFocus (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	return (frm->focus);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmSetFocus
 *
 * DESCRIPTION: This routine releases the focus form the form object that
 *              it.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object that gets the focus
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/8/94	Initial Revision
 *
 ***********************************************************************/
static void ReleaseFocus (FormPtr frm, Word objIndex)
{
	FieldPtr fld;
	FormObjectKind objType;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex != noFocus && objIndex >= frm->numObjects, "Invalid index");
	
	
	// If a field or a table has the focus, release it.
	if ((frm->focus != noFocus) && (FrmGetActiveForm() == frm))
		{
		objType = frm->objects[frm->focus].objectType;

		if (objIndex != frm->focus)
			{
			if (objType == frmFieldObj)
				{
				fld = frm->objects[frm->focus].object.field;
				if (objIndex == noFocus)
					FldReleaseFocus (fld);
				else if (frm->objects[objIndex].objectType == frmFieldObj)
					{
					FldReleaseFocus (fld);
					FldSetSelection (fld, 0, 0);
					}
				}
	
			if (objType == frmTableObj)
				{
				TblReleaseFocus (frm->objects[frm->focus].object.table);
				frm->focus = noFocus;
				}
			}
		}
}

/***********************************************************************
 *
 * FUNCTION: 	 FrmSetFocus
 *
 * DESCRIPTION: This routine sets the focus of a form to the object specified.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object that gets the focus
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *       art	1/8/97	Broke release logic out into a seperate routine
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetFocus (const FormPtr frm, const Word objIndex)
{
	FormObjectKind newObjType;


	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex != noFocus && objIndex >= frm->numObjects, "Invalid index");
	
	
	// If a field or a table has the focus, release it.
	ReleaseFocus (frm, objIndex);

/*
	if ((frm->focus != noFocus) && (FrmGetActiveForm() == frm))
		{
		objType = frm->objects[frm->focus].objectType;

		if (objIndex != frm->focus)
			{
			if (objType == frmFieldObj)
				{
				fld = frm->objects[frm->focus].object.field;
				if (objIndex == noFocus)
					FldReleaseFocus (fld);
				else if (frm->objects[objIndex].objectType == frmFieldObj)
					{
					FldReleaseFocus (fld);
					FldSetSelection (fld, 0, 0);
					}
				}
	
			if (objType == frmTableObj)
				{
				TblReleaseFocus (frm->objects[frm->focus].object.table);
				frm->focus = noFocus;
				}
			}
		}
*/

	if (objIndex == noFocus)
		{
		frm->focus = objIndex;
		return;
		}

	newObjType = frm->objects[objIndex].objectType;
	if (newObjType == frmFieldObj)
		{
		frm->focus = objIndex;

		// Turn on the insertion point, if the object is a field.
		if (FrmGetActiveForm() == frm)
			{
			FldGrabFocus (frm->objects[objIndex].object.field);
			}
		}
	
	 else if (newObjType == frmTableObj)
		{
		frm->focus = objIndex;
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmGetFormBounds
 *
 * DESCRIPTION: This routine returns the bounds to the form; the region
 *              returned includes the form's frame.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					 r       pointer to a RectangleType structure
 *
 * RETURNED:	 bounds of the form
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmGetFormBounds (const FormPtr frm, const RectanglePtr r)
{
	WinHandle drawWin;

	ECFrmValidatePtr(frm);
	
	drawWin = WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (FrmGetWindowHandle(frm), r);
	WinSetDrawWindow (drawWin);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetFormId
 *
 * DESCRIPTION: This routine returns the resource id of a form.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 form resource id
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmGetFormId (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	return (frm->formId);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmGetFormPtr
 *
 * DESCRIPTION: This routine returns a pointer to the form that contains
 *              the id specified.
 *
 * PARAMETERS:	 form id
 *					
 * RETURNED:	 memory block that contains the form or null if the form
 *              is not in memory.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
FormPtr FrmGetFormPtr (const Word formId)
{
	WinHandle winHandle;
	WinPtr winPtr;
	FormPtr frm;
	
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			if (frm->formId == formId)
				return (frm);
			}
		winHandle = winPtr->nextWindow;		
		}

	return (NULL);
}


/***********************************************************************
 *
 * FUNCTION:    FrmGetFirstForm
 *
 * DESCRIPTION: This routine returns the first form in the window list.
 *              The window list is a LIFO stack fo sort,  the last window
 *              created is the first window in the window list.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    a pointer to a frm or NULL if there are not forms.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/29/95	Initial Revision
 *
 ***********************************************************************/
FormPtr FrmGetFirstForm (void)
{
	WinHandle winHandle;
	WinPtr winPtr;
	
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			return ((FormPtr) winPtr);
			}
		winHandle = winPtr->nextWindow;		
		}

	return (NULL);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmGetNumberOfObjects
 *
 * DESCRIPTION: This routine returns the number of objects in a form.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 number of object in the form specified
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmGetNumberOfObjects (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	return (frm->numObjects);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetObjectId
 *
 * DESCRIPTION: This routine returns the id of the object specified.  
 *              An id is a value specified by the application developer 
 *              that uniquely identifies an object.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			art	2/20/96	Add scroll bar
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmGetObjectId (const FormPtr frm, const Word objIndex)
{
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
		case frmFieldObj:
			return (obj.field->id);

		case frmControlObj:
			return (obj.control->id);

		case frmListObj:
			return (obj.list->id);

		case frmTableObj:
			return (obj.table->id);
			
		case frmLabelObj:
			return (obj.label->id);

		case frmBitmapObj:
			return (obj.bitmap->rscID);

		case frmGadgetObj:
			return (obj.gadget->id);
			
		case frmScrollBarObj:
			return (obj.scrollBar->id);
			
		
		};

	// invalid object index
	return (-1);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetObjectType
 *
 * DESCRIPTION: This routine returns the type of an object.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              objIndex item number of the object
 *					
 * RETURNED:	 FormObjectType of the item specified
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
FormObjectKind FrmGetObjectType (const FormPtr frm, const Word objIndex)
{
	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	return (frm->objects[objIndex].objectType);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetObjectIndex
 *
 * DESCRIPTION: This routine returns the item number of an object, the 
 *              item number is the position of the object in the objects 
 *              list.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              objId   id of an object in the form.
 *					
 * RETURNED:	 item number of na  object (the first item number is 0).
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmGetObjectIndex (const FormPtr frm, const Word objId)
{
	Word i;

	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (FrmGetObjectId (frm, i) == objId)
			return (i);
		}

	ErrDisplay ("Object not in form");
	return (-1);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to the data structure of an 
 *              object in a form.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              objIndex item number of the object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
VoidPtr FrmGetObjectPtr (const FormPtr frm, const Word objIndex)
{
	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	return (frm->objects[objIndex].object.ptr);
}


/***********************************************************************
 *
 * FUNCTION: 	 PointInObject
 *
 * DESCRIPTION: This routine returns true if the coordinate passed is within
 *              the bounds of an object of the form.  The item number of the
 *              object is also returned.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *					 objIndex  index of the object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/3/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmGetObjectBounds (const FormPtr frm, const Word objIndex, 
	const RectanglePtr r)
{
	ListPtr lst;
	FieldPtr fld;
	TablePtr table;
	ControlPtr ctl;
	FormObjectKind objType;
	

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	objType = frm->objects[objIndex].objectType;

	if (objType == frmControlObj)
		{
		ctl = frm->objects[objIndex].object.control;
		RctCopyRectangle (&ctl->bounds, r);
		return;
		}

	else if (objType == frmFieldObj)
		{
		fld = frm->objects[objIndex].object.field;
		RctCopyRectangle (&fld->rect, r);			
		return;
		}

	else if (objType == frmTableObj)
		{
		table = frm->objects[objIndex].object.table;
		RctCopyRectangle (&table->bounds, r);			
		return;
		}

	else if (objType == frmListObj)
		{
		lst = frm->objects[objIndex].object.list;
		RctCopyRectangle (&lst->bounds, r);
		return;
		}
					
	else if (objType == frmGadgetObj)
		{
		RctCopyRectangle (&frm->objects[objIndex].object.gadget->rect, r);
		return;
		}
					
	else if (objType == frmScrollBarObj)
		{
		RctCopyRectangle (&frm->objects[objIndex].object.scrollBar->bounds, r);
		return;
		}
					
	else if (objType == frmLabelObj)
		{
		GetLabelBounds(frm->objects[objIndex].object.label,r);
		return;
		}
					
	else if (objType == frmBitmapObj)
		{
		GetBitmapBounds(frm->objects[objIndex].object.bitmap,r);
		return;
		}
			
	else if (objType == frmGraffitiStateObj)
		{
		FontID curFont = FntSetFont (symbolFont);
		r->topLeft = frm->objects[objIndex].object.grfState->pos;
		r->extent.x = FntAverageCharWidth();
		r->extent.y = FntLineHeight();
		FntSetFont (curFont);
		return;
		}
	else
		{
		RctSetRectangle (r, 0, 0, 0, 0);
		return;
		}	
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmHideObject
 *
 * DESCRIPTION: This routine erases the specified object and set its 
 *              attribute data so that it will do redraw or respond 
 *              to the pen.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              objIndex item number of the object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmHideObject (const FormPtr frm, const Word objIndex)
{
	RectangleType r;
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
			case frmFieldObj:
				if (frm->attr.visible)
					{
					FldEraseField (obj.field);
					if (frm->focus == objIndex)
						FldReleaseFocus (obj.field);
					}
				FldSetUsable (obj.field, false);
				break;

			case frmControlObj:
				CtlHideControl (obj.control);
				break;

			case frmListObj:
				break;

			case frmTableObj:
				break;

			case frmBitmapObj:
				if (frm->attr.visible && obj.bitmap->attr.usable) 
					{
					GetBitmapBounds(obj.bitmap,&r);
					WinEraseRectangle (&r, 0);
					}
				break;

			case frmLineObj:
				break;

			case frmFrameObj:
				break;

			case frmRectangleObj:
				break;

			case frmLabelObj:
				if (obj.label->attr.usable)
					{
					EraseLabel (frm, obj.label);
					obj.label->attr.usable = false;
					}
				break;

		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmShowObject
 *
 * DESCRIPTION: This routine sets an object usable and, if the form is 
 *              visible, draw the object.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              objIndex item number of the object
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmShowObject (const FormPtr frm, const Word objIndex)
{
	FontID curFont;
	VoidHand resH;
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
			case frmFieldObj:
				FldSetUsable (obj.field, true);
				if (frm->attr.visible)
					{
					FldDrawField (obj.field);
					if (frm->focus == objIndex)
						FldGrabFocus (obj.field);
					}
				break;

			case frmControlObj:
				CtlSetUsable (obj.control, true);
				if (frm->attr.visible)
					CtlDrawControl (obj.control);
				break;

			case frmListObj:
				break;

			case frmTableObj:
				break;

			case frmBitmapObj:
				obj.bitmap->attr.usable = true;
				if (frm->attr.visible) 
					{
					resH = DmGetResource (bitmapRsc, obj.bitmap->rscID);
					WinDrawBitmap (MemHandleLock (resH), 
						obj.bitmap->pos.x, obj.bitmap->pos.y);
					MemHandleUnlock (resH);
					}
				break;

			case frmLineObj:
				break;

			case frmFrameObj:
				break;

			case frmRectangleObj:
				break;

			case frmLabelObj:
				obj.label->attr.usable = true;
				if (frm->attr.visible)
					{
					curFont = FntSetFont (obj.label->fontID);
					DrawLabel (obj.label);
					FntSetFont (curFont);
					}
				break;

		}
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmGetActiveForm
 *
 * DESCRIPTION: This routine returns the currently active form.
 *
 * PARAMETERS:	 nothing
 *					
 * RETURNED:	 frmPtr	memory block that contains the form.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *
 ***********************************************************************/
FormPtr FrmGetActiveForm (void)
{
	return (CurrentForm);
}

/***********************************************************************
 *
 * FUNCTION: 	 FrmGetActiveFormID
 *
 * DESCRIPTION: This routine returns the id of the currently active form.
 *
 * PARAMETERS:	 nothing
 *					
 * RETURNED:	 frmPtr	memory block that contains the form.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/13/95	Initial Revision
 *
 ***********************************************************************/
Word FrmGetActiveFormID (void)
{
	if (CurrentForm)
		return (CurrentForm->formId);
	return (0);
}



/***********************************************************************
 *
 * FUNCTION: 	 FrmSetActiveForm
 *
 * DESCRIPTION: This routine sets the active form, all input (key and pen)
 *              is directed to the active form.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			art	5/15/96	Don't release focus in table if no current field
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetActiveForm (const FormPtr frm)
{
	Word i;
	FieldPtr fld;
	MenuBarPtr menuP;
	FormObjectType obj;
	FormObjectKind objType;
	FrmGraffitiStateType *  grfStateObj;


	ECFrmValidatePtr(frm);
	
	if (CurrentForm == frm) return;


	// Make sure the current form exist.
	#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
		if (CurrentForm)
			{
			Boolean exist = false;
			WinHandle winHandle;
			WinPtr winPtr;
			
			winHandle = WinGetFirstWindow ();
			while (winHandle)
				{
				winPtr = WinGetWindowPointer (winHandle);
				if (winPtr->windowFlags.dialog)
					if (CurrentForm == (FormPtr) winPtr)
						{
						exist = true;
						break;
						}
				winHandle = winPtr->nextWindow;		
				}
			if (! exist)
				ErrDisplay ("Current form does not exist");
			}
	#endif	


	// Release the menu.
	if (CurrentForm)
		{
		menuP = MenuGetActiveMenu ();
		if (menuP)
			MenuDispose (menuP);

		if (CurrentForm->focus != noFocus)
			{
			objType = CurrentForm->objects[CurrentForm->focus].objectType;
			obj = CurrentForm->objects[CurrentForm->focus].object;
			if (objType == frmFieldObj)
				FldReleaseFocus (obj.field);
			else if (objType == frmTableObj)
				{
				fld = TblGetCurrentField (obj.table);
				if (fld)
					FldReleaseFocus (fld);
				}
			}

		GsiEnable (false);
		}


	CurrentForm = frm;
	if (! frm) return;


	// Make the new current form the draw window and the active window.
	WinSetDrawWindow (FrmGetWindowHandle (frm));
	WinSetActiveWindow (FrmGetWindowHandle (frm));

	if (frm->focus == noFocus)
		InsPtEnable (false);

	// Restore the focus in the new current form.
	else if (frm->attr.visible)
		{
		objType = frm->objects[frm->focus].objectType;
		obj = frm->objects[frm->focus].object;
		if (objType == frmFieldObj)
			FldGrabFocus (obj.field);
		else if (objType == frmTableObj)
			{
			fld = TblGetCurrentField (obj.table);
			if (fld)
				FldGrabFocus (fld);
			}
		}

	// Make the form's menu the active menu.
	if (frm->menuRscId)
		{
//		menuP = MenuInit (frm->menuRscId);
		MenuSetActiveMenuRscID (frm->menuRscId);
		}
	else
		MenuSetActiveMenu (NULL);
		


	// Check if the form has a graffiti shift state indicator.
	grfStateObj = NULL;
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmGraffitiStateObj)
			{
			grfStateObj = frm->objects[i].object.grfState;
			break;
			}
		}

	if (grfStateObj)
		{
		// Set the position of the graffiti shift state indicator.
		GsiSetLocation (grfStateObj->pos.x, grfStateObj->pos.y);
	
		// If the form is visible draw the graffiti shift state indicator.
		GsiEnable (frm->attr.visible == true);

		frm->attr.graffitiShift = true;
		}
	else
		GsiEnable (false);

}


/***********************************************************************
 *
 * FUNCTION:    FrmGetControlGroupSelection
 *
 * DESCRIPTION: This routine returns the item number of the selected
 *              control, in a group of controls
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              group    control group number
 *
 * RETURNED:	 item number of selected control or -1 if none
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Byte FrmGetControlGroupSelection (const FormPtr frm, const Byte group)
{
	ControlPtr ctl;
	Int i;


	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmControlObj)
			{
			ctl = frm->objects[i].object.control;
			if (ctl->group == group && ctl->attr.on)
				return (i);
			}
		}
	return (-1);
}


/***********************************************************************
 *
 * FUNCTION:    FrmSetControlGroupSelection
 *
 * DESCRIPTION: This routine set the selected control, in a group of controls
 *
 * PARAMETERS:	 frmPtr	  memory block that contains the form.
 *              group     control group number.
 *              controlID id of control to set.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *
 ***********************************************************************/
void FrmSetControlGroupSelection (const FormPtr frm, 
	const Byte group, const Word controlID)
{
   Word oldIndex;
   Word newIndex;

	ECFrmValidatePtr(frm);
	
	oldIndex = FrmGetControlGroupSelection (frm, group);
	newIndex = FrmGetObjectIndex (frm, controlID);

	if (oldIndex != newIndex)
		{
		FrmSetControlValue (frm, oldIndex, false);	
		}
	FrmSetControlValue (frm, newIndex, true);
}



/***********************************************************************
 *
 * FUNCTION:    FrmGetControlValue
 *
 * DESCRIPTION: The function return the on / off state of a control.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
short FrmGetControlValue (const FormPtr frm, const Word objIndex)
{
	ECFrmValidatePtr(frm);
	ErrFatalDisplayIf ((objIndex >= frm->numObjects), "Invalid index");

	return (CtlGetValue (FrmGetObjectPtr (frm, objIndex)));
	
}

/***********************************************************************
 *
 * FUNCTION:    FrmSetControlValue
 *
 * DESCRIPTION: The function turns a control on or off.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object
 *              value	 new control value (non-zero equal on)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetControlValue (const FormPtr frm, const Word objIndex, 
	SWord value)
{
	ECFrmValidatePtr(frm);
	
	if (objIndex < frm->numObjects)
		CtlSetValue (FrmGetObjectPtr (frm, objIndex), value);
}


/***********************************************************************
 *
 * FUNCTION:    FrmGetGadgetData
 *
 * DESCRIPTION: The function returns the value stored in the "data"
 *              field of the gadget object.  
 *
 *              Gadget objects provide a way for an application to 
 *              attach custom gadgetry to a form.  In general the 
 *              "data" field of a gadget obejct contains a pointer 
 *              to the custom object's data structure. 
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object
 *              data  	 application defined value
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
VoidPtr FrmGetGadgetData (const FormPtr frm, const Word objIndex)
{
	ECFrmValidatePtr(frm);
	ErrFatalDisplayIf ((objIndex >= frm->numObjects), "Invalid index");

	return (frm->objects[objIndex].object.gadget->data);
}


/***********************************************************************
 *
 * FUNCTION:    FrmSetGadgetData
 *
 * DESCRIPTION: The function store the value passed in the "data"
 *              field of the gadget object.  
 *
 *              Gadget objects provide a way for an application to 
 *              attach custom gadgetry to a form.  In general the 
 *              "data" field of a gadget obejct contains a pointer 
 *              to the custom object's data structure. 
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              objIndex item number of the object
 *              data  	 application defined value
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/16/94		Initial Revision
 *
 ***********************************************************************/
void FrmSetGadgetData (const FormPtr frm, const Word objIndex, 
	const VoidPtr data)
{
	ECFrmValidatePtr(frm);
	ErrFatalDisplayIf ((objIndex >= frm->numObjects), "Invalid index");

	frm->objects[objIndex].object.gadget->data = data;
}


/***********************************************************************
 *
 * FUNCTION:    FrmPopupList
 *
 * DESCRIPTION: This routine will popup a list object.
 *
 * PARAMETERS:	frmPtr	 memory block that contains the form.
 *             controlID id of the popup trigger that initiated the popup
 *              
 * RETURNED:	nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/17/94		Initial Revision
 *
 ***********************************************************************/
static void FrmPopupList (FormPtr frm, EventPtr eventP)
{
	short				curSelection;
	short				newSelection;
	Word           i;
	Word				controlID;
	Word           objIndex;
	Word	         numObjects;
	EventType		newEvent;
	ListPtr        lst;
	ControlPtr		ctl;
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	
	ctl = eventP->data.ctlEnter.pControl;
   controlID = ctl->id;

	numObjects = frm->numObjects;

	for (i = 0; i < numObjects; i++)
		{
		if (frm->objects[i].objectType == frmPopupObj)
			{
			obj = frm->objects[i].object;
			if (obj.popup->controlID == controlID)
				{
				objIndex = FrmGetObjectIndex (frm, obj.popup->listID);
				lst = FrmGetObjectPtr (frm, objIndex);
				curSelection = LstGetSelection (lst);
				newSelection = LstPopupList (lst);
				if (newSelection != -1)
					{
					newEvent.eType = popSelectEvent;
					newEvent.data.popSelect.controlID = obj.popup->controlID;
					newEvent.data.popSelect.controlP = ctl;
					newEvent.data.popSelect.listID = obj.popup->listID;
					newEvent.data.popSelect.listP = lst;
					newEvent.data.popSelect.selection = newSelection;
					newEvent.data.popSelect.priorSelection = curSelection;
					EvtAddEventToQueue (&newEvent);
					}
				}
			}
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 PointInObject
 *
 * DESCRIPTION: This routine returns true if the coordinate passed is within
 *              the bounds of an object of the form.  The item number of the
 *              object is also returned.
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              x        window relitave coordinate
 *              x        window relitave coordinate
 *					pObjIndex pointer to Word 
 *
 * RETURNED:	 TRUE if coordinate is an object
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			art	2/20/96	Added scroll bar
 *
 ***********************************************************************/
static Boolean PointInObject (FormPtr frm, short x, short y, 
	WordPtr pObjIndex)
{
	Word i;
	ListPtr lst;
	FieldPtr fld;
	TablePtr table;
	ControlPtr ctl;
	ScrollBarPtr scrollBar;
	RectanglePtr pRect;
	FormObjectKind objType;
	
	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		objType = frm->objects[i].objectType;

		if (objType == frmControlObj)
			{
			ctl = frm->objects[i].object.control;
			if (ctl->attr.usable)
				pRect = &ctl->bounds;
			else
				continue;
			}			

		else if (objType == frmListObj)
			{
			lst = frm->objects[i].object.list;
			if (lst->attr.usable)
				pRect = &lst->bounds;
			else
				continue;
			}
						
		else if (objType == frmFieldObj)
			{
			fld = frm->objects[i].object.field;
			if (fld->attr.usable)
				pRect = &fld->rect;			
			else
				continue;
			}

		else if (objType == frmTableObj)
			{
			table = frm->objects[i].object.table;
			pRect = &table->bounds;			
			}

		else if (objType == frmScrollBarObj)
			{
			scrollBar = frm->objects[i].object.scrollBar;
			if (scrollBar->attr.usable)
				pRect = &scrollBar->bounds;			
			else
				continue;
			}

		else	
			continue;

		if (RctPtInRectangle (x, y, pRect))
			{
			*pObjIndex = i;
			return (true);
			}
		}

	return (false);
}

/***********************************************************************
 *
 * FUNCTION: 	 DoMenuCommand
 *
 * DESCRIPTION: This routine handles system edit menu commands.
 *
 * PARAMETERS:	 frmPtr	  memory block that contains the form.
 *              command  id of a menu item
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/5/95	Initial Revision
 *			scl	2/27/97	Added MenuEraseStatus for international builds
 *
 ***********************************************************************/
static Boolean DoMenuCommand (FormPtr frm, Word command)
{
	FieldPtr fld;
	FormObjectKind objType;
	
	ECFrmValidatePtr(frm);
	
	if (frm->focus == noFocus) goto exit;
	
	objType = frm->objects[frm->focus].objectType;
	if (objType == frmFieldObj)
		fld = frm->objects[frm->focus].object.field;
	else if (objType == frmTableObj)
		fld = TblGetCurrentField (frm->objects[frm->focus].object.table);
	else
		goto exit;
		
	if (! fld) goto exit;

	switch (command)
		{
		case sysEditMenuUndoCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			FldUndo (fld);
			return true;
		
		case sysEditMenuCutCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			FldCut (fld);
			return true;
		
		case sysEditMenuCopyCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			FldCopy (fld);
			return true;
		
		case sysEditMenuPasteCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			FldPaste (fld);
			return true;

		case sysEditMenuSelectAllCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			FldSetSelection (fld, 0, FldGetTextLength (fld));
			return true;
			
		case sysEditMenuKeyboardCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			SysKeyboardDialog (kbdDefault);
			return true;
			
		case sysEditMenuGraffitiCmd:
			#if LANGUAGE != LANGUAGE_ENGLISH
				MenuEraseStatus (0);		// avoid visual update problem w/ cmd status
			#endif
			SysGraffitiReferenceDialog (referenceDefault);
			return true;
		}

	return false;

exit:
	SndPlaySystemSound (sndError);
	return false;
}

/***********************************************************************
 *
 * FUNCTION: 	 SendConfirmEvent
 *
 * DESCRIPTION: This routine is called when the "confirm" hard icon
 *              in pressed.  If the form has a default button defined,
 *              this routine simulates the pressing of that button.
 *
 * PARAMETERS:	 frmPtr	  memory block that contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *
 ***********************************************************************/
static void SendConfirmEvent (FormPtr frm)
{
	Word index;
	
	ECFrmValidatePtr(frm);
	
	// Exit, if there is not a default button defined.
	if (! frm->defaultButton) return;
	
	index = FrmGetObjectIndex (frm, frm->defaultButton);
	ErrFatalDisplayIf ((index == -1), "Default button not found");
	
	CtlHitControl (FrmGetObjectPtr (frm, index));
}

/***********************************************************************
 *
 * FUNCTION: 	 HelpHandleEvent
 *
 * DESCRIPTION: This routine checks if a pen dowm event has occurred
 *              in the help trigger.  If so, the pen is tracked until
 *              it's release, if it is release on the help icon the 
 *              help dialog is displayed.
 *
 * PARAMETERS:	 frmPtr	  memory block that contains the form.
 *              event     pointer to a pen down event
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *
 ***********************************************************************/
static Boolean HelpHandleEvent (FormPtr frm, EventPtr eventP)
{
	short x, y;
	Word formWidth;
	Boolean penDown;
	Boolean inverted = false;
	RectangleType r;
	
	ECFrmValidatePtr(frm);
	
	if (! frm->helpRscId) return (false);
	
	formWidth = frm->window.windowBounds.extent.x;
	r.topLeft.x = formWidth - helpButtonWidth - 2;
	r.topLeft.y = 0;
	r.extent.y = helpButtonWidth;
	r.extent.x = helpButtonWidth;

	x = eventP->screenX;
	y = eventP->screenY;
	if ( ! RctPtInRectangle (x, y, &r))
		return (false);

	do 
		{
		if (RctPtInRectangle (x, y, &r))
			{
			if (! inverted)
				{
				WinInvertRectangle (&r, helpCornerRadius);
				inverted = true;
				}
			}
		else if (inverted)
			{
			WinInvertRectangle (&r, helpCornerRadius);
			inverted = false;
			}

		PenGetPoint (&x, &y, &penDown);
		} while (penDown);


	if (inverted)
		{
		WinInvertRectangle (&r, helpCornerRadius);
		FrmHelp (frm->helpRscId);
		
		}
	return (true);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmCopyLabel
 *
 * DESCRIPTION: This routine copies the passed string into the 
 *              data structure of the specified label object in the active
 *              form.
 *
 * PARAMETERS:	 lableID  - id of form lable object
 *              newLable - pointer to a null-terminated string
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/8/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmCopyLabel (const FormPtr frm, const Word lableID, 
	const CharPtr newLabel)
{
	FontID curFont;
	FormLabelType * obj;
	
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

	Word objIndex;
	Word labelLen;

	// A little debugging code to make sure the new label will fix.
	objIndex = FrmGetObjectIndex (frm, lableID);
	
	if (objIndex < FrmGetNumberOfObjects (frm) -1)
		{
		labelLen =  ((char *) FrmGetObjectPtr (frm, objIndex+1)) - 
						((char *) FrmGetObjectPtr (frm, objIndex)) - 
						sizeof (FormLabelType);
		}
	else
		{
		labelLen = MemPtrSize(frm);
		labelLen -=((char *) FrmGetObjectPtr (frm, objIndex)) - 
					  ((char *) frm) - 
					  sizeof (FormLabelType);
		}

	if (labelLen <= StrLen(newLabel))
		ErrDisplay ("Label too long");

#endif

	ECFrmValidatePtr(frm);
	
	obj =  FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, lableID));
	StrCopy (obj->text, newLabel);

	if ((frm->attr.visible) && (obj->attr.usable))
		{
		curFont = FntSetFont (obj->fontID);
		DrawLabel (obj);
		FntSetFont (curFont);
		}
	
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmGetLabel
 *
 * DESCRIPTION: This routine return the text of the specified label object
 *	             in the specified form.
 *
 * PARAMETERS:	 frmPtr	 - memory block that contains the form.
 *              lableID  - id of the label object.
 *					
 * RETURNED:	 pointer to the label string.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/11/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
CharPtr FrmGetLabel (const FormPtr frm, const Word lableID)
{
	FormLabelType * obj;

	ECFrmValidatePtr(frm);
	
	ErrFatalDisplayIf (
		FrmGetObjectType (frm, FrmGetObjectIndex (frm, lableID)) != frmLabelObj,
		"Invalid object type");

	obj =  FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, lableID));
	return (obj->text);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetObjectPositon
 *
 * DESCRIPTION: This routine returns the window relative coordinate
 *              of the specified object.
 *
 * PARAMETERS:	 frmPtr	 - memory block that contains the form.
 *              objIndex - item number of the object
 *
 * RETURNED:	 x        - window relative coordinate
 *              y        - window relative coordinate
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/8/95	Initial Revision
 *
 ***********************************************************************/
extern void FrmGetObjectPosition (const FormPtr frm, const Word objIndex, 
	const SWordPtr x, const SWordPtr y)
{
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
			case frmFieldObj:
				*x = obj.field->rect.topLeft.x;
				*y = obj.field->rect.topLeft.y;
				break;

			case frmControlObj:
				*x = obj.control->bounds.topLeft.x;
				*y = obj.control->bounds.topLeft.y;
				break;

			case frmListObj:
				*x = obj.list->bounds.topLeft.x;
				*y = obj.list->bounds.topLeft.y;
				break;

			case frmTableObj:
				*x = obj.table->bounds.topLeft.x;
				*y = obj.table->bounds.topLeft.y;
				break;

			case frmBitmapObj:
				*x = obj.bitmap->pos.x;
				*y = obj.bitmap->pos.y;
				break;

			case frmLabelObj:
				*x = obj.label->pos.x;
				*y = obj.label->pos.y;
				break;

			case frmGraffitiStateObj:
				*x = obj.grfState->pos.x;
				*y = obj.grfState->pos.y;
				break;

			case frmGadgetObj:
				*x = obj.gadget->rect.topLeft.x;
				*y = obj.gadget->rect.topLeft.y;
				break;

			case frmScrollBarObj:
				*x = obj.scrollBar->bounds.topLeft.x;
				*y = obj.scrollBar->bounds.topLeft.y;
				break;

		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetObjectPosition
 *
 * DESCRIPTION: This routine returns the window relative coordinate
 *              of the specified object.
 *
 * PARAMETERS:	 frmPtr	 - memory block that contains the form.
 *              objIndex - item number of the object
 *          	 x        - window relative coordinate
 *              y        - window relative coordinate
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/8/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
extern void FrmSetObjectPosition (const FormPtr frm, const Word objIndex, 
	const SWord x, const SWord y)
{
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
			case frmFieldObj:
				obj.field->rect.topLeft.x = x;
				obj.field->rect.topLeft.y = y;
				break;

			case frmControlObj:
				obj.control->bounds.topLeft.x = x;
				obj.control->bounds.topLeft.y = y;
				break;

			case frmListObj:
				obj.list->bounds.topLeft.x = x;
				obj.list->bounds.topLeft.y = y;
				break;

			case frmTableObj:
				obj.table->bounds.topLeft.x = x;
				obj.table->bounds.topLeft.y = y;
				break;

			case frmBitmapObj:
				obj.bitmap->pos.x = x;
				obj.bitmap->pos.y = y;
				break;

			case frmLabelObj:
				obj.label->pos.x = x;
				obj.label->pos.y = y;
				break;

			case frmGraffitiStateObj:
				obj.grfState->pos.x = x;
				obj.grfState->pos.y = y;
				break;

			case frmGadgetObj:
				obj.gadget->rect.topLeft.x = x;
				obj.gadget->rect.topLeft.y = y;
				break;

			case frmScrollBarObj:
				obj.scrollBar->bounds.topLeft.x = x;
				obj.scrollBar->bounds.topLeft.y = y;
				break;
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetObjectBounds
 *
 * DESCRIPTION: This routine set the bounds of the specified form object.
 *              of the specified object.
 *
 * PARAMETERS:	 frmPtr	 - memory block that contains the form.
 *              objIndex - item number of the object
 *          	 bounds   - window relative bounds
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/4/96	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetObjectBounds (const FormPtr frm, const Word objIndex, 
	const RectanglePtr bounds)
{
	FormObjectType obj;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	obj = frm->objects[objIndex].object;

	switch (frm->objects[objIndex].objectType)
		{
		case frmFieldObj:
			FldSetBounds (obj.field, bounds);
			break;

		case frmControlObj:
			RctCopyRectangle (bounds, &obj.control->bounds);
			break;

		case frmListObj:
			RctCopyRectangle (bounds, &obj.list->bounds);
			break;

		case frmTableObj:
			TblSetBounds (obj.table, bounds);
			break;

		case frmGadgetObj:
			RctCopyRectangle (bounds, &obj.gadget->rect);
			break;

		case frmScrollBarObj:
			RctCopyRectangle (bounds, &obj.scrollBar->bounds);
			break;

		case frmTitleObj:
			RctCopyRectangle (bounds, &obj.title->rect);
			break;
			
		// gmp: can't really set bounds, but at least set topleft 
		case frmLabelObj:
			obj.label->pos = bounds->topLeft;
			break;

		case frmBitmapObj:
			obj.bitmap->pos = bounds->topLeft;
			break;

		case frmGraffitiStateObj:
			obj.grfState->pos = bounds->topLeft;
			break;
		}


}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetCategoryLabel
 *
 * DESCRIPTION: This routine sets the category label displayed on the 
 *              title line of a form.
 *
 * PARAMETERS:	 frmPtr	 - memory block that contains the form.
 *              objIndex - item number of the object
 *					 newLabel - pointer to the name of the new category
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/8/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetCategoryLabel (const FormPtr frm, const Word objIndex, 
	const CharPtr newLabel)
{
	FormObjectType obj;
	FontID curFont;
	Word len;
	RectangleType r;
	short x;

	ECFrmValidatePtr(frm);
	ErrNonFatalDisplayIf (objIndex >= frm->numObjects, "Invalid index");
	
	
	obj = frm->objects[objIndex].object;
	curFont = FntSetFont (obj.label->fontID);

	CategoryTruncateName (newLabel, maxCategoryLabelWidth);

	len = StrLen (newLabel);
	obj.label->text = newLabel;
	
	// Rigth justify the label.
	x = obj.label->pos.x;
	obj.label->pos.x = frm->window.windowBounds.extent.x - 
		FntCharsWidth (newLabel, len);
			
	if (frm->attr.visible)
		{
		// If the new label is shorter then the old label, erase the 
		// vacated region.
		if (x < obj.label->pos.x)
			{
			r.topLeft.x = x;
			r.topLeft.y = obj.label->pos.y;
			r.extent.x = obj.label->pos.x - x;
			r.extent.y = FntLineHeight ();
			WinEraseRectangle (&r, 0);
			}

		FntSetFont (obj.label->fontID);
		RctSetRectangle (&r, obj.label->pos.x-2, obj.label->pos.y,
			2,FntLineHeight ());
		WinEraseRectangle (&r, 0);	
		WinDrawChars (newLabel, len, obj.label->pos.x, obj.label->pos.y);
		}	
	FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION: 	 FrmSetTitle
 *
 * DESCRIPTION: This routine returns a pointer to the title string of a 
 *              form.
 *
 * PARAMETERS:	 frmPtr	  - memory block that contains the form.
 *					
 * RETURNED:	 pointer to title string
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/17/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
CharPtr FrmGetTitle (const FormPtr frm)
{
	Word i;
	CharPtr str;

	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmTitleObj)
			{
			str = frm->objects[i].object.title->text;
			if (*str)
				return (str);
			else
				return (NULL);
			}
		}
	return (NULL);

}


/***********************************************************************
 *
 * FUNCTION: 	 RedrawTitle
 *
 * DESCRIPTION: This routine draw the title pased.
 *
 * PARAMETERS:	 title    - pointer to the title object
 *              newTitle - pointer to the new title string
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/2/95	Initial Revision
 *
 ***********************************************************************/
static void RedrawTitle (FormTitleType * title, CharPtr newTitle)
{
	FontID curFont;
	RectangleType r;
	Short x;
	Short oldWidth;
	Short newWidth;
	CharPtr oldTitle;

	curFont = FntSetFont (titleFont);

	oldTitle = title->text;

	oldWidth = FntCharsWidth (oldTitle, StrLen (oldTitle));
	newWidth = FntCharsWidth (newTitle, StrLen (newTitle));

	if (newWidth > oldWidth)
		{
		r.topLeft.x = oldWidth + (titleMarginX + (titleMarginX - 1)) - 2;
		r.topLeft.y = 0;
		r.extent.x = newWidth - oldWidth + 1;
		r.extent.y = titleHeight;
		WinDrawRectangle (&r, 0);
		
		x = r.topLeft.x + r.extent.x;
		WinDrawLine (x, r.topLeft.y+1, x, r.topLeft.y + r.extent.y - 2);
		}

	else if (newWidth < oldWidth)
		{
		r.topLeft.x = newWidth + (titleMarginX + (titleMarginX - 1));
		r.topLeft.y = 0;
		r.extent.x = oldWidth - newWidth;
		r.extent.y = titleHeight - 2;
		WinEraseRectangle (&r, 0);
		WinEraseLine (r.topLeft.x-1, 0, r.topLeft.x, 0);
		
		r.topLeft.x -= titleMarginX;
		r.extent.x = titleMarginX;
		WinDrawRectangle (&r, 3);
		}


	WinDrawInvertedChars (newTitle, StrLen (newTitle), titleMarginX, titleMarginY);
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetTitle
 *
 * DESCRIPTION: This routine set the of the title of a form.  If the form
 *              is visible the new title is drawn.
 *
 * PARAMETERS:	 frmPtr	  - memory block that contains the form.
 *              newTitle - pointer to the new title string
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/17/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetTitle (const FormPtr frm, const CharPtr newTitle)
{
	Word i;
	FormTitleType * titleObj;
	
	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmTitleObj)
			{
			titleObj = frm->objects[i].object.title;

			if (! frm->attr.visible)
				{
				titleObj->text = newTitle;
				}
			
			else if (frm->window.windowFlags.modal)
				{
				titleObj->text = newTitle;
				DrawTitle (frm, titleObj);
				}
			else
				{
				RedrawTitle (titleObj, newTitle);
				titleObj->text = newTitle;
				}	
			}
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmCopyTitle
 *
 * DESCRIPTION: This routine copies the title passed over the forms
 *              current title.  If the form is visible the new 
 *              title is drawn.
 *
 * PARAMETERS:	 frmPtr	  - memory block that contains the form.
 *              newTitle - pointer to the new title string
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/2/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmCopyTitle (const FormPtr frm, const CharPtr newTitle)
{
	Word i;
	FormTitleType * titleObj;
	
	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmTitleObj)
			{
			titleObj = frm->objects[i].object.title;

			if (! frm->attr.visible)
				{
				StrCopy (titleObj->text, newTitle);
				}
			
			else if (frm->window.windowFlags.modal)
				{
				StrCopy (titleObj->text, newTitle);
				DrawTitle (frm, titleObj);
				}
			else
				{
				RedrawTitle (titleObj, newTitle);
				StrCopy (titleObj->text, newTitle);
				}	
			}
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmAlert
 *
 * DESCRIPTION: This routine creates a modal dialog from an alert resource
 *              and displays the dialog until a button in the alert is hit.
 *              The item number of the button that was hit is returned.  
 *              A button's item number is determine by its order in the
 *              alert template, the first button has an item number of
 *              zero.
 *
 * PARAMETERS:	 alertId   - resource id of the alert.
 *					
 * RETURNED:	 the button the was pressed (the first button is zero)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/22/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Word FrmAlert (const Word  alertId)
{
	return (FrmCustomAlert (alertId, NULL, NULL, NULL));
}

/***********************************************************************
 *
 * FUNCTION: 	 FrmCustomAlert
 *
 * DESCRIPTION: This routine creates a modal dialog from an alert resource
 *              and displays the dialog until a button in the alert is hit.
 *              The item number of the button that was hit is returned.  
 *              A button's item number is determine by its order in the
 *              alert template, the first button has an item number of
 *              zero.
 *
 *					Up to three strings can be passed to this routine,
 *             they are used to replace the "text replacement variables"
 *             ^1, ^2 and ^3 that are contain in the message string
 *             of the alert.
 *
 *					NOTE: This function assumes enough dynamic memory exists.
 *
 * PARAMETERS:	 alertId   - resource id of the alert.
 *              s1        - string to replace ^1 
 *              s2        - string to replace ^2
 *              s3        - string to replace ^3
 *					
 * RETURNED:	 the button the was pressed (the first button is zero)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/22/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *			rsf	11/25/97	changed to take advantage of the dynamic ui calls
 *								Reserved an id range for the system dialog.
 *			vmk	12/10/97	Use FrmSave/RestoreActiveState to save and restore
 *								active form/window.
 *
 ***********************************************************************/
#define alertMsgXPos			32
#define alertXMargin			8
#define alertYMargin			7
#define minButtonWidth		36
#define alertButtonMargin	4
#define alertMaxMsgLines 	10

Word FrmCustomAlert (const Word alertId, const CharPtr s1, const CharPtr s2, 
	const CharPtr s3)
{
	AlertTemplateType * alertTempl;
	Handle rscHandle;
	Handle msgHandle;
	short x, y;
	short alertHeight;
	short displayWidth;
	short displayHeight;
	short alertMsgYPos;
	Word i;
	Word size;
	Word msgLen;
	Word msgHeight;
	Word buttonHit;
	FontID curFont;
	CharPtr ptr;
	CharPtr titleStrP;
	CharPtr buttonStrP;
	CharPtr msg;
	FormPtr frm;
	Word bitmapID;
	FieldPtr fieldP;
	ControlPtr controlP;
	FormActiveStateType	curFrmState;
	SndSysBeepType			beep;

	#if 0		// CASTRATION
	FormPtr curForm;
	Boolean insPtState;
	PointType insPtPos;
	WinHandle savedDrawWin;
	WinHandle savedActiveWin;
	#endif
	
	// Get the resource that defines the alert.	
	rscHandle = DmGetResource (alertRscType, alertId);
	alertTempl = (AlertTemplateType *) MemHandleLock(rscHandle);
	
	// Get pointers to the title, message, and first button string in the alert template.
	titleStrP = (CharPtr) (alertTempl + 1);
	msg = titleStrP + StrLen (titleStrP) + 1;		// skip over title string.
	buttonStrP = msg + StrLen (msg) + 1;			// skip over msg string.
	
	// Compute the size to the message string.  
	msgLen = 0;
	for (i = 0; msg[i]; i++)
		{
		// Find the "text replacement variables" in the massege.
		if (msg[i] == '^')
			{
			if (msg[i+1] == '1')
				msgLen += StrLen (s1);
			else if (msg[i+1] == '2')
				msgLen += StrLen (s2);
			else if (msg[i+1] == '3')
				msgLen += StrLen (s3);
			else
				msgLen++;
			}
		else
			msgLen++;
		}

	// Construct the message string,  substitute the tokens ^1, ^2 and ^3 
	// with the parameters passed.
	msgHandle = MemHandleNew (msgLen + 1);		// Freed by field object
	ptr = MemHandleLock (msgHandle);
	StrCopy (ptr, msg);
	while (*ptr)
		{
		if (*ptr != '^')
			ptr++;
		else
			{
			switch (ptr[1])
				{
				case '1':
					size = StrLen (s1);
					MemMove (ptr+size, ptr+2, StrLen (ptr+2)+1);
					MemMove (ptr, s1, size);
					ptr += size;
					break;
		
				case '2':
					size = StrLen (s2);
					MemMove (ptr+size, ptr+2, StrLen (ptr+2)+1);
					MemMove (ptr, s2, size);
					ptr += size;
					break;
		
				case '3':
					size = StrLen (s3);
					MemMove (ptr+size, ptr+2, StrLen (ptr+2)+1);
					MemMove (ptr, s3, size);
					ptr += size;
					break;
		
				default:
					ptr++;
				}
			}
		}
	*ptr = 0;											// null-terminate the massege
	ptr++;

	MemHandleUnlock (msgHandle);
	
	// Compute the height the message string.
	WinGetDisplayExtent (&displayWidth, &displayHeight);
	alertMsgYPos = FntLineHeight () + 1 +	// title height
						alertYMargin;				// margin above the messege

	
	frm = FrmNewForm (CustomAlertDialog, titleStrP, 2, 0, displayWidth - 4, displayHeight - 4, true, 
		CustomAlertFirstButton + alertTempl->defaultButton, alertTempl->helpRscID, 0);
	
	// Add the alert icon.
	switch (alertTempl->alertType)
		{
		case informationAlert:
			bitmapID = InformationAlertBitmap;
			break;
		case confirmationAlert:
			bitmapID = ConfirmationAlertBitmap;
			break;
		case warningAlert:
			bitmapID = WarningAlertBitmap;
			break;
		case errorAlert:
			bitmapID = ErrorAlertBitmap;
			break;
		}
	FrmNewBitmap (&frm, CustomAlertBitmap, bitmapID, alertXMargin, alertMsgYPos);
	
	// Add a text field to display the message.  A field is used because it can wrap the text.
	curFont = FntSetFont (boldFont);
	fieldP = FldNewField (&frm, CustomAlertField, alertMsgXPos, alertMsgYPos, displayWidth - alertMsgXPos - 6, 
		FntLineHeight () * alertMaxMsgLines, boldFont, 0, false, false, 
		false, false, leftAlign, false, false, false);
	FldSetTextHandle (fieldP, msgHandle);
	msgHeight = max (FldGetTextHeight (fieldP), (FntLineHeight () * 2));
	fieldP->rect.extent.y = msgHeight;
	
	// Add the buttons.
	x = alertButtonMargin + 1;								  // 1 for the frame
	y = alertMsgYPos + msgHeight + alertYMargin + 2;
	FntSetFont (stdFont);
	
	for (i = 0; i < alertTempl->numButtons ; i++)
		{
		controlP = CtlNewControl (&frm, CustomAlertFirstButton + i, buttonCtl, buttonStrP, 
						x, y, 0, 0, stdFont, 0, true);
		
		buttonStrP += StrLen(buttonStrP) + sizeofchar(nullChr);
		x += controlP->bounds.extent.x + alertButtonMargin + 2;  // 2 for frames
		}
	
	// Resize the form vertically now that we know the message height.
	alertHeight = y + 18;
	frm->window.windowBounds.topLeft.y = displayHeight - alertHeight - 2;
	frm->window.windowBounds.extent.y = alertHeight;
	
	
	FntSetFont (curFont);						// restore font
	
	// Because the form must be displayed before the sounds are played and FrmDoDialog
	// doesn't have a way for this routine to play the sounds after FrmDoDialog draws
	// the form, we must draw the form here and then play the sounds.
	
	#if 0		// CASTRATION
		insPtState = InsPtEnabled();
		InsPtGetLocation (&insPtPos.x, &insPtPos.y);
		
		curForm = FrmGetActiveForm ();
		if (! curForm)
			{
			savedDrawWin = WinGetDrawWindow ();
			savedActiveWin = WinGetActiveWindow ();
			}
	#endif
	
	FrmSaveActiveState(&curFrmState);				// save active form/window state
	
	FrmSetActiveForm (frm);      


	// Draw the form 
	FrmDrawForm (frm);

	// Play an alert sound
	beep = (SndSysBeepType)0;
	switch (alertTempl->alertType)
		{
		case informationAlert:
			beep = sndInfo;
			break;
		case confirmationAlert:
			beep = sndConfirmation;
			break;
		case warningAlert:
			beep = sndWarning;
			break;
		case errorAlert:
			beep = sndError;
			break;
		}
	if ( beep )
		SndPlaySystemSound(beep);
		
	
	buttonHit = FrmDoDialog (frm);
	
	FrmDeleteForm (frm);

	// These can maybe done sooner if the form doesn't depend on strings
	// within these resources.
	MemHandleUnlock(rscHandle);
	

	#if 0		// CASTRATION
		if (insPtState)
			InsPtSetLocation (insPtPos.x, insPtPos.y);

		if (curForm)
			FrmSetActiveForm (curForm);
		else
			{
			WinSetDrawWindow (savedDrawWin);
			WinSetActiveWindow (savedActiveWin);
			}
	#endif

	FrmRestoreActiveState(&curFrmState);				// restore active form/window state
	
	return (buttonHit - CustomAlertFirstButton);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmDoDialog
 *
 * DESCRIPTION: This routine displays a modal dialog until a button in 
 *              the dilog  is hit. The item number of the button that
 *              was hit is returned.  A button's item number is 
 *              determine by its order in the alert template, 
 *              the first button has an item number of zero.
 *
 * zzz This function should accept a callback to draw to the form.  FrmCustomAlert 
 * can use this to play sounds.
 *
 * PARAMETERS:	 frmPtr	  - memory block that contains the form.
 *					
 * RETURNED:	 the id of the button the was pressed
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/22/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *			vmk	12/10/97	Use FrmSave/RestoreActiveState to save and restore
 *								active form/window.
 *
 ***********************************************************************/
Word FrmDoDialog (const FormPtr frm)
{
	Word error;
	Word buttonHit;
	EventType event;
	FormActiveStateType	curFrmState;
	
	#if 0		// CASTRATION
	FormPtr curForm;
	Boolean insPtState;
	PointType insPtPos;
	WinHandle savedDrawWin;
	WinHandle savedActiveWin;
	#endif
	
	ECFrmValidatePtr(frm);
	
	#if 0		// CASTRATION
	insPtState = InsPtEnabled();
	InsPtGetLocation (&insPtPos.x, &insPtPos.y);
	
	curForm = FrmGetActiveForm ();
	if (! curForm)
		{
		savedDrawWin = WinGetDrawWindow ();
		savedActiveWin = WinGetActiveWindow ();
		}
	#endif
	
	FrmSaveActiveState(&curFrmState);		// save active form/window state

	FrmSetActiveForm (frm);
	if (! frm->attr.visible)
		FrmDrawForm (frm);
	FrmSetFocus (frm, frm->focus);

	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);
		
		if (frm->handler)
			{
			if (frm->handler (&event))
				continue;
			}
			
		if (! SysHandleEvent (&event))
			if (! MenuHandleEvent (0, &event, &error))
				FrmHandleEvent (frm, &event);

		if (event.eType == ctlSelectEvent)
			{
			
			if (((ControlPtr)(event.data.ctlSelect.pControl))->style == buttonCtl)
				{
				buttonHit = event.data.ctlSelect.controlID;
				break;
				}
			}


		else if (event.eType == appStopEvent)
			{
			buttonHit = frm->defaultButton;
			EvtAddEventToQueue (&event);
			break;
			}
		}

	FrmEraseForm (frm);
	
	#if 0		// CASTRATION
	if (insPtState)
		InsPtSetLocation (insPtPos.x, insPtPos.y);

	if (curForm)
		{
		if (curForm != frm)
			FrmSetActiveForm (curForm);
		}
	else
		{
		WinSetDrawWindow (savedDrawWin);
		WinSetActiveWindow (savedActiveWin);
		}
	#endif
	
	FrmRestoreActiveState(&curFrmState);		// restore active form/window state

	
	return (buttonHit);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmHelpScroll
 *
 * DESCRIPTION: This routine scrolls the help message in the direction 
 *              specified.
 *
 * PARAMETERS:	 frm       - pointer to the Help dialog
 *              direction - up or down
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/29/95	Initial Revision
 *
 ***********************************************************************/
static void FrmHelpScroll (FormPtr frm, DirectionType direction)
{
	Word upIndex;
	Word downIndex;
	Word linesToScroll;
	Boolean enableUp;
	Boolean enableDown;
	FieldPtr fld;

	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, HelpField));
	linesToScroll = FldGetVisibleLines (fld) - 1;
	FldScrollField (fld, linesToScroll, direction);

	enableUp = FldScrollable (fld, up);
	enableDown = FldScrollable (fld, down);
	upIndex = FrmGetObjectIndex (frm, HelpUpButton);
	downIndex = FrmGetObjectIndex (frm, HelpDownButton);

	FrmUpdateScrollers (frm, upIndex, downIndex, enableUp, enableDown);
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmHelp
 *
 * DESCRIPTION: This routine diplays the help message specified until the 
 *              done button, in the help dialog is hit.  The id passed 
 *              is the resource id of a string resource that contains the
 *              help message.
 *
 * PARAMETERS:	 helpMsgId   - resource id of help message string 
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/22/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *			vmk	12/10/97	Use FrmSave/RestoreActiveState to save and restore
 *								active form/window.
 *
 ***********************************************************************/
void FrmHelp (const Word helpMsgId)
{
	Word upIndex;
	Word downIndex;
	Handle helpStr;
	FormPtr frm;
	FieldPtr fld;
	Boolean enableUp;
	Boolean enableDown;
	Boolean done = false;
	EventType event;
	FormActiveStateType	curFrmState;
	
	#if 0		// CASTRATION
	FormPtr curForm;
	WinHandle savedDrawWin;
	WinHandle savedActiveWin;
	Boolean insPtState;
	#endif


	#if 0		// CASTRATION
	insPtState = InsPtEnabled();
	
	curForm = FrmGetActiveForm ();
	if (! curForm)
		{
		savedDrawWin = WinGetDrawWindow ();
		savedActiveWin = WinGetActiveWindow ();
		}
	#endif

	FrmSaveActiveState(&curFrmState);		// save active form/window state

	InsPtEnable (false);

	frm = FrmInitForm (HelpForm);

	helpStr = DmGetResource (strRsc, helpMsgId);
	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, HelpField));
	FldSetTextHandle (fld, helpStr);

	FrmSetActiveForm (frm);
	FrmDrawForm (frm);
	
	upIndex = FrmGetObjectIndex (frm, HelpUpButton);
	downIndex = FrmGetObjectIndex (frm, HelpDownButton);

	enableUp = FldScrollable (fld, up);
	enableDown = FldScrollable (fld, down);
	FrmUpdateScrollers (frm, upIndex, downIndex, enableUp, enableDown);
	
	while (! done)
		{
		EvtGetEvent (&event, evtWaitForever);
		if (! SysHandleEvent (&event))
			FrmHandleEvent (frm, &event);

		if (event.eType == ctlSelectEvent)
			{
			if (event.data.ctlSelect.controlID == HelpDoneButton)
				done = true;
			}
					
		else if (event.eType == ctlRepeatEvent)
			{
			switch (event.data.ctlSelect.controlID)
				{
				case HelpUpButton:
					FrmHelpScroll (frm, up);
					break;
					
				case HelpDownButton:
					FrmHelpScroll (frm, down);
					break;
				}
			}


		else if (event.eType == keyDownEvent)
			{
			switch (event.data.keyDown.chr)
				{
				case pageUpChr:
					FrmHelpScroll (frm, up);
					break;
					
				case pageDownChr:
					FrmHelpScroll (frm, down);
					break;
				}
			}


		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}

	FldSetTextHandle (fld, 0);
	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	
	#if 0		// CASTRATION
		if (curForm)
			FrmSetActiveForm (curForm);
		else
			{
			WinSetDrawWindow (savedDrawWin);
			WinSetActiveWindow (savedActiveWin);
			}
			
		InsPtEnable (insPtState);
	#endif

	FrmRestoreActiveState(&curFrmState);		// restore active form/window state

}

/***********************************************************************
 *
 * FUNCTION:    FrmUpdateScrollers
 *
 * DESCRIPTION: This routine draws or erases the field scroll arrow
 *              buttons depending of the contains of a field.
 *
 * PARAMETERS:  frm            - pointer to a form
 *              upIndex        - index of a the up scroller button
 *              downIndex      - index of a the down scroller button
 *              scrollableUp   - true if the up scroll should be active
 *              scrollabledown - true if the down scroll should be active
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/7/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmUpdateScrollers (const FormPtr frm, const Word upIndex, 
	const Word downIndex, const Boolean scrollableUp, 
	const Boolean scrollableDown)
{
	CharPtr scrollerLabel;
	Boolean scrollerVisible;
	Boolean scrollerEnabled;
	ControlPtr upCtl;
	ControlPtr downCtl;
		
	ECFrmValidatePtr(frm);
	
	upCtl = frm->objects[upIndex].object.control;
	downCtl = frm->objects[downIndex].object.control;

	// If not scrollable in either direction,  hide both scrollers.
	if ((! scrollableUp) && (! scrollableDown))
		{
		CtlHideControl (upCtl);
		CtlHideControl (downCtl);
		return;
		}

	// Show the up scroll button with the correct icon.  Enable or 
	// disable as appropriate.
	scrollerVisible = upCtl->attr.usable;
	scrollerEnabled = upCtl->attr.enabled;
	if (scrollableUp != scrollerEnabled)
		{
		scrollerLabel = *&upCtl->text;
		if (scrollableUp)
			*scrollerLabel = symbol7ScrollUp;
		else
			*scrollerLabel = symbol7ScrollUpDisabled;
		CtlSetEnabled (upCtl, scrollableUp);
		}

	if ( ! scrollerVisible)
		CtlShowControl (upCtl);
	else if ( (scrollableUp != scrollerEnabled) && (frm->attr.visible))
		{
		CtlEraseControl (upCtl);
		CtlDrawControl (upCtl);
		}


	// Show the down scroll button with the correct icon.  Enable or 
	// disable as appropriate.
	scrollerVisible = downCtl->attr.usable;
	scrollerEnabled = downCtl->attr.enabled;
	if (scrollableDown != scrollerEnabled)
		{
		scrollerLabel = *&downCtl->text;
		if (scrollableDown)
			*scrollerLabel = symbol7ScrollDown;
		else
			*scrollerLabel = symbol7ScrollDownDisabled;
		CtlSetEnabled (downCtl, scrollableDown);
		}

	if ( ! scrollerVisible)
		CtlShowControl (downCtl);
	else if ( (scrollableDown != scrollerEnabled) && (frm->attr.visible))
		{
		CtlEraseControl (downCtl);
		CtlDrawControl (downCtl);
		}
}


/***********************************************************************
 *
 * FUNCTION:    FrmVisible
 *
 * DESCRIPTION: This routine returns true if the form is visible.
 *
 * PARAMETERS:  frm - pointer to a form
 *
 * RETURNED:    true or false
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/24/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Boolean FrmVisible (const FormPtr frm)
{
	ECFrmValidatePtr(frm);
	
	return (frm->attr.visible);
}


/***********************************************************************
 *
 * FUNCTION:    FrmSetEventHandler
 *
 * DESCRIPTION: This routine set the event handle callback routine for
 *              the specificed form.  FrmHandleEvent will call this handler
 *              whenever it receives an event.
 *
 *              This routine should be call right after a form resource 
 *              is loaded.  The callback routine is the mechanics for 
 *              dispatching events to an application.
 *              
 *
 * PARAMETERS:  handler - address of a function
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetEventHandler (const FormPtr frm, 
	const FormEventHandlerPtr handler)
{
	ECFrmValidatePtr(frm);
	
	ErrNonFatalDisplayIf (handler == NULL, "NULL event handler");
	
	frm->handler = handler;
}


/***********************************************************************
 *
 * FUNCTION:    FrmDispatchEvent
 *
 * DESCRIPTION: This routine dispatches an event to the application's 
 *              handler for the form.
 *              
 * PARAMETERS: eventP - pointer to an event.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Boolean FrmDispatchEvent (const EventPtr eventP)
{
	FormPtr frm;

	// First dispatch the event to the application's handler for the form.
	// If the application's handler retruns true, then the event was 
	// handled and we should do nothing more with it.
	if (eventP->eType == frmOpenEvent)
		frm = FrmGetFormPtr (eventP->data.frmOpen.formID);

	else if (eventP->eType == frmGotoEvent)
		frm = FrmGetFormPtr (eventP->data.frmGoto.formID);

	else
		frm = CurrentForm;

	if (! frm) return (false);
	ErrFatalDisplayIf ((!frm->handler), "No event handler");

	if (frm->handler (eventP))
		return (true);
	
	return (FrmHandleEvent (frm, eventP));
}



/***********************************************************************
 *
 * FUNCTION:    FrmBroadcastEvent
 *
 * DESCRIPTION: This routine sends the passed event to all open
 *              forms.  Events are not posted to the event queue, the 
 *              form's event handlers are called directly.
 *
 * PARAMETERS:  eventP - pointer to the event to broadcast.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *
 ***********************************************************************/
static void FrmBroadcastEvent (EventPtr eventP)
{
	WinHandle winHandle;
	WinPtr winPtr;
	FormPtr frm;
	
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			
			if (frm->handler)
				frm->handler (eventP);
			}
		winHandle = winPtr->nextWindow;		
		}
}


/***********************************************************************
 *
 * FUNCTION:    FrmPopupForm
 *
 * DESCRIPTION: This routine sends a frmOpen event to the specified
 *              form.  This routine differs from GoToForm in that
 *              the current form is not closed.
 *
 * PARAMETERS:  formID  - resource id of form to open
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmPopupForm (const Word formId)
{
	EventType event;

	MemSet (&event, sizeof(EventType), 0);

	event.eType = frmLoadEvent;
	event.data.frmLoad.formID = formId;
	EvtAddEventToQueue (&event);
 
	event.eType = frmOpenEvent;
	event.data.frmOpen.formID = formId;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    FrmGotoForm
 *
 * DESCRIPTION: This routine sends a frmClose event to the current 
 *              form and sends a frmOpen event to the specified form.
 *              The form event handler (FrmHandleEvent) will erase and
 *              dispose of a form when it receives a frmColse event.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmGotoForm (const Word formId)
{
	Word curFormId;
	EventType event;

	MemSet (&event, sizeof(EventType), 0);

	curFormId = FrmGetActiveFormID ();
	if (curFormId)
		{
		event.eType = frmCloseEvent;
		event.data.frmClose.formID = curFormId;
		EvtAddEventToQueue (&event);
		}

	event.eType = frmLoadEvent;
	event.data.frmLoad.formID = formId;
	EvtAddEventToQueue (&event);
 
 	event.eType = frmOpenEvent;
	event.data.frmOpen.formID = formId;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    FrmUpdateForm
 *
 * DESCRIPTION: This routine sends a frmUpdate event to the specified
 *              form.  
 *
 * PARAMETERS:  formID  - resource id of form to open
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/23/95	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmUpdateForm (const Word formId, const Word updateCode)
{
	EventType event;

	MemSet (&event, sizeof(EventType), 0);
	event.eType = frmUpdateEvent;
	event.data.frmUpdate.formID = formId;
	event.data.frmUpdate.updateCode = updateCode;
	EvtAddEventToQueue (&event);
}


/***********************************************************************
 *
 * FUNCTION:    FrmReturnToForm
 *
 * DESCRIPTION: This routine erases and deletes the currently active 
 *              form and make the form specified the active form.
 *              It is assumed that the form that we're returning to
 *              is already loaded into memory.  Passing a form id of
 *              zero will return to the first form in the wiwndow list,  
 *              which is the last form to be loaded.
 *
 * PARAMETERS:  formID  - resource id of form to return to 
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	97/95		Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmReturnToForm  (const Word formId)
{
	FormPtr frm;

	frm = FrmGetActiveForm();
	MenuEraseStatus (0);
	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	
	// If no form id was specified get the id of the first form in the 
	// wiwndow list,  this will be the last form loaded.
	if (formId == 0)
		{
		frm = FrmGetFirstForm ();
		ErrFatalDisplayIf ( ! frm, "No form to return to");
		FrmSetActiveForm (frm);
		}
	else
		FrmSetActiveForm (FrmGetFormPtr (formId));
}

/***********************************************************************
 *
 * FUNCTION:    SendEventToForm
 *
 * DESCRIPTION: This routine sends an event to the specified form.
 *
 * PARAMETERS:  frm   - form to send an event to
 *              event - event to send
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/11/95	Initial Revision
 *
 ***********************************************************************/
static void SendEventToForm (FormPtr frm, EventPtr event)
{
	Boolean handled = false;
	
	ECFrmValidatePtr(frm);
	
	// Make the form the current draw window and the active form.
	WinSetDrawWindow (FrmGetWindowHandle (frm));
	CurrentForm = frm;

	// Call the form's event handler if it has one.
	if (frm->handler)
		{

		handled =  frm->handler (event);
		}

	if (! handled)
		FrmHandleEvent (frm, event);
}


/***********************************************************************
 *
 * FUNCTION:    FrmCloseAllForms
 *
 * DESCRIPTION: This routine sends a frmClose event to all open forms.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/11/95	Initial Revision
 *
 ***********************************************************************/
void FrmCloseAllForms (void)
{
	WinPtr winPtr;
	FormPtr frm;
	EventType event;
	WinHandle next;
	WinHandle winHandle;
	
	// Search the window list for forms.
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		next = winPtr->nextWindow;
		if (winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			MemSet (&event, sizeof(EventType), 0);
			event.eType = frmCloseEvent;
			event.data.frmClose.formID = frm->formId;
			SendEventToForm (frm, &event);
			}
		winHandle = next;	
		}
		
	CurrentForm = 0;

	WinSetActiveWindow (0);
	WinSetDrawWindow (WinGetDisplayWindow());
}


/***********************************************************************
 *
 * FUNCTION:    FrmSaveAllForms
 *
 * DESCRIPTION: This routine sends a frmSave event to all open forms.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/27/95	Initial Revision
 *
 ***********************************************************************/
void FrmSaveAllForms (void)
{
	WinPtr winPtr;
	EventType event;
	WinHandle winHandle;
	WinHandle curDrawWindow;
	FormPtr curForm;
	
	curDrawWindow = WinGetDrawWindow ();
	curForm = CurrentForm;
	
	// Search the window list for forms.
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		if (winPtr->windowFlags.dialog)
			{
			MemSet (&event, sizeof(EventType), 0);
			event.eType = frmSaveEvent;
			SendEventToForm ((FormPtr) winPtr, &event);
			}
		winHandle = winPtr->nextWindow;		
		}
		
	CurrentForm = curForm;
	WinSetDrawWindow (curDrawWindow);
}

/***********************************************************************
 *
 * FUNCTION:    DismissForms
 *
 * DESCRIPTION: This routine sends a frmClose event to all open forms 
 *              that have the dismissable attribute set.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/11/95	Initial Revision
 *
 ***********************************************************************/
#ifdef newcode
static void DismissForms (void)
{
	WinPtr winPtr;
	FormPtr frm;
	EventType event;
	WinHandle next;
	WinHandle winHandle;
	WinHandle curDrawWindow;
	FormPtr curForm;

	curDrawWindow = WinGetDrawWindow ();
	curForm = CurrentForm;
	
	// Search the window list for forms.
	winHandle = WinGetFirstWindow ();
	while (winHandle)
		{
		winPtr = WinGetWindowPointer (winHandle);
		next = winPtr->nextWindow;
		if (winPtr->windowFlags.dialog)
			{
			frm = (FormPtr) winPtr;
			if (frm->attr.dismissable)
				{
				if (curForm == frm)
					{
					curForm = 0;
					curDrawWindow = WinGetDisplayWindow ();
					}
		
				MemSet (&event, sizeof(EventType), 0);
				event.eType = frmCloseEvent;
				event.data.frmClose.formID = frm->formId;
				SendEventToForm (frm, &event);
				}
			}
		winHandle = next;	
		}
		
	CurrentForm = curForm;
	WinSetDrawWindow (curDrawWindow);
}
#endif


/***********************************************************************
 *
 * FUNCTION: 	 FrmPointInTitle
 *
 * DESCRIPTION: This routine returns true if the coordinate passed is within
 *              the bounds of form's title
 *
 * PARAMETERS:	 frmPtr	 memory block that contains the form.
 *              x        window relitave coordinate
 *              x        window relitave coordinate
 *
 * RETURNED:	 TRUE if coordinate is in the form's title
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	5/14/96	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Boolean FrmPointInTitle (const FormPtr frm, const Short x, const Short y)
{
	Word i;
	Short displayWidth;
	Short displayHeight;	
	CharPtr str;
	FontID currFont;
	RectangleType r;

	ECFrmValidatePtr(frm);
	
	for (i = 0; i < frm->numObjects; i++)
		{
		if (frm->objects[i].objectType == frmTitleObj)
			{
			str = frm->objects[i].object.title->text;
			if (! (*str))
				return (false);

			if (frm->window.windowFlags.modal)
				{
				WinGetWindowExtent (&displayWidth, &displayHeight);
				r.topLeft.x = 0;
				r.topLeft.y = 1;
				r.extent.x = displayWidth;
				r.extent.y = FntLineHeight ();
				}
			else
				{
				currFont = FntSetFont (titleFont);
				r.topLeft.x = 0;
				r.topLeft.y = 0;
				r.extent.x = FntCharsWidth (str, StrLen(str)) + (titleMarginX + (titleMarginX - 1));
				r.extent.y = titleHeight;
				FntSetFont (currFont);
				}
				
			return (RctPtInRectangle (x, y, &r));				
			}
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION: 	 SelectFormTitle
 *
 * DESCRIPTION: This routine is called whwn the form receives a 
 *              frmTitleEnter event.  It tracks the pen until the pen
 *              is released.  A frmTitleSelect event is sent if the pen
 *              is released within the bounds of the title.
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *              eventP  frmTitleEnter event
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/22/96	Initial Revision
 *
 ***********************************************************************/
static void SelectFormTitle (FormPtr frm, EventPtr eventP)
{
	Short x, y;
	Boolean inTitle;
	Boolean penDown;
	EventType event;

	ECFrmValidatePtr(frm);
	
	x = eventP->screenX;
	y = eventP->screenY;

	do 
		{
		inTitle = FrmPointInTitle (frm, x, y);
		PenGetPoint (&x, &y, &penDown);
		} while (penDown);


	if (inTitle)
		{
		MemSet (&event, sizeof(EventType), 0);
		event.eType = frmTitleSelectEvent;
		event.data.frmTitleSelect.formID = frm->formId;
		EvtAddEventToQueue (&event);
		}
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmSetMenu
 *
 * DESCRIPTION: This routine changes a form's menu bar. 
 *
 * PARAMETERS:	 frm     	memory block that contains the form.
 *              menuRscID  resource id of the menu
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/29/96	Initial Revision
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
void FrmSetMenu (const FormPtr frm, const Word menuRscID)
{
	MenuBarPtr menuP;

	ECFrmValidatePtr(frm);
	
	frm->menuRscId = menuRscID;

	if (CurrentForm == frm)
		{
		menuP = MenuGetActiveMenu ();
		if (menuP)
			MenuDispose (menuP);

		// Make the form's menu the active menu.
		if (frm->menuRscId)
			{
			//menuP = MenuInit (frm->menuRscId);
			MenuSetActiveMenuRscID (frm->menuRscId);
			}
		}
}


/***********************************************************************
 *
 * FUNCTION:    FrmValidatePtr
 *
 * DESCRIPTION: Validate a form pointer. 
 *
 * PARAMETERS:  frm  pointer to a form
 *
 * RETURNED:    true if the pointer is ok
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *			roger	2/6/98	Removed the check that the object list follows the form 
 *								structure and weakened the size checks.  
 *								Added additional checks
 *
 ***********************************************************************/
Boolean FrmValidatePtr (FormPtr frm)
{
	WinHandle windowInList;
	WinPtr    winPtr;
	
	
	ErrFatalDisplayIf(frm == NULL, "NULL form");
	

	// If the object list immeadiately follows the form make sure the chunk size is as big
	// as the size of a form plus the size of object list.
	if ((BytePtr) frm->objects == (BytePtr) (frm + 1) &&
		MemPtrSize(frm) < sizeof(FormType) + sizeof(FormObjListType) * frm->numObjects)
		goto badWindow;
		
	// Make sure the size of the chunk is the size of a form object.
	else if (MemPtrSize(frm) < sizeof(FormType))
		goto badWindow;
	
	if (frm->attr.reserved)
		goto badWindow;
		
	if (frm->attr.visible && !frm->attr.usable)
		goto badWindow;
	
	if (frm->focus != noFocus && frm->focus > frm->numObjects)
		goto badWindow;
	
	// Either the object list follows the form or it doesn't exist.
//	if ((BytePtr) frm->objects != (BytePtr) (frm + 1) || 
//		(frm->objects == NULL && frm->numObjects == 0))
//		goto badWindow;
	
	// would be nice to verify that frm->defaultButton is valid too
	
	
	// Verify the bits saved window if it exists.
	if (frm->bitsBehindForm != NULL)
		WinValidateHandle(frm->bitsBehindForm);
	
	// This last check looks for the window in the window list.  If 
	// found then this window seems valid.  If not, then it's a badWindow.
	windowInList = WinGetFirstWindow ();
	while (windowInList)
		{
		if (windowInList == WinGetWindowHandle(frm))
			break;
		
		winPtr = WinGetWindowPointer (windowInList);
		windowInList = winPtr->nextWindow;
		}
	if (windowInList != WinGetWindowHandle(frm))
		goto badWindow;
	 

	return WinValidateHandle(WinGetWindowHandle(frm));

badWindow:
	ErrNonFatalDisplayIf(true, "Bad form");
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    FrmNewForm
 *
 * DESCRIPTION: Create a form. 
 *
 * PARAMETERS:  formID - ID of the new form
 *					 titleStrP - the title
 *					 x - the left position of the form
 *					 y - the top position of the form
 *					 width - the width
 *					 height - the height
 *					 modal - true if the dialog is modal
 *					 defaultButton - the default button
 *					 helpRscID - the help string resource
 *					 menuRscID - the menu resource
 *
 * RETURNED:    pointer to a form or NULL for an error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
FormPtr FrmNewForm (const Word formID, const Char * const titleStrP, 
	Word x, Word y, Word width, Word height, const Boolean modal, 
	const Word defaultButton, const Word helpRscID, const Word menuRscID)
{
	Handle formH;
	FormPtr formP;
	UInt size;
	UInt numObjects;
	FormTitleType *titleP;
	
	
	size = sizeof (FormType);
	
	if (titleStrP)
		{
		numObjects = 1;
		size += sizeof (FormObjListType) * (numObjects) + sizeof (FormTitleType) + 
			StrLen(titleStrP) + sizeofchar(nullChr);
		}
	else
		numObjects = 0;
	
	formH = MemHandleNew(size);
	if (formH == NULL)
		return 0;
	
	formP = (FormPtr) MemHandleLock(formH);
	MemSet (formP, size, 0);
	
	if (modal)
		{
		formP->window.windowFlags.modal = modal;
		formP->window.frameType.word = dialogFrame;
		}
	else
		{
		formP->window.frameType.word = noFrame;
		ErrNonFatalDisplayIf(height != hwrDisplayHeight, "Non modal dialogs must be fullscreen");
		ErrNonFatalDisplayIf(helpRscID, "Only modal dialogs support help");
		}
	
	// Initialize the window info
	width += 2 * formP->window.frameType.bits.width;
	height += 2 * formP->window.frameType.bits.width;
	ErrNonFatalDisplayIf(x > hwrDisplayWidth, "form x off screen");
	ErrNonFatalDisplayIf(y > hwrDisplayHeight, "form y off screen");
	ErrNonFatalDisplayIf(width > hwrDisplayWidth, "form width larger than screen");
	ErrNonFatalDisplayIf(height > hwrDisplayHeight, "form height larger than screen");
	formP->window.windowBounds.extent.x = width - (formP->window.frameType.bits.width * 2);
	formP->window.windowBounds.extent.y = height - (formP->window.frameType.bits.width * 2);
	formP->window.windowBounds.topLeft.x = x;
	formP->window.windowBounds.topLeft.y = y;
	formP->window.windowFlags.dialog = true;		// part of a form
	formP->window.windowFlags.focusable = true;
	
	
	formP->attr.usable = true;
	formP->attr.saveBehind = true;
	
	formP->formId = formID;
	formP->helpRscId = helpRscID;
	formP->menuRscId = menuRscID;
	formP->defaultButton = defaultButton;
	formP->focus = noFocus;
	
	// Init the objects if we have a title
	if (numObjects)
		{
		formP->numObjects = numObjects;
		formP->objects = (FormObjListType *) (formP + 1);
		titleP = (FormTitleType *) (formP->objects + numObjects);
		
		// install the title into the object list
		formP->objects[0].objectType = frmTitleObj;
		formP->objects[0].object.ptr = titleP;

		// Initialize the title object
		titleP->text = (CharPtr) (titleP + 1);
		StrCopy(titleP->text, titleStrP);
		}
	
	WinInitializeWindow (FrmGetWindowHandle(formP));
	WinAddWindow (FrmGetWindowHandle(formP));
	
	return formP;
}


/***********************************************************************
 *
 * FUNCTION:    PrvFixupPointers
 *
 * DESCRIPTION: Update all pointers in a range to a moved zone by an offset. 
 *
 * PARAMETERS:  rangeP  pointer to the range to fixup
 *					 rangeSize - size of range to fixup
 *					 zoneP - pointer to the zone moved
 *					 zoneSize - size of zone moved
 *					 offset - offset of zone from old location
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
static void PrvFixupPointers(VoidPtr rangeP, DWord rangeSize, 
	VoidPtr zoneP, DWord zoneSize, DWord offset)
{
	Byte **p;
	Byte *zoneEndP;
	
	
	// Insure rangeP isn't odd because pointers are aligned
	// with every two bytes.
	if ((DWord) rangeP & 1)
		{
		p = (Byte **) ((DWord) rangeP + 1);
		rangeSize -= 1;
		}
	else
		{
		p = (Byte **) rangeP;
		}
	
	rangeSize /= (2 * sizeof(Byte));
	zoneEndP = (BytePtr) zoneP + zoneSize;
	while (rangeSize > 0)
		{
		if (zoneP <= *p && *p <= zoneEndP)
			*p += offset;
		
		p = (Byte **) ((DWord) p + 2 * sizeof(Byte));
		rangeSize--;
		}
}


/***********************************************************************
 *
 * FUNCTION:    FrmAddSpaceForObject
 *
 * DESCRIPTION: Add space to a form for an object and add the object into 
 *					 the form's list of objects. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form.  Set if moved.
 *					 objectPP - pointer to a pointer to an object.  Set to the location made.
 *					 objectType - the type of object
 *					 objectSize - size of the object.  Must include space for extras
 *									  like strings.
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
Err FrmAddSpaceForObject (FormPtr *formPP, Ptr *objectPP, 
	FormObjectKind objectKind, Word objectSize)
{
	Handle formH;
	FormPtr formP;
	UInt newSize;
	UInt oldSize;
	Ptr oldLocationP;
	Ptr newLocationP;
	Err error;
	Word bytesFromNewObjListEntryToEndOfFormChunk;
	
	
	ECFrmValidatePtr(*formPP);
	
	oldLocationP = (Ptr) *formPP;
	formH = MemPtrRecoverHandle(*formPP);
	oldSize = MemHandleSize(formH);
	oldSize = (oldSize + 1) & (~1);
	newSize = ((oldSize + 1) & (~1)) + 		// Round the oldSize up to a word boundary.
		sizeof(FormObjListType) + objectSize;
	MemHandleUnlock(formH);
	error = MemHandleResize(formH, newSize);
	if (error)
		return error;
	
	newLocationP = (Ptr) MemHandleLock(formH);
	formP = (FormPtr) newLocationP;
	*formPP = formP;
	
	// Handle any chunk movement
	if (newLocationP != oldLocationP)
		{
		PrvFixupPointers(newLocationP, oldSize, 
			oldLocationP, oldSize, newLocationP - oldLocationP);
			
		if (CurrentForm == (FormPtr) oldLocationP)
			CurrentForm = (FormPtr) newLocationP;
		
		WinMoveWindowAddr((WinPtr) oldLocationP, (WinPtr) newLocationP);
		}
	
	// make a hole to add in another object list item
	bytesFromNewObjListEntryToEndOfFormChunk = (newLocationP + oldSize) - 
		(Ptr) &formP->objects[formP->numObjects];
	MemMove(&formP->objects[formP->numObjects + 1], &formP->objects[formP->numObjects], 
		bytesFromNewObjListEntryToEndOfFormChunk);
	
	// fixup all pointers in the form which pointed at the memory just moved
	PrvFixupPointers(formP->objects, oldSize + sizeof(FormObjListType) - 
		((DWord) formP->objects - (DWord) formP), 
		&formP->objects[formP->numObjects], 
		bytesFromNewObjListEntryToEndOfFormChunk, 
		sizeof(FormObjListType));
	
	// Set the object list item
	formP->objects[formP->numObjects].objectType = objectKind;
	*objectPP = newLocationP + newSize - objectSize;
	formP->objects[formP->numObjects].object.ptr = *objectPP;
	formP->numObjects += 1;
	
	// zero the new space 
	MemSet(*objectPP, objectSize, 0);
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    FrmRemoveObject
 *
 * DESCRIPTION: Remove an object from a form.  This shrinks the form's 
 * object list and resizes the form chunk to a smaller size, fixing up
 * all the pointers.  It doesn't free any memory referenced by the object.
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form.  Set if moved.
 *					 objIndex - index to an object to remove
 *
 * RETURNED:    0 if no error
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/6/98	Initial Revision
 *
 ***********************************************************************/
Err FrmRemoveObject (FormPtr *formPP, Word objIndex)
{
	Handle formH;
	FormPtr formP;
	UInt newSize;
	UInt oldSize;
	Err error;
	Word sizeToMove;
	BytePtr locationToRemove;
	BytePtr locationAfterRemove;
	
	
	ECFrmValidatePtr(*formPP);
	
	
	formH = MemPtrRecoverHandle(*formPP);
	oldSize = MemHandleSize(formH);
	oldSize = (oldSize + 1) & (~1);
	formP = *formPP;
	ErrNonFatalDisplayIf ((objIndex >= formP->numObjects), "Invalid index");
	
	// If the object isn't the last one then fill in the hole
	if (objIndex < formP->numObjects - 1)
		{
		locationToRemove = formP->objects[objIndex].object.ptr;
		locationAfterRemove = formP->objects[objIndex + 1].object.ptr;
		sizeToMove = (BytePtr) formP + oldSize - locationAfterRemove;
		
		// Move all the objects after the one being removed.
		MemMove(locationToRemove, locationAfterRemove, sizeToMove);
		
		// Fixup the pointers in the form's chunk.  Skip the form object itself which
		// doesn't have any pointers to the objects.
		PrvFixupPointers(formP->objects, oldSize - sizeof(FormType), 
			locationAfterRemove,
			sizeToMove,
			locationToRemove - locationAfterRemove);
		
		newSize = oldSize - (locationAfterRemove - locationToRemove);
		}
	else
		newSize = (Ptr) formP->objects[objIndex].object.ptr - (Ptr) formP;
	
	// Now fixup the object list.
	locationToRemove = (BytePtr) &formP->objects[objIndex];
	locationAfterRemove = (BytePtr) &formP->objects[objIndex + 1];
	sizeToMove = (BytePtr) formP + newSize - locationAfterRemove;
	
	// Remove the object list entry by moving the list entries after the hole
	// as well as all the objects.
	MemMove(locationToRemove, locationAfterRemove, sizeToMove);
	
	newSize -= sizeof(FormObjListType);
	
	PrvFixupPointers(formP->objects, newSize - sizeof(FormType), 
		locationAfterRemove, 
		sizeToMove,
		-sizeof(FormObjListType));
	
	// The form now has one less object.
	formP->numObjects -= 1;
	
	// Now shrink the form chunk to it's new size.
	MemHandleUnlock(formH);
	error = MemHandleResize(formH, newSize);
	*formPP = MemHandleLock(formH);
	
	// If this ever proves false we'll need to fixup all the pointers in
	// the chunk to where the block is moved.
	ErrNonFatalDisplayIf (*formPP != formP, "Form shouldn't move");
	
	
	return error;
}


/***********************************************************************
 *
 * FUNCTION:    FrmNewLabel
 *
 * DESCRIPTION: Create a label. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 ID - ID of the new label
 *					 textP - string for the new label.  Copied after the label.
 *					 x - x of the new label
 *					 y - y of the new label
 *					 font - font of the new label
 *
 * RETURNED:    0 if error else a pointer to the label
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
FormLabelType * FrmNewLabel (VoidPtr *formPP, const Word ID, const Char * const textP, 
	const Word x, const Word y, const FontID font)
{
	UInt size;
	FormLabelType *labelP;
	Err error;
	
	
	size = sizeof(FormLabelType);
	if (textP)
		size += StrLen(textP) + sizeofchar(nullChr);
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)labelP, frmLabelObj, size);
	if (error)
		return 0;
	
	labelP->id = ID;
	labelP->pos.x = x;
	labelP->pos.y = y;
	
	labelP->attr.usable = true;
	labelP->fontID = font;
	
	if (textP)
		{
		labelP->text = (CharPtr) (labelP + 1);
		StrCopy(labelP->text, textP);
		}
	
	return labelP;
}


/***********************************************************************
 *
 * FUNCTION:    FrmNewBitmap
 *
 * DESCRIPTION: Create a form bitmap object to display an existing bitmap resource. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 ID - ID of the new bitmap
 *					 rscID - resource ID of the bitmap to display.
 *					 x - x of the new bitmap
 *					 y - y of the new bitmap
 *					 font - font of the new bitmap
 *
 * RETURNED:    0 if error else a pointer to the bitmap
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
FormBitmapType * FrmNewBitmap (VoidPtr *formPP, const Word id, const Word rscID, 
	const Word x, const Word y)
{
	FormBitmapType *bitmapP;
	Err error;
	
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)bitmapP, frmBitmapObj, 
				sizeof(FormBitmapType));
	if (error)
		return 0;
	
	bitmapP->pos.x = x;
	bitmapP->pos.y = y;
	
	bitmapP->attr.usable = true;
	
	bitmapP->rscID = rscID;
	
	return bitmapP;
}


/***********************************************************************
 *
 * FUNCTION:    FrmNewGadget
 *
 * DESCRIPTION: Create a form gadget object to display an existing gadget resource. 
 *
 * PARAMETERS:  formPP - pointer to a pointer to a form. Set if the form moves.
 *					 ID - ID of the new gadget
 *					 x - x of the new gadget
 *					 y - y of the new gadget
 *
 * RETURNED:    0 if error else a pointer to the gadget
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/19/97	Initial Revision
 *
 ***********************************************************************/
FormGadgetType * FrmNewGadget (VoidPtr *formPP, const Word id, 
	const Word x, const Word y, const Word width, const Word height)
{
	FormGadgetType *gadgetP;
	Err error;
	
	
	error = FrmAddSpaceForObject ((FormPtr *) formPP, &(Ptr)gadgetP, frmGadgetObj, 
				sizeof(FormGadgetType));
	if (error)
		return 0;
	
	gadgetP->id = id;
	gadgetP->rect.topLeft.x = x;
	gadgetP->rect.topLeft.y = y;
	gadgetP->rect.extent.x = width;
	gadgetP->rect.extent.y = height;
	
	gadgetP->attr.usable = true;
	
	return gadgetP;
}


/***********************************************************************
 *
 * FUNCTION:    FrmActiveState
 *
 * DESCRIPTION: Saves and restores active Form/Window state.
 *
 *					The caller is expected to use the "helper" macros
 *					FrmSaveActiveState and FrmRestoreActiveState
 *					instead of calling this function directly.
 *
 * PARAMETERS:	stateP	-- ptr to state structure
 *					save		-- if ture, save, otherwise restore active state	
 *
 * RETURNED:    0 if on success
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	12/10/97	Initial Revision
 *
 ***********************************************************************/
Err FrmActiveState (FormActiveStateType* stateP, Boolean save)
{
	Err err = 0;
	PrvActiveStateType* sP = (PrvActiveStateType*)stateP;
	
	ErrFatalDisplayIf (!sP, "null ptr arg");

	//------------------------------------------------------------
	// Check to make sure our state structure fits in the user param.
	// The compiler will normally compile this line out, unless
	// the assertion fails, in which case a link error will be
	// generated.
	//------------------------------------------------------------
	if (sizeof(PrvActiveStateType) > sizeof(FormActiveStateType))
		ThisShouldGenerateALinkError ();


	if ( save )
		{
		sP->sig = prvActiveStateSignature;
		
		sP->insPtState = InsPtEnabled();
		InsPtGetLocation (&sP->insPtPos.x, &sP->insPtPos.y);
		
		sP->curForm = FrmGetActiveForm ();
		if (! sP->curForm)
			{
			sP->savedDrawWin = WinGetDrawWindow ();
			sP->savedActiveWin = WinGetActiveWindow ();
			}
		}
	else
		{
		// Catch calls to restore state that wasn't saved first
		ErrFatalDisplayIf (sP->sig != prvActiveStateSignature, "invalid state passed");

		InsPtSetLocation (sP->insPtPos.x, sP->insPtPos.y);

		if (sP->curForm)
			{
			FrmSetActiveForm (sP->curForm);
			}
		else
			{
			WinSetDrawWindow (sP->savedDrawWin);
			WinSetActiveWindow (sP->savedActiveWin);
			}
			
		InsPtEnable (sP->insPtState);
		}
	
	
	return err;
}


/***********************************************************************
 *
 * FUNCTION: 	 FrmHandleEvent
 *
 * DESCRIPTION: 
 *
 * PARAMETERS:	 frmPtr	memory block that contains the form.
 *					
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/7/94	Initial Revision
 *			art	2/20/96	Added scroll bar
 *			art	7/22/96	Added frm title events
 *			trev	08/11/97	mode non modified passed variables constant
 *
 ***********************************************************************/
Boolean FrmHandleEvent (const FormPtr frm, const EventPtr eventP)
{
	FormObjectKind objType;
	FormObjectType obj;
	ControlPtr ctl;
	EventType event;
	TablePtr table;
	CharPtr str;
	Boolean handled;
	Word objIndex;

	ECFrmValidatePtr(frm);
	
	handled = false;

	if (eventP->eType == penDownEvent)
		{
		if (PointInObject (frm, eventP->screenX, eventP->screenY, &objIndex))
			{
			objType = frm->objects[objIndex].objectType;
			obj = frm->objects[objIndex].object;
			
			ReleaseFocus (frm, objIndex);
			if (objType == frmFieldObj || objType == frmTableObj)
				frm->focus = objIndex;

			if (objType == frmFieldObj)
				handled = FldHandleEvent (obj.field, eventP);

			else if (objType == frmTableObj)
				handled = TblHandleEvent (obj.table, eventP);

			else if (objType == frmControlObj)
				handled = CtlHandleEvent (obj.control, eventP);

			else if (objType == frmListObj)
				handled = LstHandleEvent (obj.list, eventP);
			
			else if (objType == frmScrollBarObj)
				handled = SclHandleEvent (obj.scrollBar, eventP);
			}
		else if (HelpHandleEvent (frm, eventP))
			{
			handled = true;
			}
		else if (FrmPointInTitle (frm, eventP->screenX, eventP->screenY))
			{
			MemSet (&event, sizeof(EventType), 0);
			event.eType = frmTitleEnterEvent;
			event.data.frmTitleEnter.formID = frm->formId;
			EvtAddEventToQueue (&event);
			handled = true;
			}
		}

	else if (eventP->eType == keyDownEvent)
		{
		if (frm->focus != noFocus)
			{
			objType = frm->objects[frm->focus].objectType;
			obj = frm->objects[frm->focus].object;
		
			if (objType == frmFieldObj)
				handled = FldHandleEvent (obj.field, eventP);
			else if (objType == frmTableObj)
				handled = TblHandleEvent (obj.table, eventP);
			}

		if ( (! handled)  &&  (eventP->data.keyDown.chr == confirmChr) )
			{
			SendConfirmEvent (frm);
			handled = true;
			}
		}

	else if (eventP->eType == tblEnterEvent)
		{
		table = eventP->data.tblEnter.pTable;
		handled = TblHandleEvent (table, eventP);
		}

	else if ((eventP->eType == fldEnterEvent) ||
				(eventP->eType == fldHeightChangedEvent))
		{
		if (frm->focus != noFocus)
			{
			objType = frm->objects[frm->focus].objectType;
			obj = frm->objects[frm->focus].object;
		
			if (objType == frmFieldObj)
				handled = FldHandleEvent (obj.field, eventP);
			else if (objType == frmTableObj)
				handled = TblHandleEvent (obj.table, eventP);
			}
		}

	else if (eventP->eType == ctlEnterEvent)
		{
		// If a grouped control was pressed, turn off the current selection
		//	of the group.
		ctl = eventP->data.ctlEnter.pControl;
		if (ctl->group)
			{
			objIndex = FrmGetControlGroupSelection (frm, ctl->group);
			FrmSetControlValue (frm, objIndex, false);
			}

		handled = CtlHandleEvent(ctl, eventP);

		// If a grouped control was pressed, but the pen has released outside 
		//	the control, turn the prior selection back on.
		if (ctl->group && (!ctl->attr.on))
			{
			FrmSetControlValue (frm, objIndex, true);				
			}
		}

	else if (eventP->eType == ctlRepeatEvent)
		{
		handled = CtlHandleEvent(eventP->data.ctlEnter.pControl, eventP);
		}

	else if (eventP->eType == ctlSelectEvent)
		{
		ctl = eventP->data.ctlEnter.pControl;
		if (ctl->style == popupTriggerCtl)
			{
			FrmPopupList (frm, eventP);
			}
		}

	else if (eventP->eType == popSelectEvent)
		{
		str = LstGetSelectionText (eventP->data.popSelect.listP, 
		                           eventP->data.popSelect.selection);
		CtlEraseControl (eventP->data.popSelect.controlP);                           
		CtlSetLabel (eventP->data.popSelect.controlP, str);
		CtlDrawControl (eventP->data.popSelect.controlP);
		}

	else if (eventP->eType == lstEnterEvent)
		{
		handled = LstHandleEvent(eventP->data.lstEnter.pList, eventP);
		}

	else if (eventP->eType == frmCloseEvent)
		{
		MenuEraseStatus (0);
		FrmSetFocus (frm, noFocus);
		FrmEraseForm (frm);
		FrmDeleteForm (frm);
		handled = true;
		}
	
	else if (eventP->eType == frmUpdateEvent)
		{
		FrmDrawForm (frm);
		handled = true;
		}
		
	else if (eventP->eType == menuEvent)
		{
		handled = DoMenuCommand (frm, eventP->data.menu.itemID);
		}
		
	else if (eventP->eType == sclEnterEvent || eventP->eType == sclRepeatEvent)
		{
		handled = SclHandleEvent (eventP->data.sclRepeat.pScrollBar, eventP);
		}
		
	else if (eventP->eType == frmTitleEnterEvent)
		{
		SelectFormTitle (frm, eventP);
		handled = true;
		}

	return (handled);
}
