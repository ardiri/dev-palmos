/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     Category.c
 * AUTHOR:	 Art Lamb: Feb 24, 1995
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contains routine for managing categories. 
 *
 **********************************************************************/
#include <Pilot.h>
#include <Graffiti.h>


// Extract the bit at position index from bitfield.  0 is the high bit.
#define BitAtPosition(pos)	((ULong)1 << (pos))
#define GetBitMacro(bitfield, index)	((bitfield) & BitAtPosition(index))
#define SetBitMacro(bitfield, index)	((bitfield) |= BitAtPosition(index))
#define RemoveBitMacro(bitfield, index)	((bitfield) &= ~BitAtPosition(index))


// Uniq IDs for category names used for synchronation.
#define firstDeviceUniqID		0x00		// high bit clear
#define lastDeviceUniqID		0x7F		// high bit clear
#define firstPCUniqID			0x80		// high bit set
#define lastPCUniqID				0xFF		// high bit set


#if COUNTRY == COUNTRY_FRANCE

	#define maxCategoryWidth		55			// max category display width

#elif COUNTRY == COUNTRY_GERMANY

	#define maxCategoryWidth		65			// max category display width

#elif COUNTRY == COUNTRY_ITALY

	#define maxCategoryWidth		70			// max category display width

#elif COUNTRY == COUNTRY_SPAIN

	#define maxCategoryWidth		70			// max category display width

#else	// COUNTRY_UNITED_STATES

	#define maxCategoryWidth		70			// max category display width

#endif

/***********************************************************************
 *
 * FUNCTION:    GetCategories
 *
 * DESCRIPTION: Get the categories from the specified  database.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    handle of the AppInfoType block
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/22/95	Initial Revision
 *
 ***********************************************************************/
static AppInfoType * GetCategories (DmOpenRef db)
{
	UInt 		cardNo;
	LocalID 	dbID;
	LocalID 	appInfoID;

	// Get the categories from the database.	
	if (DmOpenDatabaseInfo (db, &dbID, NULL, NULL, &cardNo, NULL))
		{
		ErrFatalDisplayIf (1, "Bad database ID");
		return (0);
		}
		
	if (DmDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
			&appInfoID, NULL, NULL, NULL))
		{
		ErrFatalDisplayIf (1, "Bad database ID");
		return (0);
		}
	return MemHandleLock((MemLocalIDToGlobal (appInfoID, cardNo)));
}


/***********************************************************************
 *
 * FUNCTION:    GiveCategoryNewUniqID
 *
 * DESCRIPTION: Give the category a uniq ID.  To be used whenever a 
 *					 category is created and kept until deletion.
 *
 * PARAMETERS:  appCategories - pointer to the categories
 *					 index - which category to change
 *
 * RETURNED:    nothing
 *					 the category's uniq id is set
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/22/95	Initial Revision
 *
 ***********************************************************************/
static void GiveCategoryNewUniqID (AppInfoType * appCategories, UInt index)
{
	UInt 		newUniqID;
	UInt	 	i;
	AppInfoType*	nilP=0;
	Byte		newValue;
	
	newUniqID = appCategories->lastUniqID + 1;
	if (newUniqID > lastDeviceUniqID)
		newUniqID = firstDeviceUniqID;
	
	do {
		// Look to see if the new Uniq ID is already used
		for (i = 0; i < dmRecNumCategories; i++)
			if (appCategories->categoryUniqIDs[i] == newUniqID)
				break;
		
		// If the new Uniq ID is used by a category try the next one
		if (i < dmRecNumCategories)
			{
			newUniqID++;
			if (newUniqID > lastDeviceUniqID)
				newUniqID = firstDeviceUniqID;
			continue;
			}
		else
			{
			break;
			}
		}
	while (true);
	
	// Write the change
	newValue = newUniqID;
	DmWrite(appCategories, (ULong)&nilP->categoryUniqIDs[index], 
					&newValue, sizeof(newValue));
	DmWrite(appCategories, (ULong)&nilP->lastUniqID, 
					&newValue, sizeof(newValue));
}


/***********************************************************************
 *
 * FUNCTION:    CategoryCompare
 *
 * DESCRIPTION: Case blind comparision of two category names. This routine is 
 *              used as a callback routine when sorting the the category list.
 *
 * PARAMETERS:  s1 - a category name (null-terminated)
 *              s2 - a category name (null-terminated)
 *
 * RETURNED:    if s1 > s2  - a positive integer
 *              if s1 = s2  - zero
 *              if s1 < se  - a negative integer
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	7/18/95	Initial Revision
 *
 ***********************************************************************/
static Int CategoryCompare (CharPtr *s1, CharPtr *s2, Long other)
{
	return StrCompare(*s1, *s2);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryCreateList
 *
 * DESCRIPTION: Read a database's categories and set the categories 
 *              list's items.
 *
 * PARAMETERS:  db - opened database containing category info
 *					 listP - list in which to place the categories
 *					 currentCategory - category to select
 *					 showAll - true to have an all category
 *					 showHidden - true to show hidden categories
 *					 numUneditableCategories - number of categories considered 
 *							uneditable.  These are stored first.
 *					 editingString - A resource type to string to edit categories.
 *					 resizeList - true to resize the list to the number of 
 *							categories.  Set true for popups, false otherwise.
 *
 * RETURNED:    CategoryListItemsHandle is set to the list's choices.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/22/95	Initial Revision
 *			roger	8/8/96	Added Uneditables and the editing string code.
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
extern void CategoryCreateList (const DmOpenRef db, const ListPtr listP, 
	const Word currentCategory, const Boolean showAll, 
	const Boolean showUneditables, const Byte numUneditableCategories, 
	const DWord editingStrID, const Boolean resizeList)
{
	Word		index;
	Word		length;
	AppInfoType * appCategories;
	VoidHand itemsHandle;
	VoidPtr  itemsPtr;			// Freed by CategoryFreeList
	CharPtr	listItems[dmRecNumCategories + 2];
	Int		listIndex;
	CharPtr	str;
	Handle	allStringH;
	Handle	EditCategoriesStringH;


	appCategories = GetCategories (db);

	if (showAll)
		{
		allStringH = DmGetResource(strRsc, categoryAllStrID);
		listItems[0] = MemHandleLock(allStringH);
		listIndex = 1;
		}
	else
		listIndex = 0;

	// For each category not empty, copy it's string to the list's
	// item list.
	for (index = numUneditableCategories; index < dmRecNumCategories; index++)
		{
		if (appCategories->categoryLabels[index][0] != '\0')
			{
			listItems[listIndex++] = appCategories->categoryLabels[index];
			}
		}
		
		
	// Sort the category list.  The "All" item should always be first
	// if it's present.
	if (showAll)
		SysQSort(&listItems[1], listIndex-1, sizeof (CharPtr), (CmpFuncPtr)CategoryCompare, 0);
	else
		SysQSort(&listItems[0], listIndex, sizeof (CharPtr), (CmpFuncPtr)CategoryCompare, 0);
		

	// Add "uneditable" items to the end of the list.
	if (showUneditables)
		{
		for (index = 0; index < numUneditableCategories; index++)
			{
			if (appCategories->categoryLabels[index][0] != '\0')
				{
				listItems[listIndex++] = appCategories->categoryLabels[index];
				}
			}
		}
	
	// Add "edit categories" item to the end of the list.
	if (editingStrID)
		{
		EditCategoriesStringH = DmGetResource(strRsc, editingStrID);
		listItems[listIndex++] = MemHandleLock(EditCategoriesStringH);
		}
	

	// Allocate a block to hold the items in the list.  This block is freed
	// when the list is disposed of.
	if (listIndex > 0)
		{
		length = (listIndex) * sizeof (CharPtr);
		itemsHandle = MemHandleNew (length);
		itemsPtr = MemHandleLock (itemsHandle);
		MemMove(itemsPtr, listItems, length);
		}
	else
		{
		itemsPtr = NULL;
		}
	
	LstSetListChoices (listP, itemsPtr, listIndex);
	if (resizeList)
		LstSetHeight (listP, listIndex);


	// Is the current category the "unfiled" category?
	if (currentCategory < numUneditableCategories)
		{
		if (showUneditables)
			LstSetSelection (listP, listIndex - (editingStrID ? 2 : 1) - 
				(numUneditableCategories - 1 - currentCategory));
		else
			LstSetSelection (listP, noListSelection);
		}
		
	// Is the current category the "All" categories?
	else if (currentCategory == dmAllCategories)
		{
		if (showAll)
			{
			LstSetSelection (listP, 0);
			}
		else
			{
			LstSetSelection (listP, noListSelection);
			}
		}
	
	// Find the current category in the in the sorted category list.
	else if (*appCategories->categoryLabels[currentCategory])
		{
		str = appCategories->categoryLabels[currentCategory];
		for (index = showAll ? 1 : 0; index < listIndex; index++)	// skip All if present
			if (StrCompare (str, listItems[index]) == 0)
				{ 
				LstSetSelection (listP, index);
				break;
				}
		}
	
	// If all else fails set the current list selection to the "unfiled" item.
	else
		{
		if (listIndex > 0)
			LstSetSelection (listP, listIndex - (editingStrID ? 2 : 1) - (numUneditableCategories - 1));
		else
			LstSetSelection (listP, noListSelection);
		}
	
	
	// Make the item visible
	LstMakeItemVisible (listP, LstGetSelection (listP));
	
	
	// Don't unlock the app info block because there are pointers into it	
}


/***********************************************************************
 *
 * FUNCTION:    CategoryFreeList
 *
 * DESCRIPTION: This routine unlocks or frees memory locked or allocated
 *              by CategoryCreateList.
 *
 * PARAMETERS:  db - database containing the categories
 *					 listP - pointer to the category list
 *					 showAll - true if the list was created with an All category
 *					 allowEditing - true if the list was created to allow editing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/23/95	Initial Revision
 *			roger	4/18/96	Revised to handle multiple lists
 *
 ***********************************************************************/
void CategoryFreeList (const DmOpenRef db, const ListPtr listP, 
	const Boolean showAll, const DWord editingStrID)
{
	VoidPtr categoriesP;
	
	
	if (listP->itemsText)
		MemPtrFree (listP->itemsText);
	
	categoriesP = GetCategories (db);
	MemPtrUnlock(categoriesP);
	MemPtrUnlock(categoriesP);	// unlock lock before this call

	// Depending on how CategoryCreateList was called it locked certain 
	// resources.  Unlock those it used.
	if (showAll)
		MemHandleUnlock(DmGetResource(strRsc, categoryAllStrID));
	
	if (editingStrID)
		MemHandleUnlock(DmGetResource(strRsc, editingStrID));
	
}


/***********************************************************************
 *
 * FUNCTION:    CategoryFind
 *
 * DESCRIPTION: This routine returns the index of the category that 
 *              match the name passed.
 *
 * PARAMETERS:  name - category name
 *
 * RETURNED:    category index
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/6/95	Initial Revision
 *			roger	4/12/96	Changed to return dmAllCategories when no category is found
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Word CategoryFind (const DmOpenRef db, const Char * const name)
{
	AppInfoType * appCategories;
	Word		     index;


	appCategories = GetCategories (db);
	for (index = 0; index < dmRecNumCategories; index++)
		{
		if (StrCompare (appCategories->categoryLabels[index], name) == 0)
			{
			MemPtrUnlock(appCategories);
			return (index);
			}
		}
	MemPtrUnlock(appCategories);

	return (dmAllCategories);			
}


/***********************************************************************
 *
 * FUNCTION:    CategoryGetName
 *
 * DESCRIPTION: This routine returns name the specified category.
 *
 * PARAMETERS:  db    - database the contains the categories
 *              index - category index
 *              name  - buffer to hold category name
 *
 * RETURNED:    category name in buffer passed
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/7/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CategoryGetName (const DmOpenRef db, const Word index, Char * const name)
{
	AppInfoType * appCategories;


	if (index == dmAllCategories)
		{
		SysCopyStringResource(name, categoryAllStrID);
		}
	else
		{
		ErrFatalDisplayIf(index >= dmRecNumCategories, "Bad Category");
		appCategories = GetCategories (db);
		StrCopy (name, appCategories->categoryLabels[index]);
		MemPtrUnlock(appCategories);
		}
}


/***********************************************************************
 *
 * FUNCTION:    CategorySetName
 *
 * DESCRIPTION: Set the category name and rename bits. A NULL ptr
 * removes the category name.  Set the uniq ID if the name is new
 * (replaces an empty string name).
 *
 * PARAMETERS:  db - database containing the categories to change
 *					 index - index of category to set
 *              name - a category name (null-terminated) or 
 *							  NULL ptr to remove the category
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	4/16/96	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CategorySetName (const DmOpenRef db, Word index, const CharPtr nameP)
{
	AppInfoType *	appCategories;
	AppInfoType *	nilP = 0;
	ULong				offset;
	Char				zero = 0;
	UInt				renamedCategories;


	appCategories = GetCategories (db);
	offset = (ULong)&nilP->categoryLabels[index];
	renamedCategories = appCategories->renamedCategories;
	
	if (nameP == NULL)
		{
		DmWrite(appCategories, offset, &zero, 1);
		RemoveBitMacro(renamedCategories, index);
		}
	else
		{
		// If the category is new give it a unique ID.
		if (appCategories->categoryLabels[index][0] == nullChr)
			GiveCategoryNewUniqID(appCategories, index);
		
		DmStrCopy(appCategories, offset, nameP);
		SetBitMacro(renamedCategories, index);
		}
		
	DmWrite(appCategories, (ULong)(&nilP->renamedCategories),
		&renamedCategories, sizeof(renamedCategories));

	MemPtrUnlock(appCategories);

}

/***********************************************************************
 *
 * FUNCTION: 	 CategoryTruncateName
 *
 * DESCRIPTION: This routine trunctated a category name such that it
 *              is short enough to display.
 *
 * PARAMETERS:	 ctl      - item number of the object
 *					 label    - pointer to the name of the new category
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/24/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CategoryTruncateName (CharPtr name, const Word maxWidth)
{
	Word i;
	Word len;
	Word width;
	FontID curFont;
	
	curFont = FntSetFont (stdFont);
	
	len = StrLen (name);
	width = FntCharsWidth (name, len);
	
	if (width > maxWidth)
		{
		// Add the width of an ellipsis to the width category.
		width += FntCharWidth ('.') * 3;
		
		// Truncate the category string.
		while ( len && (width > maxWidth))
			width -= FntCharWidth (name[--len]);
			
		// Append an ellipsis to the category string.
		len = min (len, dmCategoryLength - 4);
		for (i = len; i < len + 3; i++)
			name[i] = '.';
		name[len+3] = 0;
		}

	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION: 	 CategorySetTriggerLabel
 *
 * DESCRIPTION: This routine sets the lable displayed by the category
 *              trigger.  The category name is trunctated if it's to
 *                        long.
 *
 * PARAMETERS:	 ctl      - item number of the object
 *					 label    - pointer to the name of the new category
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/24/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CategorySetTriggerLabel (const ControlPtr ctl, CharPtr name)
{
	CategoryTruncateName (name, maxCategoryWidth);
	CtlSetLabel (ctl, name);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryGetNext
 *
 * DESCRIPTION: Given a category index this routine returns the index
 *              of the next category.  Catergory are not stored
 *              sequentially.
 *
 * PARAMETERS:  db    - database the contains the categories
 *              index - category index
 *
 * RETURNED:    category index of next category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/15/95	Initial Revision
 *			art	3/26/96	Add to ignore empty categories
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
 Word CategoryGetNext (const DmOpenRef db, Word index)
 {
	Int i, j, count;
	Word nextCategory;
	CharPtr	names [dmRecNumCategories];
	AppInfoType * appCategories;


	// The "unfiled" category is always the last category displayed,  and 
	// "show all" is always the first category displayed.  If the 
	// current category is "unfiled" wrap around to the "show all"
	// category.
	if (index == dmUnfiledCategory)
		return (dmAllCategories);


	//
	// Create a sort list of category names.
	//
	appCategories = GetCategories (db);
	count = 0;

	// For each non-blank category, copy a pointer to its name in to a
	// list and sort the list.
	for (i = 1; i < dmRecNumCategories; i++)
		{
		if (appCategories->categoryLabels[i][0] != '\0')
			{
			names[count++] = appCategories->categoryLabels[i];
			}
		}
	SysQSort (names, count, sizeof (CharPtr), (CmpFuncPtr)CategoryCompare, 0);


	// Assume the next category is the "all" category.
	nextCategory = dmAllCategories;
	
	
	// Are there categories other than "unfiled" and "show all"?  If so
	// find the index, in the sort list of names, of the next category.
	if (count)
		{
		// If the current category is "show all" find the category index
		// of the first name in sorted list of names.
		if (index == dmAllCategories)
			{
			j = 0;
			}
	
		// The current category is not "show all"  or "unfiled".
		// Find the current category in the sorted list of names.
		else
			{
			for (j = 0; j < count; j++)
				{
				if (StrCompare (appCategories->categoryLabels[index], names[j]) == 0)
					break;
				}
			j++;
			}
	
	
		// If the current category is not the last entry in the sorted list of 
		// names, then 
		while  (j < count)
			{
			// Find the category index of the name in unsorted list of names.
			for (i = 1; i < dmRecNumCategories; i++)
				{
				if (StrCompare (appCategories->categoryLabels[i], names[j]) == 0)
					break;
				}
				
			// See if there are any records in the category, if there are we've
			// found the next category.
			index = 0;
			if (DmSeekRecordInCategory (db, &index, 0, dmSeekForward, i) == 0)
				{
				nextCategory = i;
				break;
				}
				
			j++;
			}
		}

	MemPtrUnlock(appCategories);
	
	return (nextCategory);
 }
 

/***********************************************************************
 *
 * FUNCTION:    CategoryHasRecords
 *
 * DESCRIPTION: Returns true if a record exists in the category.
 *
 * PARAMETERS:  db       - database the contains the categories
 *              category - category to find a record in
 *
 * RETURNED:    true if a record exists in the category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/28/95	Initial Revision
 *
 ***********************************************************************/
static Boolean CategoryHasRecords (DmOpenRef db, Word category)
{
	UInt firstRecord = 0;
	
	
	DmSeekRecordInCategory (db, &firstRecord, 0, dmSeekForward, category);
	if (DmGetLastErr()) return (false);
	
	return (true);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryEdit
 *
 * DESCRIPTION: This routine is the event handler for the "Categories Edit"
 *              dialog.
 *
 * PARAMETERS:  event    - a pointer to an EventType structure
 *              category - current category
 *              titleStrID - string id to use for the dialog's title
 *              numUneditableCategories - how many categories can't be edited.
 *							Uneditable categories start at category zero.
 *
 * RETURNED:    This routine returns true if any of the following conditions
 *					 are true:
 *					 	- the current category is renamed
 *					 	- the current category is deleted
 *					 	- the current category is merged with another category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/21/95	Initial Revision
 *			roger	4/16/96	Changed to handle a different dialog 
 *			roger	8/8/96	Changed to handle a passed title 
 *			trm	08/07/97	made non modified passed variabls constant
 *			roger	10/30/97	Added numUneditableCategories
 *			roger	11/12/97	Fixed rename category to selected category to return true
 *
 ***********************************************************************/
Boolean CategoryEdit (const DmOpenRef db, const WordPtr categoryP, 
	const DWord titleStrID, const Byte numUneditableCategories)
{
	FormPtr frm;
	FormPtr savedFrm;
	EventType event;
	Boolean categoryChanged = false;
	UInt selectedItem;
	Word selectedCategory;
	Word newCategory;
	Word alertResponse;
	AppInfoType *	appCategories;
	Word fieldIndex;
	FieldPtr fieldP;
	CharPtr fieldTextP;
	UInt buttonHit;
	Handle fieldTextH;
	ListPtr listP;
	Boolean updateList;
	Handle titleRscH;
	CharPtr titleRscP;
	CharPtr titleP = NULL;
	CharPtr ellipsesP;
	

	// Init the dialog
	savedFrm = FrmGetActiveForm ();
	frm = FrmInitForm (CategoriesEditForm);

	// Setup the form.  Get the list ready to be updated.	
	listP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, CategoriesEditList));
	listP->attr.usable = false;
	LstSetSelection(listP, noListSelection);
	selectedCategory = *categoryP;
	updateList = true;						// set it to the editable categories


	// Setup the form title from a passed in string resource.  Remove any trailing
	// ellipses.
	if (titleStrID)
		{
		titleRscH = DmGetResource(strRsc, titleStrID);
		if (titleRscH)
			{
			titleRscP = MemHandleLock(titleRscH);
			titleP = MemPtrNew(StrLen(titleRscP) + sizeof(Char));
			if (titleP != NULL)
				{
				StrCopy(titleP, titleRscP);
				
				// Now check if the string ends with "..." and if so remove the chars.
				ellipsesP = StrStr(titleP, "...");
				if (ellipsesP)
					*ellipsesP = '\0';
				
				FrmSetTitle(frm, titleP);
				}
			
			MemHandleUnlock(titleRscH);
			DmReleaseResource(titleRscH);
			}
		}
	
	
	// Draw the dialog
	FrmSetActiveForm (frm);
	FrmDrawForm (frm);


	// Handle input for the dialog until the user presses the OK button or until
	// an appStopEvent is received.
	while (true)
		{

		// Recreate the list so it reflects any changes
		if (updateList)
			{
			if (listP->attr.usable)
				CategoryFreeList (db, listP, false, 0);
			else
				listP->attr.usable = true;
			
			CategoryCreateList (db, listP, selectedCategory, false, false, 
				numUneditableCategories, false, false);
			LstSetHeight (listP, 9);
			LstDrawList(listP);
			selectedItem = LstGetSelection (listP);

			updateList = false;
			}
			
			
		EvtGetEvent (&event, evtWaitForever);

		if (! SysHandleEvent (&event))
			if (! LstHandleEvent (listP, &event))
				{
				//	Hard scroll buttons
				if (event.eType == keyDownEvent)
					{
					if (event.data.keyDown.chr == pageUpChr)
						{
						LstScrollList(listP, up, LstGetVisibleItems(listP) - 1);
						}
					else if (event.data.keyDown.chr == pageDownChr)
						{
						LstScrollList(listP, down, LstGetVisibleItems(listP) - 1);
						}
					}
					
				
				if (event.eType == ctlSelectEvent)
					{
					if (event.data.ctlSelect.controlID == CategoriesEditOKButton)
						break;
					else
						{
						switch (event.data.ctlSelect.controlID)
							{
							case CategoriesEditNewButton:
								// Use the first unused category.
								selectedCategory = CategoryFind (db, "");
								if (selectedCategory == dmAllCategories)
									{
									FrmAlert(categoryAllUsedAlert);
									
									// Restore the selectedCategory if there is a list selection
									if (selectedItem != noListSelection)
										{
										selectedCategory = CategoryFind (db, 
											LstGetSelectionText (listP, selectedItem));
										}
									}
								else
									{
									// Have the user type in a new category name
									frm = FrmInitForm (categoryNewNameDialog);
									fieldIndex = FrmGetObjectIndex (frm, categoryNewNameField);
									FrmSetFocus (frm, fieldIndex);
									fieldP = FrmGetObjectPtr (frm, fieldIndex);
									FldSetMaxChars(fieldP, dmCategoryLength - 1);			// don't include null terminator
									
									buttonHit = FrmDoDialog(frm);
									fieldTextP = FldGetTextPtr (fieldP);
									if (buttonHit == categoryNewNameOKButton &&
										fieldTextP != NULL &&
										fieldTextP[0] != '\0')
										{
										// If the category already exists notify the user and exit.
										if (CategoryFind (db, fieldTextP) != dmAllCategories)
											FrmCustomAlert (CategoryExistsAlert, fieldTextP, NULL, NULL);
										else
											{
											// Mark the new category with a new uniq ID
											appCategories = GetCategories (db);
											GiveCategoryNewUniqID(appCategories, selectedCategory);
											MemPtrUnlock(appCategories);
											
											// Use the new name
											CategorySetName(db, selectedCategory, fieldTextP);
											
											// Recreate the list so it reflects the change
											updateList = true;
											}
										}

									FrmDeleteForm(frm);
									frm = FrmGetActiveForm();
									}
								break;
		
		
							case CategoriesEditRenameButton:
								if (selectedItem == noListSelection)
									{
									FrmAlert(SelectACategoryAlert);
									}
								else
									{
									appCategories = GetCategories (db);
									selectedCategory = CategoryFind (db, LstGetSelectionText (listP, selectedItem));
									
									frm = FrmInitForm (categoryNewNameDialog);
									fieldIndex = FrmGetObjectIndex (frm, categoryNewNameField);
									FrmSetFocus (frm, fieldIndex);
									fieldP = FrmGetObjectPtr (frm, fieldIndex);
									fieldTextH = MemHandleNew(dmCategoryLength);
									fieldTextP = MemHandleLock(fieldTextH);
									StrCopy(fieldTextP, appCategories->categoryLabels[selectedCategory]);
									MemHandleUnlock(fieldTextH);
									FldSetTextHandle(fieldP, fieldTextH);
									FldSetSelection(fieldP, 0, FldGetTextLength(fieldP));
									FldSetMaxChars(fieldP, dmCategoryLength - 1);			// don't include null terminator
									
									buttonHit = FrmDoDialog(frm);
									if (buttonHit == categoryNewNameOKButton &&
										fieldTextP[0] != '\0')
										{
										fieldTextP = FldGetTextPtr (fieldP);
										
										// Check if the category name is already used.
										newCategory = CategoryFind (db, fieldTextP);
										
										// If the category name matches the selected category
										// then the user tapped OK without changing the name.
										if (newCategory != selectedCategory)
											{
											// If the category already exists notify the user
											if (newCategory != dmAllCategories)
												{
												// Ask if the categories should be merged
												buttonHit = FrmCustomAlert (MergeCategoryAlert, 
													appCategories->categoryLabels[newCategory], fieldTextP, NULL);
												if (buttonHit == MergeCategoryYes)
													{
													// Merge (Move) the records into an existing category
													DmMoveCategory(db, newCategory, selectedCategory, true);
													
													// Remove the category name.
													CategorySetName(db, selectedCategory, NULL);

													// Recreate the list so it reflects the change
													updateList = true;
													
													
													// Check if the current category was merged into another
													// or if the selected category was merged into the current 
													// category.
													if (selectedCategory == *categoryP || 
														newCategory == *categoryP)
														{
														categoryChanged = true;
														*categoryP = newCategory;
														}
													
													// The selected category has been merged into another.
													selectedCategory = newCategory;
													}
												}
											else
												{
												// Rename the category to a new name.
												CategorySetName(db, selectedCategory, fieldTextP);

												// Optimization.  If the user renames a category with
												// records in it, assume the user is clarifying the
												// category's name.  If there aren't any records, assume
												// the user is using the category for a new purpose.  
												// Change the uniq ID to reflect this.
												// This solves an annoyance when users rename Business
												// for something else, and then a HotSync adds
												// records down to a Business category.  They used to
												// appear "misfiled".
												if (!CategoryHasRecords (db, selectedCategory))
													{
													// Mark the category with a new uniq ID
													appCategories = GetCategories (db);
													GiveCategoryNewUniqID(appCategories, selectedCategory);
													MemPtrUnlock(appCategories);
													}
												
												// Recreate the list so it reflects the change
												updateList = true;
		
												// Check if the current category was renamed.
												if (selectedCategory == *categoryP)
													{
													categoryChanged = true;
													}
												}
											}
										}
	
									MemPtrUnlock(appCategories);
	
									FrmDeleteForm(frm);
									frm = FrmGetActiveForm();
									}
								break;
		
							case CategoriesEditDeleteButton:
								if (selectedItem == noListSelection)
									{
									FrmAlert(SelectACategoryAlert);
									}
								else
									{
									// Initialize alertResponse to delete the category name incase
									// there aren't any records.  This isn't as fast as skipping
									// the DmMoveCategory call but it is cleaner code.
//									alertResponse = RemoveCategoryNameButton;
									alertResponse = RemoveCategoryYes;
									
									// If there are records ask the user what to delete.
									if (CategoryHasRecords (db, selectedCategory))
										alertResponse = FrmAlert (RemoveCategoryAlert);
									
									// If the delete wasn't canceled do something about it.
									
									/* This code is commented out until 3.0 because it breaks
									   1.0 applications which don't handle records being deleted
									   by this mechanism.
									   
									   See Roger about this.
									   
									if (alertResponse != RemoveCategoryCancelButton)
										{
										if (alertResponse == RemoveCategoryNameButton)
											{
											// Recategorize records as unfiled.
											DmMoveCategory (db, dmUnfiledCategory, selectedCategory, true);
											}
										else
											{
											DmDeleteCategory (db, selectedCategory);
											}
									*/
									
									// This is the code to replace the commented out code.
									if (alertResponse == RemoveCategoryYes)
										{
										// Recategorize records as unfiled.
										DmMoveCategory (db, dmUnfiledCategory, selectedCategory, true);
										
										// Remove the category name.
										CategorySetName(db, selectedCategory, NULL);
	
										// Recreate the list so it reflects the change
										updateList = true;
	
										// Check if the current category was deleted.
										if (selectedCategory == *categoryP)
											{
											categoryChanged = true;
											*categoryP = dmUnfiledCategory;
											}
											
										selectedCategory = dmAllCategories;
										}
									}

								break;
							}
						}
					}
				else if (event.eType == lstSelectEvent)
					{
					selectedItem = event.data.lstSelect.selection;
					selectedCategory = CategoryFind (db, LstGetSelectionText (listP, selectedItem));
					}
/* causes a visual bug
				else if (event.eType == lstExitEvent)
					{
					selectedItem = noListSelection;
					}
*/				else if (event.eType == appStopEvent)
					{
					EvtAddEventToQueue (&event);
					selectedItem = noListSelection;
					break;
					}
				else FrmHandleEvent (frm, &event);
				}		
			}		


	// Clean up
	CategoryFreeList (db, listP, false, 0);
	
	if (titleP)
		{
		MemPtrFree(titleP);
		
		}
	
	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	FrmSetActiveForm (savedFrm);
	
	return (categoryChanged);
}


/***********************************************************************
 *
 * FUNCTION:    CategorySelect
 *
 * DESCRIPTION: This routine process the selection and editting of
 *              categories. 
 *
 * PARAMETERS:  db           - database the contains the categories
 *              frm          - form the contains the category popup list
 *              ctlID        - id of the popup trigger
 *              lstID        - id of the popup list
 *              title        - true if the popup trigger is on the title line
 *              categoryP    - current category (index into db structure)
 *              categoryName - name of the current category
 *
 * RETURNED:    This routine returns true if any of the following conditions
 *					 are true:
 *					 	- the current category is renamed
 *					 	- the current category is deleted
 *					 	- the current category is merged with another category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean CategorySelect (const DmOpenRef db, const FormPtr frm, 
	const Word ctlID, const Word lstID,	const Boolean title, 
	const WordPtr categoryP, CharPtr categoryName, 
	const Byte numUneditableCategories, DWord editingStrID)

{
	ControlPtr 	ctl;
	ListPtr 		lst;
	CharPtr		str;
	short			newSelection;
	short			curSelection;
	Boolean		categoryEdited = false;
	Word 			category;
	
	ctl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ctlID));
	lst = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, lstID));

	category = *categoryP;
	
	// If the edit string is set, set it to "edit categories".
	if (!editingStrID)
		editingStrID = categoryEditStrID;

	// If the category trigger is part of the title, then the "all" item
	// should be in the list.
	CategoryCreateList (db, lst, category, title, true, numUneditableCategories, 
		editingStrID, true);
	curSelection = LstGetSelection (lst);
	newSelection = LstPopupList (lst);

	// Was the  "edit categories ..." item selected?
	if (newSelection == LstGetNumberOfItems (lst) - 1)
		{
		// We'll treat moving a category like selecting a diffent category. 
		categoryEdited = CategoryEdit (db, &category, editingStrID, numUneditableCategories);
		
		// The category name may have been changed or deleted.
		if ((*categoryP != dmAllCategories) && 
			 (*categoryP != dmUnfiledCategory))
			{
			CategoryGetName (db, category, categoryName);
			CategorySetTriggerLabel (ctl, categoryName);
			}
		}

	// Was a new category selected?
	else if ((newSelection != curSelection) && (newSelection != -1))
		{
		// Make a copy of the category name, it's going to freed.
		str = LstGetSelectionText (lst, newSelection);
		StrCopy (categoryName, str);
		
		// The first item (item 0) is "show all categories".
		if ((newSelection == 0) && (title))
			category = dmAllCategories;
		else
			{
			category = CategoryFind (db, categoryName);
			ErrFatalDisplayIf (category == dmAllCategories, "Bad category name");
			}


		// The category was changed.  Display the name of the new 
		// category on the popup trigger.
		CategorySetTriggerLabel (ctl, categoryName);
		}

	CategoryFreeList (db, lst, title, editingStrID);
	
	*categoryP = category;
	return (categoryEdited);
}


/************************************************************
 *
 * FUNCTION:    CategoryInitialize
 *
 * DESCRIPTION: Initialize the category names, ids and flages.
 *
 * PARAMETERS:  application info ptr
 *              resource id the localized category names
 *
 * RETURNS:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/29/96	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 *************************************************************/
void CategoryInitialize (AppInfoPtr appInfoP, const Word localizedAppInfoStrID)
{
	Int 				i;
	Word				len;
	UInt				renamedCategories;
	CharPtr			name;
	CharPtr	 		localizedAppInfoP;
	VoidHand 		localizedAppInfoH;
	AppInfoPtr		nilP = 0;


	localizedAppInfoH = DmGetResource (appInfoStringsRsc, localizedAppInfoStrID);
	if (! localizedAppInfoH)
		{
		return;
		}

	localizedAppInfoP = MemHandleLock (localizedAppInfoH);
	name = localizedAppInfoP;
	

	// Copy each category name and initialize the unique category ID.
	renamedCategories = appInfoP->renamedCategories;
	for (i = 0; i < dmRecNumCategories; i++)
		{
		len = StrLen (name);
		if (len)
			{
			DmStrCopy (appInfoP, (ULong) nilP->categoryLabels[i], name);
			SetBitMacro (renamedCategories, i);
			}
		name += len + 1;

		DmSet (appInfoP, (ULong)&nilP->categoryUniqIDs[i], 
			sizeof (appInfoP->categoryUniqIDs[i]), i);
		}
	DmWrite(appInfoP, (ULong) &nilP->renamedCategories, &renamedCategories,  
		sizeof(renamedCategories));


	// Set the ID of the last unique category ID.
	DmSet (appInfoP, (ULong)&nilP->lastUniqID, 
		sizeof (appInfoP->lastUniqID), dmRecNumCategories - 1);

	MemPtrUnlock (localizedAppInfoP);
}





/***********************************************************************
 *
 * FUNCTION:    CategoryEditV20
 *
 * DESCRIPTION: This routine is the event handler for the "Categories Edit"
 *              dialog.
 *
 * PARAMETERS:  event    - a pointer to an EventType structure
 *              category - current category
 *              titleStrID - string id to use for the dialog's title
 *
 * RETURNED:    This routine returns true if any of the following conditions
 *					 are true:
 *					 	- the current category is renamed
 *					 	- the current category is deleted
 *					 	- the current category is merged with another category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/30/97	Initial Revision
 *
 ***********************************************************************/
Boolean CategoryEditV20 (const DmOpenRef db, const WordPtr categoryP, 
	const DWord titleStrID)
{
	return CategoryEdit (db, categoryP, titleStrID, 1);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryEditV10
 *
 * DESCRIPTION: This routine is the event handler for the "Categories Edit"
 *              dialog.
 *
 * PARAMETERS:  event    - a pointer to an EventType structure
 *              category - current category
 *
 * RETURNED:    This routine returns true if any of the following conditions
 *					 are true:
 *					 	- the current category is renamed
 *					 	- the current category is deleted
 *					 	- the current category is merged with another category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/21/95	Initial Revision
 *			roger	4/16/96	Changed to handle a different dialog 
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean CategoryEditV10 (const DmOpenRef db, const WordPtr categoryP)
{
	return CategoryEdit (db, categoryP, categoryEditStrID, 1);
}

/***********************************************************************
 *
 * FUNCTION:    CategorySelect
 *
 * DESCRIPTION: This routine process the selection and editting of
 *              categories. 
 *
 * PARAMETERS:  db           - database the contains the categories
 *              frm          - form the contains the category popup list
 *              ctlID        - id of the popup trigger
 *              lstID        - id of the popup list
 *              title        - true if the popup trigger is on the title line
 *              categoryP    - current category (index into db structure)
 *              categoryName - name of the current category
 *
 * RETURNED:    This routine returns true if any of the following conditions
 *					 are true:
 *					 	- the current category is renamed
 *					 	- the current category is deleted
 *					 	- the current category is merged with another category
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/10/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
Boolean CategorySelectV10 (const DmOpenRef db, const FormPtr frm, 
	const Word ctlID, const Word lstID,	const Boolean title, 
	const WordPtr categoryP, CharPtr categoryName)

{
	return CategorySelect (db, frm, ctlID, lstID,	title, categoryP, categoryName, 1, 0);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryCreateListV10
 *
 * DESCRIPTION: Read a database's categories and set the categories 
 *              list's items.
 *
 *	THIS IS THE OLD VERSION 1.0 CALL WHICH WILL DISSAPPEAR IN THE FUTURE.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    CategoryListItemsHandle is set to the list's choices.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/22/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void CategoryCreateListV10 (const DmOpenRef db, const ListPtr lst, 
	const Word currentCategory, const Boolean showAll)
{
	CategoryCreateList (db, lst, currentCategory, showAll, true, 1, 0, true);
}


/***********************************************************************
 *
 * FUNCTION:    CategoryFreeListV10
 *
 * DESCRIPTION: This routine unlocks or frees memory locked or allocated
 *              by CategoryCreateList.
 *
 * PARAMETERS:  lst   - pointer to the category list
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/23/95	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *			roger	9/9/97	fixed call to CategoryFreeList to not free an editing string
 *
 ***********************************************************************/
void CategoryFreeListV10 (const DmOpenRef db, const ListPtr lst)
{
	CategoryFreeList(db, lst, false, 0);
	
	// The old method didn't know if the All string was used so it
	// reset the lock.  This prevents nested lists.
	MemHandleResetLock(DmGetResource(strRsc, categoryAllStrID));
}


