/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:	Pilot  
 * FILE:		ScrDriverNew.c
 * AUTHOR:	Ron Marianetti
 *
 * DESCRIPTION:
 *			Version 2 Screen driver for Pilot - supports color API and
 *		implemenets 1 and 2 bits/pixel displays
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		11/21/96	Created
 *
 **********************************************************************/

#include <Pilot.h>

// Don't include unless building version 2 Graphics
#if 	GRAPHICS_VERSION == GRAPHICS_VERSION_2


#include <SysEvtMgr.h>
#include <EmuStubs.h>
#include <ScrDriver.h>
#include <SerialLinkMgr.h>

#define	NON_PORTABLE
#include <Hardware.h>

#define	scrUpdateDelay		2					// delay between remote screen updates



//======================================================================
// Private routines
//==========================================================================
static void 	PrvDrawPixel(ScrBltInfoPtr infoP, Int x, Int y);

static void 	PrvDrawHLine(ScrBltInfoPtr infoP, SWord x, SWord y, SWord extentX,
									 Boolean oneBytePattern);

static void 	PrvDrawVLine(ScrBltInfoPtr infoP, SWord x, SWord y, SWord extentY);


static Word 	PrvColor2Pixels(RGBColorType* colorP, GDevicePtr deviceP);


static Boolean PrvGetDrawInfo(WinPtr winP, ScrBltInfoPtr infoP, Int height);

static Boolean PrvGetBltInfo(WinPtr dstWinP, WinPtr srcWinP, FontPtr fontP,
						ScrBltInfoPtr infoP, Word height, Word width);
						

static void 	PrvGetLineInfo(ScrBltInfoPtr infoP,
						SWord	toX, SWord toY, SWord fromX, SWord fromY,
						SWord width);

static Word		PrvGetPatternWord(BytePtr patP, UInt patRow, UInt patDepth);


static ScrConvertDepthProcP 	PrvGetDepthConvertInfo(ScrBltInfoPtr infoP, 
						IntPtr bitOffsetP, SWordPtr srcWordOffsetP,
						Word	fromX, Word toX);


static void 	PrvConvertDepthSame(WordPtr srcWP, ScrBltInfoPtr	infoP);

static void 	PrvConvertDepth1To2BW(WordPtr srcWP, ScrBltInfoPtr	infoP);

static void 	PrvConvertDepth1To2(WordPtr srcWP, ScrBltInfoPtr	infoP);

static void 	PrvConvertDepth2To1(WordPtr srcWP, ScrBltInfoPtr	infoP);


static asm 		WordPtr PrvExpand1To2Table(void);

static Err	 	PrvCompressedInnerBitBlt(ScrBltInfoPtr infoP, Word fromX, Word toX,
						Boolean dstCompressed);

static void 	PrvAlignedForwardInnerBitBlt(ScrBltInfoPtr infoP);

static void 	PrvAlignedBackwardInnerBitBlt(ScrBltInfoPtr infoP);


static void 	PrvMisAlignedForwardInnerBitBlt(ScrBltInfoPtr infoP,
							 Word fromX, Word toX);
						
static void 	PrvMisAlignedBackwardInnerBitBlt(ScrBltInfoPtr infoP, 
							 Word fromX, Word toX);
						
						
static void    PrvTimerProc(Long timerID, Long param);


						
/***********************************************************************
 *
 * FUNCTION:	ScrInit
 *
 * DESCRIPTION: Initializes the Screen Driver
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
void ScrInit(void)
{
	ScrGlobalsPtr	gP;
	ULong				size;
	Long				tag = 'ScrD';
	Err				err;
	Ptr				oldBase;
	Int				mode;
	
	// Allocate our globals
	gP = MemPtrNew(sizeof(ScrGlobalsType));
	if (!gP) DbgBreak();
	MemSet(gP, sizeof(ScrGlobalsType), 0);
	
	// Save pointer to globals
	GScrGlobalsP = (Ptr)gP;
	
	// Initialize them 
	gP->doDrawNotify = true;
	gP->gDevice.width = hwrDisplayWidth;
	gP->gDevice.height = hwrDisplayHeight;
	
	
	// NOTE: You simply have to change pixelSize from 1 to 2 in order to run in grayscale mode...
	gP->gDevice.pixelSize = hwrDisplayBootDepth;
	gP->gDevice.forDriver = true;
	gP->gDevice.rowBytes = (gP->gDevice.width * gP->gDevice.pixelSize) >> 3;
	
	// Space for expanded scan lines. See PrvGetBltInfo for an explanation of
	//  this calculated max size. 
	gP->expSrcSize = ((gP->gDevice.width * hwrDisplayMaxDepth) >> 3) + 3*sizeof(Word);
	gP->expSrcP = MemPtrNew(gP->expSrcSize);
	if (!gP->expSrcP) DbgBreak();
	
	
	// Empty the update rect
	gP->updateR.left = gP->gDevice.width;
	gP->updateR.right = 0;
	gP->updateR.top = gP->gDevice.height;
	gP->updateR.bottom = 0;


	// Create the gray pattern	
	gP->grayPat[0] = 0xAA55;
	gP->grayPat[1] = 0xAA55;
	gP->grayPat[2] = 0xAA55;
	gP->grayPat[3] = 0xAA55;
	
	
	// Allocate the display memory (large enough for maximum display depth)
	size = (hwrDisplayWidth/8 * hwrDisplayHeight) * hwrDisplayMaxDepth;
	gP->gDevice.baseAddr = MemPtrNew(size);
	if (!gP->gDevice.baseAddr) DbgBreak();
	
	
	// Copy the splash screen to the "real" video RAM area to start
	oldBase = 0;
	size = gP->gDevice.rowBytes * gP->gDevice.height;
	err = HwrLCDBaseAddr(&oldBase);
	if (!err) 
		MemMove(gP->gDevice.baseAddr, oldBase, size);
	else
		MemSet(gP->gDevice.baseAddr, size, 0);

	// Change the base address for the LCD driver. If we get no error, we don't 
	// have to do remote viewing...
	oldBase = gP->gDevice.baseAddr;
	err = HwrLCDBaseAddr(&oldBase);
	if (!err) {
		gP->doDrawNotify = false;
		
		// If we're not using boot display depth, re-initialize the LCD hardware
		//  appropriately
		if (gP->gDevice.pixelSize != hwrDisplayBootDepth) 
			HwrLCDInit(0, 0, 0, 0, gP->gDevice.pixelSize);
		}

	// Init the hardware cursor
	mode = 0;
	HwrCursor(true, &mode, 0, 0, 0);

}


/************************************************************
 *
 *  FUNCTION: ScrDisplayMode
 *
 *  DESCRIPTION: Set and/or return display geometry, depth or colorness.
 *
 *  PARAMETERS: operation - operation to perform
 *				widthP - pointer to new / old screen width
 *				heightP - pointer to new / old screen height
 *				depthP - pointer to new / old / possible screen depth(s)
 *				enableColorP - pointer to new / old color enable(d) value
 *
 *				Description of each operation:
 *
 *				getDefaults - return default settings for display.
 *					For this release defaults are width: 160, height: 160,
 *					depth: FtrGet(sysFtrNumDisplayDepth), enableColor: false
 *				get - return current settings for the display.
 *					For this release width/height/enableColor are fixed and
 *					will always be returned as width: 160, height: 160, enableColor: false.
 *					Depth may be 1 or 2.
 *				setToDefaults - changes display settings to the defaults above.
 *				set - changes display settings.  Only non-NULL ptr values are used.
 *					NULL ptr values are left as is.  Width, height and enableColor are
 *					not changable for this release and must be 160/160/false for this
 *					release if they are specified.  Depth can be 1 or 2.  Although the
 *					getSupportedDepths option (see below) should be used to determine
 *					which depths are supported.
 *				getSupportedDepths - returns a "bit map" of supported screen depths.
 *					Each bit in the returned DWORD indicates support (1) or not (0)
 *					for each display depth, with the bit position being the bit depth - 1.
 *					Some examples:
 *					Support for bit depths of 2 & 1 is indicated by 0x03.
 *					Support for bit depths of 4, 2 & 1 is indicated by 0x0B.
 *					Support for bit depths for 24, 8, 4 & 2 is indicated by 0x80008A.
 *				getSupportsColor - for a given screen size (only 160x160 for now),
 *					a boolean is returned indicating whether color mode can be enabled.
 *					Always returns false for this release.
 *
 *				Here's a table of how the arguments are used for each operation
 *				Returned values are indicated by 'out'.  Can be NULL.
 *				Required parameters are indicated by 'in'.  Can be NULL.
 *				Unused parameters are indicated by 'n/a'.
 *
 *				operation			widthP	heightP	depthP	enableColorP
 *				---------			------	-------	------	------------
 *				getDefaults			out		out		out		out
 *				get					out		out		out		out
 *				setToDefaults		n/a		n/a		n/a		n/a
 *				set					in		in		in		in
 *				getSupportedDepths	in		in		out		in
 *				getSupportsColor	in		in		in		out
 *
 *				When setting, null pointers mean use current settings
 *
 *  RETURNS: 	error if invalid parameters are given
 *
 *  CREATED: 1/19/98
 *
 *  BY: Tim Wiegman
 *
 *************************************************************/
extern Err ScrDisplayMode(ScrDisplayModeOperation operation,
 	DWordPtr widthP, DWordPtr heightP, DWordPtr depthP, BooleanPtr enableColorP)
{
	Err err;
 	DWord curDepth;
 	DWord dflDepth;
 	DWord setDepth;
 	
	// First get the current depth
	curDepth = HwrLCDGetDepth(hwrLCDGetCurrentDepth);
	
	// Get the default display depth.  If it doesn't exist (or its bad) then initialize it.
	err = FtrGet(sysFtrCreator, sysFtrNumDisplayDepth, &dflDepth);
	if (err || (((1 << (dflDepth-1)) & hwrDisplayAllDepths) == 0)) {
		dflDepth = hwrDisplayBootDepth;
		err = FtrSet(sysFtrCreator, sysFtrNumDisplayDepth, dflDepth);
		if (err) return err;
	}
	
	// Initialize set depth to the current value
	setDepth = curDepth;
	
 	// Check for invalid input args for *widthP and *heightP
	// Only one width/height combination is supported for this hardware
 	switch (operation) {
 		case scrDisplayModeSet:
		case scrDisplayModeGetSupportedDepths:
		case scrDisplayModeGetSupportsColor:
			if (widthP != NULL) {
				if (*widthP != hwrDisplayWidth) return sysErrParamErr;
			}
			if (heightP != NULL) {
				if (*heightP != hwrDisplayHeight) return sysErrParamErr;
			}
			break;
	}
 	
 	// See what the client wants to do
 	switch (operation) {
		case scrDisplayModeGetDefaults:
			curDepth = dflDepth;
			// Fall thru to next case on purpose
			
		case scrDisplayModeGet:
	 		if (widthP != NULL) *widthP = hwrDisplayWidth;
	 		if (heightP != NULL) *heightP = hwrDisplayHeight;
	 		if (depthP != NULL) *depthP = curDepth;
	 		if (enableColorP != NULL) *enableColorP = false;
			break;
			
		case scrDisplayModeSetToDefaults:
			setDepth = dflDepth;
			depthP = NULL;
			// Fall thru to next case on purpose
			
		case scrDisplayModeSet:
			if (depthP != NULL) {
				setDepth = *depthP;
				// Check that the new depth is a valid depth
				if (((1 << (setDepth-1)) & hwrDisplayAllDepths) == 0) return sysErrParamErr;
			}
		 	if (setDepth != curDepth) {
				WinHandle win;
				
				// Update fields affected by the depth change
				ScrGlobalsPtr gP = (ScrGlobalsPtr)GScrGlobalsP;
				gP->gDevice.pixelSize = setDepth;
				gP->gDevice.rowBytes = (gP->gDevice.width * gP->gDevice.pixelSize) >> 3;
				
#if EMULATION_LEVEL == EMULATION_NONE
				// Change the display to the new depth
				err = HwrLCDInit(0, NULL, 0, 0, setDepth);
				if (err) return err;
#endif
				
				// Erase the display - since the stuff there was rendered using the prev depth
				win = WinGetDrawWindow();
				WinSetDrawWindow(WinGetDisplayWindow());
				WinEraseWindow();
				WinSetDrawWindow(win);
			}
			break;
			
		case scrDisplayModeGetSupportedDepths:
			if (depthP == NULL) return sysErrParamErr;
			*depthP = hwrDisplayAllDepths;
			break;
			
		case scrDisplayModeGetSupportsColor:
			if (enableColorP == NULL) return sysErrParamErr;
			if (depthP != NULL) {
				// Check that the specified depth is a valid depth
				if (((1 << (*depthP-1)) & hwrDisplayAllDepths) == 0) return sysErrParamErr;
			}
			*enableColorP = false;
			break;
			
		default:
			return sysErrParamErr;
	}
 	
 	return 0;
}


 /***********************************************************************
 *
 * FUNCTION:	ScrCopyRectangle
 *
 * DESCRIPTION: The screen driver bitblt function.
 *
 *					 If the compressed bit is set in the source window flags,
 *					 this routine will automatically decompress the source bitmap
 *					 as it copies it to the destination.
 *
 *					 If the compressed bit is set in the dest window flags,
 *					 this routine will automatically compress the source bitmap
 *					 as it copies it to the destination.
 *
 *					NOTE: Currently, compression is only supported for scrCopy mode where the
 *					width and the height of the copy is equal to the width and height of
 *					the compressed bitmap image, whether it be the source or destination.
 *
 * PARAMETERS:	
 *				*srcWinP				- Source image window  
 *				*dstWinP	 			- Destination image window 
 *
 *				fromX					- Upper left-hand coordinates of rectangle
 *				fromY			 			 to copy. (inclusive)
 *
 *				toX					- Upper left-hand coordinates of rectangle
 *				toY				  		position in destination window.
 *
 *				width					- Width of rectangle in pixels
 *				height				- Height of rectangle in pixels
 *
 *
 * RETURNED:	void
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
Err ScrCopyRectangle(WinPtr srcWinP, WinPtr dstWinP, SWord fromX, SWord fromY, 
					SWord toX, SWord toY, SWord width, SWord height)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	ScrBltInfoType		info;
	ScrBltInfoPtr		infoP;
	Int					updTop, updLeft, updWidth, updHeight;
	Err					err = 0;
	

	// Adjust for negative extents
	if (width < 0)  {fromX += width; toX += width; width = -width;}
	if (height < 0) {fromY += height; toY += height; height = -height;}
	
	// Save the update bounds
	updTop = toY;
	updLeft = toX;
	updWidth = width;
	updHeight = height;
	

	//-------------------------------------------------------------------
	// Prepare the blt info structure for normal, uncompressed copy calls
	//------------------------------------------------------------------
	infoP = &info;
	if (!PrvGetBltInfo(dstWinP, srcWinP, 0, infoP, height, width)) return 0;
	PrvGetLineInfo(infoP, toX, toY, fromX, fromY, width);
	


	//-------------------------------------------------------------------
	// Error check if this is a compression call
	//------------------------------------------------------------------
	if (srcWinP->gDeviceP->compressed || dstWinP->gDeviceP->compressed) {
		Boolean invalid = false;
		if (srcWinP->gDeviceP->compressed) {
			if (fromX || fromY) 
				 invalid = true;
			}
		if (dstWinP->gDeviceP->compressed) {
			if (width < 16 ||  toX || toY) 
				 dstWinP->gDeviceP->compressed = 0;
			}
		if (invalid) {err = sysErrParamErr; goto Exit;}
		}



		
	//-------------------------------------------------------------------
	// Call the appropriate inner loop
	//------------------------------------------------------------------
	
	// If either source or dest is compressed, call compression inner loop
	if (srcWinP->gDeviceP->compressed || dstWinP->gDeviceP->compressed) {
		err = PrvCompressedInnerBitBlt(infoP, fromX, toX, dstWinP->gDeviceP->compressed);
		
		// If there was an error, turn off compression and do a normal copy
		if (!err) 					
			goto Exit;
		if (err > 0) 						// Invalid parameters
			goto Exit;
		err = 0;
		dstWinP->gDeviceP->compressed = 0;
		}

	// If the source and dest are the same depth and on the same bit offset
	//  within a word, call the faster aligned inner loop
	if (infoP->srcDepth == infoP->dstDepth &&
		 (fromX & infoP->dstPixelsInWordZ) == (toX & infoP->dstPixelsInWordZ))  {
		if (infoP->forward) 
			PrvAlignedForwardInnerBitBlt(infoP);
						
		else
			PrvAlignedBackwardInnerBitBlt(infoP);
		}
		
		
	// If bit depth conversion is required, or if the source and dest are 
	//  not on the same bit boundary, call the slower, more general inner
	// loop. 
	else {
		if (infoP->forward) 
			PrvMisAlignedForwardInnerBitBlt(infoP, fromX, toX);  
			
		// The only time we have to copy backwards is if the source and dest
		//  overlap which means they are the same bit depth so this routine
		//  does not have to deal with depth conversion. 
		else 
			PrvMisAlignedBackwardInnerBitBlt(infoP, fromX, toX);
		}
		
		
Exit:		
	ErrFatalDisplayIf(err, "Invalid Params");
		
	// Call the DrawNotify function if enabled	
	if (gP->doDrawNotify &&
		!dstWinP->windowFlags.offscreen)
		ScrDrawNotify(updLeft, updTop, updWidth, updHeight);
		
	return err;
}
						



 /***********************************************************************
 *
 * FUNCTION:	ScrDrawChars
 *
 * DESCRIPTION:	The screen driver character draw routine.
 *
 * PARAMETERS:	
 *				*winP			- Window to draw to.   
 *
 *				toX			- Upper left hand corner of charcter draw region.
 *				toY
 *
 *				xExtent		- Extent of the draw region. (inclusive)
 *				yExtent		   
 *
 *				clipTop		- Character clipping deltas.
 *				clipLeft		  These specify how much to clip off of the source
 *				clipBottom	   font bitmap when doing the blit. The toX, toY, xExtent and
 *				clipRight		yExtent already have the clipXXX parts removed. 
 *
 *				chars			- Pointer to charcters to draw.
 *				len			- Numer of charcters to draw.
 *				fontPtr		- Pointer to font used for this draw.
 *
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *			kcr	10/24/95	only use one-byte gray pattern for underlines
 *			kcr	11/7/95	substitute Missing Char Symbol for non-existing
 *								chars.
 *
 ***********************************************************************/
void ScrDrawChars(WinPtr dstWinP, SWord toX, SWord toY, SWord xExtent, SWord yExtent,
			 SWord clipTop, SWord clipLeft, SWord clipBottom,  SWord clipRight, 
			 const Char * const charsP, Word len, FontPtr fontP)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	ScrBltInfoType		info;
	ScrBltInfoPtr		infoP;
	
	Word					index;
	
	const Byte *		charP;
	WordPtr				locP;
	WordPtr				thisLocP;
	UInt					imageSize;
	UInt					maxX;
	Int					width, mcsWidth;			//	Missing Char Symbol width
	Int					remainingWidth;
	Int					fromX, mcsFromX;			//	MCS offset
	
	Boolean				underline;
	Int					underlineX, underlineExtentX, underlineY;

	Int					updTop, updLeft, updWidth, updHeight;
	Word					c;
	

	// Don't do anything if 0 length
	if (!len) return;

	
	// Capture the update region
	updTop = toY;
	updLeft = toX;
	updWidth = xExtent;
	updHeight = yExtent;
	

	//-------------------------------------------------------------------
	// Prepare the Blit info structure.
	// 
	//  infoP->dstBaseP will contain the
	//  	starting address of the first destination row of the destination window
	//  	given the toY coordinate and clipTop parameters.
	// 
	//  infoP->srcBaseP will contain the
	//  	starting address of the first row in the source font bitmap given
	// 	the clipTop parameter.
	//------------------------------------------------------------------
	
	// Set it up
	infoP = &info;
	if (!PrvGetBltInfo(dstWinP, 0, fontP, infoP, yExtent, xExtent)) return;
	
	// Adjust the base addresses of the source and dest given the starting
	//  y coordinate in the dest and the clipTop of the source
	infoP->dstBaseP += (toY * infoP->dstRowBytes) >> 1;
	if (clipTop)
		infoP->srcBaseP += (clipTop * infoP->srcRowBytes) >> 1;
	
	
	//----------------------------------------------------------
	// If underlining, save the underline info
	//----------------------------------------------------------
	if (!clipBottom) {
		underline = dstWinP->gstate->underlineMode;
		if (underline) {
			underlineX = toX;
			underlineExtentX = xExtent;
			underlineY = toY + yExtent - 1;
			}
		}
	else
		underline = false;
	
	
	//---------------------------------------------------------
	// Get the font info 
	//---------------------------------------------------------
	
	// Get the address of the table that specifies the location of
	// each character image in the bitmap.
	imageSize = (fontP->rowWords << 1) * fontP->fRectHeight;
	locP = (WordPtr) (((BytePtr)fontP) + sizeof (FontType) +  imageSize);


	// Calcuate the right boundary
	maxX = toX + xExtent;



	//---------------------------------------------------------
	// Loop on every character we need to draw. This loop is general
	//  in that it checks for clipping on the left. If we don't
	//  have any clipping on the left, we fall into the lower loop
	//  which doesn't have to check on every character.
	//---------------------------------------------------------
	charP = (BytePtr)charsP;
	
	// Create temp variable of remaining width - this provides better
	//  performance when checking for clipping on the right
	remainingWidth = maxX - toX;
	
	//	The measurements of the Missing Character Symbol will be used for 
	//	all chars which don't exist in the font.  If the MCS is missing,
	//	a char of width 0 will be drawn.
	mcsFromX = locP[fontP->lastChar - fontP->firstChar + 1];
	mcsWidth = locP[fontP->lastChar - fontP->firstChar + 2] - mcsFromX;
	do {
		// If no more clipping on the left, fall into next loop because it
		//  doesn't spend time checking it.
		if (!clipLeft) break;
		
		// Get the index of this character in the font
		c = *charP++;
		if (c >= fontP->firstChar && c <= fontP->lastChar)
			index = c - fontP->firstChar;
		else {
			index = fontP->lastChar - fontP->firstChar + 1;
			}

		// Get the source x coordinate and width of the character
		thisLocP = &locP[index];		// put in temp variable for performance
		fromX = *thisLocP++;
		width = *thisLocP - fromX;
		if (width == 0)					//	char does not exist, use MCS
			{
			width = mcsWidth;
			fromX = mcsFromX;
			}
		if (width <= clipLeft) {
			clipLeft -= width;
			continue;
			}
		if (clipLeft) {
			fromX += clipLeft;
			width -= clipLeft;
			clipLeft = 0;
			}
		
		
		// See if we're clipping on the right
		if (width > remainingWidth) {
			width = remainingWidth;
			if (width <= 0) {
				len = 0;				// so we don't execute next loop
				break;
				}
			}
		
			
		//---------------------------------------------------------
		// Create the masks for the left and right edges of the dest
		//---------------------------------------------------------
		PrvGetLineInfo(infoP, toX, 0, fromX, 0, width);
		

		//-------------------------------------------------------------------
		// Call the inner loop
		//------------------------------------------------------------------
		PrvMisAlignedForwardInnerBitBlt(infoP, fromX, toX);  
			
			
		// All done, bump to next character
		toX += width;
		remainingWidth -= width;
		} while(--len);


	//-----------------------------------------------------------------
	// If we broke out of the first loop because due to no more
	//  clipping on the left, we need to finish the rest of the characters
	//-----------------------------------------------------------------
	if (len) {
		do {
			// Get the index of this character in the font
			c = *charP++;
			if (c >= fontP->firstChar && c <= fontP->lastChar) 
				index = c - fontP->firstChar;
			else {
				index = fontP->lastChar - fontP->firstChar + 1; 
				}
	
			// Get the source x coordinate and width of the character
			thisLocP = &locP[index];		// put in temp variable for performance
			fromX = *thisLocP++;
			width = *thisLocP - fromX;
			if (width == 0)	{			//	Char is missing from font
				width = mcsWidth;
				fromX = mcsFromX;
				}
			

			// See if we're clipping on the right
			if (width > remainingWidth) {
				width = remainingWidth;
				if (width <= 0)  break;
				}
			
			//---------------------------------------------------------
			// Create the masks for the left and right edges of the dest
			//---------------------------------------------------------
			PrvGetLineInfo(infoP, toX, 0, fromX, 0, width);
			
			//-------------------------------------------------------------------
			// Call the inner loop
			//------------------------------------------------------------------
			PrvMisAlignedForwardInnerBitBlt(infoP, fromX, toX);
				
			// All done, bump to next character
			toX += width;
			remainingWidth -= width;
			} while(--len);
		} // if (len)
		

	//-------------------------------------------------------------------
	// See if we need to underline these characters
	//------------------------------------------------------------------
	if (underline) { 
		Byte				pat = grayHLinePattern;
		RGBColorType	ltGray;
		
		infoP->op = scrOR;
		infoP->dstBaseP = dstWinP->gDeviceP->baseAddr;
		infoP->srcBaseP = 0;
		infoP->srcDepth = 1;

		// Use light gray for the underline if we have color 
		if (infoP->dstDepth > 1) {

			infoP->simple = true;
			infoP->patternP = 0;

			ltGray.r = ltGray.g = ltGray.b = 0xA0;
			infoP->forePixels = PrvColor2Pixels(&ltGray, dstWinP->gDeviceP);
			}
			
		// Otherwise, draw a pattern line
		else {
			ScrConvertDepthProcP		convertP;
			
			infoP->simple = false;
			infoP->patternP = gP->expSrcP;

			// Convert the pattern to the destination depth
			convertP = PrvGetDepthConvertInfo(infoP, 0, 0, 0, 0);
			// The following two fields are normally initialized by PrvGetDepthConvertInfo,
			//  except when all 0's are passed to it as we just did. 
			infoP->convSrcP = (WordPtr)infoP->patternP;
			infoP->srcBytesInLine = sizeof(Byte);
			(convertP)((WordPtr)&pat, infoP);
			}
			
		PrvDrawHLine(infoP, underlineX, underlineY, underlineExtentX, true);
		}
		
		
		
		
	// Call the DrawNotify function if enabled	
	if (gP->doDrawNotify &&
		!dstWinP->windowFlags.offscreen)
		ScrDrawNotify(updLeft, updTop, updWidth, updHeight);
		
		
	// Free the temporary scan line buffer if allocated dynamically
	if (infoP->dynConvSrcP) MemPtrFree(infoP->convSrcP);

}


 /***********************************************************************
 *
 * FUNCTION:	ScrLineRoutine
 *
 * DESCRIPTION:	The screen driver line draw routine.
 *
 * PARAMETERS:	
 *				winP		- Pointer to window to draw to  
 *
 *				x1			- Pixel coordinates of line (inclusive)
 *				y1
 *				x2
 *				y2
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *			kcr	10/24/95	removed special cases for horizontal & vertical lines
 *
 ***********************************************************************/
void ScrLineRoutine(WinPtr winP, SWord x1, SWord y1, SWord x2, SWord y2)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	ScrBltInfoType		info;

	Int					updTop, updLeft, updWidth, updHeight;
	UInt	i;
	UInt	x, y;
	Int	xLen, yLen;
	Int	sum;
	Int	dx;
	Int	dy;
	Int	slope = 1;
	
	
	//-------------------------------------------------------------------
	// Prepare the draw info structure
	//------------------------------------------------------------------
	if (!PrvGetDrawInfo(winP, &info, 0)) return;


	//-------------------------------------------------------------------
	// Diagonal line routine - horizontal & vertical lines should
	//	be weeded out by this point.
	//------------------------------------------------------------------
	// Get the X and Y Lengths
	if (x2 > x1) xLen = x2 - x1;
	else xLen = x1 - x2;
	if (y2 > y1) yLen = y2 - y1;
	else yLen = y1 - y2;

	//..........................................................
	// If delta Y < delta X, mostly horizontal
	//..........................................................
	if (yLen < xLen) {
		// Swap x1 and x2 if x1 > x2
		if (x1 > x2) {
			x = x1;
			x1 = x2;
			x2 = x;
			
			y = y1;
			y1 = y2;
			y2 = y;
			}
	

		// Setup variables
		sum = -xLen;
		dx = xLen << 1;
		dy = yLen << 1;
		if (y2 < y1) slope = -1;
		
		x = x1;
		y = y1;
		
		
		// Draw each pixel in the line
		for (i=0; i <= xLen; i++) {
			PrvDrawPixel(&info, x, y);
			
			x++;
			sum += dy;
			if (sum >= 0) {
				y += slope;
				sum -= dx;
				}
			}
		}	// if (yLen < xLen) 
		
		
	//..........................................................
	// If delta Y < delta X, mostly vertical
	//..........................................................
	else {
		// Swap y1 and y2 if x1 > x2
		if (y1 > y2) {
			x = x1;
			x1 = x2;
			x2 = x;
			
			y = y1;
			y1 = y2;
			y2 = y;
			}
	
		// Setup variables
		sum = -yLen;
		dx = xLen << 1;
		dy = yLen << 1;
		if (x2 < x1) slope = -1;
		
		x = x1;
		y = y1;
		
		// Draw each pixel in the line
		for (i=0; i <= yLen; i++) {
			PrvDrawPixel(&info, x, y);
			
			y++;
			sum += dx;
			if (sum >= 0) {
				x += slope;
				sum -= dy;
				}
			}
		}	// if (yLen < xLen) 
			
		
	//-------------------------------------------------------------------
	// Call the DrawNotify function if enabled	
	//-------------------------------------------------------------------
	if (gP->doDrawNotify &&
		!winP->windowFlags.offscreen) {
		updTop = y1 < y2 ? y1 : y2;
		updLeft = x1 < x2 ? x1 : x2;
		updWidth = x2 > x1 ? x2 - x1 : x1 - x2;
		updHeight = y2 > y1 ? y2 - y1 : y1 - y2;
	
		ScrDrawNotify(updLeft, updTop, updWidth+1, updHeight+1);
		}
}






/***********************************************************************
 *
 * FUNCTION:	PrvGetLineInfo, private
 *
 * DESCRIPTION: Fill in structure of type ScrBltInfoPtr in preparation
 *					for each scan line in a bitblt or draw operation
 *
 * PARAMETERS:	
 *				infoP		- pointer to structure of type ScrDrawInfoType
 *				maskP		- pointer to structure of type ScrMaskInfoType
 *
 * RETURNED:	true if drawing operation is non-empty
 *
 * CALLED BY: ScrRectangleRoutine, ScrLineRoutine, ScrCopyRectangle once
 *            ScrDrawChars for every character.
 *
 ***********************************************************************/
static void PrvGetLineInfo(ScrBltInfoPtr infoP,
						SWord	toX, SWord toY, SWord fromX, SWord fromY,
						SWord width)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	Word					patWord;
	Int					leftBits, rightBits;
	Word					widthBits;


	// Faster to use a variable for the 0xFF constant
	patWord = 0xFFFF;


	//---------------------------------------------------------
	// Calculate the start of the top line in the destination
	//---------------------------------------------------------
	infoP->dstP = infoP->dstBaseP;
	if (toY) 
		infoP->dstP += (toY * infoP->dstRowBytes) >> 1;
		
	//---------------------------------------------------------
	// Create the masks for the left and right edges of the dest
	//  and figure out how many bytes are in the middle
	// Break out this section for each bit depth in order to make
	//  it faster. The default case shows how to do it generally for
	//  any bit depth
	//---------------------------------------------------------
	switch (infoP->dstDepth) {
		case 1:
			infoP->dstP += toX >> (4);
				
			leftBits = 16 - ((toX & 0x0F));
			if (leftBits < 16)  
				infoP->leftMask = patWord >> (16 - leftBits);
			else 
				infoP->leftMask = patWord;

			widthBits = width;
			if (leftBits < widthBits)
				rightBits = (widthBits - leftBits) & (0x0F);
			else
				rightBits = ((toX & 0x0F)) + widthBits;
			break;
			
		case 2:
			infoP->dstP += toX >> (4 - 1);
				
			leftBits = 16 - ((toX & 0x07) << 1);
			if (leftBits < 16)  
				infoP->leftMask = patWord >> (16 - leftBits);
			else 
				infoP->leftMask = patWord;

			widthBits = width << 1;
			if (leftBits < widthBits)
				rightBits = (widthBits - leftBits) & (0x07 << 1);
			else
				rightBits = ((toX & 0x07) << 1) + widthBits;
			break;
			
		default:
			infoP->dstP += toX >> (4 - infoP->dstShift);
				
			leftBits = 16 - ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift);
			if (leftBits < 16)  
				infoP->leftMask = patWord >> (16 - leftBits);
			else 
				infoP->leftMask = patWord;

			widthBits = width << infoP->dstShift;
			if (leftBits < widthBits)
				rightBits = (widthBits - leftBits) & (infoP->dstPixelsInWordZ << infoP->dstShift);
			else
				rightBits = ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift) + widthBits;
			break;
		}
		
		
	// right side mask	
	if (rightBits) 
		infoP->rightMask = patWord << (16 - rightBits);
	else {
		rightBits = 16;
		infoP->rightMask = patWord;
		}
	
	// Figure out how many bytes are in the middle
	if (leftBits >= widthBits) {
		infoP->leftMask = infoP->leftMask & infoP->rightMask;
		infoP->midWords = -1;
		}
	else
		infoP->midWords = (widthBits - leftBits - rightBits) >> 4;
		
	
	// Figure out the rowDelta from the end of one row to the start of the next
	if (infoP->midWords < 0) {
		infoP->dstRowDelta = infoP->dstRowBytes - 2;
		infoP->srcRowDelta = infoP->srcRowBytes - 2;
		}
	else {
		infoP->dstRowDelta = infoP->dstRowBytes - (infoP->midWords*2) - 4;
		infoP->srcRowDelta = infoP->srcRowBytes - (infoP->midWords*2) - 4;
		}
		


	//---------------------------------------------------------
	// Calculate the start of the top line in the source
	//---------------------------------------------------------
	if (infoP->srcBaseP) {
		infoP->srcP = infoP->srcBaseP;
		if (fromY) 
			infoP->srcP += (fromY * infoP->srcRowBytes) >> 1;
		infoP->srcP += fromX >> (4 - infoP->srcShift);
		}


	//---------------------------------------------------------
	// See if we need to copy backwards (src and dest overlap) and if so,
	//  adjust the starting addresses of the source and dest. 
	//---------------------------------------------------------
	if (infoP->srcBaseP) {
		if ((DWord)infoP->dstP < (DWord)infoP->srcP   || 
			 (DWord)infoP->dstP > ((DWord)infoP->srcP) + (infoP->srcRowBytes * infoP->height) ) 
			infoP->forward = true;

		else {
			infoP->forward = false;
			
			// Calculate the end of the bottom line in the destination
			infoP->dstP += ((infoP->height-1) * infoP->dstRowBytes) >> 1;
			if (infoP->midWords >= 0)
				infoP->dstP += 1 + infoP->midWords;
			
			// Calculate the end of the bottom line in the source
			infoP->srcP += ((infoP->height-1) * infoP->srcRowBytes) >> 1;
			if (infoP->midWords >= 0)
				infoP->srcP += 1 + infoP->midWords;
			}
		}

}
	

 /***********************************************************************
 *
 * FUNCTION:	DrawPixel, private
 *
 * DESCRIPTION: Optimized routine for drawing a single pixel
 *
 * PARAMETERS:	
 *				bP			- base address of window
 *				rowBytes	- rowBytes of window
 *				y			- y coordinate of line
 *				x			- left coordinate of line
 *				extentX	- width of line
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void PrvDrawPixel(ScrBltInfoPtr infoP, Int x, Int y)
{
	Word					mask;
	WordPtr				wP;
	Word					w;
	Word					patIndex;
	Word					patWord;
	
	
	// Calculate the byte address of the pixel
	wP = infoP->dstBaseP;
	wP += (y * infoP->dstRowBytes) >> 1;
	wP += x >> (4 - infoP->dstShift);
	

	//---------------------------------------------------------
	// Create the mask for the pixel and get the pattern word
	//  for this row.
	//---------------------------------------------------------
	switch (infoP->dstDepth) {
		case 1:
			mask = 0x8000 >> (x & 0x0F);
			if (infoP->patternP) {
				patIndex = y & 0x07;
				patWord = (infoP->patternP[patIndex] << 8) |
							 (infoP->patternP[patIndex]);
				}
			else
				patWord = infoP->forePixels;
			break;
		case 2:
			mask = 0xC000 >> ((x & 0x07) << 1);
			// For 2 bit, each row of pattern is 16 bits long (8 pixels worth)
			if (infoP->patternP) {
				patIndex = y & 0x07;
				patWord = *((WordPtr)(infoP->patternP + 2*patIndex));
				}
			else
				patWord = infoP->forePixels;
			break;
		default:
			DbgSrcBreak();		// unsupported depth
		}
	
		

	//---------------------------------------------------------
	// Handle the simple 'copy' case (draw)
	//---------------------------------------------------------
	if (infoP->simple) {
		*wP = (*wP & ~mask) | (patWord & mask);
		}


	//---------------------------------------------------------
	// The complex cases - patterns and/or non-copy operations
	//---------------------------------------------------------
	else {
		
		// scrCopy Mode
		if (infoP->op == scrCopy) {
			w = *wP;
			*wP = (w & ~mask) | ((patWord) & mask) ;
			}
			
			
		// scrAND
		else if (infoP->op == scrAND) {
			w = *wP;
			*wP = (w & ~mask) | ((w & patWord) & mask) ;
			}
			
			
		// scrXOR 
		else if (infoP->op == scrXOR) {
			w = *wP;
			*wP++ = (w & ~mask) | ((w ^ patWord) & mask) ;
			}
		
		// scrOR
		else {
			w = *wP;
			*wP = (w & ~mask) | ((w | patWord) & mask) ;
			}
		
		} // Non-copy modes
		
}




 /***********************************************************************
 *
 * FUNCTION:	DrawVLine, private
 *
 * DESCRIPTION: Optimized routine for drawing vertical lines
 *
 * PARAMETERS:	
 *				bP			- base address of window
 *				rowBytes	- rowBytes of window
 *				y			- y coordinate of line
 *				x			- left coordinate of line
 *				extentY	- height of line
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void PrvDrawVLine(ScrBltInfoPtr infoP, Int x, Int y, Int extentY)
{
	WordPtr				wP;
	Word					mask, patWord;
	Int					patIndex;
	
	
	//---------------------------------------------------------
	// Get Info on the drawing operation
	//---------------------------------------------------------
	// Calculate the start of the top line and number of bytes to write
	wP = infoP->dstBaseP;;
	wP += (y * infoP->dstRowBytes) >> 1;
	wP += x >> (4 - infoP->dstShift);
	
	
	//---------------------------------------------------------
	// Create the bit mask for drawing the vertical line
	//---------------------------------------------------------
	switch (infoP->dstDepth) {
		case 1: mask = 0x8000 >> (x & 0x0F); break;
		case 2: mask = 0xC000 >> ((x & 0x07) << 1); break;
		default: DbgSrcBreak();		// unsupported depth
		}
	
	
	//---------------------------------------------------------
	// Handle the simple solid color copy case
	//---------------------------------------------------------
	patWord = infoP->forePixels & mask;
	if (infoP->simple) {
		if (patWord == 0) {
			mask = ~mask;
			if (extentY) do  {
				*wP &= mask;
				wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
				}while(--extentY);
			}
			
		else {
			if (patWord == mask) {						// if black (all 1's in patWord)
				if (extentY) do {
					*wP |= mask;
					wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
					} while(--extentY) ;
				}
			else {
				if (extentY) do {
					*wP = ((*wP & ~mask) | patWord);
					wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
					} while (--extentY);
				}
			}
		}
		
	//---------------------------------------------------------
	// Solid color scrXOR operation
	//---------------------------------------------------------
	else if (!infoP->patternP) {
		if (extentY) do {
			*wP ^= patWord;
			wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
			} while (--extentY);
		}
		
	//---------------------------------------------------------
	// Complex cases: patterns 
	//---------------------------------------------------------
	else {
		patIndex = y & 0x07;
		patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth) & mask;
		
		if (infoP->op == scrCopy) {
			if (extentY) do {
				*wP = (*wP & ~mask) | patWord;
				wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
				patIndex = (patIndex + 1) & 0x07;
				patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth) & mask;
				} while(--extentY);
			}
		
		else if (infoP->op == scrAND) {
			if (extentY) do {
				*wP &= ~mask | patWord;
				wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
				patIndex = (patIndex + 1) & 0x07;
				patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth) & mask;
				} while(--extentY);
			}
		
		else if (infoP->op == scrXOR) {
			if (extentY) do  {
				*wP ^= patWord;
				wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
				patIndex = (patIndex + 1) & 0x07;
				patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth) & mask;
				} while(--extentY);
			}
		
		else if (infoP->op == scrOR) {
			if (extentY) do  {
				*wP |= patWord;
				wP = (WordPtr)((DWord)wP + infoP->dstRowBytes);
				patIndex = (patIndex + 1) & 0x07;
				patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth) & mask;
				} while(--extentY);
			}
		
		}
}


/***********************************************************************
 *
 * FUNCTION:	PrvCompressedInnerBitBlt, private
 *
 * DESCRIPTION: Performs the inner loop of a compressed bitblt operation where either
 *					the source or destination windows are in compressed form.
 *
 * PARAMETERS:	
 *				infoP					- pointer to bitblt info 
 *				fromX					- X pixel coordinate of source
 *				toX					- X pixel coordinate of dest. 
 *				dstCompressed		- true if dest should be compressed,
 *										  false if source is compressed. 
 *
 * RETURNED:	size of compress bits.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static Err 	PrvCompressedInnerBitBlt(ScrBltInfoPtr infoP, Word fromX, Word toX,
						Boolean dstCompressed)
{
	Int					midWord;
	Word					src, nextWord;
	Int					nBitOffset;
	Int					srcRowDelta = infoP->srcRowDelta;
	Int					bitOffset;
	
	Int					height = infoP->height;
	register	WordPtr	srcP = infoP->srcP;
	register WordPtr	dstP = infoP->dstP;
	Word					leftMask = infoP->leftMask;
	Word					rightMask = infoP->rightMask;
	Word					notLeftMask = ~infoP->leftMask;
	Word					notRightMask = ~infoP->rightMask;
	
	Byte					scanLine1[scrMaxLineBytes];			// 1 scan line
	Byte					scanLine2[scrMaxLineBytes];			// 1 scan line
	Boolean				firstLine=true;
	BytePtr				compressedP=0, curLineP, prevLineP, lineP;
	BytePtr				compressionFailP;
	
	SWord					srcWordOffset;
	Boolean				needDepthConv;
	
	ScrConvertDepthProcP	convertP;
	
	// Check for max size of each line and the appropriate copy mode
	if (infoP->srcRowBytes > scrMaxLineBytes  ||  infoP->op != scrCopy) 
		return sysErrParamErr;
	


	//-------------------------------------------------------------------------
	// If we need to do bit depth conversion, calculate the
	// number of bytes in each source line that need to be converted (srcBytesInLine),
	//  the bitOffset to shift the converted source by to line it up with the
	//  destination (bitOffset), and the first word in the converted source to
	//  to blit from (srcWordOffset)
	//-------------------------------------------------------------------------
	if (infoP->srcDepth != infoP->dstDepth) {
		needDepthConv = true;
		convertP = PrvGetDepthConvertInfo(infoP, &bitOffset, &srcWordOffset,
												fromX, toX);
		}
		
	else {
		needDepthConv = false;
		bitOffset = ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift) + 16 
				- ((fromX & infoP->dstPixelsInWordZ) << infoP->dstShift);
		if (bitOffset > 16)  {
			bitOffset -= 16;
			srcWordOffset = -1;
			}
		else 
			srcWordOffset = 0;
			
		// If the source is not compressed and not depth converted,  we must adjust it's 
		// starting pointer and srcRowDelta here since it won't get set each time 
		//  through the loop -  it will just get adjusted by srcRowDelta
		if (dstCompressed) srcP += srcWordOffset;
		}
		
		
	// Get nBitOffset and adjust srcRowDelta if we're doing bit shifting since that
	//  causes us to read 1 extra word for every line. 
	if (bitOffset) {
		srcRowDelta -= sizeof(Word);
		nBitOffset = 16 - bitOffset;
		}
	// If we're not doing the shifting logic, we must skip ahead 1 word since we
	//  don't span 2 words of source to get a dest word. 
	else
		srcWordOffset++;


	//-------------------------------------------------------------------------
	// Set up local variables depending on whether the source or dest is compressed.
	//-------------------------------------------------------------------------
	if (!dstCompressed) {
		compressedP = (BytePtr)srcP + sizeof(Word);			//check skip word of compressed size.
		curLineP = scanLine1;
		}
	else {
		compressedP = (BytePtr)dstP + sizeof(Word);			//check Leave a word for the compressed size.
		prevLineP = scanLine1;
		curLineP = scanLine2;
		dstP = (WordPtr)curLineP;
		compressionFailP = compressedP + infoP->dstRowBytes*(height-2) - 2;
		}
		
		
	while(height--) {
	
		// If the source is compressed, decompress it into our scanline buffer
		if (!dstCompressed) {
			compressedP += ScrDeCompressScanLine(compressedP, curLineP, infoP->srcRowBytes);				
			srcP = (WordPtr)curLineP;
			if (!needDepthConv) srcP += srcWordOffset;
			}
			
		// If the source needs depth conversion, do that now
		if (needDepthConv) {
			(convertP)(srcP, infoP);
			srcP = infoP->convSrcP + srcWordOffset;
			}
			
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		// Write the left pixel
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		if (bitOffset) {
			nextWord = *srcP++;
			src = nextWord << nBitOffset;
			nextWord = *srcP++;
			src |= nextWord >> bitOffset;
			}
		else 
			src = *srcP++;
		
		*dstP++ = (*dstP & notLeftMask) | (src & leftMask);
		
		// Write middle pixels
		midWord = infoP->midWords;
		if (bitOffset) {
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				
				*dstP++ = src | (nextWord >> bitOffset);
				} while(--midWord);
			}
			
		else if (midWord > 0) do {
			*dstP++ = *srcP++;
			} while(--midWord);
			
			
			
		// Write last pixel
		if (midWord == 0) {
			if (bitOffset) {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				src |= nextWord >> bitOffset;
				}
			else
				src = *srcP++;

			*dstP++ = (*dstP & notRightMask) | (src & rightMask);
			}
		
		
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		// If the dest should be compressed, compress it and send to dest
		//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		if (dstCompressed) {
			compressedP += ScrCompressScanLine(curLineP, prevLineP, infoP->dstRowBytes,
											 compressedP, firstLine);
											 
											 
			// Check for compressed data that's too big
			if (compressedP >= compressionFailP) 
				return -1;

			// Switch current and prevLine buffers
			lineP = curLineP;
			curLineP = prevLineP;
			prevLineP = lineP;
			
			dstP = (WordPtr)curLineP;
			
			if (needDepthConv) {
				infoP->srcP = (WordPtr)((DWord)infoP->srcP + infoP->srcRowBytes);
				srcP = infoP->srcP;
				}
			else
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			}
		else {
			dstP = (WordPtr)((DWord)dstP + infoP->dstRowDelta);
			}
			
		firstLine = false;
		}
		
		
	// If we were compressing, store the compressed size in the first word of
	//  the compressed bits
	if (dstCompressed) 
		*(infoP->dstP) = (DWord)compressedP - (DWord)(infoP->dstP);
	
	return 0;
}


 /***********************************************************************
 *
 * FUNCTION:	ScrSendUpdateArea
 *
 * DESCRIPTION: Call periodically during remote mode to send the updated
 *  region of the screen over the serial port to the host.
 *
 * PARAMETERS:	
 *			force - if true, send update area regardless of last time it was sent
 *					  if false, send update area only if we've passed our time threshold
 *						from the last update.
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/29/95	Initial Revision
 *
 ***********************************************************************/
void ScrSendUpdateArea(Boolean force)
{
	ScrGlobalsPtr					gP = (ScrGlobalsPtr)GScrGlobalsP;
	
	#if EMULATION_LEVEL == EMULATION_NONE
	SWord								updTop, updLeft, updWidth, updHeight;
	SlkPktHeaderType				header;
	SysPktRemoteUIUpdCmdType*	bodyP;
	SysPktBodyType					body;
	Word								rowBytes;
	Int								rows, maxRowChunk;
	BytePtr							srcP, dstP, rowP;
	Int								i, j;
	SlkWriteDataType				writeList[sysPktMaxBodyChunks];
	#endif
	
	
	// If no update area, return
	if (gP->updateR.left >= gP->updateR.right) return;
	if (gP->updateR.top >= gP->updateR.bottom) return;


	// If we haven't passed our time threshold, return
	if (!force) 
		if (TimGetTicks() - gP->lastUpdate <= scrUpdateDelay) return;

	// If in Native mode....
	#if EMULATION_LEVEL != EMULATION_NONE
	
	StubDrawNotify(gP->gDevice.baseAddr, gP->gDevice.rowBytes, gP->gDevice.pixelSize, 
			gP->updateR.left, gP->updateR.top,
		 gP->updateR.right - gP->updateR.left, gP->updateR.bottom - gP->updateR.top);
		 
	//------------------------------------------------------------------------
	// Under remote screen mode, send 1 or more RemoteUIUpd packets over serial port.
	//  to the host.
	//------------------------------------------------------------------------
	#else 


	// Setup update bounds
	updTop = gP->updateR.top;
	updLeft = gP->updateR.left;
	updWidth = gP->updateR.right - updLeft;
	updHeight = gP->updateR.bottom - updTop;
	
	bodyP = (SysPktRemoteUIUpdCmdType*)&body;
	
	// Figure out row bytes and the max # of rows we can fit in a packet body
	rowBytes = ((updWidth*gP->gDevice.pixelSize + 7) >> 3) + 1;
	if (rowBytes & 0x01) rowBytes++;
	rows = updHeight;
	maxRowChunk = ( sizeof(body) - sizeof(SysPktRemoteUIUpdCmdType) ) / rowBytes;
	
	// Fill in the common fields of the packet body
	bodyP->command = sysPktRemoteUIUpdCmd;
	bodyP->rowBytes = rowBytes;
	bodyP->fromY = 0;
	bodyP->fromX = updLeft & 0x07;
	bodyP->toX = updLeft;
	bodyP->width = updWidth;
	
	// Calculate starting row of source
	rowP = (BytePtr)((DWord)gP->gDevice.baseAddr + (gP->gDevice.rowBytes * updTop) );
	rowP += updLeft >> 3;
	
	// Fill in the common fields of the packet header
	header.type = slkPktTypeSystem;
	header.src = slkSocketRemoteUI;
	header.dest = slkSocketRemoteUI;
	header.transId = 0;
	
	// Form the writelist
	writeList[0].dataP = bodyP;
	writeList[0].size = (maxRowChunk * rowBytes) + sizeof(SysPktRemoteUIUpdCmdType);
	writeList[1].size = 0;
	
	// Send groups of rows - as much as will fit in a packet at one time
	while(rows)  {
		if (maxRowChunk > rows)  {
			maxRowChunk = rows;
			writeList[0].size = (rows * rowBytes) + sizeof(SysPktRemoteUIUpdCmdType);
			}
		bodyP->toY = updTop;
		bodyP->height = maxRowChunk;
		
		dstP = (BytePtr)&bodyP->pixels;
		for (i=maxRowChunk; i>0; i--) {
			srcP = rowP;
			for (j=rowBytes; j>0; j--)
				*dstP++ = *srcP++;
			rowP += gP->gDevice.rowBytes;
			}
			
		rows -= maxRowChunk;
		updTop += maxRowChunk;

		// Send the packet
		SlkSendPacket(&header, writeList);
		} 
		
	#endif
	
	
	// Empty the update rect
	gP->updateR.left = gP->gDevice.width;
	gP->updateR.right = 0;
	gP->updateR.top = gP->gDevice.height;
	gP->updateR.bottom = 0;

	// Update the update time
	gP->lastUpdate = TimGetTicks();
	
}




 /***********************************************************************
 *
 * FUNCTION:		ScrScreenInfo
 *
 * DESCRIPTION:	Initializes the structure pointed to by the WindowPtr
 *						with screen information. 
 *
 * PARAMETERS:		winP	- Pointer to window structure to init (WindowPtr)
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
void ScrScreenInfo (WinPtr winP)
{	
	ScrGlobalsPtr	gP = (ScrGlobalsPtr)GScrGlobalsP;
	
	// Set pointer to device info
	winP->gDeviceP = &gP->gDevice;
}






 /***********************************************************************
 *
 * FUNCTION:	ScrDrawNotify
 *
 * DESCRIPTION: Called by the screen driver after every drawing operation with
 *		bounds rect of the drawing operation. Used by the Emulator to update the
 *		Mac window that shows the Pilot display. Used by the Device when
 *		doing remote screen viewing on a Macintosh.
 *
 * PARAMETERS:	
 *				scrBaseAddr			- pointer to start of screen buffer
 *				scrWidth				- width of screen in pixels
 *			
 *				updLeft				- left coordinate of update rect.
 *				updTop				- top coordinate of update rect.
 *				updWidth				- width of update rect
 *				updHeight			- height of update rect.
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
void ScrDrawNotify(SWord updLeft, SWord updTop,  SWord updWidth, SWord updHeight)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;

	AbsRectType		updR;
	
	// If no update area, reset the update time
	if (gP->updateR.left >= gP->updateR.right && gP->updateR.top >= gP->updateR.bottom) 
		gP->lastUpdate = TimGetTicks();

	updR.left = updLeft;
	updR.right = updLeft + updWidth;
	updR.top = updTop;
	updR.bottom = updTop + updHeight;
	
	// Accumulate the update area
	if (updR.left < gP->updateR.left) 
		gP->updateR.left = updR.left;
	if (updR.right > gP->updateR.right)
		gP->updateR.right = updR.right;
	if (updR.top < gP->updateR.top) 
		gP->updateR.top = updR.top;
	if (updR.bottom > gP->updateR.bottom)
		gP->updateR.bottom = updR.bottom;
		
		
	// Do an immediate update if we're not running native
	#if EMULATION_LEVEL != EMULATION_NONE
	ScrSendUpdateArea(true);
	
	// In native mode, do an update if we've passed our timeout threshold
	#else
	if (TimGetTicks() - gP->lastUpdate > scrUpdateDelay)
		ScrSendUpdateArea(true);
	#endif
}
		
 /***********************************************************************
 *
 * FUNCTION:	ScrRectangleRoutine
 *
 * DESCRIPTION:	The screen driver draw rectangle function.
 *
 * PARAMETERS:	
 *				winP		- pointer to window to draw to
 *				y			- top coordinate of rect
 *				x			- left coordinate of rect
 *				extentX	- width
 *				extentY	- height
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
void ScrRectangleRoutine(WinPtr winP, SWord x, SWord y, SWord extentX, SWord extentY)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	ScrBltInfoType		info;
	ScrBltInfoPtr		infoP;
	Word					patWord = 0xFFFF;
	Word					leftMask;
	Word					notLeftMask;
	Word					rightMask;
	Word					notRightMask;
	Int					midWord;
	WordPtr				wP;
	Word					patIndex;
	
	Int					updTop, updLeft, updWidth, updHeight;

	// Adjust for negative extents
	if (extentX < 0) {x += extentX; extentX = -extentX;}
	if (extentY < 0) {y += extentY; extentY = -extentY;}
	
	// Capture the update region
	updTop = y;
	updLeft = x;
	updWidth = extentX;
	updHeight = extentY;
	
	
	
	//-------------------------------------------------------------------
	// Prepare the draw info structure
	//------------------------------------------------------------------
	infoP = &info;
	if (!PrvGetDrawInfo(winP, infoP, extentY)) return;


	//-------------------------------------------------------------------
	// Look for the special cases where this routine is used to draw a 
	//  horizontal or vertical line
	//------------------------------------------------------------------
	if (infoP->height == 1)
		PrvDrawHLine(&info, x, y, extentX, false);

	else if (extentX == 1)		
		PrvDrawVLine(&info, x, y, infoP->height);


	//-------------------------------------------------------------------
	// General case
	//------------------------------------------------------------------
	else {
		infoP = &info;
		PrvGetLineInfo(infoP, x, y, 0, 0, extentX);

		// Put these in local variables - hoping at least some of them will end up
		//  in registers. 
		leftMask = infoP->leftMask;
		notLeftMask = ~infoP->leftMask;
		rightMask = infoP->rightMask;
		notRightMask = ~infoP->rightMask;


		wP = infoP->dstP;

		//---------------------------------------------------------
		// Get the pattern word for this row of pixels
		//---------------------------------------------------------
		if (infoP->patternP)  {
			patIndex = y & 0x07;
			patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
			}
		else
			patWord = infoP->forePixels;
			
	

		//---------------------------------------------------------
		// Handle the simple 'copy' case (draw)
		//---------------------------------------------------------
		if (infoP->simple) {
					
			while(infoP->height--) {
				// Write the left pixel
				*wP++ = (*wP & notLeftMask) | (patWord & leftMask);
				
				
				// Write middle pixels
				midWord = infoP->midWords;
				if (midWord > 0) do {
					*wP++ = patWord;
					} while(--midWord);
					
				// Write last pixel
				if (midWord == 0) {
					*wP++ = (*wP & notRightMask) | (patWord & rightMask);
					}
				
				// On to next row
				wP = (WordPtr)((BytePtr)wP + infoP->dstRowDelta);
				}
				
			}
	
	
		//---------------------------------------------------------
		// Handle the only other mode with a solid color - srcXOR
		//---------------------------------------------------------
		else if (!infoP->patternP) {
					
			while(infoP->height--) {
				// Write the left pixel
				*wP++ ^= patWord & infoP->leftMask;
				
				
				// Write middle pixels
				midWord = infoP->midWords;
				if (midWord > 0) do {
					*wP ^= patWord;
					wP++;
					} while(--midWord);
					
				// Write last pixel
				if (midWord == 0) {
					*wP ^= patWord & infoP->rightMask;
					wP++;
					}
				
				// On to next row
				wP = (WordPtr)((DWord)wP + infoP->dstRowDelta);
				}
				
			}
	
	
		//---------------------------------------------------------
		// Handle the pattern cases
		//---------------------------------------------------------
		else {

			if (infoP->op == scrCopy) {
				while(infoP->height--) {
					// Write the left pixel
					*wP = (*wP & notLeftMask) | (patWord & leftMask);
					wP++;
					
					
					// Write middle pixels
					midWord = infoP->midWords;
					if (midWord > 0) do {
						*wP++ = patWord;
						} while(--midWord);
						
					// Write last pixel
					if (midWord == 0) {
						*wP++ = (*wP & notRightMask) | (patWord & rightMask);
						}
					
					// On to next row
					wP = (WordPtr)((BytePtr)wP + infoP->dstRowDelta);
					patIndex = (patIndex + 1) & 0x07;
					patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
					}
					
				}		
			
			else if (infoP->op == scrXOR) {
				while(infoP->height--) {
					// Write the left pixel
					*wP++ ^= patWord & leftMask;
					
					
					// Write middle pixels
					midWord = infoP->midWords;
					if (midWord > 0) do {
						*wP++ ^= patWord;
						} while(--midWord);
						
					// Write last pixel
					if (midWord == 0)  {
						*wP++ ^= patWord & rightMask;
						}
					
					// On to next row
					wP = (WordPtr)((BytePtr)wP + infoP->dstRowDelta);
					patIndex = (patIndex + 1) & 0x07;
					patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
					}
					
				}		
			
			else if (infoP->op == scrAND) {
				while(infoP->height--) {
					// Write the left pixel
					*wP++ &= notLeftMask | (patWord & leftMask);
					
					
					// Write middle pixels
					midWord = infoP->midWords;
					if (midWord > 0) do {
						*wP++ &= patWord;
						} while(--midWord);
						
					// Write last pixel
					if (midWord == 0)  {
						*wP++ &= notRightMask | (patWord & rightMask);
						}
					
					// On to next row
					wP = (WordPtr)((BytePtr)wP + infoP->dstRowDelta);
					patIndex = (patIndex + 1) & 0x07;
					patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
					}
					
				}		
			
	
			else if (infoP->op == scrOR) {
				while(infoP->height--) {
					// Write the left pixel
					*wP++ |= patWord & leftMask;
					
					
					// Write middle pixels
					midWord = infoP->midWords;
					if (midWord > 0) do {
						*wP++ |= patWord;
						} while(--midWord);
						
					// Write last pixel
					if (midWord == 0)  {
						*wP |= patWord & rightMask;
						wP++;
						}
					
					// On to next row
					wP = (WordPtr)((BytePtr)wP + infoP->dstRowDelta);
					patIndex = (patIndex + 1) & 0x07;
					patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
					}
					
				}		
				
			} // Pattern cases
		}
	

	// Call the DrawNotify function if enabled	
	if (gP->doDrawNotify &&
		!winP->windowFlags.offscreen) 
		ScrDrawNotify(updLeft, updTop, updWidth, updHeight);
		
}

 /***********************************************************************
 *
 * FUNCTION:	DrawHLine, private
 *
 * DESCRIPTION: Optimized routine for drawing horizontal lines
 *
 * PARAMETERS:	
 *				bP			- base address of window
 *				rowBytes	- rowBytes of window
 *				y			- y coordinate of line
 *				x			- left coordinate of line
 *				extentX	- width of line
 *				oneBytePattern - true if we are drawing using a one-byte
 *								pattern.  This will prevent the use of a mod to
 *								access the appropriate offset within a longer pattern.
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *			kcr	10/24/95	added oneBytePattern param.
 *
 ***********************************************************************/
static void PrvDrawHLine(ScrBltInfoPtr infoP, Int x, Int y, Int extentX,
								 Boolean oneBytePattern)
{
	Word					patWord;
	Word					w;
	Word					patIndex;
	register	WordPtr	wP;
	
	
	// Faster to use a variable for the 0xFF constant
	patWord = 0xFFFF;


	//---------------------------------------------------------
	// Create the masks for the left and right edges
	//  and figure out how many bytes are in the middle
	//---------------------------------------------------------
	PrvGetLineInfo(infoP, x, y, 0, 0, extentX);
	wP = infoP->dstP;
	
		
	//---------------------------------------------------------
	// Get the pattern byte for this row of pixels
	//---------------------------------------------------------
	if (infoP->patternP)  {
		if (oneBytePattern)
			patIndex = 0;
		else
			patIndex = y & 0x07;
		patWord = PrvGetPatternWord(infoP->patternP, patIndex, infoP->dstDepth);
		}
	else
		patWord = infoP->forePixels;
		


	//---------------------------------------------------------
	// For horizontal lines, the non-pattern case is the same as
	//  the pattern case since the pattern repeats on every word
	//  anyways it's treated like a solid color would be. 
	//---------------------------------------------------------
	// scrCopy Mode
	if (infoP->op == scrCopy) {
	
		// left Pixel
		w = *wP;
		*wP++ = (w & ~infoP->leftMask) | ((patWord) & infoP->leftMask) ;
		
		// Middle Pixels
		if (infoP->midWords > 0) do {
			*wP++ = patWord;
			} while(--infoP->midWords);
			
		// Right Pixel
		if (infoP->midWords == 0) 
			*wP = (*wP & ~infoP->rightMask) | ((patWord) & infoP->rightMask);
		}
		
		
	// scrAND
	else if (infoP->op == scrAND) {
	
		// left Pixel
		w = *wP;
		*wP++ &= ~infoP->leftMask | patWord ;
		
		// Middle Pixels
		if (infoP->midWords > 0) do {
			*wP &= patWord;
			wP++;
			} while(--infoP->midWords);
			
		// Right Pixel
		if (infoP->midWords == 0) 
			*wP &= ~infoP->rightMask | patWord;
		}
		
		
	// scrXOR 
	else if (infoP->op == scrXOR) {
	
		// left Pixel
		*wP++ ^= patWord & infoP->leftMask ;
		
		// Middle Pixels
		if (infoP->midWords > 0) do {
			*wP ^= patWord;
			wP++;
			} while(--infoP->midWords);
			
		// Right Pixel
		if (infoP->midWords == 0) 
			*wP ^= patWord & infoP->rightMask;
		}
	
	// scrOR
	else {
	
		// left Pixel
		*wP++ |= patWord & infoP->leftMask ;
		
		// Middle Pixels
		if (infoP->midWords > 0) do {
			*wP |= patWord;
			wP++;
			} while(--infoP->midWords);
			
		// Right Pixel
		if (infoP->midWords == 0) 
			*wP |= patWord & infoP->rightMask;
		}
	
}


 /***********************************************************************
 *
 * FUNCTION:	AlignedForwardInnerBitBlt, private
 *
 * DESCRIPTION: Performs the inner loop of a bitblt operation for the cases where the
 *		source and destination rects start at the same bit position
 *		within a byte and the copy proceeds in the forward direction
 *
 * PARAMETERS:	
 *				infoP					- pointer to bitblt info 
 *
 * RETURNED:	void
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void 	PrvAlignedForwardInnerBitBlt(ScrBltInfoPtr infoP)
{
	register Int		midWord;
	register WordPtr	srcP = infoP->srcP;
	register WordPtr	dstP = infoP->dstP;
	Int					height = infoP->height;
	Word					leftMask = infoP->leftMask;
	Word					rightMask = infoP->rightMask;
	Word					notLeftMask = ~infoP->leftMask;
	Word					notRightMask = ~infoP->rightMask;
	
	if (!height) return;
	
	//-------------------------------------------------------------------------
	// Copy mode
	//-------------------------------------------------------------------------
	if (infoP->op == scrCopy) {
		do  {
		
			// Write the left pixel
			*dstP++ = (*dstP & notLeftMask) | (*srcP++ & leftMask);
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP++ = *srcP++;
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				*dstP++ = (*dstP & notRightMask) | (*srcP++ & rightMask);
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP + infoP->srcRowDelta );
			} while(--height);
		} // scrCopy 
		
	else if (infoP->op == scrCopyNOT) {
		do {
			// Write the left pixel
			*dstP++ = (*dstP & notLeftMask) | (~*srcP++ & leftMask);
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP++ = ~*srcP++;
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				*dstP++ = (*dstP & notRightMask) | (~*srcP++ & rightMask);
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP + infoP->srcRowDelta);
			} while(--height);
		} // scrCopyNOT
		
	else if (infoP->op == scrANDNOT) {
		do {
			// Write the left pixel
			*dstP++ &= ~(*srcP++) | notLeftMask;
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP++ &= ~(*srcP++);
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				*dstP++ &= ~(*srcP++) | notRightMask;
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP + infoP->srcRowDelta);
			} while(--height);
		} // scrANDNOT
		
	else if (infoP->op == scrXOR) {
		do {
			// Write the left pixel
			*dstP++ ^= *srcP++ & leftMask;
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP++ ^= (*srcP++);
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				*dstP++ ^= *srcP++ & rightMask;
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP + infoP->srcRowDelta);
			} while(--height);
		} // scrXOR
		
	else if (infoP->op == scrOR) {
		do {
			// Write the left pixel
			*dstP++ |= *srcP++ & leftMask;
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP++ |= (*srcP++);
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				*dstP++ |= *srcP++ & rightMask;
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP + infoP->srcRowDelta);
			} while(--height);
		} // scrOR

}



 /***********************************************************************
 *
 * FUNCTION:	AlignedBackwardInnerBitBlt, private
 *
 * DESCRIPTION: Performs the inner loop of a bitblt operation for the cases where the
 *		source and destination rects start at the same bit position
 *		within a byte and the copy proceeds in the backward direction
 *
 * PARAMETERS:	
 *				infoP					- pointer to bitblt info 
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void 	PrvAlignedBackwardInnerBitBlt(ScrBltInfoPtr infoP)
{
	register Int		midWord;
	register WordPtr	srcP = infoP->srcP;
	register WordPtr  dstP = infoP->dstP;
	Int					height = infoP->height;
	Word					leftMask = infoP->leftMask;
	Word					notLeftMask = ~infoP->leftMask;
	Word					rightMask = infoP->rightMask;
	Word					notRightMask = ~infoP->rightMask;
	
	
	if (infoP->op == scrCopy) {
		if (height) do {
			// Write the right pixel
			if (infoP->midWords >= 0) {
				*dstP-- = (*dstP & notRightMask) | (*srcP-- & rightMask);
				}
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP-- = *srcP--;
				} while(--midWord);
				
			// Write left pixel
			*dstP-- = (*dstP & notLeftMask) | (*srcP-- & leftMask);
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - infoP->srcRowDelta);
			} while(--height);
		} // scrCopy
		
		
	if (infoP->op == scrANDNOT) {
		while (height--) {
			// Write the right pixel
			if (infoP->midWords >= 0) {
				*dstP-- &= ~(*srcP--) | notRightMask;
				}
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP-- &= ~(*srcP--);
				} while(--midWord);
				
			// Write left pixel
			*dstP-- &= ~(*srcP--) | notLeftMask;
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - infoP->srcRowDelta);
			}
		} // scrANDNOT
		
	else if (infoP->op == scrXOR) {
		while (height--) {
			// Write the right pixel
			if (infoP->midWords >= 0) {
				*dstP-- ^= *srcP-- & rightMask;
				}
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP-- ^= (*srcP--);
				} while(--midWord);
				
			// Write left pixel
			*dstP-- ^= *srcP-- & leftMask;
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - infoP->srcRowDelta);
			}
		} // scrXOR
		
	else if (infoP->op == scrOR) {
		while (height--) {
			// Write the right pixel
			if (infoP->midWords >= 0) {
				*dstP-- |= *srcP-- & rightMask;
				}
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				*dstP-- |= (*srcP--);
				} while(--midWord);
				
			// Write left pixel
			*dstP-- |= *srcP-- & infoP->leftMask;
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - infoP->srcRowDelta);
			}
			
		} // scrOR
			
}




/***********************************************************************
 *
 * FUNCTION:	MisAlignedForwardInnerBitBlt, private
 *
 * DESCRIPTION: Performs the inner loop of a bitblt operation for the cases where the
 *		source and destination rects start at different bit position
 *		within a byte and the copy proceeds in the forward direction
 *
 * PARAMETERS:	
 *				infoP					- pointer to bitblt info 
 *				fromX					- x coordinate of source
 *				toX					- x coordinate of dest. 
 *
 * RETURNED:	void
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void 	PrvMisAlignedForwardInnerBitBlt(ScrBltInfoPtr infoP,
							 Word fromX, Word toX)
{
	Int					midWord;
	Word					src, nextWord;
	Int					nBitOffset, bitOffset;
	Int					srcRowDelta = infoP->srcRowDelta - sizeof(Word);
	
	Int					height = infoP->height;
	register	WordPtr	srcP;
	register WordPtr	dstP = infoP->dstP;
	Word					leftMask = infoP->leftMask;
	Word					rightMask = infoP->rightMask;  
	Word					notLeftMask = ~infoP->leftMask;
	Word					notRightMask = ~infoP->rightMask;
	
	Boolean				needDepthConv;
	SWord					srcWordOffset;
	ScrConvertDepthProcP	convertP;
	
	if (!height) return;



	//-------------------------------------------------------------------------
	// If we need to do bit depth conversion, calculate the
	// number of bytes in each source line that need to be converted (srcBytesInLine),
	//  the bitOffset to shift the converted source by to line it up with the
	//  destination (bitOffset), and the first word in the converted source to
	//  to blit from (srcWordOffset)
	//-------------------------------------------------------------------------
	if (infoP->srcDepth != infoP->dstDepth) {
		needDepthConv = true;

		convertP = PrvGetDepthConvertInfo(infoP, &bitOffset, &srcWordOffset,
												fromX, toX);
		
		}
		
	else {
		needDepthConv = false;
		bitOffset = ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift) + 16 
				- ((fromX & infoP->dstPixelsInWordZ) << infoP->dstShift);
		if (bitOffset > 16)  {
			bitOffset -= 16;
			srcP = infoP->srcP-1;
			}
		else
			srcP = infoP->srcP;
		}
		
		
	// Init the prevSrc byte and the shift masks for the src
	nBitOffset = 16 - bitOffset;
	
	//----------------------------------------------------------------------------------
	// Optimized Copy mode for 1 to 2 bit, scrCopy mode blits where the foreground
	//  color is black and background color is white. This is put in mainly to
	//  speed up character drawing.
	//-----------------------------------------------------------------------------------
	if ((infoP->op == scrCopy) && needDepthConv && (convertP == PrvConvertDepth1To2BW)) {
		WordPtr	oneBitTableP;
		BytePtr	srcBP;
		
		oneBitTableP = infoP->oneBitTableP;
		srcBP = (BytePtr)infoP->srcP;
		srcBP += srcWordOffset;							// each word expanded was 1 byte original
		
		// Figure out the rowDelta from the end of one row to the start of the next
		if (infoP->midWords < 0) 
			infoP->srcRowDelta = infoP->srcRowBytes - 2;
		else 
			infoP->srcRowDelta = infoP->srcRowBytes - (infoP->midWords) - 3;

		do {
			// Write the left pixel
			src = oneBitTableP[*srcBP++] << nBitOffset;
			nextWord = oneBitTableP[*srcBP++];
			*dstP++ = (*dstP & notLeftMask) |
						 ((src | (nextWord >> bitOffset)) & leftMask);
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = oneBitTableP[*srcBP++];
				*dstP++ = src | (nextWord >> bitOffset);
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0) {
				*dstP++ = (*dstP & notRightMask) | 
							 (((nextWord << nBitOffset) | (oneBitTableP[*srcBP++] >> bitOffset)) & rightMask);
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			srcBP += infoP->srcRowDelta;
			} while(--height);
		return;
		}
	

	// Convert the first scan line
	if (needDepthConv) {
		(convertP)(infoP->srcP, infoP);
		srcP = infoP->convSrcP + srcWordOffset;
		}
		

	//----------------------------------------------------------------------------------
	// Optimized Copy mode for narrow blits - This was put in to speed up
	//  character drawing which is usually a copy mode blit with a width
	//  of only 1 or 2 words.
	// 
	// We speed these up by doing byte reads and writes of the destination if
	//  the blit is narrow enough to fit into a single byte. This is faster
	//  than doing word reads and writes when we have 8-bit wide RAM installed.
	//-----------------------------------------------------------------------------------
	// Handle the case where the blit is only 1 word wide
	if (infoP->op == scrCopy) {
		BytePtr	bDstP;
		
		//........................................................
		// Up to 1 word of data to write - see if we can get by with
		//  doing just a single byte accesse for better performance.
		midWord = infoP->midWords;
		if (infoP->midWords < 0)  {
			
			// If we're only writing to the rightmost byte of the word...
			if ((leftMask & 0xFF00) == 0x0000) {
				bDstP = ((BytePtr)dstP) + 1;
			 	do {
		
					// Get the source word
					src = *srcP++ << nBitOffset;
					
					// Write the byte out.
					*bDstP = (*bDstP & notLeftMask) | (((*srcP++ >> bitOffset) | src) & leftMask);
					bDstP+=2;
								
					// On to next row
					bDstP += infoP->dstRowDelta;
					if (!needDepthConv) 
						srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
					else {
						infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
						(convertP)(infoP->srcP, infoP);
						srcP = infoP->convSrcP + srcWordOffset;
						}
					} while(--height);
				return;
				} // rightmost byte
				
				
			// If we're only writing to the leftmost byte of the word...
			else if ((leftMask & 0x00FF) == 0x0000) {
				bDstP = (BytePtr)dstP;
				leftMask >>= 8;
				notLeftMask >>= 8;
			 	do {
		
					// Get the source word
					src = *srcP++ << nBitOffset;
					src |= *srcP++ >> bitOffset;
					
					// Write the byte out.
					*bDstP = (*bDstP & notLeftMask) | ((src >> 8) & leftMask);
					bDstP+=2;
								
					// On to next row
					bDstP += infoP->dstRowDelta;
					if (!needDepthConv) 
						srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
					else {
						infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
						(convertP)(infoP->srcP, infoP);
						srcP = infoP->convSrcP + srcWordOffset;
						}
					} while(--height);
				return;
				} // rightmost byte
				
			} // midWords < 0
			
		//.................................................................
		// Handle the case where the blit spans 2 words but is only the inside
		//  bytes of each word
		//.................................................................
		else if (infoP->midWords == 0 
					&& ((leftMask & 0xFF00) == 0x0000)
					&& ((rightMask & 0x00FF) == 0x0000)) {
			
			bDstP = ((BytePtr)dstP) + 1;
			rightMask >>= 8;
			notRightMask >>= 8;
			do {
	
				// Write the left pixel using the byte in the right half of the word
				src = *srcP++ << nBitOffset;
				nextWord = *srcP++;
				
				*bDstP++ = (*bDstP & notLeftMask) | ((src | (nextWord >> bitOffset)) & leftMask);
				
				
				// Write last pixel
				src = nextWord << nBitOffset;
				src |= *srcP++ >> bitOffset;

				*bDstP = (*bDstP & notRightMask) | ((src >> 8) & rightMask);
				bDstP+=3;

				
				// On to next row
				bDstP = (BytePtr)((BytePtr)bDstP + infoP->dstRowDelta);
				if (!needDepthConv) 
					srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
				else {
					infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
					(convertP)(infoP->srcP,  infoP);
					srcP = infoP->convSrcP + srcWordOffset;
					}
				} while(--height);
			return;
			} // inside bytes of 2 words
		} // infoP->op == scrCopy
	


	//----------------------------------------------------------------------------------
	// General Purpose Copy mode
	//-----------------------------------------------------------------------------------
	if (infoP->op == scrCopy) {
		do {

			// Write the left pixel
			src = *srcP++ << nBitOffset;
			nextWord = *srcP++;
			src |= nextWord >> bitOffset;
			
			*dstP++ = (*dstP & notLeftMask) | ((src | (nextWord >> bitOffset)) & leftMask);
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				
				*dstP++ = src | (nextWord >> bitOffset);
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0) {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;

				*dstP++ = (*dstP & notRightMask) | ((src | (nextWord >> bitOffset)) & rightMask);
				}
			
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			if (!needDepthConv) 
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			else {
				infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
				(convertP)(infoP->srcP, infoP);
				srcP = infoP->convSrcP + srcWordOffset;
				}
			} while(--height);
		} // scrCopy 
		
		
		
	else if (infoP->op == scrCopyNOT) {
		do {
			nextWord = ~*srcP++;

			// Write the left pixel
			src = nextWord << nBitOffset;
			nextWord = ~*srcP++;
			
			*dstP++ = (*dstP & notLeftMask) | ((src | (nextWord >> bitOffset)) & leftMask);
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = ~*srcP++;
				
				*dstP++ = (src | (nextWord >> bitOffset));
				} while(--midWord);
				
				
			// Write last pixel
			if (midWord == 0) {
				src = nextWord << nBitOffset;
				nextWord = ~*srcP++;

				*dstP++ = (*dstP & notRightMask) | ((src | (nextWord >> bitOffset)) & rightMask);
				}
			
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			if (!needDepthConv) 
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			else {
				infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
				(convertP)(infoP->srcP, infoP);
				srcP = infoP->convSrcP + srcWordOffset;
				}
			} while(--height);
		} // scrCopyNOT 
		
		
		
	else if (infoP->op == scrANDNOT) {
		do {

			// Write the left pixel
			src = *srcP++ << nBitOffset;
			nextWord = *srcP++;
			
			*dstP++ &= (notLeftMask | ~(src | (nextWord >> bitOffset)));
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				
				*dstP++ &= ~(src | (nextWord >> bitOffset));
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				src = nextWord << nBitOffset;
				*dstP++ &= (notRightMask | ~(src | (*srcP++ >> bitOffset)));
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			if (!needDepthConv) 
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			else {
				infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
				(convertP)(infoP->srcP, infoP);
				srcP = infoP->convSrcP + srcWordOffset;
				}
			} while(--height);
		} // scrANDNOT
		
		
	else if (infoP->op == scrXOR) {
		do {

			// Write the left pixel
			src = *srcP++ << nBitOffset;
			nextWord = *srcP++;
			
			*dstP++ ^= (src | (nextWord >> bitOffset)) & leftMask;
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				
				*dstP++ ^= (src | (nextWord >> bitOffset));
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				src = nextWord << nBitOffset;
				*dstP ^= (src | (*srcP++ >> bitOffset)) & rightMask;
				dstP++;
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			if (!needDepthConv) 
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			else {
				infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
				(convertP)(infoP->srcP, infoP);
				srcP = infoP->convSrcP + srcWordOffset;
				}
			} while(--height);
		} // scrXOR
		
		
		
	else if (infoP->op == scrOR) {
		do {

			// Write the left pixel
			src = *srcP++ << nBitOffset;
			nextWord = *srcP++;
			
			*dstP++ |= (src | (nextWord >> bitOffset)) & leftMask;
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord << nBitOffset;
				nextWord = *srcP++;
				
				*dstP++ |= (src | (nextWord >> bitOffset));
				} while(--midWord);
				
			// Write last pixel
			if (midWord == 0)  {
				src = nextWord << nBitOffset;
				*dstP |= (src | (*srcP++ >> bitOffset)) & rightMask;
				dstP++;
				}
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP + infoP->dstRowDelta);
			if (!needDepthConv) 
				srcP = (WordPtr)((BytePtr)srcP + srcRowDelta);
			else {
				infoP->srcP = (WordPtr)((BytePtr)infoP->srcP + infoP->srcRowBytes);
				(convertP)(infoP->srcP, infoP);
				srcP = infoP->convSrcP + srcWordOffset;
				}
			} while(--height);
		} // scrOR
		
}




/***********************************************************************
 *
 * FUNCTION:	MisAlignedBackwardInnerBitBlt, private
 *
 * DESCRIPTION: Performs the inner loop of a bitblt operation for the cases where the
 *		source and destination rects start at different bit position
 *		within a byte and the copy proceeds in the forward direction
 *
 * PARAMETERS:	
 *				infoP					- pointer to bitblt info 
 *				bitOffset			- bit offset of source relative to destination
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/3/95	Initial Revision
 *
 ***********************************************************************/
static void 	PrvMisAlignedBackwardInnerBitBlt(ScrBltInfoPtr infoP, 
		Word fromX, Word toX)
{
	Int					midWord;
	Word					src, nextWord;
	Int					nBitOffset, bitOffset;
	register WordPtr	srcP = infoP->srcP;
	register WordPtr	dstP = infoP->dstP;
	Int					height = infoP->height;
	Int					srcRowDelta = infoP->srcRowDelta-2;

	Word					leftMask = infoP->leftMask;
	Word					notLeftMask = ~infoP->leftMask;
	Word					rightMask = infoP->rightMask;
	Word					notRightMask = ~infoP->rightMask;

	if (!height) return;


	//-------------------------------------------------------------------------
	// The only time we call this misaligned backward blit routine is if
	//  the source and dest overlap which must mean that they are the same
	// bit depth, so we don't need to check for bit depth conversion. 
	//-------------------------------------------------------------------------
	bitOffset = ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift) + 16 
			- ((fromX & infoP->dstPixelsInWordZ) << infoP->dstShift);
	if (bitOffset > 16)  {
		bitOffset -= 16;
		srcP = infoP->srcP;
		}
	else
		srcP = infoP->srcP+1;


	// Init the prevSrc word and the shift masks for the src
	nBitOffset = 16 - bitOffset;
	
	if (infoP->op == scrCopy) {
		while (height--) {
			nextWord = *srcP--;

			// Write the right pixel
			if (infoP->midWords >= 0) {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;
		
				*dstP-- = (*dstP & notRightMask) | ((src | (nextWord << nBitOffset))  & rightMask);
				}
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;

				*dstP-- = (src | (nextWord << nBitOffset));
				} while(--midWord);
				
			// Write left pixel
			src = nextWord >> bitOffset;
			*dstP-- = (*dstP & notLeftMask) | ((src | (*srcP-- << nBitOffset)) & leftMask);
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - srcRowDelta);
			}
		} // scrCopy
		
		
	else if (infoP->op == scrANDNOT) {
		while (height--) {
			nextWord = *srcP--;

			// Write the right pixel
			if (infoP->midWords >= 0) {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;
		
				*dstP-- &= (notRightMask | ~(src | (nextWord << nBitOffset)));
				}
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;

				*dstP-- &= ~(src | (nextWord << nBitOffset));
				} while(--midWord);
				
			// Write left pixel
			src = nextWord >> bitOffset;
			*dstP &= ~infoP->leftMask | ~(src | (*srcP-- << nBitOffset));
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - srcRowDelta);
			}
		} // scrANDNOT
		
	else if (infoP->op == scrXOR) {
		while (height--) {
			nextWord = *srcP--;
			
			// Write the right pixel
			if (infoP->midWords >= 0) {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;
		
				*dstP-- ^= rightMask & (src | (nextWord << nBitOffset));
				}
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;

				*dstP-- ^= (src | (nextWord << nBitOffset));
				} while(--midWord);
				
			// Write left pixel
			src = nextWord >> bitOffset;
			*dstP ^= leftMask & (src | (*srcP-- << nBitOffset));
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - srcRowDelta);
			}
		} // scrXOR
		
		
	else if (infoP->op == scrOR) {
		while (height--) {
			nextWord = *srcP--;
			
			// Write the right pixel
			if (infoP->midWords >= 0) {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;
		
				*dstP-- |= rightMask & (src | (nextWord << nBitOffset));
				}
			
			
			// Write middle pixels
			midWord = infoP->midWords;
			if (midWord > 0) do {
				src = nextWord >> bitOffset;
				nextWord = *srcP--;

				*dstP-- |= (src | (nextWord << nBitOffset));
				} while(--midWord);
				
			// Write left pixel
			src = nextWord >> bitOffset;
			*dstP |= infoP->leftMask & (src | (*srcP-- << nBitOffset));
			
			// On to next row
			dstP = (WordPtr)((BytePtr)dstP - infoP->dstRowDelta);
			srcP = (WordPtr)((BytePtr)srcP - srcRowDelta);
			}
		} // scrOR
			
	
}




 /***********************************************************************
 *
 * FUNCTION:	GetBltInfo, private
 *
 * DESCRIPTION: Prepare structure of type ScrBltInfoPtr in preparation
 *					for a bitblt operation
 *
 * PARAMETERS:	
 *				dstWinP		- dest window ptr
 *				srcWinP		- source window ptr, or nil if fontP is specified
 *				fontP			- pointer to font if srcWinP is nil.
 *				infoP			- pointer to structure of type ScrBltInfoPtr
 *				height		- height of blit in pixels
 *				width			- overall width of blit in pixels
 *
 * RETURNED:	true if drawing operation is non-empty
 *
 * CALLED BY:	ScrCopyRectangle, ScrDrawChars;
 *
 ***********************************************************************/
static Boolean PrvGetBltInfo(WinPtr dstWinP, WinPtr srcWinP, FontPtr fontP,
			ScrBltInfoPtr infoP, Word height, Word width)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	Word		lineSize;

	// Get destination bitmap info
	infoP->dstBaseP = dstWinP->gDeviceP->baseAddr;
	infoP->dstRowBytes = dstWinP->gDeviceP->rowBytes;
	infoP->dstDepth = dstWinP->gDeviceP->pixelSize;
	switch (infoP->dstDepth) {
		case 1: infoP->dstShift = 0; 
				  infoP->dstPixelsInWordZ = 0x0F;
				  break;
		case 2: infoP->dstShift = 1;  
				  infoP->dstPixelsInWordZ = 0x07;
				  break;
		default: DbgSrcBreak(); 
					break;					// unsupported depth
		}
	
	// Get source bitmap info if specified
	if (srcWinP) {
		infoP->srcBaseP = srcWinP->gDeviceP->baseAddr;
		infoP->srcRowBytes = srcWinP->gDeviceP->rowBytes;
		infoP->srcDepth = srcWinP->gDeviceP->pixelSize;
		switch (infoP->srcDepth) {
			case 1: 	infoP->srcShift = 0;  
				  		infoP->srcPixelsInWordZ = 0x0F;
				 		break;
			case 2: 	infoP->srcShift = 1;  
				  		infoP->srcPixelsInWordZ = 0x07;
				 		break;
			default: DbgSrcBreak(); 
						break;					// unsupported depth
			}
		}
	// If srcWinP is nil, we're doing a font
	else {
		infoP->srcBaseP = (WordPtr)(((BytePtr)fontP) + sizeof (FontType));
		infoP->srcRowBytes = fontP->rowWords << 1;
		infoP->srcDepth = 1;
		infoP->srcShift = 0;
		infoP->srcPixelsInWordZ = 0x0F;
		}
	
	
	//-----------------------------------------------------------------------
	// If there is bit depth conversion involved, initialize the fields
	//  of infoP used for bit depth conversion. These are:
	//   infoP->oneBitTableP 		# 1 bit to dstDepth conversion
	//   infoP->convSrcP				# pointer to space to hold scan line
	//	  infoP->dynConvSrcP			# true if convSrcP dynamically allocated. 
	//	  infoP->forePixels			# foreground pixels of dest
	//   infoP->backPixels			# background pixels of dest
	// Initialize the pointer to the buffer that can hold source scanlines 
	//  converted to the bit depth of the dst.
	//-----------------------------------------------------------------------
	infoP->dynConvSrcP = false;
	if (infoP->srcDepth != infoP->dstDepth) {
	
		// Get the foreground and background pixel values for dest. 
		infoP->forePixels = PrvColor2Pixels(&dstWinP->gstate->foreColor, dstWinP->gDeviceP);
		infoP->backPixels = PrvColor2Pixels(&dstWinP->gstate->backColor, dstWinP->gDeviceP);

		// Set up the pointer to the expansion table in case we're mapping 1 to N bits 
		// If we support more bit depths later, this line will have to be more general
		infoP->oneBitTableP = PrvExpand1To2Table();
		
		// Estimate the max line size required to hold 1 scan line of source expanded
		//  to the bit depth of the dest. This must be the width plus space for
		//  a partial word on each end (in case dest is not aligned
		//  on a word boundary) plus 1 word in case source and dest are on different
		//  offsets within a word
		lineSize = ((width * infoP->dstDepth) >> 3) + 3*sizeof(Word);
		if (lineSize <= gP->expSrcSize) 
			infoP->convSrcP = (WordPtr)gP->expSrcP;
		else {
			infoP->convSrcP = MemPtrNew(lineSize);
			if (!infoP->convSrcP) return false;
			infoP->dynConvSrcP = true;
			}
		}


	//-------------------------------------------------------------------------
	// Get the mode and height
	//-------------------------------------------------------------------------
	infoP->op = dstWinP->gstate->grafMode;	
	infoP->height = height;

	return true;
}
	

 /***********************************************************************
 *
 * FUNCTION:	PrvGetDrawInfo, private
 *
 * DESCRIPTION: Prepare structure of type ScrBltInfoPtr in preparation
 *					for a drawing operation
 *
 * PARAMETERS:	
 *				winP		- window pointer to draw to
 *				infoP		- pointer to structure of type ScrDrawInfoType
 *
 * RETURNED:	true if drawing operation is non-empty
 *
 * CALLED BY: ScrLineRoutine, ScrRectangleRoutine.
 *
 ***********************************************************************/
static Boolean PrvGetDrawInfo(WinPtr winP, ScrBltInfoPtr infoP, Int height)
{
	ScrGlobalsPtr		gP = (ScrGlobalsPtr)GScrGlobalsP;
	Byte*					oneBitPatternP;				// 1 bit deep pattern
	CustomPatternType	oneBitPattern;							// copy of modified 1 bit pattern
	
	// Save simple fields
	infoP->dstBaseP = winP->gDeviceP->baseAddr;
	infoP->dstRowBytes = winP->gDeviceP->rowBytes;
	infoP->dstDepth = winP->gDeviceP->pixelSize;
	switch (infoP->dstDepth) {
		case 1: infoP->dstShift = 0; 
				  infoP->dstPixelsInWordZ = 0x0F;
				  break;
		case 2: infoP->dstShift = 1;  
				  infoP->dstPixelsInWordZ = 0x07;
				  break;
		default: DbgSrcBreak(); break;					// unsupported depth
		}
	infoP->srcBaseP = 0;
	
	// Get the mode
	infoP->op = winP->gstate->grafMode;
	
	// Assume not simple
	infoP->simple = false;
	infoP->height = height;
	
	
	// If there is a custom pattern, get the pointer to the pattern.
	//  in patternP. If the pattern is simple black or white, then
	//  patternP is nil and solidPat will contain the color to use.
	infoP->patternP = 0;
	oneBitPatternP = 0;
	if (winP->gstate->patternMode) {
	
		if (winP->gstate->pattern == grayPattern) 
			oneBitPatternP = (BytePtr)((ScrGlobalsPtr)GScrGlobalsP)->grayPat;
			
		else if (winP->gstate->pattern == customPattern)
			oneBitPatternP = (BytePtr)&winP->gstate->customPtn[0];
			
		else if (winP->gstate->pattern == whitePattern) {
			if (infoP->op == scrCopy) 
				infoP->op= scrCopyNOT;
			else  
				return false;
			}
		}	
			
			
	// Get the operation type and color if no pattern. With no pattern
	//  the only operation types we need are scrCopy and scrXOR with the
	//  appropriate solidPat byte of $0 or $FF.
	if (!oneBitPatternP) {
	
		// assume we're using foreground color
		infoP->forePixels = PrvColor2Pixels(&winP->gstate->foreColor, winP->gDeviceP);

		switch (infoP->op) {
			case scrCopy:
				infoP->simple = true;
				break;

			case scrXOR:
				break;
			
			case scrAND:						// Actually a NOP when pattern is solid 1's
				return false;
				break;
				
			case scrOR:							// an OR with solid 1's is same as a Copy
				infoP->op = scrCopy;
				infoP->simple = true;
				break;
			
			case scrANDNOT:					// Actually an erase when pattern is solid 1's
			case scrCopyNOT:
				infoP->op = scrCopy;
				infoP->forePixels = PrvColor2Pixels(&winP->gstate->backColor, winP->gDeviceP);
				infoP->simple = true;
				break;
			}
		}
		
		
	//------------------------------------------------------------------------------
	// If there is a pattern, we must invert it if the mode
	//  is one of the NOT modes. NOTE: Later on we can add support for
	//  color patterns here. Currently, we only support 1 bit deep patterns
	//  but we map the 1's in the pattern to the current foreground color
	//  and the 0's to the current background color. 
	// To support a color pattern as input, we would simply copy it into the
	//  expanded pattern area pointed to by infoP->patternP. 
	//------------------------------------------------------------------------------
	else {	
		ScrConvertDepthProcP	convertP;

		if (infoP->op == scrANDNOT || infoP->op == scrCopyNOT) {
			oneBitPattern[0] = ~oneBitPatternP[0];
			oneBitPattern[1] = ~oneBitPatternP[1];
			oneBitPattern[2] = ~oneBitPatternP[2];
			oneBitPattern[3] = ~oneBitPatternP[3];
			oneBitPatternP = (BytePtr)&oneBitPattern[0];
			if (infoP->op == scrANDNOT)
				infoP->op = scrAND;
			else
				infoP->op = scrCopy;
			}
			
			
		// Now, expand the 1 bit pattern in patternP to the bit depth of the display.
		// We use the temporary expanded pattern space in the screen globals to
		// hold the expanded pattern. 
		infoP->patternP = gP->expSrcP;
		infoP->srcDepth = 1;
		infoP->forePixels = PrvColor2Pixels(&winP->gstate->foreColor, winP->gDeviceP);
		infoP->backPixels = PrvColor2Pixels(&winP->gstate->backColor, winP->gDeviceP);
		
		// Set up the pointer to the expansion table in case we're mapping 1 to N bits 
		// If we support more bit depths later, this line will have to be more general
		infoP->oneBitTableP = PrvExpand1To2Table();
		
		convertP = PrvGetDepthConvertInfo(infoP, 0, 0, 0, 0);
		// The following two fields are normally initialized by PrvGetDepthConvertInfo,
		//  except when all 0's are passed to it as we just did. 
		infoP->convSrcP = (WordPtr)infoP->patternP;
		infoP->srcBytesInLine = sizeof(CustomPatternType);
		(convertP)((WordPtr)oneBitPatternP,  infoP);
		}
		
	return true;
}
	



 /***********************************************************************
 *
 * FUNCTION:	PrvGetPatternWord
 *
 * DESCRIPTION: Returns a 16-bit word from the given row of the
 *		pattern pointed to by patP. It is assumed that the pattern
 *		pointed to by patP has already been expanded to patDepth bits
 *		deep.
 *
 * PARAMETERS:	
 *				patP		- pointer to expanded pattern (8x8 pixels)
 *				patRow	- which row of the pattern to fetch
 *				patDepth	- depth of pattern
 *
 * RETURNED:	16-bit word with back to back pixel indices in it.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		11/26	Initial Revision
 *
 ***********************************************************************/
 static Word PrvGetPatternWord(BytePtr patP, UInt patRow, UInt patDepth)
 {
	switch (patDepth) {
		case 1: return  (((Word)(patP[patRow])) << 8) | (patP[patRow]); 
		case 2: return  *((WordPtr)(patP + 2*patRow)); break;
		default: DbgSrcBreak();		//unsupported depth
		}
	return 0;			// never gets here...
}


 /***********************************************************************
 *
 * FUNCTION:	PrvColor2Pixels
 *
 * DESCRIPTION: Takes an RGB color as input and returns a 16 bit word
 *		containing back to back pixel indices that represent that color.
 *		This call is used to get a solid color for drawing and filling
 *		operations. 
 *
 * PARAMETERS:	
 *				colorP	- pointer to RGB color as input
 *				deviceP	- GDevice of device we're going to draw to.
 *
 * RETURNED:	16-bit word with back to back pixel indices in it.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		11/26	Initial Revision
 *
 ***********************************************************************/
static Word PrvColor2Pixels(RGBColorType* colorP, GDevicePtr deviceP)
{
	Word	lum;
	
	// NOTE: Later, when we support more extensive colors, this routine
	//  will have to be enhanced to do real mappings using the device color
	//  table, etc. 
	
	
	// Get a crude luminocity of the color
	lum = colorP->r + colorP->g + colorP->b;
	if (deviceP->pixelSize == 1) {
		if (lum >= 3*128) return 0x0000;				// white
		else return 0xFFFF;								// black
		}
		
	else if (deviceP->pixelSize == 2) {
		if (lum >= 0x240) return 0x0000;				// white
		if (lum >= 0x180) return 0x5555;				// light gray
		if (lum >= 0x0C0) return 0xAAAA;				// dark gray
		else 					return 0xFFFF;				// black
		}
		
	else 
		ErrFatalDisplayIf(1, "Unsupported bit depth");

	return 0;
}








 
 /***********************************************************************
 *
 * FUNCTION:	PrvExpand1To2
 *
 * DESCRIPTION: This lookup table expands a 1 bit deep byte into a
 *		2 bit deep word. 
 *
 ***********************************************************************/
static asm WordPtr PrvExpand1To2Table(void)
{
		LEA	@Table, A0
		RTS
@Table:
		DC.W        0x0000, 0x0003, 0x000C, 0x000F, 0x0030, 0x0033, 0x003C, 0x003F
		DC.W        0x00C0, 0x00C3, 0x00CC, 0x00CF, 0x00F0, 0x00F3, 0x00FC, 0x00FF
		DC.W        0x0300, 0x0303, 0x030C, 0x030F, 0x0330, 0x0333, 0x033C, 0x033F
		DC.W        0x03C0, 0x03C3, 0x03CC, 0x03CF, 0x03F0, 0x03F3, 0x03FC, 0x03FF
		DC.W        0x0C00, 0x0C03, 0x0C0C, 0x0C0F, 0x0C30, 0x0C33, 0x0C3C, 0x0C3F
		DC.W        0x0CC0, 0x0CC3, 0x0CCC, 0x0CCF, 0x0CF0, 0x0CF3, 0x0CFC, 0x0CFF
		DC.W        0x0F00, 0x0F03, 0x0F0C, 0x0F0F, 0x0F30, 0x0F33, 0x0F3C, 0x0F3F
		DC.W        0x0FC0, 0x0FC3, 0x0FCC, 0x0FCF, 0x0FF0, 0x0FF3, 0x0FFC, 0x0FFF
		DC.W        0x3000, 0x3003, 0x300C, 0x300F, 0x3030, 0x3033, 0x303C, 0x303F
		DC.W        0x30C0, 0x30C3, 0x30CC, 0x30CF, 0x30F0, 0x30F3, 0x30FC, 0x30FF
		DC.W        0x3300, 0x3303, 0x330C, 0x330F, 0x3330, 0x3333, 0x333C, 0x333F
		DC.W        0x33C0, 0x33C3, 0x33CC, 0x33CF, 0x33F0, 0x33F3, 0x33FC, 0x33FF
		DC.W        0x3C00, 0x3C03, 0x3C0C, 0x3C0F, 0x3C30, 0x3C33, 0x3C3C, 0x3C3F
		DC.W        0x3CC0, 0x3CC3, 0x3CCC, 0x3CCF, 0x3CF0, 0x3CF3, 0x3CFC, 0x3CFF
		DC.W        0x3F00, 0x3F03, 0x3F0C, 0x3F0F, 0x3F30, 0x3F33, 0x3F3C, 0x3F3F
		DC.W        0x3FC0, 0x3FC3, 0x3FCC, 0x3FCF, 0x3FF0, 0x3FF3, 0x3FFC, 0x3FFF
		DC.W        0xC000, 0xC003, 0xC00C, 0xC00F, 0xC030, 0xC033, 0xC03C, 0xC03F
		DC.W        0xC0C0, 0xC0C3, 0xC0CC, 0xC0CF, 0xC0F0, 0xC0F3, 0xC0FC, 0xC0FF
		DC.W        0xC300, 0xC303, 0xC30C, 0xC30F, 0xC330, 0xC333, 0xC33C, 0xC33F
		DC.W        0xC3C0, 0xC3C3, 0xC3CC, 0xC3CF, 0xC3F0, 0xC3F3, 0xC3FC, 0xC3FF
		DC.W        0xCC00, 0xCC03, 0xCC0C, 0xCC0F, 0xCC30, 0xCC33, 0xCC3C, 0xCC3F
		DC.W        0xCCC0, 0xCCC3, 0xCCCC, 0xCCCF, 0xCCF0, 0xCCF3, 0xCCFC, 0xCCFF
		DC.W        0xCF00, 0xCF03, 0xCF0C, 0xCF0F, 0xCF30, 0xCF33, 0xCF3C, 0xCF3F
		DC.W        0xCFC0, 0xCFC3, 0xCFCC, 0xCFCF, 0xCFF0, 0xCFF3, 0xCFFC, 0xCFFF
		DC.W        0xF000, 0xF003, 0xF00C, 0xF00F, 0xF030, 0xF033, 0xF03C, 0xF03F
		DC.W        0xF0C0, 0xF0C3, 0xF0CC, 0xF0CF, 0xF0F0, 0xF0F3, 0xF0FC, 0xF0FF
		DC.W        0xF300, 0xF303, 0xF30C, 0xF30F, 0xF330, 0xF333, 0xF33C, 0xF33F
		DC.W        0xF3C0, 0xF3C3, 0xF3CC, 0xF3CF, 0xF3F0, 0xF3F3, 0xF3FC, 0xF3FF
		DC.W        0xFC00, 0xFC03, 0xFC0C, 0xFC0F, 0xFC30, 0xFC33, 0xFC3C, 0xFC3F
		DC.W        0xFCC0, 0xFCC3, 0xFCCC, 0xFCCF, 0xFCF0, 0xFCF3, 0xFCFC, 0xFCFF
		DC.W        0xFF00, 0xFF03, 0xFF0C, 0xFF0F, 0xFF30, 0xFF33, 0xFF3C, 0xFF3F
		DC.W        0xFFC0, 0xFFC3, 0xFFCC, 0xFFCF, 0xFFF0, 0xFFF3, 0xFFFC, 0xFFFF 
}
 
 
 /***********************************************************************
 *
 * FUNCTION:	PrvConvertDepthSame
 *
 * DESCRIPTION: Takes a sequence of pixels and converts them from n bit
 *		depth into n bit. The destination pixels are written in the
 *		buffer pointed to by dstWP.  
 *
 *		This routine is stored in a procedure pointer of type ScrConvertDepthProcP
 *		and used for every scan line in a bitblt operation. It is chosen from
 *		a set of depth conversion routines by PrvGetDepthConvertInfo(). 
 *
 *		This routine assumes that certain information about the source and
 *		destination bitmaps has been setup in the infoP structure. Namely:
 *			infoP->dstDepth 		# depth of destination bitmap
 *			infoP->srcDepth		# depth of source bitmap
 *			infoP->forePixels		# packed pixels of foreground color in dest bitmap
 *			infoP->backPixels		# packed pixels of background color in dest bitmap
 *			infoP->oneBitTableP	# table used to map 1 bit pixels to B&W pixels
 *										   in destination bitmap depth
 *			infoP->srcBytesInLine # # of bytes of source to convert
 *			infoP->convSrcP		 # converted source is sent here. 
 *			
 *		NOTE: This routine can assume that the dst and source pointers never
 *			overlap.
 *
 * PARAMETERS:	
 *				srcWP 		- pointer to source pixels
 *				dstWP			- buffer to hold dest pixels
 *				bytes			- number of bytes in srcP to expand
 *				infoP			- pointer to ScrBltInfoType containing information above
 *
 * RETURNED: void
 *
 * CALLED BY: PrvMisAlignedForwardInnerBitBlt().
 *
 ***********************************************************************/
static void PrvConvertDepthSame(WordPtr srcWP, ScrBltInfoPtr	infoP)
{
	Word		words;
	WordPtr	dstWP = infoP->convSrcP;
	Word		bytes = infoP->srcBytesInLine;
	
	words = bytes >> 1;
	if (words) do {
		*dstWP++ = *srcWP++;
		} while(--words);
		
	if (bytes & 0x01)
		*((BytePtr)dstWP) = *((BytePtr)srcWP);
}





 /***********************************************************************
 *
 * FUNCTION:	PrvConvertDepth1To2BW
 *
 * DESCRIPTION: Takes a sequence of pixels and converts them from 1 bit
 *		depth into 2 bit. The destination pixels are written in the
 *		buffer pointed to by dstWP. The foreground and background colors
 *		are black and white respectively. 
 *
 *		This routine is stored in a procedure pointer of type ScrConvertDepthProcP
 *		and used for every scan line in a bitblt operation. It is chosen from
 *		a set of depth conversion routines by PrvGetDepthConvertInfo(). 
 *
 *		This routine assumes that certain information about the source and
 *		destination bitmaps has been setup in the infoP structure. Namely:
 *			infoP->dstDepth 		# depth of destination bitmap
 *			infoP->srcDepth		# depth of source bitmap
 *			infoP->forePixels		# packed pixels of foreground color in dest bitmap
 *			infoP->backPixels		# packed pixels of background color in dest bitmap
 *			infoP->oneBitTableP	# table used to map 1 bit pixels to B&W pixels
 *										   in destination bitmap depth
 *			infoP->srcBytesInLine # # of bytes of source to convert
 *			infoP->convSrcP		 # converted source is sent here. 
 *			
 *		NOTE: This routine can assume that the dst and source pointers never
 *			overlap.
 *
 * PARAMETERS:	
 *				srcWP 		- pointer to source pixels
 *				dstWP			- buffer to hold dest pixels
 *				bytes			- number of bytes in srcP to expand
 *				infoP			- pointer to ScrBltInfoType containing information above
 *
 * RETURNED: void
 *
 * CALLED BY: PrvMisAlignedForwardInnerBitBlt().
 *
 ***********************************************************************/
static void PrvConvertDepth1To2BW(WordPtr srcWP, ScrBltInfoPtr	infoP)
{
	BytePtr	srcBP = (BytePtr)srcWP;
	WordPtr	oneBitTableP;
	WordPtr	dstWP = infoP->convSrcP;
	Word		bytes = infoP->srcBytesInLine;
	
	oneBitTableP = infoP->oneBitTableP;
	do {
		*dstWP++ = oneBitTableP[*srcBP++];
		} while(--bytes);
}



 /***********************************************************************
 *
 * FUNCTION:	PrvConvertDepth1To2
 *
 * DESCRIPTION: Takes a sequence of pixels and converts them from 1 bit
 *		depth into 2 bit. The destination pixels are written in the
 *		buffer pointed to by dstWP. The foreground and background colors
 *		are not black & white. 
 *
 *		This routine is stored in a procedure pointer of type ScrConvertDepthProcP
 *		and used for every scan line in a bitblt operation. It is chosen from
 *		a set of depth conversion routines by PrvGetDepthConvertInfo(). 
 *
 *		This routine assumes that certain information about the source and
 *		destination bitmaps has been setup in the infoP structure. Namely:
 *			infoP->dstDepth 		# depth of destination bitmap
 *			infoP->srcDepth		# depth of source bitmap
 *			infoP->forePixels		# packed pixels of foreground color in dest bitmap
 *			infoP->backPixels		# packed pixels of background color in dest bitmap
 *			infoP->oneBitTableP	# table used to map 1 bit pixels to B&W pixels
 *										   in destination bitmap depth
 *			infoP->srcBytesInLine # # of bytes of source to convert
 *			infoP->convSrcP		 # converted source is sent here. 
 *			
 *		NOTE: This routine can assume that the dst and source pointers never
 *			overlap.
 *
 * PARAMETERS:	
 *				srcWP 		- pointer to source pixels
 *				dstWP			- buffer to hold dest pixels
 *				bytes			- number of bytes in srcP to expand
 *				infoP			- pointer to ScrBltInfoType containing information above
 *
 * RETURNED: void
 *
 * CALLED BY: PrvMisAlignedForwardInnerBitBlt().
 *
 ***********************************************************************/
static void PrvConvertDepth1To2(WordPtr srcWP, ScrBltInfoPtr	infoP)
{
	BytePtr	srcBP = (BytePtr)srcWP;
	WordPtr	oneBitTableP;
	Word		mask;
	WordPtr	dstWP = infoP->convSrcP;
	Word		bytes = infoP->srcBytesInLine;
	Word		forePixels = infoP->forePixels;
	Word		backPixels = infoP->backPixels;
	
	oneBitTableP = infoP->oneBitTableP;
	do {
		mask = oneBitTableP[*srcBP++];
		*dstWP++ = (mask & forePixels) | (~mask & backPixels);
		} while(--bytes);
}



 /***********************************************************************
 *
 * FUNCTION:	PrvConvertDepth2To1
 *
 * DESCRIPTION: Takes a sequence of pixels and converts them from 2 bit
 *		depth into 1 bit. The destination pixels are written in the
 *		buffer pointed to by dstWP. The foreground and background colors
 *		are black & white respectively. 
 *
 *		This routine is stored in a procedure pointer of type ScrConvertDepthProcP
 *		and used for every scan line in a bitblt operation. It is chosen from
 *		a set of depth conversion routines by PrvGetDepthConvertInfo(). 
 *
 *		This routine assumes that certain information about the source and
 *		destination bitmaps has been setup in the infoP structure. Namely:
 *			infoP->dstDepth 		# depth of destination bitmap
 *			infoP->srcDepth		# depth of source bitmap
 *			infoP->forePixels		# packed pixels of foreground color in dest bitmap
 *			infoP->backPixels		# packed pixels of background color in dest bitmap
 *			infoP->oneBitTableP	# table used to map 1 bit pixels to B&W pixels
 *										   in destination bitmap depth
 *			infoP->srcBytesInLine # # of bytes of source to convert
 *			infoP->convSrcP		 # converted source is sent here. 
 *			
 *		NOTE: This routine can assume that the dst and source pointers never
 *			overlap.
 *
 * PARAMETERS:	
 *				srcWP 		- pointer to source pixels
 *				dstWP			- buffer to hold dest pixels
 *				bytes			- number of bytes in srcP to expand
 *				infoP			- pointer to ScrBltInfoType containing information above
 *
 * RETURNED: void
 *
 * CALLED BY: PrvMisAlignedForwardInnerBitBlt().
 *
 ***********************************************************************/
static void PrvConvertDepth2To1(WordPtr srcWP, ScrBltInfoPtr	infoP)
{
	BytePtr	dstBP = (BytePtr)infoP->convSrcP;
	Word	words = infoP->srcBytesInLine >> 1;
	
	do {
		Byte nextBit;
		Word index;
		Byte nextByte = 0;
		Word nextWord = *srcWP++;
		for (index = 0; index < 8; index++) {
			switch (nextWord & 0x3) {
				case 0:
				case 1:				// Looks better to treat light gray as 0 than 1
					nextBit = 0;
					break;
					
				case 2:
				case 3:
					nextBit = 0x80;
					break;
				}
			nextByte = (nextByte >> 1) | nextBit;
			nextWord = nextWord >> 2;
			}
		*dstBP++ = nextByte;
		} while(--words);
}


	
/***********************************************************************
 *
 * FUNCTION:	PrvGetDepthConvertInfo, private
 *
 * DESCRIPTION: Gets info for a depth conversion bit blit. 
 *				initializes the srcBytesInLine field of infoP with the 
 *				# of bytes of pre-depth converted source needed for every scan 
 *				line in the destination. Also returns the procedure pointer to
 *				use for converting a scan line of source into a scan line of destination.
 *
 *			 	Each conversion procedure takes a pointer to the source and converts
 *				infoP->srcBytesInLine bytes of source to the destination bit depth
 *				and writes the converted pixels to infoP->convSrcP. 
 *
 * PARAMETERS:	
 *				infoP 				- pointer to blit info structure
 *				bitOffsetP			- # of bits that each word in the expanded source
 *										   must be shifted right by in order to line up with
 *											the destination is returned here.If 0, neither srcBytesInLine,
 *											bitOffset, nor srcWordOffset are calculated. 
 *				srcWordOffsetP		- starting word offset into the expanded source 
 *											that we must start copying from for the blit
 *											is returned here. 
 *				fromX					- x coordinate of the source
 *				toX					- x coordinate of the dest. 
 *				
 *
 * RETURNED:	pointer to procedure of type ScrConvertDepthProcP that can
 *		be used to convert a scan line of source bitmap into the destination
 *		bitmap depth. 
 *
 * CALLED BY: 	PrvMisAlignedForwardInnerBitBlt
 *					PrvCompressedInnerBitBlt
 *					ScrDrawChars to convert gray pattern to destination depth. It
 *						passes 0 for scrBytesInLineP since it only requires
 *						the conversion procedure pointer. 
 *
 * REVISION HISTORY:
 *
 ***********************************************************************/
static  ScrConvertDepthProcP PrvGetDepthConvertInfo(ScrBltInfoPtr infoP, 
						IntPtr bitOffsetP, SWordPtr srcWordOffsetP,
						Word	fromX, Word toX)
{
	Word					srcBytesInLine;
	
	Word					srcBitOffset;
	SWord					srcWordOffset;
	Int					bitOffset;


	if (bitOffsetP) {
		// We need space for the midwords + the left mask word + the rightmask word
		// + a word for shifting the source if necessary to hold the EXPANDED data.
		// srcBytesInLine is the number of bytes of pre-expanded data so it must be
		// determined from midWords of expanded data scaled by the change in bit depth
		// required. 
		srcBytesInLine = (((infoP->midWords+3) << 1) << infoP->srcShift) >> infoP->dstShift;
		
		// Figure out the word and bit offset of the source, after it's been bit depth
		//  converted to the destination depth
		srcBitOffset = (fromX & infoP->srcPixelsInWordZ) << infoP->dstShift;
		srcWordOffset = srcBitOffset >> 4;
		srcBitOffset &= 0x0F;
		
		// Get the shift amount that we have to shift the source words right by in
		//  order to line up with the destination
		bitOffset = ((toX & infoP->dstPixelsInWordZ) << infoP->dstShift) + 16 
					- srcBitOffset;
		if (bitOffset >= 16) {
			bitOffset -= 16;
			srcWordOffset--;
			}
			
		// If we have a positive srcWordOffset, we must add to srcBytesInLine to
		//  account for it. This could happen if the fromX is near the end of a word
		//  in the source and after expansion ends up more than a word away from the
		//  front of the expanded source. 
		if (srcWordOffset > 0) 
			srcBytesInLine += srcWordOffset * sizeof(Word);
		
		// Return params
		infoP->srcBytesInLine = srcBytesInLine;
		*bitOffsetP = bitOffset;
		*srcWordOffsetP = srcWordOffset;
		}
	
	// Return the correct procedure to use for converting the source pixels
	//  to the destination depth
	if (infoP->srcDepth == infoP->dstDepth) return PrvConvertDepthSame;
	
	// 1 -> X
	if (infoP->srcDepth == 1) {
		// 1 -> 2
		if (infoP->dstDepth == 2) {
			if ((infoP->forePixels == 0xFFFF) && (infoP->backPixels == 0x0000)) 
				return PrvConvertDepth1To2BW;
			else
				return PrvConvertDepth1To2;
			}
			
		// 1 -> 4
		else
			DbgSrcBreak();		// unsupported 1 -> 4
		}
		
		
	// 2 -> X
	else if (infoP->srcDepth == 2) {
		// 2 -> 1
		if (infoP->dstDepth == 1) 
				return PrvConvertDepth2To1;
			
		// 2 -> 4
		else
			DbgSrcBreak();		// unsupported (2 -> 4)
		}
		
		
	// 4 -> X
	else
		DbgSrcBreak();			// unsupported (4 -> ??)
		
	return 0;
}






#if 0   // NOT USED ANYMORE>......
/***********************************************************************
 *
 * FUNCTION:	TimerProc, private
 *
 * DESCRIPTION: Timer procedure called by AMX periodically in order
 *  to send updated area of screen over serial port to host
 *
 * PARAMETERS:	
 *
 * RETURNED:	Nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			RM		3/29/95	Initial Revision
 *
 ***********************************************************************/
static void    PrvTimerProc(Long timerID, Long param)
{
	ScrGlobalsPtr					scrP;
	SysEvtMgrGlobalsPtr			evtP;
	
	// If no update area, return
	scrP = (ScrGlobalsPtr)GScrGlobalsP;
	if (scrP->updateR.left >= scrP->updateR.right) return;
	if (scrP->updateR.top >= scrP->updateR.bottom) return;


	// Set semaphore to wake up event manager so that it can send the
	//  update area of the screen
	evtP = (SysEvtMgrGlobalsPtr)GSysEvtMgrGlobalsP;
	evtP->needRemoteScrUpdate = true;
	SysSemaphoreSet(evtP->smID);
	
}

#endif  // #if 0 for TimerProc

#endif //#if 	GRAPHICS_VERSION == GRAPHICS_VERSION_2





