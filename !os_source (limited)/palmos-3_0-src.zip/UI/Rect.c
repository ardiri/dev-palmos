/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     rect.c
 * AUTHOR:	 Art Lamb: Dec 14, 1994
 *
 * DECLARER: UI
 *
 * ROUTINES:
 *		RctSetRectangle
 *		RctCopyRectangle
 *		RctInsetRectangle
 *		RctOffsetRectangle
 *		RctPtInRectangle
 *
 * DESCRIPTION:
 *	  This file contains the routines that manipulate rectangles.
 *
 **********************************************************************/

#include <Pilot.h>


/***********************************************************************
 *
 * FUNCTION:    RctSetRectangle
 *
 * DESCRIPTION: Set a RectangeType structure to the bound passed.
 *
 * PARAMETERS:  r			pointer to a RectangleType structure
 *              left		left bound of the rectangle
 *              top		bound of the rectangle
 *              width	width of the rectangle
 *              height	height of the rectangle
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void RctSetRectangle (const RectanglePtr r, const SWord left, 
	const SWord top, const SWord width, const SWord height)
{
	r->topLeft.x = left;
	r->topLeft.y = top;
	r->extent.x = width;
	r->extent.y = height;
}


/***********************************************************************
 *
 * FUNCTION:    RctCopyRectangle
 *
 * DESCRIPTION: Copy a rectangle structure.
 *
 * PARAMETERS:  srcRect  pointer to source rectangle
 *              dstRect  pointer to destination rectangle
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void RctCopyRectangle (const RectanglePtr srcRect, 
	const RectanglePtr  dstRect)
{
	*dstRect = *srcRect;
}


/***********************************************************************
 *
 * FUNCTION:    RctInsetRectangle
 *
 * DESCRIPTION: This routine moves all sides of a rectangle in or out
 *              an equal distance.  Pass a negative value, in insetAmt
 *              to move all size of the rectangle out.
 *
 * PARAMETERS:  r			  pointer to a RectangleType structure.
 *              insetAmt  number of pixels by which to move all side
 *                        of the rectangle.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void RctInsetRectangle (const RectanglePtr r, SWord insetAmt)
{
	r->topLeft.x += insetAmt;
	r->topLeft.y += insetAmt;

	insetAmt += insetAmt;

	r->extent.x -= insetAmt;
	r->extent.y -= insetAmt;
}


/***********************************************************************
 *
 * FUNCTION:    RctOffsetRectangle
 *
 * DESCRIPTION: This routine moves a rectangle a specified amount by
 *              changing coordinates in the RectangleType structure.
 *
 * PARAMETERS:  r			 pointer to a RectangleType structure
 *              deltaX   amount to adjust x coordinate, in pixels
 *              deltaX   amount to adjust y coordinate, in pixels
 *
 * RETURNED:   nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void RctOffsetRectangle (const RectanglePtr r, const SWord deltaX, 
	const SWord deltaY)
{
	r->topLeft.x += deltaX;
	r->topLeft.y += deltaY;
}



/***********************************************************************
 *
 * FUNCTION:    RctPtInRectangle
 *
 * DESCRIPTION: This routine return TRUE is the coordinate passed is
 *              within the rectangle passed.
 *
 * PARAMETERS:  r	   pointer to a RectangleType structure
 *              x    coordinate 
 *              y    coordinate 
 *
 * RETURNED:    TRUE if the coordinate is in the rectangle
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean RctPtInRectangle (const SWord x, const SWord y, const RectanglePtr r)
{
	return (x >= r->topLeft.x &&
			  y >= r->topLeft.y &&
			  x < r->topLeft.x + r->extent.x &&
			  y < r->topLeft.y + r->extent.y);
}


/***********************************************************************
 *
 * FUNCTION:    RctGetIntersection
 *
 * DESCRIPTION: This routine returns the intersection of two rectangles.
 *
 * PARAMETERS:  r1	 pointer to a RectangleType structure
 *              r2    pointer to a RectangleType structure 
 *              r3    intersection of r1 and r2 (returned)
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	10/2/94	Initial Revision
 *
 ***********************************************************************/
void RctGetIntersection (const RectanglePtr r1, const RectanglePtr r2, 
	RectanglePtr r3)
{
	Short left, right, top, bottom;
	
	left = max (r1->topLeft.x, r2->topLeft.x);
	top = max (r1->topLeft.y, r2->topLeft.y);
	right = min (r1->topLeft.x + r1->extent.x, r2->topLeft.x + r2->extent.x);
	bottom = min (r1->topLeft.y + r1->extent.y, r2->topLeft.y + r2->extent.y);
	
	if ((left < right) && top < bottom)
		RctSetRectangle (r3, left, top, right - left, bottom - top);
	else
		RctSetRectangle (r3, 0, 0, 0, 0);
}










