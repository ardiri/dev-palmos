/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     GraffitiShift.c
 * AUTHOR:	 Art Lamb: Aug 24, 1995
 *
 * DECLARER: UI
 *
 * ROUTINES:
 *		GsiDrawIndicator
 *		GsiInitialize
 *		GsiSetLocation
 *		GsiEnable
 *		GsiEnabled
 *		GsiSetShiftState
 * 
 * DESCRIPTION:
 *	  This file contains the Griffiti shift state indicator routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <Graffiti.h>


/***********************************************************************
 *
 * FUNCTION:    GsiDrawIndicator
 *
 * DESCRIPTION: This routine draws the graffiti shift state indicator.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *
 ***********************************************************************/
static void GsiDrawIndicator (void)
{
	Char		indicatorChr;
	FontID	curFont;
		
	if (! GsiIsEnabled) return;

	switch (GsiState)
		{
		case gsiNumLock:				indicatorChr = symbolNumLock;		break;
		case gsiCapsLock:				indicatorChr = symbolCapsLock;	break;
		case gsiShiftPunctuation:	indicatorChr = symbolShiftPunc;	break;
		case gsiShiftExtended:		indicatorChr = symbolShiftExt;	break;
		case gsiShiftUpper:			indicatorChr = symbolShiftUpper;	break;
		case gsiShiftLower:			indicatorChr = symbolShiftUpper;	break;
		case gsiShiftNone:			indicatorChr = symbolShiftNone;	break;
		}

	curFont = FntSetFont (symbolFont);
	WinDrawChars (&indicatorChr, 1, GsiLocation.x, GsiLocation.y);
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    GsiInitialize
 *
 * DESCRIPTION: This routine initializes the global variables used to
 *              manage the graffiti shift state indicator.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *
 ***********************************************************************/
void GsiInitialize (void)
{
	GsiState = gsiShiftLower;
	GsiIsEnabled = false;
	GsiLocation.x = 0;
	GsiLocation.y = 0;
}


/***********************************************************************
 *
 * FUNCTION:    GsiEnable
 *
 * DESCRIPTION: This function enables or disables the graffiti shift
 *              state indicator.  Disabling the indicator makes it visible
 *              disabling making the insertion point invisible.
 *
 * PARAMETERS:  enableIt  TRUE to enable, FALSE to disable
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void GsiEnable (const Boolean enableIt)
{
	GsiIsEnabled = enableIt;

	if (enableIt)
		GsiDrawIndicator ();
}


/***********************************************************************
 *
 * FUNCTION:    GsiEnabled
 *
 * DESCRIPTION: This routine returns TRUE if the graffiti shift
 *              state indicator is enabled, or FALSE if its disabled.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:   TRUE or FALSE
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *
 ***********************************************************************/
Boolean GsiEnabled (void)
{
	return (GsiIsEnabled);
}



/***********************************************************************
 *
 * FUNCTION:    GsiSetLocation
 *
 * DESCRIPTION: This routine set the display-relative position of the 
 *              graffiti shift state indicator.  The indicator is not 
 *              redraw by this routine.
 *
 * PARAMETERS:  x  coordinate of left side of the indicator
 *              y  coordinate of top side of the indicator
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void GsiSetLocation (const SWord x, const SWord y)
{
	GsiLocation.x = x;
	GsiLocation.y = y;
}


/***********************************************************************
 *
 * FUNCTION:    GsiSetLocation
 *
 * DESCRIPTION: This routine set the graffiti shift state indicator.
 *
 * PARAMETERS:  capsLock	- true if caps lock on
 *              numLock		- true if num lock on
 *              tempShift	- current temporary shift
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	8/24/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void GsiSetShiftState (const Word lockFlags, const Word tempShift)
{
	if (tempShift == grfTempShiftPunctuation)
		GsiState = gsiShiftPunctuation;

	else if (tempShift == grfTempShiftExtended)
		GsiState = gsiShiftExtended;

	else if (tempShift == grfTempShiftUpper)
		GsiState = gsiShiftUpper;

	else if (tempShift == grfTempShiftLower)
		GsiState = gsiShiftLower;
	
	else if (lockFlags & glfNumLock)
		GsiState = gsiNumLock;

	else if (lockFlags & glfCapsLock)
		GsiState = gsiCapsLock;

	else
		GsiState = gsiShiftNone;
		
	GsiDrawIndicator ();
}




