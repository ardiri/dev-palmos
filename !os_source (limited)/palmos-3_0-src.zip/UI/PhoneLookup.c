/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot 2.0
 * FILE:     PhoneLookup.c
 * AUTHOR:	 Art Lamb: July 23, 1996
 *
 * DECLARER: Mail
 *
 * DESCRIPTION:
 *	  This is the Mail application's main module.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>

/***********************************************************************
 *
 * FUNCTION:    CallAddressApp
 *
 * DESCRIPTION: This routine sends the Address application a launch 
 *              code to lookup a record
 *
 * PARAMETERS:  key - key to search for
 *
 * RETURNED:    handle of string return by address application.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/26/96	Initial Revision
 *
 ***********************************************************************/
static VoidHand CallAddressApp (CharPtr keyP)
{
#if EMULATION_LEVEL == EMULATION_NONE
	Err						err;
	UInt						cardNo;
	DWord						result;
	LocalID					dbID;
	DmSearchStateType		searchState;
	AddrLookupParamsType	params;
			
	// Get the card number and database id of the Address application.
	err = DmGetNextDatabaseByTypeCreator (true, &searchState, 
		sysFileTApplication, sysFileCAddress, true, &cardNo, &dbID);
	ErrFatalDisplayIf(err, "Address app not found");
	if (err) return (0);


	// parameters for the lookup
	params.title = MemHandleLock (DmGetResource (strRsc, 
							phoneLookupTitleStrID));
	params.pasteButtonText = MemHandleLock (DmGetResource (strRsc, 
							phoneLookupAddStrID));
	params.formatStringP = MemHandleLock (DmGetResource (strRsc, 
							phoneLookupFormatStrID));
	params.field1 = addrLookupSortField;
	params.field2 = addrLookupListPhone;
	params.field2Optional = false;
	params.userShouldInteract = true;

	if (keyP)
		{
		MemSet(params.lookupString, addrLookupStringLength, 0);	
		StrNCopy(params.lookupString, keyP, addrLookupStringLength - 1);
		}
	else
		*params.lookupString = 0;
			
	// <RM> 1-19-98, Fixed to pass 0 for flags, instead of sysAppLaunchFlagSubCall
	//  The sysAppLaunchFlagSubCall flag is for internal use by SysAppLaunch only
	//  and should NOT be set  on entry.
	err = SysAppLaunch (cardNo, dbID, 0, sysAppLaunchCmdLookup, (Ptr)&params, &result);

	ErrFatalDisplayIf(err, "Error sending lookup action to app");

	MemPtrUnlock (params.title);
	MemPtrUnlock (params.pasteButtonText);
	MemPtrUnlock (params.formatStringP);

	if (err) return (0);
	
	return (params.resultStringH);

#else
	{
	CharPtr p;
	CharPtr str = "#LOOKUP#";
	VoidHand h;
	
	h = MemHandleNew (StrLen(str) + 1);
	p = MemHandleLock (h);
	StrCopy (p, str);
	MemPtrUnlock (p);
	return (h);
	}

#endif
}


/***********************************************************************
 *
 * FUNCTION:    PhoneNumberLookup
 *
 * DESCRIPTION: This routine called the Address Book application to
 *              lookup a phone number.
 *
 * PARAMETERS:  fld - field object
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	7/23/96	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void PhoneNumberLookup (const FieldPtr fld)
{
	Word		len;
	Word		pos;
	Word		end;
	Word		start;
	Word		resultLen;
	WordPtr	charAttrs;
	CharPtr	keyP = 0;
	CharPtr	text;
	CharPtr	resultP;
	VoidHand	keyH = 0;
	VoidHand	resultH;
	Boolean	isSelection = true;


	// If there is a selection then use it as the key.
	text = FldGetTextPtr (fld);
	FldGetSelection (fld, &start, &end);
	if (start == end)
		{
		isSelection = false;
		pos = FldGetInsPtPosition (fld);
		if (text && pos)
			{
			charAttrs = GetCharAttr ();

			// Find the start of the key value. Search backwards from the 
			// insertion point position for a delimiter.
			start = pos;
			end = start;
			while (start && ! 
					 (IsSpace(charAttrs, text[start-1]) || 
				 	  IsPunct(charAttrs, text[start-1])))
				start--;

			// If there are characters between the insertion point and the 
			// delimiter or start of the field if there are no deleimiter,
			// then find the end of the key.
			if (start != pos - 1)
				{
				len = FldGetTextLength (fld);
				while (end < len && ! 
						 (IsSpace(charAttrs, text[end]) || 
						  IsPunct(charAttrs, text[end])))
					end++;
				}
			}
		}

	// Copy the key value for the string.
	if (start != end)
		{
		len = end - start;
		if (len  > addrLookupStringLength - 1)
			len = addrLookupStringLength - 1;
		keyH = MemHandleNew (len+1);
		keyP = MemHandleLock (keyH);
		MemMove (keyP, &text[start], len);
		keyP[len] = 0;
		}


	resultH = CallAddressApp (keyP);
	if (keyH) MemHandleFree (keyH);

	// Replace the key string with the value returned by the Address 
	// application.
	if (resultH)
		{
		resultP = MemHandleLock (resultH);
		resultLen = StrLen(resultP);

		// I we can paste the result into the field through the clipboard so that
		// change can be undone with to "undo" command.
		if (resultLen <= cbdMaxTextLength)
			{
			ClipboardAddItem (clipboardText, resultP, resultLen);
			if (! isSelection)
				FldSetSelection (fld, start, end);
			FldPaste (fld);
			}
		else
			{
			if (start != end)
				FldDelete (fld, start, end);
			FldInsert (fld, resultP, resultLen);
			}

		MemHandleFree (resultH);
		}
}








