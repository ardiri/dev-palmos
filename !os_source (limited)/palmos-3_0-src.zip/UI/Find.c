/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     find.c
 * AUTHOR:	 Art Lamb: April 16, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contains the text search routines.
 *
 **********************************************************************/

#include <Pilot.h>
#include <CharAttr.h>
#include <SysEvtMgr.h>
#include <SystemPrv.h>

extern DWord	TDMain (Word cmd, Ptr cmdPBP, Word launchFlags);


/***********************************************************************
 *
 * FUNCTION:    FindStrInStr
 *
 * DESCRIPTION: This routine performs a case-blind partial word search
 *              for a string in another string.
 *
 *              This routine assumes that the string to find is in
 *              lower case characters.
 *
 * PARAMETERS:	 strToSeach - string to search
 *              strToFind  - string to find
 *              whiteSpace - array of white space characters (word 
 *                           delimiters)
 *              posP       - pointer to the offset, in the search string.
 *                           of the match
 *
 * RETURNED:	 true if the string was found.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/17/95	Initial Revision
 *			trev	08/08/97	made non modified passed variables constant
 *
 ***********************************************************************/

// Combine CharAttr.h macros for better speed
#define IsSpaceOrDelim(attr,c)		(attr[(Byte)(c)] & (_CN|_SP|_XS|_PU))

 Boolean FindStrInStr (const CharPtr strToSearch, const CharPtr strToFind, 
 	const WordPtr posP)
{
	Byte chr;
	Byte firstChr;
	WordPtr charAttr;	
	long pos = 0;
	Byte	c1, c2;
	BytePtr s1;
	BytePtr s2;
	Int result;
	BytePtr	tableP;

	
	firstChr = *strToFind;
	charAttr = GetCharAttr ();
	// Get pointer to translation table
	tableP = GetCharCaselessValue();

	while (true)
		{
		chr = strToSearch[pos];
		if (chr == '\0') break;
		
		// If the current character matches the first character of the 
		// string we're searching for, and the character is the start of 
		// a word, check for a word macth.
		chr = tableP[chr];
		if ((chr == firstChr) &&
			 ((pos == 0) || IsSpaceOrDelim (charAttr, strToSearch[pos-1])))
			{
			s1 = (BytePtr) strToFind;
			s2 = (BytePtr) &strToSearch[pos];
			
			
			do {
				c1 = *s1++;
				c2 = *s2++;
				result = c1 - tableP[c2];
				} while (result == 0 && c1 != '\0');
		
			
			// If the match is identical or all the characters in strToFind 
			// were found then we have a match.
			if (result == 0 ||
				(s1 - (BytePtr) strToFind) > StrLen(strToFind))
				{
				*posP = pos;
				return (true);
				}
			}
		pos++;
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION: 	 FindLoadFindStr
 *
 * DESCRIPTION: This routine loads the find string from any currently
 *              selected text or from the state file.
 *
 *              Each time the find dialog is confirmed, the find 
 *              setting is saved to the state file.
 *
 * PARAMETERS:  curFrm - current form (before the find dialog)
 *					 findStrLen - to be set to the length of the string (or 0)
 *
 * RETURNED:	 handle of find string
 *					 findStrLen - to be set to the length of the string (or 0)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/31/95	Initial Revision
 *			roger	3/22/96	Use selected text if available
 *
 ***********************************************************************/
 static VoidHand FindLoadFindStr (FormPtr curFrm, WordPtr findStrLen)
{
	VoidHand		findStrH = 0;
	CharPtr			findStrP;
#if	USER_MODE != USER_MODE_DEMO
	DmOpenRef		dbP;
	VoidHand		resourceH;
	FieldPtr		fld = 0;
	Word			startPosition;
	Word			endPosition;
	Word 			focusObj;
#endif

	ErrNonFatalDisplayIf(!findStrLen, "null arg");

	*findStrLen = 0;
	
// <DemoChange> If this is a demo device, display alert
#if	USER_MODE == USER_MODE_DEMO
	// Allocate a handle to hold a find string resource.
	findStrH = MemHandleNew (maxFindStrLen+1);
	findStrP = MemHandleLock (findStrH);
	StrCopy(findStrP, "call");
	*findStrLen = StrLen( findStrP );
	MemHandleUnlock(findStrH);
	return findStrH;

#else
	focusObj = FrmGetFocus(curFrm);
	if (focusObj != noFocus)
		{
		// If the table doesn't have a field then leave
		if (FrmGetObjectType(curFrm, focusObj) == frmTableObj)
			{
			fld = TblGetCurrentField(FrmGetObjectPtr(curFrm, focusObj));
			}
		else
			fld = FrmGetObjectPtr(curFrm, focusObj);
		
		if (fld != NULL)
			{
			FldGetSelection (fld, &startPosition, &endPosition);
			if (startPosition != endPosition)
				{
				// We have a selection.  Use the selected text for
				// the find dialog's text.
				
				// Do not use more text than find can handle.
				if (endPosition > startPosition + maxFindStrLen)
					endPosition = startPosition + maxFindStrLen;
				
				*findStrLen = endPosition - startPosition;
				
				findStrH = MemHandleNew (*findStrLen + 1);
				findStrP = MemHandleLock (findStrH);
		
				// Copy the find string from the resource.
				MemMove(findStrP, FldGetTextPtr(fld) + startPosition, *findStrLen);
				findStrP[*findStrLen] = '\0';
				
				MemHandleUnlock (findStrH);
				}
			}
		}


	// If no text was selected use text from the last find.	
	if (*findStrLen == 0)
		{
		dbP = PrefOpenPreferenceDB (true);
	
		if (! dbP) return 0;
		
		resourceH = DmGetResource (sysResTSysPref, sysResIDSysPrefFindStr);
		if (resourceH)
			{	
			// Allocate a handle to hold a find string resource.
			findStrH = MemHandleNew (maxFindStrLen+1);
			findStrP = MemHandleLock (findStrH);
			MemSet (findStrP, maxFindStrLen+1, 0);
	
			// Copy the find string from the resource.
			StrCopy (findStrP, MemHandleLock(resourceH));
			*findStrLen = StrLen (findStrP);
			
			MemHandleUnlock (findStrH);
			MemHandleUnlock(resourceH);
			DmReleaseResource (resourceH);
			}
	
		DmCloseDatabase (dbP);
		}


	return findStrH;
#endif
}


/***********************************************************************
 *
 * FUNCTION: 	 FindSaveFindStr
 *
 * DESCRIPTION: Save the find string from the state file.
 *
 *              Each time the find dialog is confirmed, the find 
 *              sting is saved to the state file.
 *
 * PARAMETERS:  handle of find string
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	1/31/95	Initial Revision
 *
 ***********************************************************************/
 static void FindSaveFindStr (VoidHand findStrH)
{
	DmOpenRef	dbP;
	VoidHand		resourceH;
	VoidPtr		resourceP;
	VoidPtr		findStrP;

	dbP = PrefOpenPreferenceDB (true);
	if (! dbP) return;
	
	resourceH = DmGetResource (sysResTSysPref, sysResIDSysPrefFindStr);

	// Create or resize the find string resource.
	if (!resourceH)
		resourceH = DmNewResource (dbP, sysResTSysPref, sysResIDSysPrefFindStr, maxFindStrLen+1);
	else
		resourceH = DmResizeResource (resourceH, maxFindStrLen+1);

	// Initialize find string resource.
	if (resourceH)
		{
		resourceP = MemHandleLock(resourceH);
		findStrP = MemHandleLock(findStrH);
		DmWrite(resourceP, 0, findStrP, maxFindStrLen+1);
		MemPtrUnlock(resourceP);
		MemPtrUnlock(findStrP);
		DmReleaseResource (resourceH);
		}

	DmCloseDatabase (dbP);
}



/***********************************************************************
 *
 * FUNCTION:    FindInitParams
 *
 * DESCRIPTION: This routine allocates and initializes the parameter
 *              block that is passed to to each application.
 *
 * PARAMETERS:	 nothing
 *
 * RETURNED:	 handle of the find parameter block (FindParamsType structure)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/18/95	Initial Revision
 *
 ***********************************************************************/
static VoidHand FindInitParams (CharPtr strToFind)
{
	Word							numBytes;
	BytePtr 						sc;
	BytePtr						dc;
	VoidHand 					handle;
	FindParamsPtr 				params;
	SystemPreferencesType 	sysPrefs;
	BytePtr						tableP;
	Err							err;
	

	// Allocate and zero out the parameter block.
	numBytes = sizeof (FindParamsType);
	handle = MemHandleNew (numBytes);
	params = (FindParamsPtr) MemHandleLock(handle);
	MemSet (params, numBytes, 0);
	params->newSearch = true;


	// Save the search string as typed and in all lower case.  We'll
	// use the lower case string to speed up the search.
	StrCopy (params->strAsTyped, strToFind);
	
	
	// Convert the string to find into sorted values.  We could just use
	// StrCaselessCompare on a word by word basis but it would be slower.
	// By passing the translated sort string around we only need to convert
	// it once.
	sc = (BytePtr) strToFind;
	dc = (BytePtr) params->strToFind;
	
	// Get pointer to translation table
	tableP = GetCharCaselessValue();
	
	while (*sc != '\0')
		{
		*dc = tableP[*sc];
		sc++;
		dc++;
		}
	
	// Terminate the new string
	*dc = '\0';

	// Determime if secert record should be shown.
	PrefGetPreferences (&sysPrefs);
	if (sysPrefs.hideSecretRecords)
		params->dbAccesMode = dmModeReadOnly;
	else
		params->dbAccesMode = dmModeReadOnly | dmModeShowSecret;
		
		
	// Get the info on the current app
	err = SysCurAppDatabase(&params->callerAppCardNo, &params->callerAppDbID);
	ErrFatalDisplayIf(err, "Error getting app info");

	// Make it the app we start searching
	params->appDbID = params->callerAppDbID;
	params->appCardNo = params->callerAppCardNo;	
	
	MemHandleUnlock(handle);
	return (handle);
}


/***********************************************************************
 *
 * FUNCTION:    FindGetLineBounds
 *
 * DESCRIPTION: This routine returns the bound of the next available 
 *              line, for displaying a match, in the find results
 *              dialog. 
 *
 * PARAMETERS:	 findParams  handle of FindParamsPtr
 *              r           pointer to a structure to hold the bound 
 *                          of the next results line.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/19/95	Initial Revision
 *			roger	3/22/96	Leave a border column unwritten in on both sides.
 *			trev	08/08/97	made non modified passed variables constant
 *
 ***********************************************************************/
void FindGetLineBounds (const FindParamsPtr params, const RectanglePtr r)
{
	FormPtr frm;
	TablePtr table;


	// Get the bounds of the next line in the results table.
	frm = FrmGetFormPtr (FindResultsDialog);
	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsTable));
	TblGetItemBounds (table, params->lineNumber, 0, r);
	
	// Trim off the outside column of pixels so that nothing is drawn
	// in them so they remain unbroken.
	r->topLeft.x++;
	r->extent.x -= 2;
}


/***********************************************************************
 *
 * FUNCTION:    FindDrawHeader
 *
 * DESCRIPTION: This routine draws the header line the seperates, by
 *              database, the list of found items.
 *
 * PARAMETERS:	 findParams  handle of FindParamsPtr
 *              title       description of the database (i.e. Memos)
 *
 * RETURNED:	 true if find screen is filled up. App should exit from
 *						the search if this occurs.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/19/95	Initial Revision
 *			trev	08/08/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean FindDrawHeader (const FindParamsPtr params, const CharPtr title)
{
	short x, y;
	short width;
	short titleWidth;
	short continueWidth;
	CharPtr continueStr;
	VoidHand continueStrH;
	FormPtr frm;
	TablePtr table;
	RectangleType r;


	// If there's no room for the header, set the more flag and return.
	if (params->lineNumber == maxFinds) {
		params->more = true;			
		return (true);
		}


	frm = FrmGetFormPtr (FindResultsDialog);
	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsTable));
	TblGetItemBounds (table, params->lineNumber, 0, &r);

	// Compute the width of the header text.
	titleWidth = FntCharsWidth (title, StrLen (title));
	if (params->continuation)
		{
		continueStrH = DmGetResource (strRsc, FindResultsContinueStr);
		continueStr = MemHandleLock (continueStrH);
		continueWidth = FntCharsWidth (continueStr, StrLen(continueStr));
		MemHandleUnlock (continueStrH);
		}
	else 
		continueWidth = 0;
	width = titleWidth + continueWidth - 1;
	
			
	// Draw the line to left of the title
	x = (r.extent.x - width) / 2 - 4;
	y = r.topLeft.y + (r.extent.y / 2);
	WinDrawLine (r.topLeft.x, y, x, y);
	x += 4;
	
	// Draw the header text.
	WinDrawChars (title, StrLen (title), x, r.topLeft.y);
	if (params->continuation)
		{
		continueStr = MemHandleLock (continueStrH);		
		WinDrawChars (continueStr, StrLen(continueStr), x+titleWidth, 
		 	r.topLeft.y);
		MemHandleUnlock (continueStrH);
		}
	x += width + 4;
	
	// Draw the line to the right of the title.
	WinDrawLine (x, y, r.topLeft.x + r.extent.x - 1, y);
	

	// Make the line non-selectable.
	TblSetRowUsable (table, params->lineNumber, true);
	TblSetRowSelectable (table, params->lineNumber, false);

	params->lineNumber++;
	return false;
}



/***********************************************************************
 *
 * FUNCTION:    FindSaveMatch
 *
 * DESCRIPTION: This routine saves the record and position within the record
 *              of a text search match.  This information is save so
 *              that we can later navigate to the match.
 *
 * PARAMETERS:	 params		 FindParamsPtr
 *              recordNum   record index
 *              pos         offset of the macth string from start of record
 *					 dbCardNo	 card number of database that contains the match
 *					 dbID        LocalID of database that contains the match
 *
 * RETURNED:	 true if the maximum displayable items has been exceeded.
 *
 * CALLED BY:   application code when it gets a match.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/19/95	Initial Revision
 *			trev	08/08/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean FindSaveMatch (const FindParamsPtr params, const Word recordNum, 
	const Word pos, const Word fieldNum, const DWord appCustom, 
	const Word dbCardNo, const LocalID dbID)
{
	Word row;
	FormPtr frm;
	TablePtr table;
	FindMatchPtr match;
	
	
	// Save the last record displayed.  If the search is continued it
	// continues from this record.  Note that it doesn't resume from the 
	// last record checked.  It was decided not to burden the app with 
	// this responsibility.  Retaining control of this parameter is also
	// desired.
	params->recordNum = recordNum;
	
	if (params->lineNumber == maxFinds)
		{
		params->more = true;			
		return (true);
		}

	// Save the match info.
	match = &params->match[params->numMatches];
	match->appCardNo = params->appCardNo;
	match->appDbID = params->appDbID;
	
	match->dbCardNo = dbCardNo;
	match->dbID = dbID;
	
	match->recordNum = recordNum;
	match->matchPos = pos;
	match->matchFieldNum = fieldNum;
	match->matchCustom = appCustom;
	if (params->appCardNo == params->callerAppCardNo &&
		 params->appDbID == params->callerAppDbID)
		match->foundInCaller = true;
	else
		match->foundInCaller = false;
		
		
	
	// Enable the line in the results table that will display the match.
	frm = FrmGetFormPtr (FindResultsDialog);
	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsTable));

	row = params->lineNumber;
	TblSetItemInt (table, row, 0, params->numMatches);
	TblSetItemStyle (table, row, 0, customTableItem);
	TblSetRowUsable (table, row, true);
	TblSetRowSelectable (table, row, true);

	params->numMatches++;

	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    FindDisplayNumMatchs
 *
 * DESCRIPTION: This routine displays the status line that reports the 
 *              number of matches that were found.
 *
 * PARAMETERS:	 findParams handle of FindParamsPtr
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/16/95	Initial Revision
 *
 ***********************************************************************/
static void FindDisplayNumMatchs (FindParamsPtr params, RectanglePtr r)
{
	char chr;
	short x, y;
	short width;
	Word i;
	Word len;
	Word maxWidth;
	CharPtr str;
	VoidHand rscH;

	FntSetFont (boldFont);

	// Erase the previous message.
	x = r->topLeft.x;
	y = r->topLeft.y;
	WinEraseRectangle (r, 0);

	// Display the "Matches for" or "No matches" string.
	if (params->numMatches == 0)
		rscH = DmGetResource (strRsc, FindResultsNoMatchesStr);
	else
		rscH = DmGetResource  (strRsc, FindResultsMatchesStr);

	str = MemHandleLock (rscH);
	WinDrawChars (str, StrLen (str), x, y);
	x += FntCharsWidth (str, StrLen (str)) + 2;
	MemPtrUnlock (str);
	
	// Display the search string, truncate if necessary.
	chr = dblOpenCommaQuoteChr;
	WinDrawChars (&chr, 1, x, y);
	x += FntCharWidth (chr);
	
	str = params->strAsTyped;
	len = StrLen (str);
	width = FntCharsWidth (str, len);
	if (x + width + FntCharWidth (dblCloseCommaQuoteChr) + 1 < r->extent.x)
		{
		WinDrawChars (str, len, x, y);
		x += width;
		}
	else
		{
		// Truncate the search string.
		maxWidth = r->topLeft.x + r->extent.x - x - (FntCharWidth('.') * 3) -
			FntCharWidth (dblCloseCommaQuoteChr) - 1;
		while (width && (width > maxWidth))
			{
			len--;
			width -= FntCharWidth (str[len]);
			}
		WinDrawChars (str, len, x, y);
		x += width;

		// Draw an ellipsis.
		chr = periodChr;
		for (i = 0; i < 3; i++)
			{
			WinDrawChars (&chr, 1, x, y);
			x += FntCharWidth (chr);
			}
		}
	
	chr = dblCloseCommaQuoteChr;
	WinDrawChars (&chr, 1, x, y);
	x += FntCharWidth (chr);

}

/***********************************************************************
 *
 * FUNCTION:    FindSearch
 *
 * DESCRIPTION: This routine 
 *
 * PARAMETERS:	 findParams
 *				resumeInPlace - true to continue the search from the last line
 *								false to start new or continue at top of table
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/16/95	Initial Revision
 *			roger	3/22/96	Don't select the first item
 *
 ***********************************************************************/
static void FindSearch (FormPtr frm, VoidHand findParams, Boolean resumeInPlace)
{
	short x, y;
	Word row;
	Word numRows;
	Word ctlIndex;
	Word msgIndex;
	FontID curFont;
	CharPtr str;
	TablePtr table;
	RectangleType r;
	FindParamsPtr params;
	DWord result;
	Err err=0;
	

	// Display the "searching..." message.
	curFont = FntSetFont (boldFont);
	msgIndex = FrmGetObjectIndex (frm, FindResultsMsgLabel);
	FrmGetObjectPosition (frm, msgIndex, &x, &y);
	r.topLeft.x = x;
	r.topLeft.y = y;
	r.extent.y = FntLineHeight ();
	WinGetWindowExtent (&r.extent.x, NULL);
	r.extent.x -= x;
	WinEraseRectangle (&r, 0);

	str = MemHandleLock (DmGetResource (strRsc, FindResultsSearchingStr));
	WinDrawChars (str, StrLen (str), x, y);
	MemPtrUnlock (str);	

	// Re-initial the find parameters.
	params = (FindParamsPtr) MemHandleLock(findParams);
	params->more = 0;
	if (!resumeInPlace)
		{
		params->numMatches = 0;
		params->lineNumber = 0;
		}

	// Enable / disable the find more button.
	ctlIndex = FrmGetObjectIndex (frm, FindResultsMoreButton);
	FrmHideObject (frm, ctlIndex);
	
	
	if (!resumeInPlace)
		{
		// Erase the current contents of the find results table.
		table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsTable));
		TblUnhighlightSelection (table);
		WinEraseRectangle (&table->bounds, 0);

		TblSetColumnUsable (table, 0, true);

		// Disable all the items in the table.
		numRows = TblGetNumberOfRows (table);
		for (row = 0; row < numRows; row++)
			{
			TblSetRowUsable (table, row, false);
			TblSetRowSelectable (table, row, false);
			}
		}

	
	// If this is the first time, start by searching the currently running
	// application.
	FntSetFont (stdFont);

#if EMULATION_LEVEL != EMULATION_NONE
	result = PilotMain (sysAppLaunchCmdFind, (Ptr)params, 0);
#else

	// Search applications until we fill the screen
	while (!params->more) 
		{
		// If we're not continuing a search, reset the record number
		if (!params->continuation)
			params->recordNum = 0;
			
	
		// Search the initiating application first
		if (!params->searchedCaller) {
			err = SysAppLaunch(params->appCardNo, params->appDbID, 0,
						sysAppLaunchCmdFind, (Ptr)params, &result);
			ErrFatalDisplayIf(err, "Error launching app for Find");
			if (params->more || EvtSysEventAvail(true)) 
				{
				params->more = true;
				params->continuation = true;
				}
			else
				{
				params->searchedCaller = true;
				params->continuation = false;
				}
			}
			
		// Search every other application
		else {
			UInt				cardNo;
			LocalID				dbID;
			DmSearchStateType oldState;
			Boolean oldNewSearch;
			
			// Find the next database.
			oldState = params->searchState;
			oldNewSearch = params->newSearch;
			err = DmGetNextDatabaseByTypeCreator(params->newSearch, &params->searchState, 
				sysFileTApplication, 0, true, &cardNo, &dbID);
			params->newSearch = false;
			if (err == dmErrCantFind) break;
			ErrFatalDisplayIf(err, "Error finding next app");
			
			// If this is the caller application, don't search it again
			if (cardNo == params->callerAppCardNo && 
							dbID == params->callerAppDbID) continue;
			
			// Save it's info so that FindSaveMatch can capture it
			params->appDbID = dbID;
			params->appCardNo = cardNo;
			
			// Search it
			err = SysAppLaunch(cardNo, dbID, 0,
						sysAppLaunchCmdFind, (Ptr)params, &result);
			ErrFatalDisplayIf(err, "Error launching app for Find");
			
			// If there's more to search in this app, backup the search state
			//  start the search from here when we get called again
			if (params->more || EvtSysEventAvail(true)) {
				params->more = true;
				params->searchState = oldState;
				params->newSearch = oldNewSearch;
				params->continuation = true;
				}
			else 
				params->continuation = false;
			}
		}
			
			
#endif // EMULATION_LEVEL != EMULATION_NONE
	
		

	// Display the number of matches message.
	FindDisplayNumMatchs (params, &r);
	
	// Select the first item found.
/*
	for (row = 0; row < numRows; row++)
		{
		if (TblRowSelectable (table, row))
			{
			TblSelectItem (table, row, 0);
			break;
			}
		}
*/

	// Enable / disable the find more button.
	if (params->more)
		FrmShowObject (frm, ctlIndex);
		
	MemPtrUnlock(params);
	FntSetFont (curFont);
}


/***********************************************************************
 *
 * FUNCTION:    FindGetGoToInfo
 *
 * DESCRIPTION: This routine returns information about the selected
 *              item the the "find results table".
 *
 * PARAMETERS:	 goToParams - info about record to go to (returned values)
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/7/95	Initial Revision
 *			roger 8/3/95	Handled no matches
 *
 ***********************************************************************/
static Boolean FindGetGoToInfo (VoidHand findParams, FindMatchPtr goToParams)
{
	Word row;
	Word column;
	Word count;
	FormPtr frm;
	TablePtr table;
	FindParamsPtr params;

	frm = FrmGetActiveForm ();
	table = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsTable));
	if (!TblGetSelection (table, &row, &column))
		return false;

	// Ingore the header lines.
	for (count = row ; ((int)row) >= 0; row--) 
		{
		if (!TblRowSelectable (table, row))
			count--;
		}

	params = (FindParamsPtr) MemHandleLock(findParams);
	MemMove(goToParams, &params->match[count], sizeof(FindMatchType));
	MemPtrUnlock(params);
	
	return true;
}


/***********************************************************************
 *
 * FUNCTION:    FindShowResults
 *
 * DESCRIPTION: This routine display the dialog the contains the 
 *              results to a text search.
 *
 * PARAMETERS:	 findParams - text search parameter block
 *              goToParams - info about record to go to (returned values)
 *
 * RETURNED:	 true if the go to button was pressed.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art		4/16/95		Initial Revision
 *			roger	3/22/96		Changes for touching item gotos the record
 *			tlw		2/4/98		Don't restore curForm if it was NULL
 *
 ***********************************************************************/
static Boolean FindShowResults (VoidHand findParams, FindMatchPtr goToParams)
{
	FormPtr frm;
	FormPtr curForm;
	EventType event;
	Boolean done = false;
	Boolean goToMatch = false;
	FindParamsPtr findParamsP;
	Boolean more;
	SysAppLaunchCmdSaveDataType	cmdPB;
	DWord result;
	Boolean stopButtonUsable = true;
	ControlPtr buttonP;
	Boolean handled;
	

	// Before we put up this dialog and start searching apps, send a "warning" to
	// the current application to give it a chance to save data that might be
	//  in an open dialog, close editing sessions, etc.
	findParamsP = (FindParamsPtr) MemHandleLock(findParams);
	cmdPB.uiComing = true;
	SysAppLaunch(findParamsP->callerAppCardNo, findParamsP->callerAppDbID, 0,
						sysAppLaunchCmdSaveData, (Ptr)&cmdPB, &result);
	more = findParamsP->more;
	MemPtrUnlock(findParamsP);



	curForm = FrmGetActiveForm ();

	frm = FrmInitForm (FindResultsDialog);
	FrmSetActiveForm (frm);
	FrmDrawForm (frm);

	FindSearch (frm, findParams, false);

	while (! done)
		{
		// If the stop Button is usable don't wait forever.  Return and
		// remove the button.
		EvtGetEvent (&event, stopButtonUsable ? 0 : evtWaitForever);
		handled = FrmHandleEvent (frm, &event);
		
		if (SysHandleEvent(&event))
			continue;
		
		// If the user tapped somewhere but didn't activate a control or 
		// or select a record in the table, then resume the search. 
		if (event.eType == penDownEvent &&
			!handled &&
			more &&
			stopButtonUsable)	// don't accept penDownEvent after form displayed
			{
			FindSearch (frm, findParams, true);
			}
		
		// If a nilEvent is returned then remove the stop button.  After the 
		// stop button is hidden this loop should not wait for nilEvents.
		if (event.eType == nilEvent)
			{
			if (stopButtonUsable)
				{
				// Hide the stop button
				buttonP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsStopButton));
				CtlHideControl(buttonP);
				
				stopButtonUsable = false;
				
				// Show the cancel button
				buttonP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsCancelButton));
				CtlShowControl(buttonP);
				}
			}
			
		// If the user selects a line go to where the data is.
		if (event.eType == tblSelectEvent)
			{
			if (FindGetGoToInfo (findParams, goToParams))
				goToMatch = true;
			done = true;
			break;
			}
			
		else if (event.eType == ctlSelectEvent)
			{
			// Do nothing for the Stop button because the search has already 
			// exited.
			switch (event.data.ctlSelect.controlID)
				{
				case FindResultsCancelButton:
					done = true;
					break;

				case FindResultsMoreButton:
					// Hide the cancel button
					buttonP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsCancelButton));
					CtlHideControl(buttonP);
					
					// Show the stop button
					buttonP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, FindResultsStopButton));
					CtlShowControl(buttonP);
					
					stopButtonUsable = true;
					
					FindSearch (frm, findParams, false);
					break;
				}
			}

		else if (event.eType == appStopEvent)
			{
			EvtAddEventToQueue (&event);
			break;
			}
		}

	MemHandleFree (findParams);
	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	
	if (curForm)
		FrmSetActiveForm (curForm);
	
	return (goToMatch);
}



/***********************************************************************
 *
 * FUNCTION:    Find
 *
 * DESCRIPTION: This routine displays the Find Dialog and handles user
 *              interactions with the dialog.
 *              
 * PARAMETERS:	 nothing.
 *
 * RETURNED:	 nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art		4/16/95		Initial Revision
 *			tlw		2/4/98		Check if active window is NULL before calling WinModal
 *								and don't use curFrm if it is NULL.
 *
 ***********************************************************************/
void Find (GoToParamsPtr goToP)
{
	Word buttonHit;
	Word fldIndex;
	Word strLength;
	FormPtr curFrm;
	FormPtr frm;
	FieldPtr fld;
	CharPtr strToFind;
	VoidHand strToFindH;
	VoidHand findParams;
	Boolean goToMatch = false;
	FindMatchType goToParams;
	UInt searchStrLen;
	WinHandle activeWin;
	
	// If the active window is modal, don't allow the find dialog to appear.
	activeWin = WinGetActiveWindow();
	if (activeWin && WinModal(activeWin))
		return;
	
	curFrm = FrmGetActiveForm();
	if (curFrm && WinModal (FrmGetWindowHandle(curFrm)))
		return;
		
	frm = FrmInitForm (FindDialog);
	fldIndex = FrmGetObjectIndex (frm, FindStrField);
	fld = FrmGetObjectPtr (frm, fldIndex);

	// Load the search string from the state file.
	if (curFrm)
		{
		strToFindH = FindLoadFindStr (curFrm, &strLength);
		FldSetTextHandle (fld, strToFindH);
		}
	else
		strLength = 0;

	FrmSetFocus (frm, fldIndex);
	FldSetSelection (fld, 0, strLength);

	// Enable Graffiti for the life of the find dialog if this is a DEMO ROM
	#if USER_MODE == USER_MODE_DEMO
	GSysMiscFlags &= ( ~sysMiscFlagGrfDisable );
	#endif

	buttonHit = FrmDoDialog (frm);
	if (buttonHit == FindOKButton)
		{
		strToFindH = FldGetTextHandle (fld);
		FldSetTextHandle (fld, 0);
		FrmDeleteForm (frm);
	
		if (strToFindH)
			{
			strToFind = MemHandleLock(strToFindH);
			if (*strToFind)
				{
				findParams = FindInitParams (strToFind);
				// Save search string length for the goto param block
				searchStrLen = StrLen(strToFind);
				goToMatch = FindShowResults (findParams, &goToParams);
				}

			// Save the search string to the state file.
			FindSaveFindStr (MemPtrRecoverHandle(strToFind));
			
			MemPtrFree (strToFind);
			}
		}

	else
		{
		FrmDeleteForm (frm);
		}
		
	// Disable Graffiti if this is a DEMO ROM
	#if USER_MODE == USER_MODE_DEMO
	GSysMiscFlags |= sysMiscFlagGrfDisable;
	#endif

	// Are we are going to navigate to a selected item. 
	if (goToMatch)
		{
		
		// If found in another app, we must allocate our own goTo paramBlock.
		if (!goToParams.foundInCaller) {
			goToP = MemPtrNew(sizeof(GoToParamsType));
			if (!goToP) return;
			MemPtrSetOwner(goToP, 0);
			}
		
		// Copy goTo info into the GoToParamsType structure
		goToP->searchStrLen = searchStrLen;
		goToP->dbCardNo = goToParams.dbCardNo;
		goToP->dbID = goToParams.dbID;
		goToP->recordNum = goToParams.recordNum;
		goToP->matchPos = goToParams.matchPos;
		goToP->matchFieldNum = goToParams.matchFieldNum;
		goToP->matchCustom = goToParams.matchCustom;


		// If the record we're navigating to is owned by the current application,
		// send the action code to the app.
		if (goToParams.foundInCaller) {
			Err		err;
			DWord		result;
			err = SysAppLaunch(goToParams.appCardNo, goToParams.appDbID, 0,
						sysAppLaunchCmdGoTo, (Ptr)goToP, &result);
			ErrFatalDisplayIf(err, "Error sending goTo action to app");
			return;
			}
			
			
		// Launch the new app. The UIAppShell will take care of disposing
		//  the goTo parameter block when the app finally quits.
		SysUIAppSwitch(goToParams.appCardNo, goToParams.appDbID, sysAppLaunchCmdGoTo,
									(Ptr)goToP);
		}

	return;
}
