/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     menu.h
 * AUTHOR:	 Roger Flores: November 21, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain menu routines.
 *
 **********************************************************************/

#include <Pilot.h>

#define menuPopupIndicatorOffset	12
#define spaceInsidePullDownFrame	3
#define menuTitleXOffset			4
#define menuFont					boldFont


#define commandPendingTimeout		150    // 2 1/2  seconds
#define commandTimeout				90		 // 1 1/2 seconds

#define isSeparator(p) (p->itemStr[0] == MenuSeparatorChar)

#define menuCommandStrokeChar		commandStrokeChr

/***********************************************************************
 *
 * FUNCTION: 	 EraseCommandStatus
 *
 * DESCRIPTION: This routine erases the menu command status.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to erase
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/4/95	Initial Revision
 *
 ***********************************************************************/
static void EraseCommandStatus (MenuBarPtr pMenu)
{
	WinHandle drawWin;
	short x, y;
	short width, height;

	// If the status is currently displayed, restore the bits behind the
	// status message.
	if (pMenu->bitsBehindStatus)
		{
		drawWin = WinSetDrawWindow (pMenu->bitsBehindStatus);
		WinGetWindowExtent (&width, &height);
		WinGetDisplayExtent (&x, &y);
		x = 0;
		y -= height;
		WinSetDrawWindow (WinGetDisplayWindow ());
		WinRestoreBits (pMenu->bitsBehindStatus, x, y);
		pMenu->bitsBehindStatus = NULL;
		WinSetDrawWindow (drawWin);
		
		// If the insertion point was on, turn it back on.
//		InsPtEnable (pMenu->attr.insPtEnabled == true);
		}
}	

/***********************************************************************
 *
 * FUNCTION: 	 DisplayCommandStatus
 *
 * DESCRIPTION: This routine display the menu command status.
 *
 * PARAMETERS:	 pMenu     - pointer to menu object to draw
 *              statusStr - status message
 *              timeout	  - number of ticks to display for
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/4/95	Initial Revision
 *
 ***********************************************************************/
static void DisplayCommandStatus (MenuBarPtr pMenu, CharPtr statusStr,
	Word timeout)
{
	FontID curFont;
	WinHandle drawWin;
	short width;
	short displayWidth, displayHeight;
	RectangleType r, insPtR;
	Word error;

	// Sets up the event manager such that it will generate a null
	// event at the specified time.
	pMenu->commandTick = TimGetTicks ();
	NeedNullTickCount = pMenu->commandTick + timeout;

	curFont = FntSetFont (boldFont);
	drawWin = WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetDisplayExtent (&displayWidth, &displayHeight);
	
	// If the status is currently displayed, restore the bits behind the
	// status message.
	EraseCommandStatus (pMenu);
	
	// Compute the size of the the status message.
	width = FntCharsWidth (statusStr, StrLen (statusStr));
	r.extent.x = width + 4;
	r.extent.y = FntLineHeight () + 3;
	r.topLeft.x = 0;
	r.topLeft.y = displayHeight - r.extent.y;

	// Turn off the insertion point if it's on, and intersects the 
	// status message.
		if (InsPtEnabled ())
		{
		InsPtGetLocation (&insPtR.topLeft.x, &insPtR.topLeft.y);
		insPtR.extent.x = insPtWidth;
		insPtR.extent.y = InsPtGetHeight ();
		RctGetIntersection (&r, &insPtR, &insPtR); 
		if ((insPtR.extent.x) || (insPtR.extent.y))
			InsPtEnable (false);
		}

	// Save the bits behind the status message that we are about to draw.
	pMenu->bitsBehindStatus = WinSaveBits (&r, &error);
	
	// Erase behind the status massage.
	WinEraseRectangle (&r, 3);
	r.topLeft.x++;
	r.topLeft.y++;
	r.extent.x--;
	r.extent.y--;
	
	// Draw the status message.
	WinDrawRectangle (&r, 3);
	WinInvertChars (statusStr, StrLen(statusStr), r.topLeft.x+2, r.topLeft.y+1);

	WinSetDrawWindow (drawWin);
	FntSetFont (curFont);
}

/***********************************************************************
 *
 * FUNCTION: 	 MenuEraseStatus
 *
 * DESCRIPTION: This routine erases the menu command status.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to erase
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/10/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void MenuEraseStatus (const MenuBarPtr pMenu)
{
	if (pMenu)
		EraseCommandStatus (pMenu);

	else if (UICurrentMenu)
		EraseCommandStatus (UICurrentMenu);
}

/***********************************************************************
 *
 * FUNCTION: 	 SendKeyCommand
 *
 * DESCRIPTION: This routine checks if a key is a menu command key, if
 *              it is a menu event is added to the event queue.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *              key   - key entered after command key by user
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/31/95	Initial Revision
 *
 ***********************************************************************/
static Boolean SendKeyCommand (MenuBarPtr pMenu, char key)
{
	int i, j;
	EventType newEvent;

	// Convert the key to uppercase.
	if ((key >= 'a') && (key <= 'z'))
		key -= ('a' - 'A');

	for (i = 0; i < pMenu->numMenus; i++)
		{
		for (j = 0; j < pMenu->menus[i].numItems; j++)
			{
			if (pMenu->menus[i].items[j].command == key)
				{
				MemSet (&newEvent,sizeof (EventType), 0);
				newEvent.eType = menuEvent;
				newEvent.data.menu.itemID = pMenu->menus[i].items[j].id;
				EvtAddEventToQueue (&newEvent);
				DisplayCommandStatus (pMenu, pMenu->menus[i].items[j].itemStr,
					commandTimeout);

				return (true);
				}
			}
		}
	return (false);
}


/***********************************************************************
 *
 * FUNCTION: 	 GetPulldownMenu
 *
 * DESCRIPTION: This routine returns a pulldown menu
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *
 * RETURNED:    MenuPullDownPtr - pointer to a MenuPullDownType
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/28/94	Initial Revision
 *
 ***********************************************************************/

static MenuPullDownPtr GetPulldownMenu (MenuBarPtr pMenu)
	{
	return &pMenu->menus[pMenu->curMenu];
	}

/***********************************************************************
 *
 * FUNCTION: 	 InvertItem
 *
 * DESCRIPTION: Invert the pulldown menu item at position item.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *					 item - position (0 - n) of the menu item to invert.
 *
 * RETURNED:    void
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/28/94	Initial Revision
 *
 ***********************************************************************/

static void InvertItem (MenuBarPtr pMenu, short item)
	{
	MenuPullDownPtr thisMenu;
	RectangleType	r;
	short	localFntLineHeight;
   MenuItemType *pItem;

	if (item != noMenuItemSelection && item != separatorItemSelection)
		{
		thisMenu = GetPulldownMenu(pMenu);
		localFntLineHeight = FntLineHeight();
		pItem = thisMenu->items;

		// Invert the item passed.
		r.topLeft.x = 0;
		r.extent.x = thisMenu->bounds.extent.x;
		r.topLeft.y = 0;
		r.extent.y = isSeparator((&pItem[item])) ? (localFntLineHeight/2) :
				localFntLineHeight;
		while (item > 0)
			{
			r.topLeft.y += isSeparator(pItem) ? (localFntLineHeight/2) :
				localFntLineHeight;
			item--;
			pItem++;
			};
		WinInvertRectangle (&r, 0);
		}
	}


/***********************************************************************
 *
 * FUNCTION: 	 InvertTitle
 *
 * DESCRIPTION: Invert the menu title at position menu.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *					 menu - position (0 - n) of the menu item to invert.
 *
 * RETURNED:    void
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/23/94	Initial Revision
 *
 ***********************************************************************/

static void InvertTitle (MenuBarPtr pMenu, short menu)
	{
	ErrNonFatalDisplayIf(menu == noMenuSelection, 
		"Somehow inverting when there isn't a menu to invert.");
	WinInvertRectangle (&(pMenu->menus[menu].titleBounds), 0);
	}


/***********************************************************************
 *
 * FUNCTION:    DrawMenuPulldown
 *
 * DESCRIPTION: Draw the current menu (if any).
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/21/94	Initial Revision
 *
 ***********************************************************************/
static void DrawMenuPulldown (MenuBarPtr pMenu)
	{
	RectangleType frame;
	short i;
	MenuItemType * items;
	char *itemText;
	Word error;
	MenuPullDownPtr thisMenu;
	short	drawY;
	Int textX;					// Where text is drawn
	Int menuCharX;				// Where the menu char is drawn
	Int menuCommandX;			// Where the menu command is drawn
	short localFntLineHeight;
	Char menuChar;
	short menuCommandWidth;
	short charWidth;
	

	if (!pMenu->attr.visible ||
		 pMenu->curMenu == noMenuSelection ||
		 pMenu->menus == NULL)
		return;


	thisMenu = GetPulldownMenu(pMenu);


	// If there isn't a window for the menu then make one and
	// save the bits behind it.
	if (thisMenu->menuWin == NULL)
		{
		thisMenu->menuWin = WinCreateWindow (&thisMenu->bounds,
			menuFrame, false, false, &error);
		// Save the bits behind the popup window.
		WinSetDrawWindow (WinGetDisplayWindow());
		WinGetWindowFrameRect (WinGetWindowHandle(thisMenu->menuWin), &frame);
		RctInsetRectangle (&frame, -1);
		thisMenu->bitsBehind = WinSaveBits (&frame, &error);
		}


	// Erase the window's backgroud and draw the windows frame.
	WinEraseLine (frame.topLeft.x + 2, frame.topLeft.y + 2,
		frame.topLeft.x + frame.extent.x - 4, frame.topLeft.y + 2);
	frame.topLeft.y += 3;
	frame.extent.y -= 3;
	WinEraseRectangle (&frame, 0);
	WinSetDrawWindow (WinGetWindowHandle(thisMenu->menuWin));
	WinDrawWindowFrame();


	// Find the widest menu command char.  The command keys will be drawn
	// so that the widest char is separated from the right edge of the 
	// menu by spaceInsidePullDownFrame.  If no command keys are assigned
	// then RezConvert will have set up the right bounds closer in and this
	// code will not find any command keys to draw.
	menuCommandWidth = 0;
	items = thisMenu->items;
	for (i=0; i < thisMenu->numItems; i++)
		{
		itemText = items[i].itemStr;
		if (items[i].command != 0 &&
			items[i].itemStr[0] != MenuSeparatorChar)
			{
			charWidth = FntCharWidth(items[i].command);
			if (charWidth > menuCommandWidth)
				menuCommandWidth = charWidth;
			}
		}
	// FntCharWidth counts the last column which is blank.  Subtract it.
	if (charWidth > 0)
		charWidth--;
	

	// Draw all the menu items
	textX = spaceInsidePullDownFrame;
	menuCommandX = thisMenu->bounds.extent.x - (spaceInsidePullDownFrame - 1 ) - 
		menuCommandWidth;
	menuCharX = menuCommandX - FntCharWidth(menuCommandStrokeChar);
	drawY = 0;
	localFntLineHeight = FntLineHeight();
	menuChar = menuCommandStrokeChar;
	
	items = thisMenu->items;
	for (i=0; i < thisMenu->numItems; i++)
		{
		itemText = items[i].itemStr;

		// Draw the item text if there is any.
		ErrFatalDisplayIf(itemText == NULL, "NULL menu item text.");
		if (itemText[0] == MenuSeparatorChar)
			{
			// Draw a dotted line for a separator.
			WinDrawGrayLine (0, drawY + localFntLineHeight / 4,
				thisMenu->bounds.extent.x, drawY + localFntLineHeight / 4);
			drawY += localFntLineHeight / 2;		// separators occupy half a line
			}
		else
			{
			// Draw the menu item text
			WinDrawChars (itemText, StrLen(itemText), textX, drawY);
			
			// If there is a command display the key for it
			if (items[i].command != 0)
				{
				WinDrawChars (&menuChar, 1, menuCharX, drawY);
				WinDrawChars ((char *) &items[i].command, 1, menuCommandX, drawY);
				}
			drawY += localFntLineHeight;
			}

		}


	InvertItem (pMenu, pMenu->curItem);
	WinEnableWindow (WinGetWindowHandle(thisMenu->menuWin));
	WinSetActiveWindow (WinGetWindowHandle(thisMenu->menuWin));
	}


/***********************************************************************
 *
 * FUNCTION:    ErasePulldownMenu
 *
 * DESCRIPTION: Erase the bounds of the menu pulldown specified.
 *
 * PARAMETERS:	 menu - MenuBarPtr containing menu pulldown to erase
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/28/94	Initial Revision
 *			roger	6/6/96	Cleaned up the way menus exit
 *
 ***********************************************************************/
static void ErasePulldownMenu (MenuBarPtr pMenu, Boolean removingCompleteMenu)
	{
	WinHandle drawWindow; 
	RectangleType r;
	MenuPullDownPtr thisMenu;

	if (!pMenu->attr.visible ||
		 pMenu->curMenu == noMenuSelection ||
		 pMenu->menus == NULL)
		{
		return;
		}


	thisMenu = GetPulldownMenu(pMenu);


	drawWindow = WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (WinGetWindowHandle(thisMenu->menuWin), &r);
	RctInsetRectangle (&r, -1);
	WinRestoreBits (thisMenu->bitsBehind, r.topLeft.x, r.topLeft.y);
	
	// check if old draw window was pulldown menu which we're about to delete
	if (drawWindow == thisMenu->menuWin)
		drawWindow = NULL;
	WinDeleteWindow(WinGetWindowHandle(thisMenu->menuWin), false);
	thisMenu->menuWin = NULL;
	
	// When removing the complete menu bar it is desirable to 
	// not call WinSetActiveWindow so that multiple winEnter and winExit
	// events are not posted to the event queue.
	if (!removingCompleteMenu)
		{
		WinSetDrawWindow (WinGetWindowHandle(pMenu->barWin));
		WinSetActiveWindow (WinGetWindowHandle(pMenu->barWin));
		InvertTitle (pMenu, pMenu->curMenu);
		}
	else
		// only restore draw window if it wasn't the pulldown menu
		if (drawWindow != NULL)
			WinSetDrawWindow (drawWindow);
	}


/***********************************************************************
 *
 * FUNCTION:    MenuEraseMenu
 *
 * DESCRIPTION: Erase the bounds of the menu bar and pulldown
 *
 * PARAMETERS:	 menu - pointer to menu object to erase
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/28/94	Initial Revision
 *			roger	6/6/96	Cleaned up the way menus exit
 *
 ***********************************************************************/
static void MenuEraseMenu (MenuBarPtr pMenu, Boolean removingCompleteMenu)
	{
	WinHandle drawWindow;
	RectangleType r;

	if (!pMenu->attr.visible)
		return;

	if (pMenu->curMenu != noMenuSelection)
		ErasePulldownMenu (pMenu, removingCompleteMenu);

	drawWindow = WinSetDrawWindow (WinGetDisplayWindow ());
	WinGetWindowFrameRect (WinGetWindowHandle(pMenu->barWin), &r);
	WinRestoreBits (pMenu->bitsBehind, r.topLeft.x, r.topLeft.y);
	WinDeleteWindow(WinGetWindowHandle(pMenu->barWin), false);
	pMenu->barWin = NULL;
	pMenu->attr.visible = false;
	
	
	// Don't send another winEnter event if the savedActiveWin is already
	// set active.  This can happen if the user does a penDown outside
	// the menu windows.
	if (WinGetActiveWindow() != pMenu->savedActiveWin)
		{
		WinSetDrawWindow (pMenu->savedActiveWin);
		WinSetActiveWindow (pMenu->savedActiveWin);
		}
	else if (pMenu->savedActiveWin == 0)
		{
		// If there wasn't an active window we need to reset the draw window.
		WinSetDrawWindow (WinGetDisplayWindow ());
		}
	else
		WinSetDrawWindow(drawWindow);

	// Restore the state of the insertion point.
	InsPtEnable (pMenu->attr.insPtEnabled == true);
	}


/***********************************************************************
 *
 * FUNCTION: 	 MapPointToItem
 *
 * DESCRIPTION: Return return the item at x, y.  noItemSelected is
 *					 if the point is out of bounds of the menu or if
 *					 the item isn't selectable (a separator).
 *
 * PARAMETERS:  x, y - coordinate
 *              pMenu - menu bar pointer
 *
 * RETURNED:	 Title number (doesn't check for invalid bounds!)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/28/94	Initial Revision
 *
 ***********************************************************************/

static short MapPointToItem (SWord x, SWord y, MenuBarPtr pMenu)
	{
	MenuPullDownPtr thisMenu;
	MenuItemType *pItem;
	short item;		// the item selected;
	short localFntLineHeight;


	thisMenu = GetPulldownMenu(pMenu);

	// Is the point outside the menu window?
	if (x >= thisMenu->bounds.extent.x ||
		 y >= thisMenu->bounds.extent.y)
		item = noMenuItemSelection;
	else
		{
		item = noMenuItemSelection;
		pItem = &thisMenu->items[0];
		localFntLineHeight = FntLineHeight();

		do
			{
			y -= isSeparator(pItem++) ? localFntLineHeight/2 : localFntLineHeight;
			item++;
			} while (y >= 0);

		if (isSeparator((pItem-1)))
			item = separatorItemSelection;
		else
		if (item >= thisMenu->numItems)
			item = noMenuItemSelection;
		}


	return item;
	}


/***********************************************************************
 *
 * FUNCTION: 	 MapPointToTitle
 *
 * DESCRIPTION: Return the Title at x, y.
 *
 * PARAMETERS:  x, y - coordinate
 *              pMenu - menu bar pointer
 *
 * RETURNED:	 Title number (doesn't check for invalid bounds!)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/15/94	Initial Revision
 *
 ***********************************************************************/

static short MapPointToTitle (short x, short y, MenuBarPtr pMenu)
	{
	short i;


	for (i=0; i < pMenu->numMenus; i++)
		{
		if (RctPtInRectangle(x, y, &pMenu->menus[i].titleBounds))
			return i;
		}

	return noMenuSelection;
	}




/***********************************************************************
 *
 * FUNCTION:    MenuPulldownHandleEvent
 *
 * DESCRIPTION: Handles events in pulldown menus.  The currently only
 *              penDownEvents are handled.
 *
 *              For a penDownEvent the pen position is polled and
 *					 the menu item under the pen is inverted if allowed
 *					 (separators aren't inverted).  If the pen moves above
 *					 the menu then a penDownEvent is made and passed to the
 *					 menu bar via the event queue.  If the pen is outside
 *					 the pulldown menu but not above, no item is inverted.
 *					 If the pen is released outside the pulldown menu the
 *					 pulldown menu is erased.
 *
 *
 * PARAMETERS:	 pMenu	  - pointer to Menu Bar object (MenuBarType)
 *              pEvent    - pointer to an EventType structure.
 *              pError    - pointer to returned error code
 *
 * RETURNED:	true if the event was handle or false if it was not.
 *             pError     - error code.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/28/94	Initial Revision
 *
 ***********************************************************************/

static Boolean MenuPulldownHandleEvent
  (MenuBarPtr pMenu, EventPtr pEvent)
	{
	EventType	newEvent;
	Boolean		penDown;
	Boolean		inverted;
	short			x, y;
	short       newItem, proposedItem;
	RectangleType	r;
	MenuPullDownPtr thisMenu;


	// point to the correct menu.
	thisMenu = GetPulldownMenu(pMenu);


	r.topLeft.x = 0;
	r.topLeft.y = 0;
	WinGetWindowExtent(&r.extent.x, &r.extent.y);


	// The first point must be in the window or else the window wouldn't
	// be given the point.
	newItem = pMenu->curItem;
	proposedItem = MapPointToItem (pEvent->screenX, pEvent->screenY, pMenu);
	if (newItem != proposedItem)
		{
		InvertItem(pMenu, newItem);
		newItem = proposedItem;
		InvertItem(pMenu, proposedItem);
		pMenu->curItem = proposedItem;
//		inverted	= true;
		}


	inverted = (newItem != noMenuItemSelection);
	penDown = true;
	do
		{
		PenGetPoint (&x, &y, &penDown);
		if (RctPtInRectangle (x, y, &r))
			{
			proposedItem = MapPointToItem (x, y, pMenu);
			if (penDown)
				{
				if (newItem != proposedItem)
					{
					if (inverted)
						{
						InvertItem(pMenu, newItem);
						}
					newItem = proposedItem;
					InvertItem(pMenu, newItem);
					pMenu->curItem = proposedItem;
					inverted = true;
					}
				}
			}
		else     //moved out of bounds
			{
			if (inverted)
				{
				InvertItem(pMenu, newItem);
				inverted = false;
				}
			newItem = noMenuSelection;


			// if the pen drags above the menu to the window bar
			// then exit this loop and pass the pen to the menu bar
			// event handler.  To do this we pass the batton by
			// switching the active window to the pulldown's window
			// and we add a doctored event signaling a penDownEvent
			// within the pulldown menu.
			if (y < -1)
				{
				newEvent.penDown = true;
				newEvent.screenX = x;
				newEvent.screenY = y;
				newEvent.eType = penDownEvent;
				EvtAddEventToQueue (&newEvent);
				WinSetDrawWindow (WinGetWindowHandle(pMenu->barWin));
				WinSetActiveWindow (WinGetWindowHandle(pMenu->barWin));
				pMenu->curItem = noMenuItemSelection;
				return true;
				}
			}
		} while (penDown);




	if (newItem == noMenuItemSelection)
		{
		ErasePulldownMenu(pMenu, false);
		pMenu->curMenu = noMenuSelection;
		pMenu->curItem = noMenuItemSelection;
		return true;
		}
	else if (newItem == separatorItemSelection)
		return true;


	pMenu->curItem = newItem;
	newEvent.data.menu.itemID = thisMenu->items[newItem].id;
	newEvent.eType = menuEvent;
	
	// <DemoChange> If this is a demo device, display alert
	#if	USER_MODE == USER_MODE_DEMO
		SndPlaySystemSound(sndWarning);
	#else
		EvtAddEventToQueue (&newEvent);
	#endif

	MenuEraseMenu(pMenu, false);
	return true;
	}


/***********************************************************************
 *
 * FUNCTION:    MenuBarHandleEvent
 *
 * DESCRIPTION: Handles events in the menu bar.  This routine
 *              handles penDownEvents.
 *
 *              When this routine receives a penDownEvents it polls
 *              if the pen position.  If the pen is on a menu title
 *					 that menu title becomes the inverted title.  In
 *					 addition the pulldown menu associated with the
 *					 inverted title is drawn.  If the pen descends into
 *					 the pulldown menu a penDownEvent is made and passed
 *					 to the PulldownEventHandler via the EventQueue.  If
 *					 pen travels to where there isn't a menu title (the
 *					 far left and far right of the menu bar or outside of
 *					 the bar) no menu title is shown inverted.  If the pen
 *					 is released nothing is done.
 *
 *
 *
 * PARAMETERS:	 pMenu	  - pointer to Menu Bar object (MenuBarType)
 *              pEvent    - pointer to an EventType structure.
 *              pError    - pointer to returned error code
 *
 * RETURNED:	true if the event was handle or false if it was not.
 *             pError     - error code.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/23/94	Initial Revision
 *
 ***********************************************************************/

static Boolean MenuBarHandleEvent
  (MenuBarPtr pMenu, EventPtr pEvent, WordPtr pError)
	{
	EventType	newEvent;
	Boolean		penDown;
	Boolean		inverted;
	Boolean		penUpInTitleRemovesPulldown;	// true only for the original menu
	short			x, y;
	short       newTitle, proposedTitle;
	RectangleType	r;
	MenuPullDownPtr thisMenu;



	r.topLeft.x = 0;
	r.topLeft.y = 0;
	WinGetWindowExtent(&r.extent.x, &r.extent.y);


	// The first point must be in the window or else the window wouldn't
	// be given the point.
	newTitle = pMenu->curMenu;
	inverted = (newTitle != noMenuSelection);
	penUpInTitleRemovesPulldown = inverted;
	proposedTitle = MapPointToTitle (pEvent->screenX, pEvent->screenY, pMenu);
	if (newTitle != proposedTitle)
		{
		newTitle = proposedTitle;
		ErasePulldownMenu(pMenu, false);
		if (proposedTitle != noMenuSelection)
			{
			InvertTitle(pMenu, proposedTitle);
			inverted	= true;
			}
		else
		inverted	= false;
		penUpInTitleRemovesPulldown = false;
		pMenu->curMenu = proposedTitle;
		pMenu->curItem = noMenuItemSelection;
		DrawMenuPulldown (pMenu);
		WinSetDrawWindow (WinGetWindowHandle(pMenu->barWin));
		WinSetActiveWindow (WinGetWindowHandle(pMenu->barWin));
		}


	penDown		= true;
	do
		{
		PenGetPoint (&x, &y, &penDown);
		if (*pError) return (false);

		// ignore the out of bounds
		proposedTitle = MapPointToTitle (x, 1, pMenu);

		if (RctPtInRectangle (x, y, &r))
			{
			if (penDown)
				{
				if (newTitle != proposedTitle)
					{
					if (inverted)
						{
						ErasePulldownMenu(pMenu, false);
						}
					newTitle = proposedTitle;
					pMenu->curMenu = proposedTitle;
					pMenu->curItem = noMenuItemSelection;
					penUpInTitleRemovesPulldown = false;
					if (newTitle != noMenuSelection)
						{
						InvertTitle(pMenu, newTitle);
						DrawMenuPulldown (pMenu);
						inverted = true;
						}
					else
						inverted = false;
						
					WinSetDrawWindow (WinGetWindowHandle(pMenu->barWin));
					WinSetActiveWindow (WinGetWindowHandle(pMenu->barWin));
					}
				}
			else
				{
				if (inverted && penUpInTitleRemovesPulldown)
					{
	
					ErasePulldownMenu(pMenu, false);
					pMenu->curMenu = noMenuSelection;
					pMenu->curItem = noMenuItemSelection;
					newTitle = noMenuSelection;
					inverted = false;
					}
				}
			}
		else     //moved out of bounds
			{
			if (inverted)
				{

				// if the pen drags below the menu bar to the menu pulldown
				// then exit this loop and pass the pen to the menu pulldown
				// event handler.  To do this we pass the batton by
				// switching the active window to the pulldown's window
				// and we add a doctored event signaling a penDownEvent
				// within the pulldown menu.
				if (proposedTitle == newTitle && y >= 12)
					{
					// point to the correct menu.
					thisMenu = GetPulldownMenu(pMenu);

					newEvent.penDown = true;
					newEvent.screenX = x;
					newEvent.screenY = y;
					newEvent.eType = penDownEvent;
					EvtAddEventToQueue (&newEvent);
					WinSetDrawWindow (WinGetWindowHandle(thisMenu->menuWin));
					WinSetActiveWindow (WinGetWindowHandle(thisMenu->menuWin));
					return true;
					}

				ErasePulldownMenu(pMenu, false);
				pMenu->curMenu = noMenuSelection;
				pMenu->curItem = noMenuItemSelection;
				newTitle = noMenuSelection;
				inverted = false;
				}
			}
		} while (penDown);



	if (newTitle == noMenuSelection &&
		pMenu->curMenu != noMenuSelection)
		{
		InvertTitle(pMenu, pMenu->curMenu);
//		return true;
		}


	return true;
	}

/***********************************************************************
 *
 * FUNCTION: 	 MenuInit
 *
 * DESCRIPTION: Load a menu bar and all its pulldowns from
 *              a resource file
 *
 * PARAMETERS:	 resourceId - resource id of a menu bar resource
 *
 * RETURNED:    pointer to the memory block containing the menu
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
MenuBarPtr MenuInit (const Word resourceId)
{
	return (ResLoadMenu (resourceId));
}


/***********************************************************************
 *
 * FUNCTION: 	 MenuDispose
 *
 * DESCRIPTION: This routine frees all memory allocated by a menu and
 *   the command status and restores their saved bits to the screen
 *
 * PARAMETERS:	 pMenu - pointer to menu object to dispose
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	3/31/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void MenuDispose (const MenuBarPtr pMenu)
{
	int i;
	RectangleType r;
	WinHandle curDrawWin;
	MenuPullDownPtr thisMenu;
	
	// If no menu, return doing nothing. This is necessary because some
	// 3rd party apps (XXXXXXXX in particular) call this routine with a 
	// nill menu pointer. <RM> 11/5/96
	if (!pMenu) return;
	
	// If the menu bar or pulldown menu is visible, erase them.
	if (pMenu->attr.visible)
		{
		curDrawWin = WinGetDrawWindow ();
		WinSetDrawWindow (WinGetDisplayWindow ());

		if ((pMenu->curMenu != noMenuSelection) && pMenu->menus)
			{
			thisMenu = GetPulldownMenu(pMenu);
			WinGetWindowFrameRect (WinGetWindowHandle(thisMenu->menuWin), &r);
			RctInsetRectangle (&r, -1);
			WinRestoreBits (thisMenu->bitsBehind, r.topLeft.x, r.topLeft.y);
			}
		
		WinGetWindowFrameRect (WinGetWindowHandle(pMenu->barWin), &r);
		WinRestoreBits (pMenu->bitsBehind, r.topLeft.x, r.topLeft.y);

		WinSetDrawWindow (curDrawWin);

		// Restore the state of the insertion point.
		InsPtEnable (pMenu->attr.insPtEnabled == true);
		}

	EraseCommandStatus (pMenu);

	for (i=0; i < pMenu->numMenus; i++)
		{
		if (pMenu->menus[i].menuWin)
			WinDeleteWindow (pMenu->menus[i].menuWin, false);
		}	
	if (pMenu->barWin)
		WinDeleteWindow (pMenu->barWin, false);
	
	MemPtrFree (pMenu);
}


/***********************************************************************
 *
 * FUNCTION: 	 MenuGetActiveMenu
 *
 * DESCRIPTION: This routine returns a pointer to the current menu.
 *
 * PARAMETERS:	 nothing
 *
 * RETURNED:    pointer to the active menu
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/8/95	Initial Revision
 *
 ***********************************************************************/
MenuBarPtr MenuGetActiveMenu (void)
{
	return (UICurrentMenu);
}


/***********************************************************************
 *
 * FUNCTION: 	 MenuSetActiveMenu
 *
 * DESCRIPTION: Set the current menu.
 *
 * PARAMETERS:	 pMenu - pointer to the memory block containing the menu
 *
 * RETURNED:    pointer to the menu that was active before the new menu
 *              was set
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/6/95	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
MenuBarPtr MenuSetActiveMenu (const MenuBarPtr pMenu)
{
	MenuBarPtr curMenu;
	
	curMenu = UICurrentMenu;
	UICurrentMenu = pMenu;
	UICurrentMenuRscID = 0;
	return (curMenu);
}


/***********************************************************************
 *
 * FUNCTION: 	 MenuSetActiveMenuRscID
 *
 * DESCRIPTION: Set the resource id of the current menu.  This routine 
 *              will not load the menu resource,  it will be loaded the
 *              first time it is needed.
 *
 * PARAMETERS:	 resourceId - resource id of a menu bar resource
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	9/22/96	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void MenuSetActiveMenuRscID (const Word resourceId)
{	
	UICurrentMenu = NULL;
	UICurrentMenuRscID = resourceId;
}


/***********************************************************************
 *
 * FUNCTION:    MenuDrawMenu
 *
 * DESCRIPTION: Draw the menu bar and any current menu pulldown.
 *
 * PARAMETERS:	 pMenu - pointer to menu object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/21/94	Initial Revision
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/
void MenuDrawMenu (const MenuBarPtr pMenu)
	{
	RectangleType	r, frame;
	short i;
	char *titleText;
	Word error;
	FontID currFont;

	pMenu->attr.visible = true;
	currFont = FntSetFont (menuFont);
	
	// Turn off the insertion point if it's on.
	if (InsPtEnabled ())
		{
		pMenu->attr.insPtEnabled = true;
		InsPtEnable (false);
		}
	else
		pMenu->attr.insPtEnabled = false;

	// If there isn't a window for the menu then make one and
	// save the bits behind it.
	if (pMenu->barWin == NULL)
		{
		// Set the bounds of the menu bar.
		r.topLeft.x = 1;
		r.topLeft.y = 1;
		WinGetDisplayExtent(&r.extent.x, &r.extent.y);
		r.extent.x -= 3;		// leave room for the two pixel shadow
		r.extent.y = FntLineHeight () + 1;

		pMenu->barWin = WinCreateWindow (&r, menuFrame, false, false, &error);
		// Save the bits behind the popup window.
		WinSetDrawWindow (WinGetDisplayWindow());
		WinGetWindowFrameRect (WinGetWindowHandle(pMenu->barWin), &frame);
		frame.extent.y++;
		pMenu->bitsBehind = WinSaveBits (&frame, &error);
		}


	// Erase the window's backgroud and draw the windows frame.
	WinEraseRectangle (&frame, 0);
	WinSetDrawWindow (WinGetWindowHandle(pMenu->barWin));
	WinDrawWindowFrame();


	// Draw all the menu titles
	for (i=0; i < pMenu->numMenus; i++)
		{
		titleText = pMenu->menus[i].title;
		WinDrawChars (titleText, StrLen(titleText),
			pMenu->menus[i].titleBounds.topLeft.x + menuTitleXOffset,
			pMenu->menus[i].titleBounds.topLeft.y);
		}

	if (pMenu->curMenu != noMenuSelection)
		InvertTitle (pMenu, pMenu->curMenu);

	WinEnableWindow (WinGetWindowHandle(pMenu->barWin));
	pMenu->savedActiveWin = WinGetActiveWindow ();
	WinSetActiveWindow (WinGetWindowHandle(pMenu->barWin));

	DrawMenuPulldown (pMenu);
	FntSetFont (currFont);

	}


/***********************************************************************
 *
 * FUNCTION:    MenuHandleEvent
 *
 * DESCRIPTION: Handle event in the specified menu.  This routine
 *              handles two type of events, penDownEvents and
 *              menuEnterEvent.
 *
 *              When this routine receives a penDownEvent it checks
 *              if the pen position is within the bounds of the
 *              menu object, if it is this routine tracks the pen
 *              until the pen comes up.  If the pen comes up
 *              within the bounds of the menu, a menuEnterEvent is
 *              added to the event queue, and the routine is exited.
 *
 *              When this routine receives a menuEnterEvent it
 *              checks that the menu id in the event record match
 *              the id of the menu specified, if there is a match
 *              this routne will create and display a popup window
 *              containing the menu's choices, and the routine is exited.
 *
 *              If a penDownEvent is received while the menu's popup
 *              window is displayed, and the the pen postion is outside the
 *              bounds of the popup window, the pulldown will be dismissed.
 *              If the pen postion is within the bounds of the window
 *              the this routne will track the pen until it comes up.
 *              If the pen comes up in the menu a menuExitEvent will be
 *              added to the event queue.
 *
 *
 * PARAMETERS:	 pMenu    - pointer to menu object
 *              event    - pointer to an EventType structure.
 *              error    - pointer to returned erro code
 *
 * RETURNED:	 true if the event was handle or false if it was not.
 *              error     - error code.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/28/94	Initial Revision
 *			roger	6/6/96	Cleaned up the way menus exit
 *			trev	08/11/97	made non modified passed variables constant
 *
 ***********************************************************************/

Boolean MenuHandleEvent (MenuBarPtr pMenu, const EventPtr event, 
	const WordPtr error)
	{
	WinHandle curWin;
	Boolean result;
	FontID currFont;
	CharPtr stringP;


	*error = 0;

	// zzz - the menu parameter to this routine should be removed,  its nolonger 
	// used.
	if (! pMenu)
		pMenu = UICurrentMenu;
	
	// Verify that the menu is valid.  Some older apps still don't pass 
	// zero for pMenu and also mismanaged the pointer.  Catch them.
#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
	if (pMenu != NULL)
      MemPtrSize(pMenu);
#endif
	
	
	if (! pMenu)
		{
		if (! UICurrentMenuRscID)
			return (false);

		// Load the menu if the key event is a menu key (sent when the 
		// menu button is pressed) or a command key (sent when the 
		// menu command glyph is written).
		if ( (event->eType == keyDownEvent) &&
			  (event->data.keyDown.chr == menuChr || 
			   event->data.keyDown.chr == commandChr))
			{
			UICurrentMenu = MenuInit (UICurrentMenuRscID);
			pMenu = UICurrentMenu;
			}
		}
		
	if (! pMenu)
		return (false);


	if (event->eType == penDownEvent)
		{
		if (pMenu->attr.visible)
			{
			curWin = WinGetActiveWindow();
			currFont = FntSetFont (menuFont);
	
			if (pMenu->barWin == curWin)
				{
				result = MenuBarHandleEvent(pMenu, event, error);
				}
			else if (GetPulldownMenu(pMenu)->menuWin == curWin)
				{
				result = MenuPulldownHandleEvent(pMenu, event);
				}
			else
				{
				MenuEraseMenu (pMenu, true);
				EraseCommandStatus (pMenu);
				result = true;
				}
	
			FntSetFont (currFont);
			return result;
			}
		else
			{
			pMenu->attr.commandPending = false;
			EraseCommandStatus (pMenu);
			return (false);
			}
		}
		
	else if (event->eType == keyDownEvent)
		{
		if (event->data.keyDown.chr == menuChr)
			{
			if (! pMenu->attr.visible)
				MenuDrawMenu (pMenu);
			else
				MenuEraseMenu (pMenu, true);				
			return (true);
			}

		if (pMenu->attr.visible)
			{
			MenuEraseMenu (pMenu, true);				
			return (false);		
			}	

		else if (event->data.keyDown.chr == commandChr)
			{
			pMenu->attr.commandPending = true;
			stringP = MemHandleLock(DmGetResource (strRsc, menuCommandStrID));
			DisplayCommandStatus (pMenu, stringP, commandPendingTimeout);
			MemPtrUnlock(stringP);
			return (true);
			}

		else if (pMenu->attr.commandPending)
			{
			pMenu->attr.commandPending = false;
			EraseCommandStatus (pMenu);
			MenuEraseMenu (pMenu, false);
			result = SendKeyCommand (pMenu, event->data.keyDown.chr);
			return (true);			
			}
		}
		
	else if (event->eType == nilEvent)
		{
		if (pMenu->attr.commandPending)
			{
			if (TimGetTicks () - pMenu->commandTick >= commandPendingTimeout)
				{
				EraseCommandStatus (pMenu);
				pMenu->attr.commandPending = false;
				}
			}
		else if (pMenu->bitsBehindStatus) 
			{
			if (TimGetTicks () - pMenu->commandTick >= commandTimeout)
				EraseCommandStatus (pMenu);	
			}
		return (false);
		}

	return (false);
	}


