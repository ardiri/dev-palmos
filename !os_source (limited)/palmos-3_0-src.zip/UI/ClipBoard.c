/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     clipBrd.c
 * AUTHOR:	 Art Lamb: December 14, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contains the clipboard routines.
 *
 **********************************************************************/

#include <Pilot.h>


/***********************************************************************
 *
 * FUNCTION:    ClipboardAddItem
 *
 * DESCRIPTION: Add the item passed to the clipboard specified.  The 
 *              format parameter determines which which clipboard 
 *              (text, ink, etc) the item is added to.
 *
 * PARAMETERS:  format	text, ink, bitmap, etc
 *              ptr		pointer to the item to place on the clipboard
 *              length  size of the the item to place on the clipboard
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
void ClipboardAddItem (const ClipboardFormatType format, const VoidPtr ptr, 
	Word length)
{
	VoidHand itemH;
	VoidPtr itemP;

	ErrFatalDisplayIf( (format >= numClipboardForamts), 
		"Invalid clipboard format");

	// If the clipboard already contains a item, free it.
	if (Clipboard[format].item)
		MemHandleFree (Clipboard[format].item);

	if (ptr && length)
		{
		itemH = MemHandleNew (length);
		itemP = MemHandleLock (itemH);

		// Change the owner of the clipboard item such that it's owned by the 
		// system,  so that it will not be freed when the current application
		// terminates.
		MemPtrSetOwner (itemP, 0);

		MemMove (itemP, ptr, length);
		MemPtrUnlock (itemP);
		}
	else
		{
		itemH = NULL;
		length = 0;
		}	

	Clipboard[format].item = itemH;
	Clipboard[format].length = length;
}


/***********************************************************************
 *
 * FUNCTION:    ClipboardGetItem
 *
 * DESCRIPTION: This routine returns a pointer to the contents of the
 *              specified clipboard and the length of the clipboard item.
 *
 * PARAMETERS:  format	text, ink, bitmap, etc
 *              length  pointer to the length of the clipboard item
 *
 * RETURNED:    Pointer to clipboard item
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	12/14/94		Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
VoidHand ClipboardGetItem (const ClipboardFormatType format, 
	const WordPtr length)
{
	ErrFatalDisplayIf( (format >= numClipboardForamts), 
		"Invalid clipboard format");

	*length = Clipboard[format].length;
	return (Clipboard[format].item);
}








