/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Touchdown
 * FILE:     seltime.c
 * AUTHOR:	 Roger Flores: December 2, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain the selection time routines.
 *
 * NOTES:
 * It might be worthwhile using the struct tm instead of HMSTime.
 *
 **********************************************************************/

#pragma pcrelstrings off

#include <Pilot.h>

/***********************************************************************
 *
 *	Internal Constants
 *
 ***********************************************************************/
typedef enum {
	changingStartTime, changingEndTime, changingNoTime
	} ChangingTimeType;
	

/***********************************************************************
 *
 * FUNCTION:    TimeDifference
 *
 * DESCRIPTION: Subtract pTime2 from pTime1 and place the result in
 *					 pTimeDiff.
 *
 *					 Note that TimeType is now unsigned so this doesn't
 *					 work for negative times (which no longer exist!).
 *
 * PARAMETERS:  pTime1   - pointer to HMSTime
 *              pTime2   - pointer to HMSTime
 *              pTimeDiff- pointer to HMSTime
 *
 * RETURNED:	 pTimeDiff is set to pTime1 - pTime2.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *
 ***********************************************************************/

static void TimeDifference(TimePtr pTime1, TimePtr pTime2, TimePtr pTimeDiff)
	{
	pTimeDiff->hours = pTime1->hours - pTime2->hours;

	if (pTime1->minutes < pTime2->minutes)
		{
		pTimeDiff->minutes = pTime1->minutes + hoursInMinutes - pTime2->minutes;
		pTimeDiff->hours--;
		}
	else
		pTimeDiff->minutes = pTime1->minutes - pTime2->minutes;
	
	}



/***********************************************************************
 *
 * FUNCTION: 	 Hours12Array, private
 *
 * DESCRIPTION: Returns pointer to array of hours
 *
 *  PARAMETERS:  	void
 *
 *  RETURNS: BytePtr
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/2/95	Initial Revision
 *
 ***********************************************************************/
//static BytePtr		Hours12Array(void);
#define numSpace	"\200"

static BytePtr asm 	Hours12Array(void)
{
	LEA	@array, A0
	RTS
@array:
	DC.B	"12A", \
			numSpace "1", \
			numSpace "2", \
			numSpace "3", \
			numSpace "4", \
			numSpace "5", \
			numSpace "6", \
			numSpace "7", \
			numSpace "8", \
			numSpace "9", \
			"10",         \
			"11",         \
			"12P",        \
			numSpace "1", \
			numSpace "2", \
			numSpace "3", \
			numSpace "4", \
			numSpace "5", \
			numSpace "6", \
			numSpace "7", \
			numSpace "8", \
			numSpace "9", \
			"10",         \
			"11"
}


/***********************************************************************
 *
 * FUNCTION: 	 Hours24Array, private
 *
 * DESCRIPTION: 	Returns pointer to array of hours
 *
 *  PARAMETERS:  	void
 *
 *  RETURNS: BytePtr
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/2/95	Initial Revision
 *
 ***********************************************************************/
static BytePtr asm 	Hours24Array(void)
{
	LEA	@array, A0
	RTS
@array:
	DC.B	numSpace "0", \
			numSpace "1", \
			numSpace "2", \
			numSpace "3", \
			numSpace "4", \
			numSpace "5", \
			numSpace "6", \
			numSpace "7", \
			numSpace "8", \
			numSpace "9", \
			"10",         \
			"11",         \
			"12",         \
			"13",         \
			"14",         \
			"15",         \
			"16",         \
			"17",         \
			"18",         \
			"19",         \
			"20",         \
			"21",         \
			"22",         \
			"23"
}


/***********************************************************************
 *
 * FUNCTION:    Translate12HourTime
 *
 * DESCRIPTION: This routine handles key events in the Date Picker.  
 *              Key events are translated into times.
 *
 * PARAMETERS:  chr         - character written
 *              firstHour   - first valid hour
 *              timeStr     - passed: previously written character
 *                            returned: written character, including char passed
 *					 time			 - passed: previously translated time
 *                            returned: the translated time
 *
 * RETURNED:	 true if sucessful
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/2/96	Initial Revision
 *
 ***********************************************************************/
static Boolean Translate12HourTime (Char chr, Int firstHour, 
	CharPtr timeStr, TimePtr time)
	{
	Word i;
	Word len;
	Byte num;
	Byte hours, minutes;
	Boolean accept = false;
	Boolean am = false;
	Boolean pm = false;
	
	
	len = StrLen (timeStr);
	
	// Was the last character accepted an AM or PM character.
	if (len && (timeStr[len-1] < '0' || timeStr[len-1] > '9'))
		;
	
	// Was a digit written?
	else if (chr >= '0' && chr <= '9')
		{
		// The first character can be 0 - 9.
		if (len == 0)
			accept = true;

		// The second character can be:
		//		0 - 9  if the first character is a 0.
		//		0 - 6  if the first character is a 1.
		//		0 - 6  if the first character is greater than 1 (first minute 
		//           digit).
		else if (len == 1 && (
						(*timeStr == '0' || chr < '6')))
			accept = true;

		// The third character can be:
		//		0 - 6   if the first character is 0 (first minute digit).
		//		0 - 6   if the first character is 1 and the second character is 
		//            less then or equal to 2 (first minute digit).
		//		0 or 5  if the first character is greater than 1 (second munute digit). 
		else if (len == 2 && (
						(*timeStr == '0' && chr < '6') ||
						(*timeStr == '1' && timeStr[1] <= '2' && chr < '6') ||
						(chr == '0' || chr == '5')))
			accept = true;

		// The forth character can be:
		//		0 or 5  if the if the first character is 0 (second minute digit).
		//		0 or 5  if the first character is 1 and the second character is 
		//            less then or equal to 2 (second minute digit).
		else if (len == 3 && 
					(chr == '0' || chr == '5') && 
					(timeStr[0] == '0' || (timeStr[0] == '1' && timeStr[1] <= '2')))
			accept = true;
		}
			
	// Was the AM character written?
	else if (len && (chr == 'a' || chr == 'A'))
		{
		accept = true;
		am = true;
		}

	// Was the PM character written?
	else if ( len && (chr == 'p' || chr == 'P'))
		{
		accept = true;
		pm = true;
		}

	
	// Add the character passed to the time string if it is valid, 
	// otherwise exit.
	if (accept)
		{
		timeStr[len++] = chr;
		timeStr[len] = 0;
		}
	else
		return (false);



	// Translate the written character into a time.
	for (i = 0; i < len; i++)
		{
		// Have we reached the end of the numeric characters?
		if (! (timeStr[i] >= '0' && timeStr[i] <= '9'))
			break;

		num = timeStr[i] - '0';
		
		// The first characters is always an hours digit.
		if (i == 0)
			{
			hours = num;
			if (hours && hours < firstHour)
				hours += 12;
			minutes = 0;
			}

		// The second characters may be the second hours digit or the
		// first minutes digit.
		else if (i == 1)
			{
			if (hours == 0)
				{
				hours = num;
				if (hours && hours < firstHour)
					hours += 12;
				}
			else if ((hours == 1 || hours == 13) && (num <= 2))
				{
				hours = 10 + num;
				if (hours && hours < firstHour)
					hours += 12;
				}
			else
				minutes = num * 10;
			}

		// The third characters is	may be the first or second minutes digit		
		else if (i == 2)
			{
			if ((hours > 9 && hours < 13) || hours > 21)
				minutes = num * 10;
			else if (*timeStr == '0')
				minutes = num * 10;
			else
				minutes += num;
			}
			
		// The forth characters is always the second minutes digit..
		else if (i == 3)
			minutes += num;
		}
		
	if (am && hours > 12)
		hours -= 12;
	
	if (pm && hours < 12)
		hours += 12;
		
	// Return the translated time.
	time->hours = hours;
	time->minutes = minutes;
	
	return (true);
	}


/***********************************************************************
 *
 * FUNCTION:    Translate24HourTime
 *
 * DESCRIPTION: This routine translated a series of character into a 
 *              24 hour times.
 *
 * PARAMETERS:  chr         - character written
 *              firstHour   - first valid hour
 *              timeStr     - passed: previously written character
 *                            returned: written character, including char passed
 *					 time			 - passed: previously translated time
 *                            returned: the translated time
 *
 * RETURNED:	 true if sucessful
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/2/96	Initial Revision
 *
 ***********************************************************************/
static Boolean Translate24HourTime (Char chr, Int firstHour, 
	CharPtr timeStr, TimePtr time)
	{
	Word i;
	Word len;
	Byte num;
	Byte hours, minutes;
	Boolean accept = false;
	
	
	len = StrLen (timeStr);
	
	// Was a digit written?
	if (chr >= '0' && chr <= '9')
		{
		// The first character can be 0 - 9.
		if (len == 0)
			accept = true;

		// The second character can be:
		//		0 - 9  if the first character is a 0.
		//		0 - 9  if the first character is a 1.
		//		0 - 6  if the first character is greater than 1 (first minute 
		//           	digit).
		else if (len == 1 && ((*timeStr <= '1' || chr < '6')))
			accept = true;

		// The third character can be:
		//		0 - 6   if the first two character are between 00 - 23 (first 
		//            		minute digit).
		//		0 or 5  if the first character is greater than 2 (second munute digit). 
		else if (len == 2 && (
						(*timeStr < '2' && chr < '6') ||
						(*timeStr == '2' && timeStr[1] < '4' && chr < '6') ||
						(chr == '0' || chr == '5')))
			accept = true;

		// The forth character can be:
		//		0 or 5  if the first two character are between 00 - 23
		//						(second minute digit).
		else if (len == 3 && 
					(chr == '0' || chr == '5') && 
					(timeStr[0] < '2' || (timeStr[0] == '2' && timeStr[1] < '4')))
			accept = true;
		}
			

	
	// Add the character passed to the time string if it is valid, 
	// otherwise exit.
	if (accept)
		{
		timeStr[len++] = chr;
		timeStr[len] = 0;
		}
	else
		return (false);



	// Translate the written character into a time.
	for (i = 0; i < len; i++)
		{
		num = timeStr[i] - '0';
		
		// The first characters is always an hours digit.
		if (i == 0)
			{
			hours = num;
			minutes = 0;
			}

		// The second characters may be the second hours digit or the
		// first minutes digit.
		else if (i == 1)
			{
			if (hours == 0)
				{
				hours = num;
				}
			else if (hours < 2 || (hours == 2 && (num < 4)))
				{
				hours = (hours * 10) + num;
				}
			else
				minutes = num * 10;
			}

		// The third characters is	may be the first or second minutes digit		
		else if (i == 2)
			{
			if ((hours > 9) || (*timeStr == '0'))
				minutes = num * 10;
			else
				minutes += num;
			}
			
		// The forth characters is always the second minutes digit..
		else if (i == 3)
			minutes += num;
		}
		
		
	// Return the translated time.
	time->hours = hours;
	time->minutes = minutes;
	
	return (true);
	}


/***********************************************************************
 *
 * FUNCTION:    TranslateTime
 *
 * DESCRIPTION: This routine translated a series of character into a 
 *              times.
 *
 * PARAMETERS:  timeFormat  - time format
 *              chr         - character written
 *              firstHour   - first valid hour
 *              timeStr     - passed: previously written character
 *                            returned: written character, including char passed
 *					 time			 - passed: previously translated time
 *                            returned: the translated time
 *
 * RETURNED:	 true if sucessful
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/2/96	Initial Revision
 *
 ***********************************************************************/
static Boolean TranslateTime (TimeFormatType timeFormat, Char chr, 
	Int firstHour, CharPtr timeStr, TimePtr time)
{
	if (timeFormat == tfColon24h 	|| 
		 timeFormat == tfDot24h 	||
		 timeFormat == tfHours24h)
		return (Translate24HourTime (chr, firstHour, timeStr, time));
	else
		return (Translate12HourTime (chr, firstHour, timeStr, time));
}


/***********************************************************************
 *
 * FUNCTION:    SetTimeTriggers
 *
 * DESCRIPTION: This routine sets the text label of the start time and
 *              end time triggers.
 *
 * PARAMETERS:  startTime	    - pointer to HMSTime
 *              endTime        - pointer to HMSTime
 *              startTimeText  - buffer that holds start time string
 *              emdTimeText    - buffer that holds end time string
 *              timeFormat     - time format
 *              untimed  	    - true if there isn't a time.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/4/96	Initial Revision
 *
 ***********************************************************************/
static void SetTimeTriggers (TimeType startTime, TimeType endTime,
		CharPtr startTimeText, CharPtr endTimeText, 
		TimeFormatType timeFormat, Boolean untimed)
	{

	FormPtr		frm;
	ControlPtr 	startTimeCtl, endTimeCtl;

	frm = FrmGetActiveForm ();
	startTimeCtl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorStartTimeButton));
	endTimeCtl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorEndTimeButton));

	if (! untimed)
		{
		TimeToAscii (startTime.hours, startTime.minutes, timeFormat, startTimeText);
		TimeToAscii (endTime.hours, endTime.minutes, timeFormat, endTimeText);
		}
	else
		{
		startTimeText[0] = '\0';
		endTimeText[0] = '\0';
		}
		
	CtlSetLabel (startTimeCtl, startTimeText);
	CtlSetLabel(endTimeCtl, endTimeText);
	}


/***********************************************************************
 *
 * FUNCTION:    AdjustTimes
 *
 * DESCRIPTION: This routine adjusts the start or end times.  It's
 *              called when ever the start or end time are changed. If
 *              the start time has been changed then the end time is adjust
 *              such that the elasped time is maintained.  If the end
 *              time has been changed then the start time is adjusted so
 *              that it will not be before the end time.
 *
 * PARAMETERS:  startTime	    - pointer to HMSTime
 *              endTime        - pointer to HMSTime
 *              startTimeText  - buffer that holds start time string
 *              emdTimeText    - buffer that holds end time string
 *              timeFormat     - time format
 *              untimed  	    - true if there isn't a time.
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/4/96	Initial Revision
 *
 ***********************************************************************/
static Boolean AdjustTimes (TimePtr startTime, TimePtr endTime, 
		TimePtr timeDiff, ChangingTimeType changingTime)
	{
	Boolean changed = false;

	if (changingTime == changingStartTime)
		{
		// The start time has changed so update the end time.
		endTime->minutes = startTime->minutes + timeDiff->minutes;
		endTime->hours = startTime->hours + timeDiff->hours;

		// If there are 60 or more minutes wrap to the next hour
		if (endTime->minutes >= hoursInMinutes)
			{
			endTime->minutes -= hoursInMinutes;
			endTime->hours++;
			}

		// Don't allow the end time past 11:55 PM.
		if (endTime->hours >= 24)
			{
			endTime->minutes = 55;
			endTime->hours = 23;
			}
		changed = true;
		}

	else if (changingTime == changingEndTime)
		{
		// The end time has changed so make sure it's valid
		// and calculate the new difference.
		TimeDifference (endTime, startTime, timeDiff);
		if (endTime->hours < startTime->hours ||
			(endTime->hours == startTime->hours && 
			endTime->minutes < startTime->minutes))
			{
			timeDiff->hours = 0;
			timeDiff->minutes = 0;
			endTime->hours = startTime->hours;
			endTime->minutes = startTime->minutes;	
			changed = true;
			}
		}
	return (changed);
	}


/***********************************************************************
 *
 * FUNCTION:    SelectTime
 *
 * DESCRIPTION: Display a form showing a start and end time.
 *					 Allow the user to change the time and then
 *              return them.
 *					 pTimeDiff.
 *
 * PARAMETERS:  pStartTime	- pointer to HMSTime
 *              pEndTime   - pointer to HMSTime
 *              untimed  	- true if there isn't a time.
 *              title	   - string containing the title
 *              startOfDay - first hour initially visible
 *
 * RETURNED:	 True if the time was changed by the user.
 * 				 The first three parameters may change.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	12/2/94	Initial Revision
 *			trev	08/12/97	made non modified passed variables constant
 *
 ***********************************************************************/
Boolean SelectTime (const TimePtr startTimeP, const TimePtr endTimeP, 
	const Boolean untimed, const CharPtr title, SWord startOfDay)
	{
	Int				firstHour;
	Char 				startTimeText [timeStringLength];
	Char 				endTimeText [timeStringLength];
	Char				timeChars [timeStringLength];
	TimePtr			timeP;
	FormPtr 			originalForm, frm;
	ListPtr 			hoursLst, minutesLst;
	ControlPtr 		startTimeCtl, endTimeCtl;
	EventType 		event;
	Boolean 			confirmed = false;
	VoidHand 		hoursItems;
	TimeType 		startTime, endTime, timeDiff;
	TimeFormatType timeFormat;
	ChangingTimeType	changingTime;


	// Get the time format from the system preerances;
	timeFormat = (TimeFormatType)PrefGetPreference(prefTimeFormat);


	// Because this routine only deals with minutes in five minute
	// intervals we convert the proposed times from those passed.
	startTime.hours = startTimeP->hours;
	startTime.minutes = startTimeP->minutes;
	endTime.hours = endTimeP->hours;
	endTime.minutes = endTimeP->minutes;
	TimeDifference (&endTime, &startTime, &timeDiff);
	
	// Clear the buffer that holds written characters.
	*timeChars = 0;

	startOfDay = min (startOfDay, 12);

	originalForm = FrmGetActiveForm();
	frm = (FormPtr) FrmInitForm (TimeSelectorForm);
	FrmSetActiveForm (frm);

	hoursLst = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorHourList));
	minutesLst = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorMinuteList));
	startTimeCtl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorStartTimeButton));
	endTimeCtl = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, TimeSelectorEndTimeButton));


	// Set list to use either 12 or 24 hour time
	hoursItems = SysFormPointerArrayToStrings (
		((timeFormat == tfColon24h) || (timeFormat == tfDot24h)) ? 
			(CharPtr) Hours24Array() : (CharPtr) Hours12Array(), 24);
 
 	LstSetListChoices (hoursLst, MemHandleLock(hoursItems), 24);
	LstSetTopItem (hoursLst, 8);
	LstMakeItemVisible (hoursLst, startTime.hours);


	if (! untimed)
		{
		LstSetSelection (hoursLst, startTime.hours);
		LstSetSelection (minutesLst, startTime.minutes / 5);

		CtlSetValue (startTimeCtl, true);
		changingTime = changingStartTime;
		}
	else
		{
		// The hour list is dynamically created and doesn't have a selection
		LstSetSelection (minutesLst, noListSelection);

		changingTime = changingNoTime;
		}


	// Set the start and end time buttons to the current times or blank them
	// if No Time is selected.
	SetTimeTriggers (startTime, endTime, startTimeText, endTimeText, 
		timeFormat, untimed);
		

	FrmSetTitle (frm, title);
	FrmDrawForm (frm);
	
	
	while (true)
		{
		EvtGetEvent (&event, evtWaitForever);

		if (SysHandleEvent (&event))
			continue;
			
		if (event.eType == appStopEvent)
			{
			// Cancel the dialog and repost this event for the app
			EvtAddEventToQueue(&event);
			confirmed = false;
			break;
			}
			
		// Handle these before the form does to overide the default behavior
		if (changingTime == changingNoTime &&
			event.eType == lstEnterEvent && 
			event.data.lstEnter.listID == TimeSelectorMinuteList)
			{
			SndPlaySystemSound(sndError);
			continue;
			}

		FrmHandleEvent (frm, &event);


		// If the start or end time buttons are pressed then change
		// the time displayed in the lists.
		if (event.eType == ctlSelectEvent)
			{
			// "Ok" button pressed?
			if (event.data.ctlSelect.controlID == TimeSelectorOKButton)
				{
				confirmed = true;
				}

			// "Cancel" button pressed?
			else if (event.data.ctlSelect.controlID == TimeSelectorCancelButton)
				{
				break;
				}

			// Start time button pressed?
			else if (event.data.ctlSelect.controlID == TimeSelectorStartTimeButton)
				{
				if (changingTime != changingStartTime)
					{
					if (changingTime == changingNoTime)
						{
						SetTimeTriggers (startTime, endTime, startTimeText, 
							endTimeText, timeFormat, false);
						}

					CtlSetValue (endTimeCtl, false);
					LstSetSelection (hoursLst, startTime.hours);
					LstSetSelection (minutesLst, startTime.minutes / 5);
					changingTime = changingStartTime;
					}
				else
					CtlSetValue(startTimeCtl, true);
				}

			// End time button pressed?
			else if (event.data.ctlSelect.controlID == TimeSelectorEndTimeButton)
				{
				if (changingTime != changingEndTime)
					{
					if (changingTime == changingNoTime)
						{
						SetTimeTriggers (startTime, endTime, startTimeText, 
							endTimeText, timeFormat, false);
						}

					CtlSetValue(startTimeCtl, false);
					LstSetSelection (hoursLst, endTime.hours);
					LstSetSelection (minutesLst, endTime.minutes / 5);
					changingTime = changingEndTime;
					}
				else
					CtlSetValue(endTimeCtl, true);
				}

			// No time button pressed?
			else if (event.data.ctlSelect.controlID == TimeSelectorNoTimeButton)
				{
				if (changingTime != changingNoTime)
					{
					if (changingTime == changingStartTime)
						CtlSetValue(startTimeCtl, false);
					else
						CtlSetValue(endTimeCtl, false);
					SetTimeTriggers (startTime, endTime, startTimeText, 
						endTimeText, timeFormat, true);
					
					LstSetSelection (hoursLst, noListSelection);
					LstSetSelection (minutesLst, noListSelection);
					changingTime = changingNoTime;
					}
				}

			// Clear the buffer that holds written characters.
			*timeChars = 0;
			}


		// If either list is changed then get the new time.  If the
		// start time is changed then change the end time so that the
		// the time difference remains the same.  If the end time is
		// changed then make sure the end time isn't before the start
		// time.  Also calculate a new time difference.
		else if (event.eType == lstSelectEvent)
			{
         // First, get the info from the list which has changed.
			if (event.data.lstSelect.listID == TimeSelectorHourList)
				{
				if (changingTime == changingStartTime)
               startTime.hours = LstGetSelection (hoursLst);
           	else if (changingTime == changingEndTime)
               endTime.hours = LstGetSelection (hoursLst);
           	else if (changingTime == changingNoTime)
           		{
               startTime.hours = LstGetSelection (hoursLst);
					SetTimeTriggers (startTime, endTime, startTimeText, 
						endTimeText, timeFormat, false);
					CtlSetValue (endTimeCtl, false);
					LstSetSelection (minutesLst, startTime.minutes / 5);
					changingTime = changingStartTime;
					}
				}
         else if (event.data.lstSelect.listID == TimeSelectorMinuteList)
				{
				if (changingTime == changingStartTime)
               startTime.minutes = LstGetSelection (minutesLst) * 5;
           	else if (changingTime == changingEndTime)
					endTime.minutes = LstGetSelection (minutesLst) * 5;
           	else if (changingTime == changingNoTime)
           		{
               ErrNonFatalDisplayIf(true, "lstEnterEvent not being filtered.");
               }
				}


			if (AdjustTimes (&startTime, &endTime, &timeDiff, changingTime))
				{
				if (changingTime == changingStartTime)
					{
					TimeToAscii (startTime.hours, startTime.minutes, timeFormat, 
						startTimeText);
					CtlSetLabel (startTimeCtl, startTimeText);
					}
				else if (changingTime == changingEndTime)
					{
					LstSetSelection (hoursLst, startTime.hours);
					LstSetSelection (minutesLst, startTime.minutes / 5);
					}
				}
			TimeToAscii(endTime.hours, endTime.minutes, timeFormat, endTimeText);
			CtlSetLabel(endTimeCtl, endTimeText);


			// Clear the buffer that holds written characters.
			*timeChars = 0;
			}


		// Handle character written in the time picker.
		else if (event.eType == keyDownEvent)
			{
			if (changingTime == changingEndTime)
				{
				timeP = &endTime;
				firstHour = startTime.hours;
				}
			else
				{
				timeP = &startTime;
				firstHour = startOfDay;
				}
		
			// If a backspace character was written, change the time picker's
			// current setting to "no-time".
			if (event.data.keyDown.chr == backspaceChr)
				{
				*timeChars = 0;
				if (changingTime != changingNoTime)
					{
					if (changingTime == changingStartTime)
						CtlSetValue (startTimeCtl, false);
					else
						CtlSetValue (endTimeCtl, false);
					SetTimeTriggers (startTime, endTime, startTimeText, 
						endTimeText, timeFormat, true);
					LstSetSelection (hoursLst, noListSelection);
					LstSetSelection (minutesLst, noListSelection);
					changingTime = changingNoTime;
					}
				}

			// A linefeed character confirms the dialog box.
			else if (event.data.keyDown.chr == linefeedChr)
				{
				confirmed = true;
				}

			// If next-field character toggle between start time in end
			// time.
			else if (event.data.keyDown.chr == nextFieldChr)
				{
				*timeChars = 0;
				if (changingTime == changingStartTime)
					{
					CtlSetValue (startTimeCtl, false);
					CtlSetValue (endTimeCtl, true);
					changingTime = changingEndTime;
					}
				else
					{
					CtlSetValue (endTimeCtl, false);
					CtlSetValue (startTimeCtl, true);
					changingTime = changingStartTime;
					}
				}


			// If a valid time character was written, translate the written 
			// character into a time and update the time picker's UI.
			else if (TranslateTime (timeFormat, event.data.keyDown.chr, 
				firstHour, timeChars, timeP))
				{
				if (changingTime == changingNoTime)
					{
					changingTime = changingStartTime;
					CtlSetValue (startTimeCtl, true);
					}

				AdjustTimes (&startTime, &endTime, &timeDiff, changingTime);
				
				SetTimeTriggers (startTime, endTime, startTimeText, 
					endTimeText, timeFormat, false);

				LstSetSelection (hoursLst, timeP->hours);
				LstSetSelection (minutesLst, timeP->minutes / 5);
				}
			}

		// Has the dialog been confirmed.
		if (confirmed)
			{
			if (changingTime != changingNoTime)
				{
				*startTimeP = startTime;
				*endTimeP = endTime;
				}
			else
				{
				TimeToInt(*startTimeP) = noTime;
				TimeToInt(*endTimeP) = noTime;
				}
			break;
			}

		}

	FrmEraseForm (frm);
	FrmDeleteForm (frm);
	MemHandleFree (hoursItems);
	
	FrmSetActiveForm(originalForm);
	
	return (confirmed);
	}
