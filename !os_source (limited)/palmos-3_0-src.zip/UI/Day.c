/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     day.c
 * AUTHOR:	 Roger Flores: November 11, 1994
 *
 * DECLARER: UI
 *
 * DESCRIPTION:
 *	  This file contain routines to draw the month area.
 *
 **********************************************************************/

#include <Pilot.h>

#include <stdio.h>

#define noItemSelection		 -32  // -1 is the last day of the prior month
#define daysInWeek				7
#define linesInMonthPlusTitle	7

// These are placed in the beginning to avoid declaring them.

#define FirstDayInVisibleMonth(p) \
			(DayOfWeek(p->visibleMonth, 1, p->visibleYear))
			
			
#define FirstDayInSelectedMonth(p) \
			(DayOfWeek(pSelector->selected.month, 1, p->selected.year))



/***********************************************************************
 *
 * FUNCTION: 	 MapPointToItem
 *
 * DESCRIPTION: Return return the item at x, y.
 *
 * PARAMETERS:  x, y - coordinate
 *              r - the bounds of the item area (not the MTWTFSS area)
 *
 * RETURNED:	 item number (doesn't check for invalid bounds!)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/15/94	Initial Revision
 *
 ***********************************************************************/

static short MapPointToItem (short x, short y, RectanglePtr r)
	{
	short itemNumber;

	itemNumber = daysInWeek * (((y - r->topLeft.y) /
		(r->extent.y / linesInMonthPlusTitle)) - 1);
	itemNumber += ((x - r->topLeft.x) / (r->extent.x / daysInWeek));
	return itemNumber;
	}


/***********************************************************************
 *
 * FUNCTION: 	 InvertItem
 *
 * DESCRIPTION: Invert an item.  The top left item is 0 and the
 *              one below is 7.
 *
 * PARAMETERS:  pSelector     - pointer to control object to draw
 *              itemNumber    - item to invert
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/15/94	Initial Revision
 *
 ***********************************************************************/

static void InvertItem (DaySelectorPtr pSelector, short itemNumber)
{
	RectangleType r;
	short x, y;

	if (itemNumber == noItemSelection ||
		pSelector->selectDayBy == selectDayByMonth)
		return;

	x = itemNumber % daysInWeek;
	y = itemNumber / daysInWeek;
	if (pSelector->selectDayBy == selectDayByDay)
		{
		r.extent.x = pSelector->bounds.extent.x / daysInWeek;
		r.extent.y = pSelector->bounds.extent.y / linesInMonthPlusTitle;
		r.topLeft.x = pSelector->bounds.topLeft.x + x * r.extent.x;
		r.topLeft.y = pSelector->bounds.topLeft.y + (y + 1) * r.extent.y;
		}
	else if (pSelector->selectDayBy == selectDayByWeek)
		{
		r.extent.x = pSelector->bounds.extent.x;
		r.extent.y = pSelector->bounds.extent.y / linesInMonthPlusTitle;
		r.topLeft.x = pSelector->bounds.topLeft.x;
		r.topLeft.y = pSelector->bounds.topLeft.y + (y + 1) * r.extent.y;
		}
/*	else if (pSelector->selectDayBy == selectDayByMonth)
		{
		RctCopyRectangle(&pSelector->bounds, &r);
		
		// Don't include the day of week labels
		r.extent.y -= pSelector->bounds.extent.y / linesInMonthPlusTitle;
		r.topLeft.y += pSelector->bounds.extent.y / linesInMonthPlusTitle;
		}
*/	else 
		ErrDisplay("Bad selectDayBy");
		
	r.extent.y++;      // invert an extra row of pixels for visual evenness
	WinInvertRectangle (&r, 4);
}


/***********************************************************************
 *
 * FUNCTION: 	 MapDateToItem
 *
 * DESCRIPTION: Return return the item for the date.
 *
 * PARAMETERS:  pSelector	  - pointer to control object to draw
 *
 * RETURNED:	 item number (doesn't check for invalid dates!)
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/15/94	Initial Revision
 *			roger	10/4/95	Fixed to handle weekStartDay
 *
 ***********************************************************************/
static short MapDateToItem(DaySelectorPtr pSelector)
{
	SystemPreferencesType systemPreferences;
	UInt weekStartDayOffset;
	short wrappedDay;
	
	if (pSelector->visibleMonth == pSelector->selected.month &&
		 pSelector->visibleYear == pSelector->selected.year)
		{
		PrefGetPreferences(&systemPreferences);
		weekStartDayOffset = systemPreferences.weekStartDay;

		wrappedDay = FirstDayInSelectedMonth(pSelector) - weekStartDayOffset;
		if (wrappedDay < 0) wrappedDay += daysInWeek;			// wrap around
		return pSelector->selected.day - 1 + wrappedDay;
		}
	else
		return noItemSelection;
}


/***********************************************************************
 *
 * FUNCTION: 	 DayDrawControl
 *
 * DESCRIPTION: Draw a control object on screen.
 *					 The control is drawn only if it is usable.
 *
 * PARAMETERS:  pSelector     - pointer to control object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
extern void DayDrawDaySelector (const DaySelectorPtr pSelector)
	{
	short				drawX, drawY;
	short				cellWidth, cellHeight;
	short				charWidth;
	short				lastDay;
	short				textOffset;
	FontID			currFont;
	Handle			dayOfWeekStringsH;
	CharPtr			dayOfWeekText;	// array of day of week letters
	Char				dayOfWeekLetter;
	Char				dayInAscii[3];
	Char				bracketChar;
	unsigned char	i;
	short				x;
	DateTimeType	today;
	SystemPreferencesType systemPreferences;
	UInt weekStartDayOffset;
	short				wrappedDay;


	// "Sun Mon Tue Wed Thu Fri Sat "
	dayOfWeekStringsH = DmGetResource (strRsc, daysOfWeekStrID);
	dayOfWeekText = MemHandleLock(dayOfWeekStringsH);
	PrefGetPreferences(&systemPreferences);
	weekStartDayOffset = systemPreferences.weekStartDay;

	cellWidth = pSelector->bounds.extent.x / daysInWeek;
	cellHeight = pSelector->bounds.extent.y / linesInMonthPlusTitle;

	currFont = FntSetFont (boldFont);
	charWidth = FntCharWidth('0');
	textOffset = (cellWidth - 2 * charWidth) / 2;


	// Draw the days of the week labels right justified to the number columns
	for (i=0; i < daysInWeek; i++)
		{
		dayOfWeekLetter = dayOfWeekText[((i + weekStartDayOffset) % daysInWeek) * 4];
		WinDrawChars (&dayOfWeekLetter, 1, 
			pSelector->bounds.topLeft.x + cellWidth * (i + 1) - textOffset -
			FntCharWidth(dayOfWeekLetter), pSelector->bounds.topLeft.y);
		}
	MemHandleUnlock(dayOfWeekStringsH);


	// Draw the days of the month
	FntSetFont (stdFont);
	charWidth = FntCharWidth('0');
	textOffset = (cellWidth - 2 * charWidth) / 2;
	
	x = FirstDayInVisibleMonth(pSelector) - weekStartDayOffset;
	if (x < 0) x += daysInWeek;			// wrap around
	
	drawX = pSelector->bounds.topLeft.x + x * cellWidth - textOffset;
	drawY = pSelector->bounds.topLeft.y + cellHeight;
	lastDay = DaysInMonth(pSelector->visibleMonth, pSelector->visibleYear);
	for (i=1; i <= lastDay; i++, x++)
		{
		if (x == daysInWeek)
			{
			drawX = pSelector->bounds.topLeft.x - textOffset;
			drawY += cellHeight;
			x = 0;
			}
		drawX += cellWidth;
		StrIToA(dayInAscii, i);
		WinDrawChars(dayInAscii, (i < 10) ? 1 : 2,
					drawX - ((i < 10) ? charWidth : 2 * charWidth), drawY);
		}


	// Display a rectangle around today's day if visible
	TimSecondsToDateTime(TimGetSeconds(), &today);
	if (pSelector->visibleMonth == today.month &&
		 pSelector->visibleYear == today.year)
		{
		// i keeps track of the unshown days before this month.
		wrappedDay = FirstDayInVisibleMonth(pSelector) - weekStartDayOffset;
		if (wrappedDay < 0) wrappedDay += daysInWeek;			// wrap around
		today.day = today.day - 1 + wrappedDay;
		drawX = pSelector->bounds.topLeft.x +
			(today.day % daysInWeek) * cellWidth + 1;
		drawY = pSelector->bounds.topLeft.y +
			((today.day / daysInWeek) + 1) * cellHeight;
		bracketChar = '(';
		WinDrawChars(&bracketChar, 1, drawX, drawY);
		bracketChar = ')';
		WinDrawChars(&bracketChar, 1, drawX + cellWidth - 5, drawY);
		}


	// Invert the selected day if it's visible
	if (pSelector->selectDayBy != selectDayByMonth)
		InvertItem(pSelector, MapDateToItem(pSelector));

	FntSetFont (currFont);
	}


/***********************************************************************
 *
 * FUNCTION: 	 DayDrawDays
 *
 * DESCRIPTION: Draw only the days.  Used when the year or month
 *					 changes.  This avoids flicker from redrawing week titles.
 *
 * PARAMETERS:  pSelector     - pointer to control object to draw
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	11/17/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/
extern void DayDrawDays (const DaySelectorPtr pSelector)
{
	RectangleType	r, saveClip;


	if (!pSelector->visible)
		return;

	RctCopyRectangle (&(pSelector->bounds), &r);
	r.topLeft.y += r.extent.y / linesInMonthPlusTitle;
	// erase one extra row of pixels for the extra inverted item row
	r.extent.y -= r.extent.y / linesInMonthPlusTitle - 1;


	// Clip the weekday titles
	WinGetClip (&saveClip);
	WinClipRectangle (&r);
	WinSetClip (&r);
	WinEraseRectangle (&r, 0);
	DayDrawDaySelector (pSelector);
	WinSetClip (&saveClip);
}

/***********************************************************************
 *
 * FUNCTION: 	 AdjustSelectionIfSelectByWeek
 *
 * DESCRIPTION: If selectDayByWeek mode then selecting another day
 * is really selecting that week and the spec wants the same day of
 * the week to be the day picked instead of what the user selected.
 *
 * PARAMETERS:  pSelector - day selector info
 *					 currentSelection	- the currently selected day
 *					 proposedSelection - the proposed selection
 *
 * RETURNED:	 nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	4/26/96	Initial Revision
 *
 ***********************************************************************/
static void AdjustSelectionIfSelectByWeek(DaySelectorPtr pSelector, 
	SWord currentSelection, SWord *proposedSelection)
{
	if (pSelector->selectDayBy == selectDayByWeek)
		{
		*proposedSelection -= *proposedSelection % daysInWeek;
		*proposedSelection += currentSelection % daysInWeek;
		}
}


/***********************************************************************
 *
 * FUNCTION:    DayHandleEvent
 *
 * DESCRIPTION: Handle event in the specified control.  This routine
 *              handles two type of events, penDownEvents and
 *              controlEnterEvent.
 *
 *              When this routine receives a penDownEvents it checks
 *              if the pen position is within the bounds of the
 *              control object, if it is a dayEnterEvent is
 *              added to the event queue and the routine exits.
 *
 *              When this routine receives a dayEnterEvent it
 *              checks that the control id in the event record match
 *              the id of the control specified, if they match
 *              this routine will track the pen until it comes up
 *              in the bounds in which case daySelectEvent is sent.
 *              If the pen exits the bounds a dayExitEvent is sent.
 *
 *
 * PARAMETERS:	 pSelector - pointer to control object (ControlType)
 *              pEvent    - pointer to an EventType structure.
 *              pError    - pointer to returned erro code
 *
 * RETURNED:	true if the event was handle or false if it was not.
 *             pError     - error code.
 *					posts a daySelectEvent with info on whether to use the date.
 *						a date is used if the user selects a day in the visible month.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	10/28/94	Initial Revision
 *			trm	08/07/97	made non modified passed variabls constant
 *
 ***********************************************************************/

Boolean DayHandleEvent
  (const DaySelectorPtr pSelector, const EventPtr pEvent)
	{
	EventType	newEvent;
	Boolean		penDown;
	Boolean		inverted;
	short			x, y;
	short       newSelection, proposedSelection;
	RectangleType	r;
	short       localFirstDayInMonth;
	short       localDaysInMonth;
	SystemPreferencesType systemPreferences;
	UInt 			weekStartDayOffset;
	UInt			dateInMonth;
	

	if (!pSelector->visible)
		return (false);

	if (pEvent->eType != penDownEvent)
		return false;

	PrefGetPreferences(&systemPreferences);
	weekStartDayOffset = systemPreferences.weekStartDay;

	localFirstDayInMonth = FirstDayInVisibleMonth(pSelector) - weekStartDayOffset;
	if (localFirstDayInMonth < 0) localFirstDayInMonth += daysInWeek;			// wrap around
	localDaysInMonth = DaysInMonth(pSelector->visibleMonth,
		pSelector->visibleYear);

	// Restrict the selection bounds.  The top should be moved down
	// to exclude selecting the day of week titles.  The bottom should
	// be moved up to the last week with a day in it.
	RctCopyRectangle (&(pSelector->bounds), &r);
	r.topLeft.y += r.extent.y / linesInMonthPlusTitle;
	r.extent.y = (r.extent.y / linesInMonthPlusTitle) *
		(((localFirstDayInMonth + localDaysInMonth - 1) / 7) + 1);


	if (RctPtInRectangle (pEvent->screenX, pEvent->screenY, &r))
		{
		newSelection = MapDateToItem(pSelector);
		proposedSelection = MapPointToItem (pEvent->screenX, pEvent->screenY,
														&pSelector->bounds);
		AdjustSelectionIfSelectByWeek(pSelector, newSelection, &proposedSelection);
		
		if (newSelection != proposedSelection)
			{
			InvertItem(pSelector, newSelection);
			newSelection = proposedSelection;
			InvertItem(pSelector, newSelection);
			}
		inverted	= true;
		}
	else
		return false;


	penDown		= true;

	do
		{
		PenGetPoint (&x, &y, &penDown);

		if (RctPtInRectangle (x, y, &r))
			{
			proposedSelection = MapPointToItem (x, y, &pSelector->bounds);
			AdjustSelectionIfSelectByWeek(pSelector, newSelection, &proposedSelection);
			
			if (penDown)
				{
				if (newSelection != proposedSelection)
					{
					if (inverted)
						InvertItem(pSelector, newSelection);
					newSelection = proposedSelection;
					InvertItem(pSelector, newSelection);
					inverted = true;
					}
				}
			}
		else     //moved out of bounds
			{
			if (inverted)
				{
				InvertItem(pSelector, newSelection);
				inverted = false;
				}
			newSelection = noItemSelection;
			}
		} while (penDown);


	newEvent.penDown = penDown;
	newEvent.screenX = x;
	newEvent.screenY = y;


	if (newSelection == noItemSelection)
		{
		InvertItem(pSelector, MapDateToItem(pSelector));
		return true;
		}

	// If we are selecting by week make sure that the newSelection is
	// the same day of the week as the current date.  We do this now before
	// the following code which handles the cases where the date is outside
	// of valid ranges for the month that year.
	if (pSelector->selectDayBy == selectDayByWeek)
		{
		newSelection = (newSelection / daysInWeek) * daysInWeek + 
			DayOfWeek (pSelector->selected.month, pSelector->selected.day, pSelector->selected.year);
		}


	pSelector->selected.month = pSelector->visibleMonth;
	pSelector->selected.year = pSelector->visibleYear;
	if ((unsigned) (newSelection - localFirstDayInMonth) >=
		 (unsigned) localDaysInMonth)
		{
		// Because the selection is outside of the visible month don't automatically
		// use the date selected.
		// Spec changed to automatically use the date.  Saves taps in more cases.
		newEvent.data.daySelect.useThisDate = true;
		
		if (pSelector->selectDayBy == selectDayByMonth)
			{
			dateInMonth = pSelector->selected.day;
			pSelector->selected.day = 1;
			TimAdjust(&pSelector->selected, (newSelection - localFirstDayInMonth) * daysInSeconds);
			
			// Now that the month and year are correctly wrapped to the preceding or following
			// month, set the day to the one selected before.  Handle days past the end
			// of the month.
			localDaysInMonth = DaysInMonth(pSelector->selected.month, pSelector->selected.year);
			if (dateInMonth < localDaysInMonth)
				pSelector->selected.day = dateInMonth;
			else
				pSelector->selected.day = localDaysInMonth;
			}
		else
			{
			pSelector->selected.day = 1;
			TimAdjust(&pSelector->selected, (newSelection - localFirstDayInMonth) * daysInSeconds);
			}
		
		// The TimAdjust function may not actually change the time to a different month
		// if the user is on Jan. 1, 1904 and clicks to the left.  In this case
		// visually move the inverted item to the correct place because the month
		// ins't going to be redrawn.
		if (pSelector->selected.month == pSelector->visibleMonth && 
			MapDateToItem(pSelector) != newSelection)
			{
			InvertItem(pSelector, newSelection);
			InvertItem(pSelector, MapDateToItem(pSelector));
			}
		}
	else
		{
		newEvent.data.daySelect.useThisDate = true;
		
		// if selectDayByMonth the granularity is at the month level so the user can't
		// pick a particular day within the month.  Just use the existing selection.
		if (pSelector->selectDayBy != selectDayByMonth)
			pSelector->selected.day = newSelection - localFirstDayInMonth + 1;
		}


	newEvent.eType = daySelectEvent;
	EvtAddEventToQueue (&newEvent);

	return true;
	}



