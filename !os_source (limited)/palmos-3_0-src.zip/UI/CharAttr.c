/***********************************************************************
 * Copyright � 1995 - 1998, 3Com Corporation or its subsidiaries ("3Com").  
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     CType.c
 * AUTHOR:	 Art Lamb: April 21, 1995
 *
 * DECLARER: Toolbox
 *
 * DESCRIPTION:
 *	  This file contains the an array of 257 characters used by
 *   the character classification and character conversion macros
 *   (such as isalpha and toascii).
 *
 *   See CType.h 
 *
 **********************************************************************/
#include <SysAll.h>
#include <CharAttr.h>

/***********************************************************************
 *
 * FUNCTION: 	 GetCharAttr
 *
 * DESCRIPTION: Returns a a pointer to the characters attributes 
 *              array which is used by the character classification 
 *              and character conversion macros (such as isalpha 
 *              and toascii).
 *
 * PARAMETERS:  a character
 *
 * RETURNED:	A pointer to the attributes array.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/21/95	Initial Revision
 *			david	7/18/95	Added extended char. attributes
 *
 ***********************************************************************/
 
asm WordPtr GetCharAttr (void)
{

	lea	@charAttr, a0
	rts
	
@charAttr:	dc.w	_BB			// 00
				dc.w	_BB			// 01
				dc.w	_BB			// 02
				dc.w	_BB			// 03
				dc.w	_BB			// 04
				dc.w	_BB			// 05
				dc.w	_BB			// 06
				dc.w	_BB			// 07
				dc.w	_BB			// 08
				dc.w	_CN			// 09
				dc.w	_CN			// 0a
				dc.w	_CN			// 0b
				dc.w	_CN			// 0c
				dc.w	_CN			// 0d
				dc.w	_BB			// 0e
				dc.w	_BB			// 0f
				dc.w	_BB			// 10
				dc.w	_BB			// 11
				dc.w	_BB			// 12
				dc.w	_BB			// 13
				dc.w	_BB			// 14
				dc.w	_BB			// 15
				dc.w	_BB			// 16 
				dc.w	_BB			// 17
				dc.w	_BB			// 18
				dc.w	_BB			// 19
				dc.w	_BB			// 1a
				dc.w	_BB			// 1b
				dc.w	_BB			// 1c
				dc.w	_BB			// 1d
				dc.w	_BB			// 1e
				dc.w	_BB			// 1f
				dc.w	_SP			// 20 " "
				dc.w	_PU			// 21 "!"
				dc.w	_PU			// 22 """
				dc.w	_PU			// 23 "#"
				dc.w	_PU			// 24 "$"
				dc.w	_PU			// 25 "%"
				dc.w	_PU			// 26 "&"
				dc.w	_PU			// 27 "'"
				dc.w	_PU			// 28 "("
				dc.w	_PU			// 29 ")"
				dc.w	_PU			// 2a "*"
				dc.w	_PU			// 2b "+"
				dc.w	_PU			// 2c ","
				dc.w	_PU			// 2d "-"
				dc.w	_PU			// 2e "."
				dc.w	_PU			// 2f "/"
				dc.w	_DI|_XD		// 30 "0"
				dc.w	_DI|_XD		// 31 "1"
				dc.w	_DI|_XD		// 32 "2"
				dc.w	_DI|_XD		// 33 "3"
				dc.w	_DI|_XD		// 34 "4"
				dc.w	_DI|_XD		// 35 "5"
				dc.w	_DI|_XD		// 36 "6"
				dc.w	_DI|_XD		// 37 "7"
				dc.w	_DI|_XD		// 38 "8"
				dc.w	_DI|_XD		// 39 "9"
				dc.w	_PU			// 3a ":"
				dc.w	_PU			// 3b ";"
				dc.w	_PU			// 3c "<"
				dc.w	_PU			// 3d "="
				dc.w	_PU			// 3e ">"
				dc.w	_PU			// 3f "?"
				dc.w	_PU			// 40 "@"
				dc.w	_UP|_XD		// 41 "A"
				dc.w	_UP|_XD		// 42 "B"
				dc.w	_UP|_XD		// 43 "C"
				dc.w	_UP|_XD		// 44 "D"
				dc.w	_UP|_XD		// 45 "E"
				dc.w	_UP|_XD		// 46 "F"
				dc.w	_UP			// 47 "G"
				dc.w	_UP			// 48 "H"
				dc.w	_UP			// 49 "I"
				dc.w	_UP			// 4a "J"
				dc.w	_UP			// 4b "K"
				dc.w	_UP			// 4c "L"
				dc.w	_UP			// 4d "M"
				dc.w	_UP			// 4e "N"
				dc.w	_UP			// 4f "O"
				dc.w	_UP			// 50 "P"
				dc.w	_UP			// 51 "Q"
				dc.w	_UP			// 52 "R"
				dc.w	_UP			// 53 "S"
				dc.w	_UP			// 54 "T"
				dc.w	_UP			// 55 "U"
				dc.w	_UP			// 56 "V"
				dc.w	_UP			// 57 "W"
				dc.w	_UP			// 58 "X"
				dc.w	_UP			// 59 "Y"
				dc.w	_UP			// 5a "Z"
				dc.w	_PU			// 5b "["
				dc.w	_PU			// 5c "\"
				dc.w	_PU			// 5d "]"
				dc.w	_PU			// 5e "^"
				dc.w	_PU			// 5f "_"
				dc.w	_PU			// 60 "`"
				dc.w	_LO|_XD		// 61 "a"
				dc.w	_LO|_XD		// 62 "b"
				dc.w	_LO|_XD		// 63 "c"
				dc.w	_LO|_XD		// 64 "d"
				dc.w	_LO|_XD		// 65 "e"
				dc.w	_LO|_XD		// 66 "f"
				dc.w	_LO			// 67 "g"
				dc.w	_LO			// 68 "h"
				dc.w	_LO			// 69 "i"
				dc.w	_LO			// 6a "j"
				dc.w	_LO			// 6b "k"
				dc.w	_LO			// 6c "l"
				dc.w	_LO			// 6d "m"
				dc.w	_LO			// 6e "n"
				dc.w	_LO			// 6f "o"
				dc.w	_LO			// 70 "p"
				dc.w	_LO			// 71 "q"
				dc.w	_LO			// 72 "r"
				dc.w	_LO			// 73 "s"
				dc.w	_LO			// 74 "t"
				dc.w	_LO			// 75 "u"
				dc.w	_LO			// 76 "v"
				dc.w	_LO			// 77 "w"
				dc.w	_LO			// 78 "x"
				dc.w	_LO			// 79 "y"
				dc.w	_LO			// 7a "z"
				dc.w	_PU			// 7b "{"
				dc.w	_PU			// 7c "|"
				dc.w	_PU			// 7d "}"
				dc.w	_PU			// 7e "~"
				dc.w	_BB			// 7f
				dc.w	_SP|_XS		// 80 numericSpaceChr
				dc.w	0				// 81
				dc.w	_PU			// 82	lowSingleCommaQuoteChr
				dc.w	_XA			// 83	scriptFChr
				dc.w	_PU			// 84	lowDblCommaQuoteChr
				dc.w	_PU			// 85	horizEllipsisChr
				dc.w	_PU			// 86 daggerChr
				dc.w	_PU			// 87 dblDaggerChr
				dc.w	_PU			// 88	circumflexChr
				dc.w	_PU			// 89	perMilleChr
				dc.w	_XA|_UP		// 8a	upSHacekChr
				dc.w	_PU			// 8b	leftSingleGuillemetChr
				dc.w	_XA|_UP		// 8c	upOEChr
				dc.w	0				// 8d	
				dc.w	0				// 8e	
				dc.w	0				// 8f	
				dc.w	0				// 90
				dc.w	_PU			// 91	singleOpenCommaQuoteChr		
				dc.w	_PU			// 92	singleCloseCommaQuoteChr
				dc.w	_PU			// 93	dblOpenCommaQuoteChr
				dc.w	_PU			// 94	dblCloseCommaQuoteChr
				dc.w	_PU			// 95	bulletChr
				dc.w	_PU			// 96	enDashChr
				dc.w	_PU			// 97	emDashChr
				dc.w	_PU			// 98	spacingTildeChr
				dc.w	_PU			// 99	trademarkChr			
				dc.w	_XA|_LO		// 9a	lowSHacekChr
				dc.w	_PU			// 9b	rightSingleGuillemetChr
				dc.w	_XA|_LO		// 9c	lowOEChr
				dc.w	_PU			// 9d commandStrokeChr
				dc.w	_PU			// 9e shortcutStrokeChr
				dc.w	_XA|_UP		// 9f	upYDiaeresisChr
				dc.w	_SP|_XS		// a0	nonBreakSpaceChr
				dc.w	_PU			// a1	invertedExclamationChr
				dc.w	_PU			// a2	centChr
				dc.w	_PU			// a3	poundChr
				dc.w	_PU			// a4	currencyChr
				dc.w	_PU			// a5	yenChr
				dc.w	_PU			// a6	brokenVertBarChr
				dc.w	_PU			// a7	sectionChr
				dc.w	_PU			// a8	spacingDiaeresisChr
				dc.w	_PU			// a9	copyrightChr
				dc.w	_PU			// aa	feminineOrdinalChr
				dc.w	_PU			// ab	leftGuillemetChr
				dc.w	_PU			// ac	notChr
				dc.w	_PU			// ad	softHyphenChr
				dc.w	_PU			// ae	registeredChr
				dc.w	_PU			// af	spacingMacronChr
				dc.w	_PU			// b0	degreeChr
				dc.w	_PU			// b1	plusMinusChr
				dc.w	_PU			// b2	superscript2Chr
				dc.w	_PU			// b3	superscript3Chr
				dc.w	_PU			// b4	spacingAcuteChr
				dc.w	_PU			// b5	microChr
				dc.w	_PU			// b6	paragraphChr
				dc.w	_PU			// b7	middleDotChr
				dc.w	_PU			// b8	spacingCedillaChr
				dc.w	_PU			// b9	superscript1Chr
				dc.w	_PU			// ba	masculineOrdinalChr
				dc.w	_PU			// bb	rightGullemetChr
				dc.w	_PU			// bc	fractOneQuarterChr
				dc.w	_PU			// bd	fractOneHalfChr
				dc.w	_PU			// be	fractThreeQuartersChr
				dc.w	_PU			// bf	invertedQuestionChr
				dc.w	_XA|_UP		// c0	upAGraveChr
				dc.w	_XA|_UP		// c1	upAAcuteChr
				dc.w	_XA|_UP		// c2	upACircumflexChr
				dc.w	_XA|_UP		// c3	upATildeChr
				dc.w	_XA|_UP		// c4	upADiaeresisChr
				dc.w	_XA|_UP		// c5	upARingChr
				dc.w	_XA|_UP		// c6	upAEChr
				dc.w	_XA|_UP		// c7	upCCedillaChr
				dc.w	_XA|_UP		// c8	upEGraveChr
				dc.w	_XA|_UP		// c9	upEAcuteChr
				dc.w	_XA|_UP		// ca	upECircumflexChr
				dc.w	_XA|_UP		// cb	upEDiaeresisChr
				dc.w	_XA|_UP		// cc	upIGraveChr
				dc.w	_XA|_UP		// cd	upIAcuteChr
				dc.w	_XA|_UP		// ce	upICircumflexChr
				dc.w	_XA|_UP		// cf	upIDiaeresisChr
				dc.w	_XA|_UP		// d0	upEthChr
				dc.w	_XA|_UP		// d1	upNTildeChr
				dc.w	_XA|_UP		// d2	upOGraveChr
				dc.w	_XA|_UP		// d3	upOAcuteChr
				dc.w	_XA|_UP		// d4 upOCircumflexChr
				dc.w	_XA|_UP		// d5	upOTildeChr
				dc.w	_XA|_UP		// d6	upODiaeresisChr
				dc.w	_PU			// d7	multiplyChr
				dc.w	_XA|_UP		// d8	upOSlashChr
				dc.w	_XA|_UP		// d9	upUGraveChr
				dc.w	_XA|_UP		// da	upUAcuteChr
				dc.w	_XA|_UP		// db upUCircumflexChr
				dc.w	_XA|_UP		// dc	upUDiaeresisChr
				dc.w	_XA|_UP		// dd	upYAcuteChr
				dc.w	_XA|_UP		// de	upThorn
				dc.w	_XA|_LO		// df	lowSharpSChr
				dc.w	_XA|_LO		// e0	lowAGraveChr
				dc.w	_XA|_LO		// e1	lowAAcuteChr
				dc.w	_XA|_LO		// e2	lowACircumflexChr
				dc.w	_XA|_LO		// e3	lowATildeChr
				dc.w	_XA|_LO		// e4	lowADiaeresisChr
				dc.w	_XA|_LO		// e5	lowARingChr
				dc.w	_XA|_LO		// e6	lowAEChr
				dc.w	_XA|_LO		// e7	lowCCedillaChr
				dc.w	_XA|_LO		// e8	lowEGraveChr
				dc.w	_XA|_LO		// e9	lowEAcuteChr
				dc.w	_XA|_LO		// ea	lowECircumflexChr
				dc.w	_XA|_LO		// eb	lowEDiaeresisChr
				dc.w	_XA|_LO		// ec	lowIGraveChr
				dc.w	_XA|_LO		// ed	lowIAcuteChr
				dc.w	_XA|_LO		// ee	lowICircumflexChr
				dc.w	_XA|_LO		// ef	lowIDiaeresisChr
				dc.w	_XA|_LO		// f0	lowEthChr
				dc.w	_XA|_LO		// f1	lowNTildeChr
				dc.w	_XA|_LO		// f2	lowOGraveChr
				dc.w	_XA|_LO		// f3	lowOAcuteChr
				dc.w	_XA|_LO		// f4	lowOCircumflexChr
				dc.w	_XA|_LO		// f5 lowOTildeChr
				dc.w	_XA|_LO		// f6	lowODiaeresisChr
				dc.w	_PU			// f7	divideChr
				dc.w	_XA|_LO		// f8	lowOSlashChr
				dc.w	_XA|_LO		// f9	lowUGraveChr
				dc.w	_XA|_LO		// fa	lowUAcuteChr
				dc.w	_XA|_LO		// fb	lowUCircumflexChr
				dc.w	_XA|_LO		// fc	lowUDiaeresisChr
				dc.w	_XA|_LO		// fd	lowYAcuteChr
				dc.w	_XA|_LO		// fe	lowThorn
				dc.w	_XA|_LO		// ff	lowYDiaeresisChr				
}



/***********************************************************************
 *
 * FUNCTION: 	 GetLowerChars
 *
 * DESCRIPTION: Returns a pointer to an array that maps upper
 *              case characters to lower case.  Characters that are
 *              not upper case are map to themselves.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	A pointer to the attributes array.  
 *	The stupid compiler pads each byte out to a word so index them
 * appriprately.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	4/21/95	Initial Revision
 *
 ***********************************************************************/
/*
asm CharPtr GetLowerChars (void)
{

	lea	@lowerChar, a0
	rts
#pragma options align=mac68k

@lowerChar:	dc.b	0x00		// 00
				dc.b	0x01		// 01
				dc.b	0x02		// 02
				dc.b	0x03		// 03
				dc.b	0x04		// 04
				dc.b	0x05		// 05
				dc.b	0x06		// 06
				dc.b	0x07		// 07
				dc.b	0x08		// 08
				dc.b	0x09		// 09
				dc.b	0x0a		// 0a
				dc.b	0x0b		// 0b
				dc.b	0x0c		// 0c
				dc.b	0x0d		// 0d
				dc.b	0x0e		// 0e
				dc.b	0x0f		// 0f
				dc.b	0x10		// 10
				dc.b	0x11		// 11
				dc.b	0x12		// 12
				dc.b	0x13		// 13
				dc.b	0x14		// 14
				dc.b	0x15		// 15
				dc.b	0x16		// 16
				dc.b	0x17		// 17
				dc.b	0x18		// 18
				dc.b	0x19		// 19
				dc.b	0x1a		// 1a
				dc.b	0x1b		// 1b
				dc.b	0x1c		// 1c
				dc.b	0x1d		// 1d
				dc.b	0x1e		// 1e
				dc.b	0x1f		// 1f
				dc.b	0x20		// 20	" "
				dc.b	0x21		// 21	"!"
				dc.b	0x22		// 22	"""
				dc.b	0x23		// 23	"#"
				dc.b	0x24		// 24	"$"
				dc.b	0x25		// 25	"%"
				dc.b	0x26		// 26	"&"
				dc.b	0x27		// 27	"'"
				dc.b	0x28		// 28	"("
				dc.b	0x29		// 29	")"
				dc.b	0x2a		// 2a	"*"
				dc.b	0x2b		// 2b	"+"
				dc.b	0x2c		// 2c	","
				dc.b	0x2d		// 2d	"-"
				dc.b	0x2e		// 2e	"."
				dc.b	0x2f		// 2f	"/"
				dc.b	0x30		// 30	"0"
				dc.b	0x31		// 31	"1"
				dc.b	0x32		// 32	"2"
				dc.b	0x33		// 33	"3"
				dc.b	0x34		// 34	"4"
				dc.b	0x35		// 35	"5"
				dc.b	0x36		// 36	"6"
				dc.b	0x37		// 37	"7"
				dc.b	0x38		// 38	"8"
				dc.b	0x39		// 39	"9"
				dc.b	0x3a		// 3a	":"
				dc.b	0x3b		// 3b	";"
				dc.b	0x3c		// 3c	"<"
				dc.b	0x3d		// 3d	"="
				dc.b	0x3e		// 3e	">"
				dc.b	0x3f		// 3f	"?"
				dc.b	0x40		// 40	"@"
				dc.b	0x61		// 41	"A"
				dc.b	0x62		// 42	"B"
				dc.b	0x63		// 43	"C"
				dc.b	0x64		// 44	"D"
				dc.b	0x65		// 45	"E"
				dc.b	0x66		// 46	"F"
				dc.b	0x67		// 47	"G"
				dc.b	0x68		// 48	"H"
				dc.b	0x69		// 49	"I"
				dc.b	0x6a		// 4a	"J"
				dc.b	0x6b		// 4b	"K"
				dc.b	0x6c		// 4c	"L"
				dc.b	0x6d		// 4d	"M"
				dc.b	0x6e		// 4e	"N"
				dc.b	0x6f		// 4f	"O"
				dc.b	0x70		// 50	"P"
				dc.b	0x71		// 51	"Q"
				dc.b	0x72		// 52	"R"
				dc.b	0x73		// 53	"S"
				dc.b	0x74		// 54	"T"
				dc.b	0x75		// 55	"U"
				dc.b	0x76		// 56	"V"
				dc.b	0x77		// 57	"W"
				dc.b	0x78		// 58	"X"
				dc.b	0x79		// 59	"Y"
				dc.b	0x7a		// 5a	"Z"
				dc.b	0x5b		// 5b	"["
				dc.b	0x5c		// 5c	"\"
				dc.b	0x5d		// 5d	"]"
				dc.b	0x5e		// 5e	"^"
				dc.b	0x5f		// 5f	"_"
				dc.b	0x60		// 60	"`"
				dc.b	0x61		// 61	"a"
				dc.b	0x62		// 62	"b"
				dc.b	0x63		// 63	"c"
				dc.b	0x64		// 64	"d"
				dc.b	0x65		// 65	"e"
				dc.b	0x66		// 66	"f"
				dc.b	0x67		// 67	"g"
				dc.b	0x68		// 68	"h"
				dc.b	0x69		// 69	"i"
				dc.b	0x6a		// 6a	"j"
				dc.b	0x6b		// 6b	"k"
				dc.b	0x6c		// 6c	"l"
				dc.b	0x6d		// 6d	"m"
				dc.b	0x6e		// 6e	"n"
				dc.b	0x6f		// 6f	"o"
				dc.b	0x70		// 70	"p"
				dc.b	0x71		// 71	"q"
				dc.b	0x72		// 72	"r"
				dc.b	0x73		// 73	"s"
				dc.b	0x74		// 74	"t"
				dc.b	0x75		// 75	"u"
				dc.b	0x76		// 76	"v"
				dc.b	0x77		// 77	"w"
				dc.b	0x78		// 78	"x"
				dc.b	0x79		// 79	"y"
				dc.b	0x7a		// 7a	"z"
				dc.b	0x7b		// 7b	"{"
				dc.b	0x7c		// 7c	"|"
				dc.b	0x7d		// 7d	"}"
				dc.b	0x7e		// 7e	"~"
				dc.b	0x7f		// 7f
				dc.b	0x80		// 80	"�"
				dc.b	0x81		// 81	"�"
				dc.b	0x82		// 82	"�"
				dc.b	0x83		// 83	"�"
				dc.b	0x84		// 84	"�"
				dc.b	0x85		// 85	"�"
				dc.b	0x86		// 86	"�"
				dc.b	0x87		// 87	"�"
				dc.b	0x88		// 88	"�"
				dc.b	0x89		// 89	"�"
				dc.b	0x8a		// 8a	"�"
				dc.b	0x8b		// 8b	"�"
				dc.b	0x8c		// 8c	"�"
				dc.b	0x8d		// 8d	"�"
				dc.b	0x8e		// 8e	"�"
				dc.b	0x8f		// 8f	"�"
				dc.b	0x90		// 90	"�"
				dc.b	0x91		// 91	"�"
				dc.b	0x92		// 92	"�"
				dc.b	0x93		// 93	"�"
				dc.b	0x94		// 94	"�"
				dc.b	0x95		// 95	"�"
				dc.b	0x96		// 96	"�"
				dc.b	0x97		// 97	"�"
				dc.b	0x98		// 98	"�"
				dc.b	0x99		// 99	"�"
				dc.b	0x9a		// 9a	"�"
				dc.b	0x9b		// 9b	"�"
				dc.b	0x9c		// 9c	"�"
				dc.b	0x9d		// 9d	"�"
				dc.b	0x9e		// 9e	"�"
				dc.b	0x9f		// 9f	"�"
				dc.b	0xa0		// a0	"�"
				dc.b	0xa1		// a1	"�"
				dc.b	0xa2		// a2	"�"
				dc.b	0xa3		// a3	"�"
				dc.b	0xa4		// a4	"�"
				dc.b	0xa5		// a5	"�"
				dc.b	0xa6		// a6	"�"
				dc.b	0xa7		// a7	"�"
				dc.b	0xa8		// a8	"�"
				dc.b	0xa9		// a9	"�"
				dc.b	0xaa		// aa	"�"
				dc.b	0xab		// ab	"�"
				dc.b	0xac		// ac	"�"
				dc.b	0xad		// ad	"�"
				dc.b	0xae		// ae	"�"
				dc.b	0xaf		// af	"�"
				dc.b	0xb0		// b0	"�"
				dc.b	0xb1		// b1	"�"
				dc.b	0xb2		// b2	"�"
				dc.b	0xb3		// b3	"�"
				dc.b	0xb4		// b4	"�"
				dc.b	0xb5		// b5	"�"
				dc.b	0xb6		// b6	"�"
				dc.b	0xb7		// b7	"�"
				dc.b	0xb8		// b8	"�"
				dc.b	0xb9		// b9	"�"
				dc.b	0xba		// ba	"�"
				dc.b	0xbb		// bb	"�"
				dc.b	0xbc		// bc	"�"
				dc.b	0xbd		// bd	"�"
				dc.b	0xbe		// be	"�"
				dc.b	0xbf		// bf	"�"
				dc.b	0xc0		// c0	"�"
				dc.b	0xc1		// c1	"�"
				dc.b	0xc2		// c2	"�"
				dc.b	0xc3		// c3	"�"
				dc.b	0xc4		// c4	"�"
				dc.b	0xc5		// c5	"�"
				dc.b	0xc6		// c6	"�"
				dc.b	0xc7		// c7	"�"
				dc.b	0xc8		// c8	"�"
				dc.b	0xc9		// c9	"�"
				dc.b	0xca		// ca	"�"
				dc.b	0xcb		// cb	"�"
				dc.b	0xcc		// cc	"�"
				dc.b	0xcd		// cd	"�"
				dc.b	0xce		// ce	"�"
				dc.b	0xcf		// cf	"�"
				dc.b	0xd0		// d0	"�"
				dc.b	0xd1		// d1	"�"
				dc.b	0xd2		// d2	"�"
				dc.b	0xd3		// d3	"�"
				dc.b	0xd4		// d4	"�"
				dc.b	0xd5		// d5	"�"
				dc.b	0xd6		// d6	"�"
				dc.b	0xd7		// d7	"�"
				dc.b	0xd8		// d8	"�"
				dc.b	0xd9		// d9	"�"
				dc.b	0xda		// da	"�"
				dc.b	0xdb		// db	"�"
				dc.b	0xdc		// dc	"�"
				dc.b	0xdd		// dd	"�"
				dc.b	0xde		// de	"�"
				dc.b	0xdf		// df	"�"
				dc.b	0xe0		// e0	"�"
				dc.b	0xe1		// e1	"�"
				dc.b	0xe2		// e2	"�"
				dc.b	0xe3		// e3	"�"
				dc.b	0xe4		// e4	"�"
				dc.b	0xe5		// e5	"�"
				dc.b	0xe6		// e6	"�"
				dc.b	0xe7		// e7	"�"
				dc.b	0xe8		// e8	"�"
				dc.b	0xe9		// e9	"�"
				dc.b	0xea		// ea	"�"
				dc.b	0xeb		// eb	"�"
				dc.b	0xec		// ec	"�"
				dc.b	0xed		// ed	"�"
				dc.b	0xee		// ee	"�"
				dc.b	0xef		// ef	"�"
				dc.b	0xf0		// f0	"�"
				dc.b	0xf1		// f1	"�"
				dc.b	0xf2		// f2	"�"
				dc.b	0xf3		// f3	"�"
				dc.b	0xf4		// f4	"�"
				dc.b	0xf5		// f5	"�"
				dc.b	0xf6		// f6	"�"
				dc.b	0xf7		// f7	"�"
				dc.b	0xf8		// f8	"�"
				dc.b	0xf9		// f9	"�"
				dc.b	0xfa		// fa	"�"
				dc.b	0xfb		// fb	"�"
				dc.b	0xfc		// fc	"�"
				dc.b	0xfd		// fd	"�"
				dc.b	0xfe		// fe	"�"
				dc.b	0xff		// ff	"�"
#pragma options align=reset
}
*/

/***********************************************************************
 *
 * FUNCTION: 	 GetCharSortValue
 *
 * DESCRIPTION: Returns a pointer to an array that maps all
 *              characters to an assigned sorting value
 *
 *					 This should be used for ordering (sorting) text.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	A pointer to the attributes array.
 *	The stupid compiler pads each byte out to a word so index them
 * appriprately.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			David	7/11/95	Initial Revision
 *
 ***********************************************************************/
asm BytePtr GetCharSortValue (void)
{

	lea	@sortValues, a0
	rts
#pragma options align=mac68k


//	Case and accent sensitive sort values, accent letters mixed in with regular letters.
// These values are set up for English, German, and French ONLY.  
// Sorting other languages may result in errors!
			
@sortValues:	dc.b	  0, 1		// 00
									// 01
				dc.b	  2, 3	// 02
									// 03
				dc.b	  4, 5	// 04
									// 05
				dc.b	  6, 7	// 06
							 		// 07
				dc.b	  8, 43	// 08
									// 09
				dc.b	 44, 45	// 0a
									// 0b
				dc.b	 46, 47	// 0c
									// 0d
				dc.b	 9, 10	// 0e
									// 0f
				dc.b	 11, 12	// 10
									// 11
				dc.b	 13, 14	// 12
									// 13
				dc.b	 15, 16	// 14
									// 15
				dc.b	 17, 18	// 16
									// 17
				dc.b	 19, 20	// 18
									// 19
				dc.b	 21, 22	// 1a
									// 1b
				dc.b	 23, 24	// 1c
									// 1d
				dc.b	 25, 26	// 1e
									// 1f
				dc.b	 41, 48	// 20	" "
									// 21	"!"
				dc.b	 49, 50	// 22	"""
									// 23	"#"
				dc.b	 51, 52	// 24	"$"
									// 25	"%"
				dc.b	 53, 36	// 26	"&"
									// 27	"'"
				dc.b	 54, 55	// 28	"("
									// 29	")"
				dc.b	 56, 91	// 2a	"*"
									// 2b	"+"
				dc.b	 57, 37	// 2c	","
									// 2d	"-"
				dc.b	 58, 59	// 2e	"."
									// 2f	"/"
				dc.b	117, 121	// 30	"0"
									// 31	"1"
				dc.b	123, 125	// 32	"2"
									// 33	"3"
				dc.b	127, 128	// 34	"4"
									// 35	"5"
				dc.b	129, 130	// 36	"6"
									// 37	"7"
				dc.b	131, 132	// 38	"8"
									// 39	"9"
				dc.b	 60, 61	// 3a	":"
									// 3b	";"
				dc.b	 92, 93	// 3c	"<"
									// 3d	"="
				dc.b	 94, 62	// 3e	">"
									// 3f	"?"
				dc.b	 63, 134	// 40	"@"
									// 41	"A"
				dc.b	151, 153	// 42	"B"
									// 43	"C"
				dc.b	157, 161	// 44	"D"
									// 45	"E"
				dc.b	171, 174	// 46	"F"
									// 47	"G"
				dc.b	176, 178	// 48	"H"
									// 49	"I"
				dc.b	188, 190	// 4a	"J"
									// 4b	"K"
				dc.b	192, 194	// 4c	"L"
									// 4d	"M"
				dc.b	196, 200	// 4e	"N"
									// 4f	"O"
				dc.b	217, 219	// 50	"P"
									// 51	"Q"
				dc.b	221, 223	// 52	"R"
									// 53	"S"
				dc.b	228, 233	// 54	"T"
									// 55	"U"
				dc.b	243, 245	// 56	"V"
									// 57	"W"
				dc.b	247, 249	// 58	"X"
									// 59	"Y"
				dc.b	255, 64	// 5a	"Z"
									// 5b	"["
				dc.b	 65, 66	// 5c	"\"
									// 5d	"]"
				dc.b	 67, 69	// 5e	"^"
									// 5f	"_"
				dc.b	 70, 133	// 60	"`"
									// 61	"a"
				dc.b	150, 152	// 62	"b"
									// 63	"c"
				dc.b	156, 160	// 64	"d"
									// 65	"e"
				dc.b	170, 173	// 66	"f"
									// 67	"g"
				dc.b	175, 177	// 68	"h"
									// 69	"i"
				dc.b	187, 189	// 6a	"j"
									// 6b	"k"
				dc.b	191, 193	// 6c	"l"
									// 6d	"m"
				dc.b	195, 199	// 6e	"n"
									// 6f	"o"
				dc.b	216, 218	// 70	"p"
									// 71	"q"
				dc.b	220, 222	// 72	"r"
									// 73	"s"
				dc.b	227, 232	// 74	"t"
									// 75	"u"
				dc.b	242, 244	// 76	"v"
									// 77	"w"
				dc.b	246, 248	// 78	"x"
									// 79	"y"
				dc.b	254, 71	// 7a	"z"
									// 7b	"{"
				dc.b	 72, 73	// 7c	"|"
									// 7d	"}"
				dc.b	 74, 27	// 7e	"~"
									// 7f
				dc.b	 28, 29	// 80	
									// 81	
				dc.b	 85, 172	// 82	"�" lowSingleCommaQuoteChr 
									// 83	"�" scriptFChr 
				dc.b	 88, 115	// 84	"�" lowDblCommaQuoteChr 
									// 85	"�" horizEllipsisChr 
				dc.b	112, 113	// 86	"�" daggerChr 
									// 87	"�" dblDaggerChr 
				dc.b	 68, 116	// 88	"�" circumflexChr 
									// 89	"�" perMilleChr 
				dc.b	225, 89	// 8a	upSHacekChr
									// 8b	"�" leftSingleGuillemetChr 
				dc.b	215, 30	// 8c	"�" upOEChr
									// 8d	
				dc.b	 31, 32	// 8e	
									// 8f	
				dc.b	 33, 83	// 90	
									// 91	"�" singleOpenCommaQuoteChr	
				dc.b	 84, 86	// 92	"�" singleCloseCommaQuoteChr 
									// 93	"�" dblOpenCommaQuoteChr
				dc.b	 87, 114	// 94	"�" dblCloseCommaQuoteChr	
									// 95	"�" bulletChr 
				dc.b	 39, 40	// 96	"�" enDashChr
									// 97	"�" emDashChr
				dc.b	 82, 231	// 98	"�" spacingTildeChr 
									// 99	"�" trademarkChr 
				dc.b	224, 90	// 9a	lowSHacekChr
									// 9b	"�" rightSingleGuillemetChr
				dc.b	214, 34	// 9c	"�" lowOEChr
									// 9d	
				dc.b	 35, 253	// 9e	
									// 9f	"�" upYDiaeresisChr 
				dc.b	 42, 75	// a0	nonBreakSpaceChr
									// a1	"�" invertedExclamationChr 
				dc.b	100, 101	// a2	"�" centChr 
									// a3	"�" poundChr 
				dc.b	102, 103	// a4	"�" currencyChr 
									// a5	"�" yenChr 
				dc.b	 76, 104	// a6	brokenVertBarChr
									// a7	"�" sectionChr
				dc.b	 77, 105	// a8	"�" spacingDiaeresisChr
									// a9	"�" copyrightChr 
				dc.b	135, 96	// aa	"�" feminineOrdinalChr
									// ab	"�" leftGuillemetChr
				dc.b	106, 38	// ac	"�" notChr 
									// ad	softHyphenChr
				dc.b	107, 78	// ae	"�" registeredChr
									// af	"�" spacingMacronChr
				dc.b	108, 95	// b0	"�" degreeChr 
									// b1	"�" plusMinusChr
				dc.b	124, 126	// b2	superscript2Chr
									// b3	superscript3Chr
				dc.b	 79, 109	// b4	"�" spacingAcuteChr
									// b5	"�" microChr
				dc.b	110, 111	// b6	"�" paragraphChr
									// b7	middleDotChr
				dc.b	 80, 122	// b8	"�" spacingCedillaChr
									// b9	superscript1Chr
				dc.b	118, 201	// ba	"�" masculineOrdinalChr
									// bb	"�" rightGullemetChr
				dc.b	118, 119	// bc	fractOneQuarterChr
									// bd	fractOneHalfChr
				dc.b	120,  81	// be	fractThreeQuartersChr
									// bf	"�" invertedQuestionChr
				dc.b	139, 137	// c0	"�" upAGraveChr
									// c1	"�" upAAcuteChr
				dc.b	141, 145	// c2	"�" upACircumflexChr
									// c3	"�" upATildeChr
				dc.b	143, 147	// c4	"�" upADiaeresisChr
									// c5	"�" upARingChr
				dc.b	149, 155	// c6	"�" upAEChr
									// c7	"�" upCCedillaChr
				dc.b	165, 163	// c8	"�" upEGraveChr
									// c9	"�" upEAcuteChr
				dc.b	167, 169	// ca	"�" upECircumflexChr
									// cb	"�" upEDiaeresisChr
				dc.b	182, 180	// cc	"�" upIGraveChr
									// cd	"�" upIAcuteChr
				dc.b	184, 186	// ce	"�" upICircumflexChr
									// cf	"�" upIDiaeresisChr
				dc.b	159, 198	// d0	upEthChr
									// d1	"�" upNTildeChr
				dc.b	205, 203	// d2	"�" upOGraveChr
									// d3	"�" upOAcuteChr
				dc.b	207, 211	// d4 "�" upOCircumflexChr
									// d5	"�" upOTildeChr
				dc.b	209, 98	// d6	"�" upODiaeresisChr
									// d7	multiplyChr
				dc.b	213, 237	// d8	"�" upOSlashChr
									// d9	"�" upUGraveChr
				dc.b	235, 239	// da	"�" upUAcuteChr
									// db "�" upUCircumflexChr
				dc.b	241, 251	// dc	"�" upUDiaeresisChr
									// dd	upYAcuteChr
				dc.b	230, 226	// de	upThorn
									// df	"�" lowSharpSChr
				dc.b	138, 136	// e0	"�" lowAGraveChr
									// e1	"�" lowAAcuteChr
				dc.b	140, 144	// e2	"�" lowACircumflexChr
									// e3	"�" lowATildeChr
				dc.b	142, 146	// e4	"�" lowADiaeresisChr
									// e5	"�" lowARingChr
				dc.b	148, 154	// e6	"�" lowAEChr
									// e7	"�" lowCCedillaChr
				dc.b	164, 162	// e8	"�" lowEGraveChr
									// e9	"�" lowEAcuteChr
				dc.b	166, 168	// ea	"�" lowECircumflexChr
									// eb	"�" lowEDiaeresisChr
				dc.b	181, 179	// ec	"�" lowIGraveChr
									// ed	"�" lowIAcuteChr
				dc.b	183, 190	// ee	"�" lowICircumflexChr
									// ef	"�" lowIDiaeresisChr
				dc.b	158, 197	// f0	"�" lowEthChr
									// f1	"�" lowNTildeChr
				dc.b	204, 202	// f2	"�" lowOGraveChr
									// f3	"�" lowOAcuteChr
				dc.b	206, 210	// f4	"�" lowOCircumflexChr
									// f5 "�" lowOTildeChr
				dc.b	208, 99	// f6	"�" lowODiaeresisChr
									// f7	"�" divideChr
				dc.b	212, 236	// f8	"�" lowOSlashChr
									// f9	"�" lowUGraveChr
				dc.b	234, 238	// fa	"�" lowUAcuteChr
									// fb	"�" lowUCircumflexChr
				dc.b	240, 250	// fc	"�" lowUDiaeresisChr
									// fd	lowYAcuteChr
				dc.b	229, 252	// fe	lowThorn
									// ff	"�" lowYDiaeresisChr


#pragma options align=reset
}


/***********************************************************************
 *
 * FUNCTION: 	 GetCharCaselessValue
 *
 * DESCRIPTION: Returns a pointer to an array that maps all
 *              characters to an assigned caseless and accentless value.
 *
 *					 This should be used for finding text.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:	A pointer to the attributes array.
 *	The stupid compiler pads each byte out to a word so index them
 * appriprately.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	9/26/95	Initial Revision
 *
 ***********************************************************************/
asm BytePtr GetCharCaselessValue (void)
{

	lea	@compareValues, a0
	rts
#pragma options align=mac68k


//			Case and accent insensitive sort values, accent letters mixed in with regular letters.
			
@compareValues:	dc.b	  0, 1		// 00
									// 01
				dc.b	  2, 3	// 02
									// 03
				dc.b	  4, 5	// 04
									// 05
				dc.b	  6, 7	// 06
							 		// 07
				dc.b	  8, 43	// 08
									// 09
				dc.b	 44, 45	// 0a
									// 0b
				dc.b	 46, 47	// 0c
									// 0d
				dc.b	 9, 10	// 0e
									// 0f
				dc.b	 11, 12	// 10
									// 11
				dc.b	 13, 14	// 12
									// 13
				dc.b	 15, 16	// 14
									// 15
				dc.b	 17, 18	// 16
									// 17
				dc.b	 19, 20	// 18
									// 19
				dc.b	 21, 22	// 1a
									// 1b
				dc.b	 23, 24	// 1c
									// 1d
				dc.b	 25, 26	// 1e
									// 1f
				dc.b	 41, 48	// 20	" "
									// 21	"!"
				dc.b	 49, 50	// 22	"""
									// 23	"#"
				dc.b	 51, 52	// 24	"$"
									// 25	"%"
				dc.b	 53, 36	// 26	"&"
									// 27	"'"
				dc.b	 54, 55	// 28	"("
									// 29	")"
				dc.b	 56, 91	// 2a	"*"
									// 2b	"+"
				dc.b	 57, 37	// 2c	","
									// 2d	"-"
				dc.b	 58, 59	// 2e	"."
									// 2f	"/"
				dc.b	117, 121	// 30	"0"
									// 31	"1"
				dc.b	123, 125	// 32	"2"
									// 33	"3"
				dc.b	127, 128	// 34	"4"
									// 35	"5"
				dc.b	129, 130	// 36	"6"
									// 37	"7"
				dc.b	131, 132	// 38	"8"
									// 39	"9"
				dc.b	 60, 61	// 3a	":"
									// 3b	";"
				dc.b	 92, 93	// 3c	"<"
									// 3d	"="
				dc.b	 94, 62	// 3e	">"
									// 3f	"?"
				dc.b	 63, 133	// 40	"@"
									// 41	"A"
				dc.b	150, 152	// 42	"B"
									// 43	"C"
				dc.b	156, 160	// 44	"D"
									// 45	"E"
				dc.b	170, 173	// 46	"F"
									// 47	"G"
				dc.b	175, 177	// 48	"H"
									// 49	"I"
				dc.b	187, 189	// 4a	"J"
									// 4b	"K"
				dc.b	191, 193	// 4c	"L"
									// 4d	"M"
				dc.b	195, 199	// 4e	"N"
									// 4f	"O"
				dc.b	216, 218	// 50	"P"
									// 51	"Q"
				dc.b	220, 222	// 52	"R"
									// 53	"S"
				dc.b	227, 232	// 54	"T"
									// 55	"U"
				dc.b	243, 245	// 56	"V"
									// 57	"W"
				dc.b	246, 248	// 58	"X"
									// 59	"Y"
				dc.b	255, 64	// 5a	"Z"
									// 5b	"["
				dc.b	 65, 66	// 5c	"\"
									// 5d	"]"
				dc.b	 67, 69	// 5e	"^"
									// 5f	"_"
				dc.b	 70, 133	// 60	"`"
									// 61	"a"
				dc.b	150, 152	// 62	"b"
									// 63	"c"
				dc.b	156, 160	// 64	"d"
									// 65	"e"
				dc.b	170, 173	// 66	"f"
									// 67	"g"
				dc.b	175, 177	// 68	"h"
									// 69	"i"
				dc.b	187, 189	// 6a	"j"
									// 6b	"k"
				dc.b	191, 193	// 6c	"l"
									// 6d	"m"
				dc.b	195, 199	// 6e	"n"
									// 6f	"o"
				dc.b	216, 218	// 70	"p"
									// 71	"q"
				dc.b	220, 222	// 72	"r"
									// 73	"s"
				dc.b	227, 232	// 74	"t"
									// 75	"u"
				dc.b	243, 245	// 76	"v"
									// 77	"w"
				dc.b	246, 248	// 78	"x"
									// 79	"y"
				dc.b	255, 71	// 7a	"z"
									// 7b	"{"
				dc.b	 72, 73	// 7c	"|"
									// 7d	"}"
				dc.b	 74, 27	// 7e	"~"
									// 7f
				dc.b	 28, 29	// 80	
									// 81	
				dc.b	 85, 170	// 82	"�" lowSingleCommaQuoteChr 
									// 83	"�" scriptFChr 
				dc.b	 88, 115	// 84	"�" lowDblCommaQuoteChr 
									// 85	"�" horizEllipsisChr 
				dc.b	112, 113	// 86	"�" daggerChr 
									// 87	"�" dblDaggerChr 
				dc.b	 68, 116	// 88	"�" circumflexChr 
									// 89	"�" perMilleChr 
				dc.b	222, 89	// 8a	upSHacekChr
									// 8b	"�" leftSingleGuillemetChr 
				dc.b	214, 30	// 8c	"�" upOEChr
									// 8d	
				dc.b	 31, 32	// 8e	
									// 8f	
				dc.b	 33, 83	// 90	
									// 91	"�" singleOpenCommaQuoteChr	
				dc.b	 84, 86	// 92	"�" singleCloseCommaQuoteChr 
									// 93	"�" dblOpenCommaQuoteChr
				dc.b	 87, 114	// 94	"�" dblCloseCommaQuoteChr	
									// 95	"�" bulletChr 
				dc.b	 39, 40	// 96	"�" enDashChr
									// 97	"�" emDashChr
				dc.b	 82, 231	// 98	"�" spacingTildeChr 
									// 99	"�" trademarkChr 
				dc.b	222, 90	// 9a	lowSHacekChr
									// 9b	"�" rightSingleGuillemetChr
				dc.b	214, 34	// 9c	"�" lowOEChr
									// 9d	
				dc.b	 35, 248	// 9e	
									// 9f	"�" upYDiaeresisChr 
				dc.b	 42, 75	// a0	nonBreakSpaceChr
									// a1	"�" invertedExclamationChr 
				dc.b	100, 101	// a2	"�" centChr 
									// a3	"�" poundChr 
				dc.b	102, 103	// a4	"�" currencyChr 
									// a5	"�" yenChr 
				dc.b	 76, 104	// a6	brokenVertBarChr
									// a7	"�" sectionChr
				dc.b	 77, 105	// a8	"�" spacingDiaeresisChr
									// a9	"�" copyrightChr 
				dc.b	133, 96	// aa	"�" feminineOrdinalChr
									// ab	"�" leftGuillemetChr
				dc.b	106, 38	// ac	"�" notChr 
									// ad	softHyphenChr
				dc.b	107, 78	// ae	"�" registeredChr
									// af	"�" spacingMacronChr
				dc.b	108, 95	// b0	"�" degreeChr 
									// b1	"�" plusMinusChr
				dc.b	124, 126	// b2	superscript2Chr
									// b3	superscript3Chr
				dc.b	 79, 109	// b4	"�" spacingAcuteChr
									// b5	"�" microChr
				dc.b	110, 111	// b6	"�" paragraphChr
									// b7	middleDotChr
				dc.b	 80, 122	// b8	"�" spacingCedillaChr
									// b9	superscript1Chr
				dc.b	199, 201	// ba	"�" masculineOrdinalChr
									// bb	"�" rightGullemetChr
				dc.b	118, 119	// bc	fractOneQuarterChr
									// bd	fractOneHalfChr
				dc.b	120,  81	// be	fractThreeQuartersChr
									// bf	"�" invertedQuestionChr
				dc.b	133, 133	// c0	"�" upAGraveChr
									// c1	"�" upAAcuteChr
				dc.b	133, 133	// c2	"�" upACircumflexChr
									// c3	"�" upATildeChr
				dc.b	133, 133	// c4	"�" upADiaeresisChr
									// c5	"�" upARingChr
				dc.b	148, 152	// c6	"�" upAEChr
									// c7	"�" upCCedillaChr
				dc.b	160, 160	// c8	"�" upEGraveChr
									// c9	"�" upEAcuteChr
				dc.b	160, 160	// ca	"�" upECircumflexChr
									// cb	"�" upEDiaeresisChr
				dc.b	177, 177	// cc	"�" upIGraveChr
									// cd	"�" upIAcuteChr
				dc.b	177, 177	// ce	"�" upICircumflexChr
									// cf	"�" upIDiaeresisChr
				dc.b	158, 195	// d0	upEthChr
									// d1	"�" upNTildeChr
				dc.b	199, 199	// d2	"�" upOGraveChr
									// d3	"�" upOAcuteChr
				dc.b	199, 199	// d4 "�" upOCircumflexChr
									// d5	"�" upOTildeChr
				dc.b	199, 98	// d6	"�" upODiaeresisChr
									// d7	multiplyChr
				dc.b	199, 232	// d8	"�" upOSlashChr
									// d9	"�" upUGraveChr
				dc.b	232, 232	// da	"�" upUAcuteChr
									// db "�" upUCircumflexChr
				dc.b	232, 248	// dc	"�" upUDiaeresisChr
									// dd	upYAcuteChr
				dc.b	229, 226	// de	upThorn
									// df	"�" lowSharpSChr
				dc.b	133, 133	// e0	"�" lowAGraveChr
									// e1	"�" lowAAcuteChr
				dc.b	133, 133	// e2	"�" lowACircumflexChr
									// e3	"�" lowATildeChr
				dc.b	133, 133	// e4	"�" lowADiaeresisChr
									// e5	"�" lowARingChr
				dc.b	148, 152	// e6	"�" lowAEChr
									// e7	"�" lowCCedillaChr
				dc.b	160, 160	// e8	"�" lowEGraveChr
									// e9	"�" lowEAcuteChr
				dc.b	160, 160	// ea	"�" lowECircumflexChr
									// eb	"�" lowEDiaeresisChr
				dc.b	177, 177	// ec	"�" lowIGraveChr
									// ed	"�" lowIAcuteChr
				dc.b	177, 177	// ee	"�" lowICircumflexChr
									// ef	"�" lowIDiaeresisChr
				dc.b	158, 195	// f0	"�" lowEthChr
									// f1	"�" lowNTildeChr
				dc.b	199, 199	// f2	"�" lowOGraveChr
									// f3	"�" lowOAcuteChr
				dc.b	199, 199	// f4	"�" lowOCircumflexChr
									// f5 "�" lowOTildeChr
				dc.b	199, 99	// f6	"�" lowODiaeresisChr
									// f7	"�" divideChr
				dc.b	199, 232	// f8	"�" lowOSlashChr
									// f9	"�" lowUGraveChr
				dc.b	232, 232	// fa	"�" lowUAcuteChr
									// fb	"�" lowUCircumflexChr
				dc.b	232, 248	// fc	"�" lowUDiaeresisChr
									// fd	lowYAcuteChr
				dc.b	229, 248	// fe	lowThorn
									// ff	"�" lowYDiaeresisChr


#pragma options align=reset
}

